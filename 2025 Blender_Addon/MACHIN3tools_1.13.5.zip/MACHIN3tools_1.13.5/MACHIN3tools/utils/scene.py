import bpy

from mathutils import Vector, Quaternion

def create_scene(context, name="Scene", inherit=True, ensure_user=True, force_new_comp=False):
    if inherit:
        scene = context.scene.copy()
        scene.name = name

        for col in scene.collection.children:
            scene.collection.children.unlink(col)

        for obj in scene.collection.objects:
            scene.collection.objects.unlink(obj)

    else:
        scene = bpy.data.scenes.new(name)

    if ensure_user:

        if bpy.app.version >= (5, 0, 0) and force_new_comp:
            scene.compositing_node_group = None

        ensure_compositor_nodes(scene)

    return scene

def ensure_compositor_node_tree(scene):
    if bpy.app.version >= (5, 0, 0):
        tree = scene.compositing_node_group

        if not tree:
            tree = bpy.data.node_groups.new("Compositor Nodes", "CompositorNodeTree")

            scene.compositing_node_group = tree

        image_in_outs = [item for item in tree.interface.items_tree if item.item_type == 'SOCKET' and item.in_out == 'OUTPUT' and item.socket_type == 'NodeSocketColor']

        if not image_in_outs:
            tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")

        return tree

    else:
        if not scene.use_nodes:
            scene.use_nodes = True

        return scene.node_tree

def ensure_compositor_nodes(scene, use_nodes=False):
    tree, input, output = ensure_composite_input_and_output(scene)

    if input.scene != scene:
        input.scene = scene

    if bpy.app.version < (5, 0, 0):
        scene.use_nodes = use_nodes

def set_cursor(matrix=None, location=Vector(), rotation=Quaternion()):
    cursor = bpy.context.scene.cursor

    if matrix:
        cursor.location = matrix.to_translation()
        cursor.rotation_quaternion = matrix.to_quaternion()
        cursor.rotation_mode = 'QUATERNION'

    else:
        cursor.location = location

        if cursor.rotation_mode == 'QUATERNION':
            cursor.rotation_quaternion = rotation

        elif cursor.rotation_mode == 'AXIS_ANGLE':
            cursor.rotation_axis_angle = rotation.to_axis_angle()

        else:
            cursor.rotation_euler = rotation.to_euler(cursor.rotation_mode)

def get_composite_output(scene):
    tree = ensure_compositor_node_tree(scene)

    if bpy.app.version >= (5, 0, 0):
        output = tree.nodes.get('Group Output')

        if not output:
            for node in tree.nodes:
                if node.type == 'GROUP_OUTPUT':
                    return node

        return output

    else:
        output = tree.nodes.get('Composite')

        if not output:
            for node in scene.node_tree.nodes:
                if node.type == 'COMPOSITE':
                    return node

        return output

def get_composite_input(scene):
    tree = ensure_compositor_node_tree(scene)

    if bpy.app.version >= (5, 0, 0):
        input = tree.nodes.get('Render Layers')

        if not input:
            for node in tree.nodes:
                if node.type == 'R_LAYERS':
                    return node

        return input

    else:
        input = tree.nodes.get('Render Layers')

        if not input:
            for node in scene.node_tree.nodes:
                if node.type == 'R_LAYERS':
                    return node

        return input

def get_composite_viewer(scene):
    tree = ensure_compositor_node_tree(scene)

    if bpy.app.version >= (5, 0, 0):
        viewer = tree.nodes.get('Viewer')

        if not viewer:
            for node in tree.nodes:
                if node.type == 'VIEWER':
                    return node

        return viewer

def ensure_composite_input_and_output(scene):
    output = get_composite_output(scene)
    input = get_composite_input(scene)

    tree = ensure_compositor_node_tree(scene)

    if not output and not input:
        input = tree.nodes.new('CompositorNodeRLayers')
        input.scene = scene
        input.location.x = -300

        output = tree.nodes.new('NodeGroupOutput' if bpy.app.version >= (5, 0, 0) else 'CompositorNodeComposite')
        output.location.x = 300

        tree.links.new(input.outputs[0], output.inputs[0])

    elif not output:
        output = tree.nodes.new('NodeGroupOutput' if bpy.app.version >= (5, 0, 0) else 'CompositorNodeComposite')
        output.location.x = 300

        tree.links.new(input.outputs[0], output.inputs[0])

    elif not input:
        input = tree.nodes.new('CompositorNodeRLayers')
        input.scene = scene
        input.location.x = -300

        tree.links.new(input.outputs[0], output.inputs[0])

    return tree, input, output

def clear_compositor_nodes(scene):
    if bpy.app.version >= (5, 0, 0):
        if tree := scene.compositing_node_group:
            tree.nodes.clear()

    else:
        scene.node_tree.nodes.clear()
        scene.use_nodes = False

def get_composite_glare(scene, glare_type='BLOOM', force=False):
    tree = ensure_compositor_node_tree(scene)

    for node in tree.nodes:
        if node.type == 'GLARE':
            if bpy.app.version >= (5, 0, 0):
                if node.inputs[1].default_value == glare_type.title():
                    return node

            else:
               if node.glare_type == glare_type:
                return node

    if force:
        glare = tree.nodes.new('CompositorNodeGlare')
        glare.name = glare_type.title()
        glare.label = glare_type.title()

        if bpy.app.version >= (5, 0, 0):

            glare.inputs[1].default_value = glare_type.title()
            glare.inputs[3].default_value = 0.7
        else:
            glare.glare_type = glare_type

            glare.inputs[1].default_value = 0.7
        output = get_composite_output(scene)

        if output and (links := output.inputs[0].links):

            move_nodes = [output]
            preceding = links[0].from_node

            while preceding.type == 'REROUTE':
                links = preceding.inputs[0].links
                output = preceding

                move_nodes.append(output)
                preceding = links[0].from_node

            glare.location = Vector((output.location.x - 100, output.location.y + 50))

            for node in move_nodes:
                node.location.x += 100

            tree.links.new(links[0].from_socket, glare.inputs[0])
            tree.links.new(glare.outputs[0], output.inputs[0])

            if bpy.app.version >= (5, 0, 0):
                if (viewer := get_composite_viewer(scene)):
                    if output.type == 'GROUP_OUTPUT':
                        tree.links.new(glare.outputs[0], viewer.inputs[0])

                    viewer.location.x = move_nodes[0].location.x

        return glare

def get_composite_dispersion(scene, force=False):
    tree = ensure_compositor_node_tree(scene)

    for node in tree.nodes:
        if node.type == 'LENSDIST' and node.name == "Dispersion":
            return node

    if force:
        disp = tree.nodes.new('CompositorNodeLensdist')
        disp.name = "Dispersion"
        disp.label = "Dispersion"

        idx = 3 if bpy.app.version >= (5, 0, 0) else 2
        disp.inputs[idx].default_value = 0.02
        output = get_composite_output(scene)

        if output and (links := output.inputs[0].links):
            move_nodes = [output]
            preceding = links[0].from_node

            while preceding.type == 'REROUTE':
                links = preceding.inputs[0].links
                output = preceding

                move_nodes.append(output)
                preceding = links[0].from_node

            disp.location = Vector((output.location.x, output.location.y + 50))

            for node in move_nodes:
                node.location.x += 200

            tree.links.new(links[0].from_socket, disp.inputs[0])
            tree.links.new(disp.outputs[0], output.inputs[0])

            if bpy.app.version >= (5, 0, 0):
                if (viewer := get_composite_viewer(scene)):
                    if output.type == 'GROUP_OUTPUT':
                        tree.links.new(disp.outputs[0], viewer.inputs[0])

                    viewer.location.x = move_nodes[0].location.x

        return disp

def is_bloom(context, simple=True):
    view = context.space_data
    shading = view.shading
    scene = context.scene
    tree = ensure_compositor_node_tree(scene)

    if tree:
        if shading.use_compositor =='ALWAYS' or (view.region_3d.view_perspective == 'CAMERA' and shading.use_compositor == 'CAMERA'):

            if bpy.app.version >= (5, 0, 0):
                glare_nodes = [node for node in tree.nodes if node.type == 'GLARE' and node.inputs[1].default_value == 'Bloom']
            else:
                glare_nodes = [node for node in tree.nodes if node.type == 'GLARE' and node.glare_type == 'BLOOM']

            is_bloom = bool(glare_nodes and not glare_nodes[0].mute)

            if simple:
                return is_bloom

            disp_nodes = [node for node in tree.nodes if node.type == 'LENSDIST' and node.name == 'Dispersion']
            is_disp = bool(disp_nodes and not disp_nodes[0].mute)

            if simple:
                return is_bloom or is_disp
            else:
                return {'is_bloom': is_bloom,
                        'is_dispersion': is_disp}

    if simple:
        return False
    else:
        return {'is_bloom': False,
                'is_dispersion': False}
