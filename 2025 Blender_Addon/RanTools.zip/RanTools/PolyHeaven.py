from .utils import *
import requests
import json
import os
import zipfile
import bpy.utils.previews
from requests.api import options
import bpy
import time
import multiprocessing.dummy as multiprocessing
import sys
import urllib
from urllib import request
import warnings
from .t3dn_bip import previews
import certifi
#import asynciof
#import aiofiles
#import aiohttp

previewSize = 256
searchTerm = "Asphalt"
result_number = 0
quality = '2K'
sbsar_quality = "LQ"
texture_format = 'jpg'
sortby = 'popular'
hdri_preview_collections = {}
hdri_preview_list = {}
previews_generated = {}
qualities = {}
previews_generated_offline = {}
qualities_offline = {}
__DIRNAME__ = os.path.dirname(os.path.dirname(__file__))
icon_collection = {}
pcoll = bpy.utils.previews.new()
my_icons_dir = os.path.join(os.path.dirname(__file__), "icons")
pcoll.load("check", os.path.join(my_icons_dir, "checkmark.png"), 'IMAGE')
icon_collection["icons"] = pcoll
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
from requests import Session

s = Session()
# Add headers
s.headers.update(headers)
try:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            response = s.get("http://api.polyhaven.com/assets", params={
                        't': 'hdris', 's': "Dark", 'c': ''
                    }, headers=headers, timeout=2,verify=False)
        except:
            response = s.get("http://api.polyhaven.com/assets", params={
                        't': 'hdris', 's': "Dark", 'c': ''
                    }, headers=headers, timeout=2,verify=certifi.where())
except:
    pass
def getPreviewsOffline(search="", offset=0, count=8):
    if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt")):
        f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                              "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='w+', newline='', encoding='utf-8')
        f.close()
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
        reader = csv.reader(csvFile, delimiter=',')
        preview_paths = {}
        used = []
        for row in reader:
            if (row[0], row[1]) not in used:
                if os.path.isfile(row[2]):
                    used.append((row[0], row[1]))
                    # if os.path.isfile(os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")):
                    if (search.lower() in row[0].lower() or search.lower() in row[3].lower()) and (os.path.isfile(row[2])):
                        preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")] = preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]+[
                            row[1], ] if os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png") in preview_paths.keys() else [row[1], ]
        # print(list(preview_paths.values()))
        # print(int(len(preview_paths)/16))
        offset = min(offset, int(len(preview_paths)/count))
        page_offset=offset
        offset *= count
        
        # print([offset,min(offset+16,len(preview_paths))])
        paths = list(preview_paths.keys())[
            offset:min(offset+count, len(preview_paths))]
        qualities = list(preview_paths.values())[
            offset:min(offset+count, len(preview_paths))]
        # print(qualities)
        return paths, qualities,page_offset


def savePreviewPar(asset):
    path, url, qualities = asset
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if not os.path.isfile(path):
            with open(path, 'wb') as file:
                try:
                    file.write(requests.get(url, headers=headers,verify=False).content)
                except:
                    file.write(requests.get(url, headers=headers,verify=certifi.where()).content)

def get_available_quality(asset):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            response = s.get(
                f"http://api.polyhaven.com/files/{asset}", timeout=10,verify=False)
        except:
            response = s.get(
                f"http://api.polyhaven.com/files/{asset}", timeout=10,verify=certifi.where())
        json_data = response.json()
        # print(json_data)
        data = []
        for a in json_data['hdri']:
            for k in json_data['hdri'][a].keys():
                data.append((a, a+"-"+k, json_data['hdri'][a][k]['size']))
        # print(data)

        data = sorted(data, key=lambda v: eval(v[0].replace("k", "")))
        return [(a, b) for c, a, b in data]


def get_file_url(name, quality):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            response = s.get(
                f"http://api.polyhaven.com/files/{name}", timeout=10,verify=False)
        except:
            response = s.get(
                f"http://api.polyhaven.com/files/{name}", timeout=10,verify=certifi.where())
        json_data = response.json()
        
        for a in json_data['hdri']:
            for k in json_data['hdri'][a].keys():
                if a+"-"+k == quality:
                    return json_data['hdri'][a][k]['url']


def getPreviewsPar(self, search, category, count=8, sortby='popular', offset=0):
    st = time.time()
    if not os.path.isdir(os.path.join(__DIRNAME__, 'RanTools-Previews')):
        os.mkdir(os.path.join(__DIRNAME__, 'RanTools-Previews'))
    res = preferences().hdri_preview_resolution
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if isConnected():
            search = search.replace("http://polyhaven.com/a/", "")
            
            try:
                try:
                    response = s.get("http://api.polyhaven.com/assets", params={
                        't': 'hdris', 's': search, 'c': category.lower() if category != 'All' else ''
                    }, timeout=10,verify=False)
                except:
                    response = s.get("http://api.polyhaven.com/assets", params={
                        't': 'hdris', 's': search, 'c': category.lower() if category != 'All' else ''
                    }, timeout=10,verify=certifi.where())
                if response.status_code == 200:
                    json_data = response.json()
                    offset = min(offset, int(len(json_data)/count))
                    offset *= count
                    json_data = [a for a in json_data][offset:min(
                        offset+count, len(json_data))]
                    # for a in json_data:
                    #    for b in get_available_quality(a):

                    #        print(type(b[1]))
                    assets = [
                        (
                            os.path.join(
                                __DIRNAME__, 'RanTools-Previews', asset+".png"),
                            f"http://cdn.polyhaven.com/asset_img/thumbs/{asset}.png?width={res}&height={res}",
                            [asset, ]+[a[0] +
                                    f"({round(a[1]/1024/1024,2)} MB)" for a in get_available_quality(asset)]
                        )
                        for asset in json_data
                    ]
                    preview_paths = [path for path, _, qualities in assets]
                    qualities = [qualities for path, _, qualities in assets]
                    # print(preview_paths)
                    previews_to_download=[asset for asset in assets if not os.path.isfile(asset[0])]
                    if len(previews_to_download)>6:
                        with multiprocessing.Pool() as pool:
                            pool.map(savePreviewPar, previews_to_download, chunksize = 2)
                    else:
                        for ase in previews_to_download:
                            savePreviewPar(ase)
                    # with multiprocessing.Pool() as pool:
                    #     pool.map(savePreviewPar, assets, chunksize=2)
                    # for asset in assets:
                        # savePreviewPar(asset)
                    #print("Previews Loaded in ", time.time()-st, "s")
                    #print(time.time()-st)
                    return preview_paths, qualities
            except Exception as e:
                print("ERROR: " ,e)
                #self.report({'WARNING'},"Couldn't Connect")
        else:
            print("Couldn't Connect")
#        self.report({'WARNING'},"Couldn't Connect")
    
    return [], []


def get_asset_url(self, context, name, quality):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if isConnected():
            try:
                try:
                    response = s.get(
                        f"http://api.polyhaven.com/info/{name}", timeout=10,verify=False)
                except:
                    response = s.get(
                        f"http://api.polyhaven.com/info/{name}", timeout=10,verify=certifi.where())
                json_data = response.json()
                # print(json_data)
                # print(response.url)
                asset_name = "Not Found"
                if json_data:
                    tags = json_data["tags"] + \
                        [context.scene.rt_tools.HDRIToSearch, ]
                    asset_name = json_data["name"]

                    asset_url = get_file_url(name, quality)
                    return asset_url, asset_name, quality[quality.index('-')+1:], tags
            except:
                return None, None, None, None
    return None, None, None, None


def hdri_previews_from_directory_items(self, context):
    enum_items = []
    if context is None:
        return enum_items
    directory = os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "RanTools-Previews/")
    if self.name == 'Hdris':
        if "Hdris" not in hdri_preview_collections.keys():
            return [(None, None, None), ]
        pcoll = hdri_preview_collections['Hdris']
    else:
        pcoll = hdri_preview_collections['Downloaded-Hdris']
    if len(pcoll.my_previews) > 0:
        return pcoll.my_previews
    def_dir = directory
    # print(previews_generated)
    if directory and os.path.exists(def_dir):

        for i, name in enumerate(previews_generated if self.name == 'Hdris' else previews_generated_offline):
            # print(name)
            filepath = name
            thumb=pcoll.load_safe(str(name),str(name),'IMAGE')
            enum_items.append(
                (",".join(qualities[i] if self.name == 'Hdris' else [os.path.basename(name).replace(".png", ""), ]+qualities_offline[i]), os.path.basename(name).replace(".png", "").replace("_", " ").title(), "", thumb.icon_id, i))
    pcoll.my_previews = enum_items
    return pcoll.my_previews


class HDRIInfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="name", default="")
    preview: bpy.props.EnumProperty(
        items=hdri_previews_from_directory_items)


class Import_HDRI_Panel(bpy.types.Operator):
    bl_idname = "rtools.import_hdri"
    bl_label = "HDRI Library"
    bl_description = "Search HDRIs Library Panel"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        count = 0
        for item in context.scene.rt_hdris:
            count = count+1
        layout = self.layout
        row = layout.row(align=True)
        layout.ui_units_x = 26 if len(context.scene.rt_hdris) == 2 else 16
        #row.label(text="HDRI Library")
        if not isConnected():
            row.label(text="No Internet", icon='ERROR')

        column = layout.column()
        row = layout.row()
        row = row.split(factor=0.8)
        # row.active_default=True
        row.prop(context.scene.rt_tools, "HDRIToSearch", text="", text_ctxt="")

        row.operator("rtools.search_hdri", text="", icon="VIEWZOOM").offset = 0
        row = layout.row()
        row.prop(context.scene.rt_tools, 'category')
        # layout.label(text=context.scene.downloadProgress)
        if bpy.data.worlds.get("RT_World") and bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World"):
            row = layout.row()
            group = bpy.data.worlds.get(
                "RT_World").node_tree.nodes.get("RT_World")
            row.prop(group.inputs[0], 'default_value', text="Strength")
            row.prop(group.inputs[1], 'default_value', text="Z Offset")
            row.prop(group.inputs[2], 'default_value', text="Rotation")
            row.prop(group.inputs[3], 'default_value', text="Blur")
            row = layout.row()
            row.prop(group.inputs[4], 'default_value', text="Brightness")
            row.prop(group.inputs[5], 'default_value', text="Contrast")
            row.prop(group.inputs[6], 'default_value', text="Hue")
            row.prop(group.inputs[7], 'default_value', text="Saturation")
            row = layout.row()
            row.prop(group.inputs[8], 'default_value', text="")
            row.prop(group.inputs[9], 'default_value', text="Mix Factor")
            row = layout.row()
            row.alignment = 'LEFT'
            #row.prop(context.scene.rt_tools,'extract_sun',emboss=False,icon="TRIA_DOWN" if not context.scene.rt_tools.extract_sun else "TRIA_RIGHT")
            row.prop(context.scene.rt_tools, 'extract_sun')
            if group.inputs[10].default_value == 1:
                row.prop(group.inputs[11], 'default_value', text="Threshold")
                row.prop(group.inputs[12],
                         'default_value', text="Sun Strength")
                row.prop(group.inputs[13], 'default_value', text="")
            row = layout.row()
            row.alignment = 'LEFT'
            #row.prop(context.scene.rt_tools,'extract_sun',emboss=False,icon="TRIA_DOWN" if not context.scene.rt_tools.extract_sun else "TRIA_RIGHT")
            row.prop(context.scene.rt_tools, 'use_solid_color')
            if group.inputs[14].default_value == 1:
                row.prop(group.inputs[15], 'default_value',
                         text="Background Color")
            row = layout.row()
            row.operator('rtools.resetworldnode', icon='LOOP_BACK')
            row.prop(context.scene.render, 'film_transparent')

        column = layout.grid_flow(row_major=True, columns=5)
        if len(hdri_preview_list) > 0:
            for i, item in enumerate(context.scene.rt_hdris):

                column2 = column.box()
                row = column2.row()
                row.label(text="PolyHaven" if item.name !=
                          "Downloaded-Hdris" else "Offline")
                if item.name == "Downloaded-Hdris":
                    row.prop(context.scene.rt_tools,
                             'show_all_offline_hdris', toggle=True)
                column2.template_icon_view(
                    item, "preview", show_labels=True, scale=16 if len(context.scene.rt_hdris) == 1 else 12, scale_popup=8)
                row = column2.row(align=True)
                row.scale_x = 10
                if item.name == "Hdris":
                    row.operator('rtools.search_hdri', icon='FRAME_PREV',
                                 text="Previous", text_ctxt="").offset = -1

                    row.operator('rtools.search_hdri', icon='FRAME_NEXT',
                                 text="Next", text_ctxt="").offset = 1
                elif item.name == "Downloaded-Hdris":
                    op = row.operator('rtools.search_hdri',
                                      icon='FRAME_PREV', text="Previous", text_ctxt="")
                    op.offset_offline = -1
                    op.only_offline = True
                    op = row.operator('rtools.search_hdri',
                                      icon='FRAME_NEXT', text="Next", text_ctxt="")
                    op.offset_offline = 1
                    op.only_offline = True
                for a in item.preview.split(',')[1:]:
                    row = column2.row(align=True)
                    button = row.operator(
                        "rtools.download_hdri", text=a)
                    button.name = item.preview.split(',')[0]
                    button.quality = a[:a.index("(")]

    def invoke(self, context, event):
        lib_path = [
            a.path for a in bpy.context.preferences.filepaths.asset_libraries if a.name == "RanTools Hdris"]

        self.files = [f for f in os.listdir(lib_path[0])] if lib_path else []
        if not context.scene.rt_tools.HDRIToSearch:
            search_offline(self, context, 0)
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):

        return {'FINISHED'}


class RTOOLS_OT_Download_HDRI(bpy.types.Operator):

    bl_idname = "rtools.download_hdri"
    bl_label = "Download"
    bl_description = "Download"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty(options={'HIDDEN'})
    quality: bpy.props.StringProperty(options={'HIDDEN'})
    timer = None
    running = False
    completed = False
    chunkSize = 512 * 1024
    downloaded = 0
    file = None
    response = None
    chunk = None

    def modal(self, context, event):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if event.type == 'TIMER' and not self.running and not self.completed:

                self.file = open(
                    f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}", 'wb')
                #req = urllib.request.Request(self.asset_url, headers={
                #                             'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'})
                #self.response = urllib.request.urlopen(
                #    req, timeout=10, context=ssl.create_default_context(cafile=certifi.where()))
                try:
                    self.response = requests.get(self.asset_url, timeout=10, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}, stream=True,verify=False)
                except:
                    self.response = requests.get(self.asset_url, timeout=10, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}, stream=True,verify=certifi.where())
                self.chunks = self.response.iter_content(chunk_size=self.chunkSize)
                self.running = True

            if event.type == 'TIMER' and self.running:
                try:
                    self.chunk = next(self.chunks, None)
                    #self.chunk = self.response.read(self.chunkSize)

                    if sys.getsizeof(self.chunk) < self.chunkSize:
                        self.file.write(self.chunk)
                        self.downloaded += self.chunkSize
                        self.running = False
                        self.completed = True
                        self.file.close()
                        image = bpy.data.images.load(
                            f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}")
                        rt_world = bpy.data.worlds.new("RT_World") if not bpy.data.worlds.get(
                            "RT_World") else bpy.data.worlds.get("RT_World")

                        rt_world.use_nodes = True
                        nodes = rt_world.node_tree.nodes
                        if not nodes.get("RT_World"):
                            rt_world_node = nodes.new(type="ShaderNodeGroup")
                            rt_world_node.name = "RT_World"
                            rt_world_node.node_tree = bpy.data.node_groups.get(
                                "RT_World")
                        rt_world_node = nodes.get("RT_World")

                        environment = rt_world_node.node_tree.nodes.get(
                            "RT_Environment")
                        # print(environment,rt_world_node)
                        environment.image = image

                        context.scene.world = rt_world
                        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                            csvFileWriter = csv.writer(
                                csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            csvFileWriter.writerow(
                                [self.name, self.quality+f"({round(eval(self.response.headers['content-length'])/1024/1024,2)} MB)", f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}", ",".join(self.tags)])
                        context.scene.downloadProgress = ""
                        context.area.tag_redraw()
                        # context.workspace.status_text_set(None)
                    else:
                        self.file.write(self.chunk)
                        self.downloaded += self.chunkSize

                        progress = f"Status: {format(round((self.downloaded/1024/1024),2),'0.2f')}/{round(eval(self.response.headers['content-length'])/1024/1024,2)} MB"
                        context.scene.downloadProgress = progress
                        # print(context.scene.downloadProgress)
                        # bpy.context.workspace.status_text_set(progress)
                        context.area.tag_redraw()
                # print(context.scene.downloadProgress)
                except:
                    if self.file:
                        self.file.close()
                    if os.path.exists(f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}"):
                        os.remove(
                            f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}")
                    self.cancel(context)
                    self.report({'WARNING'}, "Disconnected")
                    return {'CANCELLED'}
            if self.completed:
                self.cancel(context)
            if event.type == 'ESC' and event.value == 'PRESS':
                if self.file:
                    self.file.close()
                if os.path.exists(f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}"):
                    os.remove(
                        f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}")
                self.cancel(context)
                context.area.tag_redraw()
                self.report({'WARNING'}, "Cancelled")
                return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        self.completed = False
        wm = context.window_manager
        self.asset_url, self.asset_name, self.asset_type, self.tags = get_asset_url(
            self, context, self.name, self.quality)
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()

        if self.asset_url:

            if not os.path.isdir(preferences().hdris_folder):
                os.mkdir(preferences().hdris_folder)
            if not os.path.isfile(f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}"):

                self.timer = wm.event_timer_add(0.05, window=context.window)
                wm.modal_handler_add(self)
                self.running = False
                return {'RUNNING_MODAL'}
            else:
                image = bpy.data.images.load(
                    f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}")
                rt_world = bpy.data.worlds.new("RT_World") if not bpy.data.worlds.get(
                    "RT_World") else bpy.data.worlds.get("RT_World")

                rt_world.use_nodes = True
                nodes = rt_world.node_tree.nodes
                if not nodes.get("RT_World"):
                    rt_world_node = nodes.new(type="ShaderNodeGroup")
                    rt_world_node.name = "RT_World"
                    rt_world_node.node_tree = bpy.data.node_groups.get(
                        "RT_World")
                rt_world_node = nodes.get("RT_World")

                environment = rt_world_node.node_tree.nodes.get(
                    "RT_Environment")
                # print(environment,rt_world_node)
                environment.image = image

                context.scene.world = rt_world

                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                    reader = csv.reader(csvFile, delimiter=',')
                    reader = [[row[0], row[2]] for row in reader]
                    if [self.name, f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}"] not in reader:

                        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                            csvFileWriter = csv.writer(
                                csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            size = round(os.path.getsize(
                                f"{os.path.join(preferences().hdris_folder,self.asset_name)+f'_{self.quality}'}")/1024/1024, 2)
                            csvFileWriter.writerow(
                                [self.name, self.quality+f"({size} MB)", f"{os.path.join(preferences().hdris_folder,self.asset_name+f'_{self.quality}')}.{self.asset_type}", ",".join(self.tags)])
        else:
            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                reader = csv.reader(csvFile, delimiter=',')
                for row in reader:
                    # (self.name,self.quality)
                    # print(row[0],row[1][:row[1].index("(")])
                    if row[0] == self.name and row[1][:row[1].index("(")] == self.quality:
                        if os.path.exists(row[2]):
                            image = bpy.data.images.load(row[2])
                            rt_world = bpy.data.worlds.new("RT_World") if not bpy.data.worlds.get(
                                "RT_World") else bpy.data.worlds.get("RT_World")

                            rt_world.use_nodes = True
                            nodes = rt_world.node_tree.nodes
                            if not nodes.get("RT_World"):
                                rt_world_node = nodes.new(
                                    type="ShaderNodeGroup")
                                rt_world_node.name = "RT_World"
                                rt_world_node.node_tree = bpy.data.node_groups.get(
                                    "RT_World")
                            rt_world_node = nodes.get("RT_World")

                            environment = rt_world_node.node_tree.nodes.get(
                                "RT_Environment")
                            # print(environment,rt_world_node)
                            environment.image = image

                            context.scene.world = rt_world
        return {'FINISHED'}

    def invoke(self, context, event):
        if bpy.data.worlds.get('RT_World') is None:
            path = os.path.join(os.path.dirname(os.path.abspath(
                __file__)), "Assets", "ExtraAssets.blend", "World")
            bpy.ops.wm.append(
                directory=path,
                filename='RT_World', autoselect=False
            )
            if context.scene.world:
                bpy.data.worlds.get('RT_World').cycles.sampling_method=context.scene.world.cycles.sampling_method
                bpy.data.worlds.get('RT_World').cycles.sample_map_resolution=context.scene.world.cycles.sample_map_resolution
                bpy.data.worlds.get('RT_World').cycles.max_bounces=context.scene.world.cycles.max_bounces
        return self.execute(context)

    def cancel(self, context):
        context.workspace.status_text_set(None)
        wm = context.window_manager
        wm.event_timer_remove(self.timer)


def search_hdri(self, context, offset, offset_offline):
    context.scene.rt_hdris.clear()
    (paths, quality) = getPreviewsPar(self, context.scene.rt_tools.HDRIToSearch,
                                      context.scene.rt_tools.category, offset=offset)
    global previews_generated
    previews_generated = paths
    global qualities
    qualities = quality

    for pcoll in hdri_preview_collections.values():
        pcoll.clear()
        bpy.utils.previews.remove(pcoll)
    hdri_preview_collections.clear()
    hdri_preview_list.clear()
    temp = bpy.context.scene.rt_hdris.add()
    temp.name = 'Hdris'
    hdri_preview_list['Hdris'] = paths
    pcoll = previews.new()
    pcoll.my_previews = ()
    hdri_preview_collections['Hdris'] = pcoll
    (paths_offline, quality_offline,pageoffset) = getPreviewsOffline(
        context.scene.rt_tools.HDRIToSearch if not context.scene.rt_tools.show_all_offline_hdris else "", offset=offset_offline)
    global previews_generated_offline
    previews_generated_offline = paths_offline
    global qualities_offline
    qualities_offline = quality_offline
    temp = bpy.context.scene.rt_hdris.add()
    temp.name = 'Downloaded-Hdris'
    hdri_preview_list['Downloaded-Hdris'] = paths_offline
    pcoll2 = previews.new()
    pcoll2.my_previews = ()
    hdri_preview_collections['Downloaded-Hdris'] = pcoll2


def search_offline(self, context, offset_offline):

    for name, pcoll in hdri_preview_collections.items():
        if name == "Downloaded-Hdris":
            pcoll.clear()
            bpy.utils.previews.remove(pcoll)
    (paths_offline, quality_offline,pageoffset) = getPreviewsOffline(
        context.scene.rt_tools.HDRIToSearch if not context.scene.rt_tools.show_all_offline_hdris else "", offset=offset_offline)
    global previews_generated_offline
    previews_generated_offline = paths_offline
    global qualities_offline
    qualities_offline = quality_offline
    for i, ob in enumerate(context.scene.rt_hdris):
        if ob.name == "Downloaded-Hdris":
            context.scene.rt_hdris.remove(i)
    temp = bpy.context.scene.rt_hdris.add()
    temp.name = 'Downloaded-Hdris'
    hdri_preview_list['Downloaded-Hdris'] = paths_offline
    pcoll2 = previews.new()
    pcoll2.my_previews = ()
    hdri_preview_collections['Downloaded-Hdris'] = pcoll2
    return pageoffset

def search_hdri_update(self, context):
    context.scene.rt_tools.HDRIpageIndex = 0
    search_hdri(self, context, offset=0,
                offset_offline=context.scene.rt_tools.HDRIpageIndexOffline)


def show_all_hdri_update(self, context):
    search_hdri(self, context, offset=0,
                offset_offline=context.scene.rt_tools.HDRIpageIndexOffline)


class RTOOLS_OT_Search_HDRI(bpy.types.Operator):
    bl_idname = "rtools.search_hdri"
    bl_label = "Search"
    bl_description = "Search"
    bl_options = {'REGISTER', 'UNDO'}
    offset: bpy.props.IntProperty(default=0, options={'SKIP_SAVE', 'HIDDEN'})
    offset_offline: bpy.props.IntProperty(
        default=0, options={'SKIP_SAVE', 'HIDDEN'})
    only_offline: bpy.props.BoolProperty(
        default=False, options={'SKIP_SAVE', 'HIDDEN'})
    # bl_property="name"

    @classmethod
    def description(cls, context, properties):
        if properties.offset == 1:
            return translate_text("Next Page")
        elif properties.offset == -1:
            return translate_text("Previous Page")
        else:
            return translate_text("Search")

    def execute(self, context):
        if self.offset == 1:
            context.scene.rt_tools.HDRIpageIndex = context.scene.rt_tools.HDRIpageIndex+1
        elif self.offset == -1:
            context.scene.rt_tools.HDRIpageIndex = max(
                0, context.scene.rt_tools.HDRIpageIndex-1)
        else:
            context.scene.rt_tools.HDRIpageIndex = 0
        if self.offset_offline == 1:
            context.scene.rt_tools.HDRIpageIndexOffline = context.scene.rt_tools.HDRIpageIndexOffline+1
        elif self.offset_offline == -1:
            context.scene.rt_tools.HDRIpageIndexOffline = max(
                0, context.scene.rt_tools.HDRIpageIndexOffline-1)
        else:
            context.scene.rt_tools.HDRIpageIndexOffline = 0
        if self.only_offline:
            context.scene.rt_tools.HDRIpageIndexOffline=search_offline(
                self, context, context.scene.rt_tools.HDRIpageIndexOffline)
        else:
            search_hdri(self, context, offset=context.scene.rt_tools.HDRIpageIndex,
                        offset_offline=context.scene.rt_tools.HDRIpageIndexOffline)

        return {'FINISHED'}


class RTOOLS_OT_Reset_World_Node(bpy.types.Operator):
    bl_idname = "rtools.resetworldnode"
    bl_label = "Reset"
    bl_description = "Reset all the input values of the RT_World Node"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if bpy.data.worlds.get("RT_World") and bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World"):
            group = bpy.data.worlds.get(
                "RT_World").node_tree.nodes.get("RT_World")
            group.inputs[0].default_value = 1
            group.inputs[1].default_value = 0
            group.inputs[2].default_value = 0
            group.inputs[3].default_value = 0
            group.inputs[4].default_value = 0
            group.inputs[5].default_value = 0
            group.inputs[6].default_value = 0.5
            group.inputs[7].default_value = 1
            group.inputs[8].default_value = (1, 1, 1, 1)
            group.inputs[9].default_value = 0
            group.inputs[10].default_value = 0
            group.inputs[11].default_value = 3
            group.inputs[12].default_value = 0.1
            group.inputs[13].default_value = (1, 1, 1, 1)
            context.scene.rt_tools.extract_sun = False
            group.inputs[14].default_value = 0
            group.inputs[15].default_value = (0, 0, 0, 1)
            context.scene.rt_tools.use_solid_color = False
        return {'FINISHED'}
