bl_info = {
    "name": "RanTools",
    "author": "Amandeep",
    "description": "Collection of Hard Surface, Curve, Rendering, Lighting, Modifier & Baking tools that aim to increase performance and help users work efficiently.",
    "blender": (2, 91, 0),
    "version": (3, 2, 7),
    "location": "View3D",
    'doc_url': 'https://rantools.github.io/rantools',
    "category": "Object",
}
#region INFORMATION
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or 
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from .PolyHeaven import *
from .AmbientCG import *
from .NodeTools import *
from .RenderFeatures import *
from .Prefrences import *
from .ModsPreset import *
from .Mirror import *
from .Light import *
from .ExtendedPanel import *
from .Emission import *
from .BooleanCleanup import *
from .backdrop import *
from .AssetManager import *
from .AppendFeatures import *
from .MaterialMenu import *
from .UVGrid import *
from .utils import *
from .Menus import *
from .extrautils import *
from .BackUpManager import *
from .BakeTools import *
from .LightGroups import *
from .RemeshAndCloth import *
from .CurveTools import *
from .ParticleTools import *
from .Booleans import *
from .translations import langs
from .addon_update_checker import *
#from .Test import *
import rna_keymap_ui
from bpy.app.handlers import persistent
from bpy.types import Menu, PropertyGroup
from bpy.props import *
import bpy
from mathutils import Matrix
import gpu
from random import random
import bgl
from gpu_extras.batch import batch_for_shader
import re as regex
# endregion
class RTOOLS_Intersect(bpy.types.Operator):
    bl_idname = "rtools.intersect"
    bl_label = "Make It Flow"
    bl_description = "Add Flow Map To Image"
    bl_options = {"REGISTER","UNDO"}
    def drawHandler(self):
        if self.shader is not None and self.batch is not None:
            gpu.state.line_width_set(3)
            gpu.state.blend_set("ALPHA") 
            self.shader.bind()
            self.shader.uniform_float("color", (1, 1, 1, 0.4))
            self.batch.draw(self.shader)
    def execute(self, context):
        
        return {'RUNNING_MODAL'}
    def modal(self, context, event):
        if event.type=='LEFTMOUSE' and event.value=="PRESS":
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            return {'FINISHED'}
        if event.type=='MOUSEMOVE':
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            if object is not None:
                obj=object
                obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                #obj.data.calc_loop_triangles()
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                #bm.verts.ensure_lookup_table()
                #bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
                coords = [obj.matrix_world@v.co for v in bm.verts]
                indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges if e in bm.faces[index].edges] 
                #indices=obj.data.loop_triangles
                vertex_colors = [(random(), random(), random(), 1) for _ in range(len(obj.data.vertices))]
                self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
                if self.points:
                    coords = [obj.matrix_world@v.co for v in bm.verts if v in bm.faces[index].verts]
                    self.batch = batch_for_shader(self.shader, 'POINTS', {"pos": coords})
                else:
                    self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
                context.area.tag_redraw()
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.points=event.ctrl
        context.window_manager.modal_handler_add(self)
        self.shader=None
        self.batch=None
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(self.drawHandler, (), 'WINDOW', 'POST_VIEW')
        return self.execute(context)
class RTOOLS_OT_Create_Custom_Op(bpy.types.Operator):
    bl_idname = "rtools.createop"
    bl_label = "Create Custom Macro"
    bl_description = "Create Custom Macro Operators"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        newContent=""
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "Test.py"), mode='r', newline='', encoding='utf-8') as test:
            ogContent=test.read()
            #Operators=bpy.context.window_manager.clipboard.replace('bpy','        bpy').replace('bpy.ops.rtools.deleteinfopanel()',"") if context.scene.rt_tools.custom_operator_operations =="" else context.scene.rt_tools.custom_operator_operations.replace('bpy','\n        bpy')
            FinalOperators=[]
            properties=[]
            if context.scene.rt_tools.custom_operator_operations =="":
                for op in context.scene.OperatorLines:
                    paramString=""
                    for arg in op.arguments:
                        if arg.value!="":
                            
                            properties.append(f"\n    {arg.name}:{arg.type.replace(arg.oGValue,arg.value)}")
                        oGValueString=f"'{arg.oGValue}'"
                        paramString+=f"{arg.name}={arg.oGValue if not arg.isString else oGValueString}," if arg.value=="" else f"{arg.name}=self.{arg.name},"
                    FinalOperators.append(op.line.replace(op.params,paramString).replace('bpy.','        bpy.').replace('AObject',"context.active_object").replace('SObject','Diff(context.selected_objects,[context.active_object])[0]'))
            else:
                Operators=context.scene.rt_tools.custom_operator_operations.replace('bpy.','\n        bpy.')
                for op in Operators.split('\n'):
                    if 'space_data.context' not in op and 'Deleted' not in op and op!='':
                        FinalOperators.append(op)
            Operators='\n'.join(FinalOperators)
            newContent=ogContent.replace("custom_operators=[",f"custom_operators=[RT_Custom_{context.scene.rt_tools.custom_operator_name.replace(' ','_')},")
            newContent=newContent.replace("#NewOpPlaceHolder","""#NewOpPlaceHolder
#{name}
class {name}(bpy.types.Operator):
    bl_idname = "rt_custom.{nameLower}"
    bl_label = "{nameOG}"
    bl_description = "{nameOG}"
    bl_options = {{'REGISTER','UNDO'}}
    {properties}
    def execute(self, context):
{operations}
        return{{'FINISHED'}}
#{name}""".format(properties="".join(properties),operations=Operators,nameOG=context.scene.rt_tools.custom_operator_name,name="RT_Custom_"+context.scene.rt_tools.custom_operator_name.replace(" ","_"),nameLower=context.scene.rt_tools.custom_operator_name.lower().replace(" ","_")))
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "Test.py"), mode='w', newline='', encoding='utf-8') as test:
            test.write(newContent)
        return {'FINISHED'}

#context.scene.rt_tools.custom_operator_operations.replace('bpy','\n        bpy')
#clipboard = bpy.context.window_manager.clipboard
class RTOOLS_OT_Clear_Info(bpy.types.Operator):
    bl_idname = "rtools.deleteinfopanel"
    bl_label = "Clear"
    bl_description = "Add Flow Map To Image"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        areaOG = context.window.screen.areas[0].type
        context.window.screen.areas[0].type = 'INFO'
        bpy.ops.info.select_all({'area':context.window.screen.areas[0]}, action='SELECT')
        bpy.ops.info.report_delete({'area':context.window.screen.areas[0]})
        context.window.screen.areas[0].type = areaOG
        context.scene.OperatorLines.clear()
        return {'FINISHED'}
class RTOOLS_OT_Copy_Info(bpy.types.Operator):
    bl_idname = "rtools.copyinfopanel"
    bl_label = "Fetch"
    bl_description = "Fetch Commands From INFO Panel"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        #obj=context.active_object
        #bm=bmesh.new()
        #bm.from_mesh(obj.data)
        #verts=[]
        #for f in bm.faces:
        #    verts.append(([f"vertex3D{((v.co[0]*360)+360, (v.co[1]*360)+360,(v.co[2]*360)+360)}" for v in f.verts]))
        #print(verts)
        #print([(f.verts[0],f.verts[1],f.verts[2],f.verts[3],) for f in bm.faces])
        #print([((obj.matrix_world @v.co)[0]*100,(obj.matrix_world @v.co)[1]*100,(obj.matrix_world @v.co)[2]*100) for v in obj.data.vertices])
        #print([(e.vertices[0],e.vertices[1]) for e in obj.data.edges])
        areaOG = context.window.screen.areas[0].type
        context.window.screen.areas[0].type = 'INFO'
        bpy.ops.info.select_all({'area':context.window.screen.areas[0]}, action='SELECT')
        bpy.ops.info.report_copy({'area':context.window.screen.areas[0]})
        context.window.screen.areas[0].type = areaOG
        Operators=bpy.context.window_manager.clipboard.replace('bpy.ops.rtools.deleteinfopanel()',"")
        context.scene.OperatorLines.clear()
        for op in Operators.split('\n'):
            if 'space_data.context' not in op and 'Deleted' not in op and op!='':
                t=context.scene.OperatorLines.add()
                t.line=op
                t.params=regex.search(r"\((.*)\)",op)[1] if regex.search(r"\((.*)\)",op) is not None else t.params
                for arg,value in getArguments(op).items():
                    a=t.arguments.add()
                    a.name=arg
                    value=f"{value}"
                    a.value=value
                    a.oGValue=value
                    #print(arg,"=>",f"{value}")
                    if bool(regex.match('^[a-zA-Z_]+$', value)) and value!='False' and value!='True':
                        a.type=f"bpy.props.StringProperty(default='{value}',name='{arg.capitalize()}')"
                        a.isString=True
                    else:
                       
                        if eval(f"type({value})")==bool:
                            a.type=f"bpy.props.BoolProperty(default={value},name='{arg.capitalize()}')"
                        elif eval(f"type({value})")==float:
                            a.type=f"bpy.props.FloatProperty(default={value},name='{arg.capitalize()}')"
                        elif eval(f"type({value})")==int:
                            a.type=f"bpy.props.IntProperty(default={value},name='{arg.capitalize()}')"
                        elif eval(f"type({value})")==tuple:
                            types=list(map(type, eval(value)))
                            size=len(types)
                            if len([n for n in types if n==float])>0:
                                a.type=f"bpy.props.FloatVectorProperty(default={value},size={size},name='{arg.capitalize()}')"
                            elif len([n for n in types if n==int])>0:
                                a.type=f"bpy.props.IntVectorProperty(default={value},size={size},name='{arg.capitalize()}')"
                            elif len([n for n in types if n==bool])>0:
                                a.type=f"bpy.props.BoolVectorProperty(default={value},size={size},name='{arg.capitalize()}')"
                            elif len([n for n in types if n==tuple])>0:
                                a.type=""
                                a.value=""
                        #elif eval(f"type({value})")==dict:
                        else:
                            a.type=""
                            a.value=""

        #Operators='\n'.join(FinalOperators)
        return {'FINISHED'}

class RTOOLS_OT_Remove_Saved_View(bpy.types.Operator):
    bl_idname = "rtools.removesavedview"
    bl_label = "Save View"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        index=context.scene.SavedViewsIndex
        context.scene.saved_views.remove(index)
        return {'FINISHED'}

class RTOOLS_OT_Save_View(bpy.types.Operator):
    bl_idname = "rtools.saveview"
    bl_label = "Save View"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        def flatten(mat):
            dim = len(mat)
            return [mat[i][j] for i in range(dim) 
                          for j in range(dim)]
        a=context.scene.saved_views.add()
        if context.scene.rt_tools.view_name!="":
            a.name=context.scene.rt_tools.view_name
        else:
            name="View"
            ogName=name
            i=1
            while name in [n.name for n in context.scene.saved_views]:
                name=ogName+f" {i}"
                i+=1
            a.name=name
        mat=context.space_data.region_3d.view_matrix.copy()
        a.matrix=flatten(mat)
        #print(len(context.scene.saved_views))
        
        return {"FINISHED"}
class RTOOLS_OT_Set_View(bpy.types.Operator):
    bl_idname = "rtools.setview"
    bl_label = "Set View"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty(options={'HIDDEN'})
    next:bpy.props.IntProperty(default=0,options={'HIDDEN'})
    def execute(self, context):
        if len(context.scene.saved_views)>0:
            context.scene.SavedViewsIndex=(context.scene.SavedViewsIndex+self.next)%len(context.scene.saved_views)
            index=context.scene.SavedViewsIndex
            context.space_data.region_3d.view_matrix=Matrix([context.scene.saved_views[index].matrix[:4],context.scene.saved_views[index].matrix[4:8],context.scene.saved_views[index].matrix[8:12],context.scene.saved_views[index].matrix[12:16]])
        return {'FINISHED'}
class RT_Test2(bpy.types.Operator):
    bl_idname = "rtools.test"
    bl_label = "UV Project From View"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty()
    def execute(self, context):
        obj=context.active_object
        obj_to_align=Diff(context.selected_objects,[obj])[0]
        mesh=obj.data
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='EDIT')
        selected_face_center=None
        #bm = bmesh.from_edit_mesh(mesh)
        selected_face_center=obj.matrix_world@mesh.polygons[mesh.polygons.active].center
        normal=mesh.polygons[mesh.polygons.active].normal
        #print(mesh.polygons.active)
                #break
        if selected_face_center is not None:
            obj_to_align.location=selected_face_center
            normal
            z = Vector((0,0,1))
            if normal!=Vector((0,0,0)):
                rot = z.rotation_difference( normal ).to_euler()
                obj_to_align.rotation_euler= rot
        return {'FINISHED'}
class RTOOLS_Project_From_Saved_View(bpy.types.Operator):
    bl_idname = "rtools.projectfromsavedview"
    bl_label = "UV Project From View"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty()
    def execute(self, context):
        initMat=context.space_data.region_3d.view_matrix.copy()
        bpy.ops.rtools.setview('INVOKE_DEFAULT')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        #bpy.ops.uv.project_from_view(scale_to_bounds=False)
        bpy.ops.rtools.projectfromview('INVOKE_DEFAULT')
        
        # endregionbpy.ops.object.mode_set(mode='OBJECT')
        context.space_data.region_3d.view_matrix=initMat
        return {'FINISHED'}
# Region TESTING
class RT_RenderSettingsSave2(bpy.types.Operator):
    bl_idname = "rtools.rendersettingsave"
    bl_label = "Render Preset Save"
    bl_description = "Create Render Settings Preset"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        #print(inspect.getmembers(context.scene.cycles))
        #print(inspect.getmembers(context.scene.camera.data))
        for (arg,value) in inspect.getmembers(context.scene.camera.data):
                if arg not in {'cycles','copy','background_images','animation_data_create','animation_data_clear','__doc__','__module__','__slots__','bl_rna','bloom_color','rna_type','gi_cache_info','motion_blur_position','__annotations__','denoiser','device','register','progressive','preview_denoiser','rolling_shutter_type','sampling_pattern','tile_order','texture_limit_render','texture_limit','unregister','use_layer_samples','feature_set','filter_type','motion_blur_position','pixel_filter_type','name'}:
                    if 'bake' not in arg and 'debug' not in arg:
                    
                        if True:
                            if eval(f"type({value})")==bool:
                                print(f"{arg}:bpy.props.BoolProperty(default={value},name='{arg.capitalize().replace('_',' ')}')")
                            elif eval(f"type({value})")==float:
                                print(f"{arg}:bpy.props.FloatProperty(default={value},name='{arg.capitalize().replace('_',' ')}')")
                            elif eval(f"type({value})")==int:
                                print(f"{arg}:bpy.props.IntProperty(default={value},name='{arg.capitalize().replace('_',' ')}')")
                            elif eval(f"type({value})")==tuple:
                                types=list(map(type, eval(value)))
                                size=len(types)
                                if len([n for n in types if n==float])>0:
                                    print(f"{arg}:bpy.props.FloatVectorProperty(default={value},size={size},name='{arg.capitalize().replace('_',' ')}')")
                                elif len([n for n in types if n==int])>0:
                                    print(f"{arg}:bpy.props.IntVectorProperty(default={value},size={size},name='{arg.capitalize().replace('_',' ')}')")
                                elif len([n for n in types if n==bool])>0:
                                    print(f"{arg}:bpy.props.BoolVectorProperty(default={value},size={size},name='{arg.capitalize().replace('_',' ')}')")
                                elif len([n for n in types if n==tuple])>0:
                                    pass
                            #elif eval(f"type({value})")==dict:
                            else:
                                pass
        return {'FINISHED'}
class RTOOLS_OT_Call_Render_All(bpy.types.Operator):
    bl_idname = "rtools.renderall"
    bl_label = "Render All"
    bl_description = "Render All Render Presets"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        if not bpy.data.is_saved:
            bpy.ops.wm.save_mainfile('INVOKE_DEFAULT')
            return {'FINISHED'}
        areaOG = context.window.screen.areas[0]
        view_area=areaOG
        for area in context.window.screen.areas:
            if area.type=='VIEW_3D':
                view_area=area
        bpy.ops.rtools.renderalll({'area':view_area})
        context.window.screen.areas[0].type= areaOG.type
        queue = get_render_queue()
        context.scene.rt_tools.render_all=True
        visible_indexes=[i for i,a in enumerate(context.scene.RenderSettingsSaves) if not a.hide_view]
        for i in visible_indexes:
            queue.createtask('RTOOLS_OT_rendersettingsload',index=i)
            queue.createtask("RENDER_OT_render",use_viewport=True)
            queue.createtask("RTOOLS_OT_saverenderresult",index=i)
        queue.createtask("RTOOLS_OT_render_batch_done")
        context.scene.activeRenderSettingsIndexCopy=0
        bpy.ops.render.render_batch('INVOKE_DEFAULT')
        
        #bpy.ops.wm.refresh('INVOKE_DEFAULT')
        return {'FINISHED'}
class RTOOLS_OT_saverenderresult(bpy.types.Operator):
    bl_idname = "rtools.saverenderresult"
    bl_label = "Render result"
    bl_description = "Save Render Results"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty()
    def execute(self, context):
        scene=context.scene
        if not bpy.data.is_saved :
            return {'CANCELLED'}
        
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]
        blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
        filepath = os.path.splitext(bpy.data.filepath)[0] if not os.path.isdir(context.scene.projectInfo.renders_folder_path) else context.scene.projectInfo.renders_folder_path
        #print(context.scene.projectInfo.renders_folder_path)
        fname=blendname
        
        if bpy.context.scene.render.engine=='CYCLES':
            filepath=os.path.join(filepath,'Cycles')
        else:
            filepath=os.path.join(filepath,'Eevee')
        if not os.path.exists(filepath):
            os.mkdir(filepath)
        if scene.rt_tools.render_all:
            blendname=blendname+" "+scene.RenderSettingsSaves[self.index].name
            fname=blendname
        files = [file for file in os.listdir(filepath)
                if file.startswith(blendname)]
        i=0
        name=fname
        while(fname+"."+scene.render.image_settings.file_format.lower() in files):
            fname = f"{name}_{i}"
            #print(fname)
            i+=1
        final_name = os.path.join(filepath, fname+"."+scene.render.image_settings.file_format.lower())

        image = bpy.data.images['Render Result']
        if not image:
            return "ERROR"

        image.save_render(final_name, scene=None)
        return {'FINISHED'}
class RTOOLS_OT_Render_All(bpy.types.Operator):
    bl_idname = "rtools.renderalll"
    bl_label = "Render All"
    bl_description = "Render All Render Presets"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        if bpy.data.node_groups.get('RT_WireFrame') is None:
                
                path=os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets/"),"ExtraAssets.blend/NodeTree/")
            
        
                bpy.ops.wm.append(
                        directory=path,
                        filename='RT_WireFrame', autoselect=False
                    )
        
        scene=context.scene
        context.scene.rt_tools.render_all=True
        context.scene.activeRenderSettingsIndexCopy=0
        while scene.activeRenderSettingsIndexCopy<len(scene.RenderSettingsSaves) and scene.RenderSettingsSaves[scene.activeRenderSettingsIndexCopy].hide_view :
            scene.activeRenderSettingsIndexCopy+=1
            if scene.activeRenderSettingsIndexCopy==len(scene.RenderSettingsSaves):
                        scene.rt_tools.render_all=False
                        scene.activeRenderSettingsIndexCopy=0
                        return {'FINISHED'}
        #print("Loading:",scene.activeRenderSettingsIndexCopy)
        for settings in [a for a in scene.RenderSettingsSaves if a.wire_type and not a.hide_view]:
            scene.rt_tools.render_settings_name=settings.name
            scene.camera=settings.camera
            scene.camera.location=settings.camera_location
            scene.camera.rotation_euler=settings.camera_rotation
            scene.render.engine=settings.engine_string
            scene.render.resolution_x=settings.res_x
            scene.render.resolution_y=settings.res_y
            scene.world=settings.world
            scene.render.film_transparent=settings.film_transparent
            scene.camera.data.lens=settings.cameraSettings.lens
            scene.camera.data.type=settings.cameraSettings.type_string
            scene.camera.data.ortho_scale=settings.cameraSettings.ortho_scale
            scene.camera.data.sensor_width=settings.cameraSettings.sensor_width
            for key in settings.cameraSettings.dofSettings.__annotations__.keys():
                DofSettings=settings.cameraSettings.dofSettings
                setattr(scene.camera.data.dof,key,getattr(DofSettings,key))
            
            cSettings=settings.cyclesSettings
            for key in settings.cyclesSettings.__annotations__.keys():
                try:
                    setattr(scene.cycles,key,getattr(cSettings,key))
                except:
                    pass    
            eSettings=settings.eeveeSettings
            for key in settings.eeveeSettings.__annotations__.keys():
                setattr(scene.eevee,key,getattr(eSettings,key))
            #bpy.ops.view3d.view_camera()
            if bpy.context.area:
                if bpy.context.area.type == 'VIEW_3D':
                    bpy.context.area.spaces[0].region_3d.view_perspective = 'CAMERA'
            
            
            areaOG=context.window.screen.areas[0].type
            context.window.screen.areas[0].type = 'VIEW_3D'
            #context.window.screen.areas[0].spaces[0].type='VIEW_3D'
            selected=[ob for ob in scene.objects if ob.type in {'MESH','CURVE','SURFACE','FONT'}]
            add_clay_material(selected,add_to_translucent=True,render_mode=True)
            settings.wireframe_image=create_wireframe_image(context,index=settings.name)
            context.window.screen.areas[0].type=areaOG
            
        #load_render_settings(context.scene,scene.activeRenderSettingsIndexCopy)
        #bpy.ops.render.view_show('INVOKE_DEFAULT')
        #bpy.ops.render.render(use_viewport = True)
        
        #print("Hi")
        #bpy.ops.render.render('INVOKE_DEFAULT',use_viewport = True)
        
        return {'FINISHED'}
def get_render_queue():
    class RTOOLS_OT_render_batch(bpy.types.Macro):
        bl_idname = "render.render_batch"
        bl_label = "Render Batch"

        @classmethod
        def createtask(cls, idname, **kwargs):
            op = super().define(idname).properties
            for key, val in kwargs.items():
                setattr(op, key, val)

    old = getattr(bpy.types, "RENDER_OT_render_batch", False)
    if old:
        bpy.utils.unregister_class(old)
    bpy.utils.register_class(RTOOLS_OT_render_batch)
    return RTOOLS_OT_render_batch
class RTOOLS_OT_render_batch_done(bpy.types.Operator):
    bl_idname = "rtools.render_batch_done"
    bl_label = "Mark Complete"
    def execute(self, context):
            context.scene.rt_tools.render_all=False
            return {'FINISHED'}
        
class RTOOLS_OT_RenderSettingsSave(bpy.types.Operator):
    bl_idname = "rtools.saverendersettings"
    bl_label = "Render Preset Save"
    bl_description = "Create Render Settings Preset"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        settings=context.scene.RenderSettingsSaves.add()
        name=context.scene.rt_tools.render_settings_name
        fname=name
        i=0
        while(fname in [a.name for a in context.scene.RenderSettingsSaves]):
            fname = f"{name}_{i}"
            i+=1
        settings.name=fname
        settings.camera=context.scene.camera
        settings.camera_location=context.scene.camera.location.copy()
        settings.camera_rotation=context.scene.camera.rotation_euler.copy()
        settings.engine=context.scene.render.engine
        settings.engine_string=context.scene.render.engine
        settings.res_x=context.scene.render.resolution_x
        settings.res_y=context.scene.render.resolution_y
        settings.world=context.scene.world
        settings.film_transparent=context.scene.render.film_transparent
        settings.cameraSettings.lens=context.scene.camera.data.lens
        settings.cameraSettings.type_string=context.scene.camera.data.type
        settings.cameraSettings.ortho_scale=context.scene.camera.data.ortho_scale
        settings.cameraSettings.sensor_width=context.scene.camera.data.sensor_width
        for key in settings.cameraSettings.dofSettings.__annotations__.keys():
            DofSettings=settings.cameraSettings.dofSettings
            setattr(DofSettings,key,getattr(context.scene.camera.data.dof,key))
        
        cSettings=settings.cyclesSettings
        for key in settings.cyclesSettings.__annotations__.keys():
            #print(getattr(context.scene.cycles,key))
            try:
                setattr(cSettings,key,getattr(context.scene.cycles,key))
            except:
                pass
        eSettings=settings.eeveeSettings
        for key in settings.eeveeSettings.__annotations__.keys():
            setattr(eSettings,key,getattr(context.scene.eevee,key))
        context.scene.activeRenderSettingsIndex=len(context.scene.RenderSettingsSaves)-1
        return {'FINISHED'}
class RTOOLS_OT_Update_RenderSettings(bpy.types.Operator):
    bl_idname = "rtools.updaterenderset"
    bl_label = "Update"
    bl_description = "Update Render Settings Preset"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        settings=context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex]
        #settings.name=context.scene.rt_tools.render_settings_name
        settings.camera=context.scene.camera
        settings.camera_location=context.scene.camera.location.copy()
        settings.camera_rotation=context.scene.camera.rotation_euler.copy()
        settings.engine=context.scene.render.engine
        settings.engine_string=context.scene.render.engine
        settings.res_x=context.scene.render.resolution_x
        settings.res_y=context.scene.render.resolution_y
        settings.world=context.scene.world
        settings.film_transparent=context.scene.render.film_transparent
        settings.cameraSettings.lens=context.scene.camera.data.lens
        settings.cameraSettings.type_string=context.scene.camera.data.type
        settings.cameraSettings.ortho_scale=context.scene.camera.data.ortho_scale
        settings.cameraSettings.sensor_width=context.scene.camera.data.sensor_width
        for key in settings.cameraSettings.dofSettings.__annotations__.keys():
            DofSettings=settings.cameraSettings.dofSettings
            setattr(DofSettings,key,getattr(context.scene.camera.data.dof,key))

        
        cSettings=settings.cyclesSettings
        for key in settings.cyclesSettings.__annotations__.keys():
            try:
                setattr(cSettings,key,getattr(context.scene.cycles,key))
            except:
                pass
        eSettings=settings.eeveeSettings
        for key in settings.eeveeSettings.__annotations__.keys():
            
            setattr(eSettings,key,getattr(context.scene.eevee,key))
        return {'FINISHED'}
class RTOOLS_OT_Remove_RenderSettings(bpy.types.Operator):
    bl_idname = "rtools.removerenderset"
    bl_label = "Render Preset Remove"
    bl_description = "Remove Render Preset"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        context.scene.RenderSettingsSaves.remove(context.scene.activeRenderSettingsIndex)
        context.scene.activeRenderSettingsIndex=max(context.scene.activeRenderSettingsIndex-1,0)
        return {'FINISHED'}
def load_render_settings(scene,index,render=True):
    
    selected=[ob for ob in scene.objects if ob.type in {'MESH','CURVE','SURFACE','FONT'}]
    remove_clay_material(selected,render_mode=True)
    if scene.use_nodes:
        wireframeNode=scene.node_tree.nodes.get('RT_WireFrame')
        if wireframeNode and wireframeNode.inputs[0].links and wireframeNode.outputs[0].links:
            scene.node_tree.links.new(wireframeNode.inputs[0].links[0].from_socket,wireframeNode.outputs[0].links[0].to_socket)
            
            scene.node_tree.nodes.remove(wireframeNode)
    
    if index<len(scene.RenderSettingsSaves):
        
        settings=scene.RenderSettingsSaves[index]
        #scene.rt_tools.render_settings_name=settings.name
        
        scene.camera=settings.camera
        scene.camera.location=settings.camera_location
        
        scene.camera.rotation_euler=settings.camera_rotation
        scene.render.resolution_x=settings.res_x
        scene.render.resolution_y=settings.res_y
        scene.render.engine=settings.engine_string
        #settings.engine=settings.engine_string
        #print(settings.res_x,settings.res_y)
        
        #print("After ",settings.res_x,settings.res_y)
        scene.world=settings.world
        
        scene.render.film_transparent=settings.film_transparent
        scene.camera.data.lens=settings.cameraSettings.lens
        scene.camera.data.type=settings.cameraSettings.type_string
        #print(settings.engine_string)
        #settings.cameraSettings.type=settings.cameraSettings.type_string
        scene.camera.data.ortho_scale=settings.cameraSettings.ortho_scale
        scene.camera.data.sensor_width=settings.cameraSettings.sensor_width
        for key in settings.cameraSettings.dofSettings.__annotations__.keys():
            DofSettings=settings.cameraSettings.dofSettings
            setattr(scene.camera.data.dof,key,getattr(DofSettings,key))
   
        cSettings=settings.cyclesSettings
        for key in settings.cyclesSettings.__annotations__.keys():
            try:
                setattr(scene.cycles,key,getattr(cSettings,key))
            except:
                pass
        eSettings=settings.eeveeSettings
        for key in settings.eeveeSettings.__annotations__.keys():
            setattr(scene.eevee,key,getattr(eSettings,key))
        #bpy.ops.view3d.view_camera()
        if bpy.context.area:
            if bpy.context.area.type == 'VIEW_3D':
                bpy.context.area.spaces[0].region_3d.view_perspective = 'CAMERA'
        if settings.clay_type:
            
            #print(len(selected))
            add_clay_material(selected,add_to_translucent=True,render_mode=True)
            if bpy.data.node_groups.get('RT_ClayGroup') is not None:
                bpy.data.node_groups.get('RT_ClayGroup').nodes['RT_Diffuse'].inputs[0].default_value=[settings.clay_color[0],settings.clay_color[1],settings.clay_color[2],1]
        
        if render and settings.wire_type:
            AONode=setup_wireframe_node(settings.mix_render)
            AONode.image=settings.wireframe_image
            """areaOG=context.window.screen.areas[0].type
            context.window.screen.areas[0].type = 'VIEW_3D'
            bpy.ops.rtools.wireframerender({'area':context.window.screen.areas[0]},'INVOKE_DEFAULT',mix=settings.mix_render)
            context.window.screen.areas[0].type=areaOG"""
        #print(index,len(scene.RenderSettingsSaves))
        
        
class RTOOLS_OT_rendersettingsload(bpy.types.Operator):
    bl_idname = "rtools.rendersettingsload"
    bl_label = "Render Presets Load"
    bl_description = "Load Render Settings Preset"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty(default=0)
    def execute(self, context):
        load_render_settings(context.scene,self.index)
        return {'FINISHED'}
class RTOOLS_OT_Test(bpy.types.Operator):
    bl_idname = "rtools.switchrender"
    bl_label = "Switch Render Engine"
    bl_description = "Switch Render Engine"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        bpy.context.scene.cycles.device='GPU'
        context.scene.render.engine='CYCLES' if context.scene.render.engine=='BLENDER_EEVEE' else 'BLENDER_EEVEE' 
        context.space_data.shading.type='RENDERED'
        return {'FINISHED'}
class RTOOLS_OT_Reset_Project(bpy.types.Operator):
    bl_idname = "rtools.resetproject"
    bl_label = "Reset Project"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        context.scene.is_project_setup=False
        context.scene.projectInfo.textures_folder_path=""
        context.scene.projectInfo.renders_folder_path=""
        return {'FINISHED'}
def write_recent_files(path):
    #print(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),"config",'recent-files.txt'))
    if os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),"config",'recent-files.txt')):
        files=[]
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),"config",'recent-files.txt'),mode='r') as f:
            files=f.readlines()
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),"config",'recent-files.txt'),mode='w') as f:
            f.writelines([path+"\n",]+files)
class RTOOLS_OT_Setup_Project(bpy.types.Operator):
    bl_idname = "rtools.setupproject"
    bl_label = "Set Up Project"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    force:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE','HIDDEN'})
    def execute(self, context):
        projects_path=preferences().projects_path
        if os.path.isdir(preferences().projects_path):
            context.scene.is_project_setup=True
            if not os.path.isdir(os.path.join(projects_path,context.scene.projectInfo.name)):
                os.mkdir(os.path.join(projects_path,context.scene.projectInfo.name))
            project_path=os.path.join(projects_path,context.scene.projectInfo.name)
            if not os.path.isdir(os.path.join(project_path,"Blend Files")):
                os.mkdir(os.path.join(project_path,"Blend Files"))
            bpy.ops.wm.save_as_mainfile(filepath=os.path.join(os.path.join(project_path,"Blend Files"),context.scene.projectInfo.name+".blend"))
            write_recent_files(os.path.join(os.path.join(project_path,"Blend Files"),context.scene.projectInfo.name+".blend"))
            if not os.path.isdir(os.path.join(project_path,preferences().textures_folder_name)):
                os.mkdir(os.path.join(project_path,preferences().textures_folder_name))
            context.scene.projectInfo.textures_folder_path=os.path.join(project_path,preferences().textures_folder_name)
            if not os.path.isdir(os.path.join(project_path,preferences().renders_folder_name)):
                os.mkdir(os.path.join(project_path,preferences().renders_folder_name))
            context.scene.projectInfo.renders_folder_path=os.path.join(project_path,preferences().renders_folder_name)
            bpy.ops.wm.save_mainfile()
        else:
            self.report({'WARNING'},"Select a valid Projects Directory in the Preferences")
        return {'FINISHED'}
    def invoke(self, context, event):
        if os.path.isdir(os.path.join(preferences().projects_path,context.scene.projectInfo.name)) and not self.force:
            bpy.ops.wm.call_menu(name="RTOOLS_MT_Override_Project")
            return {"FINISHED"}
        else:
            return self.execute(context)
class RTOOLS_MT_Override_Project(Menu):
    bl_label = "Override Project?"
    def draw(self, context):
        layout= self.layout
        layout.label(text="Project with same name already exists do you want to override it?")
        layout.operator("rtools.setupproject",text="Override!").force=True
        
class RTOOLS_OT_Save_Override(bpy.types.Operator):
    bl_idname = "rtools.saveproject"
    bl_label = "Save Project"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        if preferences().override_save and not context.scene.is_project_setup and not bpy.data.is_saved:
            bpy.ops.rtools.projectsettings('INVOKE_DEFAULT')
        else:
            return {'PASS_THROUGH'}
        return {'FINISHED'}
class RTOOLS_OT_Project_Info(bpy.types.Operator):
    bl_idname = "rtools.projectsettings"
    bl_label = "Project Settings"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    recent_files:bpy.props.BoolProperty(default=False,name="Recent Files")
    def draw(self,context):
        layout = self.layout
        layout.ui_units_x=20
        project = context.scene.projectInfo
        row=layout.row()
        row.label(text="Project Information")
        row.operator("rtools.resetproject",icon="FILE_REFRESH")
        col=layout.column()
        col.prop(context.scene.projectInfo,"name",emboss=not context.scene.is_project_setup)
        
        col2=col.column()
        col2.separator(factor=1)
        col2.operator("rtools.setupproject",icon='CHECKMARK' if context.scene.is_project_setup else 'NONE')
        col2.separator(factor=1)
        if context.scene.is_project_setup:
            col2.enabled=False
        col.prop(project,"textures_folder_path")
        col.prop(project,"renders_folder_path")
        col.separator(factor=1)
        if [a for a in self.recents if a[:-2]!=bpy.data.filepath]:
            last_project=[a for a in self.recents if a[:-2]!=bpy.data.filepath][0]
            op=col.operator("wm.open_mainfile",text=f"Last Project ({os.path.basename(last_project[:-2])})")
            op.display_file_selector=False
            op.filepath=last_project[:-2]
        col.separator(factor=1)
        col.prop(self,'recent_files',toggle=True,icon="TRIA_DOWN")
        if self.recent_files:
            for a in self.recents:
                op=col.operator("wm.open_mainfile",text=os.path.basename(a[:-2]))
                op.display_file_selector=False
                op.filepath=a[:-2]
            
    def invoke(self, context,event):
        self.recents=[]
        if os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config","recent-files.txt")):
            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config","recent-files.txt"), mode='r', newline='\n', encoding='utf-8') as file:
                self.recents=file.readlines()
        return context.window_manager.invoke_popup(self)
    def execute(self, context):
        return {'FINISHED'}
class RTOOLS_MT_Pie_Menu(Menu):
    bl_label = "Pie Menu"
    
    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        if "icons" in icon_collection.keys():
            pcoll = icon_collection["icons"]
            
        dice_icon = pcoll["dice"]
        uvgrid_icon=pcoll["uvgrid"]
        pieMenu.operator("rtools.dice",icon_value=dice_icon.icon_id)

        pieMenu.operator("rtools.materialpick")

        pieMenu.operator("rtools.create_modifier_preset_menu")

        pieMenu.operator("rtools.switchdisplaytype")
        pieMenu.operator("rtools.shadesmooth")
        pieMenu.operator("rtools.modifieradjustpanel", text="Modifier Adjust")
        addUv = pieMenu.operator("rtools.adduvgrid",icon_value=uvgrid_icon.icon_id)
        addUv.callFrom = "Pie"
        pieMenu.operator("rtools.removeuvgrid")
class RTOOLS_MT_RanTools_Main(Menu):
    bl_label = "RanTools Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        layout=layout.column()
        if context.active_object is not None and context.active_object.type=='CURVE':
                layout.prop(context.active_object.data,'bevel_depth')
        layout.operator_context='INVOKE_DEFAULT'
        #layout.operator('rtools.mergevgroups')
        #layout.operator('rtools.slidevertices')
        #layout.operator('rtools.createbooleanvgroups')
        #if context.active_object is not None:
                #for m in [mod for mod in context.active_object.modifiers if mod.type in {'BEVEL'}][::-1]:
                    #layout.operator("rtools.adjustmodifier",text="Last Bevel").name=m.name
                    #break
        if context.active_object :
            layout.operator("rtools.curveadjust")
        #layout.operator('rtools.booltest')
        layout.operator("rtools.capsoncurve")
        layout.operator("rtools.refitcaps")
        layout.operator('rtools.applymodifiers')
        layout.operator("rtools.extractfaces")
        layout.operator("rtools.insetshrink")
        layout.operator("rtools.converttoplane")
        layout.operator("rtools.addplanetoboolean")
        layout.operator("rtools.origintogeometrywithmodifiers")
        layout.operator("rtools.addlattice")
        layout.operator("rtools.taper")
        #layout.operator("rtools.edgetostrip")
panels=[RTOOLS_PT_BackUps,
RTOOLS_PT_Camera,
RTOOLS_Curve_Tools,
RTOOLS_OT_RTools,
RTOOLS_Material,
RTOOLS_OT_Light,
RTOOLS_OT_Bake,
RTOOLS_OT_PT_Cutter,]
class RTOOLS_Call_Panels_Sub_Pie(bpy.types.Operator):
    bl_idname = "rtools.callpanelssubpie"
    bl_label = "RanTools - Panels Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    name: bpy.props.StringProperty()
    def invoke(self, context, event):
        context.scene.last_panel_subcategory=self.name
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Panels_Sub_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_MT_Panels_Sub_Pie_Menu(Menu):
    bl_label = "Panels Pie Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        category=context.scene.last_panel_subcategory
        base_type = bpy.types.Panel
        count=0
        for typename in dir(bpy.types):
            bl_type = getattr(bpy.types, typename)
            try:
                if issubclass(bl_type, base_type):
                    if "." not in getattr(bl_type,"bl_context","None"):
                        if (getattr(bl_type,"bl_context","None")=="None" or getattr(bl_type,"bl_context","None")==get_current_context(context)) and getattr(bl_type,"bl_region_type","None")=='UI' and getattr(bl_type,"bl_category","None")==category and getattr(bl_type,'bl_space_type',"None")==context.space_data.type and bl_type.bl_label!='Help'and bl_type.bl_label!='Asset Tools':
                        
                        #pieMenu.popover(bl_type.bl_idname, text=getattr(bl_type,'bl_label',"None"))
                        #print(bl_type.bl_label)
                            if getattr(bl_type,'poll',None):
                                        
                                    if bl_type.poll(context):
                                        if "layout" in inspect.getsource(bl_type.draw):
                                            op=pieMenu.operator("rtools.popuppanel",text=bl_type.bl_label)
                                            op.name=bl_type.__name__
                                            op.call_panel=True
                                            count+=1
                            else:
                                if "layout" in inspect.getsource(bl_type.draw):
                                    op=pieMenu.operator("rtools.popuppanel",text=bl_type.bl_label)
                                    op.name=bl_type.__name__
                                    op.call_panel=True
                                    count+=1
                            
                            if count==8:
                                break
            except:
                pass
        
            #pieMenu.popover(a.bl_idname, text=a.bl_label)
class RTOOLS_MT_Panels_Pie_Menu(Menu):
    bl_label = "Panels Pie Menu"

    def draw(self, context):
        panel_list={}
        #categories_string=sentence = ''.join(preferences().panel_categories.split())
        #categories=categories_string.split(",")
        name=context.scene.last_panel_subcategory
        categories=[]
        for a in preferences().panel_categories:
            if a.name==name:
                #categories_string= ''.join(a.panels.split())
                categories=a.panels.split(",")
                categories=[a.strip() for a in categories]
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        count=0
        for a in categories:
            count+=1
            #print(a)
            #pieMenu.popover(a.bl_idname, text=a.bl_label)
            pieMenu.operator("rtools.popuppanel",text=a).name=a
            if count==8:
                break
            #pieMenu.operator("rtools.callpanelssubpie",text=a).name=a
class RTOOLS_MT_Panel_Categories_Pie_Menu(Menu):
    bl_label = "Panels Pie Menu"

    def draw(self, context):
        categories=[a.name for a in preferences().panel_categories]
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        count=0
        for a in categories:
            count+=1
            pieMenu.operator("rtools.callpanelspie",text=a).name=a
            if count==8:
                break
class RTOOLS_MT_Curves_Pie_Menu(Menu):
    bl_label = "RT Curves Pie Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        pcoll = icon_collection["icons"]
            
        cable_icon = pcoll["cable"]
        multicable_icon=pcoll["multicable"]
        simul_icon=pcoll["wiresimul"]
        draw_icon=pcoll["drawcables"]
        putoncurve_icon=pcoll["putoncurve"]
        edgetocurve_icon=pcoll["edgetocurve"]
        pieMenu.operator("rtools.putoncurve",icon_value=putoncurve_icon.icon_id)
        pieMenu.operator("rtools.createcable",icon_value=cable_icon.icon_id)
        pieMenu.operator("rtools.createmultiplewires",icon_value=multicable_icon.icon_id)
        pieMenu.operator("rtools.drawcurve",icon_value=draw_icon.icon_id)
        pieMenu.operator("rtools.edgetocurve", icon_value=edgetocurve_icon.icon_id)
        if context.scene.rt_tools.wiresimul_version_1:
            pieMenu.operator("rtools.simulatewire",icon_value=simul_icon.icon_id)
        else:
            pieMenu.operator("rtools.simulatewire2",icon_value=simul_icon.icon_id)
        pieMenu.operator("rtools.capsoncurve")
        
        pieMenu.operator("rtools.curveadjust")
ASSET_ICON_AVAILABLE="ASSET_MANAGER" in bpy.types.UILayout.bl_rna.functions[
                "prop"].parameters["icon"].enum_items.keys()
class RTOOLS_MT_Booleans_Pie_Menu(Menu):
    bl_label = ""

    def draw(self, context):

        layout = self.layout
        if context.mode=='OBJECT':
            layout.label(text="Booleans Pie Menu")
        else:
            layout.label(text="Mesh Pie Menu")
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        pcoll = icon_collection["icons"]
            
        difference_icon = pcoll["difference"]
        slice_icon=pcoll["slice"]
        union_icon=pcoll["union"]
        intersect_icon=pcoll["intersect"]
        inset_icon=pcoll["inset"]
        draw_icon=pcoll["draw"]
        adjust_icon=pcoll["adjust"]
        cable_icon = pcoll["cable"]
        multicable_icon=pcoll["multicable"]
        simul_icon=pcoll["wiresimul"]
        draw_cable_icon=pcoll["drawcables"]
        putoncurve_icon=pcoll["putoncurve"]
        edgetocurve_icon=pcoll["edgetocurve"]
        if context.mode=='OBJECT':
            if preferences().use_master_pie:
                pieMenu.operator("rtools.grid",icon_value=draw_icon.icon_id, text="Draw")
                grid=pieMenu.grid_flow(columns=2,even_columns=True)
                grid.ui_units_x=10
                grid.operator("rtools.booleans",icon_value=difference_icon.icon_id, text="Difference").type='DIFFERENCE'
                grid.operator("rtools.booleans",icon_value=union_icon.icon_id, text="Union").type='UNION'
                grid.operator("rtools.booleans",icon_value=intersect_icon.icon_id, text="Intersect").type='INTERSECT'
                
                grid.operator("rtools.slicebool",icon_value=slice_icon.icon_id, text="Slice")
                grid.operator("rtools.insetbool",icon_value=inset_icon.icon_id, text="Inset")
                grid.operator("rtools.extractfaces",text="Extract Faces")
                
                box=pieMenu.column()
                box.ui_units_x=10
                row=box.row()
                row=row.split(factor=0.5,align=True)
                row.operator('rtools.cutterspanel',text='Cutters List',icon='MOD_BOOLEAN')
                row.operator('rtools.recalllastcutter',text='Last Cutter',icon='MOD_BOOLEAN')
                if context.active_object:
                    if context.active_object.type=='MESH':
                        row=box.row()
                        row=row.split(factor=0.5,align=True)
                        row.operator("rtools.shadesmooth")
                        row.prop(context.active_object.data,'auto_smooth_angle',text="Angle")
                    bevel_mods=[mod for mod in context.active_object.modifiers if mod.type in {'BEVEL',} ]
                    if bevel_mods:
                        box.prop(bevel_mods[len(bevel_mods)-1],'width',text="Last Bevel Width")
                    pass
                    box.label(text="Adjust Modifiers ")
                    if context.active_object is not None:
                        for m in [mod for mod in context.active_object.modifiers if mod.type in {'BEVEL','SOLIDIFY','DISPLACE','SCREW','SIMPLE_DEFORM','SHRINKWRAP'} ]:
                            row=box.row()
                            row=row.split(factor=0.8,align=True)
                            row.operator("rtools.adjustmodifier",text=m.name).name=m.name
                            row.prop(m,'show_viewport',text="")
                    box.operator("rtools.applymodifiers")
                box=pieMenu.row()
                box.ui_units_x=20
                box1=box.column()
                box1.ui_units_x=10
                box1.label(text="Materials",icon='MATERIAL')
                grid=box1.grid_flow(row_major=True,columns=2,even_columns=True)
                grid.operator("rtools.call_material_menu",icon='MATERIAL_DATA',text="Change")
                grid.operator("rtools.newmaterial",icon="ADD",text="New")
                grid.operator("rtools.materialadjustpanel",text="Adjust",icon_value=adjust_icon.icon_id)
                grid.operator("rtools.import_material",text="Library",icon="ASSET_MANAGER" if ASSET_ICON_AVAILABLE else "MATERIAL_DATA")
                box1=box.column()
                box1.ui_units_x=10
                box1.label(text="Cables",icon='OUTLINER_OB_CURVE')
                grid=box1.grid_flow(row_major=True,columns=2,even_columns=True)
                
                grid.operator("rtools.createcable",text="Create",icon_value=cable_icon.icon_id)
                grid.operator("rtools.createmultiplewires",icon_value=multicable_icon.icon_id)
                if context.scene.rt_tools.wiresimul_version_1:
                    grid.operator("rtools.simulatewire",text="Simulate",icon_value=simul_icon.icon_id)
                else:
                    grid.operator("rtools.simulatewire2",text="Simulate",icon_value=simul_icon.icon_id)
                grid.operator("rtools.curveadjust",text="Edit",icon='GREASEPENCIL')
                
            else:    
                pieMenu.operator("rtools.grid",icon_value=draw_icon.icon_id, text="Draw")
                pieMenu.operator("rtools.insetbool",icon_value=inset_icon.icon_id, text="Inset")
                box=pieMenu.column()
                box.label(text="Adjust Modifiers ")
                if context.active_object is not None:
                    for m in [mod for mod in context.active_object.modifiers if mod.type in {'BEVEL','SOLIDIFY','DISPLACE','SCREW','SIMPLE_DEFORM','SHRINKWRAP'} ]:
                        row=box.row()
                        row=row.split(factor=0.8,align=True)
                        row.operator("rtools.adjustmodifier",text=m.name).name=m.name
                        row.prop(m,'show_viewport',text="")
                box.operator("rtools.applymodifiers")
                
                pieMenu.operator("rtools.booleans",icon_value=union_icon.icon_id, text="Union").type='UNION'
                pieMenu.operator("rtools.booleans",icon_value=difference_icon.icon_id, text="Difference").type='DIFFERENCE'
                pieMenu.operator("rtools.booleans",icon_value=intersect_icon.icon_id, text="Intersect").type='INTERSECT'
                pieMenu.prop(bpy.context.space_data.overlay,'show_wireframes',toggle=True)
                pieMenu.operator("rtools.slicebool",icon_value=slice_icon.icon_id, text="Slice")
        elif context.mode=='EDIT_MESH':
            #pieMenu.operator("rtools.marksharp")
            #pieMenu.operator("mesh.mark_sharp",text="Clear Sharp").clear=True
            #pieMenu.operator("rtools.selectsharp")
            pieMenu.operator("rtools.edgetocurve")
            pieMenu.operator("rtools.separatesolidify")
            #pieMenu.operator("transform.edge_bevelweight")
            op=pieMenu.operator("rtools.createcloth")
            op=pieMenu.operator("rtools.preparecloth")
            op.flip_normals=False
            #op.size=0.25
            #pieMenu.operator("rtools.cleanbooleans")
class RTOOLS_MT_Edges_Pie_Menu(Menu):
    bl_label = ""

    def draw(self, context):

        layout = self.layout
        layout.label(text="Mesh Pie Menu")
        layout.operator_context = "INVOKE_DEFAULT"
        pieMenu = layout.menu_pie()
        pcoll = icon_collection["icons"]
        #row=pieMenu.row(align=True)
        #row=row.split(factor=0.8)
        pieMenu.operator("rtools.edge_bevelweight",text="Bevel Weight").attribute="Bevel Weight"
        #row.operator("rtools.edge_bevelweight",text="1").attribute="Crease"
        pieMenu.operator("rtools.edge_bevelweight",text="Crease").attribute="Crease"
        pieMenu.operator("rtools.selectsharp")
        pieMenu.operator("rtools.clearedges")
        #pieMenu.operator("mesh.mark_sharp",text="Clear Sharp").clear=True

        
        #col=pieMenu.column()
        pieMenu.operator("rtools.marksharp")
        #col.operator("rtools.selectedgesbytrait",text="Select Edges (Sharp)").trait="Sharp"
        #col.operator("rtools.selectedgesbytrait",text="Select Edges (Seam)").trait="Seam"
        
        
        #pieMenu.operator("transform.edge_crease")
        pieMenu.operator("rtools.markseam")
import inspect           
class RTOOLS_OT_Add_To_RanTools_Menu(bpy.types.Operator):
    bl_idname = "rtools.addtorantoolsmenu"
    bl_label = "Add To RanTools Menu"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and "rtools" in str(getattr(context,'button_operator',None)).lower()

    def execute(self, context):
        value = getattr(context, "button_operator", None)
        if value is not None:
            print(value)
            value=str(value)[13:]
            value=value[:value.index(" ")]
            print(eval(f"bpy.types.{value}").bl_idname)
            print(eval(f"bpy.types.{value}"))
            

        return {'FINISHED'}           
class RTOOLS_MT_Material_Mix_Sub_Menu(Menu):
    bl_label = "Material Mix Menu"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        for i in bpy.data.materials:
            if i.name!=context.material.name and i.name!='Dots Stroke':
                layout.operator("rtools.mixwithnode",text=i.name).node_to_mix="MATERIAL:"+i.name 
class RTOOLS_MT_Node_Mix_Sub_Menu(Menu):
    bl_label = "Node Mix Menu"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        #print("Debug Info Mix Menu: ",len(context.scene.imperfection_maps))
        for i in context.scene.imperfection_maps:
            layout.operator("rtools.mixwithnode",text=i.name).node_to_mix=i.path
class RTOOLS_MT_Material_Imperfection_Maps_Sub_Menu(Menu):
    bl_label = "Node Mix Menu"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        for i in context.scene.imperfection_maps:
            layout.operator("rtools.mixmaterials",text=i.name).node_to_mix=i.path
class RTOOLS_MT_Material_Mix_Using_Menu(Menu):
    bl_label = "Mix using"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"

        layout.menu("RTOOLS_MT_Material_Imperfection_Maps_Sub_Menu", text="Imperfection Maps")
        layout.operator("rtools.mixmaterials",text='Noise Texture').node_to_mix='NOISE'
        layout.operator("rtools.mixmaterials",text='Musgrave Texture').node_to_mix='MUSGRAVE'
        layout.operator("rtools.mixmaterials",text='Edge Mask').node_to_mix='EDGE_MASK'
        layout.operator("rtools.mixmaterials",text='Worn Edge Mask').node_to_mix='WORN_EDGE_MASK'
        layout.separator(factor=1)
        for node in context.material.node_tree.nodes[:]+bpy.data.materials.get(context.scene.materialtomix).node_tree.nodes[:]:
            if node.type=='TEX_IMAGE' and node.image:
                if any([(a in node.image.name.lower()) for a in ['displacement', 'displace', 'disp','dsp', 'height', 'heightmap', 'bmp', 'bump','edgemask'] ]):
                    name=node.image.name
                    if "." in name:
                        name=node.image.name[:node.image.name.rindex(".")]
                    layout.operator("rtools.mixmaterials",text=name).node_to_mix=node.image.name
        
class RTOOLS_MT_Node_Mix_Menu(Menu):
    bl_label = "Node Mix Menu"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        for a in context.active_node.outputs:
            if a.is_linked:
                for link in a.links:
                    if link.to_node.type=='OUTPUT_MATERIAL':
                        layout.menu("RTOOLS_MT_Material_Mix_Sub_Menu", text="Other Materials")

        layout.menu("RTOOLS_MT_Node_Mix_Sub_Menu", text="Imperfection Maps")
        layout.operator("rtools.mixwithnode",text='Noise Texture').node_to_mix='NOISE'
        layout.operator("rtools.mixwithnode",text='Musgrave Texture').node_to_mix='MUSGRAVE'
        layout.operator("rtools.mixwithnode",text='Edge Mask').node_to_mix='EDGE_MASK'
        layout.operator("rtools.mixwithnode",text='Worn Edge Mask').node_to_mix='WORN_EDGE_MASK'
        layout.separator(factor=1)
        layout.label(text="Height Maps and Edge Masks")
        for node in context.material.node_tree.nodes:
            if node.type=='TEX_IMAGE' and node.image:
                if any([(a in node.image.name.lower()) for a in ['displacement', 'displace', 'disp','dsp', 'height', 'heightmap', 'bmp', 'bump','edgemask'] ]):
                    name=node.image.name
                    if "." in name:
                        name=node.image.name[:node.image.name.rindex(".")]
                    layout.operator("rtools.mixwithnode",text=name).node_to_mix=node.image.name
        layout.separator(factor=1)
        layout.label(text="Add Node")
        for node,info in {'ShaderNodeInvert':['Invert',1],'ShaderNodeRGBCurve':['RGB Curves',1],'ShaderNodeValToRGB':['Color Ramp',0],'ShaderNodeMixRGB':['Mix RGB',1]}.items():
            op=layout.operator("rtools.addadjustmentnode",text=info[0])
            op.node_type=node
            op.socket=info[1]
class RTOOLS_MT_Plug_To_Socket_Menu(Menu):
    bl_label = "Plug Into"

    def draw(self, context):

        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        for a in context.active_node.inputs:
            layout.operator("rtools.plugintonode",text=a.name,icon='DECORATE').socket=a.name

class RTOOLS_OT_Call_Main_Menu(bpy.types.Operator):
    bl_idname = "rtools.callrtmain"
    bl_label = "RanTools - Main Menu"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        
        bpy.ops.wm.call_menu(name="RTOOLS_MT_RanTools_Main")
        return {"FINISHED"}      
class RTOOLS_OT_Call_Node_Mix_Menu(bpy.types.Operator):
    bl_idname = "rtools.callnodemixmenu"
    bl_label = "RanTools - Node Mix"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    @classmethod
    def poll(self, context):
        return context.area.type =='NODE_EDITOR' and context.active_node and context.selected_nodes
    def invoke(self, context, event):
        #print("Debug:")
        context.scene.imperfection_maps.clear()
        #print(os.path.isdir(preferences().imperfection_maps))
        if os.path.isdir(preferences().imperfection_maps):
            #print(os.listdir(preferences().imperfection_maps))
            for name in os.listdir(preferences().imperfection_maps):
                #print(name)
                if name.endswith('.jpg') or name.endswith('.png'):
                    t=context.scene.imperfection_maps.add()
                    t.name=name.replace('.jpg','').replace('.png','')
                    t.path=os.path.join(preferences().imperfection_maps,name)
        bpy.ops.wm.call_menu(name="RTOOLS_MT_Node_Mix_Menu")
        return {"FINISHED"}       
class callRTPie(bpy.types.Operator):
    bl_idname = "rtools.callpie"
    bl_label = "RanTools - Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        #context.preferences.view.pie_menu_radius = 160
        #return context.window_manager.invoke_popup(self)
        #bpy.ops.wm.call_panel(name="OBJECT_PT_Material_Adjust")
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_Call_Curves_Pie(bpy.types.Operator):
    bl_idname = "rtools.callcurvespie"
    bl_label = "RanTools - Curves Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Curves_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_Call_Panels_Pie(bpy.types.Operator):
    bl_idname = "rtools.callpanelspie"
    bl_label = "RanTools - Panels Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    name:bpy.props.StringProperty()
    def invoke(self, context, event):
        context.scene.last_panel_subcategory=self.name
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Panels_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_Call_Panels_Categories_Pie(bpy.types.Operator):
    bl_idname = "rtools.callcategoriespie"
    bl_label = "RanTools - Panels Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Panel_Categories_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_Call_Booleans_Pie(bpy.types.Operator):
    bl_idname = "rtools.callbooleanspie"
    bl_label = "RanTools - Booleans"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Booleans_Pie_Menu")
        return {"FINISHED"}
class RTOOLS_OT_Call_Edges_Pie_Menu(bpy.types.Operator):
    bl_idname = "rtools.calledgespie"
    bl_label = "RanTools - Edges Pie"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    def invoke(self, context, event):
        bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Edges_Pie_Menu")
        return {"FINISHED"}
class WM_MT_button_context(Menu):
    bl_label = "Unused"

    def draw(self, context):
        pass
def visiblityUpdate(self, context):
    try:
        self.hide_set(getattr(self,"hide_view"))
    except:
        pass    
def nodeGroupsAvailable(self,context):
    path=os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets/"),"ExtraAssets.blend")
    with bpy.data.libraries.load(str(path)) as (data_from, _):
        #print(data_from.node_groups)
        return set([(n,n,n) for n in data_from.node_groups])
def hookscaleupdate_1(self, context):
    if "RT_CableHook_1" in context.active_object.modifiers.keys():
        hook=context.active_object.modifiers.get("RT_CableHook_1").object
        hook.scale=(getattr(self,'hook1_scale'),getattr(self,'hook1_scale'),getattr(self,'hook1_scale'))
    elif context.active_object.modifiers.get("RT_POC_Curve").object is not None and "RT_CableHook_1" in context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.keys():
        hook=context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.get("RT_CableHook_1").object
        hook.scale=(getattr(self,'hook1_scale'),getattr(self,'hook1_scale'),getattr(self,'hook1_scale'))
def hookscaleupdate_2(self, context):
    if "RT_CableHook_2" in context.active_object.modifiers.keys():
        hook=context.active_object.modifiers.get("RT_CableHook_2").object
        hook.scale=(getattr(self,'hook2_scale'),getattr(self,'hook2_scale'),getattr(self,'hook2_scale'))
    elif context.active_object.modifiers.get("RT_POC_Curve").object is not None and "RT_CableHook_2" in context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.keys():
        hook=context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.get("RT_CableHook_2").object
        hook.scale=(getattr(self,'hook2_scale'),getattr(self,'hook2_scale'),getattr(self,'hook2_scale'))
def BackUpEnumGen(self, context):
    return context.active_object.BackUps
def EmissionRateUpdate(self, context):
    if  len(context.scene.boidSystems)>0:
            settings=self.particle_system
            settings.frame_start=1
            settings.frame_end=(settings.count*bpy.context.scene.render.fps)/self.emission_rate
def wire_offset_update(self, context):
    if self:
        if self.wire_axis=='X':
            if self.modifiers.get('RT_WIRE_COUNT'):
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[0]=abs(self.wire_parallel_offset)
        if self.wire_axis=='Y':
            if self.modifiers.get('RT_WIRE_COUNT'):
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[1]=abs(self.wire_parallel_offset)
def wire_axis_update(self, context):
    if self:
        if self.wire_axis=='X':
            if self.modifiers.get('RT_WIRE_COUNT'):
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[0]=self.wire_parallel_offset
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[1]=0
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[2]=0
        if self.wire_axis=='Y':
            if self.modifiers.get('RT_WIRE_COUNT'):
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[1]=self.wire_parallel_offset
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[0]=0
                self.modifiers.get('RT_WIRE_COUNT').constant_offset_displace[2]=0
def wire_type_update(self, context):
   
    if self is not None:
        if self.wire_type=='Parallel':
            if self.modifiers.get('RT_WIRE_COUNT') is not None:
                self.modifiers.get('RT_WIRE_COUNT').use_object_offset=False
                self.modifiers.get('RT_WIRE_COUNT').use_constant_offset=True
            if self.modifiers.get('RT_WIRE_RADIUS'):
                self.modifiers.get('RT_WIRE_RADIUS').show_render=False
                self.modifiers.get('RT_WIRE_RADIUS').show_viewport=False
            if self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE'):
                self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE').show_render=True
                self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE').show_viewport=True
        if self.wire_type=='Radial':
            if self.modifiers.get('RT_WIRE_COUNT') is not None:
                self.modifiers.get('RT_WIRE_COUNT').use_object_offset=True
                self.modifiers.get('RT_WIRE_COUNT').use_constant_offset=False
            if self.modifiers.get('RT_WIRE_RADIUS'):
                self.modifiers.get('RT_WIRE_RADIUS').show_render=True
                self.modifiers.get('RT_WIRE_RADIUS').show_viewport=True
            if self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE'):
                self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE').show_render=False
                self.modifiers.get('RT_PARALLEL_WIRE_DISPLACE').show_viewport=False
def extract_sun_changed(self, context):
    
        if bpy.data.worlds.get("RT_World") and bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World"):
            group=bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World")
            if self.extract_sun:
                group.inputs[10].default_value=1
            else:
                group.inputs[10].default_value=0
def use_solid_color_changed(self, context):
    if bpy.data.worlds.get("RT_World") and bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World"):
            group=bpy.data.worlds.get("RT_World").node_tree.nodes.get("RT_World")
            if self.use_solid_color:
                group.inputs[14].default_value=1
            else:
                group.inputs[14].default_value=0
class ImperfectionMapsInfo(PropertyGroup):
    name: bpy.props.StringProperty()
    path:bpy.props.StringProperty()
class BrokenObjs(PropertyGroup):
    obj:bpy.props.PointerProperty(type=bpy.types.Object)
class BoidSystems(PropertyGroup):
    name: bpy.props.StringProperty()
    particle_system: bpy.props.PointerProperty(type=bpy.types.ParticleSettings)
    emission_rate: bpy.props.IntProperty(default=10,update=EmissionRateUpdate,min=1)
class SavedViews(PropertyGroup):
    name: bpy.props.StringProperty()
    matrix:bpy.props.FloatVectorProperty(size=16)
class BackUpInfo(PropertyGroup):
    name: bpy.props.StringProperty()
    obj: bpy.props.PointerProperty(name="Object",type=bpy.types.Object)
    time:bpy.props.StringProperty()
class CapsInfo(PropertyGroup):
    name: bpy.props.StringProperty()
    obj: bpy.props.PointerProperty(name="Object",type=bpy.types.Object)
class Lights(PropertyGroup):
    name: bpy.props.StringProperty()
    light: bpy.props.PointerProperty(name="Light",type=bpy.types.Object)
class LightGroups(PropertyGroup):
    name: bpy.props.StringProperty()
    lights:bpy.props.CollectionProperty(type=Lights)
    solo:bpy.props.BoolProperty(default=False)
    hidden_lights:bpy.props.CollectionProperty(type=Lights)
class RTOOLSProps(PropertyGroup):
    MaterialFolderPath: bpy.props.StringProperty(
        name="Path To PBR Textures Directory",
        description="SetUp All PBR Textures in this directory",
        subtype="DIR_PATH",
        default="Choose Path",
    )
    select_string: bpy.props.StringProperty(
        name="Select Similar String",
        description="Used for finding objects that include this in their name",
        default="Cube",
    )
    backup_name:bpy.props.StringProperty(name='BackUp Name',description="Name To Use For The Created Backup")
    choice: bpy.props.IntProperty(default=0)
    presetName: bpy.props.StringProperty()
    auto_save:bpy.props.BoolProperty(default=False)
    hexwidget : bpy.props.FloatVectorProperty(name="Clay Color", 
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[1.0,1.0,1.0])
    bevel_width:bpy.props.FloatProperty(name="Bevel Width",default=0.05,soft_min=0.001,soft_max=1,min=0.00001,max=10,step=1)
    bevel_render_samples:bpy.props.IntProperty(name="Render Samples to Use",default=8,soft_min=1,soft_max=128,min=1,max=500,step=8)
    light_group_name:bpy.props.StringProperty(name="Light Group Name")
    remesh_scale: bpy.props.FloatProperty(default=0.1)
    texture_resolution:bpy.props.IntProperty(default=2048,min=64,max=16324,step=1024,name="Resolution")
    bake_diffuse:bpy.props.BoolProperty(default=False)
    bake_rough:bpy.props.BoolProperty(default=False)
    bake_metal:bpy.props.BoolProperty(default=False)
    bake_glossy:bpy.props.BoolProperty(default=False)
    bake_normal:bpy.props.BoolProperty(default=False)
    bake_ao:bpy.props.BoolProperty(default=False)
    bake_emit:bpy.props.BoolProperty(default=False)
    bake_opacity:bpy.props.BoolProperty(default=False)
    bake_uv:bpy.props.BoolProperty(default=False)
    bake_environment:bpy.props.BoolProperty(default=False)
    bake_combined:bpy.props.BoolProperty(default=False)
    bake_height:bpy.props.BoolProperty(default=False)
    bake_id:bpy.props.BoolProperty(default=False)
    ao_object_influence:bpy.props.BoolProperty(default=True,name="Only Local",description="Only Consider the object itself while baking AO")
    create_mats_for_bake:bpy.props.BoolProperty(default=False,name="Create New Materials")
    assign_materials:bpy.props.BoolProperty(default=False,name="Assign Materials")
    use_mat_colors:bpy.props.BoolProperty(default=False,name="Use Viewport Colors",description="Use Viewport Colors for ID Maps instead of Random Colors")
    bake_all_to_one:bpy.props.BoolProperty(default=False,name="Bake All Objects to Single Image")
    ogObj:bpy.props.PointerProperty(type=bpy.types.Object)
    brokenObjs:bpy.props.CollectionProperty(type=BrokenObjs)
    hook1_scale:bpy.props.FloatProperty(default=1,update=hookscaleupdate_1)
    hook2_scale:bpy.props.FloatProperty(default=1,update=hookscaleupdate_2)
    view_name:bpy.props.StringProperty()
    #('RT_FlowMap','Flow Map','Flow Map'),
    nodeToAppend:bpy.props.EnumProperty(name='Node To Append',items=(('RT_Worn_Edge_Mask','Worn Edge Mask','Worn Edge Mask'),('RT_Edge_Mask','Edge Mask','Edge Mask'),('RT_Mask_Noise','Grunge Mask','Grunge Mask'),('RT_Color_Adjustment','Color Adjust','Color Adjust'),('RT_Ground_Mask','Ground Mask','Ground Mask'),('RT_Musgrave_Imperfection','Musgrave Imperfections','Musgrave Imperfections'),('RT_Scratches','Scratches','Scratches'),('RT_Scratches_2','Scratches 2','Scratches 2')))
    boid_count:bpy.props.IntProperty(default=100)
    show_advanced_boid_options:bpy.props.BoolProperty(default=False)
    socketsToAdd:bpy.props.StringProperty(name="Sockets To Add")
    hittingObject:bpy.props.PointerProperty(type=bpy.types.Object,name="Hitting Object")
    custom_operator_name:bpy.props.StringProperty(name="Name")
    custom_operator_operations:bpy.props.StringProperty(name='Operations')
    render_settings_name:bpy.props.StringProperty(default='Name',name="Name")
    render_all:bpy.props.BoolProperty(default=False)
    keep_drawing:bpy.props.BoolProperty(default=False,name="Continuous Drawing")
    wiresimul_version_1:bpy.props.BoolProperty(default=False,name="Use Wire Simulation V1")
    snap_angle:bpy.props.FloatProperty(default=15)
    backup_name:bpy.props.StringProperty()
    limited_dissolve:bpy.props.BoolProperty(default=True,name="Clean Mesh",description="Run Limited Dissolve And Remove Doubles To Remove Extra Vertices After Drawing")
    coplanar_faces:bpy.props.BoolProperty(default=True,name="Calculate Coplanar Faces",description="Whether to calculate coplanar faces and center(Turn off when working with very high poly meshes)")
    default_curve_type:bpy.props.EnumProperty(items=(('BEZIER','Bezier','Bezier'),('NURBS','Nurbs','Nurbs')),name="Default Curve Type")
    current_shape:bpy.props.StringProperty(default="MESH",name='Shape',description="Current Shape")
    default_shape:bpy.props.EnumProperty(items={('BOX','Box','Box'),('CIRCLE','Circle','Circle'),('POLYGON','Polygon','Polygon')},default='BOX',name='Shape',description="Default Shape To Use While Drawing")
    #last_cutter:bpy.props.PointerProperty(type=bpy.types.Object,name="Last Cutter")
    last_cutter_object:bpy.props.PointerProperty(type=bpy.types.Object,name="Last Cutter Boolean")
    last_cutter_index:bpy.props.IntProperty(default=0)
    show_help: bpy.props.BoolProperty(default=True)
    materialToSearch:bpy.props.StringProperty(default="",update=search_material_update)
    pageIndex:bpy.props.IntProperty()
    pageIndexOffline:bpy.props.IntProperty()
    show_all_offline:bpy.props.BoolProperty(default=False,name="Show All",update=show_all_material_update,description="Show all Offline materials instead of just the ones matching the search query")
    HDRIToSearch:bpy.props.StringProperty(default="",update=search_hdri_update)
    category:bpy.props.EnumProperty(items={("All","All","All"),("Outdoor","Outdoor","Outdoor"),("Skies","Skies","Skies"),("Indoor","Indoor","Indoor"),("Studio","Studio","Studio"),("Sunrise-Sunset","Sunrise-Sunset","Sunrise-Sunset"),("Night","Night","Night"),("Nature","Nature","Nature"),("Urban","Urban","Urban")},default="All",name="Category",update=search_hdri_update)
    HDRIpageIndex:bpy.props.IntProperty()
    HDRIpageIndexOffline:bpy.props.IntProperty()
    show_all_offline_hdris:bpy.props.BoolProperty(default=False,name="Show All",update=show_all_hdri_update,description="Show all Offline materials instead of just the ones matching the search query")
    extract_sun:bpy.props.BoolProperty(default=False,name="Extract Sun",update=extract_sun_changed)
    use_solid_color:bpy.props.BoolProperty(default=False,name="Solid Color For Background",update=use_solid_color_changed)
    auto_hide_grid:bpy.props.BoolProperty(default=True)
    pc_operation:bpy.props.StringProperty(default="Boolean")
    material_categories:bpy.props.EnumProperty(items=get_categories_enum,name="Category",update=search_material_update)
    #last_bool_type:bpy.props.StringProperty()
    #cutter_extra_1:bpy.props.PointerProperty(type=bpy.types.Object,name="Extra 1")
    #cutter_extra_2:bpy.props.PointerProperty(type=bpy.types.Object,name="Extra 2")
    #last_mod_name:bpy.props.StringProperty()
    #last_inset_mod:bpy.props.StringProperty()
class CutterInfo(PropertyGroup):
    name: bpy.props.StringProperty()
    direction:bpy.props.IntProperty()
    center_location:bpy.props.FloatVectorProperty(size=3)
    normal:bpy.props.FloatVectorProperty(size=3)
    mods_applied:bpy.props.BoolProperty(default=True)
    #last_cutter:bpy.props.PointerProperty(type=bpy.types.Object,name="Last Cutter")
    cutter_id:bpy.props.StringProperty(default="",name="Cutter ID")
    last_cutter:bpy.props.StringProperty(default="",name="Last Cutter")
    new_bevel_mod:bpy.props.StringProperty(default="")
    last_bool_type:bpy.props.StringProperty()
    cutter_extra_1:bpy.props.StringProperty(default="Not",name="Extra 1")
    cutter_extra_2:bpy.props.StringProperty(default="Not",name="Extra 2")
    #cutter_extra_1:bpy.props.PointerProperty(type=bpy.types.Object,name="Extra 1")
    #cutter_extra_2:bpy.props.PointerProperty(type=bpy.types.Object,name="Extra 2")
    last_mod_name:bpy.props.StringProperty()
    last_inset_mod:bpy.props.StringProperty()
class ProjectInfo(PropertyGroup):
    name: bpy.props.StringProperty(name="Project Name")
    textures_folder_path: bpy.props.StringProperty(
        name='Textures Folder',
        subtype='DIR_PATH',
        default='Choose Path')
    renders_folder_path:bpy.props.StringProperty(
        name='Renders Folder',
        subtype='DIR_PATH',
        default='Choose Path')
def getArguments(line):
    code=line
    params=regex.search(r"\((.*)\)",code)


    if params is not None:
        params=params[1]
        if params!="" and '=' in params:
            return eval(f"dict({params})")
        else:
            return {}
    else:
        return {}
class Parameter(PropertyGroup):
    name:bpy.props.StringProperty()
    value:bpy.props.StringProperty()
    type:bpy.props.StringProperty()
    oGValue:bpy.props.StringProperty()
    isString:bpy.props.BoolProperty(default=False)
class OperatorLines(PropertyGroup):
    line:bpy.props.StringProperty()
    params:bpy.props.StringProperty(default="ABCDEFGHIJ")
    arguments:bpy.props.CollectionProperty(type=Parameter)

class EeveeSettings(PropertyGroup):
    bloom_clamp:bpy.props.FloatProperty(default=0.0,name='Bloom clamp')
    bloom_intensity:bpy.props.FloatProperty(default=0.05,name='Bloom intensity')
    bloom_knee:bpy.props.FloatProperty(default=0.5,name='Bloom knee')
    bloom_radius:bpy.props.FloatProperty(default=6.5,name='Bloom radius')
    bloom_threshold:bpy.props.FloatProperty(default=0.8,name='Bloom threshold')
    bokeh_max_size:bpy.props.FloatProperty(default=100.0,name='Bokeh max size')
    bokeh_threshold:bpy.props.FloatProperty(default=1.0,name='Bokeh threshold')
    gi_auto_bake:bpy.props.BoolProperty(default=False,name='Gi auto bake')
    gi_cubemap_display_size:bpy.props.FloatProperty(default=0.3,name='Gi cubemap display size')
    gi_cubemap_resolution:bpy.props.StringProperty(name='Gi cubemap resolution')
    gi_diffuse_bounces:bpy.props.IntProperty(default=3,name='Gi diffuse bounces')
    gi_filter_quality:bpy.props.FloatProperty(default=3.0,name='Gi filter quality')
    gi_glossy_clamp:bpy.props.FloatProperty(default=0.0,name='Gi glossy clamp')
    gi_irradiance_display_size:bpy.props.FloatProperty(default=0.1,name='Gi irradiance display size')
    gi_irradiance_smoothing:bpy.props.FloatProperty(default=0.1,name='Gi irradiance smoothing')
    gi_show_cubemaps:bpy.props.BoolProperty(default=False,name='Gi show cubemaps')
    gi_show_irradiance:bpy.props.BoolProperty(default=False,name='Gi show irradiance')
    gi_visibility_resolution:bpy.props.StringProperty(name='Gi visibility resolution')
    gtao_distance:bpy.props.FloatProperty(default=0.2,name='Gtao distance')
    gtao_factor:bpy.props.FloatProperty(default=1.0,name='Gtao factor')
    gtao_quality:bpy.props.FloatProperty(default=0.25,name='Gtao quality')
    light_threshold:bpy.props.FloatProperty(default=0.01,name='Light threshold')
    motion_blur_depth_scale:bpy.props.FloatProperty(default=100.0,name='Motion blur depth scale')
    motion_blur_max:bpy.props.IntProperty(default=32,name='Motion blur max')
    motion_blur_shutter:bpy.props.FloatProperty(default=0.5,name='Motion blur shutter')
    motion_blur_steps:bpy.props.IntProperty(default=1,name='Motion blur steps')
    overscan_size:bpy.props.FloatProperty(default=3.0,name='Overscan size')
    shadow_cascade_size:bpy.props.StringProperty(default='512',name='Shadow cascade size')
    shadow_cube_size:bpy.props.StringProperty(default='1024',name='Shadow cube size')
    ssr_border_fade:bpy.props.FloatProperty(default=0.075,name='Ssr border fade')
    ssr_firefly_fac:bpy.props.FloatProperty(default=10.0,name='Ssr firefly fac')
    ssr_max_roughness:bpy.props.FloatProperty(default=0.5,name='Ssr max roughness')
    ssr_quality:bpy.props.FloatProperty(default=0.25,name='Ssr quality')
    ssr_thickness:bpy.props.FloatProperty(default=0.20,name='Ssr thickness')
    sss_jitter_threshold:bpy.props.FloatProperty(default=0.3,name='Sss jitter threshold')
    sss_samples:bpy.props.IntProperty(default=7,name='Sss samples')
    taa_render_samples:bpy.props.IntProperty(default=64,name='Taa render samples')
    taa_samples:bpy.props.IntProperty(default=16,name='Taa samples')
    use_bloom:bpy.props.BoolProperty(default=False,name='Use bloom')
    use_gtao:bpy.props.BoolProperty(default=False,name='Use gtao')
    use_gtao_bent_normals:bpy.props.BoolProperty(default=True,name='Use gtao bent normals')
    use_gtao_bounce:bpy.props.BoolProperty(default=True,name='Use gtao bounce')
    use_motion_blur:bpy.props.BoolProperty(default=False,name='Use motion blur')
    use_overscan:bpy.props.BoolProperty(default=False,name='Use overscan')
    use_shadow_high_bitdepth:bpy.props.BoolProperty(default=False,name='Use shadow high bitdepth')
    use_soft_shadows:bpy.props.BoolProperty(default=True,name='Use soft shadows')
    use_ssr:bpy.props.BoolProperty(default=False,name='Use ssr')
    use_ssr_halfres:bpy.props.BoolProperty(default=True,name='Use ssr halfres')
    use_ssr_refraction:bpy.props.BoolProperty(default=False,name='Use ssr refraction')
    use_taa_reprojection:bpy.props.BoolProperty(default=True,name='Use taa reprojection')
    use_volumetric_lights:bpy.props.BoolProperty(default=True,name='Use volumetric lights')
    use_volumetric_shadows:bpy.props.BoolProperty(default=False,name='Use volumetric shadows')
    volumetric_end:bpy.props.FloatProperty(default=100.0,name='Volumetric end')
    volumetric_light_clamp:bpy.props.FloatProperty(default=0.0,name='Volumetric light clamp')
    volumetric_sample_distribution:bpy.props.FloatProperty(default=0.8,name='Volumetric sample distribution')
    volumetric_samples:bpy.props.IntProperty(default=64,name='Volumetric samples')
    volumetric_shadow_samples:bpy.props.IntProperty(default=16,name='Volumetric shadow samples')
    volumetric_start:bpy.props.FloatProperty(default=0.1,name='Volumetric start')
    volumetric_tile_size:bpy.props.StringProperty(default='8',name='Volumetric tile size')
class CyclesSettings(PropertyGroup):
    preview_adaptive_threshold:bpy.props.FloatProperty(default=0.0,name='Adaptive threshold')
    preview_adaptive_min_samples:bpy.props.IntProperty(default=0,name="Preview Adaptive Min Samples")
    preview_denoiser:bpy.props.StringProperty(default="")
    preview_denoising_input_passes:bpy.props.StringProperty(default="")
    preview_denoising_prefilter:bpy.props.StringProperty(default="")
    time_limit:bpy.props.IntProperty(default=1)
    denoiser:bpy.props.StringProperty(default="")
    denoising_input_passes:bpy.props.StringProperty(default="")
    denoising_prefilter:bpy.props.StringProperty(default="")
    sampling_pattern:bpy.props.StringProperty(default="")
    auto_scrambling_distance:bpy.props.BoolProperty(default=False)
    preview_scrambling_distance:bpy.props.BoolProperty(default=False)
    scrambling_distance:bpy.props.FloatProperty(default=1)
    


    device:bpy.props.StringProperty(default="GPU")
    #device:bpy.props.EnumProperty(items={('CPU','CPU','CPU'),('GPU','GPU','GPU')})
    #aa_samples:bpy.props.IntProperty(default=128,name='Aa samples')
    adaptive_min_samples:bpy.props.IntProperty(default=0,name='Adaptive min samples')
    
    adaptive_threshold:bpy.props.FloatProperty(default=0.0,name='Adaptive threshold')
    ao_bounces:bpy.props.IntProperty(default=0,name='Ao bounces')
    ao_bounces_render:bpy.props.IntProperty(default=0,name='Ao bounces render')
    #ao_samples:bpy.props.IntProperty(default=1,name='Ao samples')
    blur_glossy:bpy.props.FloatProperty(default=1.0,name='Blur glossy')
    camera_cull_margin:bpy.props.FloatProperty(default=0.1,name='Camera cull margin')
    caustics_reflective:bpy.props.BoolProperty(default=True,name='Caustics reflective')
    caustics_refractive:bpy.props.BoolProperty(default=True,name='Caustics refractive')
    dicing_rate:bpy.props.FloatProperty(default=1.0,name='Dicing rate')
    diffuse_bounces:bpy.props.IntProperty(default=4,name='Diffuse bounces')
    #diffuse_samples:bpy.props.IntProperty(default=1,name='Diffuse samples')
    distance_cull_margin:bpy.props.FloatProperty(default=50.0,name='Distance cull margin')
    film_exposure:bpy.props.FloatProperty(default=1.0,name='Film exposure')
    film_transparent_glass:bpy.props.BoolProperty(default=False,name='Film transparent glass')
    film_transparent_roughness:bpy.props.FloatProperty(default=0.1,name='Film transparent roughness')
    filter_width:bpy.props.FloatProperty(default=1.5,name='Filter width')
    glossy_bounces:bpy.props.IntProperty(default=4,name='Glossy bounces')
    #glossy_samples:bpy.props.IntProperty(default=1,name='Glossy samples')
    light_sampling_threshold:bpy.props.FloatProperty(default=0.01,name='Light sampling threshold')
    max_bounces:bpy.props.IntProperty(default=12,name='Max bounces')
    max_subdivisions:bpy.props.IntProperty(default=12,name='Max subdivisions')
    #mesh_light_samples:bpy.props.IntProperty(default=1,name='Mesh light samples')
    min_light_bounces:bpy.props.IntProperty(default=0,name='Min light bounces')
    min_transparent_bounces:bpy.props.IntProperty(default=0,name='Min transparent bounces')
    offscreen_dicing_scale:bpy.props.FloatProperty(default=4.0,name='Offscreen dicing scale')
    #preview_aa_samples:bpy.props.IntProperty(default=32,name='Preview aa samples')
    preview_denoising_start_sample:bpy.props.IntProperty(default=1,name='Preview denoising start sample')
    preview_dicing_rate:bpy.props.FloatProperty(default=8.0,name='Preview dicing rate')
    preview_pause:bpy.props.BoolProperty(default=False,name='Preview pause')
    preview_samples:bpy.props.IntProperty(default=32,name='Preview samples')
    #preview_start_resolution:bpy.props.IntProperty(default=64,name='Preview start resolution')
    rolling_shutter_duration:bpy.props.FloatProperty(default=0.1,name='Rolling shutter duration')
    #sample_all_lights_direct:bpy.props.BoolProperty(default=True,name='Sample all lights direct')
    #sample_all_lights_indirect:bpy.props.BoolProperty(default=True,name='Sample all lights indirect')
    #sample_clamp_direct:bpy.props.FloatProperty(default=0.0,name='Sample clamp direct')
    #sample_clamp_indirect:bpy.props.FloatProperty(default=10.0,name='Sample clamp indirect')
    samples:bpy.props.IntProperty(default=128,name='Samples')
    seed:bpy.props.IntProperty(default=0,name='Seed')
    shading_system:bpy.props.BoolProperty(default=False,name='Shading system')
    #subsurface_samples:bpy.props.IntProperty(default=1,name='Subsurface samples')
    transmission_bounces:bpy.props.IntProperty(default=12,name='Transmission bounces')
    #transmission_samples:bpy.props.IntProperty(default=1,name='Transmission samples')
    transparent_max_bounces:bpy.props.IntProperty(default=8,name='Transparent max bounces')
    use_adaptive_sampling:bpy.props.BoolProperty(default=False,name='Use adaptive sampling')
    use_animated_seed:bpy.props.BoolProperty(default=False,name='Use animated seed')
    use_camera_cull:bpy.props.BoolProperty(default=False,name='Use camera cull')
    use_denoising:bpy.props.BoolProperty(default=False,name='Use denoising')
    use_distance_cull:bpy.props.BoolProperty(default=False,name='Use distance cull')
    use_preview_denoising:bpy.props.BoolProperty(default=False,name='Use preview denoising')
    #use_progressive_refine:bpy.props.BoolProperty(default=False,name='Use progressive refine')
    #use_square_samples:bpy.props.BoolProperty(default=False,name='Use square samples')
    volume_bounces:bpy.props.IntProperty(default=0,name='Volume bounces')
    volume_max_steps:bpy.props.IntProperty(default=1024,name='Volume max steps')
    volume_preview_step_rate:bpy.props.FloatProperty(default=1.0,name='Volume preview step rate')
    #volume_samples:bpy.props.IntProperty(default=1,name='Volume samples')
    volume_step_rate:bpy.props.FloatProperty(default=1.0,name='Volume step rate')
class DofSettings(PropertyGroup):
    use_dof:bpy.props.BoolProperty()
    focus_object:bpy.props.PointerProperty(type=bpy.types.Object)
    focus_distance: bpy.props.FloatProperty()
    aperture_fstop:bpy.props.FloatProperty()
def lens_type_update(self, context):
    self.type_string=self.type
def engine_update(self, context):
    #print("Engine Update ",self.engine)
    self.engine_string=self.engine
class CameraSettings(PropertyGroup):
    lens: bpy.props.FloatProperty()
    ortho_scale:bpy.props.FloatProperty()
    sensor_width:bpy.props.FloatProperty()
    type:bpy.props.EnumProperty(items={('PERSP','Perspective','Perspective'),('ORTHO','Orthographic','Orthographic'),('PANO','Panoramic','Panoramic')},default='PERSP',update=lens_type_update)
    type_string:bpy.props.StringProperty(default='PERSP')
    dofSettings:bpy.props.PointerProperty(type=DofSettings)
def isCamera(self,object):
    return object.type=='CAMERA'
def camera_update(self, context):
    self.camera_location=self.camera.location.copy()
    self.camera_rotation=self.camera.rotation_euler.copy()
    self.cameraSettings.lens=context.scene.camera.data.lens
    self.cameraSettings.type_string=context.scene.camera.data.type
    self.cameraSettings.ortho_scale=context.scene.camera.data.ortho_scale
    self.cameraSettings.sensor_width=context.scene.camera.data.sensor_width
    for key in self.cameraSettings.dofSettings.__annotations__.keys():
        DofSettings=self.cameraSettings.dofSettings
        setattr(DofSettings,key,getattr(context.scene.camera.data.dof,key))
class RenderSettings(PropertyGroup):
    
    name: bpy.props.StringProperty()
    engine:bpy.props.EnumProperty(items={('CYCLES','Cycles','Cycles'),('BLENDER_EEVEE','Eevee','Eevee')},name='Engine',update=engine_update)
    engine_string:bpy.props.StringProperty(default='BLENDER_EEVEE')
    hide_view:bpy.props.BoolProperty(default=False)
    clay_type:bpy.props.BoolProperty(default=False,name="Clay")
    wire_type:bpy.props.BoolProperty(default=False,name="Wireframe")
    mix_render:bpy.props.FloatProperty(default=1,name="Mix",max=1,min=0)
    clay_color:bpy.props.FloatVectorProperty(name="Clay Color", 
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[1.0,1.0,1.0])
    wireframe_image:bpy.props.PointerProperty(type=bpy.types.Image)
    camera:bpy.props.PointerProperty(type=bpy.types.Object,poll=isCamera,name='Camera',update=camera_update)
    camera_location:bpy.props.FloatVectorProperty(size=3,name="Location")
    camera_rotation:bpy.props.FloatVectorProperty(size=3,name="Rotation")
    res_x:bpy.props.IntProperty(name='Resolution x')
    res_y:bpy.props.IntProperty(name='Resolution Y')
    world:bpy.props.PointerProperty(type=bpy.types.World,name='World')
    exposure:bpy.props.FloatProperty(default=0)
    cameraSettings:bpy.props.PointerProperty(type=CameraSettings)
    film_transparent:bpy.props.BoolProperty(default=False,name='Transparent')
    view_transform:bpy.props.StringProperty(default='Filmic')
    eeveeSettings:bpy.props.PointerProperty(type=EeveeSettings)
    cyclesSettings:bpy.props.PointerProperty(type=CyclesSettings)
    
# endregion
class Opened_Panels(PropertyGroup):
    name: bpy.props.StringProperty()
    opened_panels:bpy.props.StringProperty()
class RTOOLS_OT_Help(Panel):
    bl_idname = "OBJECT_PT_Help"
    bl_label = "Help"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        col=layout.column()
        pcoll = icon_collection["icons"]
        youtube_icon = pcoll["youtube"]
        discord_icon=pcoll["discord"]
        green=pcoll["updategreen"]
        red=pcoll["updatered"]
        draw_update_section_for_panel(col,context)
        # col.label(text=scene.update_status,icon_value=green.icon_id if 'RanTools is Up To Date!' in scene.update_status  else red.icon_id)
        col.operator('wm.url_open',text="Documentation",icon="HELP").url="https://rantools.github.io/rantools"
        row=col.row(align=True)
        row.operator('wm.url_open',text="Chat Support",icon_value=discord_icon.icon_id).url="https://discord.gg/PgtZ33ePw7"
        row.operator('wm.url_open',text="Youtube",icon_value=youtube_icon.icon_id).url="https://www.youtube.com/c/AmandeepBairwal"
        if scene.rantools_custom_message:
            col.label(text="Message from the Developer:",icon="TEXT")
            message=scene.rantools_custom_message
            message1=" ".join(message.split(" ")[:round(len(message.split(" "))/2)])
            message2=" ".join(message.split(" ")[round(len(message.split(" "))/2):])
            if message1:
                col.label(text=message1)
            if message2:
                col.label(text=message2)

# region REGISTRATION
classes = (#Opened_Panels,Panel_Category,
WM_MT_button_context,CapsInfo,
    RTOOLS_OT_render_batch_done,
    RTOOLS_OT_saverenderresult,
    RTOOLS_Clean_Booleans,
    RTOOLS_MT_RanTools_Main,
    RTOOLS_OT_Call_Main_Menu,
    DofSettings,
    CameraSettings,
    CyclesSettings,
    EeveeSettings,
    RenderSettings,
    RTOOLS_Call_Booleans_Pie,
    RTOOLS_MT_Booleans_Pie_Menu,
    Parameter,
    OperatorLines,
    RTOOLS_Intersect,
    RTOOLS_Call_Curves_Pie,
    RTOOLS_MT_Curves_Pie_Menu,
    RTOOLS_OT_Shade_Smooth,
    BoidSystems,
    RTOOLS_OT_Remesh_With_Dice,
    #RTOOLS_Project_From_Saved_View,
    #RTOOLS_UL_SavedViews_UIList,
    #RTOOLS_OT_Set_View,
    #RTOOLS_OT_Save_View,
    #RTOOLS_OT_Remove_Saved_View,
    #SavedViews,
    RTOOLS_Edit_Child_Curve,
    BackUpInfo,
    # BackUp Manager
    RTOOLS_OT_Normal_Transfer,
    RTOOLS_UL_BackUps_UIList,
    RTOOLS_OT_BackUps,
    RTOOLS_OT_CreateBackUp,
    RTOOLS_OT_ViewBackUp,
    RTOOLS_OT_HideBackUp,
    RTOOLS_OT_RefreshBackUps,

    RTOOLS_OT_AddBackUp,
    RTOOLS_OT_ReplaceBackup,
    RTOOLS_OT_RemoveBackUp,
    # End BackUp Manager
    Lights,
    LightGroups,
    
    BrokenObjs,
    RTOOLS_OT_Add_Tube,
    RTOOLS_OT_Circle_Array,
    RTOOLS_OT_Put_On_Curve,
    RTOOLS_OT_Create_Asset,
    RTOOLS_UL_SavedRenderSettings_UIList,
    RTOOLS_OT_Create_Asset_Panel,
    RTOOLS_OT_Add_Modifier_Preset,
    RTOOLS_OT_Create_Modifier_Preset,
    RTOOLS_OT_Create_Modifier_Preset_Menu,
    RTOOLS_OT_Invoke_Modifier_Menu,
    RTOOLS_OT_Invoke_Modifier_Sub_Menu,
    RTOOLS_OT_Invoke_Modifier_Favorites_Menu,
    RTOOLS_MT_Mods_Menu,
    RTOOLS_MT_Mods_Stacks_Menu,
    RTOOLS_MT_Mods_Sub_Menu,
    RTOOLS_MT_Mods_Favorites_Menu,
    RTOOLS_OT_Refresh,
    RTOOLS_OT_Add_Path,
    RTOOLS_OT_Remove_Asset_Path,
    Import_Asset,
    Import_Asset_Panel,
    RTOOLS_OT_Make_Emissive,
    RTOOLS_OT_Ratio,
    RTOOLS_OT_Lens,
    RTOOLS_OT_SnapIt,
    RTOOLS_OT_Resolution,
    RTOOLS_OT_RenderPath,
    RTOOLS_OT_RatioSwitch,
    RTOOLS_OT_addBackDrop,
    RTOOLS_OT_updateBevel,
    RTOOLS_OT_addLights,
    RTOOLS_OT_updateLightIntensity,
    RTOOLS_OT_SetupDenoise,
    RTOOLS_OT_Append,
    RTOOLS_OT_GroupIt,
    Call_Append_Panel,
    Append_Button,
    # HTE_Vertex,
    # HTE_Vertex_Mask,
    
    RTOOLS_MT_Pie_Menu,
    callRTPie,
    RTOOLS_OT_Refresh_Asset_Panel,
    RTOOLS_OT_Quick_Mirror,
    
    
   
    
    
    
    #Material Tools
    RTOOLS_OT_New_Material,
    RTOOLS_MT_Single_Material_Adjust_Panel,
    RTOOLS_MT_Node_Unlock,
    RTOOLS_MT_Material_Adjust_Panel,
    RTOOLS_OT_SetupMaterials,
    RTOOLS_MT_Material_Menu,
    RTOOLS_OT_call_material_menu,
    RTOOLS_OT_Change_Material,
    RTOOLS_OT_AddUVGrid,
    RTOOLS_OT_RemoveUVGrid,
    RTOOLS_OT_ClayMaterial,
    RTOOLS_OT_RemoveClayMaterial,
    #End - Material Tools
    RTOOLS_Match_Visiblity,
    RTOOLS_OriginToGeometryWithModifiers,
    AssetInfo,
    MenuInfo,
    subMenuInfo,
    appendObjectInfo,
    RTOOLS_Asset_Folders,
    RTOOLSPrefs,
    RTOOLSProps,
    ##Menus
    RTOOLS_MT_EXPLODE_Mod_Menu,
    RTOOLS_MT_OCEAN_Mod_Menu,
    RTOOLS_MT_MULTIRES_Mod_Menu,
    RTOOLS_MT_ARRAY_Mod_Menu,
    RTOOLS_MT_BEVEL_Mod_Menu,
    RTOOLS_MT_BOOLEAN_Mod_Menu,
    RTOOLS_MT_BUILD_Mod_Menu,
    RTOOLS_MT_EDGE_SPLIT_Mod_Menu,
    RTOOLS_MT_DECIMATE_Mod_Menu,
    RTOOLS_MT_NODES_Mod_Menu,
    RTOOLS_MT_MASK_Mod_Menu,
    RTOOLS_MT_MIRROR_Mod_Menu,
    RTOOLS_MT_REMESH_Mod_Menu,
    RTOOLS_MT_SCREW_Mod_Menu,
    RTOOLS_MT_SKIN_Mod_Menu,
    RTOOLS_MT_SOLIDIFY_Mod_Menu,
    RTOOLS_MT_SUBSURF_Mod_Menu,
    RTOOLS_MT_VOLUME_TO_MESH_Mod_Menu,
    RTOOLS_MT_TRIANGULATE_Mod_Menu,
    RTOOLS_MT_WELD_Mod_Menu,
    RTOOLS_MT_WIREFRAME_Mod_Menu,
    RTOOLS_MT_ARMATURE_Mod_Menu,
    RTOOLS_MT_CAST_Mod_Menu,
    RTOOLS_MT_CURVE_Mod_Menu,
    RTOOLS_MT_DISPLACE_Mod_Menu,
    RTOOLS_MT_HOOK_Mod_Menu,
    RTOOLS_MT_LAPLACIANDEFORM_Mod_Menu,
    RTOOLS_MT_LATTICE_Mod_Menu,
    RTOOLS_MT_SHRINKWRAP_Mod_Menu,
    RTOOLS_MT_MESH_DEFORM_Mod_Menu,
    RTOOLS_MT_SIMPLE_DEFORM_Mod_Menu,
    RTOOLS_MT_SMOOTH_Mod_Menu,
    RTOOLS_MT_CORRECTIVE_SMOOTH_Mod_Menu,
    RTOOLS_MT_LAPLACIANSMOOTH_Mod_Menu,
    RTOOLS_MT_SURFACE_DEFORM_Mod_Menu,
    RTOOLS_MT_WARP_Mod_Menu,
    RTOOLS_MT_WAVE_Mod_Menu,
    RTOOLS_MT_DATA_TRANSFER_Mod_Menu,
    RTOOLS_MT_MESH_CACHE_Mod_Menu,
    RTOOLS_MT_MESH_SEQUENCE_CACHE_Mod_Menu,
    RTOOLS_MT_NORMAL_EDIT_Mod_Menu,
    RTOOLS_MT_WEIGHTED_NORMAL_Mod_Menu,
    RTOOLS_MT_UV_PROJECT_Mod_Menu,
    RTOOLS_MT_UV_WARP_Mod_Menu,
    RTOOLS_MT_VERTEX_WEIGHT_EDIT_Mod_Menu,
    RTOOLS_MT_VERTEX_WEIGHT_MIX_Mod_Menu,
    RTOOLS_MT_VERTEX_WEIGHT_PROXIMITY_Mod_Menu,
    
    
    
    ### NOde Tools
    RTOOLS_OT_NodeEditor,
    RTOOLS_OT_Add_Node,
    RTOOLS_OT_Selected_Node_To_QAM,
    RTOOLS_OT_SetUp_Flow_Map,
    RTOOLS_OT_Add_Sockets_To_QAM,
    
    ### End Node Tools
    

    ###Light Groups
    RTOOLS_OT_Create_Light_Group,
    RTOOLS_OT_Remove_Light_Group,
    RTOOLS_OT_Select_Light_Group,
    RTOOLS_OT_Delete_Light_Group,
    RTOOLS_OT_Add_Light_To_Group,
    RTOOLS_OT_Remove_Light_From_Group,
    RTOOLS_OT_Multiply_Light_Energy,
    RTOOLS_OT_Select_Light,
    RTOOLS_OT_Randomise_Light_Color,
    RTOOLS_OT_Solo_Light_Group,
    RTOOLS_OT_UnSolo_Light_Group,
    ###End Light Groups
    
    RTOOLS_OT_Planer_Remesh,
    RTOOLS_OT_Create_Cloth,
    
    
    RTOOLS_OT_Break_Op,
    ### Bake Tools
    RTOOLS_OT_Bake_Bevels,
    RTOOLS_OT_Bake_Texture_Maps,
    BakePanel,
    RTOOLS_OT_Multiply_Resolution,
    ### End Bake Tools
    RTOOLS_OT_Project_From_View,
    RTOOLS_OT_Shutter_Speed,
    RTOOLS_OT_Break,
    RTOOLS_OT_Slice,
    
    RTOOLS_OT_Dice,
    
    RTOOLS_OT_Create_Cable,
    RTOOLS_OT_Multiple_Wires,
    RTOOLS_OT_Draw_Curve,
    RTOOLS_OT_Edge_To_Curve,
    
    RTOOLS_MT_Modifier_Adjust_Panel,
    RTOOLS_OT_Add_Lattice,
    
    
    #Particle Tools
    #RT_Particle_Tools,
    #RTOOLS_OT_Instance_At_Vertices,
    RTOOLS_OT_Convert_And_Apply_PS,
    #RTOOLS_OT_Instance_At_Faces,
    #RTOOLS_OT_IAF_Subdivide,
    #RTOOLS_OT_Update_IAF,
    #RTOOLS_OT_Boid_Paritcles,
    #RTOOLS_OT_Add_Collision_Object,
    #RTOOLS_OT_Add_Instance_Object,
    #End - Particle Tools
    RTOOLS_OT_Test,
    RTOOLS_OT_Change_Active_Camera,
    
    
    RTOOLS_OT_Material_Picker,
    RTOOLS_OT_Inset_Boolean,
    RTOOLS_OT_Slice_Boolean,
    RTOOLS_OT_Create_Custom_Op,
    RTOOLS_OT_Clear_Info,
    RTOOLS_OT_Copy_Info,
    RTOOLS_OT_BoolTest,
    RTOOLS_OT_Booleans,
    RTOOLS_OT_Apply_All_Modifiers,
    RTOOLS_OT_AdjustModifier,
    RTOOLS_OT_Grid,
    RTOOLS_OT_Draw_Boolean,
    RTOOLS_OT_Separate_Solidify,
    RTOOLS_OT_Wire_Simul,
    RTOOLS_OT_Mesh_Deform,
    RTOOLS_OT_Spin_Ninty,
    RTOOLS_OT_Display_Type,
    RTOOLS_OT_Object_Brush,
    RTOOLS_OT_RenderSettingsSave,
    RTOOLS_OT_rendersettingsload,
    RTOOLS_OT_Remove_RenderSettings,
    RTOOLS_OT_Update_RenderSettings,
    RTOOLS_OT_Render_All,
    
    RTOOLS_OT_Add_Plane_To_Booleans,
    RTOOLS_OT_Convert_To_Plane,
    RTOOLS_OT_Taper,
    RTOOLS_OT_ExtractFaces,
    RTOOLS_OT_Circular_Array,
    RTOOLS_OT_Apply_Modifiers,
    #RTOOLS_OT_Edge_To_Strip,
    RTOOLS_OT_Wire_Simul2,
    RTOOLS_OT_Load_Presets,
    RTOOLS_OT_WireFrameRender,
    RTOOLS_OT_Call_Render_All,
    RTOOLS_OT_Align_View_To_Face,
    RTOOLS_OT_Inset_Shrink,
    RTOOLS_OT_Merge_VGroups,
    RTOOLS_OT_Create_Boolean_Cleanup_VGroups,
    RTOOLS_OT_Slide_Vertices,
    RTOOLS_OT_Align_Normal_To_Axis,
    RTOOLS_OT_Sync_Modifiers,
    RTOOLS_OT_Caps_On_Curve,RTOOLS_OT_Caps_On_Curve_Internal,
    RTOOLS_OT_Origin_To_Bottom,
    RTOOLS_OT_Curve_Adjust_Modal,
    RTOOLS_OT_Refit_Caps_On_Curve,
    RTOOLS_OT_Recall_Last_Cutter,
    CutterInfo,
    RTOOLS_Cutters_Panel,
    RTOOLS_OT_Recall_Cutter,
    RTOOLS_OT_Add_Camera,
    RTOOLS_OT_Normal_Transfer_2,
    #RTOOLS_OT_Add_To_RanTools_Menu
    RTOOLS_OT_Search_Material,
    Import_Material_Panel,MaterialInfo,RTOOLS_OT_Download_Material,RTOOLS_OT_Select_Children,RTOOLS_OT_Solidify,
    RTOOLS_MT_Node_Mix_Menu,RTOOLS_OT_Call_Node_Mix_Menu,ImperfectionMapsInfo,RTOOLS_OT_Mix_To_Node,RTOOLS_MT_Node_Mix_Sub_Menu,RTOOLS_MT_Material_Mix_Sub_Menu,
    RTOOLS_MT_Material_Mix_Using_Menu,RTOOLS_OT_Mix_Materials,RTOOLS_MT_Material_Imperfection_Maps_Sub_Menu,RTOOLS_MT_Plug_To_Socket_Menu,RTOOLS_OT_Plug_Into_Node,
    RTOOLS_OT_Light_Color_From_Clipboard,
    ProjectInfo,
    RTOOLS_OT_Setup_Project,RTOOLS_OT_Project_Info,RTOOLS_OT_Add_Adjustment_Node,RTOOLS_OT_Save_Override,RTOOLS_MT_Override_Project,RTOOLS_OT_Save_Preferences,RTOOLS_OT_Load_Preferences
    ,RTOOLS_OT_Reset_Project,RTOOLS_OT_Check_For_Updates,
    RTOOLS_OT_Help,
    RTOOLS_OT_Select_Edges_Marked_Sharp,RTOOLS_OT_Bevel_Weight,RTOOLS_OT_Mark_Sharp,
    RTOOLS_MT_Edges_Pie_Menu,RTOOLS_OT_Call_Edges_Pie_Menu,RTOOLS_OT_Edge_Bevel_Weight,RTOOLS_OT_Clear_Edges,RTOOLS_OT_Select_Edges,RTOOLS_OT_Mark_Seam,RTOOLS_OT_Set_Weights
    #modifierPanelExtension
    ,RTOOLS_OT_Generate_All_Thumbnails,
    #HDRI
    HDRIInfo,Import_HDRI_Panel,RTOOLS_OT_Download_HDRI,RTOOLS_OT_Search_HDRI,RTOOLS_OT_Reset_World_Node,RTOOLS_OT_Select,RTOOLS_OT_Prepare_Cloth,RTOOLS_OT_Load_HDRIs
    ,RTOOLS_OT_install_pillow,RTOOLS_OT_Load_Previews
    # RTOOLS_OT_PopUp,RTOOLS_MT_Panels_Pie_Menu,RTOOLS_Call_Panels_Pie
    # ,RTOOLS_Call_Panels_Sub_Pie,RTOOLS_MT_Panels_Sub_Pie_Menu,RTOOLS_OT_Add_Category,RTOOLS_OT_Remove_Category,RTOOLS_MT_Panel_Categories_Pie_Menu,RTOOLS_Call_Panels_Categories_Pie,
    # RTOOLS_OT_searchPopup,RTOOLS_OT_PopUp_Full_Panel,RTOOLS_OT_searchPopupForDropDown,RTOOLS_OT_Remove_Category_Dropdown,RTOOLS_OT_Remove_Category_Workspace,RTOOLS_OT_searchPopupForWorkspace
    
)
panel_classes=(RTOOLS_PT_BackUps,RTOOLS_PT_Camera,RTOOLS_Curve_Tools,RTOOLS_OT_RTools,RTOOLS_Material,RTOOLS_OT_Light,RTOOLS_OT_Bake,RTOOLS_OT_PT_Cutter)
icon_collection={}
addon_keymaps = []
def RenderIndexChanged(self, context):
    if context.scene.activeRenderSettingsIndex<len(context.scene.RenderSettingsSaves):
        load_render_settings(context.scene,context.scene.activeRenderSettingsIndex,render=False)
def drawIntoHeader(self, context):
    layout=self.layout
    #print(context.scene.downloadProgress)
    if context.scene.downloadProgress:
        layout.label(text=context.scene.downloadProgress)
    #layout.scale_x=0.8
    
    #layout.prop(context.scene.rt_tools,'default_shape')
    #layout.prop(context.scene.rt_tools,'keep_drawing')
    if context.active_object is not None:
        layout.prop(context.active_object,'isGround',icon='MOD_OCEAN')
    if "icons" in icon_collection.keys():
        pcoll = icon_collection["icons"]
        snap_icon = pcoll["snap"]
        op=layout.operator("rtools.snapit",icon_value=snap_icon.icon_id,text="Snap")
        op.location=0
        op.onlyGround=False
    else:
        op=layout.operator("rtools.snapit",text="Snap")
        op.location=0
        op.onlyGround=False
def addToRightClickMenu(self, context):
    layout=self.layout
    layout.operator("rtools.addtorantoolsmenu",text="Add To RanTools Menu")
def addToUVMenu(self, context):
    layout=self.layout
    layout.operator("rtools.projectfromview")
def addToCameraMenu(self, context):
    layout=self.layout
    layout.operator("rtools.addcamera",icon='OUTLINER_OB_CAMERA')
def shadingExtended(self, context):
    layout=self.layout.menu_pie()
    layout.operator("rtools.switchrender",text="Rendered (Eevee)" if context.scene.render.engine=='CYCLES' else 'Rendered (Cycles)')
def renderExtended(self, context):
    self.layout.operator('rtools.renderall')
def RT_Menu(self, context):
    popover_panels=["RTOOLS_OT_PT_Cutter","RTOOLS_OT_Light","RTOOLS_OT_Light","RTOOLS_OT_Light"]
    panel = RTOOLS_OT_PT_Cutter.bl_idname
    self.layout.separator(factor=0.2)
    row=self.layout.row()
    #row.popover_group("VIEW_3D", "UI", "", "RanTools")
    #for a in popover_panels:
        #self.layout.popover(eval(f"{a}.bl_idname"), text=eval(f"{a}.bl_label"))
    self.layout.popover(panel, text='RanTools')
    # categories=[]
    # for a in preferences().dropdown_categories:
    #         if a.name==context.scene.active_dropdown_category:
    #             #categories_string= ''.join(a.panels.split())
    #             categories=a.panels.split(",")
    #             categories=[a.strip() for a in categories]
    # #panels=preferences().dropdown_panels.split(',')
    # #panels=[a.strip() for a in panels]
    # for a in categories:
    #     if a:
    #         self.layout.emboss='PULLDOWN_MENU'
    #         #self.layout.alignment = 'RIGHT'
    #         self.layout.operator("rtools.popupcompletepanel",text=a,icon="DOWNARROW_HLT").name=a
def get_dropdown_categories(self, context):
    return [("None","None","None")]+[(a.name,a.name,a.name) for a in preferences().dropdown_categories]
def get_workspace_categories(self, context):
    return [("None","None","None")]+[(a.name,a.name,a.name) for a in preferences().workspace_categories]
def draw_before_editor_menu(self, context):
    self.layout.prop(context.scene,'active_dropdown_category',text="")
    self.layout.prop(context.workspace,'active_workspace_category',text="")
def rtools_manual_map():
    url_manual_prefix = "https://rantools.github.io/rantools/"
    url_manual_mapping = (
        ("bpy.ops.rtools.ratioswitch", "CameraAndRender.html#interactive-camera-adjust"),
        ("bpy.ops.rtools.ratio", "CameraAndRender.html#render-aspect-ratio"),
        ("bpy.ops.rtools.res", "CameraAndRender.html#render-resolution"),
        ("bpy.ops.rtools.cameralens", "CameraAndRender.html#focal-length"),
        ("bpy.ops.rtools.shutter", "CameraAndRender.html#shutter-speed"),
        ("bpy.ops.rtools.addbackdrop", "CameraAndRender.html#add-backdrop"),
        ("bpy.ops.rtools.addlights", "CameraAndRender.html#add-lights"),
        ("bpy.ops.rtools.render_path", "CameraAndRender.html#set-render-path"),
        ("bpy.ops.rtools.denoise", "sCameraAndRender.html#etup-denoising"),
        ("bpy.ops.rtools.saverendersettings", "CameraAndRender.html#batch-rendering"),
        ("bpy.ops.rtools.updaterenderset", "CameraAndRender.html#batch-rendering"),
        ("bpy.ops.rtools.removerenderset", "CameraAndRender.html#batch-rendering"),
        ("bpy.ops.rtools.putoncurve", "CurveTools.html#put-on-curve"),
        ("bpy.ops.rtools.createcable", "CurveTools.html#create-cable"),
        ("bpy.ops.rtools.createmultiplewires", "CurveTools.html#multiple-wires"),
        ("bpy.ops.rtools.drawcurve", "CurveTools.html#draw-cables"),
        ("bpy.ops.rtools.edgetocurve", "CurveTools.html#edge-to-curve"),
        ("bpy.ops.rtools.capsoncurve", "CurveTools.html#caps"),
        ("bpy.ops.rtools.refitcaps", "CurveTools.html#caps"),
        ("bpy.ops.rtools.simulatewire2", "CurveTools.html#simulate-curve-wire"),
        ("bpy.ops.rtools.simulatewire", "CurveTools.html#simulate-curve-wire"),
        ("bpy.ops.rtools.quick_mirror", "RandomTools.html#mirror"),
        ("bpy.ops.rtools.create_asset", "RandomTools.html#create-asset"),
        ("bpy.ops.rtools.import_asset", "RandomTools.html#import-asset"),
        ("bpy.ops.rtools.create_modifier_preset_menu", "RandomTools.html#modifier-presets"),
        ("bpy.ops.rtools.origintogeometrywithmodifiers", "RandomTools.html#origin-to-geometry"),
        ("bpy.ops.rtools.matchvisiblity", "RandomTools.html#match-viewport-and-render-visibility"),
        ("bpy.ops.rtools.groupit", "RandomTools.html#group-it"),
        ("bpy.ops.rtools.snapit", "RandomTools.html#snap-and-snap-to-ground"),
        ("bpy.ops.rtools.remeshdice", "RandomTools.html#dice-remesh"),
        ("bpy.ops.rtools.planerremesh", "RandomTools.html#planar-remesh"),
        ("bpy.ops.rtools.slice", "RandomTools.html#slice"),
        ("bpy.ops.rtools.dice", "RandomTools.html#dice"),
        ("bpy.ops.rtools.addtube", "RandomTools.html#create-tube"),
        ("bpy.ops.rtools.addlattice", "RandomTools.html#add-lattice"),
        ("bpy.ops.rtools.objectbrush", "RandomTools.html#place-copies"),
        ("bpy.ops.rtools.addplanetoboolean", "RandomTools.html#add-plane"),
        ("bpy.ops.rtools.converttoplane", "RandomTools.html#convert-to-plane"),
        ("bpy.ops.rtools.taper", "RandomTools.html#taper"),
        ("bpy.ops.rtools.extractfaces", "RandomTools.html#extract-faces"),
        ("bpy.ops.rtools.circlearray", "RandomTools.html#instance-based-circular-array"),
        ("bpy.ops.rtools.circulararray", "RandomTools.html#circular-array"),
        ("bpy.ops.rtools.convertandapply", "RandomTools.html#make-instances-real"),
        ("bpy.ops.rtools.aligntoface", "RandomTools.html#align-view-to-face"),
        ("bpy.ops.rtools.insetshrink", "RandomTools.html#inset-shrink"),
        ("bpy.ops.rtools.createcloth", "RandomTools.html#cloth"),
        ("bpy.ops.rtools.setup_materials", "MaterialAndNodes.html#setup-materials"),
        ("bpy.ops.rtools.import_material", "MaterialAndNodes.html#material-library"),
        ("bpy.ops.rtools.makeemissive", "MaterialAndNodes.html#make-emissive"),
        ("bpy.ops.rtools.adduvgrid", "MaterialAndNodes.html#add-uv-grid"),
        ("bpy.ops.rtools.removeuvgrid", "MaterialAndNodes.html#add-uv-grid"),
        ("bpy.ops.rtools.addclaymaterial", "MaterialAndNodes.html#add-clay-material"),
        ("bpy.ops.rtools.addclaymaterial", "MaterialAndNodes.html#add-clay-material"),
        ("bpy.ops.rtools.baketextures", "BakingTools.html#bake-textures"),
        ("bpy.ops.rtools.bakebevels", "BakingTools.html#bake-bevels"),
        ("bpy.ops.rtools.curveadjust", "CurveTools.html#curve-modal"),
        ("bpy.ops.rtools.createbackup", "BackupTools.html#create-backup"),
        ("bpy.ops.rtools.refreshbackup", "BackupTools.html#backup-tools"),
        ("bpy.ops.rtools.deletebackup", "BackupTools.html#add-backup"),
        ("bpy.ops.rtools.addbackup", "BackupTools.html#add-backup"),
        ("bpy.ops.rtools.replacebackup", "BackupTools.html#replace-with-backup"),
        ("bpy.ops.rtools.normaltransfer", "BackupTools.html#normal-transfer"),
        ("bpy.ops.rtools.addnode", "MaterialAndNodes.html#add-node"),
        ("bpy.ops.rtools.addnodetoqam", "MaterialAndNodes.html#quick-material-adjust-panel"),
        ("bpy.ops.rtools.addsocketstoqam", "MaterialAndNodes.html#quick-material-adjust-panel"),
        ("bpy.ops.rtools.makeitflow", "MaterialAndNodes.html#make-it-flow"),
        ("bpy.ops.rtools.createbooleanvgroups", "PCutter.html#merge-nearby-vertices"),
        ("bpy.ops.rtools.slidevertices", "PCutter.html#slide-nearby-vertices"),
        ("bpy.ops.rtools.cleanbooleans", "PCutter.html#clean-booleans"),
        #("bpy.ops.rtools.normaltransfer", "edge"),


    )
    return url_manual_prefix, url_manual_mapping
addons_to_exclude=['io_anim_bvh', 'io_curve_svg', 'io_mesh_ply', 'io_mesh_uv_layout', 'io_mesh_stl', 'io_scene_fbx', 'io_scene_gltf2', 'io_scene_obj', 'io_scene_x3d', 'cycles', 'pose_library','node_wrangler', 'node_arrange', 'node_presets','mesh_looptools', 'development_iskeyfree','development_icon_get','add_curve_extra_objects', 'add_mesh_extra_objects','space_view3d_spacebar_menu', 'brush_quickset', 'development_edit_operator', 'space_view3d_modifier_tools']

def active_dropdown_category_changed(self, context):
    
    if context.workspace.active_workspace_category=="None":
        context.workspace.use_filter_by_owner = False
    else:
        context.workspace.use_filter_by_owner = True
        categories=[]
        for a in preferences().workspace_categories:
                if a.name==context.workspace.active_workspace_category:
                    #categories_string= ''.join(a.panels.split())
                    categories=a.panels.split(",")
                    categories=[a.strip() for a in categories]
        
        for a in ["RanTools"] + categories[:]:
            try:
                a=sys.modules[a].__name__
                if a not in [c.name for c in context.workspace.owner_ids]:
                    bpy.ops.wm.owner_enable(owner_id=a)
            except:
                pass
        for a in addons_to_exclude:
            try:
                if a not in [c.name for c in context.workspace.owner_ids]:
                    bpy.ops.wm.owner_enable(owner_id=a)
            except:
                pass
        for b in bpy.context.preferences.addons.keys():
            try:
                #print(b)
                mod = sys.modules[b]
                if mod.__name__ not in categories+["RanTools"] and mod.__name__ in [a.name for a in context.workspace.owner_ids]:
                    if mod.__name__ not in addons_to_exclude:
                        #print("Disable",mod.__name__)
                        bpy.ops.wm.owner_disable(owner_id=mod.__name__)
            except:
                    pass
def register():
    indexesPath=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes")
    if not os.path.exists(indexesPath):
            os.mkdir(indexesPath)
    from bpy.utils import register_class
    #for cls in custom_operators:
    #    register_class(cls)
    """with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "operators.csv"), mode='w', newline='', encoding='utf-8') as csvFile:
        csvFileWriter = csv.writer(
            csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
        for cls in classes:
            
            try:
                pass
                #print(cls.bl_idname)
                #csvFileWriter.writerow([cls.bl_label,])
            except:
                pass
    with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "descriptions.csv"), mode='w', newline='', encoding='utf-8') as csvFile:
        csvFileWriter = csv.writer(
            csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
        for cls in classes:
            
            try:
                pass
                #print(cls.bl_description)
                #csvFileWriter.writerow([cls.bl_description.replace("\n"," <br> "),])
            except:
                pass
    with open("operators - operators.csv", mode='r', newline='', encoding='utf-8') as csvFile:
        reader =csv.reader(csvFile, delimiter=',')
        f=open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "op_translations.csv"), mode='w', newline='', encoding='utf-8')
        csvFileWriter = csv.writer(
            f, delimiter=",",)
        #for r in reader:
        #    f.write(f"('Operator', '{r[0]}'): '{r[1]}',\n")
    with open("Untitled spreadsheet - Sheet1.csv", mode='r', newline='', encoding='utf-8') as csvFile:
        reader =csv.reader(csvFile, delimiter=',')
        f=open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "my_translations.csv"), mode='w', newline='', encoding='utf-8')
        csvFileWriter = csv.writer(
            f, delimiter=",",)
        for r in reader:
            f.write(f"'{r[0].lower()}': '{r[1]}',\n")"""
    for cls in classes:

        register_class(cls)
    for cls in panel_classes:
        try:
            register_class(cls)
        except:
            pass
    bpy.types.Scene.rt_tools = bpy.props.PointerProperty(type=RTOOLSProps)
    bpy.types.Scene.rt_props = bpy.props.CollectionProperty(type=appendObjectInfo)
    bpy.types.Scene.rt_assets = bpy.props.CollectionProperty(type=AssetInfo)
    bpy.types.Scene.rt_materials = bpy.props.CollectionProperty(type=MaterialInfo)
    bpy.types.Scene.rt_hdris = bpy.props.CollectionProperty(type=HDRIInfo)
    bpy.types.Scene.modMenuInfo = bpy.props.CollectionProperty(type=MenuInfo)
    bpy.types.Scene.projectInfo= bpy.props.PointerProperty(type=ProjectInfo)
    bpy.types.Scene.is_project_setup = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.modSubMenuInfo = bpy.props.CollectionProperty(type=subMenuInfo)
    bpy.types.Scene.lightGroups = bpy.props.CollectionProperty(type=LightGroups)
    #bpy.types.Scene.saved_views=bpy.props.CollectionProperty(type=SavedViews)
    #bpy.types.Scene.SavedViewsIndex=bpy.props.IntProperty()
    #bpy.types.Scene.boidSystems= bpy.props.CollectionProperty(type=BoidSystems)
    #bpy.types.Scene.active_boid_system= bpy.props.IntProperty(default=0)
    bpy.types.Scene.OperatorLines = bpy.props.CollectionProperty(type=OperatorLines)
    bpy.types.Scene.imperfection_maps = bpy.props.CollectionProperty(type=ImperfectionMapsInfo)
    #bpy.types.Scene.last_panel_category = bpy.props.StringProperty(default="")
    #bpy.types.Scene.last_panel_subcategory = bpy.props.StringProperty(default="Item")
    #bpy.types.Scene.opened_panels= bpy.props.CollectionProperty(type=Opened_Panels)
    #bpy.types.Scene.active_dropdown_category=bpy.props.EnumProperty(items=get_dropdown_categories,name="Dropdowns")
    #bpy.types.WorkSpace.active_workspace_category=bpy.props.EnumProperty(items=get_workspace_categories,name="Dropdowns",update=active_dropdown_category_changed)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    #if (2, 92, 0) > bpy.app.version:
    #    kc = wm.keyconfigs.new("RToolsConfig")
    #else:
    #    kc = wm.keyconfigs.addon
    kmaps = [
        #("rtools.ratioswitch", "C", "alt"),
        # ("rtools.render_path", 'R', 'shift'),
        ("rtools.addlights", "L", ""),
        ("rtools.addbackdrop", "U", ""),
        ("rtools.callrtmain", "E", ""),
        ("rtools.quick_mirror", "E", "alt"),
        ("rtools.callpie", "W", "shift"),
        ("rtools.call_append_panel", "F", "alt"),
        #("rtools.clean_booleans", "U", "alt"),
        ("rtools.create_asset", "Y", "alt"),
        ("rtools.import_asset", "L", "alt"),
        ("rtools.makeemissive", "G", "alt"),
        ("rtools.invoke_modifier_menu", "Q", "alt"),
        ("rtools.ratioswitch", "C", "alt"),
        ("rtools.call_material_menu", "J", 'shift'),
        #("rtools.call_material_menu", "N", "alt"),
        ("rtools.backup_panel","B","alt"),
        #("rtools.snapit","M","alt"),
        ("rtools.bake_panel","O","alt"),
        ('rtools.materialadjustpanel','F','shift'),
        ('rtools.callcurvespie','E','shift'),
        ('rtools.callbooleanspie','Q','shift'),
        ('rtools.cleanbooleans','U','alt'),
        ('rtools.recalllastcutter','V','alt'),
        ('rtools.cutterspanel','X','alt'),
        ("rtools.invoke_modifier_favorites_menu","T","alt"),
        ("rtools.import_material",'M','alt'),
        ("rtools.import_hdri",'N','alt'),
        ("rtools.selectchildren","NUMPAD_SLASH",""),
        ("rtools.projectsettings","I","shift"),
        ("rtools.saveproject","S","ctrl"),
    ]
    """kmaps = [
        ("rtools.ratioswitch", "C", "alt"),
        # ("rtools.render_path", 'R', 'shift'),
        ("rtools.addlights", "L", "alt+ctrl"),
        ("rtools.addbackdrop", "U", ""),
        ("rtools.callrtmain", "E", ""),
        ("rtools.quick_mirror", "E", "alt"),
        ("rtools.callpie", "W", "shift+ctrl"),
        ("rtools.call_append_panel", "F", "alt+ctrl"),
        #("rtools.clean_booleans", "U", "alt"),
        ("rtools.create_asset", "Y", "alt"),
        ("rtools.import_asset", "L", "alt"),
        ("rtools.makeemissive", "G", "alt"),
        ("rtools.invoke_modifier_menu", "Q", "alt+shift"),
        ("rtools.ratioswitch", "C", "alt"),
        ("rtools.call_material_menu", "J", 'shift'),
        #("rtools.call_material_menu", "N", "alt"),
        ("rtools.backup_panel","B","alt"),
        #("rtools.snapit","M","alt"),
        ("rtools.bake_panel","O","alt"),
        ('rtools.materialadjustpanel','F','shift+alt'),
        ('rtools.callcurvespie','E','shift+ctrl'),
        ('rtools.callbooleanspie','Q','shift+ctrl'),
        ('rtools.cleanbooleans','U','alt'),
        ('rtools.recalllastcutter','V','alt+ctrl'),
        ('rtools.cutterspanel','S','alt+ctrl'),
        ("rtools.invoke_modifier_favorites_menu","T","alt"),
        ("rtools.import_material",'M','alt'),
        ("rtools.selectchildren","NUMPAD_SLASH",""),
        ("rtools.projectsettings","I","shift"),
        ("rtools.saveproject","S","ctrl")
    ]"""
    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
    if kc:
        for (op, k, sp) in kmaps:
            kmi = km.keymap_items.new(
                op,
                type=k,
                value="PRESS",
                alt="alt" in sp,
                shift="shift" in sp,
                ctrl="ctrl" in sp,
            )
            addon_keymaps.append((km, kmi))
    km= kc.keymaps.new(name="Node Editor", space_type="NODE_EDITOR")
    if kc:
        kmi= km.keymap_items.new("rtools.callnodemixmenu",type='M',value='PRESS',alt=True)
        addon_keymaps.append((km, kmi))
    # km = kc.keymaps.new(name="Object Mode", space_type="EMPTY")
    # if kc:
    #     kmi = km.keymap_items.new(
    #         "rtools.callcategoriespie", type="R", value="PRESS", shift=True
    #     )
    #     addon_keymaps.append((km, kmi))
    km = kc.keymaps.new(name="Mesh", space_type="EMPTY")
    if kc:
        kmi = km.keymap_items.new(
            "rtools.calledgespie", type="E", value="PRESS", shift=True
        )
        addon_keymaps.append((km, kmi))
    if kc:
        kmi = km.keymap_items.new(
            "rtools.setweight", type="EQUAL", value="PRESS",
        )
        kmi.properties.value=1
        addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new(
            "rtools.setweight", type="MINUS", value="PRESS",
        )
        kmi.properties.value=-1
        addon_keymaps.append((km, kmi))
    bpy.types.Scene.update_status=bpy.props.StringProperty(default="RanTools is Up To Date!")
    bpy.types.Scene.rantools_custom_message= bpy.props.StringProperty(default="")
    bpy.types.DATA_PT_modifiers.append(modifierPanelExtension)
    bpy.app.handlers.depsgraph_update_post.append(updateModPresets)
    bpy.app.handlers.load_post.append(onNewProjectLoad)
    bpy.app.handlers.render_complete.append(filePathHandler)
    bpy.types.Scene.node_to_mix= bpy.props.StringProperty()
    bpy.types.Scene.materialtomix= bpy.props.StringProperty()
    bpy.types.Scene.RenderSettingsSaves=bpy.props.CollectionProperty(type=RenderSettings)
    bpy.types.Scene.activeRenderSettingsIndex=bpy.props.IntProperty(update=RenderIndexChanged)
    bpy.types.Scene.activeRenderSettingsIndexCopy=bpy.props.IntProperty()
    bpy.types.Scene.downloadProgress=bpy.props.StringProperty()
    bpy.types.Object.BackUps=bpy.props.CollectionProperty(type=BackUpInfo)
    bpy.types.Object.backup_collection_name= bpy.props.StringProperty(default="")
    bpy.types.Object.Caps=bpy.props.CollectionProperty(type=CapsInfo)
    bpy.types.Object.CutterId=bpy.props.StringProperty(default="None")
    bpy.types.Object.CuttersInfo=bpy.props.CollectionProperty(type=CutterInfo)
    bpy.types.Object.isGround=bpy.props.BoolProperty(default=False,name="Ground")
    bpy.types.Object.specialInfo=bpy.props.StringProperty(default="None")
    bpy.types.Object.wire_type=bpy.props.EnumProperty(items=(('Parallel','Parallel','Parallel'),('Radial','Radial','Radial')),update=wire_type_update)
    bpy.types.Object.wire_axis=bpy.props.EnumProperty(items=(('X','X','Y'),('Y','Y','Y')),update=wire_axis_update,name="Axis")
    bpy.types.Object.wire_parallel_offset=bpy.props.FloatProperty(default=0.1,update=wire_offset_update,name="Offset")
    bpy.types.Object.last_clothpin_group_name=bpy.props.StringProperty(default="",name="Last Cloth Pin Group",options={'HIDDEN'})
    #bpy.types.Object.isTube=bpy.props.BoolProperty(default=False)
    bpy.types.Material.backup_blend_mode=bpy.props.StringProperty(default="NA",name="Backup Blend Mode")
    bpy.types.Object.BackUpsIndex=bpy.props.IntProperty(name="Backup")
    bpy.types.Object.hide_view=bpy.props.BoolProperty(name="Hide View",options={'ANIMATABLE'},default=False,update=visiblityUpdate)
    
    
    bpy.types.VIEW3D_MT_uv_map.append(addToUVMenu)
    bpy.types.VIEW3D_MT_camera_add.append(addToCameraMenu)
    bpy.types.VIEW3D_MT_shading_pie.append(shadingExtended)
    bpy.types.TOPBAR_MT_render.append(renderExtended)
    bpy.types.VIEW3D_MT_editor_menus.append(RT_Menu)
   # bpy.types.VIEW3D_HT_tool_header.prepend(draw_before_editor_menu)
    #bpy.types.WM_MT_button_context.append(addToRightClickMenu)
    pcoll = bpy.utils.previews.new()
    my_icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    pcoll.load("snap", os.path.join(my_icons_dir, "snapToGround.png"), 'IMAGE')
    pcoll.load("union", os.path.join(my_icons_dir, "Union.png"), 'IMAGE')
    pcoll.load("difference", os.path.join(my_icons_dir, "Difference.png"), 'IMAGE')
    pcoll.load("slice", os.path.join(my_icons_dir, "Slice.png"), 'IMAGE')
    pcoll.load("intersect", os.path.join(my_icons_dir, "Intersect.png"), 'IMAGE')
    pcoll.load("inset", os.path.join(my_icons_dir, "Inset.png"), 'IMAGE')
    pcoll.load("uvgrid", os.path.join(my_icons_dir, "UVGrid.png"), 'IMAGE')
    pcoll.load("cable", os.path.join(my_icons_dir, "Cable.png"), 'IMAGE')
    pcoll.load("wiresimul", os.path.join(my_icons_dir, "WireSimulation.png"), 'IMAGE')
    pcoll.load("dice", os.path.join(my_icons_dir, "Dice.png"), 'IMAGE')
    pcoll.load("multicable", os.path.join(my_icons_dir, "MultiCable.png"), 'IMAGE')
    pcoll.load("stack", os.path.join(my_icons_dir, "Stack.png"), 'IMAGE')
    pcoll.load("draw", os.path.join(my_icons_dir, "Draw.png"), 'IMAGE')
    pcoll.load("putoncurve", os.path.join(my_icons_dir, "Putoncurve.png"), 'IMAGE')
    pcoll.load("drawcables", os.path.join(my_icons_dir, "Drawcables.png"), 'IMAGE')
    pcoll.load("edgetocurve", os.path.join(my_icons_dir, "Edgetocurve.png"), 'IMAGE')
    pcoll.load("youtube", os.path.join(my_icons_dir, "Youtube.png"), 'IMAGE')
    pcoll.load("discord", os.path.join(my_icons_dir, "Discord.png"), 'IMAGE')
    pcoll.load("updategreen", os.path.join(my_icons_dir, "updategreen.png"), 'IMAGE')
    pcoll.load("updatered", os.path.join(my_icons_dir, "updatered.png"), 'IMAGE')
    pcoll.load("adjust", os.path.join(my_icons_dir, "Adjust.png"), 'IMAGE')
    icon_collection["icons"] = pcoll
    # bpy.app.translations.register(__name__, langs)
    other_langs={bpy.context.preferences.view.language:{}}
    for file in os.listdir(os.path.join(os.path.dirname(__file__),'Translations')): 
        if bpy.context.preferences.view.language in file:
            with open(os.path.join(os.path.dirname(__file__),'Translations',file),encoding='utf-8',mode='r') as json_file:
                other_langs[bpy.context.preferences.view.language].update(json.load(json_file)[bpy.context.preferences.view.language])
    other_langs=process_json(other_langs)
    if other_langs:
        langs.update(other_langs)
    
    bpy.app.translations.register(__name__, langs)
    bpy.utils.register_manual_map(rtools_manual_map)
    addon_update_checker.register("fdc3ba55182ef142063df0b2cc794563")
    # bpy.app.handlers.load_post.append(setupdatestatus)
    loadPreferences()
@persistent
def setupdatestatus(scene):
    try:
        bpy.types.VIEW3D_HT_tool_header.remove(drawIntoHeader)
    except:
        pass
    bpy.types.VIEW3D_HT_tool_header.append(drawIntoHeader)
    current_version=str(sys.modules['RanTools'].bl_info['version']).replace("(","").replace(")","").replace(", ","")
    og_online_version,message=getCurrentVersion()
    online_version=og_online_version.replace(".","")
    if online_version!="Disconnected":
        if int(online_version)<int(current_version):
            bpy.context.scene.update_status ="RanTools is Up To Date! (Beta)" 
        elif int(online_version)==int(current_version):
            bpy.context.scene.update_status ="RanTools is Up To Date!" 
        else:
            bpy.context.scene.update_status=f"Update Available! (v{og_online_version})"
        if message!="Disconnected":
            bpy.context.scene.rantools_custom_message=message
        else:
            bpy.context.scene.rantools_custom_message=""
    else:
        print("Couldn't check for Updates")
@persistent
def filePathHandler(scene):
        #scene=bpy.context.window_manager.windows[0].scene
        #print(bpy.context.area,bpy.context.screen,bpy.context.workspace)
        if not scene.rt_tools.auto_save  or not bpy.data.is_saved or scene.rt_tools.render_all:
            return {'CANCELLED'}
        
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]
        blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
        filepath = os.path.splitext(bpy.data.filepath)[0]  if not os.path.isdir(scene.projectInfo.renders_folder_path) else scene.projectInfo.renders_folder_path
        fname=blendname
        if bpy.context.scene.render.engine=='CYCLES':
            filepath=os.path.join(filepath,'Cycles')
        else:
            filepath=os.path.join(filepath,'Eevee')
        if not os.path.exists(filepath):
            os.mkdir(filepath)
        #if scene.rt_tools.render_all:
        #    blendname=blendname+" "+scene.RenderSettingsSaves[scene.activeRenderSettingsIndexCopy].name
        #    fname=blendname
        files = [file for file in os.listdir(filepath)
                if file.startswith(blendname)]
        i=0
        name=fname
        while(fname+"."+scene.render.image_settings.file_format.lower() in files):
            fname = f"{name}_{i}"
            #print(fname)
            i+=1
        final_name = os.path.join(filepath, fname+"."+scene.render.image_settings.file_format.lower())

        image = bpy.data.images['Render Result']
        if not image:
            return "ERROR"

        image.save_render(final_name, scene=None)
        """if scene.rt_tools.render_all:
            
            scene.activeRenderSettingsIndexCopy+=1
            while scene.activeRenderSettingsIndexCopy<len(scene.RenderSettingsSaves) and scene.RenderSettingsSaves[scene.activeRenderSettingsIndexCopy].hide_view :
                scene.activeRenderSettingsIndexCopy+=1
            if scene.activeRenderSettingsIndexCopy==len(scene.RenderSettingsSaves):
                        scene.rt_tools.render_all=False
                        scene.activeRenderSettingsIndexCopy=0
                        return {'FINISHED'}
            #print('loading: ',scene.activeRenderSettingsIndexCopy)
            load_render_settings(scene,scene.activeRenderSettingsIndexCopy)
            
            #print(scene.activeRenderSettingsIndex,len(scene.RenderSettingsSaves))
            if scene.activeRenderSettingsIndexCopy<=len(scene.RenderSettingsSaves):
                bpy.ops.render.render()
                """
    
"""        if filename:
        if not os.path.isdir(os.path.join(bpy.data.filepath[:bpy.data.filepath.rindex('\\')], filename)):
            os.mkdir(os.path.join(
                bpy.data.filepath[:bpy.data.filepath.rindex('\\')], filename))
        folderPath = os.path.join(
            bpy.data.filepath[:bpy.data.filepath.rindex('\\')], filename)
        i=0
        print(folderPath)
        print(os.listdir(folderPath))
        while(filename in os.listdir(folderPath)):
            filename = f"{filename}_{i}"
            i+=1
        bpy.context.scene.render.filepath = os.path.join(
                folderPath, f"{filename}")
        if not bpy.context.scene.use_nodes:

            bpy.context.scene.use_nodes = True
        nodesField = bpy.context.scene.node_tree
        fileOutputNode=None
        #renderLayerNode=nodesField.nodes.new(type = 'CompositorNodeRLayers')
        if "RT_File_Output" in [n.name for n in nodesField.nodes]:
            fileOutputNode=nodesField.nodes["RT_File_Output"]
            fileOutputNode.inputs[0].name="HI"
        else:
            fileOutputNode = nodesField.nodes.new(
                type='CompositorNodeOutputFile')
            fileOutputNode.name="RT_File_Output"
        fileOutputNode.base_path=f"{bpy.context.scene.render.filepath}/{filename}.png"
"""

@persistent
def onNewProjectLoad(scene):
    
    bpy.app.handlers.depsgraph_update_post.append(updateModPresets)

def unregister():
    savePreferences()
    from bpy.utils import unregister_class

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()
    for pcoll in icon_collection.values():
        bpy.utils.previews.remove(pcoll)
    icon_collection.clear()
    preview_list.clear()
    #for cls in reversed(custom_operators):
    #    unregister_class(cls)
    for cls in reversed(classes):
        unregister_class(cls)
    for cls in reversed(panel_classes):
        try:
            unregister_class(cls)
        except:
            pass
    del bpy.types.Scene.rt_tools
    for (km, kmi) in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.DATA_PT_modifiers.remove(modifierPanelExtension)
    bpy.types.VIEW3D_HT_tool_header.remove(drawIntoHeader)
    bpy.types.VIEW3D_MT_uv_map.remove(addToUVMenu)
    bpy.types.VIEW3D_MT_camera_add.remove(addToCameraMenu)
    bpy.types.VIEW3D_MT_shading_pie.remove(shadingExtended)
    bpy.types.TOPBAR_MT_render.remove(renderExtended)
    bpy.types.VIEW3D_MT_editor_menus.remove(RT_Menu)
    #bpy.types.VIEW3D_HT_tool_header.remove(draw_before_editor_menu)
    #rcmenu = getattr(bpy.types, "WM_MT_button_context", None)
    #if rcmenu:
        #bpy.types.WM_MT_button_context.remove(addToRightClickMenu)
    try:
        # bpy.app.handlers.load_post.remove(setupdatestatus)
        bpy.app.handlers.load_post.remove(onNewProjectLoad)
    except:
        pass
    try:
        bpy.app.handlers.render_complete.remove(filePathHandler)
    except:
        pass
    addon_update_checker.unregister()
    #bpy.app.handlers.frame_change_pre.clear()
    bpy.app.translations.unregister(__name__)
    bpy.utils.unregister_manual_map(rtools_manual_map)
if __name__ == "__main__":
    register()


# endregion
