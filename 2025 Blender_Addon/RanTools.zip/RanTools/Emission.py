import bpy
from . utils import *


class RTOOLS_OT_Make_Emissive(bpy.types.Operator):
    bl_idname = "rtools.makeemissive"
    bl_label = "Make Emissive"
    bl_description = "Make Selected Faces Emissive"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object is not None and context.active_object.active_material is not None:
            return context.active_object.mode == 'EDIT'
        else:
            return False

    def add_drawHandler(self, context):
        self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_px, (context,), "WINDOW", "POST_PIXEL")

    def remove_drawHandler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, "WINDOW")
        context.area.tag_redraw()

    def draw_callback_px(self, context):
        draw_Text(context, 0, preferences().font_size, text=[
                  f"Emission Strength: {round(self.node_emission.inputs[1].default_value,4) if self.node_emission is not None else '0'}"])

    def execute(self, context):
        colorInput = None
        a = None
        Done = False
        me = bpy.context.active_object.data
        mat_offset = len(me.materials)
        if bpy.data.materials.get(f"Emissive_{bpy.context.active_object.active_material.name}") is not None:
            for i, m in enumerate(me.materials):
                if m.name == f"Emissive_{bpy.context.active_object.active_material.name}":
                    bpy.context.active_object.active_material_index = i
                    self.mat = bpy.context.active_object.active_material
                    links = self.mat.node_tree.links
                    for link in links:
                        #print(f"{link.from_node} => {link.to_node}")
                        if link.to_node.bl_idname == "ShaderNodeOutputMaterial" and link.to_node.name == 'Material Output':
                            if int(link.to_socket.path_from_id()[-2:-1]) == 0:
                                self.node_emission = link.from_node
                                # print(self.node_emission)
                                if len(self.node_emission.inputs) > 1:
                                    self.thresholdSave = self.node_emission.inputs[1].default_value
                                # print(self.node_emission)
                                break
                    bpy.ops.object.material_slot_assign()
                    Done = True
                    return {'RUNNING_MODAL'}
        if not Done:
            self.mat = bpy.context.active_object.active_material.copy()
            self.mat.name = f"Emissive_{bpy.context.active_object.active_material.name}" if 'Emissive_' not in bpy.context.active_object.active_material.name else f"{bpy.context.active_object.active_material.name}"

            me.materials.append(self.mat)
            nodes = self.mat.node_tree.nodes
            node_output = nodes.get("Material Output")
            if not node_output and [a for a in nodes if a.type == "OUTPUT_MATERIAL"]:
                node_output = [a for a in nodes if a.type ==
                               "OUTPUT_MATERIAL"][0]
            self.node_emission = nodes.new(type='ShaderNodeEmission')
            self.node_emission.location = 0, 500
            links = self.mat.node_tree.links
            lastNode = None
            for link in links:
                #print(f"{link.from_node} => {link.to_node}")
                if link.to_node.bl_idname == "ShaderNodeOutputMaterial":
                    if int(link.to_socket.path_from_id()[-2:-1]) == 0:
                        lastNode = link.from_node
                        # print(lastNode)
                        break
            # print(lastNode)
            # print(lastNode.inputs[0].default_value)
            # print("Hi")
            if lastNode and lastNode.bl_idname in {'ShaderNodeEmission', 'ShaderNodeBsdfPrincipled', 'ShaderNodeBsdfDiffuse', 'ShaderNodeBsdfGlass', 'ShaderNodeBsdfGlossy', 'ShaderNodeBsdfRefraction', 'ShaderNodeBsdfTranslucent', 'ShaderNodeBsdfTransparent', 'ShaderNodeSubsurfaceScattering', 'ShaderNodeEeveeSpecular'} and node_output:
                self.node_emission.inputs[0].default_value = lastNode.inputs[0].default_value
                self.node_emission.inputs[1].default_value = 2
                for link in links:

                    if link.to_node == lastNode:
                        t = int(link.to_socket.path_from_id()[link.to_socket.path_from_id().index(
                            "inputs[")+7:][:link.to_socket.path_from_id()[link.to_socket.path_from_id().index("inputs[")+7:].index("]")])
                        if t == 0:
                            colorInput = link.from_node
                            # print(colorInput)
                            a = int(link.from_socket.path_from_id()[-2:-1])
                            break
                link = links.new(colorInput.outputs[a], self.node_emission.inputs[0]
                                 ) if colorInput is not None and a is not None else None
                link = links.new(
                    self.node_emission.outputs[0], node_output.inputs[0])

                bpy.context.active_object.active_material_index = mat_offset
                bpy.ops.object.material_slot_assign()

                # face.material_index=mat_offset
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'LEFT_SHIFT':
            self.initX = event.mouse_x
            if event.value == 'PRESS':
                self.speed = 10
            elif event.value == 'RELEASE':
                self.speed = 1
            self.thresholdSave = self.node_emission.inputs[1].default_value
            context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            if self.node_emission is not None and len(self.node_emission.inputs) > 1:
                self.node_emission.inputs[1].default_value = max(
                    round(self.thresholdSave-(self.initX-event.mouse_x)/(100*self.speed), 2), 0)
            context.area.tag_redraw()
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            bpy.context.active_object.active_material_index = self.initMatIndex
            bpy.ops.object.material_slot_assign()
            bpy.context.active_object.active_material_index = len(
                bpy.context.active_object.data.materials)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.material_slot_remove()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.context.active_object.active_material_index = self.initMatIndex
            bpy.data.materials.remove(self.mat)
            self.remove_drawHandler(context)
            return {'FINISHED'}
        return{'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.thresholdSave = 0
        self.initX = event.mouse_x
        self.speed = 1
        self.node_emission = None
        self.initMatIndex = bpy.context.active_object.active_material_index
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        return self.execute(context)
