import bpy
from . utils import * 
import os
class RTOOLS_OT_addLights(bpy.types.Operator):
    # Add Lights
    bl_idname = "rtools.addlights"
    bl_label = "Add Light Setups"
    bl_description = "Add Light Setups"
    bl_options = {'REGISTER', 'UNDO'}
    lights=[]
    currentL=None
    lastL=None
    LightsCol=None
    AlignToggle=True
    alignedTo="None"
    active=None
    i=0
    @classmethod
    def poll(cls, context):
        if context.active_object is not None:
            return context.active_object.mode == 'OBJECT'
    #for a in range(1,6):
    #    lights.append(f"Light_{a}")
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"T: Track to object({'ON' if self.add_constraint else 'OFF'})",f"Hold CTRL : Light Intensity Multiplier ({format(round(self.multiplier,2),'0.2f')})",f"A: Change Alignment({self.alignedTo})",f"Light Setup: {self.lastL.name}"])
    def execute(self, context):
        context.area.tag_redraw()
        last_scale=self.lastL.scale.copy() if self.lastL else [1,1,1]
        last_rotation_euler=self.lastL.rotation_euler.copy() if self.lastL else [0,0,0]
        if self.lastL is not None:
            delete_collection(self.lastL.users_collection[0],delete_objects=True)
        file_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","Lights.blend","Collection")
        bpy.ops.wm.append(
            directory=file_path,
            filename=self.currentL,autoselect=True
        )
        obj=bpy.data.objects[self.currentL]
        obj.scale=(max(self.scale[:])/2,max(self.scale[:])/2,max(self.scale[:])/2)
        obj.name="L_"+obj.name
        obj.users_collection[0].name="Light_temp"
        active_object=bpy.context.active_object
        self.active=active_object
        #obj.scale=(active_object.dimensions.x*3,active_object.dimensions.x*3,active_object.dimensions.x*3)
        obj.location=active_object.location
        if bpy.context.scene.camera is not None:
            if not self.AlignToggle:
                self.alignedTo="Camera"
                obj.rotation_euler[2] = bpy.context.scene.camera.rotation_euler[2]
            else:
                self.alignedTo="Object"
                obj.rotation_euler[2] = active_object.rotation_euler[2]
        else:
            self.alignedTo="Object"
            obj.rotation_euler[2] = active_object.rotation_euler[2]
        self.lightEnergies=[]
        
        self.lastL=obj
        self.lastL.scale=last_scale
        self.lastL.rotation_euler=last_rotation_euler
        for c in self.lastL.children:
            self.lightEnergies.append(c.data.energy)
            if self.add_constraint:
                constraint=c.constraints.new('TRACK_TO')
                constraint.name="RT_Track_To"
                constraint.target=self.active
            c.data.energy*=self.multiplier
        return {'FINISHED'}  
    def modal(self, context,event):
        rt_tools=context.scene.rt_tools
        
        if event.type == 'LEFT_CTRL':
                self.multiplierSave=self.multiplier
                self.initX=event.mouse_x
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i=(self.i+1)%len(self.lights)
            self.currentL=self.lights[self.i]
            self.execute(context)
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i=(self.i-1)%len(self.lights)
            self.currentL=self.lights[self.i]
            self.execute(context)
        elif event.type == 'MOUSEMOVE' and event.ctrl and self.lightEnergies:
            self.multiplier=self.multiplierSave-((self.initX-event.mouse_x)/100)
            if self.lastL:
                for i,c in enumerate(self.lastL.children):
                    c.data.energy=self.lightEnergies[i]*self.multiplier
        elif event.type == 'T' and event.value=="PRESS":
            self.add_constraint=not self.add_constraint
            if self.add_constraint:
                if self.lastL:
                    for i,c in enumerate(self.lastL.children):
                        if not c.constraints.get("RT_Track_To"):
                            constraint=c.constraints.new('TRACK_TO')
                            constraint.name="RT_Track_To"
                            constraint.target=self.active
            else:
                if self.lastL:
                    for i,c in enumerate(self.lastL.children):
                        if c.constraints.get("RT_Track_To"):
                            c.constraints.remove(c.constraints.get("RT_Track_To"))
                        
            return {'RUNNING_MODAL'}
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.remove_drawHandler(context)
            lastCol=self.lastL.users_collection[0].name
            #print(self.lastL.type)
            moveToNewCollection(lastCol,self.lastL,'Lights')
            select(self.lastL,active=True)
            bpy.ops.rtools.changelightintensity('INVOKE_DEFAULT')
            bpy.ops.rtools.createlightgroup()
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC':
            self.remove_drawHandler(context)
            delete_collection(self.lastL.users_collection[0],delete_objects=True)
            return {'CANCELLED'}

        elif event.type == 'A' and event.value=="PRESS":
            self.AlignToggle=not self.AlignToggle
            if self.AlignToggle:
                self.alignedTo="Object"
                self.lastL.rotation_euler[2]=self.active.rotation_euler[2]
            if not self.AlignToggle:
                if bpy.context.scene.camera is not None:
                    self.alignedTo="Camera"
                    self.lastL.rotation_euler[2] = bpy.context.scene.camera.rotation_euler[2]
                else:
                    self.report({'ERROR'},"No Active Camera Found")
        elif event.type == 'S' or event.type=='R' and event.value=="PRESS":   
            return {'PASS_THROUGH'} 
        return {'RUNNING_MODAL'}    
    def invoke(self, context,event):
        self.add_constraint=False
        self.lights=[]
        with bpy.data.libraries.load(os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","Lights.blend")) as (data_from, _):
            for col in data_from.collections:
                self.lights.append(col)
        self.lights.reverse()
        enable_abs(context)
        active_object=bpy.context.active_object
        self.active=active_object
        self.scale=self.active.dimensions.copy()
        if active_object is None:
            self.report({'ERROR'},"No Active Object Found!")
            return{'CANCELLED'}
        self.multiplier=1
        self.multiplierSave=self.multiplier
        self.initX=event.mouse_x
        self.lightEnergies=[]
        self.lastL=None
        rt_tools=context.scene.rt_tools
        self.alignedTo="Camera"
        self.AlignToggle=True
        #self.lights=[f'Light_1',f'Light_2','Light_3']
        self.currentL=self.lights[0]
        self.LightsCol=get_collection("Lights")
        self.execute(context)
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        return{'RUNNING_MODAL'}    


class RTOOLS_OT_updateLightIntensity(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.changelightintensity"
    bl_label = "Change Bevel Properties"
    bl_description = "Bevel Properties"
    bl_options = {'REGISTER', 'UNDO'}
    obj=None
    first=True
    initX=None
    prevIntensities=[]
    drawHandler=None
    objlist=None
    increasePercentage=None
    
    def execute(self, context):
        return {'FINISHED'}  
    def modal(self, context,event):
        self.increasePercentage=self.initX-event.mouse_x
        
        if event.type == 'MOUSEMOVE':
            p=self.increasePercentage
            #print(self.prevIntensities)
            for o,value in self.prevIntensities:
                o.data.energy =value-(p)*value/500
            context.area.tag_redraw()
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
                return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
            for o,value in self.prevIntensities:
                o.data.energy=value
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}    
    def invoke(self, context,event):
        
        
        self.obj=bpy.context.active_object
        
        self.objlist=self.obj.children
        self.prevIntensities=[]
        for o in self.objlist:
            self.prevIntensities.append((o,o.data.energy))
        self.initX=event.mouse_x 
        self.increasePercentage=self.initX-event.mouse_x
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return{'RUNNING_MODAL'} 
    def draw_callback_px(self,context):
        p=self.increasePercentage
        draw_Text(context,0,preferences().font_size,text=[f"Light Intensity : {int(-p/5)}%",])
