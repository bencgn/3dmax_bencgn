import bpy
import os
from . utils import *


class RTOOLS_OT_Add_Node(bpy.types.Operator):
    bl_idname = "rtools.addnode"
    bl_label = "Add Node"
    bl_description = "Add Selected Node To The NodeTree"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        #print(context.scene.rt_tools.nodeToAppend)
        mode=context.mode
        if context.mode!='OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.data.node_groups.get(context.scene.rt_tools.nodeToAppend) is None:
            path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
            bpy.ops.wm.append(
                    directory=path,
                    filename=context.scene.rt_tools.nodeToAppend, autoselect=True
                )
        if context.material is not None:
            mat=context.material
            Group=mat.node_tree.nodes.new('ShaderNodeGroup')
            Group.location=-550,200
            Group.name=context.scene.rt_tools.nodeToAppend
            Group.node_tree = bpy.data.node_groups.get(context.scene.rt_tools.nodeToAppend)
            #if context.scene.rt_tools.nodeToAppend=='RT_FlowMap':
            #    
            #    Group=mat.node_tree.nodes.new('ShaderNodeGroup')
            #    Group.location=-550,350
            #    Group.name="RT_FlowMap_Image"
            #    Group.node_tree = bpy.data.node_groups.get("RT_FlowMap_Image")
        if mode!='OBJECT':
            bpy.ops.object.editmode_toggle()
        return{"FINISHED"}
class RTOOLS_OT_SetUp_Flow_Map(bpy.types.Operator):
    bl_idname = "rtools.makeitflow"
    bl_label = "Make It Flow"
    bl_description = "Add Flow Map To Image"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        mat=context.material
        node=None
        Group=None
        selectedNodes=[n for n in mat.node_tree.nodes if n.select and 'Vector' in n.inputs.keys()]
        if 'RT_FlowMap' not in [n.name for n in mat.node_tree.nodes]:
            if bpy.data.node_groups.get('RT_FlowMap') is None:
                path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
                bpy.ops.wm.append(
                        directory=path,
                        filename='RT_FlowMap', autoselect=True
                    )
            Group=mat.node_tree.nodes.new('ShaderNodeGroup')
            Group.location=-550,200
            Group.name='RT_FlowMap'
            Group.node_tree = bpy.data.node_groups.get('RT_FlowMap')
        else:
            Group=mat.node_tree.nodes.get('RT_FlowMap')
        if mat is not None:
            driver=Group.node_tree.nodes['Frame_1'].outputs[0].driver_add("default_value")
            var = driver.driver.variables.new()
            var.name = "speed"
            var.targets[0].data_path = f'node_tree.nodes["{Group.name}"].inputs[1].default_value'
            var.targets[0].id_type='MATERIAL'
            var.targets[0].id = mat
            driver.driver.expression = "((frame*speed)/50)-int((frame*speed)/50)"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]
            driver=Group.node_tree.nodes['Frame_2'].outputs[0].driver_add("default_value")
            var = driver.driver.variables.new()
            var.name = "speed"
            var.targets[0].data_path = f'node_tree.nodes["{Group.name}"].inputs[1].default_value'
            var.targets[0].id_type='MATERIAL'
            var.targets[0].id = mat
            driver.driver.expression = "((frame*speed)/50+0.5)-int((frame*speed)/50+0.5)"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]
            driver=Group.node_tree.nodes['Frame_3'].outputs[0].driver_add("default_value")
            var = driver.driver.variables.new()
            var.name = "speed"
            var.targets[0].data_path = f'node_tree.nodes["{Group.name}"].inputs[1].default_value'
            var.targets[0].id_type='MATERIAL'
            var.targets[0].id = mat
            driver.driver.expression = "abs(((((frame*speed)/50)-int((frame*speed)/50))*2)-1)"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]
            for node in selectedNodes:
                initNodes=[]
                for n in mat.node_tree.nodes:
                    initNodes.append(n)
                    n.select=n==node
                if node is not None:
                    bpy.ops.node.duplicate()
                    outputSockets=[]
                    for outLinks in node.outputs[0].links:
                        outputSockets.append(outLinks.to_socket)
                    new_node=Diff(mat.node_tree.nodes,initNodes)[0]
                    
                    Group.location=node.location.x-300,node.location.y
                    new_node.location=node.location.x,node.location.y-50
                    new_node.hide=True
                    node.hide=True
                    links=mat.node_tree.links
                    links.new(Group.outputs[0],node.inputs['Vector'])
                    links.new(Group.outputs[1],new_node.inputs['Vector'])
                    mixNode=mat.node_tree.nodes.new(type='ShaderNodeMixRGB')
                    mixNode.location=node.location.x+300,node.location.y
                    mixNode.hide=True
                    links.new(node.outputs[0],mixNode.inputs[1])
                    links.new(new_node.outputs[0],mixNode.inputs[2])
                    links.new(Group.outputs[2],mixNode.inputs[0])
                    for out in outputSockets:
                        links.new(mixNode.outputs[0],out)
        return {'FINISHED'}
class RTOOLS_OT_Selected_Node_To_QAM(bpy.types.Operator):
    bl_idname = "rtools.addnodetoqam"
    bl_label = "Add Node To Quick Adjust"
    bl_description = "Add Node To Quick Material Adjust Panel"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        mat=context.material
        if mat is not None:
            node=mat.node_tree.nodes.active
        if node is not None:
            if node.type not in context.preferences.addons[__package__].preferences.nodes.split(','):
                context.preferences.addons[__package__].preferences.nodes=context.preferences.addons[__package__].preferences.nodes+","+node.type
            #print(",".join([a.name for a in node.inputs]))
            context.scene.rt_tools.socketsToAdd=",".join([a.name for a in node.inputs])
            #for socket in node.inputs:
            #    if socket.name not in context.preferences.addons[__package__].preferences.sockets.split(','):
            #        context.preferences.addons[__package__].preferences.sockets=context.preferences.addons[__package__].preferences.sockets +','+socket.name
        else:
            self.report({'INFO'},"Already Exists!")
        return {'FINISHED'}
class RTOOLS_OT_Add_Sockets_To_QAM(bpy.types.Operator):
    bl_idname = "rtools.addsocketstoqam"
    bl_label = "Add Sockets"
    bl_description = "Add Sockets To Quick Material Adjust Panel"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        for socket in context.scene.rt_tools.socketsToAdd.split(','):
            if socket not in context.preferences.addons[__package__].preferences.sockets.split(','):
                    context.preferences.addons[__package__].preferences.sockets=context.preferences.addons[__package__].preferences.sockets +','+socket
        context.scene.rt_tools.socketsToAdd=""
        return {'FINISHED'}
class RTOOLS_OT_Plug_Into_Node(bpy.types.Operator):
    bl_idname = "rtools.plugintonode"
    bl_label = "Plug Into Node"
    bl_options = {"REGISTER","UNDO"}
    socket: bpy.props.StringProperty()
    @classmethod
    def description(cls, context,properties):
        socket=bpy.app.translations.pgettext(properties.socket)
        japanese_translations=f"「{socket}」ソケットに差し込む"
        if bpy.context.preferences.view.language == "ja_JP":
            return f"{japanese_translations}\nALT+LMB: {translate_text('Do not mix even if socket is connected')}"
        return f"Plug into {socket} Socket\nALT+LMB: {translate_text('Do not mix even if socket is connected')}"
    def execute(self, context):
        node_to_mix=context.scene.node_to_mix
        n1=context.active_node
        if n1:
            output_sockets=[]
            node_tree=context.active_node.id_data
            if node_to_mix!="":
                if os.path.isfile(node_to_mix):
                    img=bpy.data.images.load(node_to_mix)
                    img.colorspace_settings.name='Non-Color'
                    img_node=node_tree.nodes.new(type='ShaderNodeTexImage')
                    img_node.hide=True
                    img_node.image=img
                    img_node.location=n1.location[0]-450,n1.location[1]
                    contrast_node=node_tree.nodes.new(type='ShaderNodeBrightContrast')
                    contrast_node.location=n1.location[0]-250,n1.location[1]
                    contrast_node.inputs[2].default_value =10 if "alpha" in self.socket.lower() else 0
                    node_tree.links.new(img_node.outputs[0],contrast_node.inputs[0])
                    node_tree.links.new(contrast_node.outputs[0],context.active_node.inputs[self.socket])

                elif node_to_mix=="EDGE_MASK":
                    if bpy.data.node_groups.get('RT_Edge_Mask') is None:
                        path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
            
        
                        bpy.ops.wm.append(
                                directory=path,
                                filename='RT_Edge_Mask', autoselect=False
                            )
                    mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                    mask_node.node_tree=bpy.data.node_groups.get('RT_Edge_Mask')
                    mask_node.location=n1.location[0]-250,n1.location[1]
                    mask_node.inputs[1].default_value=0
                    node_tree.links.new(mask_node.outputs[0],context.active_node.inputs[self.socket])
                elif node_to_mix=="WORN_EDGE_MASK":
                    if bpy.data.node_groups.get('RT_Worn_Edge_Mask') is None:
                        path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
            
        
                        bpy.ops.wm.append(
                                directory=path,
                                filename='RT_Worn_Edge_Mask', autoselect=False
                            )
                    
                    mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                    mask_node.node_tree=bpy.data.node_groups.get('RT_Worn_Edge_Mask')
                    mask_node.location=n1.location[0]-250,n1.location[1]
                    mask_node.inputs[4].default_value=0
                    node_tree.links.new(mask_node.outputs[0],context.active_node.inputs[self.socket])
                elif node_to_mix=="NOISE":

                    noise_node=node_tree.nodes.new(type='ShaderNodeTexNoise')
                    noise_node.inputs[2].default_value =2
                    noise_node.inputs[3].default_value =5
                    noise_node.inputs[4].default_value =0.8
                    noise_node.location=n1.location[0]-450,n1.location[1]
                    contrast_node=node_tree.nodes.new(type='ShaderNodeBrightContrast')
                    contrast_node.location=n1.location[0]-250,n1.location[1]
                    contrast_node.inputs[2].default_value =10 if "alpha" in self.socket.lower() else 0
                    node_tree.links.new(noise_node.outputs[0],contrast_node.inputs[0])
                    node_tree.links.new(contrast_node.outputs[0],context.active_node.inputs[self.socket])
                elif node_to_mix=="MUSGRAVE":
                    noise_node=node_tree.nodes.new(type='ShaderNodeTexMusgrave')
                    noise_node.inputs[2].default_value =2
                    noise_node.inputs[3].default_value =16
                    noise_node.inputs[4].default_value =0.2
                    noise_node.inputs[5].default_value =2
                    mathNode=node_tree.nodes.new(type="ShaderNodeMath")
                    mathNode.use_clamp=True
                    mathNode.inputs[1].default_value=0.5
                    noise_node.location=n1.location[0]-450,n1.location[1]
                    mathNode.location=n1.location[0]-250,n1.location[1]
                    node_tree.links.new(noise_node.outputs[0],mathNode.inputs[0])
                    node_tree.links.new(mathNode.outputs[0],context.active_node.inputs[self.socket])

                elif node_to_mix in [a.image.name for a in context.active_node.id_data.nodes if a.type=='TEX_IMAGE' and a.image]:
                    img_node=[a for a in context.active_node.id_data.nodes if a.type=='TEX_IMAGE' and a.image and a.image.name==node_to_mix][0]
                    img_node.location =n1.location[0]-250,n1.location[1]
                    node_tree.links.new(img_node.outputs[0],context.active_node.inputs[self.socket])
                if self.socket=='Alpha':
                    context.material.blend_method='CLIP' if context.material.blend_method=='OPAQUE' else context.material.blend_method
        return {'FINISHED'}
    def invoke(self,context,event):
        if not event.alt and context.active_node.inputs[self.socket].links and context.active_node.inputs[self.socket].links[0].from_node:
            bpy.ops.rtools.mixwithnode('INVOKE_DEFAULT',node_to_mix=context.scene.node_to_mix,node=context.active_node.inputs[self.socket].links[0].from_node.name,socket=context.active_node.inputs[self.socket].links[0].from_socket.name) 
            return {'FINISHED'}
        else:
            return self.execute(context)
node_names={'ShaderNodeInvert':['Invert',1],'ShaderNodeRGBCurve':['RGB Curves',1],'ShaderNodeValToRGB':['Color Ramp',0],'ShaderNodeMixRGB':['Mix RGB',1]}
class RTOOLS_OT_Add_Adjustment_Node(bpy.types.Operator):
    bl_idname = "rtools.addadjustmentnode"
    bl_label = "Add Node"
    #bl_description = "Mix this texture with this node\nALT+LMB: Plug this texture into this node"
    bl_options = {"REGISTER","UNDO"}
    node_type:bpy.props.StringProperty(default="")
    socket: bpy.props.IntProperty(default=0,options={'SKIP_SAVE'})
    @classmethod
    def poll(self, context):
        return context.area.type =='NODE_EDITOR' and context.active_node
    @classmethod
    def description(cls, context, properties):
        
        return "Add "+node_names[properties.node_type][0]+" Node next to this node"
    def execute(self, context):
        n1=context.active_node
        output_sockets=[]
        node_tree=context.active_node.id_data
        for out in n1.outputs:
            if out.is_linked:
                output_sockets=[a.to_socket for a in out.links]
                break
        mix_node=node_tree.nodes.new(type=self.node_type)
        node_tree.links.new(n1.outputs[0],mix_node.inputs[self.socket])
        mix_node.location=n1.location[0]+n1.width+50,n1.location[1]

        for o in output_sockets:
                node_tree.links.new(mix_node.outputs[0],o)
              
            
        return {'FINISHED'}
class RTOOLS_OT_Mix_To_Node(bpy.types.Operator):
    bl_idname = "rtools.mixwithnode"
    bl_label = "Mix With Node"
    bl_description = "Mix this texture with this node\nALT+LMB: Plug this texture into this node"
    bl_options = {"REGISTER","UNDO"}
    node_to_mix:bpy.props.StringProperty(default="")
    node: bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    socket: bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    @classmethod
    def poll(self, context):
        return context.area.type =='NODE_EDITOR' and context.active_node
    @classmethod
    def description(cls, context, properties):
        if "MATERIAL:" not in properties.node_to_mix:
            return translate_text("Mix this texture with this node\nALT+LMB: Plug this texture into this node")
        else:
            return translate_text("Mix this Material")
    def execute(self, context):
        n1=context.active_node
        if self.node!="":
            n1=context.active_node.id_data.nodes[self.node]
        socket=0
        if self.socket!="":
            socket=self.socket
        output_sockets=[]
        #print(context.active_node.id_data)
        node_tree=context.active_node.id_data
        node_to_mix=self.node_to_mix
        if node_to_mix!="":
            if os.path.isfile(node_to_mix):
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]
                img=bpy.data.images.load(node_to_mix)
                img.colorspace_settings.name='Non-Color'
                img_node=node_tree.nodes.new(type='ShaderNodeTexImage')
                img_node.hide=True
                img_node.image=img
                img_node.location=n1.location[0]-200,n1.location[1]+n1.height+200
                contrast_node=node_tree.nodes.new(type='ShaderNodeBrightContrast')
                contrast_node.location=n1.location[0],n1.location[1]+n1.height+200
                contrast_node.inputs[2].default_value =10  if any([a.name=='Alpha' for a in output_sockets]) else 0
                node_tree.links.new(img_node.outputs[0],contrast_node.inputs[0])
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'SCREEN'
                mix_node.inputs[0].default_value =1
                mix_node.hide=True
                mix_node.use_clamp=True
                node_tree.links.new(contrast_node.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100

                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif node_to_mix=="EDGE_MASK":
                if bpy.data.node_groups.get('RT_Edge_Mask') is None:
                    path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
                    bpy.ops.wm.append(
                            directory=path,
                            filename='RT_Edge_Mask', autoselect=False
                        )
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]
                mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                mask_node.node_tree=bpy.data.node_groups.get('RT_Edge_Mask')
                mask_node.location=n1.location[0],n1.location[1]+n1.height+200
                mask_node.inputs[1].default_value=0
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                node_tree.links.new(mask_node.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'SCREEN'
                mix_node.inputs[0].default_value =1
                mix_node.hide=True
                mix_node.use_clamp=True
                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif node_to_mix=="WORN_EDGE_MASK":
                if bpy.data.node_groups.get('RT_Worn_Edge_Mask') is None:
                    path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
                    bpy.ops.wm.append(
                            directory=path,
                            filename='RT_Worn_Edge_Mask', autoselect=False
                        )
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]
                
                mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                mask_node.node_tree=bpy.data.node_groups.get('RT_Worn_Edge_Mask')
                mask_node.location=n1.location[0],n1.location[1]+n1.height+200
                mask_node.inputs[4].default_value=0
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                node_tree.links.new(mask_node.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'SCREEN'
                mix_node.inputs[0].default_value =1
                mix_node.hide=True
                mix_node.use_clamp=True
                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif node_to_mix=="NOISE":
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]

                noise_node=node_tree.nodes.new(type='ShaderNodeTexNoise')
                noise_node.inputs[2].default_value =2
                noise_node.inputs[3].default_value =5
                noise_node.inputs[4].default_value =0.8
                noise_node.location=n1.location[0]-200,n1.location[1]+n1.height+200
                contrast_node=node_tree.nodes.new(type='ShaderNodeBrightContrast')
                contrast_node.location=n1.location[0],n1.location[1]+n1.height+200
                contrast_node.inputs[2].default_value =10  if any([a.name=='Alpha' for a in output_sockets]) else 0
                node_tree.links.new(noise_node.outputs[0],contrast_node.inputs[0])
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                node_tree.links.new(contrast_node.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'SCREEN'
                mix_node.inputs[0].default_value =1
                mix_node.hide=True
                mix_node.use_clamp=True
                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif node_to_mix=="MUSGRAVE":
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]

                noise_node=node_tree.nodes.new(type='ShaderNodeTexMusgrave')
                noise_node.inputs[2].default_value =2
                noise_node.inputs[3].default_value =16
                noise_node.inputs[4].default_value =0.2
                noise_node.inputs[5].default_value =2
                mathNode=node_tree.nodes.new(type="ShaderNodeMath")
                mathNode.use_clamp=True
                mathNode.inputs[1].default_value=0.5
                node_tree.links.new(noise_node.outputs[0],mathNode.inputs[0])
                noise_node.location=n1.location[0],n1.location[1]+n1.height+200
                mathNode.location=noise_node.location[0]+200,noise_node.location[1]
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                node_tree.links.new(mathNode.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+150,n1.location[1]+100
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'MIX'
                mix_node.hide=True
                mix_node.use_clamp=True
                mix_node.inputs[0].default_value =1 if any([a.name=='Alpha' for a in output_sockets]) else 0.8
                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif node_to_mix in [a.image.name for a in context.active_node.id_data.nodes if a.type=='TEX_IMAGE' and a.image]:
                for out in n1.outputs:
                    if out.is_linked:
                        output_sockets=[a.to_socket for a in out.links]
                img_node=[a for a in context.active_node.id_data.nodes if a.type=='TEX_IMAGE' and a.image and a.image.name==node_to_mix][0]
                #img_node.image=img
                #img_node.location=n1.location[0],n1.location[1]+n1.height+200
                mix_node=node_tree.nodes.new(type='ShaderNodeMixRGB')
                mix_node.blend_type='MULTIPLY' if any([a.name=='Alpha' for a in output_sockets]) else 'SCREEN'
                mix_node.inputs[0].default_value =1
                node_tree.links.new(img_node.outputs[0],mix_node.inputs[1])
                node_tree.links.new(n1.outputs[socket],mix_node.inputs[2])
                mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100
                mix_node.hide=True
                mix_node.use_clamp=True
                for o in output_sockets:
                        node_tree.links.new(mix_node.outputs[0],o)
            elif "MATERIAL:" in node_to_mix:
                context.scene.materialtomix=node_to_mix.replace("MATERIAL:","")
                bpy.ops.wm.call_menu(name="RTOOLS_MT_Material_Mix_Using_Menu")
        return {'FINISHED'}
    def invoke(self, context,event):
        if event.alt and "MATERIAL:" not in self.node_to_mix:
            context.scene.node_to_mix=self.node_to_mix
            bpy.ops.wm.call_menu(name="RTOOLS_MT_Plug_To_Socket_Menu")
            return {'FINISHED'}
        return self.execute(context)
class RTOOLS_OT_Mix_Materials(bpy.types.Operator):
    bl_idname = "rtools.mixmaterials"
    bl_label = "Mix 2 Materials"
    bl_description = "Mix 2 materials"
    bl_options = { "REGISTER", "UNDO" }

    node_to_mix: bpy.props.StringProperty( default="")


    def copy_attributes(self, attributes, old_prop, new_prop):
        for attr in attributes:
            if hasattr( new_prop, attr ):
                if attr=='parent':
                    setattr( new_prop, attr, new_prop.id_data.nodes.get(getattr( old_prop, attr ).name) if getattr( old_prop, attr ) else None)
                else:
                    setattr( new_prop, attr, getattr( old_prop, attr ))
    def get_node_attributes(self, node):
        ignore_attributes = ( "rna_type", "type", "dimensions", "inputs", "outputs", "internal_links", "select")
        attributes = []
        for attr in node.bl_rna.properties:
            if not attr.identifier in ignore_attributes and not attr.identifier.split("_")[0] == "bl" and not attr.is_readonly:
                attributes.append(attr.identifier)
        return attributes


    def copy_nodes(self, nodes, group):
        input_attributes = ( "default_value", "name" )
        output_attributes = ( "default_value", "name" )
        nodes=sorted(nodes,key =lambda x:x.type!='FRAME')
        for node in nodes:
            new_node = group.nodes.new( node.bl_idname )
            node_attributes = self.get_node_attributes( node )
            self.copy_attributes( node_attributes, node, new_node )
            if node.type!='REROUTE':
                for i, inp in enumerate(node.inputs):
                    self.copy_attributes( input_attributes, inp, new_node.inputs[i] )
                for i, out in enumerate(node.outputs):
                    self.copy_attributes( output_attributes, out, new_node.outputs[i] )


    def copy_links(self, context, nodes, group):

        for node in nodes:
            new_node = group.nodes[ node.name ]
            for i, inp in enumerate( node.inputs ):
                for link in inp.links:
                    connected_node = group.nodes[ link.from_node.name ]
                    group.links.new( connected_node.outputs[ link.from_socket.name ], new_node.inputs[i] )


    def add_group_nodes(self, group):
        group_input = group.nodes.new("NodeGroupInput")
        group_output = group.nodes.new("NodeGroupOutput")

        if len(group.nodes) > 0:
            min_pos = 9999999
            max_pos = -9999999

            for node in group.nodes:
                if node.type=='OUTPUT_MATERIAL':
                    outsocket=node.inputs[0].links[0].from_socket
                    group.nodes.remove(node)
                else:
                    if node.location[0] < min_pos:
                        min_pos = node.location[0]
                    elif node.location[0] + node.width > max_pos:
                        max_pos = node.location[0]

            group_input.location = (min_pos - 250, 0)
            group_output.location = (max_pos + 250, 0)
            group.links.new(outsocket,group_output.inputs[0])

    def execute( self, context ):
        self.material = context.scene.materialtomix
        group = bpy.data.node_groups.new( name=self.material, type="ShaderNodeTree" )
        nodes = bpy.data.materials[self.material].node_tree.nodes[:]
        self.copy_nodes( nodes, group )
        self.copy_links( context, nodes, group )
        self.add_group_nodes(group)
        node_to_mix=self.node_to_mix
        group_node=context.material.node_tree.nodes.new(type="ShaderNodeGroup")
        group_node.node_tree=group
        n1=None
        node_tree=context.material.node_tree
        for node in node_tree.nodes:
            if node.type=='OUTPUT_MATERIAL':
                n1=node.inputs[0].links[0].from_node
        if n1:
            if os.path.isfile(node_to_mix):
                img=bpy.data.images.load(node_to_mix)
                img.colorspace_settings.name='Non-Color'
                mask_node=node_tree.nodes.new(type='ShaderNodeTexImage')
                mask_node.hide=True

                mask_node.image=img
                mask_node.location=n1.location[0]-250,n1.location[1]+n1.height+400
                ramp_node=node_tree.nodes.new(type='ShaderNodeValToRGB')
                ramp_node.location=n1.location[0],n1.location[1]+n1.height+400
                ramp_node.color_ramp.elements[0].position=0.2
                ramp_node.color_ramp.elements[1].position=0.8
                node_tree.links.new(mask_node.outputs[0],ramp_node.inputs[0])
                mask_node=ramp_node
            elif node_to_mix=='EDGE_MASK':
                if bpy.data.node_groups.get('RT_Edge_Mask') is None:
                    path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
                    bpy.ops.wm.append(
                            directory=path,
                            filename='RT_Edge_Mask', autoselect=False
                        )
                mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                mask_node.node_tree=bpy.data.node_groups.get('RT_Edge_Mask')
                mask_node.location=n1.location[0],n1.location[1]+n1.height+250
                mask_node.inputs[1].default_value=0

            elif node_to_mix=='WORN_EDGE_MASK':
                if bpy.data.node_groups.get('RT_Worn_Edge_Mask') is None:
                    path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
                    bpy.ops.wm.append(
                            directory=path,
                            filename='RT_Worn_Edge_Mask', autoselect=False
                        )
                mask_node=node_tree.nodes.new(type='ShaderNodeGroup')
                mask_node.node_tree=bpy.data.node_groups.get('RT_Worn_Edge_Mask')
                mask_node.location=n1.location[0],n1.location[1]+n1.height+250
                mask_node.inputs[1].default_value=0
            elif node_to_mix=='NOISE':
                mask_node=node_tree.nodes.new(type='ShaderNodeTexNoise')
                mask_node.inputs[2].default_value =2
                mask_node.inputs[3].default_value =5
                mask_node.inputs[4].default_value =0.8
                mask_node.location=n1.location[0]-250,n1.location[1]+n1.height+250
                ramp_node=node_tree.nodes.new(type='ShaderNodeValToRGB')
                ramp_node.location=n1.location[0],n1.location[1]+n1.height+400
                ramp_node.color_ramp.elements[0].position=0.4
                ramp_node.color_ramp.elements[1].position=0.6
                node_tree.links.new(mask_node.outputs[0],ramp_node.inputs[0])
                mask_node=ramp_node
            elif node_to_mix=='MUSGRAVE':
                noise_node=node_tree.nodes.new(type='ShaderNodeTexMusgrave')
                noise_node.inputs[2].default_value =2
                noise_node.inputs[3].default_value =16
                noise_node.inputs[4].default_value =0.2
                noise_node.inputs[5].default_value =2
                mathNode=node_tree.nodes.new(type="ShaderNodeMath")
                mathNode.use_clamp=True
                mathNode.inputs[1].default_value=0.5
                node_tree.links.new(noise_node.outputs[0],mathNode.inputs[0])
                mask_node=mathNode
                noise_node.location=n1.location[0]-200,n1.location[1]+n1.height+250
                mask_node.location=n1.location[0],n1.location[1]+n1.height+250
            elif node_to_mix in [a.image.name for a in context.active_node.id_data.nodes[:]+group.nodes[:] if a.type=='TEX_IMAGE' and a.image]:
                img_name=[a.image.name for a in context.active_node.id_data.nodes[:]+group.nodes[:] if a.type=='TEX_IMAGE' and a.image and a.image.name==node_to_mix][0]
                img=bpy.data.images[img_name]
                mask_node=node_tree.nodes.new(type='ShaderNodeTexImage')
                mask_node.hide=True
                mask_node.image=img
                mask_node.location=n1.location[0]-250,n1.location[1]+n1.height+400
                ramp_node=node_tree.nodes.new(type='ShaderNodeValToRGB')
                ramp_node.location=n1.location[0],n1.location[1]+n1.height+400
                ramp_node.color_ramp.elements[0].position=0.2
                ramp_node.color_ramp.elements[1].position=0.8
                node_tree.links.new(mask_node.outputs[0],ramp_node.inputs[0])
                mask_node=ramp_node
            for out in n1.outputs:
                if out.is_linked:
                    output_sockets=[a.to_socket for a in out.links]
            
            mix_node=node_tree.nodes.new(type='ShaderNodeMixShader')
            
            node_tree.links.new(mask_node.outputs[0],mix_node.inputs[0])
            node_tree.links.new(n1.outputs[0],mix_node.inputs[2])
            node_tree.links.new(group_node.outputs[0],mix_node.inputs[1])
            for o in output_sockets:
                node_tree.links.new(mix_node.outputs[0],o)
            group_node.location=n1.location[0],n1.location[1]+150
            mix_node.location=n1.location[0]+n1.width+50,n1.location[1]+100
            mix_node.hide=True
            

        return { "FINISHED" }