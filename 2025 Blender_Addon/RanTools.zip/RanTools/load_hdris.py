

import bpy
import sys
import os
import csv
argv = sys.argv
argv = argv[argv.index("--") + 1:] 
SELECTED_FILES=argv[0].split(":--separator--:") if argv[0]!="None" else None
TAGS=argv[1]
__DIRNAME__ = os.path.dirname(os.path.dirname(__file__))
context = bpy.context
scene = context.scene
def get_quality(name):
    name=name.lower()
    if name:
        if "1k" in name or "1024" in name:
            return "1k", 1
        elif "2k" in name or "2048" in name:
            return "2k", 2
        elif "4k" in name or "4096" in name:
            return "4k", 4
        elif "8k" in name or "8192" in name:
            return "8k", 8
        elif "6k" in name or "6144" in name:
            return "6k", 6
        elif "12k" in name:
            return "12k", 12
        elif "16k" in name:
            return "16k", 16
    return "", 4
if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt")):
        f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                              "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='w+', newline='', encoding='utf-8')
        f.close()
for f in SELECTED_FILES:
    name=os.path.splitext(os.path.basename(f))[0]
    print("Loading:",name)
    quality=get_quality(name)[0]
    file_type=os.path.splitext(os.path.basename(f))[1].lower().replace(".","")
    quality=quality+"-"+file_type
    name=name.replace(quality,"").replace("_","")
    size=os.path.getsize(f)
    image=bpy.data.images.load(f)
    preview_image=image.copy()
    preview_image.scale(800,400)
    preview_path=os.path.join( __DIRNAME__, 'RanTools-Previews', name+".png")
    preview_image.save_render(preview_path, scene=None)
    #print(preview_image.name)
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes", "Dowloaded-HDRIs.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                            csvFileWriter = csv.writer(
                                csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                            
                            csvFileWriter.writerow(
                                [name, quality+f"({round(size / (1024 * 1024), 2)} MB)", f, TAGS])
