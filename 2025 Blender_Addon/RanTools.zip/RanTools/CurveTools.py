import bpy
from .utils import *
import bmesh
from bpy_extras import view3d_utils
import gpu
import bgl
from gpu_extras.batch import batch_for_shader
def curve_coords(start,end,normal1,normal2):
    p1_translate=normal1*0.5
    p2_translate=normal2*0.5
    points=[]
    midpoint=[(start[0]+end[0])/2,(start[1]+end[1])/2,(start[2]+end[2])/2]
    points.append(start)
    points.append([(midpoint[0]+start[0])/2,(midpoint[1]+start[1])/2,(midpoint[2]+start[2])/2])
    points.append([(midpoint[0]+end[0])/2,(midpoint[1]+end[1])/2,(midpoint[2]+end[2])/2])
    #points.append([(midpoint[0]+start[0])/2+p1_translate[0],(midpoint[1]+start[1])/2+p1_translate[1],(midpoint[2]+start[2])/2+p1_translate[2]])
    #points.append([(midpoint[0]+end[0])/2+p2_translate[0],(midpoint[1]+end[1])/2+p2_translate[1],(midpoint[2]+end[2])/2+p2_translate[2]])
    
    points.append(end)
    #print(points)
    return points
def hookCurve(o1, o2,o3 ,curve,curve_type='NURBS'):
    

    m0 = curve.modifiers.new("RT_CableHook_1", 'HOOK')
    m0.object = o2
    m0.show_in_editmode=True
    m1 = curve.modifiers.new("RT_CableHook_2", 'HOOK')
    m1.object = o1
    m1.show_in_editmode=True
    if curve_type=='NURBS':
        m2 = curve.modifiers.new("RT_CableHook_3", 'HOOK')
        m2.object = o3
        m2.show_in_editmode=True
    deselect_all()
    og_hide_view=curve.hide_get()
    curve.hide_view=False
    select(curve)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='DESELECT')

    if curve_type=='NURBS':
        for p in curve.data.splines[0].points[-3:]:
            p.select=True
        bpy.ops.object.hook_assign(modifier="RT_CableHook_1")
        for p in curve.data.splines[0].points[-3:]:
            p.select=False
        for p in curve.data.splines[0].points[:3]:
            p.select=True
        bpy.ops.object.hook_assign(modifier="RT_CableHook_2")
        for p in curve.data.splines[0].points[:3]:
            p.select=False
        for p in curve.data.splines[0].points[3:-3]:
            p.select=True
        bpy.ops.object.hook_assign(modifier="RT_CableHook_3")
        #o1.hide_view=True
        #o2.hide_view=True
    else:
        for p in curve.data.splines[0].bezier_points[-1:]:
            p.select_control_point=True
            p.select_right_handle=True
            p.select_left_handle=True
        bpy.ops.object.hook_assign(modifier="RT_CableHook_1")
        for p in curve.data.splines[0].bezier_points[-1:]:
            p.select_control_point=False
            p.select_right_handle=False
            p.select_left_handle=False
        for p in curve.data.splines[0].bezier_points[:1]:
            p.select_control_point=True
            p.select_right_handle=True
            p.select_left_handle=True
        bpy.ops.object.hook_assign(modifier="RT_CableHook_2")
    bpy.ops.object.mode_set(mode='OBJECT')
    curve.hide_view=og_hide_view
def nurbs(context,locA,locB,normals,startLength,ob1,ob2,curve_type='NURBS',start_strength=6):
    a1=locA+(normals[0]*startLength)*start_strength
    a2=locB+(normals[1]*startLength)*start_strength
    a3=locA+(normals[0]*startLength/2)
    a4=locB+(normals[1]*startLength/2)
    a5=locA-(normals[0]*startLength)
    a6=locB-(normals[1]*startLength)
    coords=curve_coords(a1,a2,normals[0],normals[1])
    meanX=(coords[1][0] +coords[2][0])/2
    meanY=(coords[1][1] +coords[2][1])/2
    meanZ=(coords[1][2] +coords[2][2])/2
    curveData = bpy.data.curves.new('myCurve', type='CURVE')
    curveData.dimensions = '3D'
    if curve_type=='BEZIER':
        curveData.resolution_u=84
    curveData.bevel_resolution=12
    polyline = curveData.splines.new(curve_type)
    polyline.use_endpoint_u=True
    points=[a5,a2]
    points2=[a1,a6]
    if curve_type=='NURBS':
        coords=[locA,a3]+coords+[a4,locB]
    else:
        coords=[locA,locB]
    if curve_type=='NURBS':
        polyline.points.add(len(coords)-1)
    else:
        polyline.bezier_points.add(len(coords)-1)
    for i, coord in enumerate(coords):
        x,y,z = coord
        if curve_type=='NURBS':
            polyline.points[i].co = (x, y, z, 1)
        else:
            polyline.bezier_points[i].co = (x, y, z)
            polyline.bezier_points[i].handle_left_type='ALIGNED'
            #polyline.bezier_points[i].handle_right_type='ALIGNED'
            polyline.bezier_points[i].handle_left=points[i]
            polyline.bezier_points[i].handle_right=points2[i]
    #if curve_type!='NURBS':
   #     polyline.bezier_points[1].handle_left_type='AUTO'
   #     polyline.bezier_points[1].handle_right_type='AUTO'
    polyline.order_u=4
    # create Object
    curveOB = bpy.data.objects.new('RT_Curve', curveData)
    curveData.bevel_depth = 0.04
    bpy.context.collection.objects.link(curveOB)
    #move_object_to_collection(curveOB,col="Collection")
    #ob1.location=locA
    #ob2.location=locB
    bpy.ops.object.select_all(action='DESELECT')
    ob3=None
    if curve_type=='NURBS':
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(meanX,meanY,meanZ), scale=(1, 1, 1))
        context.active_object.empty_display_size=0.05
        context.active_object.empty_display_type='SPHERE'
        ob3=context.active_object
        ob3.location=(meanX,meanY,meanZ)
        ob3.show_in_front=True
    
    
    #ob1.show_in_front=True
    #ob2.show_in_front=True
    select(curveOB)
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
    select(ob1)
    select(ob2)
    if curve_type=='NURBS':
        select(ob3)
    select(curveOB)
    if curve_type=='NURBS':
        curveObjects=[curveOB,ob1,ob2,ob3]
    else:
        curveObjects=[curveOB,ob1,ob2]
    bpy.ops.object.parent_set(type='OBJECT', keep_transform=False)
    
    hookCurve(ob1,ob2,ob3, curveOB,curve_type=curve_type)
    bpy.ops.object.select_all(action='DESELECT')
        
    if curve_type=='NURBS':
        select(ob3)
    rt_curves=get_collection("RT_Curves")
    move_objects_to_collection(curveObjects,col=rt_curves)
    ob1.hide_view=True
    ob2.hide_view=True
    if curve_type!='NURBS':
        select(curveOB,active=True)
    return curveOB
class RTOOLS_OT_Create_Cable(bpy.types.Operator):
    bl_idname = "rtools.createcable"
    bl_label = "Create Cable"
    bl_description = "Create Cable Between 2 Points"
    bl_options = {"REGISTER","UNDO"}
    startLen:bpy.props.FloatProperty(default=0.2,options={'HIDDEN'})
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()   
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"Hold SHIFT: Snap To Face Bounding Box Center",f"Hold CTRL: Snap To Face Center",f"C : Type ({self.curve_type})"],alignH="RIGHT",activeKey=self.activeKey)
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def execute(self, context):
        
        if self.clickCount<=2:
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = self.X,self.Y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            #print(location)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH')):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_view=True
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_view=s
            self.normals.append(normal)
            bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            empty=context.active_object
            empty.empty_display_size=0.1
            empty.empty_display_type='CUBE'
            z = Vector((0,0,1))
            if normal!=Vector((0,0,0)):
                rot = z.rotation_difference( normal ).to_euler()
                empty.rotation_euler= rot
            self.empties.append(empty)
            if object is not None:
                if not self.event.ctrl and not self.event.shift or object.type!='MESH':
                    empty.location =location
                else:
                    depsgraph = bpy.context.evaluated_depsgraph_get()
                    depsgraph.update()
                    object=object.evaluated_get(depsgraph)
                    bm= bmesh.new()
                    bm.from_mesh(object.data)
                    bm.faces.ensure_lookup_table()
                    
                    if self.event.shift:
                        empty.location = object.matrix_world@bm.faces[index].calc_center_bounds()
                    else:
                        empty.location = object.matrix_world@bm.faces[index].calc_center_median_weighted()
                    bm.free()
                    
                    #
            if self.clickCount==2:
                curve=nurbs(context,self.empties[0].location-(self.normals[0]*0.03),self.empties[1].location-(self.normals[1]*0.03),self.normals,self.startLen,self.empties[0],self.empties[1],curve_type=self.curve_type,start_strength=1 if self.curve_type=='NURBS' else 3)
                if self.curve_type=='BEZIER':
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.curve.select_all(action='SELECT')
                    #bpy.ops.curve.subdivide()
                    bpy.ops.object.editmode_toggle()
                bpy.context.space_data.overlay.show_relationship_lines = False
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                context.area.tag_redraw()
                self.remove_drawHandler(context)
                select(curve)
                bpy.ops.rtools.curveadjust('INVOKE_DEFAULT')
                
                return {'FINISHED'}
            
        return {'RUNNING_MODAL'}
    def modal(self,context,event):
        if event.type == 'C':
            if event.value == 'PRESS':
                self.curve_type='NURBS' if self.curve_type!='NURBS' else 'BEZIER'
                self.activeKey='C'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and (not event.alt if preferences().industry_keymap else True):
            
            self.event=event
            self.X=event.mouse_region_x
            self.Y=event.mouse_region_y
            self.clickCount+=1
            context.area.tag_redraw()
            return self.execute(context)
            
        if event.type=='MOUSEMOVE':
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH')):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_view=True
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_view=s
            if object is not None and object.type=='MESH':
                obj=object
                obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                bm.faces.ensure_lookup_table()
                coords = [obj.matrix_world@v.co for v in bm.verts]
                indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges if e in bm.faces[index].edges] 
                self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
                self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
            else:
                self.batch = None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS') or event.type=='ESC':
            for empty in self.empties:
                delete_object(empty)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            self.remove_drawHandler(context)
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
        #return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.activeKey=None
        self.curve_type=context.scene.rt_tools.default_curve_type
        bpy.context.scene.tool_settings.snap_elements = {'FACE'}
        bpy.context.scene.tool_settings.use_snap_align_rotation = True
        #bpy.context.space_data.show_region_ui = True
        bpy.ops.wm.tool_set_by_id(name="builtin.select")
        bpy.context.window.cursor_set("CROSSHAIR")
        self.normals=[]
        self.obj=context.active_object
        self.center=False
        self.empties=[]
        self.clickCount=0
        context.window_manager.modal_handler_add(self)
        self.shader=None
        self.batch=None
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(4)
                gpu.state.blend_set("ALPHA") 
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                self.shader.bind()
                self.shader.uniform_float("color", (0.8, 0, 0, 0.6))
                self.batch.draw(self.shader)
                gpu.state.blend_set("NONE") 
                #bgl.glDisable(bgl.GL_LINE_SMOOTH)
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        self.add_drawHandler(context)
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Edge_To_Curve(bpy.types.Operator):
    bl_idname = "rtools.edgetocurve"
    bl_label = "Edge To Curve"
    bl_description = "Convert Selected Edges To Curves"
    bl_options = {"REGISTER","UNDO"}
    depth:bpy.props.FloatProperty(default=0.02,name="Depth",min=0)
    resolution:bpy.props.IntProperty(default=8,name="Resolution",min=0)
    offset:bpy.props.FloatProperty(default=0,name="Offset")
    doBevel:bpy.props.BoolProperty(default=False,name="Bevel")
    bevel:bpy.props.FloatProperty(default=0.1,name="Width",min=0)
    bevelSegments:bpy.props.IntProperty(default=4,name="Segments",min=2)
    
    @classmethod
    def poll(cls, context):
        return  context.active_object is not None and context.active_object.type in {'CURVE','MESH'}
    def execute(self, context):
        if context.mode!="EDIT_MESH":
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='SELECT')
            #self.report({'WARNING'},'Mesh Needs To Be In Edit Mode')
            #return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.duplicate_move()
        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.editmode_toggle()
        obj=Diff(context.selected_objects,[context.active_object])[0]
        bpy.ops.object.select_all(action='DESELECT')
        select(obj,active=True)
        if self.doBevel:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.dissolve_limited()
            bpy.ops.mesh.bevel(offset=self.bevel, offset_pct=0, segments=self.bevelSegments, affect='VERTICES')
            bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.ops.object.convert(target='CURVE')
        if context.active_object.type=='CURVE':
            self.curveData=obj.data
            self.curveData.bevel_depth=self.depth
            self.curveData.bevel_resolution=self.resolution
            self.curveData.offset=self.offset
        else:
            self.report({'WARNING'},"Could not convert to Curve!")
        return {'FINISHED'}

class RTOOLS_Edit_Child_Curve(bpy.types.Operator):
    bl_idname = "rtools.editchildcurve"
    bl_label = "Edit Child Curve"
    bl_description = "Make child curve visible and enter edit mode"
    bl_options = {"REGISTER","UNDO"}
    name:bpy.props.StringProperty()
    def invoke(self, context,event):
        obj=context.scene.objects[self.name]
        select(obj)
        if obj is not None:
            if event.shift:
                for m in obj.modifiers:
                    if m.type=="HOOK" and m.name=='RT_CableHook_3':
                        empty=m.object
                        bpy.ops.object.modifier_apply(modifier=m.name)
                        delete_object(empty)
            elif event.ctrl:
                for m in obj.modifiers:
                    if m.type=="HOOK":
                        empty=m.object
                        bpy.ops.object.modifier_apply(modifier=m.name)
                        delete_object(empty)
            bpy.ops.object.select_all(action='DESELECT')
            obj.hide_view=False
            
            bpy.ops.object.editmode_toggle()
            bpy.ops.wm.tool_set_by_id(name="builtin.select")
        return {'FINISHED'}
class RTOOLS_OT_Draw_Curve(bpy.types.Operator):
    bl_idname = "rtools.drawcurve"
    bl_label = "Draw Curves/Cables"
    bl_description = "Draw Curves on Surface Of Objects"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def execute(self, context):
        bpy.ops.curve.primitive_bezier_curve_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        curve=context.active_object
        curve.data.bevel_depth=0.02
        bpy.ops.object.editmode_toggle()
        #bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.delete(type='VERT')
        bpy.context.scene.tool_settings.curve_paint_settings.depth_mode = 'SURFACE'
        bpy.context.scene.tool_settings.curve_paint_settings.surface_offset = 0.02
        bpy.context.scene.tool_settings.curve_paint_settings.use_offset_absolute = True

        bpy.context.scene.tool_settings.curve_paint_settings.use_corners_detect = False

        bpy.ops.wm.tool_set_by_id(name="builtin.draw")
        return {'FINISHED'}
class Test6(bpy.types.Operator):
    bl_idname = "rtools.test3"
    bl_label = "My Class Name"
    bl_description = "Description that shows in blender tooltips"
    bl_options = {"REGISTER","UNDO"}
    def execute(self, context):
        #bpy.ops.mesh.duplicate_move()
            
        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.editmode_toggle()
        obj=Diff(context.selected_objects,[context.active_object])[0]
        bpy.ops.object.select_all(action='DESELECT')
        select(obj,active=True)
        bpy.ops.object.convert(target='CURVE')
        self.curveData=obj.data
        self.curveData.bevel_depth=0.02
        self.bevelCopy= self.curveData.bevel_depth
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def modal(self, context, event):
        if event.type == 'LEFT_SHIFT':
            self.initX=event.mouse_x
            self.bevelCopy=self.curveData.bevel_depth
            if event.value == 'PRESS':
                self.speed=30
            elif event.value == 'RELEASE':
                self.speed=2 
        elif event.type == 'LEFT_CTRL':
            if event.value == 'PRESS':
                self.speed=0.5
            elif event.value == 'RELEASE':
                self.speed=2   
            self.bevelCopy=self.curveData.bevel_depth
            self.initX=event.mouse_x
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type =='MOUSEMOVE':
            self.curveData.bevel_depth=self.bevelCopy-(self.initX-event.mouse_x)/(10*self.speed)
        elif (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            self.curveData.bevel_resolution+=1
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            self.curveData.bevel_resolution-=1
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and (not event.alt if preferences().industry_keymap else True):
            return {'FINISHED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        bpy.ops.object.mode_set(mode='EDIT')
        self.initX=event.mouse_x
        self.speed=10
        return self.execute(context)
class RTOOLS_OT_Multiple_Wires(bpy.types.Operator):
    bl_idname = "rtools.createmultiplewires"
    bl_label = "Multiple Wires"
    bl_description = "Convert Curve To Multiple Wires"
    bl_options = {"REGISTER","UNDO"}
   # startLen:bpy.props.FloatProperty(default=0.2)
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"Count: {self.countMod.count}",f"Radius: {format(round(self.radiusMod.strength,2),'.2f')}" if self.wire.wire_type=='Radial' else f"Offset: {format(round(self.wire.wire_parallel_offset,2),'.2f')}",f"Strand Radius: {format(round(self.strandradiusMod.strength+0.01,2),'.2f')}",f"Twist: {format(round(eulerToDegreeS(self.twistMod.angle),2),'.2f')}"])
        draw_Text(context,0,preferences().font_size,text=["R : Strand Radius",f"W: {'Radius' if self.wire.wire_type=='Radial' else 'Offset'}",f"T : Twist",f'X : Wire Axis({self.wire.wire_axis})' if self.wire.wire_type=='Parallel' else "",f'S : Wire Type ({self.wire.wire_type})',f"{self.adjustMode} Adjust Mode"],alignH="LEFT",activeKey=self.activeKey)
    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type =='CURVE'
    def execute(self, context):
        curve=context.active_object
        self.curve_bevel_depth=curve.data.bevel_depth
        curve.data.bevel_depth=0
        self.curve=curve
        bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        plane=context.active_object
        plane.scale=(0.001,0.001,0.001)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        arrayMod=plane.modifiers.new(type="ARRAY",name="RT_Temp")
        arrayMod.fit_type="FIT_CURVE"
        arrayMod.curve=curve
        bpy.ops.object.modifier_apply(modifier=arrayMod.name)
        wire_length=plane.dimensions[0]
        delete_object(plane)
        bpy.ops.object.select_all(action='DESELECT')
        path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","Object")
        
        bpy.ops.wm.append(
            directory=path,
            filename="RT_Wire", autoselect=True
        )
        wire=context.selected_objects[0]
        wire.wire_type='Radial'
        self.wire=wire
        for c in wire.children:
            if "Empty" in c.name:
                c.hide_view=True
        if wire.modifiers.get("RT_WIRE_LENGTH_ARRAY") is not None:
            wire.modifiers.get("RT_WIRE_LENGTH_ARRAY").curve=curve
        self.lengthMod=wire.modifiers.get("RT_WIRE_LENGTH")
        if self.lengthMod is not None:
            self.lengthMod.screw_offset=wire_length+0.04
        self.strandradiusMod=wire.modifiers.get("RT_STRAND_RADIUS")
        self.radiusMod=wire.modifiers.get("RT_WIRE_RADIUS")
        self.parallelDisplaceMod=wire.modifiers.get("RT_PARALLEL_WIRE_DISPLACE")
        self.countMod=wire.modifiers.get("RT_WIRE_COUNT")

        self.twistMod=wire.modifiers.get("RT_WIRE_TWIST")
        select(curve)
        wire.location=curve.location
        
        self.displaceMod=wire.modifiers.new(type="DISPLACE",name="RT_CurveDisplace")
        self.displaceMod.mid_level=0
        self.displaceMod.direction='Z'
        self.displaceMod.strength=-0.02
        self.curveMod=wire.modifiers.new(type="CURVE",name="RT_POC_Curve")
        self.curveMod.object=curve
        self.curveMod.deform_axis='POS_Z'
        self.radiusCopy=self.radiusMod.strength
        self.twistCopy=self.twistMod.angle
        self.offsetCopy=self.wire.wire_parallel_offset
        select(wire)
        return bpy.ops.rtools.curveadjust('INVOKE_DEFAULT')
        #self.add_drawHandler(context)
        #context.window_manager.modal_handler_add(self)
        #return {'RUNNING_MODAL'}
    def modal(self, context, event):
        self.activeKey=f"{'SHIFT+' if event.shift else ''}{'CTRL+' if event.ctrl else ''}{event.type}"
        
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            self.initX=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.initX=context.region.width
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        if event.type == 'LEFT_SHIFT':
            self.initX=event.mouse_x
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            if event.value == 'PRESS':
                self.speed=100
            elif event.value == 'RELEASE':
                self.speed=30 
        if event.type == 'LEFT_CTRL':
            self.initX=event.mouse_x
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            if event.value == 'PRESS':
                self.speed=10
            elif event.value == 'RELEASE':
                self.speed=30 
        if event.type =='MOUSEMOVE':
            if self.adjustMode=="Radius":
                if self.wire.wire_type=='Radial':
                    if self.radiusMod is not None and self.radiusCopy is not None:
                        self.radiusMod.strength=self.radiusCopy-(self.initX-event.mouse_x)/(10*self.speed)
                else:
                    if self.offsetCopy is not None:
                        self.wire.wire_parallel_offset=self.offsetCopy-(self.initX-event.mouse_x)/(10*self.speed)
            elif self.adjustMode=="Twist":
                if self.twistMod is not None and self.twistCopy is not None:
                    self.twistMod.angle=self.twistCopy-(self.initX-event.mouse_x)/(10*self.speed)
            elif self.adjustMode=="Strand Radius":
                if self.strandradiusMod is not None and self.strandradiusCopy is not None:
                    self.strandradiusMod.strength=self.strandradiusCopy-(self.initX-event.mouse_x)/(10*self.speed)
        elif (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            self.countMod.count+=1
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            self.countMod.count-=1
        elif event.type =='S' and event.value=='PRESS':
            self.wire.wire_type='Radial' if self.wire.wire_type!='Radial' else 'Parallel'
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        elif event.type =='X' and event.value=='PRESS':
            self.wire.wire_axis='X' if self.wire.wire_axis!='X' else 'Y'
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        elif event.type =='R':
            self.adjustMode="Strand Radius"
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            self.initX=event.mouse_x
        elif event.type =='T':
            self.adjustMode="Twist"
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            self.initX=event.mouse_x
        elif event.type =='W':
            self.adjustMode="Radius"
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
            self.initX=event.mouse_x
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and (not event.alt if preferences().industry_keymap else True):
            if self.curve is not None:
                
                bpy.ops.object.select_all(action='DESELECT')
                
                rt_wires=get_collection("RT_Wires")
                move_to_collection(self.curve,rt_wires)
                move_to_collection(self.wire,rt_wires)
                select(self.curve)
                for c in self.curve.children:
                    move_to_collection(c,rt_wires)
                    #select(c)
                for c in self.wire.children:
                    move_to_collection(c,rt_wires)
                    c.hide_view=True
                select(self.wire)
                
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=False)
                self.curve.hide_view=True
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC' and event.value == 'PRESS' :
            if self.curve:
                self.curve.data.bevel_depth=self.curve_bevel_depth
            if self.wire:
                delete_object_with_data(self.wire)
            self.remove_drawHandler(context)
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.curve_bevel_depth=0
        self.activeKey=None
        self.initX=event.mouse_x
        self.speed=30
        self.adjustMode="Radius"
        self.radiusCopy=None
        self.twistCopy=None
        self.offsetCopy=None
        self.radiusMod=None
        self.twistMod=None
        self.countMod=None
        self.strandradiusMod=None
        self.strandradiusCopy=None
        
        return self.execute(context)
class RTOOLS_OT_Curve_Adjust_Modal(bpy.types.Operator):
    bl_idname = "rtools.curveadjust"
    bl_label = "Curve Adjust"
    bl_description = "Manipulate curve in a modal operator"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        if self.tensionAvailable:
            if self.tensionA and not self.tensionB:
                tensionAdjustMode='A'
            elif self.tensionB and not self.tensionA:
                tensionAdjustMode='B'
            else:
                tensionAdjustMode='Both'
            if self.wire:
                draw_Text(context,0,preferences().font_size,text=[f"X : Select Empty B" if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object else '',f"Z : Select Empty A" if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object else '',f"O : Cap Offset ({round(self.curve.Caps[0].obj.location[2],2)})" if len(self.curve.Caps)>0 else '',f"U : Cap Scale ({round(self.curve.Caps[0].obj.scale[0],2)})" if len(self.curve.Caps)>0 else "",f"Caps : {self.capName}",f"C : Cap Picker ({'ON' if self.capPickMode else 'OFF'})",f"B : Separation",f"Y : Drip" if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object else "",f"G : Axis ({self.wire.wire_axis})" if self.wire.wire_type=='Parallel' else '',f"F : Wire Type ({self.wire.wire_type})",f"E : {'Offset' if self.wire.wire_type=='Parallel' else 'Wire Radius' }",f"V : Twist ({round(math.degrees(self.twistMod.angle),2)})",f"W : Tilt B",f"Q : Tilt A",f"A/S/D: Tension Adjustment ({tensionAdjustMode})" if self.tensionAvailable else '',f"T : Tension ({round(self.tension1,3)})" if self.tensionAvailable else '',f"R: Strand Radius ({round(self.strandradiusMod.strength,3)})",f"Count : {self.countMod.count}"],alignH="LEFT",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
            else:
                draw_Text(context,0,preferences().font_size,text=[f"X : Select Empty B" if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object else '',f"Z : Select Empty A" if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object else '',f"O : Cap Offset ({round(self.curve.Caps[0].obj.location[2],2)})" if len(self.curve.Caps)>0 else '',f"U : Cap Scale ({round(self.curve.Caps[0].obj.scale[0],2)})" if len(self.curve.Caps)>0 else "",f"Caps : {self.capName}",f"C : Cap Picker ({'ON' if self.capPickMode else 'OFF'})",f"B : Separation",f"Y : Drip" if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object else "",f"F : Fill ({self.curve.data.use_fill_caps})",f"E: Extrude ({round(self.curve.data.extrude,3)})",f"W : Tilt B",f"Q : Tilt A",f"A/S/D: Tension Adjustment ({tensionAdjustMode})" if self.tensionAvailable else '',f"T : Tension ({round(self.tension1,3)})" if self.tensionAvailable else '',f"R: Radius ({round(self.curve.data.bevel_depth,3)})",f"CTRL + Scroll : Resolution ({self.curve.data.resolution_u})"],alignH="LEFT",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
        else:
            if self.wire:
                draw_Text(context,0,preferences().font_size,text=[f"X : Select Empty B" if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object else '',f"Z : Select Empty A" if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object else '',f"O : Cap Offset ({round(self.curve.Caps[0].obj.location[2],2)})" if len(self.curve.Caps)>0 else '',f"U : Cap Scale ({round(self.curve.Caps[0].obj.scale[0],2)})" if len(self.curve.Caps)>0 else "",f"Caps : {self.capName}",f"C : Cap Picker ({'ON' if self.capPickMode else 'OFF'})",f"Y : Drip" if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object else "",f"G : Axis ({self.wire.wire_axis})" if self.wire.wire_type=='Parallel' else '',f"F : Wire Type ({self.wire.wire_type})",f"E : {'Offset' if self.wire.wire_type=='Parallel' else 'Wire Radius' }",f"V : Twist ({round(math.degrees(self.twistMod.angle),2)})",f"W : Tilt B",f"Q : Tilt A",f"R: Strand Radius ({round(self.strandradiusMod.strength,3)})",f"Count : {self.countMod.count}"],alignH="LEFT",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
            else:
                draw_Text(context,0,preferences().font_size,text=[f"X : Select Empty B" if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object else '',f"Z : Select Empty A" if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object else '',f"O : Cap Offset ({round(self.curve.Caps[0].obj.location[2],2)})" if len(self.curve.Caps)>0 else '',f"U : Cap Scale ({round(self.curve.Caps[0].obj.scale[0],2)})" if len(self.curve.Caps)>0 else "",f"Caps : {self.capName}",f"C : Cap Picker ({'ON' if self.capPickMode else 'OFF'})",f"Y : Drip" if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object else "",f"F : Fill ({self.curve.data.use_fill_caps})",f"E: Extrude ({round(self.curve.data.extrude,3)})",f"W : Tilt B",f"Q : Tilt A",f"R: Radius ({round(self.curve.data.bevel_depth,3)})",f"CTRL + Scroll : Resolution ({self.curve.data.resolution_u})"],alignH="LEFT",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
    def tensionAdjust(self,curve,tension1,tension2,ogTension1,ogTension2,tension1direction,tension2direction,oglocation1,oglocation2,oglocation3,oglocation4,):
        if curve.data.splines[0].type=='BEZIER':
            curve.data.splines[0].bezier_points[0].handle_right=-(tension1*tension1direction)+oglocation1
            curve.data.splines[0].bezier_points[-1].handle_left=+(tension2*tension2direction)+oglocation2
            if len(self.curve.data.splines[0].bezier_points)==3:
                curve.data.splines[0].bezier_points[1].co=-((self.initLocation1-curve.data.splines[0].bezier_points[0].handle_right)+(self.initLocation2-curve.data.splines[0].bezier_points[-1].handle_left))/2+self.initLocation3
                curve.data.splines[0].bezier_points[1].handle_left=-((self.initLocation1-curve.data.splines[0].bezier_points[0].handle_right)+(self.initLocation2-curve.data.splines[0].bezier_points[-1].handle_left))/2+self.initLocation4
                curve.data.splines[0].bezier_points[1].handle_right=-((self.initLocation1-curve.data.splines[0].bezier_points[0].handle_right)+(self.initLocation2-curve.data.splines[0].bezier_points[-1].handle_left))/2+self.initLocation5
            self.location1=self.curve.data.splines[0].bezier_points[0].handle_right.copy()
            self.location2=self.curve.data.splines[0].bezier_points[-1].handle_left.copy()
        else:
            curve.data.splines[0].points[2].co=Vector(((tension1*tension1direction)[0],(tension1*tension1direction)[1],(tension1*tension1direction)[2],1))+oglocation1
            curve.data.splines[0].points[5].co=Vector(((tension2*tension2direction)[0],(tension2*tension2direction)[1],(tension2*tension2direction)[2],1))+oglocation2
            curve.data.splines[0].points[3].co=Vector(((tension1*tension1direction)[0],(tension1*tension1direction)[1],(tension1*tension1direction)[2],1))+oglocation3
            curve.data.splines[0].points[4].co=Vector(((tension2*tension2direction)[0],(tension2*tension2direction)[1],(tension2*tension2direction)[2],1))+oglocation4
            self.location1=self.curve.data.splines[0].points[2].co.copy()
            self.location2=self.curve.data.splines[0].points[5].co.copy()
            #print((tension2*tension2direction)+oglocation2,curve.matrix_world@curve.data.splines[0].bezier_points[1].handle_left)
            #print((tension1*tension1direction)+oglocation1,curve.matrix_world@curve.data.splines[0].bezier_points[0].handle_right,tension2*tension2direction,curve.data.splines[0].bezier_points[1].handle_left)
            #print((tension1*tension1direction),oglocation1,(tension1*tension1direction)+oglocation1,(tension2*tension2direction),oglocation2,(tension2*tension2direction)+oglocation2)
    def separationAdjust(self,curve):
        if curve.data.splines[0].type=='BEZIER':
            direction=(self.initLocation1-self.initLocation2).normalized()
            curve.data.splines[0].bezier_points[0].handle_right=(self.separation*direction)+self.location1
            curve.data.splines[0].bezier_points[-1].handle_left=-(self.separation*direction)+self.location2
            self.tension1direction=(self.curve.data.splines[0].bezier_points[0].co-self.curve.data.splines[0].bezier_points[0].handle_right).normalized()
            self.tension2direction=-(self.curve.data.splines[0].bezier_points[-1].co-self.curve.data.splines[0].bezier_points[-1].handle_left).normalized()
            self.tension1direction=Vector((round(self.tension1direction[0],4),round(self.tension1direction[1],4),round(self.tension1direction[2],4)))
            self.tension2direction=Vector((round(self.tension2direction[0],4),round(self.tension2direction[1],4),round(self.tension2direction[2],4)))
            self.tension1= (self.curve.data.splines[0].bezier_points[0].co-self.curve.data.splines[0].bezier_points[0].handle_right).length
            self.tension2=(self.curve.data.splines[0].bezier_points[-1].co-self.curve.data.splines[0].bezier_points[-1].handle_left).length
        else:
            direction=(self.initLocation1-self.initLocation2).normalized()
            curve.data.splines[0].points[2].co=(self.separation*direction)+self.location1
            curve.data.splines[0].points[5].co=-(self.separation*direction)+self.location2
            self.tension1=(self.curve.data.splines[0].points[1].co-self.curve.data.splines[0].points[2].co).resized(3).length
            self.tension2=(self.curve.data.splines[0].points[5].co-self.curve.data.splines[0].points[6].co).resized(3).length
            self.tension1direction=-(self.curve.data.splines[0].points[1].co-self.curve.data.splines[0].points[2].co).normalized()
            self.tension2direction=(self.curve.data.splines[0].points[5].co-self.curve.data.splines[0].points[6].co).normalized()
            self.tension1direction=Vector((round(self.tension1direction[0],4),round(self.tension1direction[1],4),round(self.tension1direction[2],4)))
            self.tension2direction=Vector((round(self.tension2direction[0],4),round(self.tension2direction[1],4),round(self.tension2direction[2],4)))
            #curve.data.splines[0].bezier_points[0].handle_right=Vector((2,2,2))
            #curve.data.splines[0].bezier_points[-1].handle_left=Vector((2,2,2))
            #print(curve.data.splines[0].bezier_points[0].handle_left,curve.data.splines[0].bezier_points[-1].handle_left)
    def saveState(self, context):
        self.radiusCopy=self.curve.data.bevel_depth
        self.extrudeCopy=self.curve.data.extrude
        self.separationCopy=self.separation
        if self.tensionAvailable:
            self.tension1Copy=self.tension1
            self.tension2Copy=self.tension2
            if self.curve.data.splines[0].type=='BEZIER':
                self.tilt1Copy=self.curve.data.splines[0].bezier_points[0].tilt
                self.tilt2Copy=self.curve.data.splines[0].bezier_points[-1].tilt
            elif self.curve.data.splines[0].type=='NURBS' and len(self.curve.data.splines[0].points)==8:
                self.tilt1Copy=self.curve.data.splines[0].points[1].tilt
                self.tilt2Copy=self.curve.data.splines[0].points[5].tilt
            else:
                self.tilt1Copy=self.curve.data.splines[0].points[1].tilt
                self.tilt2Copy=self.curve.data.splines[0].points[-1].tilt
        if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object:
            self.emptyLocation_z=self.curve.modifiers.get("RT_CableHook_3").object.location[2]
        
        if self.ismultiwire:
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        self.capScaleCopy=1 if len(self.curve.Caps)==0 else self.curve.Caps[0].obj.scale[2]
        self.capOffsetCopy=0 if len(self.curve.Caps)==0 else self.curve.Caps[0].obj.location[2]
    def modal(self, context, event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        #if preferences().cursor_overflow:
        if event.mouse_x>context.region.x+context.region.width-10:
            self.saveState(context)
            context.window.cursor_warp(context.region.x+10,event.mouse_y)
            self.init_x=context.region.x+5
        if event.mouse_x<context.region.x+10:
            self.saveState(context)
            context.window.cursor_warp(context.region.x+context.region.width-10,event.mouse_y)
            self.init_x=context.region.x+context.region.width-5
        if event.type == 'LEFT_ALT':
            self.init_x=event.mouse_x
            self.saveState(context)
        if event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.saveState(context)
            if event.value == 'PRESS':
                self.speed=10
            elif event.value == 'RELEASE':
                self.speed=1
        if event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            self.saveState(context)
            if event.value == 'PRESS':
                self.speed=0.3
            elif event.value == 'RELEASE':
                self.speed=1
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            if self.wire:
                self.countMod.count+=1
            elif event.ctrl:
                self.curve.data.resolution_u+=1
            else:
                return {'PASS_THROUGH'}
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            if self.wire:
                self.countMod.count-=1
            elif event.ctrl:
                self.curve.data.resolution_u-=1
            else:
                return {'PASS_THROUGH'}
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type =='MOUSEMOVE':
            if (self.adjustMode=="Tension"  or event.alt) and self.tensionAvailable:
                if self.tensionA:
                    self.tension1=max(0.001,self.tension1Copy-(self.init_x-event.mouse_x)/(300*self.speed))
                if self.tensionB:
                    self.tension2=max(0.001,self.tension2Copy-(self.init_x-event.mouse_x)/(300*self.speed))
                self.tensionAdjust(self.curve,self.tension1,self.tension2,self.ogTension1,self.ogTension2,self.tension1direction,self.tension2direction,self.oglocation1,self.oglocation2,self.oglocation3,self.oglocation4)
            elif self.adjustMode=="Separation":
                self.separation=self.separationCopy-(self.init_x-event.mouse_x)/(300*self.speed)
                self.separationAdjust(self.curve)
            elif self.adjustMode=="CapOffset":
                for cap in self.curve.Caps:
                    cap.obj.location[2]=self.capOffsetCopy-(self.init_x-event.mouse_x)/(1000*self.speed)
            elif self.adjustMode=="CapSize":
                for cap in self.curve.Caps:
                    cap.obj.scale=(self.capScaleCopy-(self.init_x-event.mouse_x)/(1000*self.speed),self.capScaleCopy-(self.init_x-event.mouse_x)/(1000*self.speed),self.capScaleCopy-(self.init_x-event.mouse_x)/(1000*self.speed))
                    if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object:
                        self.curve.modifiers.get("RT_CableHook_1").object.empty_display_size=max(cap.obj.dimensions)/2
                    if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object:
                        self.curve.modifiers.get("RT_CableHook_2").object.empty_display_size=max(cap.obj.dimensions)/2
            elif self.adjustMode=="Radius" :
                if self.wire:
                    if self.wire.wire_type=='Radial':
                        if self.radiusMod is not None and self.radiusCopy is not None:
                            self.radiusMod.strength=self.radiusCopy-(self.init_x-event.mouse_x)/(1000*self.speed)
                    else:
                        if self.offsetCopy is not None:
                            self.wire.wire_parallel_offset=self.offsetCopy-(self.init_x-event.mouse_x)/(1000*self.speed)
                else:
                    self.curve.data.bevel_depth=max(0,self.radiusCopy-(self.init_x-event.mouse_x)/(1000*self.speed))
            elif self.adjustMode=="Extrude":
                self.curve.data.extrude=self.extrudeCopy-(self.init_x-event.mouse_x)/(500*self.speed)
            
            elif self.adjustMode=="Drip":
                self.empty.location.z=self.emptyLocation_z+(self.init_x-event.mouse_x)/(500*self.speed)
            elif self.adjustMode=="TiltA":
                    if self.curve.data.splines[0].type=='BEZIER':
                        self.curve.data.splines[0].bezier_points[0].tilt=self.tilt1Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                    elif self.curve.data.splines[0].type=='NURBS' and len(self.curve.data.splines[0].points)==8:
                        self.curve.data.splines[0].points[0].tilt=self.tilt1Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                        self.curve.data.splines[0].points[1].tilt=self.tilt1Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                        self.curve.data.splines[0].points[2].tilt=self.tilt1Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                    else:
                        self.curve.data.splines[0].points[0].tilt=self.tilt1Copy-(self.init_x-event.mouse_x)/(300*self.speed)
            elif self.adjustMode=="TiltB":    
                    if self.curve.data.splines[0].type=='BEZIER':
                        self.curve.data.splines[0].bezier_points[-1].tilt=self.tilt2Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                    elif self.curve.data.splines[0].type=='NURBS' and len(self.curve.data.splines[0].points)==8:
                        self.curve.data.splines[0].points[5].tilt=self.tilt2Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                        self.curve.data.splines[0].points[6].tilt=self.tilt2Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                        self.curve.data.splines[0].points[7].tilt=self.tilt2Copy-(self.init_x-event.mouse_x)/(300*self.speed)
                    else:
                        self.curve.data.splines[0].points[-1].tilt=self.tilt2Copy-(self.init_x-event.mouse_x)/(300*self.speed)
            elif self.adjustMode=="Twist" :
                if self.twistMod is not None and self.twistCopy is not None:
                    self.twistMod.angle=self.twistCopy-(self.init_x-event.mouse_x)/(200*self.speed)
            elif self.adjustMode=="Strand Radius":
                if self.strandradiusMod is not None and self.strandradiusCopy is not None:
                    self.strandradiusMod.strength=self.strandradiusCopy-(self.init_x-event.mouse_x)/(1000*self.speed)
            context.area.tag_redraw()
        elif event.type =='U':
            if event.value=='PRESS'  and len(self.curve.Caps)>0:
                self.adjustMode="CapSize"  if self.adjustMode!="CapSize" else "None"
                self.saveState(context)
                self.activeKey='U'
                self.init_x=event.mouse_x
            else:
                self.activeKey=None
            
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='O':
            if event.value=='PRESS'  and len(self.curve.Caps)>0:
                self.adjustMode="CapOffset"  if self.adjustMode!="CapOffset" else "None"
                self.saveState(context)
                self.activeKey='O'
                self.init_x=event.mouse_x
            else:
                self.activeKey=None
            
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='G' and self.wire:
            if event.value== 'PRESS':
                self.wire.wire_axis='X' if self.wire.wire_axis!='X' else 'Y'
                self.activeKey='G'
            else:
                self.activeKey=None
            self.saveState(context)
            self.init_x=event.mouse_x
            context.area.tag_redraw()
        elif event.type =='V'  and self.wire:
            if event.value== 'PRESS':
                self.adjustMode="Twist"  if self.adjustMode!="Twist" else "None"
                self.activeKey='V'
            else:
                self.activeKey=None
            self.saveState(context)
            self.init_x=event.mouse_x
            context.area.tag_redraw()
        elif event.type =='Z' :
            if event.value=='PRESS':
                if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object:
                    deselect_all()
                    self.curve.modifiers.get("RT_CableHook_1").object.hide_view=False
                    self.curve.modifiers.get("RT_CableHook_1").object.hide_viewport=False
                    select(self.curve.modifiers.get("RT_CableHook_1").object)
                    self.remove_drawHandler(context)
                    return {'FINISHED'}
                self.activeKey='Z'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='X' :
            if event.value=='PRESS':
                if self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object:
                    deselect_all()
                    self.curve.modifiers.get("RT_CableHook_2").object.hide_view=False
                    self.curve.modifiers.get("RT_CableHook_2").object.hide_viewport=False
                    select(self.curve.modifiers.get("RT_CableHook_2").object)
                    self.remove_drawHandler(context)
                    return {'FINISHED'}
                self.activeKey='X'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='F' :
            if event.value=='PRESS':
                if self.wire:
                    self.wire.wire_type='Radial' if self.wire.wire_type!='Radial' else 'Parallel'
                else:
                    self.curve.data.use_fill_caps=not self.curve.data.use_fill_caps
                self.activeKey='F'
                self.init_x=event.mouse_x
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='W':
            if event.value=='PRESS':
                self.adjustMode="TiltA" if self.adjustMode!="TiltA" else "None"
                self.saveState(context)
                self.activeKey='W'
                self.init_x=event.mouse_x
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='Q':
            if event.value=='PRESS':
                self.adjustMode="TiltB" if self.adjustMode!="TiltB" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='Q'
                
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='A' and self.tensionAvailable:
            if event.value=='PRESS':
                self.adjustMode="Tension"
                self.tensionA=True

                self.tensionB=True
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='A/S/D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='S' and self.tensionAvailable:
            if event.value=='PRESS':
                self.adjustMode="Tension"
                self.tensionA=True

                self.tensionB=False
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='A/S/D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='C':
            if event.value=='PRESS':
                self.capPickMode=not self.capPickMode
                self.backUpMode=self.adjustMode
                self.adjustMode="None"
                
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='C'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='D' and self.tensionAvailable:
            if event.value=='PRESS':
                self.adjustMode="Tension"
                self.tensionA=False

                self.tensionB=True
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='A/S/D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        
        elif event.type =='Y' and self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object:
            if event.value == 'PRESS':
                self.adjustMode="Drip" if self.adjustMode!="Drip" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='Y'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='R':
            if event.value == 'PRESS':
                if self.wire:
                    self.adjustMode="Strand Radius"  if self.adjustMode!="Strand Radius" else "None"
                else:
                    self.adjustMode="Radius" if self.adjustMode!="Radius" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='R'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='E':
            if event.value == 'PRESS':
                if self.wire:
                    self.adjustMode='Radius' if self.adjustMode!="Radius" else "None"
                else:
                    self.adjustMode="Extrude" if self.adjustMode!="Extrude" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='E'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='B' and self.tensionAvailable:
            if event.value == 'PRESS':
                self.adjustMode="Separation" if self.adjustMode!="Separation" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='B'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type =='T' and self.tensionAvailable:
            if event.value == 'PRESS':
                self.adjustMode="Tension" if self.adjustMode!="Tension" else "None"
                self.saveState(context)
                self.init_x=event.mouse_x
                self.activeKey='T'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and (not event.alt if preferences().industry_keymap else True):
            if self.capPickMode:
                scene = context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                hidden_objs=[]
                
                while ( object and (object.type!='MESH' or not object.visible_get() or (object.display_type=='WIRE' and preferences().extract_from_only_solid_objects))):
                    
                    hidden_objs.append((object,object.hide_get()))
                    object.hide_view=True
                    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                for o,s in hidden_objs:
                    o.hide_view=s
                if object:
                    select(object)
                    #print(object,object.type)
                    bpy.ops.rtools.capsoncurve('INVOKE_DEFAULT',method='Empties')
                    self.capName=",".join([c.name for c in self.curve.Caps])
                self.capPickMode=False
                self.adjustMode="CapOffset"
                #self.adjustMode=self.backUpMode
                context.area.tag_redraw()
                self.init_x=event.mouse_x
                return {'RUNNING_MODAL'}
            else:
                self.remove_drawHandler(context)
                return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC' and event.value == 'PRESS' :
            if self.tensionAvailable:
                if self.curve.data.splines[0].type=='BEZIER':
                    self.curve.data.splines[0].bezier_points[0].handle_right=self.initLocation1
                    self.curve.data.splines[0].bezier_points[-1].handle_left=self.initLocation2
                    self.curve.data.splines[0].bezier_points[0].tilt=self.initTilt1
                    self.curve.data.splines[0].bezier_points[-1].tilt=self.initTilt2
                    if len(self.curve.data.splines[0].bezier_points)==3:
                        self.curve.data.splines[0].bezier_points[1].co=self.initLocation3
                        self.curve.data.splines[0].bezier_points[1].handle_left=self.initLocation4
                        self.curve.data.splines[0].bezier_points[1].handle_right=self.initLocation5
                else:
                    self.curve.data.splines[0].points[2].co=self.initLocation1
                    self.curve.data.splines[0].points[5].co=self.initLocation2
                    self.curve.data.splines[0].points[3].co=self.initLocation3
                    self.curve.data.splines[0].points[4].co=self.initLocation4
                    self.curve.data.splines[0].points[1].tilt=self.initTilt1
                    self.curve.data.splines[0].points[5].tilt=self.initTilt2
            self.curve.data.resolution_u=self.initResolution
            self.curve.data.bevel_depth=self.initRadius
            self.curve.data.extrude=self.initExtrude
            self.curve.data.use_fill_caps=self.fill
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type=='MIDDLEMOUSE' or (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) or (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.capPickMode=False
        self.capName=None
        self.separation=0
        self.tensionA=True
        self.tensionB=True
        self.tiltA=False
        self.tiltB=False
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        self.init_x=event.mouse_x
        self.speed=1
        self.curve=context.active_object
        deselect_all()
        select(self.curve)
        self.activeKey=None
        self.tensionAvailable=True
        self.adjustMode="Tension"
        self.wire=None
        self.ismultiwire=self.curve.modifiers.get("RT_WIRE_LENGTH_ARRAY") is not None
        self.strandradiusMod=None
        self.radiusMod=None
        self.parallelDisplaceMod=None
        self.countMod=None
        self.twistMod=None
        if self.ismultiwire:
            self.wire=self.curve
            self.strandradiusMod=self.wire.modifiers.get("RT_STRAND_RADIUS")
            self.radiusMod=self.wire.modifiers.get("RT_WIRE_RADIUS")
            self.parallelDisplaceMod=self.wire.modifiers.get("RT_PARALLEL_WIRE_DISPLACE")
            self.countMod=self.wire.modifiers.get("RT_WIRE_COUNT")
            self.twistMod=self.wire.modifiers.get("RT_WIRE_TWIST")
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        if self.curve.type !='CURVE':
            if self.curve.modifiers.get("RT_POC_Curve") is not None:
                
                self.curve=self.curve.modifiers.get("RT_POC_Curve").object
            else:
                self.report({'WARNING'},'No Curve Or Wire Selected')
                return {'CANCELLED'}
        for cap in self.curve.Caps:
            if cap.obj not in [a for a in context.scene.objects]:
                self.curve.Caps.remove(self.curve.Caps.find(cap.name))
        self.oglocation3=None
        self.oglocation4=None
        self.initLocation3=None
        self.initLocation4=None
        self.initLocation5=None
        if self.curve.modifiers.get("RT_CableHook_1") and self.curve.modifiers.get("RT_CableHook_1").object and self.curve.modifiers.get("RT_CableHook_2") and self.curve.modifiers.get("RT_CableHook_2").object:
            hook1=self.curve.modifiers.get("RT_CableHook_1").object
            hook2=self.curve.modifiers.get("RT_CableHook_2").object
            hook3=None
            if self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object:
                hook3=self.curve.modifiers.get("RT_CableHook_3").object
                bpy.ops.object.modifier_apply({'object':self.curve},modifier='RT_CableHook_3')
            bpy.ops.object.modifier_apply({'object':self.curve},modifier='RT_CableHook_1')
            bpy.ops.object.modifier_apply({'object':self.curve},modifier='RT_CableHook_2')
            hookCurve(hook2,hook1,hook3,self.curve,curve_type=self.curve.data.splines[0].type)
        if  self.curve.modifiers.get("RT_CableHook_3") and self.curve.modifiers.get("RT_CableHook_3").object:
            self.empty=self.curve.modifiers.get("RT_CableHook_3").object
            self.emptyLocation_z=self.curve.modifiers.get("RT_CableHook_3").object.location[2]
        if self.curve.data.splines[0].type=='BEZIER':
            self.ogTension1= (self.curve.data.splines[0].bezier_points[0].co-self.curve.data.splines[0].bezier_points[0].handle_right).length
            self.ogTension2=(self.curve.data.splines[0].bezier_points[-1].co-self.curve.data.splines[0].bezier_points[-1].handle_left).length
            #print(self.ogTension1,self.ogTension2)
            self.tension1direction=(self.curve.data.splines[0].bezier_points[0].co-self.curve.data.splines[0].bezier_points[0].handle_right).normalized()
            self.tension2direction=-(self.curve.data.splines[0].bezier_points[-1].co-self.curve.data.splines[0].bezier_points[-1].handle_left).normalized()
            self.tension1direction=Vector((round(self.tension1direction[0],4),round(self.tension1direction[1],4),round(self.tension1direction[2],4)))
            self.tension2direction=Vector((round(self.tension2direction[0],4),round(self.tension2direction[1],4),round(self.tension2direction[2],4)))
            #print(self.tension1direction,self.tension2direction)
            self.oglocation1=self.curve.data.splines[0].bezier_points[0].co.copy()
            self.oglocation2=self.curve.data.splines[0].bezier_points[-1].co.copy()
            self.initLocation1=self.curve.data.splines[0].bezier_points[0].handle_right.copy()
            self.initLocation2=self.curve.data.splines[0].bezier_points[-1].handle_left.copy()
            self.location1=self.curve.data.splines[0].bezier_points[0].handle_right.copy()
            self.location2=self.curve.data.splines[0].bezier_points[-1].handle_left.copy()
            if len(self.curve.data.splines[0].bezier_points)==3:
                self.initLocation3=self.curve.data.splines[0].bezier_points[1].co.copy()
                self.initLocation4=self.curve.data.splines[0].bezier_points[1].handle_left.copy()
                self.initLocation5=self.curve.data.splines[0].bezier_points[1].handle_right.copy()
            self.tilt1Copy=self.curve.data.splines[0].bezier_points[0].tilt
            self.tilt2Copy=self.curve.data.splines[0].bezier_points[-1].tilt
            self.initTilt1=self.curve.data.splines[0].bezier_points[0].tilt
            self.initTilt2=self.curve.data.splines[0].bezier_points[-1].tilt
            #print(self.oglocation1,self.oglocation2)
        elif self.curve.data.splines[0].type=='NURBS' and len(self.curve.data.splines[0].points)==8:
            self.ogTension1=(self.curve.data.splines[0].points[1].co-self.curve.data.splines[0].points[2].co).resized(3).length
            self.ogTension2=(self.curve.data.splines[0].points[5].co-self.curve.data.splines[0].points[6].co).resized(3).length
            self.tilt1Copy=self.curve.data.splines[0].points[1].tilt
            self.tilt2Copy=self.curve.data.splines[0].points[5].tilt
            self.initTilt1=self.curve.data.splines[0].points[1].tilt
            self.initTilt2=self.curve.data.splines[0].points[5].tilt
            self.tension1direction=-(self.curve.data.splines[0].points[1].co-self.curve.data.splines[0].points[2].co).normalized()
            self.tension2direction=(self.curve.data.splines[0].points[5].co-self.curve.data.splines[0].points[6].co).normalized()
            self.tension1direction=Vector((round(self.tension1direction[0],4),round(self.tension1direction[1],4),round(self.tension1direction[2],4)))
            self.tension2direction=Vector((round(self.tension2direction[0],4),round(self.tension2direction[1],4),round(self.tension2direction[2],4)))
            #print(self.tension1direction,self.tension2direction)
            self.initLocation1=self.curve.data.splines[0].points[2].co.copy()
            self.initLocation2=self.curve.data.splines[0].points[5].co.copy()
            self.location1=self.curve.data.splines[0].points[2].co.copy()
            self.location2=self.curve.data.splines[0].points[5].co.copy()
            self.initLocation3=self.curve.data.splines[0].points[3].co.copy()
            self.initLocation4=self.curve.data.splines[0].points[4].co.copy()
            self.oglocation1=self.curve.data.splines[0].points[1].co
            self.oglocation2=self.curve.data.splines[0].points[6].co
            self.oglocation3=self.curve.data.splines[0].points[3].co+(self.curve.data.splines[0].points[1].co-self.curve.data.splines[0].points[2].co)
            self.oglocation4=self.curve.data.splines[0].points[4].co-(self.curve.data.splines[0].points[5].co-self.curve.data.splines[0].points[6].co)
        else:
            self.tilt1Copy=self.curve.data.splines[0].points[1].tilt
            self.tilt2Copy=self.curve.data.splines[0].points[-1].tilt
            self.initTilt1=self.curve.data.splines[0].points[1].tilt
            self.initTilt2=self.curve.data.splines[0].points[-1].tilt
            self.tensionAvailable=False
            self.adjustMode="Radius"
        self.capName=",".join([c.name for c in self.curve.Caps])
        self.backUpMode=self.adjustMode
        self.separationCopy=self.separation
        self.radiusCopy=self.curve.data.bevel_depth
        self.extrudeCopy=self.curve.data.extrude
        self.initRadius=self.curve.data.bevel_depth
        self.initExtrude=self.curve.data.extrude
        self.fill=self.curve.data.use_fill_caps
        self.initResolution=self.curve.data.resolution_u
        self.capScaleCopy=1
        self.capOffsetCopy=0 if len(self.curve.Caps)==0 else self.curve.Caps[0].obj.location[2]
        if self.ismultiwire:
            self.radiusCopy=self.radiusMod.strength
            self.twistCopy=self.twistMod.angle
            self.strandradiusCopy=self.strandradiusMod.strength
            self.offsetCopy=self.wire.wire_parallel_offset
        if self.tensionAvailable:
            self.tension1Copy=self.ogTension1
            self.tension2Copy=self.ogTension2
            self.tension1=self.ogTension1
            self.tension2=self.ogTension2
        self.add_drawHandler(context)
        self.adjustMode="None"
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Caps_On_Curve(bpy.types.Operator):
    bl_idname = "rtools.capsoncurve"
    bl_label = "Add Caps on Curve"
    bl_description = "Put Active object on selected curves"
    bl_options = {"REGISTER","UNDO"}
    offset:bpy.props.FloatProperty(default=0,name="Offset")
    method:bpy.props.EnumProperty(items=(('Curves','Curves','Curves'),('Empties','Empties','Empties')),name="Method")
    scale:bpy.props.FloatProperty(default=1,name="Scale")
    def draw(self, context):
        layout=self.layout
        layout.prop(self,'method')
        layout.prop(self,'offset')
        layout.prop(self,'scale')
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type=='MESH'
    def execute(self,context):
        self.obj=context.active_object
        self.curves=Diff(context.selected_objects,[self.obj])
        if self.method=='Empties':
            for curve in self.curves:
                if curve.type !='CURVE':
                    if curve.modifiers.get("RT_POC_Curve") is not None:
                        curve=curve.modifiers.get("RT_POC_Curve").object
                        if not curve.modifiers.get("RT_CableHook_1"):
                            self.method='Curves'
                            self.report({'WARNING'},"All Curves need to have Empties available!")
                            break
                else:
                    if not curve.modifiers.get("RT_CableHook_1"):
                        self.method='Curves'
                        self.report({'WARNING'},"All Curves need to have Empties available!")
                        break
        deselect_all()
        select(self.obj)
        bpy.ops.object.duplicate_move()
        bpy.ops.object.parent_clear()
        self.obj=context.active_object
        bpy.ops.rtools.origintobottom()
        bpy.ops.transform.resize(value=(self.scale, self.scale, self.scale))
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
        
        dup_flipped=context.active_object
        
        #if self.method=='Curves' :
        #    dup_flipped.scale[2]=-dup_flipped.scale[2]
        #    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        for curve in self.curves:
            deselect_all()
            select(self.obj)
            bpy.ops.object.duplicate_move_linked(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
            
            dup=context.active_object
            deselect_all()
            select(dup_flipped)
            bpy.ops.object.duplicate_move_linked(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
            dup2=context.active_object
            deselect_all()
            select(curve)
            select(dup)
            bpy.ops.rtools.capsoncurveinternal('INVOKE_DEFAULT',offset=self.offset,curve_name=curve.name,cap1=dup.name,cap2=dup2.name,method=self.method)
        if len(self.curves)>0:
            delete_object(self.obj)
        delete_object(dup_flipped)
        return {'FINISHED'}
class RTOOLS_OT_Caps_On_Curve_Internal(bpy.types.Operator):
    bl_idname = "rtools.capsoncurveinternal"
    bl_label = "Add Caps on Curve"
    bl_description = "Add Caps on Curve"
    bl_options = {"REGISTER","UNDO"}
    method:bpy.props.EnumProperty(items=(('Curves','Curves','Curves'),('Empties','Empties','Empties')))
    offset:bpy.props.FloatProperty(default=0)
    cap1:bpy.props.StringProperty(default="None")
    cap2:bpy.props.StringProperty(default="None")
    curve_name:bpy.props.StringProperty(default="None")
    def execute(self,context):
        self.obj=context.active_object
        #self.curve=Diff(context.selected_objects,[self.obj])[0]
        self.curve=bpy.data.objects[self.curve_name]
        if self.curve.type !='CURVE':
            if self.curve.modifiers.get("RT_POC_Curve") is not None:
                self.curve=self.curve.modifiers.get("RT_POC_Curve").object
            else:
                return {'CANCELLED'}
        if self.method=='Curves' or 'RT_CableHook_1' not in [m.name for m in self.curve.modifiers]:
            if self.obj.scale[:]!=(1.0,1.0,1.0):
                self.report({'WARNING'},"Apply Scale For Proper EndPoints")
            bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            plane=context.active_object
            plane.scale=(0.001,0.001,0.001)
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            arrayMod=plane.modifiers.new(type="ARRAY",name="RT_Temp")
            arrayMod.fit_type="FIT_CURVE"
            arrayMod.curve=self.curve
            bpy.ops.object.modifier_apply(modifier=arrayMod.name)
            self.maxStrength=plane.dimensions[0]
            self.maxStrength=self.maxStrength-self.obj.modifiers.get("RT_ST_Screw_2").screw_offset if self.obj.modifiers.get("RT_ST_Screw_2") is not None else self.maxStrength
            
            #print(self.maxStrength)
            delete_object(plane)
            curve=self.curve

            select(self.obj,active=True)
            self.objInitLocation=self.obj.location.copy()
            self.obj.location=curve.location
            #bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_type":'GLOBAL', "orient_matrix":((0, 0, 0), (0, 0, 0), (0, 0, 0)), "orient_matrix_type":'GLOBAL', "constraint_axis":(False, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
            self.obj_dup=bpy.data.objects[self.cap2]
            #self.obj_dup=duplicate_object(self.obj)
            self.obj_dup.location=curve.location
            self.displaceMod=self.obj.modifiers.new(type="DISPLACE",name="RT_CurveDisplace")
            self.displaceMod.mid_level=0
            self.displaceMod.direction='Z' if self.obj.modifiers.get("RT_ST_Displace") is not None else 'Z'
            self.displaceMod.strength=self.offset+0.03
            self.curveMod=self.obj.modifiers.new(type="CURVE",name="RT_POC_Curve")
            self.curveMod.object=curve
            self.curveMod.deform_axis='POS_Z'
            
            self.displaceMod=self.obj_dup.modifiers.new(type="DISPLACE",name="RT_CurveDisplace")
            self.displaceMod.mid_level=0
            self.displaceMod.direction='Z' if self.obj_dup.modifiers.get("RT_ST_Displace") is not None else 'Z'
            self.curveMod=self.obj_dup.modifiers.new(type="CURVE",name="RT_POC_Curve")
            self.curveMod.object=curve
            self.curveMod.deform_axis='NEG_Z'
            self.displaceMod.strength=-(self.maxStrength-self.offset-0.03)
        else:
            

            hook1=self.curve.modifiers.get("RT_CableHook_1").object
            hook2=self.curve.modifiers.get("RT_CableHook_2").object
            self.obj_dup=bpy.data.objects[self.cap2]
            self.obj.location=(0,0,self.offset)
            self.obj_dup.location=(0,0,self.offset)
            self.obj.parent=hook1
            self.obj_dup.parent=hook2
            maxDim=max(self.obj.dimensions)/2
            hook1.empty_display_size=maxDim
            hook2.empty_display_size=maxDim

        t=self.curve.Caps.add()
        t.name=self.obj.name
        t.obj=self.obj
        t=self.curve.Caps.add()
        t.name=self.obj_dup.name
        t.obj=self.obj_dup
        return {'FINISHED'}
class RTOOLS_OT_Refit_Caps_On_Curve(bpy.types.Operator):
    bl_idname = "rtools.refitcaps"
    bl_label = "Reposition Caps on Curve"
    bl_description = "Reposition caps on the curve"
    bl_options = {"REGISTER","UNDO"}
    offset:bpy.props.FloatProperty(default=0)
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.modifiers.get("RT_POC_Curve")
    def execute(self, context):
        for active in context.selected_objects:
            self.curve=None
            if active.modifiers.get("RT_POC_Curve") is not None:
                self.curve=active.modifiers.get("RT_POC_Curve").object
            else:
                return {'CANCELLED'}
            if self.curve:
                if active.scale[:]!=(1.0,1.0,1.0):
                    self.report({'WARNING'},"Apply Scale For Proper EndPoints")
                bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                plane=context.active_object
                plane.scale=(0.001,0.001,0.001)
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                arrayMod=plane.modifiers.new(type="ARRAY",name="RT_Temp")
                arrayMod.fit_type="FIT_CURVE"
                arrayMod.curve=self.curve
                bpy.ops.object.modifier_apply(modifier=arrayMod.name)
                self.curveLength=plane.dimensions[0]
                delete_object(plane)
                if active.modifiers.get("RT_CurveDisplace"):
                    self.displaceMod=active.modifiers.get("RT_CurveDisplace")
                    
                    self.displaceMod.strength=(-1 if active.modifiers.get("RT_POC_Curve").deform_axis=='NEG_Z' else 1)*(self.curveLength-self.offset-0.03)
                select(active)
        return {'FINISHED'}
class RTOOLS_OT_Put_On_Curve(bpy.types.Operator):
    bl_idname = "rtools.putoncurve"
    bl_label = "Put on Curve"
    bl_description = "Put selected object on active curve object\nCTRL+LMB : Set Array length to Fit Curve"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        if len(context.selected_objects)==2 and context.active_object is not None:
            if context.active_object.type=='CURVE' :
                return True
            elif context.active_object.modifiers.get("RT_POC_Curve") is not None:
                obj=context.active_object.modifiers.get("RT_POC_Curve").object
                return obj is not None
            else:
                return False
        else:
            return False
    def execute(self,context):
        curve=self.curve
        
        select(self.obj,active=True)
        self.objInitLocation=self.obj.location.copy()
        self.obj.location=curve.location
        self.arrayMod=self.obj.modifiers.new(type="ARRAY",name="RT_POC_ARRAY")
        self.arrayMod.use_relative_offset=True
        #self.arrayMod.use_constant_offset=True
        self.arrayMod.relative_offset_displace=[0,0,1]
        #self.arrayMod.constant_offset_displace=[0,0,0.2]
        self.arrayMod.use_merge_vertices=True
        self.arrayMod.count=1
        if self.curveLength:
            self.arrayMod.fit_type='FIT_CURVE'
        self.arrayMod.curve=curve
        self.displaceMod=self.obj.modifiers.new(type="DISPLACE",name="RT_CurveDisplace")
        self.displaceMod.mid_level=0
        self.displaceMod.direction='Z' if self.obj.modifiers.get("RT_ST_Displace") is not None else 'Z'
        self.curveMod=self.obj.modifiers.new(type="CURVE",name="RT_POC_Curve")
        self.curveMod.object=curve
        self.curveMod.deform_axis='POS_Z' if self.obj.modifiers.get("RT_ST_Displace") is not None else 'POS_Z'
        self.strengthCopy=self.displaceMod.strength
        
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.strengthCopy=self.displaceMod.strength
            self.initX=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.initX=context.region.x+context.region.width
            self.strengthCopy=self.displaceMod.strength
        if event.type == 'LEFT_SHIFT':
            self.initX=event.mouse_x
            self.strengthCopy=self.displaceMod.strength
            if event.value == 'PRESS':
                self.speed=30
            elif event.value == 'RELEASE':
                self.speed=2 
        if event.type == 'LEFT_CTRL':
            self.initX=event.mouse_x
            self.strengthCopy=self.displaceMod.strength
            if event.value == 'PRESS':
                self.speed=0.5
            elif event.value == 'RELEASE':
                self.speed=2 
        if event.type =='MOUSEMOVE':
            self.displaceMod.strength=clamp(self.strengthCopy+(self.initX-event.mouse_x)/(10*self.speed),0,self.maxStrength-self.height)
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and (not event.alt if preferences().industry_keymap else True):
            return {'FINISHED'}
        elif (event.type == 'RIGHTMOUSE' and event.value =='PRESS') or event.type == 'ESC':
            self.obj.modifiers.remove(self.displaceMod)
            self.obj.modifiers.remove(self.curveMod)
            self.obj.modifiers.remove(self.arrayMod)
            self.obj.location=self.objInitLocation
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        
        self.initX=event.mouse_x
        self.speed=10
        self.curve=context.active_object
        self.obj=Diff(context.selected_objects,[self.curve])[0]
        if self.curve.type !='CURVE':
            if self.curve.modifiers.get("RT_POC_Curve") is not None:
                self.curve=self.curve.modifiers.get("RT_POC_Curve").object
            else:
                self.report({'WARNIGN'},'No Curve Or Wire Selected')
                return {'CANCELLED'}
        #sum=0
        #curveData=self.curve.data
        #curveData=bpy.data.curves[self.curve.name]
        #for spline in curveData.splines:
        #    sum+=spline.calc_length()
        
        #print(sum)
        self.height=self.obj.dimensions[2]
        if self.obj.scale[:]!=(1.0,1.0,1.0):
            self.report({'WARNING'},"Apply Scale For Proper EndPoints")
        bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        plane=context.active_object
        plane.scale=(0.001,0.001,0.001)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        arrayMod=plane.modifiers.new(type="ARRAY",name="RT_Temp")
        arrayMod.fit_type="FIT_CURVE"
        arrayMod.curve=self.curve
        bpy.ops.object.modifier_apply(modifier=arrayMod.name)
        self.maxStrength=plane.dimensions[0]
        self.maxStrength=self.maxStrength-self.obj.modifiers.get("RT_ST_Screw_2").screw_offset if self.obj.modifiers.get("RT_ST_Screw_2") is not None else self.maxStrength
        #print(self.maxStrength)
        delete_object(plane)
        self.curveLength=event.ctrl
        context.window_manager.modal_handler_add(self)
        return self.execute(context)

class RTOOLS_OT_Wire_Simul(bpy.types.Operator):
    bl_idname = "rtools.simulatewire"
    bl_label = "Simulate Wire"
    bl_description = "Simulate Wire"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT' 
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()   
    def draw_callback_px(self,context):
        if self.clothMod is not None:
            draw_Text(context,0,preferences().font_size,text=[f"Stretch : {-round(self.clothMod.settings.shrink_min,4)}"],alignH="CENTER")
            draw_Text(context,0,preferences().font_size,text=['D : Stretch'],alignH="LEFT",activeKey=self.activeKey)
    def execute(self, context):
        self.activeKey=None
        bpy.ops.screen.frame_jump(end=False)
        
        curve=context.active_object
        if curve.type not in {'MESH','CURVE'}:
            self.report({'WARNING'},'Object Type Not Supported')
            return {'CANCELLED'}
        if curve.type=='MESH':
            for m in curve.modifiers:
                if m.type=='CURVE' and 'RT' in m.name:
                    curve=m.object
                    break
        
        if curve.type!='CURVE':
            self.report({'WARNING'},'No Curve Found')
            return {'CANCELLED'}

        self.curve=curve
        self.bevel=curve.data.bevel_depth
        curve.data.bevel_depth=0
        curve.data.extrude=0
        curve.hide_view=False
        for m in curve.modifiers:
            if m.type=='HOOK':
                if m.object is not None:
                    hook=m.object
                    bpy.ops.object.modifier_apply({'object':curve},modifier=m.name)
                    delete_object(hook)
        bpy.ops.object.select_all( action='DESELECT')
        select(curve)
        bpy.ops.object.convert(target='MESH')
        
        maskGroup=curve.vertex_groups.new(name="Pinned")
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action= 'DESELECT')        
        bm=bmesh.from_edit_mesh(curve.data)
        endVertsCount=preferences().freezed_verts_for_simulations
        looseVertsCount=preferences().freezed_verts_for_simulations
        endVerts=[i for i in range(0,endVertsCount)]
        endVerts+=[len(bm.verts)-i for i in  range(0,endVertsCount)]
        beforeEndVerts=[i for i in range(endVertsCount,endVertsCount+looseVertsCount)]
        beforeEndVerts+=[len(bm.verts)-i for i in range(endVertsCount,endVertsCount+looseVertsCount)]
        
        bpy.ops.object.mode_set(mode='OBJECT')
        maskGroup.add(endVerts,1,'REPLACE')
        maskGroup.add(beforeEndVerts,0.999,'REPLACE')
        self.clothMod=curve.modifiers.new(name='RT_Cloth',type='CLOTH')
        self.clothMod.settings.vertex_group_mass=maskGroup.name 
        self.clothMod.settings.effector_weights.gravity=100
        self.mods=[]
        for ob in context.scene.objects:
            if ob!=curve and ob.visible_get():
                col_mod=ob.modifiers.new(name='QC_Collision',type='COLLISION')
                if col_mod:
                    ob.collision.cloth_friction=20
                    self.mods.append((ob,col_mod))
        bpy.ops.screen.animation_play()
        self.add_drawHandler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def modal(self, context, event):
        #self.activeKey=f"{'SHIFT+' if event.shift else ''}{'CTRL+' if event.ctrl else ''}{event.type}"
        #print(self.activeKey)
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and (not event.alt if preferences().industry_keymap else True):
            for ob,m in self.mods:
                bpy.ops.object.modifier_remove(
                    {'object': ob}, modifier=m.name)
            bpy.ops.screen.animation_play()

            bpy.ops.object.convert(target='CURVE')
            self.curve.data.bevel_depth=self.bevel
            bpy.ops.screen.frame_jump(end=False)
            bpy.ops.object.shade_smooth()
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='D':
            if event.value=='PRESS':
                self.activeKey='D'
                if event.alt:
                    self.clothMod.settings.shrink_min+=0.05
                else:
                    self.clothMod.settings.shrink_min-=0.05
                bpy.ops.screen.frame_jump(end=False)
                bpy.ops.screen.animation_cancel()
                bpy.ops.screen.animation_play()
            else:
                self.activeKey=None
                
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}
class RTOOLS_OT_Wire_Simul2(bpy.types.Operator):
    bl_idname = "rtools.simulatewire2"
    bl_label = "Simulate Wire"
    bl_description = "Simulate Wire"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT' 
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()    
    def draw_callback_px(self,context):
        if self.clothMod is not None:
            draw_Text(context,0,preferences().font_size+5,text=[f"Collision Distance  : {round(self.clothMod.collision_settings.distance_min,4)}",f"Stretch : {-round(self.clothMod.settings.shrink_min,4)}"],alignH="CENTER")
            draw_Text(context,0,preferences().font_size+5,text=['D : Stretch',"C : Collision Distance"],alignH="LEFT",activeKey=self.activeKey)
        
    def execute(self, context):
        self.activeKey=None
        bpy.ops.screen.frame_jump(end=False)
        
        curve=context.active_object
        if curve.type not in {'MESH','CURVE'}:
            self.report({'WARNING'},'Object Type Not Supported')
            return {'CANCELLED'}
        if curve.type=='MESH':
            for m in curve.modifiers:
                if m.type=='CURVE' and 'RT' in m.name:
                    curve=m.object
                    break
        
        if curve.type!='CURVE':
            self.report({'WARNING'},'No Curve Found')
            return {'CANCELLED'}

        self.curve=curve
        self.bevel=curve.data.bevel_depth
        curve.data.bevel_depth=0
        curve.data.extrude=0
        curve.hide_view=False
        for m in curve.modifiers:
            if m.type=='HOOK':
                if m.object is not None:
                    hook=m.object
                    bpy.ops.object.modifier_apply({'object':curve},modifier=m.name)
                    delete_object(hook)
        bpy.ops.object.select_all( action='DESELECT')
        select(curve)
        bpy.ops.object.convert(target='MESH')
        
        maskGroup=curve.vertex_groups.new(name="Pinned")
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action= 'DESELECT')        
        bm=bmesh.from_edit_mesh(curve.data)
        endVertsCount=preferences().freezed_verts_for_simulations
        looseVertsCount=preferences().freezed_verts_for_simulations
        endVerts=[i for i in range(0,endVertsCount)]
        endVerts+=[len(bm.verts)-i for i in  range(0,endVertsCount)]
        beforeEndVerts=[i for i in range(endVertsCount,endVertsCount+looseVertsCount)]
        beforeEndVerts+=[len(bm.verts)-i for i in range(endVertsCount,endVertsCount+looseVertsCount)]
        
        bpy.ops.object.mode_set(mode='OBJECT')
        maskGroup.add(endVerts,1,'REPLACE')
        maskGroup.add(beforeEndVerts,0.999,'REPLACE')
        dup=duplicate_object(curve)
        self.dup=dup
        subsurfMod=dup.modifiers.new(type='SUBSURF',name="RT_Subsurf")
        subsurfMod.levels=2
        skinMod=dup.modifiers.new(type='SKIN',name="RT_Skin")
        
        #subsurfMod.levels=2
        for v in dup.data.skin_vertices[0].data:
            v.radius = 0.01, 0.01
        self.clothMod=dup.modifiers.new(name='RT_Cloth',type='CLOTH')
        self.clothMod.settings.vertex_group_mass=maskGroup.name 
        self.clothMod.settings.effector_weights.gravity=10
        self.clothMod.collision_settings.distance_min=0.03
        #self.clothMod.settings.tension_stiffness=800
        self.clothMod.settings.bending_model='LINEAR'
        self.clothMod.settings.bending_damping=70
        #self.clothMod.settings.shrink_min=-0.3
        #
        dup.hide_view=True
        deformMod=curve.modifiers.new(type="SURFACE_DEFORM",name="RT_Deform")
        deformMod.target=dup
        deformMod.vertex_group=maskGroup.name
        deformMod.invert_vertex_group=True
        smoothMod=curve.modifiers.new(type="SMOOTH",name="RT_Smooth")
        smoothMod.factor=1
        smoothMod.iterations=2
        smoothMod.vertex_group=maskGroup.name
        smoothMod.invert_vertex_group=True
        select(curve)
        self.maskGroup=maskGroup
        #corrective_smooth=curve.modifiers.new(type='CORRECTIVE_SMOOTH',name="RT_Corrective_Smooth")
        #corrective_smooth.factor=1
        #corrective_smooth.iterations=4
        #subsurfMod=curve.modifiers.new(type='SUBSURF',name="RT_Subsurf")
        bpy.ops.object.surfacedeform_bind(modifier=deformMod.name)
        self.mods=[]
        for ob in context.scene.objects:
            if ob!=curve and ob.visible_get():
                col_mod=ob.modifiers.new(name='QC_Collision',type='COLLISION')
                if col_mod:
                    ob.collision.cloth_friction=20
                    self.mods.append((ob,col_mod))
        bpy.ops.screen.animation_play()
        self.add_drawHandler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def modal(self, context, event):
        #self.activeKey=f"{'SHIFT+' if event.shift else ''}{'CTRL+' if event.ctrl else ''}{event.type}"
        #print(self.activeKey)
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and (not event.alt if preferences().industry_keymap else True):
            for ob,m in self.mods:
                bpy.ops.object.modifier_remove(
                    {'object': ob}, modifier=m.name)
            bpy.ops.screen.animation_play()

            bpy.ops.object.convert(target='CURVE')
            curve=context.active_object
            smoothMod=curve.modifiers.new(type="SMOOTH",name='RT_Smooth')
            smoothMod.factor=1
            smoothMod.iterations=3
            bpy.ops.object.modifier_apply(modifier=smoothMod.name)
            self.curve.data.bevel_depth=self.bevel
            delete_object_with_data(self.dup)
            bpy.ops.screen.frame_jump(end=False)
            bpy.ops.object.shade_smooth()
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='D':
            if event.value=='PRESS':
                self.activeKey='D'
                if event.alt:
                    self.clothMod.settings.shrink_min+=0.05
                else:
                    self.clothMod.settings.shrink_min-=0.05
                bpy.ops.screen.frame_jump(end=False)
                bpy.ops.screen.animation_cancel()
                bpy.ops.screen.animation_play()
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        if event.type=='C':
            if event.value=='PRESS':
                self.activeKey='C'
                if event.alt:
                    self.clothMod.collision_settings.distance_min-=0.005
                else:
                    self.clothMod.collision_settings.distance_min+=0.005
                bpy.ops.screen.frame_jump(end=False)
                bpy.ops.screen.animation_cancel()
                bpy.ops.screen.animation_play()
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}