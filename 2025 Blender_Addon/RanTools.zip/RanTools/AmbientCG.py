from .utils import *
import requests
import json
import os
import zipfile
import certifi
from requests.api import options
import bpy
import time
import multiprocessing.dummy as multiprocessing
import sys
import urllib
from urllib import request
import warnings
from .t3dn_bip import previews
import traceback

#import asyncio
#import aiofiles
#import aiohttp
previewSize=256
searchTerm="Asphalt"
result_number=0
quality='2K'
sbsar_quality="LQ"
texture_format='jpg'
sortby='popular'
material_preview_collections = {}
material_preview_list={}
previews_generated ={}
qualities={}
previews_generated_offline ={}
qualities_offline={}
__DIRNAME__ = os.path.dirname(os.path.dirname(__file__))
icon_collection={}
pcoll = bpy.utils.previews.new()
my_icons_dir = os.path.join(os.path.dirname(__file__), "icons")
pcoll.load("check", os.path.join(my_icons_dir, "checkmark.png"), 'IMAGE')
icon_collection["icons"] = pcoll
import random
def generate_random_user_agent():
    user_agent_templates = [
        "Mozilla/5.0 (Windows NT {nt_version}; {platform}; rv:{firefox_version}) Gecko/{gecko_version} Firefox/{firefox_version}",
        "Mozilla/5.0 (Windows NT {nt_version}; {platform}; rv:{firefox_version}) Gecko/{gecko_version} Firefox/{firefox_version}",
        "Mozilla/5.0 (Windows NT {nt_version}; WOW64; rv:{firefox_version}) Gecko/{gecko_version} Firefox/{firefox_version}",
        "Mozilla/5.0 (Windows NT {nt_version}; Win64; x64; rv:{firefox_version}) Gecko/{gecko_version} Firefox/{firefox_version}",
        "Mozilla/5.0 (Windows NT {nt_version}; WOW64; Trident/7.0; AS; rv:{ie_version}) like Gecko",
        "Mozilla/5.0 (Windows NT {nt_version}; Trident/7.0; rv:{ie_version}) like Gecko",
        "Mozilla/5.0 (Windows NT {nt_version}; WOW64; Trident/7.0; rv:{ie_version}) like Gecko",
        "Mozilla/5.0 (Windows NT {nt_version}; Win64; x64; Trident/7.0; rv:{ie_version}) like Gecko",
        "Mozilla/5.0 (Windows NT {nt_version}; {platform}; rv:{edge_version}) AppleWebKit/{webkit_version} (KHTML, like Gecko) Chrome/{chrome_version} Safari/{safari_version}",
        "Mozilla/5.0 (Windows NT {nt_version}; {platform}; WOW64; Trident/7.0; rv:{ie_version}) like Gecko",
        "Mozilla/5.0 (Windows NT {nt_version}; {platform}; Win64; x64; Trident/7.0; rv:{ie_version}) like Gecko",
    ]
    
    random_template = random.choice(user_agent_templates)
    
    user_agent = random_template.format(
        nt_version=random.choice(["6.1", "10.0"]),
        platform=random.choice(["Win64; x64", "WOW64"]),
        firefox_version=random.randint(60, 99),
        gecko_version="20100101",
        ie_version=random.choice(["11.0", "7.0"]),
        edge_version=random.randint(80, 95),
        webkit_version="537.36",
        chrome_version=random.randint(80, 95),
        safari_version=random.randint(600, 605),
    )
    
    return user_agent

# Example usage:
random_user_agent = generate_random_user_agent()
# headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'}
headers = {'User-Agent':random_user_agent}
from requests import Session
s = Session()
# Add headers
s.headers.update(headers)
try:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        response = s.get("http://ambientcg.com/api/v2/full_json", params = {
                    'type': 'Material', 'q': "Test",
                    'include':'downloadData,imageData', 'sort':sortby,'limit':'1'
                }, timeout=2)
except:
    pass
def getPreviews(search,count=20,sortby='popular'):
    st=time.time()
    response=requests.get("http://ambientcg.com/api/v2/full_json",params={'type':'PhotoTexturePBR,SBSAR','q':search,'include':'downloadData,imageData','sort':sortby},headers=headers)
    
    json_data=response.json()
    preview_paths=[]
    for i in range(min(count,len(json_data['foundAssets']))):
        preview_paths.append(f"{os.path.join(os.path.join(os.path.dirname(__file__),'previews'),json_data['foundAssets'][i]['assetId'])}.png")
        image_url=json_data['foundAssets'][i]['previewImage'][f'{previewSize}-PNG']
        f = open(f"{os.path.join(os.path.join(os.path.dirname(__file__),'previews'),json_data['foundAssets'][i]['assetId'])}.png",'wb')
        try:
            f.write(requests.get(image_url,verify=False).content)
            
        except:
            f.write(requests.get(image_url,verify=certifi.where()).content)
        f.close()
    #print(time.time()-st)
    return preview_paths
def getPreviewsOffline(search="",offset=0,category=''):
    if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
        reader= csv.reader(csvFile, delimiter=',')
        preview_paths={}
        used=[]
        for row in reader:
            if (row[0],row[1]) not in used:
                used.append((row[0],row[1]))
                if category:
                    if len(row)>4:
                        if (category.lower() in row[4].lower()) and (search.lower() in row[0].lower() or search.lower() in row[3].lower()) and (os.path.isfile(row[2]) or os.path.isdir(row[2].replace('.zip',""))):
                            preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]=preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]+[row[1],] if os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png") in preview_paths.keys() else [row[1],]
                    else:
                        if (category.lower() in row[3].lower()) and (search.lower() in row[0].lower() or search.lower() in row[3].lower()) and (os.path.isfile(row[2]) or os.path.isdir(row[2].replace('.zip',""))):
                            preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]=preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]+[row[1],] if os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png") in preview_paths.keys() else [row[1],]
                else:
                    if (search.lower() in row[0].lower() or search.lower() in row[3].lower()) and (os.path.isfile(row[2]) or os.path.isdir(row[2].replace('.zip',""))):
                            preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]=preview_paths[os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png")]+[row[1],] if os.path.join(__DIRNAME__, 'RanTools-Previews', row[0]+".png") in preview_paths.keys() else [row[1],]
        #print(list(preview_paths.values()))
        #print(int(len(preview_paths)/16))
        offset=min(offset,int(len(preview_paths)/16))
        offset*=16
        #print([offset,min(offset+16,len(preview_paths))])
        paths=list(preview_paths.keys())[offset:min(offset+16,len(preview_paths))]
        qualities=list(preview_paths.values())[offset:min(offset+16,len(preview_paths))]
        #print(qualities)
        return paths,qualities
def savePreviewPar(asset):
    path, url,qualities = asset
    #url=url.replace("https",'http')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if not os.path.isfile(path):
                with open(path, 'wb') as file:
                    try:
                        file.write(requests.get(url,verify=False).content)
                        
                    except:
                        file.write(requests.get(url,verify=certifi.where()).content)
    except Exception as e:
        print(e)
cats=['Asphalt', 'Bark', 'Bricks', 'Candy', 'Cardboard', 'Carpet', 'Chainmail', 'Chip', 'Chipboard', 'ChristmasTreeOrnament', 'Concrete', 'Cork', 'CorrugatedSteel', 'DiamondPlate', 'Fabric', 'Facade', 'Fence', 'Fingerprints', 'Foam', 'Footsteps', 'GlazedTerracotta', 'Grass', 'Gravel', 'Ground', 'Ice', 'Lava', 'Leather', 'Marble', 'Metal', 'MetalPlates', 'MetalWalkway', 'Moss', 'OfficeCeiling', 'Paint', 'PaintedBricks', 'PaintedMetal', 'PaintedPlaster', 'PaintedWood', 'Painting', 'Paper', 'Pathway', 'PavingStones', 'PineNeedles', 'Pipe', 'Planks', 'Plaster', 'Plastic', 'Porcelain', 'Road', 'Rock', 'RockBrush', 'Rocks', 'RoofingTiles', 'Rope', 'Rust', 'Scratches', 'SheetMetal', 'Sign', 'Smear', 'Snow', 'SolarPanel', 'Sponge', 'Sticker', 'SurfaceImperfections', 'TactilePaving', 'Tape', 'Terrazzo', 'Tiles', 'TreeEnd', 'Wicker', 'Wood', 'WoodChips', 'WoodFloor', 'WoodSiding']

def get_categories_enum(self, context):
    return [('All','All','All'),]+[(a,a,a) for a in cats]
def getPreviewsPar(self,search, count = 16, sortby = 'popular',category='',offset=0):
    if not os.path.isdir(os.path.join(__DIRNAME__, 'RanTools-Previews')):
                os.mkdir(os.path.join(__DIRNAME__, 'RanTools-Previews'))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if isConnected():
            search=search.replace("http://ambientcg.com/view?id=","")
            search=search.replace("https://ambientcg.com/view?id=","")
            search=search.replace("ambientCG.com/a/","")
            try:
                st=time.time()
                try:
                    response = s.get("http://ambientcg.com/api/v2/full_json", params = {
                        'type': 'Material', 'q': search,
                        'include':'downloadData,imageData', 'sort':sortby,'limit':f'{count}','offset':offset*count,'category':category if category !='All' else ''
                    }, timeout=10,verify=False)
                except:
                    response = s.get("http://ambientcg.com/api/v2/full_json", params = {
                        'type': 'Material', 'q': search,
                        'include':'downloadData,imageData', 'sort':sortby,'limit':f'{count}','offset':offset*count,'category':category if category !='All' else ''
                    }, timeout=10,verify=certifi.where())
                if response.status_code==200:
                    json_data = response.json()
                    if not json_data['foundAssets']:
                        try:
                            response = s.get("http://ambientcg.com/api/v2/full_json", params = {'id':search ,'include':'downloadData,imageData'}, headers = headers,verify=False)
                        except:
                            response = s.get("http://ambientcg.com/api/v2/full_json", params = {'id':search ,'include':'downloadData,imageData'}, headers = headers,verify=certifi.where())
                if response.status_code==200:
                    json_data = response.json()
                    assets = [
                        (
                            os.path.join(__DIRNAME__, 'RanTools-Previews', asset['assetId']+".png"),
                            asset['previewImage'][f'{previewSize}-PNG'],
                            [asset['assetId'],]+[a['attribute']+f"({round(a['size']/1024/1024,2)} MB)" for a in asset['downloadFolders']['/']['downloadFiletypeCategories']['sbsar']['downloads']] if asset['dataType']=='SBSAR' else [asset['assetId'],]+[a['attribute']+f"({round(a['size']/1024/1024,2)} MB)" for a in asset['downloadFolders']['default']['downloadFiletypeCategories']['zip']['downloads']]
                        )
                        for asset in json_data['foundAssets'][:min(count, len(json_data['foundAssets']))]
                    ]
                    # assets_cats = [asset['category']
                    #     for asset in json_data['foundAssets'][:min(count, len(json_data['foundAssets']))]
                    # ]
                    # cats.update(set(assets_cats))
                    preview_paths = [ path for path, _,qualities in assets ]
                    qualities = [ qualities for path, _,qualities in assets ]
                    #print(preview_paths)
                    st2=time.time()
                    # for ase in assets:
                    #     savePreviewPar(ase)
                    #print(len(assets))
                    previews_to_download=[asset for asset in assets if not os.path.isfile(asset[0])]
                    if len(previews_to_download)>6:
                        with multiprocessing.Pool() as pool:
                            pool.map(savePreviewPar, previews_to_download, chunksize = 2)
                    else:
                        for ase in previews_to_download:
                            savePreviewPar(ase)
                    #for asset in assets:
                        #savePreviewPar(asset)
                    #print("Previews Loaded in ",time.time()-st,"s",time.time()-st2)
                    return preview_paths,qualities
            except Exception as e:
                print("Error",e)
                #self.report({'WARNING'},"Couldn't Connect")
        else:
            print("Couldn't Connect")
#        self.report({'WARNING'},"Couldn't Connect")
    return [],[]

def get_asset_url(self,context,name,quality):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if isConnected():
            try:
                try:
                    response=s.get("http://ambientcg.com/api/v2/full_json",params={'id':name ,'include':'downloadData,imageData,tagData'},timeout=10,verify=False)
                except:
                    response=s.get("http://ambientcg.com/api/v2/full_json",params={'id':name ,'include':'downloadData,imageData,tagData'},timeout=10,verify=certifi.where())
                json_data=response.json()
                #print(response.url)
                asset_name="Not Found"
                
                if json_data['foundAssets'][0]['dataType']=='SBSAR':
                    asset_urls=json_data['foundAssets'][0]['downloadFolders']['default']['downloadFiletypeCategories']['sbsar']['downloads']
                    asset_url=[a for a in asset_urls if a['attribute']==sbsar_quality]
                    if not asset_url:
                        asset_url=asset_urls
                    asset_type='sbsar'
                else:
                    asset_urls=json_data['foundAssets'][0]['downloadFolders']['default']['downloadFiletypeCategories']['zip']['downloads']
                    asset_url=[a for a in asset_urls if a['attribute']==quality]
                    asset_type='zip'
                    
                if asset_url:
                    asset_name=asset_url[0]['fileName'].replace(".zip","").replace(".sbsar","")
                    asset_url=asset_url[0]['downloadLink']
                    tags=json_data['foundAssets'][0]['tags']
                    category=tags=json_data['foundAssets'][0]['category']
                    #asset_url=asset_url.replace("https",'http')
                    return asset_url,asset_name,asset_type,tags,category
            except:
                return None,None,None,None,None
    return None,None,None,None,None
def download_material(self,context,name,quality):
    #print(name)
    
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if isConnected():
                
            wm = context.window_manager
            #print(asset_url)
            asset_url,asset_name,asset_type,tags ,category= self.get_asset_url(self,context,name,quality)
            if asset_url:
                if not os.path.isdir(preferences().materials_folder):
                    os.mkdir(preferences().materials_folder)
                if not os.path.isfile(f"{os.path.join(preferences().materials_folder,asset_name)}.{asset_type}"):
                    f = open(f"{os.path.join(preferences().materials_folder,asset_name)}.{asset_type}",'wb')
                    try:
                        response=s.get(asset_url,stream=True,verify=False)
                    except:
                        response=s.get(asset_url,stream=True,verify=certifi.where())
                    if response.status_code == 200:
                        size=eval(response.headers['Content-length'])
                        #print(size/(1024*1024)," MB")
                        i=0
                        wm.progress_begin(0, size)
                        for chunk in response.iter_content(chunk_size = 1024*256 ):
                            f.write(chunk)
                            i=i+1
                            #print(round(min(i*1024*256/size,1)*100,2),"%")
                            context.scene.downloadProgress=round(min(i*1024*256/size,1)*100,2)
                            wm.progress_update(round(min(i*1024*256/size,1)*100,2))
                        f.close()
                        #wm.progress_end()
                        if asset_type=='zip':
                    #        print(f"{os.path.join(os.path.dirname(__file__),json_data['foundAssets'][result_number]['assetId'])}.zip")
                            with zipfile.ZipFile(f"{os.path.join(preferences().materials_folder,asset_name)}.zip", 'r') as zip_ref:
                                zip_ref.extractall(f"{os.path.join(preferences().materials_folder,asset_name)}")
                            return f"{os.path.join(preferences().materials_folder,asset_name)}"
                else:
                    if os.path.exists(f"{os.path.join(preferences().materials_folder,asset_name)}"):
                        return f"{os.path.join(preferences().materials_folder,asset_name)}"
                    else:
                        with zipfile.ZipFile(f"{os.path.join(preferences().materials_folder,asset_name)}.zip", 'r') as zip_ref:
                            zip_ref.extractall(f"{os.path.join(preferences().materials_folder,asset_name)}")
                        return f"{os.path.join(preferences().materials_folder,asset_name)}"
        else:
            self.report({'WARNING'},"No Internet!")
    return None

def material_previews_from_directory_items(self, context):
    enum_items = []
    if context is None:
        return enum_items
    directory = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Previews/")
    if self.name=='Materials':
        pcoll = material_preview_collections['Materials']
    else:
        pcoll = material_preview_collections['Downloaded-Materials']
    if len(pcoll.my_previews) > 0:
        return pcoll.my_previews
    def_dir = directory
    #print(previews_generated)
    if directory and os.path.exists(def_dir):
        
        for i, name in enumerate(previews_generated if self.name=='Materials' else previews_generated_offline):
            #print(name)
            filepath = name
            # if filepath not in pcoll:
            #     thumb = pcoll.load(filepath, filepath, 'IMAGE')
            # else:
            #     thumb=pcoll[filepath]
            if os.path.isfile(filepath):
                thumb=pcoll.load_safe(str(name),str(name),'IMAGE')
                enum_items.append(
                    (",".join(qualities[i] if self.name=='Materials' else [os.path.basename(name).replace(".png",""),]+qualities_offline[i]), os.path.basename(name).replace(".png", ""), "", thumb.icon_id, i))
    pcoll.my_previews = enum_items
    return pcoll.my_previews

class MaterialInfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="name", default="")
    preview: bpy.props.EnumProperty(
        items=material_previews_from_directory_items)
class Import_Material_Panel(bpy.types.Operator):
    bl_idname = "rtools.import_material"
    bl_label = "Material Library"
    bl_description = "Search Materials Library Panel"
    bl_options = {'REGISTER', 'UNDO'}
    # bl_property="name"
    # bl_property="name"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        count = 0
        for item in context.scene.rt_materials:
                count = count+1
        layout = self.layout
        row=layout.row(align=True)
        #layout.ui_units_x = 5*min(count, 5)
        row.label(text="Material Library")
        row.prop(preferences(),'material_preset')
        if not isConnected():
            row.label(text="No Internet",icon='ERROR')
        column = layout.column()
        row = layout.row()
        row = row.split(factor=0.8)
        #row.active_default=True
        row.prop(context.scene.rt_tools, "materialToSearch", text="", text_ctxt="")
        
        row.operator("rtools.search_material", text="", icon="VIEWZOOM").offset=0
        layout.row().prop(context.scene.rt_tools, "material_categories")
        #layout.label(text=context.scene.downloadProgress)
        column = layout.grid_flow(row_major=True, columns=5)
        if len(material_preview_list) > 0:
            for i,item in enumerate(context.scene.rt_materials):
                
                    column2 = column.box()
                    row=column2.row()
                    row.label(text="AmbientCG" if i==0 else "Offline")
                    if i==1:
                        row.prop(context.scene.rt_tools,'show_all_offline',toggle=True)
                    column2.template_icon_view(
                        item, "preview", show_labels=True, scale=8, scale_popup=6)
                    row=column2.row(align=True)
                    row.scale_x=8
                    if i==0:
                        row.operator('rtools.search_material',icon='FRAME_PREV',text="Previous",text_ctxt="").offset=-1 
                        row.operator('rtools.search_material',icon='FRAME_NEXT',text="Next",text_ctxt="").offset=1
                    elif i==1:
                        row.operator('rtools.search_material',icon='FRAME_PREV',text="Previous",text_ctxt="").offset_offline=-1 
                        row.operator('rtools.search_material',icon='FRAME_NEXT',text="Next",text_ctxt="").offset_offline=1
                    for a in item.preview.split(',')[1:]:
                        row=column2.row(align=True)
                        asset_name=item.preview.split(',')[0]+"_"+a[:a.index("(")]+".blend"
                        pcoll = icon_collection["icons"]
                        check_icon = pcoll["check"]
                        if asset_name in self.files:
                        
                            button = row.operator(
                            "rtools.download_material", text=a,icon_value=check_icon.icon_id)
                        else:
                            button = row.operator(
                            "rtools.download_material", text=a)
                        button.name =item.preview.split(',')[0]
                        button.quality=a[:a.index("(")]
                        
                        
        

    def invoke(self, context, event):
        self.files=[]
        if bpy.app.version>=(3,0,0):
            lib_path=ensure_library("RanTools Materials",preferences().material_asset_library_folder)
            self.files=[f for f in os.listdir(lib_path)] if lib_path else []
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):

        return {'FINISHED'}
class RTOOLS_OT_Download_Material2(bpy.types.Operator):
    bl_idname = "rtools.download_material"
    bl_label = "Download"
    bl_description = "Download"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty(options={'HIDDEN'})
    quality: bpy.props.StringProperty(options={'HIDDEN'})
    def execute(self, context):
        selected_objects=context.selected_objects
        path=download_material(self,context,self.name,self.quality)
        if path:
            mat=setup_materials(self, context,folder_path=path)
            if mat and selected_objects:
                for ob in selected_objects:
                    if ob.data.materials:
                        ob.data.materials[ob.active_material_index]=mat[0]
                    else:
                        ob.data.materials.append(mat[0])
        return {'FINISHED'}
def getSize(folderPath):
    size=0
    for path, dirs, files in os.walk(folderPath):
        for f in files:
            fp = os.path.join(path, f)
            size += os.path.getsize(fp)
    return size
class RTOOLS_OT_Download_Material(bpy.types.Operator):

    bl_idname = "rtools.download_material"
    bl_label = "Download"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty(options={'HIDDEN'})
    quality: bpy.props.StringProperty(options={'HIDDEN'})
    timer = None
    running = False
    completed = False
    chunkSize = 512 * 1024
    downloaded = 0
    file = None
    response = None
    chunk = None
    @classmethod
    def description(cls, context, properties):
        if bpy.app.version >= (3,0,0):
            return  "Download\nCTRL+LMB: Mark as Asset"
        else:
            return  "Download"
    def modal(self, context, event):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if event.type == 'TIMER' and not self.running and not self.completed:
                
                self.file = open(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}",'wb')
                # req=urllib.request.Request(self.asset_url,headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'})
                # self.response = urllib.request.urlopen(req,timeout=10, context=ssl.create_default_context(cafile=certifi.where()))
                #print(self.asset_url)
                try:
                    self.response = s.get(self.asset_url, timeout=10,  stream=True,verify=False)
                except:
                    self.response = s.get(self.asset_url, timeout=10,  stream=True,verify=certifi.where())
                self.chunks = self.response.iter_content(chunk_size=self.chunkSize)
                self.running = True

            if event.type == 'TIMER' and self.running:
                try:
                    self.chunk = next(self.chunks, None)
                    #self.chunk = self.response.read(self.chunkSize)

                    if sys.getsizeof(self.chunk) < self.chunkSize: 
                        self.file.write(self.chunk)
                        self.downloaded += self.chunkSize
                        self.running = False
                        self.completed = True  
                        self.file.close()
                        if self.asset_type=='zip':
                        #        print(f"{os.path.join(os.path.dirname(__file__),json_data['foundAssets'][result_number]['assetId'])}.zip")
                                with zipfile.ZipFile(f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip", 'r') as zip_ref:
                                    zip_ref.extractall(f"{os.path.join(preferences().materials_folder,self.asset_name)}")
                                if preferences().delete_zips and os.path.exists(f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip"):
                                    os.remove(f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip")
                                path=None
                                if self.mark_asset:
                                    lib_path=ensure_library("RanTools Materials",preferences().material_asset_library_folder)
                                    if lib_path:
                                        blendname=self.asset_name
                                        #if bpy.data.is_saved:
                                        #    filename = bpy.path.basename(bpy.data.filepath)
                                        #    filename = os.path.splitext(filename)[0]
                                            #blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
                                        files = [file for file in os.listdir(lib_path)]
                                        i=0
                                        name=blendname
                                        fname=blendname
                                        already_exists=False
                                        while(fname+".blend" in files):
                                            fname = f"{name}_{i}"
                                            already_exists = True
                                            #print(fname)
                                            i+=1
                                        path=os.path.join(lib_path, fname+".blend")
                                mat=setup_materials(self, context,folder_path=f"{os.path.join(preferences().materials_folder,self.asset_name)}",lib_path=path,mark_asset=self.mark_asset and path and not already_exists,tags=self.tags)
                                if mat and context.active_object:
                                    if context.active_object.data.materials:
                                        context.active_object.data.materials[context.active_object.active_material_index]=mat[0]
                                    else:
                                        context.active_object.data.materials.append(mat[0])
                                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                                    csvFileWriter = csv.writer(
                                        csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                                    csvFileWriter.writerow(
                                        [self.name,self.quality+f"({round(eval(self.response.headers['content-length'])/1024/1024,2)} MB)",f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip",",".join(self.tags),self.category])
                        context.scene.downloadProgress = ""
                        #context.workspace.status_text_set(None)
                    else: 
                        self.file.write(self.chunk)
                        self.downloaded += self.chunkSize

                        progress = f"Status: {format(round((self.downloaded/1024/1024),2),'0.2f')}/{round(eval(self.response.headers['content-length'])/1024/1024,2)} MB"
                        context.scene.downloadProgress = progress
                        #print(context.scene.downloadProgress)
                        #bpy.context.workspace.status_text_set(progress)
                        context.area.tag_redraw()
                #print(context.scene.downloadProgress)
                except Exception as e:
                    if self.file:
                        self.file.close()
                    if os.path.exists(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}"):
                        os.remove(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}")
                    self.cancel(context)
                    self.report({'WARNING'},"ERROR!")
                    
                    print(e)
                    traceback.print_exc()
                    return {'CANCELLED'}
            if self.completed:
                self.cancel(context)
            if event.type=='ESC' and event.value=='PRESS':
                if self.file:
                        self.file.close()
                if os.path.exists(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}"):
                    os.remove(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}")
                self.cancel(context)
                self.report({'WARNING'},"Cancelled")
                return {'CANCELLED'}
        
        return {'PASS_THROUGH'}


    def execute(self, context):
        self.completed = False
        wm = context.window_manager
        self.asset_url,self.asset_name,self.asset_type,self.tags,self.category=get_asset_url(self, context,self.name,self.quality)
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()
        
        if self.asset_url:
            path=None
            if self.mark_asset:
                lib_path=ensure_library("RanTools Materials",preferences().material_asset_library_folder)
                if lib_path:
                    blendname=self.asset_name if self.asset_name else "Material"
                    # if bpy.data.is_saved:
                    #     filename = bpy.path.basename(bpy.data.filepath)
                    #     filename = os.path.splitext(filename)[0]
                    #     blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
                    files = [file for file in os.listdir(lib_path)]
                    i=0
                    name=blendname
                    fname=blendname
                    already_exists=False
                    while(fname+".blend" in files):
                        fname = f"{name}_{i}"
                        already_exists = True
                        #print(fname)
                        i+=1
                    path=os.path.join(lib_path, fname+".blend")
            if not os.path.isdir(preferences().materials_folder):
                    os.mkdir(preferences().materials_folder)
            if not os.path.isfile(f"{os.path.join(preferences().materials_folder,self.asset_name)}.{self.asset_type}") and not os.path.exists(f"{os.path.join(preferences().materials_folder,self.asset_name)}"):
                
                    self.timer = wm.event_timer_add(0.05,window= context.window)
                    wm.modal_handler_add(self)
                    self.running = False
                    return {'RUNNING_MODAL'}
            else:
                if os.path.exists(f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip"):
                    with zipfile.ZipFile(f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip", 'r') as zip_ref:
                        zip_ref.extractall(f"{os.path.join(preferences().materials_folder,self.asset_name)}")
                    
                else:
                    pass
                if os.path.isdir(f"{os.path.join(preferences().materials_folder,self.asset_name)}"):
                    mat=setup_materials(self, context,folder_path=f"{os.path.join(preferences().materials_folder,self.asset_name)}",lib_path=path,mark_asset=self.mark_asset and path and not already_exists,tags=self.tags)
                    if mat and context.active_object:
                        if context.active_object.data.materials:
                            context.active_object.data.materials[context.active_object.active_material_index]=mat[0]
                        else:
                            context.active_object.data.materials.append(mat[0])
                    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                        reader= csv.reader(csvFile, delimiter=',')
                        reader=[[row[0],row[2]] for row in reader]
                        if [self.name,f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip"] not in reader:

                            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                                            csvFileWriter = csv.writer(
                                                csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                                            
                                            csvFileWriter.writerow(
                                                [self.name,self.quality+f"({round(getSize(f'{os.path.join(preferences().materials_folder,self.asset_name)}')/1024/1024,2)} MB)",f"{os.path.join(preferences().materials_folder,self.asset_name)}.zip",",".join(self.tags),self.category])
        else:
            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","Dowloaded-Materials.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                reader= csv.reader(csvFile, delimiter=',')
                for row in reader:
                    #(self.name,self.quality)
                    #print(row[0],row[1][:row[1].index("(")])
                    if row[0]==self.name and row[1][:row[1].index("(")]==self.quality:
                        if os.path.exists(row[2]):
                            with zipfile.ZipFile(row[2], 'r') as zip_ref:
                                zip_ref.extractall(row[2].replace(".zip",""))
                        if os.path.isdir(row[2].replace(".zip","")):
                            path=None
                            if self.mark_asset:
                                lib_path=ensure_library("RanTools Materials",preferences().material_asset_library_folder)
                                if lib_path:
                                    blendname=row[0]
                                    # if bpy.data.is_saved:
                                    #     filename = bpy.path.basename(bpy.data.filepath)
                                    #     filename = os.path.splitext(filename)[0]
                                    #     blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
                                    files = [file for file in os.listdir(lib_path)]
                                    i=0
                                    name=blendname
                                    fname=blendname
                                    already_exists=False
                                    while(fname+".blend" in files):
                                        fname = f"{name}_{i}"
                                        already_exists = True
                                        #print(fname)
                                        i+=1
                                    path=os.path.join(lib_path, fname+".blend")
                            mat=setup_materials(self, context,folder_path=row[2].replace(".zip",""),lib_path=path,mark_asset=self.mark_asset and path and not already_exists,tags=row[3].split(','))
                            if mat and context.active_object:
                                if context.active_object.data.materials:
                                    context.active_object.data.materials[context.active_object.active_material_index]=mat[0]
                                else:
                                    context.active_object.data.materials.append(mat[0])
        return {'FINISHED'}
    def invoke(self, context,event):
        #print(context.workspace)
        #bpy.context.workspace.status_text_set(None)
        self.mark_asset=event.ctrl and bpy.app.version>=(3,0,0)
        
        if event.ctrl and self.mark_asset:
            ensure_library("RanTools Materials",preferences().material_asset_library_folder)
            if "rantools materials" not in [a.name.lower() for a in bpy.context.preferences.filepaths.asset_libraries]:
                self.report({'WARNING'},"No 'RanTools Materials' asset library found (Create in preferences)!")
                return {'CANCELLED'}
        return self.execute(context)
    def cancel(self, context):
        context.workspace.status_text_set(None)
        wm = context.window_manager
        wm.event_timer_remove(self.timer)
def search_material(self, context,offset,offset_offline):
        context.scene.rt_materials.clear()
        (paths,quality) =getPreviewsPar(self,context.scene.rt_tools.materialToSearch,category=context.scene.rt_tools.material_categories,offset=offset)    
        global previews_generated
        previews_generated=paths
        global qualities
        qualities=quality
        (paths_offline,quality_offline)=getPreviewsOffline(context.scene.rt_tools.materialToSearch if not context.scene.rt_tools.show_all_offline else "",offset=offset_offline,category=context.scene.rt_tools.material_categories if context.scene.rt_tools.material_categories!='All' else '')
        global previews_generated_offline
        previews_generated_offline=paths_offline
        global qualities_offline
        qualities_offline=quality_offline
        for pcoll in material_preview_collections.values():
            pcoll.clear()
            bpy.utils.previews.remove(pcoll)
        material_preview_collections.clear()
        material_preview_list.clear()
        temp = bpy.context.scene.rt_materials.add()
        temp.name = 'Materials'
        material_preview_list['Materials'] = paths
        pcoll = previews.new()
        pcoll.my_previews = ()
        material_preview_collections['Materials'] = pcoll
        temp = bpy.context.scene.rt_materials.add()
        temp.name = 'Downloaded-Materials'
        material_preview_list['Downloaded-Materials'] = paths_offline
        pcoll2 = previews.new()
        pcoll2.my_previews = ()
        material_preview_collections['Downloaded-Materials'] = pcoll2
def search_material_update(self, context):
    #pass
    context.scene.rt_tools.pageIndex=0
    search_material(self,context,offset=0,offset_offline=context.scene.rt_tools.pageIndexOffline)
def show_all_material_update(self, context):
    #pass
    #context.scene.rt_tools.pageIndex=0
    search_material(self,context,offset=0,offset_offline=context.scene.rt_tools.pageIndexOffline)
class RTOOLS_OT_Search_Material(bpy.types.Operator):
    bl_idname = "rtools.search_material"
    bl_label = "Search"
    bl_description = "Search"
    bl_options = {'REGISTER', 'UNDO'}
    offset:bpy.props.IntProperty(default=0,options={'SKIP_SAVE','HIDDEN'})
    offset_offline:bpy.props.IntProperty(default=0,options={'SKIP_SAVE','HIDDEN'})
    # bl_property="name"
    @classmethod
    def description(cls, context, properties):
        if properties.offset==1:
            return translate_text("Next Page")
        elif properties.offset==-1:
            return translate_text("Previous Page")
        else:
            return translate_text("Search")
    def execute(self, context):
        if self.offset==1:
            context.scene.rt_tools.pageIndex=context.scene.rt_tools.pageIndex+1
        elif self.offset==-1:
            context.scene.rt_tools.pageIndex=max(0,context.scene.rt_tools.pageIndex-1)
        else:
            context.scene.rt_tools.pageIndex=0
        if self.offset_offline==1:
            context.scene.rt_tools.pageIndexOffline=context.scene.rt_tools.pageIndexOffline+1
        elif self.offset_offline==-1:
            context.scene.rt_tools.pageIndexOffline=max(0,context.scene.rt_tools.pageIndexOffline-1)
        else:
            context.scene.rt_tools.pageIndexOffline=0
        search_material(self,context,offset=context.scene.rt_tools.pageIndex,offset_offline=context.scene.rt_tools.pageIndexOffline)

        return {'FINISHED'}