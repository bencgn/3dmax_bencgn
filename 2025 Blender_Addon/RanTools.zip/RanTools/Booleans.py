import bpy
from . utils import *
from mathutils import Vector,Matrix,geometry
import bmesh
from mathutils.bvhtree import BVHTree
from bpy_extras import view3d_utils
import gpu
import bgl
import random


    #return f"{random_id_source[random.randint(0,61)]}{random_id_source[random.randint(0,61)]}{random_id_source[random.randint(0,61)]}{random_id_source[random.randint(0,61)]}{random_id_source[random.randint(0,61)]}{random_id_source[random.randint(0,61)]}"
from gpu_extras.batch import batch_for_shader
activeProps={"ARRAY":('count',),
'BEVEL':('width','angle_limit','profile'),
'SCREW':('screw_offset','angle'),
'SOLIDIFY':('thickness','offset'),
'SUBSURF':('levels',),
'WELD':('merge_threshold',),
'CAST':('radius',),
'DISPLACE':('strength','mid_level'),
'SHRINKWRAP':('offset',),
'SIMPLE_DEFORM':('angle',),
'SMOOTH':('factor',),
'WEIGHTED_NORMAL':('weight',)}
events={'MINUS':'-','NUMPAD_MINUS':'-','ZERO' :0,'ONE':1,'TWO' :2,'THREE': 3,'FOUR': 4,'FIVE': 5,'SIX' :6,'SEVEN': 7,'EIGHT': 8,'NINE': 9,'PERIOD':'.','NUMPAD_1':1,'NUMPAD_2':2,'NUMPAD_3':3,'NUMPAD_4':4,'NUMPAD_5':5,'NUMPAD_6':6,'NUMPAD_7':7,'NUMPAD_8':8,'NUMPAD_9':9,'NUMPAD_0':0,'NUMPAD_PERIOD':'.'}
cutter_names={'POLYGON':'Cutter','BOX':'Cube','CIRCLE':'Cylinder'}

solver_to_use='FAST'
grid_offset=0.003
def find_shoot_distance2(origin,direction,target,bool_obj,scene):
    og_origin=origin
    #origin=origin-direction
    bool_obj.hide_view=True
    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    hidden_objs=[]
    print(location,object)
    while ( (object and object!=target)):
        print(object)
        hidden_objs.append((object,object.hide_get()))
        object.hide_view=True
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    print(location,object)
    origin=location
    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    while ( (object and object!=target)):
    
        hidden_objs.append((object,object.hide_get()))
        object.hide_view=True
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    print(location)
    for o,s in hidden_objs:
        o.hide_view=s
    bool_obj.hide_view=False
    #print((og_origin-location).length+0.010)
    return (og_origin-location).length+0.010
def get_grid_points_for_object(obj,resolution=6):
    bm = bmesh.new()
    #print(max(bool_obj.dimensions))
    res=int(max(obj.dimensions)*resolution)
    verts=bmesh.ops.create_grid(bm, x_segments=res,y_segments=res,size= max(obj.dimensions)/2,matrix=obj.matrix_world,calc_uvs=False)
    verts=[v.co.copy() for v in verts['verts']]
    #print(verts)
   # mesh_data = bpy.data.meshes.new("Circle")
    #bm.to_mesh(mesh_data)
    #mesh_obj = bpy.data.objects.new("Circle", mesh_data)
    #bpy.context.collection.objects.link(mesh_obj)
    bm.free()
    #print(verts)
    return verts
def find_shoot_distance(origin,direction,target,bool_obj,scene):
    extra=1.1
    og_origin=origin.copy()
    #print("Origin",origin)
    #origin=origin-direction
    distances=[]
    
    
    verts=get_grid_points_for_object(bool_obj)
    iterations=30
    bool_obj.hide_view=True
    #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    
    hidden_objs=[]
    for v in verts+[og_origin,]:
        #print("Trying",v)
        origin=v.copy()
        last_location=origin.copy()
        for i in range(iterations):
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
            if result:
                origin=location+(direction*0.001)
            #print(location)
            if object==target:
                #print(location)
                last_location=location.copy()
        bool_obj.hide_view=False
        #print(og_origin,last_location)
        #print((og_origin-last_location).length+0.010)
        distances.append((v-last_location).length*extra)
    #print(distances)
    #print(max(distances))
    return max(distances)
def find_shoot_distance3(origin,direction,target,bool_obj,scene):
    extra=1.1
    og_origin=origin
    #origin=origin-direction
    bm = bmesh.new()
    res=10
    verts=bmesh.ops.create_grid(bm, res,res, 1,target.matrix_world,False)
    print(verts)
    iterations=100
    bool_obj.hide_view=True
    #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
    
    hidden_objs=[]
    last_location=og_origin
    for i in range(iterations):
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),origin, direction)
        if result:
            origin=location+(direction*0.001)
        #print(location)
        if object==target:
            last_location=location
    bool_obj.hide_view=False
    #print(og_origin,last_location)
    #print((og_origin-last_location).length+0.010)
    return (og_origin-last_location).length*extra
class RTOOLS_Cutters_Panel(bpy.types.Operator):
    bl_label = "Cutters List"
    bl_idname = "rtools.cutterspanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.active_object and len(context.active_object.CuttersInfo) 
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        #start=time.time()
        if self.cutters:
            draw_Text(context,0,preferences().font_size,text=[f"SHIFT+A: Apply Modifiers and Delete all Cutters",f"E : Solver ({self.last_solver})",f"X : Delete Cutter","A : Apply Modifier","CTRL + LMB : Select cutter","[LMB] : Edit Cutter"],alignH='RIGHT',activeKey=self.activeKey)
            self.button_coords=draw_buttons(context,0,16,text=[a.name for (a,b) in self.cutters],alignH='LEFT',activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y,box_start_x=self.init_x,box_start_y=self.init_y,draw_down_triangle=self.start_index>0,draw_up_triangle=self.start_index+self.cutters_to_show<self.cutters_available)
        #print( "Time ; ",time.time()-start)    
    """def draw(self, context):
        
        
        if context.active_object:
            layout = self.layout
            layout.label(text="Cutters")
            layout.operator_context = "INVOKE_DEFAULT"
            #layout.separator_spacer()
            column=layout.column()
            for i,t in enumerate(context.active_object.CuttersInfo):
                #cutter=bpy.data.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in bpy.data.objects] else None
                #print(t.cutter_id)
                
                cutter=[a for a in bpy.data.objects if a.CutterId==t.cutter_id][0] if [a for a in bpy.data.objects if a.CutterId==t.cutter_id] else None
                if cutter:
                    column.separator(factor=0.2)
                    row=column.row()
                    
                    row=row.box()
                    row=row.split(factor=0.5)
                    row.label(text=t.last_cutter)
                    
                    if not cutter.visible_get():
                        row.prop(cutter, "hide_view", text="",emboss=False, icon="HIDE_ON")
                    else:
                        row.prop(cutter, "hide_view", text="",emboss=False, icon="HIDE_OFF")
                    row.operator('rtools.recallcutter',icon='GREASEPENCIL',text="").index=i"""
    def modal(self,context,event):
        
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        
        
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            i=current_selection(self.mouse_x,self.mouse_y,self.button_coords)
            if i is not None :
                if not event.ctrl:
                    deselect_all()
                    select(self.active_object)
                    bpy.ops.rtools.recallcutter('INVOKE_DEFAULT',index=self.cutters[i][1])
                    for c in [a for a,b in self.all_cutters]:
                        if c!=self.cutters[i][0]:
                            try:
                                c.hide_set(True)
                            except:
                                pass
                else:
                    for c in [a for a,b in self.all_cutters]:
                        if c!=self.last_cutter:
                            try:
                                c.hide_set(True)
                            except:
                                pass
            else:
                for c in [a for a,b in self.all_cutters]:
                        try:
                            c.hide_set(True)
                        except:
                            pass
            #for c in [a for a,b in self.all_cutters if a not in self.hidden_cutters]:
            #        c.hide_view=False
            deselect_all()
            if self.last_cutter:
                select(self.last_cutter)
            else:
                select(self.active_object)
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif (event.type=='RIGHTMOUSE' or event.type=='ESC') and event.value=='PRESS':
            for c in [a for a,b in self.all_cutters]:
                    try:
                        c.hide_set(True)
                    except:
                        pass
            #for c in [a for a,b in self.all_cutters if a not in self.hidden_cutters]:
                    #print(c)
            #        c.hide_view=False
            #print(current_selection(self.mouse_x,self.mouse_y,self.button_coords))
            select(self.active_object)
            self.remove_drawHandler(context)
            return {'CANCELLED'}
        elif event.type=='E':
            if event.value=='PRESS':
                i=current_selection(self.mouse_x,self.mouse_y,self.button_coords)
                if i is not None:
                    for m in self.active_object.modifiers:
                        if m.type=='BOOLEAN' and m.object==self.cutters[i][0]:
                            try:
                                m.solver='EXACT' if m.solver=='FAST' else 'FAST'
                            except:
                                pass
                self.activeKey='E'
            else:
                self.activeKey=None
        elif event.type=='X' :
            if event.value=='PRESS':
                i=current_selection(self.mouse_x,self.mouse_y,self.button_coords)
                if i is not None:
                    delete_object_with_data(self.cutters[i][0])
                    self.last_cutter=None
                self.cutters=[]
                self.activeKey=None
                self.button_coords=[]
                for i,t in enumerate(self.active_object.CuttersInfo):
                    #cutter=bpy.data.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in bpy.data.objects] else None
                    #print(t.cutter_id)
                    
                    cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                    if cutter :
                        self.cutters.append((cutter,i))
                self.cutters_available=len(self.cutters)
                self.cutters_to_show=min(20,self.cutters_available)
                self.all_cutters=self.cutters[:]
                self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
                self.activeKey='X'
                
            else:
                self.activeKey=None
        elif event.type=='A':
            if not event.shift:
                if event.value=='PRESS':
                    i=current_selection(self.mouse_x,self.mouse_y,self.button_coords)
                    if i is not None:
                        for m in self.active_object.modifiers:
                            if m.type=='BOOLEAN' and m.object==self.cutters[i][0]:
                                try:
                                    bpy.ops.object.modifier_apply({'object':self.active_object},modifier=m.name)
                                except:
                                    pass
                        delete_object_with_data(self.cutters[i][0])
                        self.last_cutter=None
                    self.cutters=[]
                    self.last_cutter=None
                    self.button_coords=[]
                    for i,t in enumerate(self.active_object.CuttersInfo):
                        #cutter=context.view_layer.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in context.view_layer.objects] else None
                        #print(t.cutter_id)
                        
                        cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                        if cutter :
                            self.cutters.append((cutter,i))
                    self.cutters_available=len(self.cutters)
                    self.cutters_to_show=min(20,self.cutters_available)
                    self.all_cutters=self.cutters[:]
                    self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
                    self.activeKey='A'
                else:
                    self.activeKey=None
            else:
                if event.value=='PRESS':
                    for c in self.cutters:

                        for m in self.active_object.modifiers:
                                try:
                                    bpy.ops.object.modifier_apply({'object':self.active_object},modifier=m.name)
                                except:
                                    pass
                        for child in c[0].children:
                            if child.specialInfo=='MirrorEmpty' or child.specialInfo=="RadialArrayEmpty":
                                delete_object(child)
                        delete_object_with_data(c[0])
                        self.last_cutter=None
                    self.active_object.CuttersInfo.clear()
                    self.cutters=[]
                    self.last_cutter=None
                    self.button_coords=[]
                    for i,t in enumerate(self.active_object.CuttersInfo):
                        #cutter=context.view_layer.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in context.view_layer.objects] else None
                        #print(t.cutter_id)
                        
                        cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                        if cutter :
                            self.cutters.append((cutter,i))
                    self.cutters_available=len(self.cutters)
                    self.cutters_to_show=min(20,self.cutters_available)
                    self.all_cutters=self.cutters[:]
                    self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
                    self.activeKey='SHIFT+A'
                else:
                    self.activeKey=None
                self.remove_drawHandler(context)
                return {'FINISHED'}
        elif event.type=='MIDDLEMOUSE' :
            return {'PASS_THROUGH'}
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.start_index-=1
            self.start_index=max(0,self.start_index)
            self.cutters=[]
            self.activeKey=None
            self.button_coords=[]
            for i,t in enumerate(self.active_object.CuttersInfo):
                #cutter=context.view_layer.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in context.view_layer.objects] else None
                #print(t.cutter_id)
                
                cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                if cutter :
                    self.cutters.append((cutter,i))
            self.cutters_available=len(self.cutters)
            self.cutters_to_show=min(20,self.cutters_available)
            self.all_cutters=self.cutters[:]
            self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
        elif (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.start_index+=1
            self.start_index=min(self.cutters_available-self.cutters_to_show,self.start_index)
            self.cutters=[]
            self.activeKey=None
            self.button_coords=[]
            for i,t in enumerate(self.active_object.CuttersInfo):
                #cutter=context.view_layer.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in context.view_layer.objects] else None
                #print(t.cutter_id)
                
                cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                if cutter:
                    self.cutters.append((cutter,i))
            self.cutters_available=len(self.cutters)
            self.cutters_to_show=min(20,self.cutters_available)
            self.all_cutters=self.cutters[:]
            self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
        #t=time.time()
        selection=current_selection(self.mouse_x,self.mouse_y,self.button_coords)
        #print(time.time()-t)
        #print(selection)
        if selection is not None:
            cutter=self.cutters[selection][0]
            cutter.hide_set(False)
            self.last_cutter=cutter
            for m in self.active_object.modifiers:
                if m.type=='BOOLEAN' and m.object==cutter:
                    self.last_solver=m.solver
            select(cutter)
            for c in [a for a,b in self.all_cutters]:
                if c!=cutter:
                    try:
                        c.hide_set(True)
                    except:
                        pass
        else:
            self.last_solver=""
            for c in [a for a,b in self.all_cutters ]:
                    try:
                        c.hide_set(True)
                    except:
                        pass
        
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        
        self.last_cutter=None
        self.last_solver=""
        self.start_index=0
        self.cutters_to_show=5
        self.active_object=context.active_object
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        self.init_x=event.mouse_region_x
        self.init_y=event.mouse_region_y
        self.cutters=[]
        self.activeKey=None
        self.hidden_cutters=[]
        self.button_coords=[]
        self.cutters_in_modifiers=[]
        for a in [b for b in self.active_object.modifiers if b.type=='BOOLEAN']:
            if a.object:
                self.cutters_in_modifiers.append(a.object)
        for i,t in enumerate(context.active_object.CuttersInfo):
                #cutter=context.view_layer.objects[t.last_cutter] if t.cutter_id in [a.CutterId for a in context.view_layer.objects] else None
                #print(t.cutter_id)
                
                cutter=[a for a in context.view_layer.objects if a.CutterId==t.cutter_id][0] if [a for a in context.view_layer.objects if a.CutterId==t.cutter_id] else None
                if cutter:
                    self.cutters.append((cutter,i))
                    if not cutter.visible_get():
                        self.hidden_cutters.append(cutter)
        self.cutters_available=len(self.cutters)
        self.cutters_to_show=min(20,self.cutters_available)
        self.all_cutters=self.cutters[:]
        self.cutters=self.cutters[self.start_index:self.start_index+self.cutters_to_show]
        self.add_drawHandler(context)
        context.window_manager.modal_handler_add(self)
        #return context.window_manager.invoke_popup(self,width=200)
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Recall_Cutter(bpy.types.Operator):
    bl_idname = "rtools.recallcutter"
    bl_label = "Recall Cutter"
    bl_description = "Recall Cutter used in P-Cutter"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty(options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def execute(self,context):
        rt_tools=context.scene.rt_tools
        active_object=context.active_object
        if self.index >=0   and active_object.CuttersInfo[self.index].last_cutter :
            if active_object.CuttersInfo[self.index].last_cutter in [a.name for a in context.scene.objects]:
                deselect_all()
                select(active_object)
                cutter=context.view_layer.objects[active_object.CuttersInfo[self.index].last_cutter]   if active_object.CuttersInfo[self.index].last_cutter in [a.name for a in context.view_layer.objects] else None
                if cutter:
                    cutter.hide_view=False
                    cutter.hide_viewport=False
                    
                    if active_object.CuttersInfo[self.index].mods_applied or "RT_SOLIDIFY" not in [m.name for m in cutter.modifiers]:
                        deselect_all()
                        select(cutter)
                        bpy.ops.object.editmode_toggle()
                    else:
                        select(cutter)
                        extra_1=[a for a in context.view_layer.objects if a.CutterId==active_object.CuttersInfo[self.index].cutter_extra_1][0].name if [a for a in context.view_layer.objects if a.CutterId==active_object.CuttersInfo[self.index].cutter_extra_1] and active_object.CuttersInfo[self.index].cutter_extra_1 else ""
                        extra_2=[a for a in context.view_layer.objects if a.CutterId==active_object.CuttersInfo[self.index].cutter_extra_2][0].name if [a for a in context.view_layer.objects if a.CutterId==active_object.CuttersInfo[self.index].cutter_extra_2] and active_object.CuttersInfo[self.index].cutter_extra_2 else ""
                        #context.window.cursor_warp(context.region.x+context.region.width/4,context.region.height/2)
                        cutterInfo=active_object.CuttersInfo[self.index]
                        #if cutter.dimensions==Vector((0,0,0)):
                        #    self.report({'WARNING'},"Cutter has Invalid Geometry!")
                        bpy.ops.rtools.createboolean('INVOKE_DEFAULT',normal_prop=cutterInfo.normal,center_location=cutter.location,direction=cutterInfo.direction,recalled="Panel",last_bool_type=cutterInfo.last_bool_type,cutter_extra_2=extra_2,cutter_extra_1=extra_1,last_mod_name=cutterInfo.last_mod_name,last_inset_mod=cutterInfo.last_inset_mod,cutter_index=self.index,bevel_mod=cutterInfo.new_bevel_mod)
            else:
                self.report({'WARNING'},"Cutter not Available!")
        return {'FINISHED'}            
def is_alt_down(self,event):
    return self.tab_down if preferences().industry_keymap else event.alt
class RTOOLS_OT_Draw_Boolean(bpy.types.Operator):
    bl_idname = "rtools.createboolean"
    bl_label = "Draw Booleans"
    bl_description = "Draw Booleans"
    bl_options = {"REGISTER","UNDO"}
    center_location:bpy.props.FloatVectorProperty(size=3)
    draw:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE'})
    from_inset_shrink:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE'})
    recalled:bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    last_bool_type:bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    cutter_extra_1:bpy.props.StringProperty(default="",options={'SKIP_SAVE'},name="Extra 1")
    cutter_extra_2:bpy.props.StringProperty(default="",options={'SKIP_SAVE'},name="Extra 2")
    last_mod_name:bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    last_inset_mod:bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    bevel_mod:bpy.props.StringProperty(default="",options={'SKIP_SAVE'})
    cutter_index:bpy.props.IntProperty(default=-1,options={'SKIP_SAVE'})
    direction:bpy.props.IntProperty(default=-1,options={'SKIP_SAVE'})
    normal_prop:bpy.props.FloatVectorProperty(size=3,options={'SKIP_SAVE'})
    fast_mode:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE'})
    internal_atv:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE'})
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        
        if self.array_adjust_mode:
            offset=max(getattr(self.linear_array_mod,'relative_offset_displace'),key=abs)
            draw_Text(context,0,preferences().font_size,text=[f"{'Offset'} : {format(round(offset,3),'.3f')}",f"{'Count'} : {getattr(self.linear_array_mod,'count')}",f"{'Axis'} : {self.adjust_axis}"],alignH="CENTER",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
            if  self.show_help:
                if self.bool_type:
                    draw_Text(context,0,preferences().font_size,text=["LMB : Confirm Array","E : Cancel Array","X/Y/Z : Array Axis","line","S : Slice","C : Inset","I : Intersect","D : Difference","U : Union","Change Mode :"],alignH="RIGHT",activeKey=self.activeKey)
                else:
                    draw_Text(context,0,preferences().font_size,text=["LMB : Confirm Array","E : Cancel Array","X/Y/Z : Array Axis"],alignH="RIGHT",activeKey=self.activeKey)
        elif self.radius_adjust_mod:
            draw_Text(context,0,preferences().font_size,text=[f"{'Count'} : {getattr(self.array_mod,'count')}",f"{'Radius'} : {round(getattr(self.displace_mod,'strength'),3)}"],alignH="CENTER",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
            if  self.show_help:
                if self.bool_type:
                    draw_Text(context,0,preferences().font_size,text=["LMB : Confirm Array","R : Cancel Array","Q : Array Center","F : Array Axis","line","S : Slice","C : Inset","I : Intersect","D : Difference","U : Union","Change Mode :"],alignH="RIGHT",activeKey=self.activeKey)
                
                else:
                    draw_Text(context,0,preferences().font_size,text=["LMB : Confirm Array","R : Cancel Array","Q : Array Center","F : Array Axis"],alignH="RIGHT",activeKey=self.activeKey)
            
        elif self.mod is not None and self.activeProp is not None and self.activeProp2 is not None :
            s1=self.activeProp.replace("_"," ").capitalize()
            
            s2=self.activeProp2.replace("_"," ").capitalize()
            activePropValue=getattr(self.mod,self.activeProp) if 'angle' not in s1.lower() else math.degrees(getattr(self.mod,self.activeProp))
            MirrorAxis=[]
            if self.mirror_mod.use_axis[0]:
                MirrorAxis+=["X",]  if not self.mirror_mod.use_bisect_flip_axis[0] else ["-X",]
            if self.mirror_mod.use_axis[1]:
                MirrorAxis+=["Y",]  if not self.mirror_mod.use_bisect_flip_axis[1] else ["-Y",]
            if self.mirror_mod.use_axis[2]:
                MirrorAxis+=["Z",]  if not self.mirror_mod.use_bisect_flip_axis[2] else ["-Z",]
            
            MirrorAxis="|".join(MirrorAxis)
            draw_Text(context,0,preferences().font_size,text=[f"Mirror : {MirrorAxis}" if MirrorAxis else "",f"{s1} : {format(round(activePropValue,3),'.3f')}",f"{s2} : {getattr(self.mod,self.activeProp2)}"],alignH="CENTER",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
        elif self.mod is not None and self.activeProp is not None :
            s1=self.activeProp.replace("_"," ").capitalize()
            MirrorAxis=[]
            if self.mirror_mod.use_axis[0]:
                MirrorAxis+=["X",]  if not self.mirror_mod.use_bisect_flip_axis[0] else ["-X",]
            if self.mirror_mod.use_axis[1]:
                MirrorAxis+=["Y",]  if not self.mirror_mod.use_bisect_flip_axis[1] else ["-Y",]
            if self.mirror_mod.use_axis[2]:
                MirrorAxis+=["Z",]  if not self.mirror_mod.use_bisect_flip_axis[2] else ["-Z",]
            
            MirrorAxis="|".join(MirrorAxis)
            #print(MirrorAxis)
            draw_Text(context,0,preferences().font_size,text=[f"Mirror : {MirrorAxis}" if MirrorAxis else "",f"{s1} : {format(round(getattr(self.mod,self.activeProp),3),'0.3f')}"],alignH="CENTER",activeKey=self.activeKey,start_x=self.mouse_x,start_y=self.mouse_y)
        if not self.radius_adjust_mod and not self.array_adjust_mode and  self.show_help:
                if self.bool_type=='INSET' or self.bool_type=='SLICE':
                    draw_Text(context,0,preferences().font_size,text=[f"TAB : Keep Shape ({'ON' if self.keep_boolean else 'OFF'})","W : Toggle Wireframe","E : Array","R : Radial Array",f"O : Mirror Object ({(self.mirror_mod.mirror_object.name if not self.mirror_mod.mirror_object.type=='EMPTY' else 'Face') if self.mirror_mod.mirror_object else 'Self'})","ALT+X/Y/Z : Flip Mirror Axis","X/Y/Z : Mirror","CTRL+B : New Bevel","V : Vertex Bevel","B : Bevel","F1 : Shoot Through","T : Thickness",'G : Line Thickness' if self.is_line else '','M : Solidify Thickness Mode',"A : Inset Amount","line","S : Slice","C : Inset","I : Intersect","D : Difference","U : Union","Change Mode :"],alignH="RIGHT",activeKey=self.activeKey)
                else:
                    draw_Text(context,0,preferences().font_size,text=[f"TAB : Keep Shape ({'ON' if self.keep_boolean else 'OFF'})","W : Toggle Wireframe","E : Array","R : Radial Array",f"O : Mirror Object ({(self.mirror_mod.mirror_object.name if not self.mirror_mod.mirror_object.type=='EMPTY' else 'Face') if self.mirror_mod.mirror_object else 'Self'})","ALT+X/Y/Z : Flip Mirror Axis","X/Y/Z : Mirror","CTRL+B : New Bevel" if not self.draw else "","V : Vertex Bevel","B : Bevel","F1 : Shoot Through","T : Thickness",'G : Line Thickness' if self.is_line else '',"line","S : Slice","C : Inset","I : Intersect","D : Difference","U : Union","Change Mode :"],alignH="RIGHT",activeKey=self.activeKey)
        if self.bool_type :
            
            draw_Text(context,0,preferences().font_size,text=[f"Mode : {self.bool_type}"],alignV='TOP',alignH="CENTER",activeKey=self.activeKey)
            #draw_Text(context,0,preferences().font_size,text=["S : Slice","C : Inset","I : Intersect","D : Difference","U : Union","Change Mode :"],alignH="LEFT",activeKey=self.activeKey)
        draw_Text(context,0,preferences().font_size,text=[f"H : {'Show' if not self.show_help else 'Hide'} Help"],alignH="LEFT",activeKey=self.activeKey)
    def add_array(self,context):
        array_mod=self.bool_obj.modifiers.get('RT_ARRAY')
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        self.empty=context.active_object
        self.empty.specialInfo='RadialArrayEmpty'
       #empty.location=self.center_location
        rt_cutters=get_collection(name='RT_Cutters')
        move_to_collection(self.empty,rt_cutters)
        #self.bool_obj.location=self.center_location
        self.empty.parent=self.bool_obj
        array_mod.offset_object=self.empty
        array_mod.use_relative_offset=False
        array_mod.use_object_offset=True
        #empty.rotation_euler=self.bool_obj.rotation_euler.copy()
        self.empty.hide_view=True
        
        driver=self.empty.driver_add("rotation_euler",2)
        var = driver.driver.variables.new()
        var.name = "Count"
        var.targets[0].data_path = 'modifiers["RT_ARRAY"].count'
        var.targets[0].id_type='OBJECT'
        var.targets[0].id = self.bool_obj
        driver.driver.expression = "2*pi/Count"
        driver.driver.expression += " "
        driver.driver.expression = driver.driver.expression[:-1]
    def change_boolean_type(self, context,bool_type):
        
        if bool_type=='SLICE' and self.bool_type!='SLICE':
            self.bevel_mod_2.invert_vertex_group=False
            for o in self.extra_objects_created:
                delete_object_with_data(o)
            for mod in self.modifiers_created:
                if mod in self.obj.modifiers[:]:
                    self.obj.modifiers.remove(mod)
                elif mod in self.bool_obj.modifiers[:]:
                    self.bool_obj.modifiers.remove(mod)
            self.extra_objects_created=[]
            self.modifiers_created=[]
            self.bool_type='SLICE'
            obj=self.obj
            bool=self.bool_obj
            bool.location=self.last_location
            obj_dup=duplicate_object(obj)
            obj_dup.CutterId=get_id()
            #deselect_all()
            #select(bool)
            #bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
            bool_dup=context.active_object
            #print(bool_dup)
            bool_dup=duplicate_object(bool)
            bool_dup.CutterId=get_id()
            if preferences().apply_bools_slice_mod:
                #print("After ",self.init_mods[:])
                smart_apply_modifiers(obj_dup,self.init_mods)
            self.extra_objects_created.append(bool_dup)
            self.extra_objects_created.append(obj_dup)
            
            deselect_all()
            select(bool_dup)
            select(bool)
            #bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            bpy.ops.object.parent_set()
            deselect_all()
            select(bool)

            select(obj_dup)
            select(obj)
            #bool_dup.location=[0,0,0]
            #bool_dup.scale=[1,1,1]
            #bool_dup.rotation_euler=[0,0,0]
            #bool_dup.matrix_world=bool.matrix_world.inverted()@bool_dup.matrix_world
            #bool.matrix_world=Matrix.Identity(4)@obj.matrix_world.inverted()
            #obj_dup.location=[0,0,0]
            #obj_dup.scale=[1,1,1]
            #obj_dup.rotation_euler=[0,0,0]
            #obj_dup.parent=obj
            #bool.parent=obj
            #bool_dup.parent=bool
            rt_cutters=get_collection(name='RT_Cutters')
            move_to_collection(bool_dup,rt_cutters)
            move_to_collection(bool,rt_cutters)
            self.bool_dup_from_slice=bool_dup
            bpy.ops.object.parent_set(keep_transform=True)
            bool.hide_render=True
            bool_dup.hide_render=True
            bool_dup.hide_view=True
            #bool.hide_view=True
            bool.display_type='WIRE'
            bool_dup.display_type='WIRE'
            intersectMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Intersect_Bool")
            intersectMod.show_expanded=False
            intersectMod.object=bool
            intersectMod.solver=solver_to_use
            intersectMod.operation='INTERSECT'
            diffMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Intersect_Bool")
            diffMod.show_expanded=False
            diffMod.object=bool_dup
            #diffMod.solver='EXACT'
            diffMod.solver=solver_to_use
            solidifyMod=bool_dup.modifiers.new(type='SOLIDIFY',name="RT_Slice_Bool_Solidify")
            solidifyMod.show_expanded=False
            solidifyMod.offset=0
            solidifyMod.thickness=0.001
            solidifyMod.use_even_offset=True
            solidifyMod.solidify_mode='NON_MANIFOLD'
            mod=obj.modifiers.new(type='BOOLEAN',name="RT_Difference_Boolean")
            mod.show_expanded=False
            mod.object=bool
            mod.solver=solver_to_use
            self.bool_mod=mod
            self.modifiers_created.extend([solidifyMod,diffMod,intersectMod,mod])
            self.inset_solidify_mod=solidifyMod
            bool_dup_solidify=bool_dup.modifiers.get('RT_SOLIDIFY' if not self.is_line else 'RT_SOLIDIFY.001')
            add_driver(["thickness","show_viewport","show_render"],bool_dup_solidify,self.solidify_mod,self.bool_obj)
            #add_driver(["thickness" if not self.is_line else "screw_offset","show_viewport","show_render"],bool_dup_solidify,self.solidify_mod,self.bool_obj)
            if self.is_line:
                bool_dup_line_solidify=bool_dup.modifiers.get('RT_SOLIDIFY')
                add_driver(["thickness","show_viewport","show_render"],bool_dup_line_solidify,self.line_solidify_mod,self.bool_obj)
            bool_dup_bevel_1=[mod for mod in bool_dup.modifiers if mod.type=='BEVEL'][0]
            bool_dup_bevel_2=[mod for mod in bool_dup.modifiers if mod.type=='BEVEL'][1]
            bool_dup_mirror_mod=bool_dup.modifiers.get('RT_BOOLEAN_MIRROR')
            bool_dup_circular_array=bool_dup.modifiers.get('RT_ARRAY')
            bool_dup_linear_array=bool_dup.modifiers.get('RT_LINEAR_ARRAY')
            bool_dup_displace_mod=bool_dup.modifiers.get('RT_BOOLEAN_DISPLACE')
            self.bool_dup=bool_dup
            
            add_driver(["segments",'width',"show_viewport","show_render"],bool_dup_bevel_1,self.bevel_mod_1,self.bool_obj)
            add_driver(["segments",'width',"show_viewport","show_render"],bool_dup_bevel_2,self.bevel_mod_2,self.bool_obj)
            add_driver(["count","show_viewport","show_render"],bool_dup_circular_array,self.array_mod,self.bool_obj)
            add_driver(["strength","direction","show_viewport","show_render"],bool_dup_displace_mod,self.displace_mod,self.bool_obj)
            add_driver(["use_axis[0]","use_axis[1]","use_axis[2]","use_bisect_axis[0]","use_bisect_axis[1]","use_bisect_axis[2]","use_bisect_flip_axis[0]","use_bisect_flip_axis[1]","use_bisect_flip_axis[2]","show_viewport","show_render"],bool_dup_mirror_mod,self.mirror_mod,self.bool_obj)
            add_driver(["count","relative_offset_displace[0]","relative_offset_displace[1]","relative_offset_displace[2]","show_viewport","show_render"],bool_dup_linear_array,self.linear_array_mod,self.bool_obj)
            sort_modifiers(obj,self.sort_mirror_mod)
            sort_modifiers(obj_dup)
        if bool_type=='INSET' and self.bool_type!='INSET':
            self.bevel_mod_2.invert_vertex_group=False
            for o in self.extra_objects_created:
                delete_object_with_data(o)
            for mod in self.modifiers_created:
                if mod in self.obj.modifiers[:]:
                    self.obj.modifiers.remove(mod)
                elif mod in self.bool_obj.modifiers[:]:
                    self.bool_obj.modifiers.remove(mod)
            self.extra_objects_created=[]
            self.modifiers_created=[]
            self.bool_type='INSET'
            obj=self.obj
            bool=self.bool_obj
            bool.location=self.last_location
            obj_dup=duplicate_object(obj)
            obj_dup.CutterId=get_id()
            self.extra_objects_created.append(obj_dup)
            for m in obj_dup.modifiers:
                if m.type=='BEVEL':
                    if m.segments>1 and m.width<0.05:
                        bpy.ops.object.modifier_remove({'object':obj_dup},modifier=m.name)
            deselect_all()
            select(obj_dup)
            select(obj)
            #bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            bpy.ops.object.parent_set(keep_transform=True)
            deselect_all()
            select(bool)
            #bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            select(obj)
            bpy.ops.object.parent_set()
            #obj_dup.matrix_world=obj.matrix_world.inverted()@obj_dup.matrix_world
            #bool.matrix_world=obj.matrix_world.inverted()@bool.matrix_world
            
            #bool.matrix_world=obj.matrix_world.inverted()
            
            #obj_dup.location=[0,0,0]
            #obj_dup.rotation_euler=[0,0,0]
            #obj_dup.scale=[1,1,1]
            #obj_dup.parent=obj
            #bool.parent=obj

            rt_cutters=get_collection(name='RT_Cutters')
            move_to_collection(obj_dup,rt_cutters)
            move_to_collection(bool,rt_cutters)
            bool.hide_render=True
            obj_dup.hide_render=True
            obj_dup.hide_view=True
            bool.display_type='WIRE'
            obj_dup.display_type='WIRE'
            
            solidifyMod=obj_dup.modifiers.new(type='SOLIDIFY',name="RT_Inset_Bool_Solidify")
            solidifyMod.show_expanded=False
            solidifyMod.offset=0
            solidifyMod.use_even_offset=True
            solidifyMod.thickness=0.05
            #solidifyMod.nonmanifold_thickness_mode='FIXED'
            
            solidifyMod.solidify_mode='NON_MANIFOLD'
            solidifyMod.nonmanifold_thickness_mode='FIXED'
            boolMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Inset_Boolean")
            boolMod.show_expanded=False
            boolMod.operation='INTERSECT'
            boolMod.object=bool
            boolMod.solver=solver_to_use
            mod=obj.modifiers.new(type='BOOLEAN',name="RT_Inset_Boolean")
            mod.show_expanded=False
            mod.object=obj_dup
            mod.solver=solver_to_use
            self.bool_mod=mod
            self.modifiers_created.extend([mod,boolMod,solidifyMod])
            self.inset_solidify_mod=solidifyMod
            self.bool_dup=None
            
            sort_modifiers(obj,self.sort_mirror_mod)
        if bool_type=='DIFFERENCE' and self.bool_type!='DIFFERENCE':
            self.bevel_mod_2.invert_vertex_group=False
            for o in self.extra_objects_created:
                delete_object_with_data(o)
            for mod in self.modifiers_created:
                if mod in self.obj.modifiers[:]:
                    self.obj.modifiers.remove(mod)
                elif mod in self.bool_obj.modifiers[:]:
                    self.bool_obj.modifiers.remove(mod)
            self.extra_objects_created=[]
            self.modifiers_created=[]
            self.bool_type='DIFFERENCE'
            obj=self.obj
            bool=self.bool_obj
            bool.location=self.last_location
            bool_mod=obj.modifiers.new(type='BOOLEAN',name="RT_Difference_Boolean")
            bool_mod.show_expanded=False
            bool_mod.object=bool
            bool_mod.solver=solver_to_use
            self.bool_mod=bool_mod
            self.modifiers_created.append(bool_mod)
            self.inset_solidify_mod=None
            self.bool_dup=None
            sort_modifiers(obj,self.sort_mirror_mod)
        if bool_type=='UNION' and self.bool_type!='UNION':
            self.bevel_mod_2.invert_vertex_group=True
            for o in self.extra_objects_created:
                delete_object_with_data(o)
            for mod in self.modifiers_created:
                if mod in self.obj.modifiers[:]:
                    self.obj.modifiers.remove(mod)
                elif mod in self.bool_obj.modifiers[:]:
                    self.bool_obj.modifiers.remove(mod)
            self.extra_objects_created=[]
            self.modifiers_created=[]
            self.bool_type='UNION'
            obj=self.obj
            
            bool=self.bool_obj
            bool.location=self.last_location
            #print(grid_offset,self.normal)
            bool.location=bool.location-grid_offset*2*Vector(self.normal)
            bool_mod=obj.modifiers.new(type='BOOLEAN',name="RT_Union_Boolean")
            bool_mod.show_expanded=False
            bool_mod.object=bool
            bool_mod.solver=solver_to_use
            bool_mod.operation='UNION'
            self.bool_mod=bool_mod
            self.modifiers_created.append(bool_mod)
            self.inset_solidify_mod=None
            self.bool_dup=None
            sort_modifiers(obj,self.sort_mirror_mod)
        if bool_type=='INTERSECT' and self.bool_type!='INTERSECT':
            self.bevel_mod_2.invert_vertex_group=False
            for o in self.extra_objects_created:
                delete_object_with_data(o)
            for mod in self.modifiers_created:
                if mod in self.obj.modifiers[:]:
                    self.obj.modifiers.remove(mod)
                elif mod in self.bool_obj.modifiers[:]:
                    self.bool_obj.modifiers.remove(mod)
            self.extra_objects_created=[]
            self.modifiers_created=[]
            self.bool_type='INTERSECT'
            obj=self.obj
            bool=self.bool_obj
            bool.location=self.last_location
            bool_mod=obj.modifiers.new(type='BOOLEAN',name="RT_Intersect_Boolean")
            bool_mod.show_expanded=False
            bool_mod.object=bool
            
            bool_mod.solver=solver_to_use
            bool_mod.operation='INTERSECT'
            self.bool_mod=bool_mod
            self.modifiers_created.append(bool_mod)
            self.inset_solidify_mod=None
            self.bool_dup=None
            sort_modifiers(obj,self.sort_mirror_mod)
    def modal(self,context,event):
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        #self.activeKey=f"{'SHIFT+' if event.shift else ''}{'CTRL+' if event.ctrl else ''}{event.type}"
        #if self.self.inset_solidify_mod:
        #self.inset_solidify_mod.show_viewport=self.inset_solidify_mod.thickness>0.0005
        if self.from_inset_shrink and self.decimate_mod:
            self.decimate_mod.show_viewport=self.bevel_mod_1.width>0
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            if self.mod:
                self.activePropCopy=getattr(self.mod,self.activeProp)
            self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
            self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
            self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
            self.init_x=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            if self.mod:
                self.activePropCopy=getattr(self.mod,self.activeProp)
            self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
            self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
            self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
            self.init_x=context.region.x+context.region.width
        if event.type=='H' :
            if event.value=='PRESS':
                self.show_help=not self.show_help
                context.scene.rt_tools.show_help=self.show_help
                self.activeKey='H'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='Q' :

            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.bool_obj.location=self.init_location if self.bool_obj.location!=self.init_location else self.center_location
                self.activeKey='Q'
            else:
                self.activeKey=None
            #self.empty.parent=self.obj
            #self.bool_obj.location=self.obj.location
            return {'RUNNING_MODAL'}
        
        if event.type=='TAB' and not event.is_repeat:
            if event.value=='PRESS':
                self.keep_boolean=not self.keep_boolean
                self.activeKey='TAB'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='X':
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.init_x=event.mouse_x
                if self.mod:
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                if self.array_adjust_mode:
                    self.linear_array_mod.relative_offset_displace[2]=0
                    self.linear_array_mod.relative_offset_displace[1]=0
                    self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                    #self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                    #self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                    self.adjust_axis='X'
                else:
                    if event.alt:
                        self.mirror_mod.use_bisect_flip_axis[0]=not self.mirror_mod.use_bisect_flip_axis[0]
                        self.activeKey='ALT+X/Y/Z'
                    else:
                        self.mirror_mod.use_axis[0]=not self.mirror_mod.use_axis[0]
                        self.mirror_mod.use_bisect_axis[0]=self.mirror_mod.use_axis[0]

                        self.activeKey='X/Y/Z'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='Y':
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.init_x=event.mouse_x
                if self.mod:
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                if self.array_adjust_mode:
                    self.linear_array_mod.relative_offset_displace[0]=0
                    self.linear_array_mod.relative_offset_displace[2]=0
                    #self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                    self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                    #self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                    self.adjust_axis='Y'
                else:
                    if event.alt:
                        self.activeKey='ALT+X/Y/Z'
                        self.mirror_mod.use_bisect_flip_axis[1]=not self.mirror_mod.use_bisect_flip_axis[1]
                    else:
                        self.mirror_mod.use_axis[1]=not self.mirror_mod.use_axis[1]
                        self.mirror_mod.use_bisect_axis[1]=self.mirror_mod.use_axis[1]
                        self.activeKey='X/Y/Z'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        
        elif event.type=='Z':
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.init_x=event.mouse_x
                if self.mod:
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                if self.array_adjust_mode:
                    self.linear_array_mod.relative_offset_displace[0]=0
                    self.linear_array_mod.relative_offset_displace[1]=0
                    #self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                    #self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                    self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                    self.adjust_axis='Z'
                else:
                    if event.alt:
                        self.activeKey='ALT+X/Y/Z'
                        self.mirror_mod.use_bisect_flip_axis[2]=not self.mirror_mod.use_bisect_flip_axis[2]
                    else:
                        self.mirror_mod.use_axis[2]=not self.mirror_mod.use_axis[2]
                        self.mirror_mod.use_bisect_axis[2]=self.mirror_mod.use_axis[2]
                        self.activeKey='X/Y/Z'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=="A":
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                if self.inset_solidify_mod:
                    self.array_adjust_mode=False
                    self.radius_adjust_mod=False
                    self.mod=self.inset_solidify_mod
                    self.activeProp=activeProps[self.inset_solidify_mod.type][0]
                    self.activePropCopy=getattr(self.inset_solidify_mod,self.activeProp)
                    self.init_x=event.mouse_x
                    self.activeProp2=None
                    #self.activeProp=activeProps[self.mod.type][self.index]
                    #self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='A'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif self.activePropCopy is not None and event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            if self.mod:
                self.activePropCopy=getattr(self.mod,self.activeProp)
            self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
            self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
            self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=1 
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif self.activePropCopy is not None and event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            if self.mod:
                self.activePropCopy=getattr(self.mod,self.activeProp)
            self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
            self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
            self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
            if event.value == 'PRESS':
                self.speed=0.3
            elif event.value == 'RELEASE':
                self.speed=1 
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='V':
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.array_adjust_mode=False
                self.radius_adjust_mod=False
                self.init_x=event.mouse_x
                self.mod=self.bevel_mod_1
                self.activeProp=activeProps[self.mod.type][self.index]
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2='segments'
                self.activeKey='V'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='U'and not self.draw:
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.change_boolean_type(context,'UNION')
                if self.mod and self.mod.name in {'RT_Slice_Bool_Solidify','RT_Inset_Bool_Solidify'}:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='U'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='I' and not self.draw:
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.change_boolean_type(context,'INTERSECT')
                if self.mod and self.mod.name in {'RT_Slice_Bool_Solidify','RT_Inset_Bool_Solidify'}:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='I'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='D'  and not self.draw:
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.change_boolean_type(context,'DIFFERENCE')
                if self.mod and self.mod.name in {'RT_Slice_Bool_Solidify','RT_Inset_Bool_Solidify'}:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='S'  and not self.draw:
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.change_boolean_type(context,'SLICE')
                if self.mod and self.mod.name in {'RT_Slice_Bool_Solidify','RT_Inset_Bool_Solidify'}:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='S'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='C'  and not self.draw:
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.change_boolean_type(context,'INSET')
                if self.mod and self.mod.name in {'RT_Slice_Bool_Solidify','RT_Inset_Bool_Solidify'}:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='C'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='F' :
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.displace_mod.direction='X' if self.displace_mod.direction=='Y' else 'Y'
                self.activeKey='F'
            else:
                self.activeKey=None
            
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='R' :
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.array_adjust_mode=False
                self.array_mod.show_viewport=not self.array_mod.show_viewport
                self.array_mod.show_render=not self.array_mod.show_render
                self.displace_mod.show_render=not self.displace_mod.show_render
                self.displace_mod.show_viewport=not self.displace_mod.show_viewport
                
                self.linear_array_mod.show_render=False
                self.linear_array_mod.show_viewport=False
                if not self.array_mod.show_render:
                    self.bool_obj.location=self.init_location
                    #if self.bool_dup:
                    #    self.bool_dup.location=self.bool_obj.location
                    self.last_location=self.init_location
                else:
                    self.bool_obj.location=self.center_location
                    self.last_location=self.center_location
                    #if self.bool_dup:
                    #    self.bool_dup.location=self.bool_obj.location
                self.radius_adjust_mod=self.array_mod.show_render
                
                if self.radius_adjust_mod:
                    self.mod=self.displace_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                else:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2=None    
                self.init_x=event.mouse_x
                self.activeKey='R'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='E':
            #self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
            #self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
            #self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
            if event.value=='PRESS':
                
                self.radius_adjust_mod=False
                self.linear_array_mod.show_render=not self.linear_array_mod.show_render
                self.linear_array_mod.show_viewport=self.linear_array_mod.show_render
                self.array_adjust_mode=self.linear_array_mod.show_render
                self.array_mod.show_viewport=False
                self.array_mod.show_render=False
                self.displace_mod.show_render=False
                self.displace_mod.show_viewport=False
                self.bool_obj.location=self.init_location
                if self.bool_dup:
                    self.bool_dup.location=self.bool_obj.location
                self.last_location=self.init_location
                if not self.array_adjust_mode:
                    self.mod=self.solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2=None   
                self.init_x=event.mouse_x
                self.activeKey='E'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='B':
            if event.value=='PRESS':
                if event.ctrl and not self.draw:
                    override = bpy.context.copy()
                    override['active_object'] = self.obj
                    override['object'] = self.obj
                    bpy.ops.object.modifier_move_to_index(override,modifier=self.bool_mod.name,index=len(self.obj.modifiers)-1)
                    if self.new_bevel_mod:
                        self.obj.modifiers.remove(self.new_bevel_mod)
                        self.new_bevel_mod=None
                        self.mod=self.solidify_mod
                        self.activeProp=activeProps[self.mod.type][self.index]
                        self.activePropCopy=getattr(self.mod,self.activeProp)
                        self.activeProp2=None
                    else:
                        self.new_bevel_mod=self.obj.modifiers.new(type='BEVEL',name='Bevel')
                        self.new_bevel_mod.miter_outer='MITER_ARC'
                        if len([a for a in self.obj.modifiers if a.type=='BEVEL'])>1:
                            
                            properties = [p.identifier for p in self.new_bevel_mod.bl_rna.properties
                                        if not p.is_readonly]
                            for prop in properties:
                                setattr(self.new_bevel_mod, prop, getattr([a for a in self.obj.modifiers if a.type=='BEVEL'][len([a for a in self.obj.modifiers if a.type=='BEVEL'])-2], prop))
                        self.mod=self.new_bevel_mod
                        self.activeProp=activeProps[self.mod.type][self.index]
                        self.activePropCopy=getattr(self.mod,self.activeProp)
                        self.activeProp2='segments'
                    sort_modifiers(self.obj,self.sort_mirror_mod)
                    self.activeKey='CTRL+B'
                else:
                    self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                    self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                    self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                    self.array_adjust_mode=False
                    self.radius_adjust_mod=False
                    self.init_x=event.mouse_x
                    self.mod=self.bevel_mod_2
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.activeProp2='segments'
                    self.activeKey='B'
            else:
                self.activeKey=None
            
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='G' :
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                if self.line_solidify_mod:
                    self.array_adjust_mode=False
                    self.radius_adjust_mod=False
                    self.init_x=event.mouse_x
                    self.mod=self.line_solidify_mod
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.activeProp2=None
                self.activeKey='G'
            else:
                self.activeKey=None
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='F1':
            if event.value=='PRESS':
                self.solidify_mod.thickness=find_shoot_distance(self.source_location,-self.normal,self.obj,self.bool_obj,context.scene)
                if self.activeProp=="thickness" and self.mod:
                    self.init_x=event.mouse_x
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey="F1"
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='T':
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.array_adjust_mode=False
                self.radius_adjust_mod=False
                self.init_x=event.mouse_x
                self.mod=self.solidify_mod
                
                self.activeProp=activeProps[self.mod.type][self.index]
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2=None
                self.activeKey='T'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='O' :
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.array_adjust_mode=False
                self.radius_adjust_mod=False
                self.init_x=event.mouse_x
                self.mod=self.solidify_mod
                self.activeProp=activeProps[self.mod.type][self.index]
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2=None
                self.mirror_mod.mirror_object=self.possibleMirrorObjects[(self.possibleMirrorObjects.index(self.mirror_mod.mirror_object)+1)%3]
                #self.mirror_mod.mirror_object=self.MirrorEmpty if self.mirror_mod.mirror_object==self.obj else self.obj
                self.activeKey='O'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='M' :
            if event.value=='PRESS':
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                if  self.inset_solidify_mod:
                    self.thickness_mode_index=(self.thickness_mode_index+1)%3
                    self.inset_solidify_mod.nonmanifold_thickness_mode=self.thicknessModes[self.thickness_mode_index]
                self.activeKey='M'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}

        elif event.type=='MOUSEMOVE':
            if self.array_adjust_mode:
                
                if self.adjust_axis=='X':
                    self.linear_array_mod.relative_offset_displace[0]=self.linear_array_mod_copy_x-(self.init_x-event.mouse_x)/((50 *self.speed))
                elif self.adjust_axis=='Y':
                    self.linear_array_mod.relative_offset_displace[1]=self.linear_array_mod_copy_y-(self.init_x-event.mouse_x)/((50 *self.speed))
                elif self.adjust_axis=='Z':
                    self.linear_array_mod.relative_offset_displace[2]=self.linear_array_mod_copy_z-(self.init_x-event.mouse_x)/((50 *self.speed))
                
            #elif self.adjust_mod and self.inset_solidify_mod:
            #    setattr(self.inset_solidify_mod,self.activeProp_adjustable_mod,self.activeProp_adjustable_mod_copy-(self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp_adjustable_mod in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else (20 *self.speed)))
            
            elif self.mod is not None and self.activeProp is not None and self.activePropCopy is not None :
                if self.is_line and self.mod.type=='SCREW':
                    setattr(self.mod,self.activeProp,self.activePropCopy-self.direction*(self.init_x-event.mouse_x)/((400 *self.speed)))
                    if self.mod.screw_offset<0:
                        self.mod.use_normal_flip=True
                    else:
                        self.mod.use_normal_flip=False
                else:
                    setattr(self.mod,self.activeProp,self.activePropCopy-(self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else (20 *self.speed)))
                    
                
            self.valueString='0'
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            if self.array_adjust_mode:
                setattr(self.linear_array_mod,'count',getattr(self.linear_array_mod,'count')+1)
                
            elif self.radius_adjust_mod:
                
                setattr(self.array_mod,'count',getattr(self.array_mod,'count')+1)
                
            elif self.mod  and  self.activeProp2 is not None:
                setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)+1)
                
            else:
                return {'PASS_THROUGH'}
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif  (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            if self.array_adjust_mode:
                setattr(self.linear_array_mod,'count',getattr(self.linear_array_mod,'count')-1)
                
            elif self.radius_adjust_mod:
                
                setattr(self.array_mod,'count',getattr(self.array_mod,'count')-1)
                
            elif self.mod  and self.activeProp2 is not None:
                setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)-1)
                
            else:
                return {'PASS_THROUGH'}
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='W' :
            if event.value=='PRESS':
                bpy.context.space_data.overlay.show_wireframes = not bpy.context.space_data.overlay.show_wireframes
                self.activeKey='W'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='DOWN_ARROW' and event.value=='PRESS':
            self.activePropCopy=getattr(self.mod,self.activeProp)/2
            setattr(self.mod,self.activeProp,self.activePropCopy)
            self.activePropCopy=getattr(self.mod,self.activeProp)
            return {'RUNNING_MODAL'}
        elif event.type=='UP_ARROW' and event.value=='PRESS':
            self.activePropCopy=2*getattr(self.mod,self.activeProp)
            setattr(self.mod,self.activeProp,self.activePropCopy)
            self.activePropCopy=getattr(self.mod,self.activeProp)
            return {'RUNNING_MODAL'}
        elif event.type=='LEFTMOUSE' and event.value=='PRESS' and (not event.alt if preferences().industry_keymap else True):
            if self.radius_adjust_mod or self.array_adjust_mode:
                self.linear_array_mod_copy_x=self.linear_array_mod.relative_offset_displace[0]
                self.linear_array_mod_copy_y=self.linear_array_mod.relative_offset_displace[1]
                self.linear_array_mod_copy_z=self.linear_array_mod.relative_offset_displace[2]
                self.radius_adjust_mod=False
                self.array_adjust_mode=False
                self.mod=self.solidify_mod
                self.activeProp=activeProps[self.mod.type][self.index]
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeProp2=None
                self.init_x=event.mouse_x
                context.area.tag_redraw()
            else:
                #if self.solidify_mod.type=='SOLIDIFY' and not self.draw:
                #    if abs(self.solidify_mod.thickness)<=0.05 and self.bool_type!='UNION':
                #        self.solidify_mod.thickness=max(self.obj.dimensions[:])*2
                #elif self.solidify_mod.type=='SCREW' and not self.draw:
                #    if abs(self.solidify_mod.screw_offset)<=0.05 and self.bool_type!='UNION':
                #        self.solidify_mod.screw_offset=self.direction*max(self.obj.dimensions[:])*2
                
                self.remove_drawHandler(context)
                for m in self.bool_obj.modifiers[:]:
                    if not m.show_viewport:
                        pass
                        #self.bool_obj.modifiers.remove(m)
                if not self.array_mod.show_viewport and self.empty:
                    delete_object(self.empty)
                if self.apply_mods and not self.recalled:
                    #pass
                    if self.bool_dup:
                        smart_apply_modifiers(self.bool_dup,mirror=True)
                    smart_apply_modifiers(self.bool_obj,mirror=True)
                    if self.bool_dup:
                        self.bool_dup.hide_view=False
                        deselect_all()
                        select(self.bool_dup)
                        select(self.bool_obj)
                        bpy.ops.object.make_links_data(type='OBDATA')
                        #bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
                        self.bool_dup.hide_view=True
                if not self.draw:
                    rt_cutters=get_collection(name='RT_Cutters')
                    move_to_collection(self.bool_obj,rt_cutters)
                if not self.keep_boolean and not self.draw:
                    self.bool_obj.hide_view=True
                    select(self.obj)
                    
                else:
                    bpy.ops.object.select_all(action='DESELECT')
                    cutters=recurLayerCollection(bpy.context.view_layer.layer_collection,'RT_Cutters')
                    if cutters:
                        cutters.exclude=False
                    select(self.bool_obj)
                if not self.draw:
                    context.scene.rt_tools.last_cutter_object=self.obj
                    if not self.recalled=='Panel':
                        t=self.obj.CuttersInfo.add()
                    else:
                        t=self.obj.CuttersInfo[self.cutter_index]
                    t.mods_applied=self.apply_mods
                    t.direction=self.direction
                    t.center_location=self.center_location
                    t.normal=self.normal
                    t.last_cutter=self.bool_obj.name
                    t.new_bevel_mod=self.new_bevel_mod.name if self.new_bevel_mod else ""
                    if self.bool_obj.CutterId=="None":
                        self.bool_obj.CutterId=get_id()
                    t.cutter_id=self.bool_obj.CutterId
                    t.name=self.bool_obj.CutterId
                    #print("ID",self.bool_obj.CutterId)
                    if self.extra_objects_created:
                        if self.extra_objects_created[0].CutterId=="None":
                            self.extra_objects_created[0].CutterId=get_id()
                            #print("ID1",self.extra_objects_created[0].CutterId)
                        t.cutter_extra_1=self.extra_objects_created[0].CutterId
                        if len(self.extra_objects_created)>1:
                            if self.extra_objects_created[1].CutterId=="None":
                                self.extra_objects_created[1].CutterId=get_id()
                                #print("ID2",self.extra_objects_created[1].CutterId)
                            t.cutter_extra_2=self.extra_objects_created[1].CutterId
                        else:
                            t.cutter_extra_2="Not"
                    else:
                        t.cutter_extra_1="Not"
                    t.last_bool_type=self.bool_type if  self.bool_type else ""
                    t.last_mod_name=self.bool_mod.name if  self.bool_mod else ""
                    context.scene.rt_tools.last_cutter_index=self.obj.CuttersInfo.find(self.bool_obj.CutterId)
                    if self.inset_solidify_mod:
                        t.last_inset_mod=self.inset_solidify_mod.name
                    else:
                        t.last_inset_mod=""
                if context.scene.rt_tools.keep_drawing and not self.from_inset_shrink and not self.recalled:
                    bpy.ops.rtools.grid('INVOKE_DEFAULT',fast_mode=self.fast_mode,internal_atv=self.internal_atv)
                delete_object_with_data(self.bool_backup)
                return {'FINISHED'}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS'  and (not event.alt if preferences().industry_keymap else True)) or event.type=='ESC' or event.type=='SPACE':
            
            
            if self.recalled:
                copy_modifiers(self.bool_backup,self.bool_obj)
            else:
                if self.bool_mod:
                    self.obj.modifiers.remove(self.bool_mod)
                if self.new_bevel_mod:
                        self.obj.modifiers.remove(self.new_bevel_mod)
                for obj in self.extra_objects_created:
                    delete_object_with_data(obj)
                if self.empty:
                    delete_object(self.empty)
                if self.MirrorEmpty:
                    delete_object(self.MirrorEmpty)
                delete_object_with_data(self.bool_obj)
            delete_object_with_data(self.bool_backup)
            if self.fast_mode:
                context.scene.rt_tools.keep_drawing=False
            select(self.obj)
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type in events.keys() and event.value=='PRESS':
            if self.mod and ((event.type!='PERIOD' and event.type!='NUMPAD_PERIOD') or '.' not in self.valueString):
                if event.type=='NUMPAD_MINUS' or event.type=='MINUS' or event.type=='NDOF_BUTTON_MINUS':
                    setattr(self.mod,self.activeProp,-getattr(self.mod,self.activeProp))
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.negate*=-1
                else:
                    
                    self.valueString+=f"{events[event.type]}"
                    setattr(self.mod,self.activeProp,self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0  else eval("0"))
                    self.activePropCopy=getattr(self.mod,self.activeProp)
            return {'RUNNING_MODAL'}
        elif self.mod and event.type=='BACK_SPACE' and event.value=='PRESS':
            self.valueString=self.valueString[:-1] if len(self.valueString)>1 else self.valueString
            setattr(self.mod,self.activeProp,self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0 else eval("0"))
            self.activePropCopy=getattr(self.mod,self.activeProp)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.show_help=context.scene.rt_tools.show_help
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        context.area.tag_redraw()
        self.activeKey=None
        self.thicknessModes=['FIXED','EVEN','CONSTRAINTS']
        self.thickness_mode_index=0
        self.init_x=event.mouse_x
        self.init_y=event.mouse_y
        self.speed=1
        self.index=0
        self.valueString='0'
        self.negate=1
        self.inset_solidify_mod=None
        self.radius_adjust_mod=False
        self.activeProp_adjustable_mod=None
        self.MirrorEmpty=None
        self.empty=None
        bool_obj=context.active_object
        self.sort_mirror_mod=preferences().sort_mirror_mod
        if not self.recalled:
            maskGroup=bool_obj.vertex_groups.new(name="Bevel")
            maskGroup.remove(range(len(bool_obj.data.vertices)))
        self.is_line=len(bool_obj.data.polygons)<1
        self.apply_mods=preferences().apply_mods
        self.keep_boolean=not preferences().auto_hide_bools_after_drawing or self.recalled
        obj=Diff([a for a in context.selected_objects if a.type=='MESH'],[bool_obj])[0]
        if [a for a in context.selected_objects if a.type=='EMPTY']:
            self.MirrorEmpty=[a for a in context.selected_objects if a.type=='EMPTY'][0]
            
            self.MirrorEmpty.empty_display_size=0.1
            self.possibleMirrorObjects=[obj,None,self.MirrorEmpty]
            deselect_all()
            if not self.draw:
                rt_cutters=get_collection(name='RT_Cutters')
                move_to_collection(self.MirrorEmpty,rt_cutters)
            select(self.MirrorEmpty)
            select(bool_obj)
            bpy.ops.object.parent_set()
            self.MirrorEmpty.hide_view=True
        else:
            self.possibleMirrorObjects=[obj,None]
        self.bool_obj=bool_obj
        self.obj=obj
        self.new_bevel_mod=None
        self.init_mods=[m.name for m in obj.modifiers]
        #print("Init ",self.init_mods[:])
        if self.recalled:
            self.new_bevel_mod=self.obj.modifiers.get(self.bevel_mod) if self.obj.modifiers.get(self.bevel_mod) else None 
            deselect_all()
            select(bool_obj)
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        self.init_location=bool_obj.location.copy()
        self.last_location=self.init_location.copy()
        if self.recalled:
            self.center_location=self.init_location.copy()
        bool_vertices=[self.bool_obj.matrix_world@v.co for v in self.bool_obj.data.vertices]+[self.bool_obj.location,]
        self.bool_obj.hide_view=True
        direction=-1
        if bool_obj.dimensions==Vector((0,0,0)) and not self.is_line:
            
            if not self.recalled:
                if self.MirrorEmpty:
                    delete_object(self.MirrorEmpty)
                delete_object_with_data(bool_obj)
                self.report({'WARNING'},"Invalid Geometry")
            return {'CANCELLED'}
        self.source_location=self.bool_obj.location.copy()
        #print("Init Source",self.bool_obj.location)
        for v in [self.bool_obj.location,]+bool_vertices+get_grid_points_for_object(self.bool_obj):
            self.evaluated_bool=self.bool_obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
            if self.is_line:
                self.normal=self.evaluated_bool.rotation_euler.to_matrix()@Vector((0,0,1))
            else:
                self.normal=(self.evaluated_bool.rotation_euler.to_matrix()@self.bool_obj.data.polygons[0].normal)
            
            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(),v,self.normal)
            
            if object==self.obj:
                #print('Source',v)
                self.source_location=v.copy()
                distance=(v-location).length
                distance2=distance+1
                (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(),v,-self.normal)
                if object==self.obj:
                    distance2=(v-location).length
                if distance<=distance2:
                    direction=1
                else:
                    direction=-1
                break
            else:
                (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(bpy.context.evaluated_depsgraph_get(),v,-self.normal)
                
                if object==self.obj:
                    #print('Source',v)
                    self.source_location=v.copy()
                    
                direction=-1
        if direction==1 and not self.recalled:
            bm=bmesh.new()
            bm.from_mesh(self.bool_obj.data)
            bm.faces.ensure_lookup_table()
            bmesh.ops.reverse_faces(bm,faces=bm.faces)
            bm.to_mesh(self.bool_obj.data)
            bm.free()
        if self.from_inset_shrink:
            bm=bmesh.new()
            bm.from_mesh(self.bool_obj.data)
            bm.faces.ensure_lookup_table()
            bmesh.ops.reverse_faces(bm,faces=bm.faces)
            bm.to_mesh(self.bool_obj.data)
            bm.free()
        self.evaluated_bool=self.bool_obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        if self.is_line:
            self.normal=self.evaluated_bool.rotation_euler.to_matrix()@Vector((0,0,1))
        else:
            self.normal=(self.evaluated_bool.rotation_euler.to_matrix()@self.bool_obj.data.polygons[0].normal)
        if not self.recalled:
            self.direction=direction
        #if self.recalled:
        #    self.normal=Vector(self.normal_prop)
        self.bool_obj.hide_view=False   
        self.bool_mod=None
        obj.data.use_auto_smooth=True
        self.modifiers_created=[]
        self.bool_type=None
        self.extra_objects_created=[]
        self.line_solidify_mod=None
        
            
        if not self.draw:
            select(self.bool_obj)
            select(obj)
            #self.bool_obj.matrix_world=obj.matrix_world.inverted()@self.bool_obj.matrix_world
            #self.bool_obj.parent=obj
            bpy.ops.object.parent_set()
            #get_collection(name='RT_Cutters')
            #move_to_collection(bool_obj,'RT_Cutters')
            bool_obj.display_type='WIRE'
            self.bool_type='DIFFERENCE'
            
            #if self.recalled=='Last':
            #    self.bool_type=context.scene.rt_tools.last_bool_type
            #    self.bool_mod=obj.modifiers.get(context.scene.rt_tools.last_mod_name)
            #    if bool_obj.children:
            #        if bool_obj.children[0].modifiers.get(context.scene.rt_tools.last_inset_mod):
            #            self.inset_solidify_mod=bool_obj.children[0].modifiers.get(context.scene.rt_tools.last_inset_mod)
            #    if context.scene.rt_tools.cutter_extra_1:
            #        self.extra_objects_created.append(context.scene.rt_tools.cutter_extra_1)
            #    if context.scene.rt_tools.cutter_extra_2:
            #        self.extra_objects_created.append(context.scene.rt_tools.cutter_extra_2)
            
            if self.recalled=='Panel':
                self.bool_type=self.last_bool_type
                self.bool_mod=obj.modifiers.get(self.last_mod_name)
                #if bool_obj.children:
                #    if bool_obj.children[0].modifiers.get(self.last_inset_mod):
                        
                if self.cutter_extra_1:
                    self.extra_objects_created.append(bpy.data.objects[self.cutter_extra_1])
                    self.inset_solidify_mod=bpy.data.objects[self.cutter_extra_1].modifiers.get(self.last_inset_mod)
                if self.cutter_extra_2:
                    self.extra_objects_created.append(bpy.data.objects[self.cutter_extra_2])
            else:
                self.bool_mod=obj.modifiers.new(type='BOOLEAN',name="RT_Difference_Boolean")
                self.bool_mod.show_expanded=False
                self.bool_mod.object=bool_obj
                self.bool_mod.solver=solver_to_use
            self.modifiers_created.append(self.bool_mod)
        
            
            
        if self.is_line:
            if not bool_obj.modifiers.get("RT_BEVEL"):
                self.bevel_mod_1=bool_obj.modifiers.new(type='BEVEL',name="RT_BEVEL")
                self.bevel_mod_1.show_expanded=False
                self.bevel_mod_1.width=0
                self.bevel_mod_1.affect='VERTICES'
            else:
                self.bevel_mod_1=bool_obj.modifiers.get("RT_BEVEL")
            if not bool_obj.modifiers.get("RT_SCREW"):
                self.solidify_mod=bool_obj.modifiers.new(type='SCREW',name="RT_SCREW")
                self.solidify_mod.show_expanded=False
                self.solidify_mod.screw_offset=-0.00005
                self.solidify_mod.angle=0
                self.solidify_mod.steps=1
                self.solidify_mod.render_steps=1
                self.solidify_mod.axis='Z'
                self.solidify_mod.use_normal_flip=True
                self.solidify_mod.use_normal_calculate=True
            else:
                self.solidify_mod=bool_obj.modifiers.get("RT_SCREW")

            
            if not bool_obj.modifiers.get("RT_SOLIDIFY"):
                self.line_solidify_mod=bool_obj.modifiers.new(type='SOLIDIFY',name="RT_SOLIDIFY")
                self.line_solidify_mod.show_expanded=False
                self.line_solidify_mod.thickness=0.02
                self.line_solidify_mod.offset=0
                self.line_solidify_mod.use_even_offset=True
                self.line_solidify_mod.solidify_mode='NON_MANIFOLD'
                self.line_solidify_mod.nonmanifold_merge_threshold=0
            else:
                 self.line_solidify_mod=bool_obj.modifiers.get("RT_SOLIDIFY")
            if not bool_obj.modifiers.get("RT_WELD"):
                self.weld_mod=bool_obj.modifiers.new(type='WELD',name="RT_WELD")
                self.weld_mod.show_expanded=False
                self.weld_mod.merge_threshold=0.0001
            else:
                self.weld_mod=bool_obj.modifiers.get("RT_WELD")
            if not bool_obj.modifiers.get("RT_SOLIDIFY.001"):
                self.solidify_mod=bool_obj.modifiers.new(type='SOLIDIFY',name="RT_SOLIDIFY")
                self.solidify_mod.solidify_mode='NON_MANIFOLD'
                self.solidify_mod.show_expanded=False
                self.solidify_mod.thickness=0.02
                self.solidify_mod.offset=preferences().boolean_solidify_offset if not self.draw else preferences().draw_solidify_offset
                if self.fast_mode:
                    self.solidify_mod.offset=-1
                if not self.recalled:
                    self.solidify_mod.shell_vertex_group=maskGroup.name
                self.solidify_mod.use_even_offset=True
            else:
                 self.solidify_mod=bool_obj.modifiers.get("RT_SOLIDIFY.001")
        else:
            if not bool_obj.modifiers.get("RT_BEVEL"):
                self.bevel_mod_1=bool_obj.modifiers.new(type='BEVEL',name="RT_BEVEL")
                self.bevel_mod_1.show_expanded=False
                self.bevel_mod_1.width=0
                self.bevel_mod_1.affect='VERTICES'
            else:
                self.bevel_mod_1=bool_obj.modifiers.get("RT_BEVEL")
            if self.from_inset_shrink:
                self.decimate_mod=bool_obj.modifiers.new(type='DECIMATE',name="RT_DECIMATE")
                self.bevel_mod_1.show_expanded=False
                self.decimate_mod.show_viewport=len(self.bool_obj.data.polygons)>2
                self.decimate_mod.decimate_type='DISSOLVE'
            if not bool_obj.modifiers.get("RT_SOLIDIFY"):
                self.solidify_mod=bool_obj.modifiers.new(type='SOLIDIFY',name="RT_SOLIDIFY")
                self.solidify_mod.show_expanded=False
                self.solidify_mod.solidify_mode='NON_MANIFOLD'
                self.solidify_mod.thickness=0.045
                if not self.recalled:
                    self.solidify_mod.shell_vertex_group=maskGroup.name
                self.solidify_mod.offset=preferences().boolean_solidify_offset if not self.draw else preferences().draw_solidify_offset
                if self.fast_mode:
                    self.solidify_mod.offset=-1
            else:
                self.solidify_mod=bool_obj.modifiers.get("RT_SOLIDIFY")
            if self.from_inset_shrink:
                self.solidify_mod.offset=0
        if not bool_obj.modifiers.get("RT_BOOLEAN_DISPLACE"):
            self.displace_mod=bool_obj.modifiers.new(type='DISPLACE',name="RT_BOOLEAN_DISPLACE")
            self.displace_mod.show_expanded=False
            self.displace_mod.mid_level=0
            self.displace_mod.direction='Y'
            self.displace_mod.strength=0
            self.displace_mod.show_render=False
            self.displace_mod.show_viewport=False
        else:
            self.displace_mod=bool_obj.modifiers.get("RT_BOOLEAN_DISPLACE")
        if not bool_obj.modifiers.get("RT_ARRAY"):
            self.array_mod=bool_obj.modifiers.new(type='ARRAY',name="RT_ARRAY")
            self.array_mod.show_expanded=False
            self.array_mod.use_relative_offset=False
            self.array_mod.show_render=False
            self.array_mod.show_viewport=False
        else:
            self.array_mod=bool_obj.modifiers.get("RT_ARRAY")
        self.add_array(context)
        if not bool_obj.modifiers.get("RT_LINEAR_ARRAY"):
            self.linear_array_mod=bool_obj.modifiers.new(type='ARRAY',name="RT_LINEAR_ARRAY")
            self.linear_array_mod.show_expanded=False
            #self.linear_array_mod.use_relative_offset=True
            self.linear_array_mod.show_render=False
            self.linear_array_mod.show_viewport=False
        else:
            self.linear_array_mod=bool_obj.modifiers.get("RT_LINEAR_ARRAY")
        if not bool_obj.modifiers.get("RT_BEVEL.001"):
            self.bevel_mod_2=bool_obj.modifiers.new(type='BEVEL',name="RT_BEVEL")
            self.bevel_mod_2.show_expanded=False
            self.bevel_mod_2.width=0
            if not self.recalled:
                self.bevel_mod_2.vertex_group=maskGroup.name
            self.bevel_mod_2.angle_limit=math.radians(60)
        else:
            self.bevel_mod_2=bool_obj.modifiers.get("RT_BEVEL.001")
        if  not self.draw:
            self.bevel_mod_2.limit_method='VGROUP'
        #if self.is_line:
        #    self.bevel_mod_2.invert_vertex_group=True
        if not bool_obj.modifiers.get("RT_BOOLEAN_MIRROR"):
            self.mirror_mod=bool_obj.modifiers.new(type='MIRROR',name="RT_BOOLEAN_MIRROR")
            self.mirror_mod.show_expanded=False
            self.mirror_mod.mirror_object=self.obj
            self.mirror_mod.use_axis=[False,False,False]
        else:
            self.mirror_mod=bool_obj.modifiers.get("RT_BOOLEAN_MIRROR") 
            if not [a for a in context.selected_objects if a.type=='EMPTY'] and self.mirror_mod.mirror_object!=self.obj and self.mirror_mod.mirror_object:
                self.possibleMirrorObjects.append(self.mirror_mod.mirror_object)
            elif not [a for a in context.selected_objects if a.type=='EMPTY'] and [c for c in bool_obj.children if c.specialInfo=='MirrorEmpty']:
                self.possibleMirrorObjects.append([c for c in bool_obj.children if c.specialInfo=='MirrorEmpty'][0])
        self.bool_backup=duplicate_object(self.bool_obj)
        self.bool_backup.hide_view=True
        self.activeProp=activeProps[self.solidify_mod.type][0]
        sort_modifiers(obj,self.sort_mirror_mod)
        if not self.draw:
            bool_obj.hide_render=True
        
        if not self.recalled:
            self.activePropCopy=getattr(self.solidify_mod,self.activeProp)
            self.mod=self.solidify_mod
        else:
            self.activePropCopy=None
            self.mod=None
        self.activeProp2=None
        
        
        self.array_adjust_mode=False
        self.linear_array_mod_copy_x=0
        self.linear_array_mod_copy_y=0
        self.linear_array_mod_copy_z=0
        self.adjust_axis='X'
        self.bool_dup=None
        if self.fast_mode:
            self.activePropCopy=None
            self.mod=None
            #print(self.source_location)
            self.solidify_mod.thickness=self.solidify_mod.thickness=find_shoot_distance(self.source_location,-self.normal,self.obj,self.bool_obj,context.scene)
            if preferences().skip_adjustment_phase:
                for m in self.bool_obj.modifiers[:]:
                    if not m.show_viewport:
                        pass
                        #self.bool_obj.modifiers.remove(m)
                if not self.array_mod.show_viewport and self.empty:
                    delete_object(self.empty)
                if self.apply_mods and not self.recalled:
                    #pass
                    if self.bool_dup:
                        smart_apply_modifiers(self.bool_dup,mirror=True)
                    smart_apply_modifiers(self.bool_obj,mirror=True)
                    if self.bool_dup:
                        self.bool_dup.hide_view=False
                        deselect_all()
                        select(self.bool_dup)
                        select(self.bool_obj)
                        bpy.ops.object.make_links_data(type='OBDATA')
                        #bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":True, "mode":'TRANSLATION'})
                        self.bool_dup.hide_view=True
                if not self.draw:
                    rt_cutters=get_collection(name='RT_Cutters')
                    move_to_collection(self.bool_obj,rt_cutters)
                if not self.keep_boolean and not self.draw:
                    self.bool_obj.hide_view=True
                    select(self.obj)
                    
                else:
                    bpy.ops.object.select_all(action='DESELECT')
                    cutters=recurLayerCollection(bpy.context.view_layer.layer_collection,'RT_Cutters')
                    if cutters:
                        cutters.exclude=False
                    select(self.bool_obj)
                if not self.draw:
                    context.scene.rt_tools.last_cutter_object=self.obj
                    if not self.recalled=='Panel':
                        t=self.obj.CuttersInfo.add()
                    else:
                        t=self.obj.CuttersInfo[self.cutter_index]
                    t.mods_applied=self.apply_mods
                    t.direction=self.direction
                    t.center_location=self.center_location
                    t.normal=self.normal
                    t.last_cutter=self.bool_obj.name
                    t.new_bevel_mod=self.new_bevel_mod.name if self.new_bevel_mod else ""
                    if self.bool_obj.CutterId=="None":
                        self.bool_obj.CutterId=get_id()
                    t.cutter_id=self.bool_obj.CutterId
                    t.name=self.bool_obj.CutterId
                    #print("ID",self.bool_obj.CutterId)
                    if self.extra_objects_created:
                        if self.extra_objects_created[0].CutterId=="None":
                            self.extra_objects_created[0].CutterId=get_id()
                            #print("ID1",self.extra_objects_created[0].CutterId)
                        t.cutter_extra_1=self.extra_objects_created[0].CutterId
                        if len(self.extra_objects_created)>1:
                            if self.extra_objects_created[1].CutterId=="None":
                                self.extra_objects_created[1].CutterId=get_id()
                                #print("ID2",self.extra_objects_created[1].CutterId)
                            t.cutter_extra_2=self.extra_objects_created[1].CutterId
                        else:
                            t.cutter_extra_2="Not"
                    else:
                        t.cutter_extra_1="Not"
                    t.last_bool_type=self.bool_type if  self.bool_type else ""
                    t.last_mod_name=self.bool_mod.name if  self.bool_mod else ""
                    context.scene.rt_tools.last_cutter_index=self.obj.CuttersInfo.find(self.bool_obj.CutterId)
                    if self.inset_solidify_mod:
                        t.last_inset_mod=self.inset_solidify_mod.name
                    else:
                        t.last_inset_mod=""
                if context.scene.rt_tools.keep_drawing and not self.from_inset_shrink and not self.recalled:
                    bpy.ops.rtools.grid('INVOKE_DEFAULT',fast_mode=self.fast_mode,internal_atv=self.internal_atv)
                delete_object_with_data(self.bool_backup)
                return {'FINISHED'}
        
        self.add_drawHandler(context)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Grid(bpy.types.Operator):
    bl_idname = "rtools.grid"
    bl_label = "Draw Booleans"
    bl_description = "Draw Booleans\nCTRL+LMB: Fast Cutter Mode"
    bl_options = {"REGISTER","UNDO"}
    fast_mode:bpy.props.BoolProperty(default=False,options={'SKIP_SAVE','HIDDEN'})
    internal_atv:bpy.props.BoolProperty(default=True,options={'SKIP_SAVE','HIDDEN'})
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"D: Mode ({self.operation})",],alignV="TOP",activeKey=self.activeKey)
        if self.show_help:
            draw_Text(context,0,preferences().font_size,text=[f"Period : Grid Location({'Cursor' if self.grid_to_cursor else 'Near Object'})" if self.align_to_view else "","Hold ALT : Intersect Snapping" if self.draw_type=='POLYGON' else ('Hold ALT : Change Circle Resolution' if self.draw_type=='CIRCLE' else ''),"Hold SHIFT : Angle Snapping","Hold CTRL: Grid Snapping","SPACE : Clear Shape","Z : Undo",f"P : Hold Grid ({'OFF' if self.auto_hide_grid else 'ON'})",f"M : Length Snapping {'(ON)' if self.snap_length else '(OFF)'}",f"T : Angle Snap ({'Grid' if self.snap_to_plane else 'Last Segment'})",f"Q : Snap Angle ({self.snap_angle})",f"I : Inset Amount ({round(self.inset_amount,3)})",f"S : SubDivide ({self.subsurf_level})",f"W : Wireframe{'(ON)' if bpy.context.space_data.overlay.show_wireframes else '(OFF)'}",f"O : Grid To Edge ({'ON' if self.grid_to_edge else 'OFF'})",f"Y : Align To Edge Normal ({'ON' if self.align_to_edge_normal else 'OFF'})","SHIFT+E: Disable Align To Edges/Verts",f"E : Align To Edges {'(ON)' if self.align_to_edge else '(OFF)'}","U : Align View To Grid",f"V : Align To View {'(ON)' if self.align_to_view else '(OFF)'}",f"R : Rotate Grid({round(self.rotation_x,2),round(self.rotation_y,2),round(self.rotation_z,2)}°)",f"F: Rotation Axis({self.rotation_axis})",f"3 : Red Lines ({'OFF' if self.hide_point_lines else 'ON'})",f"2 : Inset Points ({'OFF' if self.hide_inset_verts else 'ON'})",f"1 : Intersect Points ({'OFF' if self.hide_cp_verts else 'ON'})",f"G : Grid Type ({'Points' if not self.line_type_grid else 'Lines'})","line",f"{'A : Strip/Mesh'}","X : Polygon","C : Circle","B : Box",F"Length : {round((self.polycoords[-1]-self.location).length,3)}" if len(self.polycoords)>0 and self.location else ""],alignH="RIGHT",alignV='BOTTOM',activeKey=self.activeKey)
        
        draw_Text(context,0,preferences().font_size,text=[f"H : {'Show' if not self.show_help else 'Hide'} Help"],alignH="LEFT",activeKey=self.activeKey)
        draw_Text(context,0,preferences().font_size,text=[f"Segments: {self.circle_segments}" if self.draw_type=='CIRCLE' else '',f"{self.draw_type} | {self.poly_type}",],alignH="CENTER",activeKey=self.activeKey,start_x=self.mouse_current_x,start_y=self.mouse_current_y)
        
        #draw_Text(context,0,preferences().font_size,text=[f"Segments: {self.circle_segments}" if self.draw_type=='CIRCLE' else '',f"Shape: {self.draw_type} | {self.poly_type}",f"D: Mode ({self.operation})"],alignV="TOP",activeKey=self.activeKey)
        #draw_Text(context,0,preferences().font_size,text=[f"Period : Grid Location({'Cursor' if self.grid_to_cursor else 'Near Object'})" if self.align_to_view else "","Hold ALT : Intersect Snapping" if self.draw_type=='POLYGON' else '',"Hold SHIFT : Snapping","Hold CTRL: Show Grid","SPACE : Clear Shape","Z : Undo",f"P : Hold Grid ({'OFF' if self.auto_hide_grid else 'ON'})",f"M : Length Snapping {'(ON)' if self.snap_length else '(OFF)'}",f"T : Angle Snap ({'Grid' if self.snap_to_plane else 'Last Segment'})",f"Q : Snap Angle ({self.snap_angle})",f"I : Inset Amount ({round(self.inset_amount,3)})",f"S : SubDivide ({self.subsurf_level})",f"W : Wireframe{'(ON)' if bpy.context.space_data.overlay.show_wireframes else '(OFF)'}","SHIFT+E: Disable Align To Edges",f"E : Align To Edges {'(ON)' if self.align_to_edge else '(OFF)'}","U : Align View To Grid",f"V : Align To View {'(ON)' if self.align_to_view else '(OFF)'}","R : Rotate Grid",f"J : Red Lines ({'OFF' if self.hide_point_lines else 'ON'})",f"F : Intersect Points ({'OFF' if self.hide_cp_verts else 'ON'})",f"H : Inset Points ({'OFF' if self.hide_inset_verts else 'ON'})",f"G : Grid Type ({'Points' if not self.line_type_grid else 'Lines'})"],alignH="RIGHT",alignV='BOTTOM',activeKey=self.activeKey)
        #draw_Text(context,0,preferences().font_size,text=[f"{'A : STRIP/MESH'}","X : Polygon","C : Circle","B : Box",F"Length : {round((self.polycoords[-1]-self.location).length,3)}" if len(self.polycoords)>0 and self.location else ""],alignH="LEFT",activeKey=self.activeKey,start_x=self.mouse_current_x,start_y=self.mouse_current_y)
        #draw_Text(context,0,20,text=[f"Segments: {self.circle_segments}" if self.draw_type=='CIRCLE' else '',f"{'A : STRIP/MESH'}",f"Shape: {self.draw_type} {self.poly_type}"],alignH="CENTER",activeKey=self.activeKey)
    def main(self, context):
        scene = context.scene
        region = context.region
        rv3d = context.region_data
        coord = self.X,self.Y
        #print(self.X,self.Y)
        context.space_data.region_3d.update()
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        #print(view3d_utils.region_2d_to_vector_3d(region, rv3d, (500,500)))
        #x = math.sin(bpy.context.region_data.view_rotation.to_euler()[2])
        #y = -(math.sin(bpy.context.region_data.view_rotation.to_euler()[0]) * math.cos(bpy.context.region_data.view_rotation.to_euler()[2]))
        #z = math.cos(bpy.context.region_data.view_rotation.to_euler()[0]) * math.cos(bpy.context.region_data.view_rotation.to_euler()[1])
        #view_vector=-Vector((x,y,z))
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        hidden_objs=[]
        while ( object and (not object.visible_get() or object.type!='MESH') ):
            
            hidden_objs.append((object,object.hide_get()))
            object.hide_view=True
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        for o,s in hidden_objs:
            o.hide_view=s
        #print(object.visible_get(),object.hide_get())
        if object is None and not self.align_to_view:
            return False
        if object is None:
            object=context.active_object if self.obj is None else self.obj
            #return False
        if object is None:
            return False
        if object is not None or self.align_to_view:
            #if self.plane:
            #    delete_object_with_data(self.plane)
            #    self.plane=None
            self.bigverts=[]
            self.aligned_to_verts=[]
            self.faceverts=[]
            self.coords=[]
            self.edge_middles=[]
            self.obj=object
            #print(object)
            edge_middle=None
            if not self.plane:
                bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                self.plane=context.active_object
                for c in self.plane.users_collection:
                    c.objects.unlink(self.plane)
                bpy.context.scene.collection.objects.link(self.plane)
                if not self.empty:
                    bpy.ops.object.empty_add(type='PLAIN_AXES')
                    self.empty=context.active_object
                    self.empty.empty_display_size=0
                    self.empty.specialInfo="MirrorEmpty"
                    deselect_all()
                    context.view_layer.objects.active = None
                    #select(self.og_obj)
                #elf.plane.name='CUTTER'
                self.subsurf=self.plane.modifiers.new(type='SUBSURF',name='subsurf')
                
                self.subsurf.subdivision_type='SIMPLE'
            else:
                bpy.context.scene.collection.objects.link(self.plane)

                #link_to_collection(self.plane,bpy.context.collection)
                #print("Hi")
                
            self.subsurf.levels=self.subsurf_level
            depsgraph = bpy.context.evaluated_depsgraph_get()
            depsgraph.update()
            #print(object)
            local_normal=normal
            #print("N ",normal)
            bm=None
            rot_axis='X'
            if not self.align_to_view :
                st=time.time()
                dup_obj=duplicate_object(self.obj)
                bpy.ops.object.select_all( action='DESELECT')
                select(dup_obj)
                bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
                
                obj_rotation=dup_obj.evaluated_get(context.evaluated_depsgraph_get()).rotation_euler.to_matrix()
                
                
                if self.obj.type=='MESH':
                    for m in dup_obj.modifiers:
                        if m.type=='BEVEL' and m.segments>1 and m.width<preferences().bevel_threshold and m.limit_method!='WEIGHT':
                            m.show_viewport=False
                    object_evaluated=dup_obj.evaluated_get(context.evaluated_depsgraph_get())
                   
                    bm= bmesh.new()

                    bm.from_mesh(object_evaluated.data)
                        
                    bm.faces.ensure_lookup_table()
                    
                    #bm.transform(object_evaluated.matrix_world)
                    #tree=BVHTree.FromBMesh(bm)
                    (result, location2, normal, index, object2, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                    hidden_objs=[]
                    while ( object2 and object2 !=dup_obj):
                        
                        hidden_objs.append((object2,object2.hide_get()))
                        object2.hide_view=True
                        (result, location2, normal, index, object2, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                    for o,s in hidden_objs:
                        o.hide_view=s
                    bm.edges.ensure_lookup_table()
                    bm.verts.ensure_lookup_table()
                    self.aligned_to_verts_middle=[]
                    #print(location, normal,index2,distance)
                    rot_difference=None
                    self.active_edge_length=1
                    if index is not None:
                        # self.edge_middles=[]
                        # self.all_edge_middles=[]
                        # self.all_verts=[]
                        self.edge_middles=[((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2,(object_evaluated.matrix_world@a.verts[0].co+((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2))/2,(object_evaluated.matrix_world@a.verts[1].co+((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2))/2) for a in bm.faces[index].edges]
                        self.all_edge_middles=[((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2,(object_evaluated.matrix_world@a.verts[0].co+((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2))/2,(object_evaluated.matrix_world@a.verts[1].co+((object_evaluated.matrix_world@a.verts[0].co+object_evaluated.matrix_world@a.verts[1].co)/2))/2,object_evaluated.matrix_world@a.verts[0].co,object_evaluated.matrix_world@a.verts[1].co) for a in bm.edges] if not self.obj==self.last_obj else self.all_edge_middles
                        self.all_verts=[object_evaluated.matrix_world@a.co for a in bm.verts] if not self.obj==self.last_obj else self.all_verts
                        self.last_obj=self.obj
                        #print(self.all_edge_middles)
                        
                        #print(self.edge_middles)
                        #print(len(self.all_edge_middles))
                        local_normal=bm.faces[index].normal
                        #print(local_normal)
                        
                        if self.active_edge_index is not None:
                            active_edge=bm.faces[index].edges[self.active_edge_index%len(bm.faces[index].edges)]
                        
                            self.aligned_to_verts=[object_evaluated.matrix_world@active_edge.verts[0].co.copy(),object_evaluated.matrix_world@active_edge.verts[1].co.copy()]
                            edge_middle=(self.aligned_to_verts[0]+self.aligned_to_verts[1])/2
                            if len(active_edge.link_faces)>1:
                                #print(active_edge.link_faces[0].normal,active_edge.link_faces[1].normal)
                                edge_normal=(active_edge.link_faces[0].normal+active_edge.link_faces[1].normal)/2
                                if (math.isclose(abs(local_normal.x), 0, abs_tol=0.003)and math.isclose(abs(local_normal.y), 0, abs_tol=0.003)) and self.align_to_edge_normal:
                                    #print(local_normal)
                                    local_normal=edge_normal*2-Vector((0,0,-1))
                                    #print(local_normal)
                            else:
                                edge_normal=active_edge.link_faces[0].normal
                            self.active_edge_length=active_edge.calc_length()
                            direction=(object_evaluated.matrix_world@active_edge.verts[0].co-object_evaluated.matrix_world@active_edge.verts[1].co).normalized()
                            
                            if self.align_to_edge_normal:
                                cross=local_normal.cross(edge_normal)
                                
                                rot_difference=math.atan2(cross.dot( direction), local_normal.dot(edge_normal))
                        selected_middle=Vector((0,0,0))
                        
                        if self.active_edge_indices:
                            for i in self.active_edge_indices:
                                #if i< len(self.all_edge_middles):
                                    
                                    if i in self.all_edge_middles:
                                        selected_middle=selected_middle+i[0]
                                        self.aligned_to_verts_middle.extend([i[3],i[4]])
                                        #index_of_mid=self.all_edge_middles.index(i)
                                        #if index_of_mid:
                                            #self.aligned_to_verts_middle.extend([object_evaluated.matrix_world@bm.edges[index_of_mid].verts[0].co,object_evaluated.matrix_world@bm.edges[index_of_mid].verts[1].co])
                                        
                                #print(selected_middle)
                            edge_middle=selected_middle/len(self.active_edge_indices)
                        if self.active_vert_index is not None:
                            local_normal=bm.verts[self.active_vert_index].normal.normalized()
                            normal=local_normal.normalized()
                            #print(getVertexNormal(bm.verts[self.active_vert_index],bm))
                            #print(normal)
                            edge_middle=object_evaluated.matrix_world@bm.verts[self.active_vert_index].co
                self.normal=normal
                delete_object_with_data(dup_obj)
            z = Vector((0,0,1))
            
            
                
            
            
            
            if not self.align_to_view:
                if not (math.isclose(abs(local_normal.x), 0, abs_tol=0.003)and math.isclose(abs(local_normal.y), 0, abs_tol=0.003)):
                    a1=Vector((0,-1)).angle_signed(Vector((local_normal.x,local_normal.y)))
                    if local_normal!=Vector((0,0,0)):
                        rot = z.rotation_difference( local_normal ).to_euler()
                        self.plane.rotation_euler= rot
                        self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(-a1, 3, 'Z')).to_euler()
                        
                else:
                    self.plane.rotation_euler=[0,0,0]
                self.plane.rotation_euler=(obj_rotation@self.plane.rotation_euler.to_matrix() ).to_euler()
                plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
                
                
                
                
                faceverts=[]
                depsgraph.update()
                object_evaluated=self.obj.evaluated_get(depsgraph)
                #st=time.time()
                if context.scene.rt_tools.coplanar_faces and bm:
                    cp_verts,cp_faces=coplanar_faces(bm,bm.faces[index])
                else:
                    cp_verts,cp_faces=[],[]        
                self.bigverts=[]
                #print(cp_verts)
                center=None
                # print(time.time()-st)
                if len(cp_verts)>2:
                    bm_for_center=bmesh.new()
                    for  v in cp_verts:
                        bm_for_center.verts.new(object_evaluated.matrix_world@v.co+grid_offset*normal)
                    bm_for_center.faces.new(bm_for_center.verts)
                    bm_for_center.faces.ensure_lookup_table()
                    
                    mesh_data = bpy.data.meshes.new('Test')
                    bm_for_center.to_mesh(mesh_data)
                    mesh_obj = bpy.data.objects.new('Test', mesh_data)
                    
                    bm_for_center.clear()
                    bpy.context.collection.objects.link(mesh_obj)
                    bpy.ops.object.select_all( action='DESELECT')
                    select(mesh_obj)
                    rotation=self.plane.rotation_euler.copy()
                    mesh_obj.data.use_auto_smooth=True
                    mesh_obj.rotation_mode='ZYX'
                    mesh_obj.rotation_euler[0],mesh_obj.rotation_euler[1],mesh_obj.rotation_euler[2]=-rotation[0],-rotation[1],-rotation[2]
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
                    mesh_obj.rotation_mode='XYZ'
                    mesh_obj.rotation_euler=rotation
                    
                    
                    """plane=duplicate_object(self.plane)
                    select(plane)

                    bpy.ops.object.parent_set()
                    plane.location=(0,0,0)
                    plane.rotation_euler=(0,0,0)
                    plane.scale=(1,1,1)
                    print(self.plane.location)
                    select(mesh_obj)
                    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')"""
                    #bm_for_center=bmesh.new()
                    bm_for_center.from_mesh(mesh_obj.data)
                    bm_for_center.faces.ensure_lookup_table()
                    
                    #mesh_obj.matrix_world@=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world
                    center=mesh_obj.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world@bm_for_center.faces[0].calc_center_bounds()
                    bm_for_center.free()
                    #delete_object_with_data(plane)
                    delete_object_with_data(mesh_obj)
                    #bpy.context.scene.cursor.location=center
                    center=raycast(center,normal,object_evaluated.matrix_world@cp_verts[0].co+grid_offset*normal,normal)
                    #print(center)
                    
                    bm_for_center.free()
                if not self.hide_inset_verts and bm:
                    faceverts+=[(object_evaluated.matrix_world@v.co)+grid_offset*normal for v in bm.faces[index].verts]
                #self.bigverts.extend(faceverts)
                
                
                
                #self.center_all=None
                #if len(cp_faces)>1:
                #    print(cp_faces)
                #    joined_face=bmesh.utils.face_join(cp_faces)
                #    print(joined_face)
                #    if joined_face:
                #        self.center_all=joined_face.calc_center_bounds()+grid_offset*normal
                #        print(self.center_all)
                #minX=min([v[0] for v in faceverts])
                #minY=min([v[1] for v in faceverts])
                #minZ=min([v[2] for v in faceverts])
                #maxX=max([v[0] for v in faceverts])
                #maxY=max([v[1] for v in faceverts])
                #maxZ=max([v[2] for v in faceverts])
                #meanX=mean([v[0] for v in faceverts])
                #meanY=mean([v[1] for v in faceverts])
                #meanZ=mean([v[2] for v in faceverts])
                #centroid=(meanX,meanY,meanZ)
                all_verts=[]
                if bm:
                    bm.faces.ensure_lookup_table()
                    centroid=object_evaluated.matrix_world@bm.faces[index].calc_center_median()+grid_offset*normal

                    self.centroid=(object_evaluated.matrix_world@bm.faces[index].calc_center_median_weighted()+grid_offset*normal).to_tuple()
                    distances=[]
                    for v in faceverts:
                        distances.append((v,(v-Vector(centroid)).length))
                    distances=sorted(distances,key =lambda v:v[1])[-2:]
                    scale_face=sum(v[1] for v in distances)
                    if not self.hide_cp_verts:
                        faceverts.extend([(object_evaluated.matrix_world@v.co)+grid_offset*normal for v in cp_verts])
                    all_verts=faceverts[:]
                    if cp_faces:
                        #print(cp_faces)
                        faces=bmesh.ops.inset_region(bm,faces=cp_faces,thickness=scale_face*self.inset_amount,use_even_offset=True,use_boundary =True)
                        #print(faces)
                        #bmesh.ops.inset_region(bm,faces=[bm.faces[index]],thickness=scale/self.inset_amount,use_even_offset=True)
                        bm.faces.ensure_lookup_table()
                        fverts=set([])
                        
                        for f in faces['faces']:
                            fverts.update(f.verts)
                        if not self.hide_inset_verts:
                            faceverts+=[(object.matrix_world@v.co)+grid_offset*normal for v in fverts]
                        all_verts+=[(object.matrix_world@v.co)+grid_offset*normal for v in fverts]
                    #bm.free()
                    #faceverts+=[(object.matrix_world@v.co)+grid_offset*normal for v in bm.faces[index].verts]
                #print(time.time()-st)
                #if self.event.shift:
                #    self.plane.location = object.matrix_world@bm.faces[index].calc_center_bounds()
                #    centroid=object.matrix_world@bm.faces[index].calc_center_bounds()
                #else:
                #print(center)
                distances=[]
                if self.obj:
                    center_1=center if center else centroid
                    for v in all_verts:
                        distances.append((v,(v-Vector(center_1)).length))
                    distances=sorted(distances,key =lambda v:v[1])[-2:]
                    #print(distances)
                    scale=sum(v[1] for v in distances)/1.8
                    #print(myceil(0.4,0.3))
                    scale=myceil(scale,0.3)
                    scale=max(0.05,scale)
                    #scale=max(object_evaluated.dimensions[:])
                    object_evaluated=self.obj.evaluated_get(depsgraph)
                    #scale=max(object_evaluated.dimensions[:])/1.5
                    if preferences().grid_size=='Dimensions':
                        scale=get_dimensions(self.obj)
                    if self.scale_to_edge:
                        scale=self.active_edge_length*(2**(self.subsurf_level-4))
                    #self.plane_scale=Vector((scale,scale,scale)) if self.plane_scale==Vector((0,0,0)) else self.plane_scale
                    #self.plane_scale=Vector((scale,scale,scale))*self.plane_scale
                    self.plane.scale=Vector((scale,scale,scale))*self.plane_scale[0]
                if center:
                    self.plane.location =Vector(center)
                else:
                    self.plane.location =Vector(self.centroid)
                self.empty.location=self.plane.location
                self.empty.rotation_euler=self.plane.rotation_euler
                if self.grid_to_edge and edge_middle:
                    self.plane.location = edge_middle+grid_offset*normal
                if self.active_vert_index is not None:
                    self.plane.location = edge_middle+grid_offset*normal
                #print(self.align_to_edge and self.active_edge_index)
                if self.align_to_edge and self.active_edge_index is not None:
                    a=(plane_evaluated.matrix_world@plane_evaluated.data.vertices[0].co-plane_evaluated.matrix_world@plane_evaluated.data.vertices[1].co).normalized()
                    cross=a.cross(direction)
                    self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.atan2(cross.dot( self.normal), a.dot(direction)), 3, 'Z')).to_euler()
                    #print("OUt",math.degrees(rot_difference))
                    
                    if rot_difference is not None and self.align_to_edge_normal:
                        #print("IN",math.degrees(rot_difference))
                        self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(-rot_difference, 3, rot_axis)).to_euler()
                
                else:
                    #if self.rotation_axis=='X':
                        self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_x), 3, 'X')).to_euler()
                    #elif self.rotation_axis=='Y':
                        self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_y), 3, 'Y')).to_euler()
                    #elif self.rotation_axis=='Z':
                        self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_z), 3, 'Z')).to_euler()
                    
                
                
                
                bpy.ops.object.select_all( action='DESELECT')
                plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
                mesh = plane_evaluated.data
                mesh.calc_loop_triangles()
                bm = bmesh.new()
                bm.from_mesh(mesh)
                bm.faces.ensure_lookup_table() 
                #indices = np.empty((len(mesh.loop_triangles), 3), 'i')

                #mesh.loop_triangles.foreach_get(
                #    "vertices", np.reshape(indices, len(mesh.loop_triangles) * 3))
                #coords = [object_evaluated.matrix_world@v.co for v in bm.verts]
                #indices = [e.vert for e in bm.faces[index].loops] 
                
                coords = [plane_evaluated.matrix_world@v.co for v in bm.verts]
                
                self.indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges] 
                #print(self.indices)
                #print([v.z for v in coords])
                #print(indices)
                self.faceverts=faceverts+[Vector(self.centroid)]
                #self.bigverts.append(Vector(self.centroid))
                #print(self.centroid)
                #print(center)
                #print(self.active_vert_index,edge_middle)
                if self.active_vert_index is not None:
                    if edge_middle:
                        #print("EM",edge_middle)
                        self.bigverts.append(Vector(edge_middle+grid_offset*normal))
                
                elif not self.grid_to_edge:
                    if center:
                        self.bigverts.append(Vector(center))
                    else:
                        self.bigverts.append(Vector(self.centroid))
                else:
                    if edge_middle:
                        self.bigverts.append(Vector(edge_middle+grid_offset*normal))
                #if self.center_all:
                #    self.faceverts=faceverts+[self.center_all]
                #self.coords=coords+self.faceverts
                #for v in faceverts:
                #    direction=v-Vector(centroid)
                #    unitVector=direction.normalized()
                #    for i in range(2,4):
                #        pass
                        #self.faceverts.append((v-Vector(unitVector*scale/6)))
                #print(self.normal)
                self.plane_normal=self.normal
                mx_inv = self.plane.matrix_world.inverted()
                mx_norm = mx_inv.transposed().to_3x3()

                self.plane_normal = mx_norm @ self.plane.data.polygons[0].normal
                self.coords=coords
                bm.free()
            else:
                
                location=object.location.copy() if self.obj else bpy.context.scene.cursor.location.copy()
                location=raycast(ray_origin,view_vector,location,-view_vector)
                #print(view_vector)
                #view_vector=bpy.context.region_data.view_rotation.to_euler().to_matrix()@Vector((0,0,1))
                distance=(ray_origin-location).length
                if self.obj:
                    distance-=max(self.obj.dimensions[:])
                
                self.plane.location=location-view_vector*max(self.obj.dimensions[:]) if not self.grid_to_cursor else context.scene.cursor.location-0.05*view_vector
                
                #self.plane.location=ray_origin+distance*0.999*view_vector
                self.plane.rotation_euler=bpy.context.region_data.view_rotation.to_euler()
                x = math.sin(bpy.context.region_data.view_rotation.to_euler()[2])
                y = -(math.sin(bpy.context.region_data.view_rotation.to_euler()[0]) * math.cos(bpy.context.region_data.view_rotation.to_euler()[2]))
                z = math.cos(bpy.context.region_data.view_rotation.to_euler()[0]) * math.cos(bpy.context.region_data.view_rotation.to_euler()[1])
                view_vector2=Vector((x,y,z))
                #print(self.plane.rotation_euler)
                #print(self.plane.matrix_world@self.plane.data.polygons[0].normal)
                self.plane_normal=-1*view_vector
                self.plane.scale=Vector((1,1,1))*self.plane_scale[0]
                self.empty.location=self.plane.location
                self.empty.rotation_euler=self.plane.rotation_euler
                #print(self.plane_normal)
            self.centroid=self.plane.location.copy()
            self.rotated_by=self.plane.rotation_euler.copy()
            #self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.coords})
            #self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.faceverts})
            #self.plane.display_type='WIRE'
            bpy.context.scene.collection.objects.unlink(self.plane)
            #if len(self.plane.users_collection)>0:
            #    self.plane.users_collection[0].objects.unlink(self.plane)
            #context.area.tag_redraw()
            self.grid_drawen=True
            self.normal=self.plane_normal.normalized()
            
            #print(self.normal)
            self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.bigverts})
            #backRot=-math.degrees(self.plane.rotation_euler[2])
            #self.plane.matrix_world @= Matrix.Rotation(math.radians(backRot), 4, 'Z')
            self.batch_alignment_line=batch_for_shader(self.shader,'LINES', {"pos": self.aligned_to_verts},indices=[(0,1)] if self.aligned_to_verts else [])
            if self.aligned_to_verts_middle:
                #print(self.aligned_to_verts_middle)
                self.batch_middle_alignment_line=batch_for_shader(self.shader,'LINES', {"pos": self.aligned_to_verts_middle},indices=[(i,i+1) for i in range(0,len(self.aligned_to_verts_middle),2)] if self.aligned_to_verts_middle else [])
            else:
                self.batch_middle_alignment_line=None
            #if self.active_object and preferences().use_active_object_only:
            #    self.obj=self.active_object
            #print(self.obj)
            #self.plane.matrix_world @= Matrix.Rotation(math.radians(self.rotation_z), 4, 'Z')
        return True
    def find_yellow_coords(self):
            plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
            yellow_coords=[]
            #yellow_coords.extend(findrectanglecoords(plane_evaluated.location,plane_evaluated.matrix_world@plane_evaluated.data.vertices[1].co,self.plane,center=False))
            #yellow_coords.extend(findrectanglecoords(plane_evaluated.location,plane_evaluated.matrix_world@plane_evaluated.data.vertices[2].co,self.plane,center=False))
            for p in self.polycoords:
                yellow_coords.extend(findrectanglecoords(p,plane_evaluated.matrix_world@plane_evaluated.data.vertices[1].co,self.plane,center=False))
                yellow_coords.extend(findrectanglecoords(p,plane_evaluated.matrix_world@plane_evaluated.data.vertices[2].co,self.plane,center=False))
            #print(yellow_coords)
            
            indices=[]
            for i in range(0,len(yellow_coords),4):
                indices.extend([(i,i+1),(i,i+3)])
            return yellow_coords,indices
    def generate_grid(self,hide=False):
        if self.grid_drawen:
            bpy.context.scene.collection.objects.link(self.plane)
            #link_to_collection(self.plane,bpy.context.collection)
            plane_evaluated=self.plane.evaluated_get(bpy.context.evaluated_depsgraph_get())
            
            #self.normal=plane_evaluated.matrix_world@plane_evaluated.data.polygons[0].normal
            coords = [plane_evaluated.matrix_world@v.co for v in plane_evaluated.data.vertices]
            self.indices = [(e.vertices[0],e.vertices[1]) for e in plane_evaluated.data.edges] 
            if not self.hide_cp_verts:
                self.yellow_coords,self.yellow_indices=self.find_yellow_coords()
                intersections=find_intersections(self.yellow_coords,self.yellow_indices)
                self.faceverts+=intersections
            
            middle_cross_coords=[]
            #print(plane_evaluated.location)
            if self.bigverts:
                middle_cross_coords.extend(findrectanglecoords(self.bigverts[0],plane_evaluated.matrix_world@plane_evaluated.data.vertices[1].co,self.plane,center=False))
                middle_cross_coords.extend(findrectanglecoords(self.bigverts[0],plane_evaluated.matrix_world@plane_evaluated.data.vertices[2].co,self.plane,center=False))
            indices_middle=[]
            for i in range(0,len(middle_cross_coords),4):
                indices_middle.extend([(i,i+1),(i,i+3)])
            self.coords=coords
            if self.line_type_grid:
                self.batch_points=batch_for_shader(self.shader, 'LINES', {"pos": self.coords},indices=self.indices)
            else:
                
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.coords})
            #print(indices)
            if not self.hide_point_lines:
                self.batch_yellow_points=batch_for_shader(self.shader, 'LINES', {"pos": self.yellow_coords},indices=self.yellow_indices)
            else:
                self.batch_yellow_points=batch_for_shader(self.shader,'POINTS',{"pos":[]})
            self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.faceverts})
            self.batch_big_points=batch_for_shader(self.shader, 'LINES', {"pos": middle_cross_coords},indices=indices_middle)
            bpy.context.scene.collection.objects.unlink(self.plane)
            if hide:
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader,'POINTS',{"pos":[]})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_big_points=batch_for_shader(self.shader, 'LINES', {"pos": []},indices=[])
            #if len(self.plane.users_collection)>0:
            #    self.plane.users_collection[0].objects.unlink(self.plane)        
        #return {'RUNNING_MODAL'}
    def snap_to_angle(self,location,to_plane=False):
        temp_point=None
        if len(self.polycoords)<2 or to_plane:
            direction=self.plane.matrix_world@self.plane.data.vertices[1].co-self.plane.matrix_world@self.plane.data.vertices[0].co
            temp_point=self.polycoords[-1]-direction.normalized()
        else:
            direction=self.polycoords[-1]-self.polycoords[-2]
        direction=direction.normalized()
        direction1=location-self.polycoords[-1]
        direction1=direction1.normalized()                        
        cross=direction.cross(direction1)
        angle=math.atan2(cross.dot( self.normal), direction.dot(direction1))
        angle=math.degrees(angle)
        angle=myround(angle,self.snap_angle)
        plane_direction=self.plane.matrix_world@self.plane.data.vertices[1].co-self.plane.matrix_world@self.plane.data.vertices[0].co
        cross=plane_direction.cross(direction1)
        plane_angle=math.atan2(cross.dot( self.normal), plane_direction.dot(direction1))
        plane_angle=math.degrees(plane_angle)
        plane_angle=myround(plane_angle,self.snap_angle)
        normal_on_xz=self.normal.copy()
        #print(angle)
        normal_on_xz.x=0
        if angle!=self.last_snap_angle or self.last_snap_direction is None:
            d=0 if math.isclose(normal_on_xz.magnitude,0) else normal_on_xz.magnitude
            angle_y = -math.asin(self.normal.x)
            
            norm_by_d=1*(-1 if self.normal.z<0 else 1) if math.isclose(abs(self.normal.z),d,abs_tol=0.003) else self.normal.z / d 
            
            angle_x = 0 if math.isclose(d,0) else math.acos(norm_by_d) * (1 if self.normal.y >= 0 else -1)
            #print(math.degrees(angle_x),math.degrees(angle_y))
            retranslate = Matrix.Translation((self.polycoords[-1][0], self.polycoords[-1][1], self.polycoords[-1][2]))
            rerotatex   = Matrix.Rotation(-angle_x, 4, 'X')
            rerotatey   = Matrix.Rotation(-angle_y, 4, 'Y')
            rotatez     = Matrix.Rotation(math.radians(angle), 4, 'Z')
            rotatey     = Matrix.Rotation(angle_y, 4, 'Y')
            rotatex     = Matrix.Rotation(angle_x, 4, 'X')
            translate   = Matrix.Translation((-self.polycoords[-1][0], -self.polycoords[-1][1], -self.polycoords[-1][2]))
            if len(self.polycoords)<2 or to_plane:
                direction1 = retranslate @ rerotatex @ rerotatey @ rotatez @ rotatey @ rotatex @ translate@temp_point
                
            else:
                direction1 = retranslate @ rerotatex @ rerotatey @ rotatez @ rotatey @ rotatex @ translate@self.polycoords[-2]
            direction2 = retranslate @ rerotatex @ rerotatey @ rotatez @ rotatey @ rotatex @ translate@self.polycoords[-1]
            direction=direction2-direction1
            self.last_snap_angle=angle
            self.last_snap_direction=direction
        else:
            direction=self.last_snap_direction
        #direction = retranslate @ rerotatey @ rerotatex @ rotatez @ rotatex @ rotatey @ translate@direction
        #print(math.degrees(direction.angle(direction_og)))
        distance=(self.polycoords[-1]-Vector(location)).length
        #print(math.cos(math.radians(plane_angle)))
        #cell_size=self.plane.dimensions[0]/math.sqrt(4**self.subsurf_level)
        cell_size=0.1
        #print(plane_angle,(math.cos(math.radians(plane_angle))))
        #print(round(cell_size/(math.cos(math.radians(plane_angle)) if abs(plane_angle)!=90 else 1),7))
        if self.snap_length:
            if plane_angle>45 and plane_angle<135 or(plane_angle>-135 and plane_angle<-45):
                distance=myround(distance,(round(cell_size/(math.sin(math.radians(plane_angle)) if abs(plane_angle)!=0 else 1)/2,7)))
            else:
                distance=myround(distance,(round(cell_size/(math.cos(math.radians(plane_angle)) if abs(plane_angle)!=90 else 1)/2,7)))
        #print(round(cell_size/(math.sin(math.radians(plane_angle)) if abs(plane_angle)!=0 and abs(plane_angle)!=180 else 1),7))
        #distance=myround(distance,(round(cell_size/(math.sin(math.radians(plane_angle)) if abs(plane_angle)!=0 and abs(plane_angle)!=180 else 1),7)))
        
        return self.polycoords[-1]+(direction).normalized()*distance 
    def modal(self,context,event):
        #self.activeKey=f"{'SHIFT+' if event.shift else ''}{'CTRL+' if event.ctrl else ''}{event.type}"# if event.type in {'MOUSEMOVE','LEFTMOUSE','RIGHTMOUSE','DOWN_ARROW','UP_ARROW','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'} else None
        self.mouse_current_x,self.mouse_current_y=event.mouse_region_x,event.mouse_region_y
        if event.type=='OSKEY':
            return {'RUNNING_MODAL'}
        if event.type=='TAB':
            if event.value=='PRESS':
                self.tab_down=True
            else:
                self.tab_down=False
            return {'RUNNING_MODAL'}
        """if event.type=='LEFT_SHIFT':
            if event.value=='PRESS':
                self.activeKey="SHIFT"
            else:
                self.activeKey=None
        if event.type=='LEFT_ALT':
            if event.value=='PRESS':
                self.activeKey="ALT"
            else:
                self.activeKey=None"""
        context.area.tag_redraw()
        if event.type=='DOWN_ARROW' and event.value=='PRESS'and self.grid_drawen:
            self.plane_scale.x-=0.01
            self.plane_scale.y-=0.01
            self.plane_scale.z-=0.01
            self.main(context)
            self.generate_grid()
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='UP_ARROW' and event.value=='PRESS'and self.grid_drawen:
            self.plane_scale.x+=0.01
            self.plane_scale.y+=0.01
            self.plane_scale.z+=0.01
            self.main(context)
            self.generate_grid()
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='J' and event.value=='PRESS' and self.align_to_edge:
            self.scale_to_edge=not self.scale_to_edge
            self.main(context)
            self.generate_grid()
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='S':
            if event.value=='PRESS':
                if self.subsurf is not None:
                    if event.alt:
                        self.subsurf_level-=1
                    else:
                        self.subsurf_level+=1
                self.subsurf_level=max(0,self.subsurf_level)
                self.subsurf_level=min(7,self.subsurf_level)
                self.event=event
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.activeKey='S'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='F':
            if event.value=='PRESS':
                if self.rotation_axis=='X':
                    self.rotation_axis='Y'
                elif self.rotation_axis=='Y':
                    self.rotation_axis='Z'
                else:
                    self.rotation_axis='X'
                self.activeKey='F'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='R' :
            if event.value=='PRESS':
                if event.alt:
                    if event.shift:
                        if self.rotation_axis=='Z':
                            self.rotation_z-=0.2
                        elif self.rotation_axis=='X':
                            self.rotation_x-=0.2
                        else:
                            self.rotation_y-=0.2
                    else:
                        if self.rotation_axis=='Z':
                            self.rotation_z-=15
                        elif self.rotation_axis=='X':
                            self.rotation_x-=15
                        else:
                            self.rotation_y-=15
                else:
                    if event.shift:
                        if self.rotation_axis=='Z':
                            self.rotation_z+=0.2
                        elif self.rotation_axis=='X':
                            self.rotation_x+=0.2
                        else:
                            self.rotation_y+=0.2
                    else:
                        if self.rotation_axis=='Z':
                            self.rotation_z+=15
                        elif self.rotation_axis=='X':
                            self.rotation_x+=15
                        else:
                            self.rotation_y+=15
                self.align_to_edge=False
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                #backRot=-math.degrees(self.plane.rotation_euler[2])
                #self.plane.matrix_world @= Matrix.Rotation(math.radians(backRot), 4, 'Z')
                #self.plane.matrix_world @= Matrix.Rotation(math.radians(self.rotation_z), 4, 'Z')
                self.main(context)
                #self.plane.rotation_euler = (self.plane.rotation_euler.to_matrix() @ Matrix.Rotation(math.radians(self.rotation_z), 3, 'Z')).to_euler()
                self.generate_grid()
                self.activeKey='R'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='V':
            if event.value=='PRESS':
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                self.align_to_view=not self.align_to_view
                self.rotation_z=0
                self.rotation_x=0
                self.rotation_y=0
                self.main(context)
                self.align_to_edge=False
                self.generate_grid()
                self.activeKey='V'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='PERIOD':
            if event.value=='PRESS':
                self.grid_to_cursor=not self.grid_to_cursor
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.activeKey='PERIOD'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type=='Q' :
            if event.value=='PRESS':
                if event.shift:
                    if event.alt:
                        self.snap_angle-=3.75
                    else:
                        self.snap_angle+=3.75
                else:
                    if event.alt:
                        self.snap_angle-=7.5
                    else:
                        self.snap_angle+=7.5
                self.snap_angle=max(self.snap_angle,3.75)
                context.scene.rt_tools.snap_angle=self.snap_angle
                self.activeKey='Q'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='B':
            if event.value=='PRESS':
                self.draw_type='BOX'
                if preferences().remember_last_shape:
                    context.scene.rt_tools.default_shape=self.draw_type
                self.last_snap_angle=0
                self.last_snap_direction=None
                self.activeKey='B'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='C':
            if event.value=='PRESS':
                self.draw_type='CIRCLE'
                if preferences().remember_last_shape:
                    context.scene.rt_tools.default_shape=self.draw_type
                self.last_snap_angle=0
                self.last_snap_direction=None
                
                self.activeKey='C'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='X' :
            if event.value=='PRESS':
                self.draw_type='POLYGON'
                if preferences().remember_last_shape:
                    context.scene.rt_tools.default_shape=self.draw_type
                self.last_snap_angle=0
                self.last_snap_direction=None
                self.activeKey='X'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='G':
            if event.value=='PRESS':
                self.line_type_grid=not self.line_type_grid
                self.point_distance_threshold=1 if not self.line_type_grid and preferences().show_close_points else 100
                self.generate_grid()
                self.activeKey='G'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='THREE' :
            if event.value=='PRESS':
                if self.grid_drawen:
                    self.hide_point_lines=not self.hide_point_lines
                    self.main(context)
                    self.generate_grid()
                self.activeKey='3'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='ONE':
            if event.value=='PRESS':
                if self.grid_drawen:
                    self.hide_cp_verts=not self.hide_cp_verts
                    #self.hide_point_lines=not self.hide_point_lines
                    self.main(context)
                    self.generate_grid()
                self.activeKey='1'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='TWO' :
            if event.value=='PRESS':
                if self.grid_drawen:
                    self.hide_inset_verts=not self.hide_inset_verts
                    #self.hide_point_lines=not self.hide_point_lines
                    self.main(context)
                    self.generate_grid()
                self.activeKey='2'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='H' :
            if event.value=='PRESS':
                self.show_help=not self.show_help
                context.scene.rt_tools.show_help=self.show_help
                self.activeKey='H'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='T' :
            if event.value=='PRESS':
                self.snap_to_plane=not self.snap_to_plane
                self.activeKey='T'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='P':
            if event.value=='PRESS':
                self.auto_hide_grid=not self.auto_hide_grid
                context.scene.rt_tools.auto_hide_grid=self.auto_hide_grid
                self.X=event.mouse_region_x
                self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.grid_hidden=self.auto_hide_grid
                self.activeKey='P'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='A' :
            #if self.operation=='Draw':
            if event.value=='PRESS':
                self.poly_type='MESH' if self.poly_type!='MESH' else 'STRIP'
                
                if preferences().remember_last_shape:
                    context.scene.rt_tools.current_shape=self.poly_type
                
                self.activeKey='A'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='D':
            if event.value=='PRESS':
                self.operation="Draw" if self.operation!='Draw' else "Boolean"
                context.scene.rt_tools.pc_operation=self.operation
                global grid_offset
                grid_offset=0.003 if self.operation=='Boolean' else 0
                #self.poly_type='CYCLIC' if self.operation=='Boolean' else self.poly_type
                self.activeKey='D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='SLASH':
            if event.value=='PRESS':
                context.space_data.region_3d.view_perspective='ORTHO' if context.space_data.region_3d.view_perspective!='ORTHO' else 'PERSP'
                self.activeKey='/'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='RIGHTMOUSE' and event.value=='PRESS' and event.shift and not event.alt and len(self.polycoords)<1:
            scene= context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            if event.ctrl and object:
                bm= bmesh.new()
                bm.from_mesh(object.evaluated_get(bpy.context.evaluated_depsgraph_get()).data)
                bm.faces.ensure_lookup_table()
                bpy.context.scene.cursor.location=object.matrix_world@bm.faces[index].calc_center_bounds()
                bm.free()
            else:
                bpy.context.scene.cursor.location=location
            return {'RUNNING_MODAL'}
        if event.type=='RIGHTMOUSE' and event.value=='PRESS'  and  event.ctrl and not event.alt and len(self.polycoords)<1 :
            if self.plane:
                self.align_to_vert=True
                scene= context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                
                (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                hidden_objs=[]
                while ( object and (not object.visible_get() or object.type!='MESH')):
                    
                    hidden_objs.append((object,object.hide_get()))
                    object.hide_view=True
                    (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                for o,s in hidden_objs:
                    o.hide_view=s
                if object:
                    self.X=event.mouse_region_x
                    self.Y=event.mouse_region_y
                    self.main(context)
                    location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                    if location1:
                        verts=[(v,(location1-v).length) for v in self.all_verts]
                        if len(verts)>0:
                                closest=sorted(verts,key=lambda v:v[1])[0][0]
                                self.active_vert_index=self.all_verts.index(closest)
                            #print(self.active_vert_index)
                            
                self.main(context)
                self.generate_grid()
            else:
                self.report({'WARNING'},'Place a Grid before Aligning to Edge')
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='RIGHTMOUSE' and event.value=='PRESS'  and (event.alt or self.tab_down) and len(self.polycoords)<1 :
            if self.tab_down if preferences().industry_keymap else event.alt:
                if self.plane:
                    self.align_to_edge=True
                    scene= context.scene
                    region = context.region
                    rv3d = context.region_data
                    coord = event.mouse_region_x,event.mouse_region_y
                    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                    
                    (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                    hidden_objs=[]
                    while ( object and (not object.visible_get() or object.type!='MESH')):
                        
                        hidden_objs.append((object,object.hide_get()))
                        object.hide_view=True
                        (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                    for o,s in hidden_objs:
                        o.hide_view=s
                    if object:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                        self.main(context)
                    location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                    if location:
                        middles=[(v,min((location-v[0]).length,(location-v[1]).length,(location-v[2]).length)) for v in self.edge_middles]
                        all_middles=[(v,min((location1-v[0]).length,(location1-v[1]).length,(location1-v[2]).length)) for v in self.all_edge_middles]
                        if len(middles)>0:
                            self.active_vert_index=None
                            if not event.shift:
                                closest=sorted(middles,key=lambda v:v[1])[0][0]
                                self.active_edge_index=self.edge_middles.index(closest)
                                #self.align_to_edge_normal=True
                                self.grid_to_edge=True

                            #self.active_edge_indices.append(self.edge_middles.index(closest))
                            if event.shift:
                                self.grid_to_edge=True
                                closest_in_all=sorted(all_middles,key=lambda v:v[1])[0][0]
                                #print("Closest : ",sorted(all_middles,key=lambda v:v[1])[0][1],self.all_edge_middles.index(sorted(all_middles,key=lambda v:v[1])[0][0]),self.all_edge_middles.index(sorted(all_middles,key=lambda v:v[1])[1][0]))
                                
                                if closest_in_all in self.active_edge_indices:
                                    self.active_edge_indices.remove(closest_in_all)
                                else:
                                    self.active_edge_indices.append(closest_in_all)
                            #print(self.active_edge_index)
                    #if not self.active_edge_indices:
                    #    self.grid_to_edge=False
                    self.main(context)
                    self.generate_grid()
                else:
                    self.report({'WARNING'},'Place a Grid before Aligning to Edge')
                context.area.tag_redraw()
            else:
                return {'PASS_THROUGH'}
            return {'RUNNING_MODAL'}
        if (event.type=='RET' and event.value=='PRESS') or (event.type=='RIGHTMOUSE' and event.value=='PRESS') and self.grid_drawen :
            #print(self.polycoords,self.polyIndices)
            
            bool_obj=None
            #bpy.context.scene.collection.objects.link(self.plane)
            delete_object_with_data(self.plane)
            if self.draw_type=='POLYGON':
                
                if self.poly_type!='MESH' :
                    bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by,only_edges=True,cyclic=False,limited_dissolve=bpy.context.scene.rt_tools.limited_dissolve)
                elif len(self.polycoords)>2:
                    bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by,limited_dissolve=bpy.context.scene.rt_tools.limited_dissolve)
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                select(self.empty)
                if preferences().use_only_active_object and self.initActiveObject:
                    select(self.initActiveObject)
                else:
                    select(self.obj)
                select(bool_obj)
                if bool_obj is not None:
                    if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                        self.report({'WARNING'},"Invalid Geometry")
                    bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
                else:
                    if self.empty:
                        delete_object(self.empty)
                    if self.fast_mode:
                        context.scene.rt_tools.keep_drawing=False
                    select(self.og_obj)
            else:
                if len(self.polycoords)>2:
                    select(self.empty)
                    bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by)
                    if preferences().use_only_active_object and self.initActiveObject:
                        select(self.initActiveObject)
                    else:
                        select(self.obj)
                    select(bool_obj)
                else:
                    if self.empty:
                        delete_object(self.empty)
                    if self.fast_mode:
                        context.scene.rt_tools.keep_drawing=False
                    select(self.og_obj)
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                if bool_obj is not None:
                    if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                        self.report({'WARNING'},"Invalid Geometry")
                    bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
            self.remove_drawHandler(context)
            
            return {'FINISHED'}
        #if event.type=='LEFTMOUSE' and event.value=='PRESS'and not self.grid_drawen:
            
        #    self.event=event
        #    self.X=event.mouse_region_x
        #    self.Y=event.mouse_region_y
        #    return self.main(context)
        
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False))  :
            if len(self.polycoords)>0 and self.draw_type=='CIRCLE':
                self.circle_segments+=1
                self.circle_segments_backup=self.circle_segments
                line_to_draw_coords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-self.last_hit_location).length,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                lines_to_draw_indices=[(i,(i+1)%(len(line_to_draw_coords))) for i in range(0,len(line_to_draw_coords))]
                self.batch_tris = batch_for_shader(self.shader, 'TRIS',{"pos": line_to_draw_coords},indices=[[0,i,i+1] for i in range(1,len(line_to_draw_coords)-1)])
                self.batch_poly = batch_for_shader(self.shader, 'LINES', {"pos": line_to_draw_coords},indices=lines_to_draw_indices)
            elif self.grid_drawen and event.ctrl:
                self.plane_scale.x+=0.05
                self.plane_scale.y+=0.05
                self.plane_scale.z+=0.05
                self.main(context)
                self.generate_grid()
                context.area.tag_redraw()
            else:
                return {'PASS_THROUGH'}
            return {'RUNNING_MODAL'}
        if (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            if len(self.polycoords)>0 and self.draw_type=='CIRCLE':
                self.circle_segments-=1
                self.circle_segments=max(self.circle_segments,3)
                self.circle_segments_backup=self.circle_segments
                line_to_draw_coords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-self.last_hit_location).length,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                lines_to_draw_indices=[(i,(i+1)%(len(line_to_draw_coords))) for i in range(0,len(line_to_draw_coords))]
                self.batch_tris = batch_for_shader(self.shader, 'TRIS',{"pos": line_to_draw_coords},indices=[[0,i,i+1] for i in range(1,len(line_to_draw_coords)-1)])
                self.batch_poly = batch_for_shader(self.shader, 'LINES', {"pos": line_to_draw_coords},indices=lines_to_draw_indices)
            elif self.grid_drawen and event.ctrl:
                self.plane_scale.x-=0.05
                self.plane_scale.y-=0.05
                self.plane_scale.z-=0.05
                self.main(context)
                self.generate_grid()
                context.area.tag_redraw()
            else:
                return {'PASS_THROUGH'}
            return {'RUNNING_MODAL'}
        #if event.type=='G' and event.value=='PRESS':
        #    self.event=event
        #    self.X=event.mouse_region_x
        #    self.Y=event.mouse_region_y
        #    self.main(context)
        #    return {'RUNNING_MODAL'}
        if event.type=='LEFT_ALT' and event.value=='PRESS' and self.draw_type=='CIRCLE' and not preferences().industry_keymap:
            self.init_x=event.mouse_x
            self.circle_segments_backup=self.circle_segments
            return {'RUNNING_MODAL'}
        if event.type=='LEFT_CTRL' and event.value=='PRESS':
            
            #if preferences().industry_keymap or len(self.polycoords)<1 or self.draw_type!='POLYGON':
            self.event=event
            if len(self.polycoords)<1:
                self.X=event.mouse_region_x
                self.Y=event.mouse_region_y
            #self.plane_scale=Vector((0,0,0))
                self.main(context)
            self.grid_hidden=False
                
            self.generate_grid()
            #self.activeKey="CTRL"
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='LEFT_CTRL' and event.value=='RELEASE':
            if self.auto_hide_grid:
                self.grid_hidden=True
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                #self.activeKey=None
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and ((not event.alt if preferences().industry_keymap else True)):
            grid_success=True
            #scene = context.scene
            #region = context.region
            #rv3d = context.region_data
            #coord = event.mouse_region_x,event.mouse_region_y
            #view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            #ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            if (not self.grid_drawen or (self.fast_mode and self.align_to_view)) and len(self.polycoords)<1 :# and self.draw_type!='POLYGON' :
                
                self.event=event
                self.X=event.mouse_region_x

                self.Y=event.mouse_region_y
                grid_success=self.main(context)
                self.generate_grid(hide=True)
            if grid_success:
                self.yellow_coords,self.yellow_indices=self.find_yellow_coords()
                
                #intersections=find_intersections(self.yellow_coords,self.yellow_indices)
                #self.faceverts+=intersections

                scene = context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                
                location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                #while object!=self.backgroundPlane and object!=None:
                #    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),location+0.001*view_vector, view_vector)  
                
                if event.shift and len(self.polycoords)>0 :
                    location=self.snap_to_angle(location,to_plane=self.snap_to_plane)
                if len(self.polycoords)>0 and event.alt and self.draw_type=='POLYGON':
                    intersect=find_current_line_intersections(self.yellow_coords,self.yellow_indices,self.polycoords[-1],location,self.polycoords)
                    location=intersect if intersect is not None else location
                green_coords=[(v,(location-v).length) for v in self.coords if (location-v).length<0.2]
                green_coords+=[(v,(location-v).length) for v in self.faceverts if (location-v).length<0.2]
                green_coords+=[(v,(location-v).length) for v in self.bigverts if (location-v).length<0.2]
                
                if self.draw_type=='POLYGON':
                    green_coords+=[(Vector(v),(location-Vector(v)).length) for v in self.polycoords if (location-Vector(v)).length<0.2]
                if len(green_coords)>0 and event.ctrl:
                    coord=sorted(green_coords,key=lambda v:v[1])[0][0]
                else:
                    coord=location
                self.polycoords.append(coord)
                if self.draw_type=='BOX':
                    if len(self.polycoords)>1:
                        #grid_corners=[self.plane.matrix_world@v.co for v in self.plane.data.vertices]
                        #print(grid_corners)
                        self.polycoords=findrectanglecoords(self.polycoords[0],coord,self.plane,center=event.alt if not preferences().industry_keymap else self.tab_down)
                        
                        delete_object_with_data(self.plane)
                        bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by,only_edges=self.poly_type!='MESH')
                        select(self.empty)
                        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                        if preferences().use_only_active_object and self.initActiveObject:
                            select(self.initActiveObject)
                        else:
                            select(self.obj)
                        select(bool_obj)
                        if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                            self.report({'WARNING'},"Invalid Geometry")
                        bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
                        self.remove_drawHandler(context)
                        
                        return {'FINISHED'}
                elif self.draw_type=='CIRCLE':
                    if len(self.polycoords)>1:
                        self.init_x=event.mouse_x
                        if not event.alt:
                            self.circle_radius_save=(self.polycoords[0]-coord).length
                        self.polycoords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-coord).length if not self.circle_radius_save else self.circle_radius_save,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                        delete_object_with_data(self.plane)
                        bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by,only_edges=self.poly_type!='MESH')
                        
                        select(self.empty)
                        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                        if preferences().use_only_active_object and self.initActiveObject:
                            select(self.initActiveObject)
                        else:
                            select(self.obj)
                        select(bool_obj)
                        if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                            self.report({'WARNING'},"Invalid Geometry")
                        bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
                        self.remove_drawHandler(context)
                        
                        return {'FINISHED'}
                else:
                    mapped=map(lambda x:(coord-x).length<0.001,self.polycoords[:-1])
                    mapped=list(mapped)
                    #if coord in self.polycoords[:-1] and len(self.polycoords)>2:
                    
                    if any(mapped) and len(self.polycoords)>2:
                        delete_object_with_data(self.plane)
                        bool_obj=create_object(cutter_names[self.draw_type],self.polycoords[:-1],self.rotated_by,only_edges=self.poly_type!='MESH',limited_dissolve=bpy.context.scene.rt_tools.limited_dissolve)
                        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                        select(self.empty)
                        if preferences().use_only_active_object and self.initActiveObject:
                            select(self.initActiveObject)
                        else:
                            select(self.obj)    
                        select(bool_obj)
                        if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                            self.report({'WARNING'},"Invalid Geometry")
                        bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
                        self.remove_drawHandler(context)
                        
                        return {'FINISHED'}
                
                    
                
                
                #if len(self.polycoords)>2:
                #    self.polycoords[len(self.polycoords)-2]=coord
                #if len(self.polycoords)>1:
                #    self.polycoords=findrectanglecoords(self.polycoords[0],self.polycoords[1],self.plane)
                #if len(self.polycoords)==1:
                #    self.polycoords.append(coord)
                #if self.draw_type=='BOX':
                #    self.polycoords=findrectanglecoords(self.polycoords[0],coord,self.plane,center=event.alt)
                #if self.draw_type=='CIRCLE':
                #    self.polycoords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-coord).length,self.circle_segments,self.normal)
                self.polyIndices=[(i,(i+1)%(len(self.polycoords))) for i in range(0,len(self.polycoords))]
                self.batch_poly = batch_for_shader(self.shader, 'LINES', {"pos": self.polycoords},indices=self.polyIndices)
                if not self.grid_hidden:
                    self.generate_grid()
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE' and event.value=='RELEASE' and self.grid_drawen:
            if self.draw_type=='BOX' or self.draw_type=='CIRCLE':
                scene = context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                #while object!=self.backgroundPlane and object!=None:
                #    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),location+0.001*view_vector, view_vector) 
                #print(object)  
                
                location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
                if event.shift and len(self.polycoords)>0 :
                    location=self.snap_to_angle(location,to_plane=self.snap_to_plane)  
                if len(self.polycoords)>0 and event.alt and self.draw_type=='POLYGON':
                    intersect=find_current_line_intersections(self.yellow_coords,self.yellow_indices,self.polycoords[-1],location,self.polycoords)
                    location=intersect if intersect is not None else location   
                green_coords=[(v,(location-v).length) for v in self.coords if (location-v).length<0.2]
                green_coords+=[(v,(location-v).length) for v in self.faceverts if (location-v).length<0.2]
                green_coords+=[(v,(location-v).length) for v in self.bigverts if (location-v).length<0.2]
                #print([v.z for v in self.coords])
                if len(green_coords)>0 and event.ctrl and not event.shift:
                    coord=sorted(green_coords,key=lambda v:v[1])[0][0]
                else:
                    
                    coord=location
                #if len(self.polycoords)>0:
                #    self.polycoords.append(coord)
                if len(self.polycoords)==1:
                    if self.polycoords[0]!=coord:
                        if self.draw_type=='BOX':
                            
                                self.polycoords=findrectanglecoords(self.polycoords[0],coord,self.plane,center=event.alt if not preferences().industry_keymap else self.tab_down)
                        elif self.draw_type=='CIRCLE':
                            self.init_x=event.mouse_x
                            if not event.alt:
                                self.circle_radius_save=(self.polycoords[0]-coord).length
                            self.polycoords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-coord).length if not self.circle_radius_save else self.circle_radius_save,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                            #self.polycoords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-coord).length,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                        delete_object_with_data(self.plane)
                        #bpy.context.scene.collection.objects.link(self.plane)
                        bool_obj=create_object(cutter_names[self.draw_type],self.polycoords,self.rotated_by,only_edges=self.poly_type!='MESH')
                        
                        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                        #if self.use_active_object_only:
                        #    self.obj=self.active_object
                        select(self.empty)
                        if preferences().use_only_active_object and self.initActiveObject:
                            select(self.initActiveObject)
                        else:
                            select(self.obj) 
                        select(bool_obj)
                        #print(context.selected_objects)
                        if bool_obj.dimensions==Vector((0,0,0)) and self.poly_type!='STRIP':
                            self.report({'WARNING'},"Invalid Geometry")
                        bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.centroid,draw=self.operation=='Draw',fast_mode=self.fast_mode,internal_atv=self.align_to_view)
                        self.remove_drawHandler(context)
                        
                        return {'FINISHED'}
            
            return {'RUNNING_MODAL'}
        if event.type=='MOUSEMOVE' and self.grid_drawen and self.draw_type=='CIRCLE' and event.alt and not preferences().industry_keymap:
            #print("Hi")
            self.circle_segments=max(int(self.circle_segments_backup-(self.init_x-event.mouse_x)/(50 if event.shift else 10)),3)
            #print(self.circle_radius_save)
            if len(self.polycoords)>0 and self.circle_radius_save:
                line_to_draw_coords=find_circle_coords(self.polycoords[0],self.circle_radius_save,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                lines_to_draw_indices=[(i,(i+1)%(len(line_to_draw_coords))) for i in range(0,len(line_to_draw_coords))]
                self.batch_tris = batch_for_shader(self.shader, 'TRIS',{"pos": line_to_draw_coords},indices=[[0,i,i+1] for i in range(1,len(line_to_draw_coords)-1)])
                self.batch_poly = batch_for_shader(self.shader, 'LINES', {"pos": line_to_draw_coords},indices=lines_to_draw_indices)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='MOUSEMOVE' and self.grid_drawen :
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            #(result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            #while object!=self.backgroundPlane and object!=None:
            #        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),location+0.001*view_vector, view_vector)  
            #print(self.plane.location,self.plane_normal)
            location=raycast(ray_origin,view_vector,self.plane.location,self.plane_normal)
            if location is None:
                location=Vector((0,0,0))
            #print(object)
            if event.shift and len(self.polycoords)>0 :
                location=self.snap_to_angle(location,to_plane=self.snap_to_plane)
            if len(self.polycoords)>0 and event.alt and self.draw_type=='POLYGON':
                intersect=find_current_line_intersections(self.yellow_coords,self.yellow_indices,self.polycoords[-1],location,self.polycoords)
                location=intersect if intersect is not None else location
            self.location=location
            green_coords=[(v,(location-v).length) for v in self.coords if (location-v).length<0.2]
            green_coords+=[(v,(location-v).length) for v in self.faceverts if (location-v).length<0.2]
            green_coords+=[(v,(location-v).length) for v in self.bigverts if (location-v).length<0.2]
            #print(green_coords[len(green_coords)-1])
            if self.draw_type=='POLYGON':
                    green_coords+=[(Vector(v),(location-Vector(v)).length) for v in self.polycoords if (location-Vector(v)).length<0.2]
            self.last_hit_location=location
            coords=[v for v in self.coords if (location-v).length<self.point_distance_threshold]
            
            closest=[]
            if len(green_coords)>0:
                closest=[sorted(green_coords,key=lambda v:v[1])[0][0]]
                
            #print(closest)
            #closest+=[self.plane.matrix_world@v.co for v in self.plane.data.vertices]
            if event.ctrl:
                self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": closest})
                if len(closest)>0:
                    self.location=closest[0]
            else:
                self.batch_green=batch_for_shader(self.shader, 'POINTS', {"pos": []})
            if len(self.polycoords)>0:
                if self.draw_type=='BOX':
                    #line_to_draw_coords=findrectanglecoords(self.polycoords[0],closest[0] if event.ctrl else location,self.plane,center=event.alt)
                    line_to_draw_coords=findrectanglecoords(self.polycoords[0],self.location if preferences().show_snapped_shape else location,self.plane,center=event.alt if not preferences().industry_keymap else self.tab_down)
                elif self.draw_type=='CIRCLE':
                    #line_to_draw_coords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-(closest[0] if event.ctrl else location)).length,self.circle_segments,self.normal)
                    self.circle_radius_save=(self.polycoords[0]-(self.location if preferences().show_snapped_shape else location)).length
                    line_to_draw_coords=find_circle_coords(self.polycoords[0],(self.polycoords[0]-(self.location if preferences().show_snapped_shape else location)).length,self.circle_segments,self.plane_normal,z_rotation=self.rotated_by[2])
                    #line_to_draw_coords=self.polycoords
                else:
                    #line_to_draw_coords=self.polycoords + [closest[0] if event.ctrl else location,]
                    
                        #location=self.polycoords[-1]+(1 if angle<0 else -1)*(self.plane.matrix_world@self.plane.data.vertices[0].co-self.plane.matrix_world@self.plane.data.vertices[3].co).normalized()*(self.polycoords[-1]-Vector(location)).length
                    line_to_draw_coords=self.polycoords + [self.location if preferences().show_snapped_shape else location,]
                lines_to_draw_indices=[(i,(i+1)%(len(line_to_draw_coords))) for i in range(0,len(line_to_draw_coords)-1 if self.draw_type=='POLYGON' and self.poly_type=='STRIP' else len(line_to_draw_coords))]
                
                self.batch_tris = batch_for_shader(self.shader, 'TRIS',{"pos": line_to_draw_coords},indices=[[0,i,i+1] for i in range(1,len(line_to_draw_coords)-1)]if self.draw_type!='POLYGON' and self.poly_type=='MESH' else [])
                if self.draw_type=='POLYGON':
                    self.batch_tris = batch_for_shader(self.shader, 'TRIS',{"pos": line_to_draw_coords},indices=find_polygon_triangles(line_to_draw_coords) if self.poly_type=='MESH' else [])
                self.batch_poly = batch_for_shader(self.shader, 'LINES', {"pos": line_to_draw_coords},indices=lines_to_draw_indices)
            if event.ctrl:
                if self.line_type_grid:
                    self.batch_points=batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=self.indices)
                else:
                    self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": coords})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.faceverts})
                #self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": self.bigverts})
            
            if self.grid_hidden:    
                self.batch_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_object_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_big_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        #if event.type=='MOUSEMOVE' and self.grid_drawen and self.segment_adjustment and self.circle_radius_save:
        
        elif event.type=='E' :
            if event.value=='PRESS':
                
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                if event.shift:
                    self.align_to_edge=False
                    self.align_to_edge_normal=False
                    self.grid_to_edge=False
                    self.active_edge_index=None
                    self.active_vert_index=None
                    self.active_edge_indices=[]
                    self.activeKey='SHIFT+E'
                else:
                    if self.active_edge_index is None:
                        self.active_edge_index=0
                    if event.alt:
                        self.active_edge_index-=1
                    else:
                        self.active_edge_index+=1
                    
                    self.align_to_edge=True
                    self.align_to_view=False
                    self.activeKey='E'
                self.main(context)
                self.generate_grid()
                
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='Y':
            if event.value=='PRESS':
                self.align_to_edge_normal=not self.align_to_edge_normal
                if self.align_to_edge_normal:
                    self.grid_to_edge=True
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.activeKey='Y'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='O':
            if event.value=='PRESS':
                self.grid_to_edge=not self.grid_to_edge
                if self.active_edge_index is None:
                    self.active_edge_index=0
                if not self.grid_drawen:
                        self.X=event.mouse_region_x
                        self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.activeKey='O'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='M' :
            if event.value=='PRESS':
                self.snap_length = not self.snap_length
                self.activeKey='M'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='W':
            if event.value=='PRESS':
                bpy.context.space_data.overlay.show_wireframes = not bpy.context.space_data.overlay.show_wireframes
                self.activeKey='W'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='SPACE':
            if event.value=='PRESS':
                self.polycoords=[]
                self.generate_grid()
                self.batch_tris=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_poly=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.batch_yellow_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                self.activeKey='SPACE'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='Z' :
            if event.value=='PRESS':
                if len(self.polycoords)>0:
                    if self.draw_type=='POLYGON':
                        self.polycoords.pop()
                        
                    else:
                        self.polycoords=[]
                self.generate_grid()
                if len(self.polycoords)<1:
                    self.batch_tris=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                    self.batch_poly=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                    self.batch_yellow_points=batch_for_shader(self.shader, 'POINTS', {"pos": []})
                    self.activeKey='Z'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='U':
            if event.value=='PRESS':
                if not self.grid_drawen:
                    self.X=event.mouse_region_x
                    self.Y=event.mouse_region_y
                    self.main(context)
                self.generate_grid()
                rot=self.plane.rotation_euler.to_quaternion()
                context.space_data.region_3d.view_rotation=rot
                if preferences().use_ortho_view:
                    context.space_data.region_3d.view_perspective='ORTHO'
                    self.activeKey='U'
            else:
                self.activeKey=None
            
            return {'RUNNING_MODAL'}
        elif event.type=='I':
            if event.value=='PRESS':
                if event.alt:
                    if event.shift:
                        self.inset_amount=max(self.inset_amount-0.0005,0)
                    else:
                        self.inset_amount=max(self.inset_amount-0.005,0)
                else:
                    if event.shift:
                        self.inset_amount=max(self.inset_amount+0.0005,0)
                    else:
                        self.inset_amount=max(self.inset_amount+0.005,0)
                if not self.grid_drawen:
                    self.X=event.mouse_region_x
                    self.Y=event.mouse_region_y
                self.main(context)
                self.generate_grid()
                self.activeKey='I'
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS') or event.type=='ESC':
            if self.grid_drawen:
                delete_object_with_data(self.plane)
            if self.empty:
                delete_object(self.empty)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            if self.fast_mode:
                context.scene.rt_tools.keep_drawing=False
            self.remove_drawHandler(context)
            select(self.og_obj)
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
        
        #return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if event.ctrl:
                context.space_data.region_3d.view_perspective="ORTHO" if preferences().auto_ortho else context.space_data.region_3d.view_perspective
                context.scene.rt_tools.keep_drawing=True
        #context.space_data.region_3d.view_perspective="ORTHO" 
        self.tab_down=False
        self.fast_mode=event.ctrl or self.fast_mode
        self.circle_radius_save=0
        self.init_x=event.mouse_x
        self.circle_segments_backup=preferences().circle_resolution
        self.show_help=True
        self.bm=None
        self.last_obj=None
        self.scale_to_edge=False
        self.all_edge_middles=[]
        self.all_verts=[]
        self.initActiveObject=context.active_object if context.active_object and context.active_object.type=='MESH' else None
        self.mouse_current_x,self.mouse_current_y=event.mouse_region_x,event.mouse_region_y
        self.obj=None
        self.og_obj=context.active_object
        self.align_to_vert=False
        self.active_vert_index=None
        self.active_edge_indices=[]
        self.align_to_edge_normal=False
        context.window_manager.modal_handler_add(self)
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch_points=None
        self.batch_green=None
        self.coords=[]
        self.grid_drawen=False
        self.grid_hidden=True
        self.polycoords=[]
        self.polyIndices=[]
        self.grid_to_cursor=False
        self.batch_poly=None
        self.batch_middle_alignment_line=None
        self.rotation_axis='Z'
        self.rotation_z=0
        self.rotation_x=0
        self.rotation_y=0
        self.draw_type=context.scene.rt_tools.default_shape
        self.circle_segments=preferences().circle_resolution
        self.last_hit_location=0
        self.plane=None
        self.empty=None
        self.batch_object_points=None
        self.subsurf=None
        self.align_to_view=(event.ctrl or self.fast_mode) and preferences().align__to_view_fc and self.internal_atv
        
        self.subsurf_level=5
        self.batch_tris=None
        self.active_edge_index=None
        self.indices=[]
        self.aligned_to_verts=[]
        self.aligned_to_verts_middle=[]
        self.batch_alignment_line=None
        self.batch_big_points=None
        self.batch_yellow_points=None
        self.align_to_edge=False
        self.hide_cp_verts=False
        self.hide_inset_verts=not preferences().show_inset_points
        self.hide_point_lines=not preferences().show_red_lines
        self.snap_to_plane=False
        self.inset_amount=0.05
        self.plane_scale=Vector((1,1,1))
        self.poly_type=context.scene.rt_tools.current_shape
        self.operation=context.scene.rt_tools.pc_operation
        self.grid_to_edge=False
        self.last_snap_angle=0
        self.last_snap_direction=None
        self.auto_hide_grid=context.scene.rt_tools.auto_hide_grid
        self.location=None
        self.snap_length=False
        self.snap_angle=context.scene.rt_tools.snap_angle
        global grid_offset
        grid_offset=0.003 if self.operation=='Boolean' else 0
        self.point_distance_threshold=1 if preferences().show_close_points else 100
        self.line_type_grid=preferences().grid_type=='Lines'
        grid_color=preferences().grid_color
        self.activeKey=None
        self.show_help=context.scene.rt_tools.show_help
        if self.align_to_view:
            
            self.X=event.mouse_region_x
            self.Y=event.mouse_region_y
            #self.align_to_view=not self.align_to_view
            self.main(context)
            self.generate_grid(hide=True)
            
        #if (event.ctrl or self.fast_mode ) and preferences().align__to_view_fc:
            
        #    self.X=event.mouse_region_x
        #    self.Y=event.mouse_region_y
        #    self.main(context)
        #    self.generate_grid()
        def draw():
            if self.shader is not None:
                
                gpu.state.line_width_set(preferences().grid_line_width)
                gpu.state.point_size_set(preferences().grid_point_size)
                gpu.state.blend_set("ALPHA") 
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                self.shader.bind()
                
                
                self.shader.uniform_float("color", (0, 0.5, 1, 0.3))
                if self.batch_tris:
                    self.batch_tris.draw(self.shader)
                if self.batch_points:
                    self.shader.uniform_float("color", (grid_color[0],grid_color[1],grid_color[2], grid_color[3] if self.line_type_grid else grid_color[3]+0.2))
                    self.batch_points.draw(self.shader)
                if self.batch_object_points:
                    gpu.state.point_size_set(5)
                    self.shader.uniform_float("color", (1, 0, 0, 0.75))
                    self.batch_object_points.draw(self.shader)
                if self.batch_big_points:
                    gpu.state.line_width_set(preferences().grid_line_width+1)
                    gpu.state.point_size_set(5)
                    self.shader.uniform_float("color", (1, 0, 1, 0.5))
                    self.batch_big_points.draw(self.shader)
                if self.batch_green is not None:
                    gpu.state.point_size_set(7)
                    self.shader.uniform_float("color", (0, 0.3, 1, 0.7))
                    self.batch_green.draw(self.shader)
                if self.batch_yellow_points:
                    self.shader.uniform_float("color", (1, 0, 0, 0.8 if self.line_type_grid else 0.4))
                    self.batch_yellow_points.draw(self.shader)
                if self.batch_poly is not None:
                    gpu.state.line_width_set(preferences().shape_thickness)
                    if self.draw_type=='POLYGON':
                        
                        self.shader.uniform_float("color", (0,0.3 , 1, 0.6))
                    else:
                        self.shader.uniform_float("color", (0,0.3 , 1, 0.4))
                    self.batch_poly.draw(self.shader)
                gpu.state.line_width_set(preferences().grid_line_width+1)
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                if self.batch_alignment_line and self.align_to_edge:
                    self.shader.uniform_float("color", (1, 1, 1, 1))
                    self.batch_alignment_line.draw(self.shader)
                if self.batch_middle_alignment_line:
                    self.shader.uniform_float("color", (0.3, 1, 0.3, 1))
                    self.batch_middle_alignment_line.draw(self.shader)
                gpu.state.blend_set("NONE") 
                #bgl.glDisable(bgl.GL_LINE_SMOOTH)
        self.add_drawHandler(context)
        context.area.tag_redraw()
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        return {'RUNNING_MODAL'}