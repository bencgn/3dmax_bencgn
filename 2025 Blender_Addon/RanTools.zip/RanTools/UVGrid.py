import bpy
from . utils import *
import mathutils


class RTOOLS_OT_AddUVGrid(bpy.types.Operator):
    bl_idname = "rtools.adduvgrid"
    bl_label = "Add UV Grid"
    bl_description = "Add a UV Grid Texture to All Material"
    bl_options = {'REGISTER', 'UNDO'}
    callFrom: bpy.props.StringProperty(options={'HIDDEN'})
    scaleNodes = None

    def execute(self, context):

        if bpy.data.images.get("RT_CHECKER_TEX") is None:
            if os.path.isfile(preferences().custom_uv_texture):
                image = bpy.data.images.load(preferences().custom_uv_texture)
                image.name = "RT_CHECKER_TEX"
            else:
                bpy.ops.image.new(
                    name="RT_CHECKER_TEX",
                    width=2048,
                    height=2048,
                    color=(0.0, 0.0, 0.0, 1.0),
                    alpha=True,
                    generated_type='UV_GRID',
                    float=False,
                    use_stereo_3d=False,
                    tiled=False)
        selected = [ob for ob in bpy.context.selected_objects if ob.type in {
            'MESH', 'CURVE', 'SURFACE'}]
        for ob in selected:
            if len(ob.data.materials) == 0:
                mat = bpy.data.materials.new("Material")
                mat.use_nodes = True
                ob.data.materials.append(mat)
            for m in ob.data.materials:
                if m is not None and m.use_nodes:
                    nodes = m.node_tree.nodes

                    if {n.name for n in nodes}.issuperset({'RT_Checker_Output', 'RT_Checker_Coord', 'RT_Checker_Mapping', 'RT_Checker_Scale', 'RT_Checker_Texture'}):
                        output = nodes.get('RT_Checker_Output')
                        texCoordinates = nodes.get('RT_Checker_Coord')
                        texMapping = nodes.get('RT_Checker_Mapping')
                        self.texScale = nodes.get('RT_Checker_Scale')
                        self.scaleNodes.append(self.texScale)
                        checker = nodes.get('RT_Checker_Texture')
                        checker.image = bpy.data.images.get("RT_CHECKER_TEX")
                        self.initScale = self.texScale.outputs[0].default_value
                        output.mute = False
                        texCoordinates.mute = False
                        texMapping.mute = False
                        self.texScale.mute = False
                        checker.mute = False
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True
                    else:
                        output = nodes.new(type='ShaderNodeOutputMaterial')
                        output.name = "RT_Checker_Output"
                        texCoordinates = nodes.new(type='ShaderNodeTexCoord')
                        texCoordinates.name = "RT_Checker_Coord"
                        texMapping = nodes.new(type='ShaderNodeMapping')
                        texMapping.name = "RT_Checker_Mapping"
                        self.texScale = nodes.new(type='ShaderNodeValue')
                        self.texScale.name = "RT_Checker_Scale"
                        self.texScale.outputs[0].default_value = self.initScale
                        self.scaleNodes.append(self.texScale)
                        # checker=nodes.new(type='ShaderNodeTexChecker')
                        checker = nodes.new(type='ShaderNodeTexImage')
                        checker.image = bpy.data.images.get("RT_CHECKER_TEX")
                        checker.name = "RT_Checker_Texture"
                        # checker.inputs[3].default_value=50
                        output.location = 200, 600
                        texMapping.location = -400, 600
                        self.texScale.location = -600, 400
                        checker.location = -150, 600
                        texCoordinates.location = -600, 700
                        links = m.node_tree.links
                        links.new(
                            self.texScale.outputs[0], texMapping.inputs[3])
                        links.new(
                            texCoordinates.outputs[2], texMapping.inputs[0])
                        links.new(texMapping.outputs[0], checker.inputs[0])
                        links.new(checker.outputs[0], output.inputs[0])
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True
        if self.callFrom == 'Pie' or len(selected) == 0:
            self.callFrom = ""
            return {'FINISHED'}
        else:
            return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.mouse_x > context.region.x+context.region.width:
            self.initScale = self.texScale.outputs[0].default_value
            context.window.cursor_warp(context.region.x, event.mouse_y)

            self.initX = context.region.x
        if event.mouse_x < context.region.x:
            self.initScale = self.texScale.outputs[0].default_value
            context.window.cursor_warp(context.region.x+context.region.width, event.mouse_y)
            self.initX = context.region.x+context.region.width
        if event.type == 'LEFT_SHIFT':
            self.initX = event.mouse_x
            if event.value == 'PRESS':
                self.speed = 20
            elif event.value == 'RELEASE':
                self.speed = 5
            self.initScale = self.texScale.outputs[0].default_value
        if event.type == 'LEFT_CTRL':
            self.initX = event.mouse_x
            if event.value == 'PRESS':
                self.speed = 2
            elif event.value == 'RELEASE':
                self.speed = 5
            self.initScale = self.texScale.outputs[0].default_value
        if event.type == 'MOUSEMOVE':
            for texScale in self.scaleNodes:
                if texScale is not None:
                    texScale.outputs[0].default_value = max(
                        round(self.initScale-(self.initX-event.mouse_x)/(100*self.speed), 5), 0)
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            return {'FINISHED'}
        return{'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.initScale = 2
        self.initX = event.mouse_x
        self.speed = 5
        self.texScale = None
        self.scaleNodes = []
        if self.callFrom != 'Pie':
            context.window_manager.modal_handler_add(self)
        return self.execute(context)


class RTOOLS_OT_RemoveUVGrid(bpy.types.Operator):
    bl_idname = "rtools.removeuvgrid"
    bl_label = "Remove UV Grid"
    bl_description = "Remove UV Grid Texture if present"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = [ob for ob in bpy.context.selected_objects if ob.type in {
            'MESH', 'CURVE', 'SURFACE'}]
        for ob in selected:
            for m in ob.data.materials:
                nodes = m.node_tree.nodes

                for node in nodes:
                    if any(RT_nodes in node.name for RT_nodes in {'RT_Checker_Output', 'RT_Checker_Coord', 'RT_Checker_Texture', 'RT_Checker_Mapping', 'RT_Checker_Scale'}):
                        if node.name == "RT_Checker_Texture":
                            node.image = None
                        node.mute = True
                for node in nodes:
                    if node.type == 'OUTPUT_MATERIAL' and not node.mute:
                        node.is_active_output = True
        return {'FINISHED'}


def haveTransparency(nodes):
    for n in nodes:
        if n.inputs[(17 if (
                3, 0, 0) <= bpy.app.version else 15)].default_value > 0 or n.inputs[(21 if (
                3, 0, 0) <= bpy.app.version else 19)].default_value < 1:
            return True
    return False


def add_clay_material(objects, add_to_translucent=True, render_mode=True):
    if bpy.data.node_groups.get('RT_ClayGroup') is None:
        claygroup = bpy.data.node_groups.new('RT_ClayGroup', 'ShaderNodeTree')
        nodeoutput = claygroup.nodes.new(type='NodeGroupOutput')
        diffuse = claygroup.nodes.new(type='ShaderNodeBsdfDiffuse')
        diffuse.name = "RT_Diffuse"
        """for i in range(0,3):
            driver=self.diffuse.inputs[0].driver_add("default_value",i)
            var = driver.driver.variables.new()
            var.name = "Color"
            var.targets[0].data_path = f"rt_tools.hexwidget[{i}]"
            var.targets[0].id_type='SCENE'
            var.targets[0].id = context.scene
            driver.driver.expression = "Color"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]"""
        claygroup.outputs.new('NodeSocketShader', 'out_result')
        claygroup.links.new(diffuse.outputs[0], nodeoutput.inputs[0])
        nodeoutput.name = "RT_Clay_Group_Output"
    else:
        claygroup = bpy.data.node_groups.get('RT_ClayGroup')
        diffuse = claygroup.nodes['RT_Diffuse']
    if bpy.data.node_groups.get('RT_TransparentGroup') is None:
        transparentgroup = bpy.data.node_groups.new(
            'RT_TransparentGroup', 'ShaderNodeTree')
        nodeoutput = transparentgroup.nodes.new(type='NodeGroupOutput')
        transparent = transparentgroup.nodes.new(
            type='ShaderNodeBsdfPrincipled')
        transparent.name = "RT_Transparent"

        transparentgroup.outputs.new('NodeSocketShader', 'out_result')
        transparentgroup.links.new(
            transparent.outputs[0], nodeoutput.inputs[0])
        nodeoutput.name = "RT_Transparent_Group_Output"
    else:
        transparentgroup = bpy.data.node_groups.get('RT_TransparentGroup')
        transparent = transparentgroup.nodes['RT_Transparent']
    Initcolor = mathutils.Color(diffuse.inputs[0].default_value[:-1])
    Initcolor.v = 1
    for ob in objects:
        if len(ob.data.materials) == 0:
            mat = bpy.data.materials.new("Material")
            mat.use_nodes = True
            ob.data.materials.append(mat)
        for m in ob.data.materials:
            # print(m)
            if m is not None and m.use_nodes:
                nodes = m.node_tree.nodes
                nodeTypes = set([n.type for n in nodes])
                principledNodes = [
                    n for n in nodes if n.type == 'BSDF_PRINCIPLED']
                nodesToCheck = {"BSDF_TRANSLUCENT",
                                "BSDF_TRANSPARENT", "BSDF_GLASS"}
                if (any([(n in nodeTypes) for n in nodesToCheck]) or haveTransparency(principledNodes)) and not add_to_translucent:
                    m.backup_blend_mode = m.blend_method
                    m.blend_method = 'CLIP'
                    m.shadow_method = 'CLIP'
                    transparent.inputs[(21 if (
                        3, 0, 0) <= bpy.app.version else 19)].default_value = 0
                    if {n.name for n in nodes}.issuperset({'RT_Transparent_Group_Output', 'RT_TransparentNodeGroup'}):
                        output = nodes.get('RT_Transparent_Group_Output')
                        output.mute = False
                        transGroup = nodes.get('RT_TransparentNodeGroup')
                        transGroup.mute = False
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True
                    else:
                        output = nodes.new(type='ShaderNodeOutputMaterial')
                        output.name = "RT_Transparent_Group_Output"
                        output.location = 200, 900
                        TransparentGroupNode = nodes.new('ShaderNodeGroup')
                        TransparentGroupNode.location = 0, 900
                        TransparentGroupNode.name = "RT_TransparentNodeGroup"
                        TransparentGroupNode.node_tree = bpy.data.node_groups.get(
                            'RT_TransparentGroup')
                        links = m.node_tree.links
                        links.new(
                            TransparentGroupNode.outputs[0], output.inputs[0])
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True
                else:
                    m.backup_blend_mode = m.blend_method
                    m.blend_method = 'OPAQUE'
                    if {n.name for n in nodes}.issuperset({'RT_Clay_Output', 'RT_ClayNodeGroup'}):
                        output = nodes.get('RT_Clay_Output')
                        output.mute = False
                        clayGroup = nodes.get('RT_ClayNodeGroup')
                        clayGroup.mute = False
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True
                    else:
                        output = nodes.new(type='ShaderNodeOutputMaterial')
                        output.name = "RT_Clay_Output"
                        output.location = 200, 900
                        ClayGroupNode = nodes.new('ShaderNodeGroup')
                        ClayGroupNode.location = 0, 900
                        ClayGroupNode.name = "RT_ClayNodeGroup"
                        ClayGroupNode.node_tree = bpy.data.node_groups.get(
                            'RT_ClayGroup')
                        links = m.node_tree.links
                        links.new(ClayGroupNode.outputs[0], output.inputs[0])
                        for node in nodes:
                            if node.type == 'OUTPUT_MATERIAL':
                                node.is_active_output = False
                        output.is_active_output = True


class RTOOLS_OT_ClayMaterial(bpy.types.Operator):
    bl_idname = "rtools.addclaymaterial"
    bl_label = "Add Clay Material"
    bl_description = "Add a Clay Material to All Material\nCTRL+LMB:Also Add Clay Materials To Transmissive Materials"
    bl_options = {'REGISTER', 'UNDO'}
    callFrom: bpy.props.StringProperty(default="NA", options={'HIDDEN'})
    add_to_translucent: bpy.props.BoolProperty(
        default=False, name="Also Add To Translucent Materials")
    # def add_drawHandler(self,context):
    #    self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    # def remove_drawHandler(self,context):
    #    bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
    #    context.area.tag_redraw()
    # def draw_callback_px(self,context):
    #    draw_Text(context,0,30,text=["X-axis : Hue","Y-axis : Saturation",f"Hue: {round(self.color.h,2)}",f"Saturation: {round(self.color.s,2)}"],alignH="LEFT")

    def execute(self, context):
        selected = [ob for ob in context.selected_objects if ob.type in {
            'MESH', 'CURVE', 'SURFACE', 'FONT'}]
        add_clay_material(selected, self.add_to_translucent)

        rgb = context.scene.rt_tools.hexwidget
        # self.diffuse.inputs[0].default_value=(rgb[0],rgb[1],rgb[2],1)

        return {'FINISHED'}

    def invoke(self, context, event):
        if event.ctrl:
            self.add_to_translucent = True
        else:
            self.add_to_translucent = False
        return self.execute(context)


def remove_clay_material(objects, render_mode=False):
    for ob in objects:
        for m in ob.data.materials:
            if m is not None and m.use_nodes:
                m.blend_method = m.backup_blend_mode if m.backup_blend_mode != 'NA' else m.blend_method
                nodes = m.node_tree.nodes

                for node in nodes:
                    if any(RT_nodes in node.name for RT_nodes in {'RT_ClayNodeGroup', 'RT_Clay_Output', 'RT_Transparent_Group_Output', 'RT_TransparentNodeGroup'}):
                        node.mute = True
                for node in nodes:
                    if node.type == 'OUTPUT_MATERIAL' and node.mute == False:
                        node.is_active_output = True


class RTOOLS_OT_RemoveClayMaterial(bpy.types.Operator):
    bl_idname = "rtools.removeclaymaterial"
    bl_label = "Remove Clay Material"
    bl_description = "Remove Clay Material if present"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = [ob for ob in context.selected_objects if ob.type in {
            'MESH', 'CURVE', 'SURFACE', 'FONT'}]
        remove_clay_material(selected)
        return {'FINISHED'}
