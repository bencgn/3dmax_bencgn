import os
from . utils import *
import bpy
from bpy.types import (PropertyGroup)
import sys
from bpy.utils import register_class, unregister_class
from .ExtendedPanel import *
import rna_keymap_ui
from subprocess import run
from bpy_extras.io_utils import ImportHelper
import zipfile
from .t3dn_bip.utils import support_pillow
from .addon_update_checker import AddonUpdateChecker,draw_update_section_for_prefs
kmaps_3dview = ['rtools.addlights',
                'rtools.addbackdrop',
                'rtools.callrtmain',
                'rtools.quick_mirror',
                'rtools.callpie',
                'rtools.call_append_panel',
                'rtools.create_asset',
                'rtools.import_asset',
                'rtools.makeemissive', 'rtools.invoke_modifier_menu', 'rtools.ratioswitch', 'rtools.call_material_menu', 'rtools.backup_panel', 'rtools.bake_panel', 'rtools.materialadjustpanel', 'rtools.callcurvespie', 'rtools.callbooleanspie', 'rtools.cleanbooleans', 'rtools.recalllastcutter', 'rtools.cutterspanel', 'rtools.invoke_modifier_favorites_menu', 'rtools.import_material','rtools.import_hdri', 'rtools.selectchildren', 'rtools.projectsettings', 'rtools.saveproject']

kmaps_node_editor = ["rtools.callnodemixmenu", ]
kmaps_object_mode = ["rtools.callcategoriespie", ]
kmaps_mesh = ["rtools.calledgespie", ]

import os
import os.path
import ssl
import stat
import subprocess
import sys
import certifi

def get_panel_categories(self, context):
    cat=set()
    base_type = bpy.types.Panel
    for typename in dir(bpy.types):
        bl_type = getattr(bpy.types, typename)
        try:
            if issubclass(bl_type, base_type):
        # print(bl_type)
                if getattr(bl_type,'bl_space_type',"None")=='VIEW_3D':
                    cat.add(getattr(bl_type,'bl_category',"None"))
        except:
            pass
    return [(a,a,a) for a in cat]
addons_to_exclude=['io_anim_bvh', 'io_curve_svg', 'io_mesh_ply', 'io_mesh_uv_layout', 'io_mesh_stl', 'io_scene_fbx', 'io_scene_gltf2', 'io_scene_obj', 'io_scene_x3d', 'cycles', 'pose_library','node_wrangler', 'node_arrange', 'node_presets','mesh_looptools', 'development_iskeyfree','development_icon_get','add_curve_extra_objects', 'add_mesh_extra_objects','space_view3d_spacebar_menu', 'brush_quickset', 'development_edit_operator', 'space_view3d_modifier_tools']



def get_installed_addons(self, context):
    addons=[]
    for a in bpy.context.preferences.addons.keys():

        try:
            if sys.modules[a].__name__ not in addons_to_exclude:
                addons.append(a)
        except:
            pass
    return [(a,a,a) for a in addons]
def draw_hotkeys(col, km_name):
    kc = bpy.context.window_manager.keyconfigs.user
    if km_name == "3D View":
        kmaps = kmaps_3dview
    elif km_name == "Node Editor":
        kmaps = kmaps_node_editor
    elif km_name == "Mesh":
        kmaps = kmaps_mesh
    else:
        kmaps = kmaps_object_mode
    for kmi in kmaps:
        km2 = kc.keymaps[km_name]
        kmi2 = [km2.keymap_items[a]
                for a in km2.keymap_items.keys() if a == kmi]
        if kmi2:
            for k in kmi2:
                col.context_pointer_set("keymap", km2)
                rna_keymap_ui.draw_kmi([], kc, km2, k, col, 0)


class RTOOLS_OT_Save_Preferences(bpy.types.Operator):
    bl_idname = "rtools.saveprefs"
    bl_label = "Save Preferences"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        savePreferences()
        return {'FINISHED'}


class RTOOLS_OT_Load_Preferences(bpy.types.Operator):
    bl_idname = "rtools.loadprefs"
    bl_label = "Load Preferences"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        loadPreferences()
        return {'FINISHED'}


class RTOOLS_Asset_Folders(PropertyGroup):
    icon: bpy.props.StringProperty(default='FILE_FOLDER')
    location: bpy.props.StringProperty(
        name='Path',
        description='Path of Asset Folder',
        subtype='DIR_PATH',
        default='Choose Path')
class RT_Panel(PropertyGroup):
    name: bpy.props.StringProperty()
class Panel_Category(PropertyGroup):
    panels: bpy.props.StringProperty(default="",name="Panels")
    #panels: bpy.props.CollectionProperty(type=RT_Panel)
    name: bpy.props.StringProperty(default="Category",name="Name")

prefs_to_save = {'asset_folders': 'list', 'bake_margin': 'int', 'enable_curve_tools': 'bool', 'enable_camera_tools': 'bool', 'enable_material_tools': 'bool', 'enable_bake_tools': 'bool',
                 'enable_random_tools': 'bool',
                 'enable_backup': 'bool',
                 'enable_light_tools': 'bool',
                 'override_save': 'bool',
                 'projects_path': 'str',
                 'delete_zips': 'bool',
                 'mod_presets_favorites': 'str',
                 'grid_line_width': 'int',
                 'grid_point_size': 'int',
                 'show_inset_points': 'bool',
                 'show_red_lines': 'bool',
                 'bevel_threshold': 'float',
                 'grid_size': 'str',
                 'extract_from_only_solid_objects': 'bool',
                 'use_floating_text': 'bool',
                 'use_only_active_object': 'bool',
                 'auto_hide_bools_after_drawing': 'bool',
                 'use_ortho_view': 'bool',
                 'circle_resolution': 'int',
                 'crossSnapThreshold': 'float',
                 'apply_mods': 'bool',
                 'apply_bools_slice_mod': 'bool',
                 'grid_color': 'list',
                 'grid_type': 'str',
                 'materials_folder': 'str',
                 'hdris_folder': 'str',
                 'use_unique': 'bool',
                 'auto_abs': 'bool',
                 'onlyDiffuse': 'bool',
                 'useEevee': 'bool',
                 'useBump': 'bool',
                 'useBoxEmpty': 'bool',
                 'sockets': 'str',
                 'nodes': 'str',
                 'auto_hide_bools': 'bool',
                 'imperfection_maps': 'str',
                 'custom_uv_texture': 'str',
                 'font_size': 'int',
                 'shape_thickness': 'int',
                 'use_favorites_pie': 'bool',
                 'sort_mirror_mod': 'bool',
                 # 'adjust_segments_after_draw':'bool',
                 'remember_last_shape': 'bool', 'show_snapped_shape': 'bool', 'auto_ortho': 'bool', 'align__to_view_fc': 'bool',
                 'wait_time_multiplier': 'float', 'skip_adjustment_phase': 'bool',
                 'text_color1': 'list',
                 'text_color2': 'list',
                 'text_color3': 'list',
                 'text_color4': 'list',
                 'bg_color': 'list',
                 'bg_border_color': 'list',
                 'border_thickness':'int',
                 'border_radius':'int',
                 'loc_x':'int',
                 'loc_y':'int',
                 'loc_x_from_right':'int',
                 'loc_y_from_top':'int',
                 'material_asset_library_folder':'str',
                 'flip_sides':'bool',
                 'floating_text_location':'str',
                 'use_master_pie':'bool',
                 'site_to_check_connection':'str',
                 'bake_samples':'int',
                 'industry_keymap':'bool',
                 'draw_into_modifier_panel':'bool',
                 'freezed_verts_for_simulations':'int',
                 'use_up_down_keys':'bool',
                 'material_preset':'str'
                 #'panel_categories':'pc',
                 #'pop_out_style':'str',
                 #'dropdown_categories':'pc',
                 #'workspace_categories':'pc'

}

def savePreferences():
    if not os.path.isdir(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config")):
        os.mkdir(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))))), "config"))
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config", "RanTools-config.txt"), mode='w+', newline='\n', encoding='utf-8') as file:
        for p, t in prefs_to_save.items():
            if p == 'grid_color':
                file.write(f"{p}=>{t}==={getattr(preferences(),p)[:]}\n")
            elif p == 'asset_folders':
                file.write(
                    f"{p}=>{t}==={','.join([a.location for a in getattr(preferences(),p)])}\n")
            # elif p == 'panel_categories':
            #     for s in preferences().panel_categories:
            #         file.write(
            #             f"{p}=>{t}==={s.name}>>{s.panels}\n")
            # elif p == 'dropdown_categories':
            #     for s in preferences().dropdown_categories:
            #         file.write(
            #             f"{p}=>{t}==={s.name}>>{s.panels}\n")
            # elif p == 'workspace_categories':
            #     for s in preferences().workspace_categories:
            #         file.write(
            #             f"{p}=>{t}==={s.name}>>{s.panels}\n")
            else:
                file.write(f"{p}=>{t}==={getattr(preferences(),p)}\n")


def loadPreferences():
    if not os.path.isdir(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config")):
        os.mkdir(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))))), "config"))
    if os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config", "RanTools-config.txt")):
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "config", "RanTools-config.txt"), mode='r', newline='\n', encoding='utf-8') as file:
            prefs = file.readlines()
            # preferences().panel_categories.clear()
            # preferences().dropdown_categories.clear()
            # preferences().workspace_categories.clear()
            for p in prefs:
                try:
                    attr = p[:p.index("=>")]
                    type = p[p.index("=>")+2:p.index("===")]
                    value = p[p.index("===")+3:]
                    value = value.replace("\n", "")
                    if type == "str":
                        setattr(preferences(), attr, value)
                    elif attr == 'asset_folders' and type == 'list':
                        preferences().asset_folders.clear()
                        # value=value.replace("[","").replace("]","")
                        if value.replace(" ", ""):
                            folders = value.split(",")
                            for f in folders:
                                folder = preferences().asset_folders.add()
                                folder.location = f
                    else:

                        setattr(preferences(), attr, eval(f"{type}({value})"))
                except:
                    pass


def grid_type_update(self, context):
    if self.grid_type == 'Lines':
        self.show_close_points = False


def Favorites_Update(self, context):
    if not os.path.isfile(
        os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(
                __file__))), "RanTools-Indexes", "ModPresetsFavorites.txt"
        )
    ):
        f = open(
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "RanTools-Indexes", "ModPresetsFavorites.txt",
            ),
            mode="w+",
        )
        f.close()
    with open(
        os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(
                __file__))), "RanTools-Indexes", "ModPresetsFavorites.txt"
        ),
        mode="w",
    ) as fav_file:
        favs = fav_file.write(self.mod_presets_favorites)
        fav_file.close()


def curve_tools_update(self, context):
    if self.enable_curve_tools:
        try:
            register_class(RTOOLS_Curve_Tools)
            print("Enabled Curve Tools")
        except:
            pass
    else:
        try:

            unregister_class(RTOOLS_Curve_Tools)
            print("Disabled Curve Tools")
        except:
            pass


def random_tools_update(self, context):
    if self.enable_random_tools:
        try:
            register_class(RTOOLS_OT_RTools)
            print("Enabled Random Tools")

        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_OT_RTools)
            print("Disabled Random Tools")
        except:
            pass


def backup_tools_update(self, context):
    if self.enable_backup:
        try:
            register_class(RTOOLS_PT_BackUps)
            print("Enabled Backup Manager")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_PT_BackUps)
            print("Disabled Backup Tools")
        except:
            pass


def camera_tools_update(self, context):
    if self.enable_camera_tools:
        try:
            register_class(RTOOLS_PT_Camera)
            print("Enabled Camera Tools")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_PT_Camera)
            print("Disabled Camera Tools")
        except:
            pass


def material_tools_update(self, context):
    if self.enable_material_tools:
        try:
            register_class(RTOOLS_Material)
            print("Enabled Material Tools")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_Material)
            print("Disabled Material Tools")
        except:
            pass


def bake_tools_update(self, context):
    if self.enable_bake_tools:
        try:
            register_class(RTOOLS_OT_Bake)
            print("Enabled Bake Tools")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_OT_Bake)
            print("Disabled Bake Tools")
        except:
            pass


def light_tools_update(self, context):
    if self.enable_light_tools:
        try:
            register_class(RTOOLS_OT_Light)
            print("Enabled Light Tools")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_OT_Light)
            print("Disabled Light Tools")
        except:
            pass


def asset_tools_update(self, context):
    if self.enable_asset_tools:
        try:
            register_class(RTOOLS_OT_Asset_Tools)
            print("Enabled Asset Tools")
        except:
            pass
    else:
        try:
            unregister_class(RTOOLS_OT_Asset_Tools)
            print("Disabled Asset Tools")
        except:
            pass

class RTOOLSPrefs(bpy.types.AddonPreferences,AddonUpdateChecker):
    bl_idname = __package__
    enable_curve_tools: bpy.props.BoolProperty(
        default=True, name="Curve Tools", update=curve_tools_update)
    enable_camera_tools: bpy.props.BoolProperty(
        default=True, name="Camera Tools", update=camera_tools_update)
    enable_backup: bpy.props.BoolProperty(
        default=True, name="Backup Manager", update=backup_tools_update)
    enable_random_tools: bpy.props.BoolProperty(
        default=True, name="Random Tools", update=random_tools_update)
    enable_material_tools: bpy.props.BoolProperty(
        default=True, name="Material Tools", update=material_tools_update)
    enable_bake_tools: bpy.props.BoolProperty(
        default=True, name="Bake Tools", update=bake_tools_update)
    enable_light_tools: bpy.props.BoolProperty(
        default=True, name="Light Tools", update=light_tools_update)
    #enable_asset_tools: bpy.props.BoolProperty(
     #   default=True, name="Asset Tools", update=asset_tools_update)
    bake_margin: bpy.props.IntProperty(
        default=8, name="Margin for Baking", subtype='PIXEL')
    override_save: bpy.props.BoolProperty(
        default=True, name="Override CTRL+S to open RanTools Project Panel")
    projects_path: bpy.props.StringProperty(
        name='Projects Directory',
        subtype='DIR_PATH',
        default='Choose Path')
    delete_zips: bpy.props.BoolProperty(
        default=False, name="Delete Zip files after setting up materials", description="Delete Zip files after setting up materials")
    mod_presets_favorites: bpy.props.StringProperty(
        default="", name="Favorite Presets", update=Favorites_Update)
    grid_line_width: bpy.props.IntProperty(
        default=1, name="Grid Line Thickness")
    grid_point_size: bpy.props.IntProperty(default=2, name="Grid Point Size")
    show_inset_points: bpy.props.BoolProperty(
        default=True, name="Show Inset Points")
    show_red_lines: bpy.props.BoolProperty(default=True, name="Show Red Lines")
    bevel_threshold: bpy.props.FloatProperty(
        default=0.1, name="Bevel Threshold", description="Bevel modifiers with width below this will be removed from calculations in P-Cutter(Aligning to Edges and Extract Faces)")
    grid_size: bpy.props.EnumProperty(items=(('Dimensions', 'Dimensions', 'Dimensions'), (
        'Face Size', 'Face Size', 'Face Size')), default='Face Size', name="Grid Size Based On")
    draw_solidify_offset: bpy.props.FloatProperty(
        default=1, name="Draw mode solidify offset", min=-1, max=1, step=100)
    boolean_solidify_offset: bpy.props.FloatProperty(
        default=-1, name="Boolean mode solidify offset", min=-1, max=1, step=100)
    extract_from_only_solid_objects: bpy.props.BoolProperty(
        default=True, name="Extract faces from solid objects only")
    use_floating_text: bpy.props.BoolProperty(
        default=True, name="Use Floating Text")
    use_only_active_object: bpy.props.BoolProperty(
        default=False, name="Use Active Object Only", description="Use only the active object with P-Cutter")
    auto_hide_bools_after_drawing: bpy.props.BoolProperty(
        default=True, name="Auto Hide Booleans after drawing")
    use_ortho_view: bpy.props.BoolProperty(
        default=True, name="Use orthographic view when aligning view to Grid", description="Use Orthographic view when aligning view to Grid")
    circle_resolution: bpy.props.IntProperty(
        default=32, name="Circle Resolution")
    crossSnapThreshold: bpy.props.FloatProperty(
        default=0.15, name="Intersection Snap Threshold")
    show_snapped_shape: bpy.props.BoolProperty(default=False, name="Show the final (snapped) shape while using Snapping",
                                               description="Snap the drawing to the points instead of just highlighting the snapping point")
    apply_mods: bpy.props.BoolProperty(
        default=False, name="Make meshes destructive after drawing")
    apply_bools_slice_mod: bpy.props.BoolProperty(
        default=False, name="Apply Modifiers When Using Slice Boolean")
    grid_color: bpy.props.FloatVectorProperty(name="Grid Color", size=4,
                                              subtype='COLOR', soft_max=1, soft_min=0,
                                              default=[0.9, 0.9, 0.9, 0.5])
    sort_mirror_mod: bpy.props.BoolProperty(default=True,name="Include Mirror modifier when sorting the modifier stack",description="Toggling this OFF will let you draw cutters on the mirrored side of the object(by moving the cutter below the mirror modifier)")
    shape_thickness: bpy.props.IntProperty(
        default=2, name="Shape Edges Thickness")
    grid_type: bpy.props.EnumProperty(name="Grid Type", items={(
        'Points', 'Points', 'Points'), ('Lines', 'Lines', 'Lines')}, default='Points', update=grid_type_update)
    show_close_points: bpy.props.BoolProperty(
        default=False, name="Show Close Grid Points Only")
    #adjust_segments_after_draw:bpy.props.BoolProperty(default=False,name="Adjust Circle Segments after drawing")
    auto_ortho: bpy.props.BoolProperty(
        default=True, name="Automatically Switch view to Orthographic view when using Fast Cutter Mode")
    remember_last_shape: bpy.props.BoolProperty(
        default=True, name="Remember the last shape used for drawing")
    align__to_view_fc: bpy.props.BoolProperty(
        default=True, name="Automatically align the grid to view when using Fast Cutter Mode")
    asset_folders: bpy.props.CollectionProperty(type=RTOOLS_Asset_Folders)
    materials_folder: bpy.props.StringProperty(name="Materials Folder", default=os.path.join(os.path.dirname(
        os.path.dirname(__file__)), 'Materials'), subtype='DIR_PATH', description='Directory where materials will be downloaded')
    hdris_folder: bpy.props.StringProperty(name="HDRIs Folder", default=os.path.join(os.path.dirname(
        os.path.dirname(__file__)), 'HDRIs'), subtype='DIR_PATH', description='Directory where HDRIs will be downloaded')
    use_unique: bpy.props.BoolProperty(
        name='Use Unique', description="Whether to Show Unique Objects by Name", default=True)
    auto_abs: bpy.props.BoolProperty(
        name='Auto ABS', description="Whether to Enable AO, Bloom and ScreenSpace Reflection With Camera Settings", default=True)
    onlyDiffuse: bpy.props.BoolProperty(name='SetUp Material Having Only Diffuse Texture',
                                        description="SetUp Material Having Only Diffuse Texture", default=False)
    # autoIndex: bpy.props.BoolProperty(
    #    name='Auto Update Indexes', description="Auto Update Indexes Whenever new Folder is Added", default=False)
    useEevee: bpy.props.BoolProperty(
        name='Use Eevee for thumbnails', description="Use Eevee For Asset Thumbnails", default=False)
    useBump: bpy.props.BoolProperty(
        name='Use Bump', description="Use Bump node when Setting Up PBR Materials", default=True)
    useBoxEmpty: bpy.props.BoolProperty(
        name='Use Box Empty', description="Use Box Empty Instead Of Plain-Axis While Creating Assets", default=False)
    sockets: bpy.props.StringProperty(default="Density,Roughness,Base Color,Color,Metallic,Transmission,IOR,Strength,Color1,Color2,Value",
                                      name='Sockets', description="Sockets To Show In Quick Material Adjust")
    nodes: bpy.props.StringProperty(default="DISPLACEMENT,BUMP,RGB,BSDF_PRINCIPLED,BSDF_DIFFUSE,BSDF_GLASS,EMISSION,BSDF_TRANSLUCENT,BSDF_TRANSPARENT,BSDF_REFRACTION,BSDF_GLOSSY,VOLUME_ABSORPTION,VOLUME_SCATTER,PRINCIPLED_VOLUME,GROUP,VALUE",
                                    description="Nodes To Show In Quick Material Adjust", name="Nodes")
    auto_hide_bools: bpy.props.BoolProperty(
        default=True, name="Automatically Hide Boolean Objects When Using Modifiers From Modifier Preset Menu")
    imperfection_maps: bpy.props.StringProperty(
        default="Choose Path", subtype='DIR_PATH', name='Imperfection Maps')
    textures_folder_name: bpy.props.StringProperty(
        name='Textures Folder',
        default='Textures')
    renders_folder_name: bpy.props.StringProperty(
        name='Renders Folder',
        default='Renders')
    use_favorites_pie: bpy.props.BoolProperty(
        default=True, name="Use Pie Menu for Favorite Modifier Presets")
    custom_uv_texture: bpy.props.StringProperty(
        default="Choose Path", name="Custom Checker Texture", subtype='FILE_PATH')
    show_p_cutter_settings: bpy.props.BoolProperty(
        default=False, name="P-Cutter")
    show_misc_settings: bpy.props.BoolProperty(
        default=False, name="Miscellaneous")
    show_material_settings: bpy.props.BoolProperty(
        default=False, name="Materials And HDRIs")
    show_presets_settings: bpy.props.BoolProperty(
        default=False, name="Modifier Presets")
    show_ui_settings: bpy.props.BoolProperty(default=False,name="On-Screen UI")
    show_panels: bpy.props.BoolProperty(default=False, name="Manage Panels")
    show_shortcuts: bpy.props.BoolProperty(default=False, name="Key Maps")
    show_asset_folders: bpy.props.BoolProperty(
        default=False, name="Asset Folders")
    update_status: bpy.props.StringProperty(default='RanTools is Up To Date!')
    font_size: bpy.props.IntProperty(default=15, name="Font Size")
    wait_time_multiplier: bpy.props.FloatProperty(
        default=1, name="Wait time multiplier for Thumbnail generation")
    hdri_preview_resolution: bpy.props.IntProperty(
        default=300, name="HDRI Preview Resolution", step=100, min=200, max=1200)
    skip_adjustment_phase: bpy.props.BoolProperty(
        default=True, name="Skip Cutting Phase of P-Cutter when using Fast Mode")
    #Overlay
    text_color1:bpy.props.FloatVectorProperty(name="Text Color (Left)", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[0.24, 0.8, 1, 1])
    text_color2:bpy.props.FloatVectorProperty(name="Text Color (Right)", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[1.0,1.0,1.0,1.0])
    text_color3:bpy.props.FloatVectorProperty(name="Sub-Text Color", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[152/255, 250/255,140/255, 1])
    text_color4:bpy.props.FloatVectorProperty(name="Key Highlight Color", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[1, 0.3,0, 1])
    bg_color:bpy.props.FloatVectorProperty(name="Background", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[0,0,0,0.8])
    bg_border_color:bpy.props.FloatVectorProperty(name="Border Color", size=4,
                                        subtype='COLOR',soft_max=1,soft_min=0,
                                        default=[0.2,0.2,0.2,1])
    border_radius:bpy.props.IntProperty(default=5,name="Corner Radius",min=0,max=40)
    border_thickness:bpy.props.IntProperty(default=2,name="Border Thickness",min=0,max=10)
    loc_x:bpy.props.IntProperty(default=100,name="Location X",min=0)
    loc_y:bpy.props.IntProperty(default=50,name="Location Y",min=0)
    loc_y_from_top:bpy.props.IntProperty(default=50,name="Location Y (From Top)",min=0)
    loc_x_from_right:bpy.props.IntProperty(default=0,name="Location X (From Right)",min=0)
    material_asset_library_folder:bpy.props.StringProperty(default=os.path.join(os.path.dirname(
        os.path.dirname(__file__)), 'Materials-Assets'),name="Asset Library Path",subtype='DIR_PATH')
    flip_sides: bpy.props.BoolProperty(default=False,name="Flip On-Screen UI (Left-Right)")
    floating_text_location:bpy.props.EnumProperty(items=(("ABOVE",'Above','Above'),("BELOW",'Below','Below')),name="Floating Text Location")
    #cursor_overflow:bpy.props.BoolProperty(default=True, name="Cursor Overflow",description="Whether to move the cursor to the left end when it reaches too close to the right end")
    use_master_pie: bpy.props.BoolProperty(default=True,name="Use Master Pie Menu")
    site_to_check_connection:bpy.props.StringProperty(default="www.google.com",name="Internet Connection Check Site")
    bake_samples: bpy.props.IntProperty(default=2,name="Bake Samples",description="Bake Samples (For bakes other than AO and Bevels)")
    industry_keymap:bpy.props.BoolProperty(default=False,name="Use Industry Compatible Keymap")
    draw_into_modifier_panel:bpy.props.BoolProperty(default=True,name="Add Presets menu to the Modifier Panel")
    freezed_verts_for_simulations: bpy.props.IntProperty(default=5,min=1,name="Pinned vertices for cable simulations",description="Number vertices on both ends which are not affected by the simulation")
    use_up_down_keys :bpy.props.BoolProperty(default=False, name="Use UP/DOWN Key instead of Scroll Wheel")
    material_preset: bpy.props.EnumProperty(items=(("Bump",'Bump',"Bump"),("Displacement",'Displacement',"Displacement"),("FBX",'FBX',"FBX")),default=0,name="Preset")
    # show_panel_pies: bpy.props.BoolProperty(default=False, name="Panels and Pies")
    # pop_out_style:bpy.props.EnumProperty(items=(("Pie-PopUp","Pie-PopUp","Pie-PopUp"),("DropDown","DropDown","DropDown")),default=0,name="PopUp Panel Style")
    # #panel_categories: bpy.props.StringProperty(default="RanTools",name="Panel Categories")
    # panel_categories : bpy.props.CollectionProperty(type=Panel_Category)
    # dropdown_categories : bpy.props.CollectionProperty(type=Panel_Category)
    # workspace_categories: bpy.props.CollectionProperty(type=Panel_Category)
    # show_panel_categories: bpy.props.BoolProperty(default=False,name="Pie Panels")
    # show_dropdown_categories: bpy.props.BoolProperty(default=False,name="Dropdown Panels")
    # show_workspace_categories: bpy.props.BoolProperty(default=False, name="Workspace Addon Categories")
    #dropdown_panels:bpy.props.StringProperty(default="",name="Dropdown Panels")
    def draw(self, context):
        layout = self.layout
        draw_update_section_for_prefs(layout,context)
        # row = layout.row()

        # row = row.split(factor=0.7)
        # row.label(text=self.update_status)
        # row.operator("rtools.checkupdates", icon="FILE_REFRESH")
        layout.row().operator("rtools.install_pillow",text="Update Pillow" if support_pillow() else "Install Pillow")    
        # row=layout.row(align=True)
        # row.operator("rtools.saveprefs")
        # row.operator("rtools.loadprefs")
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_shortcuts", emboss=False,
                 icon="TRIA_DOWN" if self.show_shortcuts else "TRIA_RIGHT")

        if self.show_shortcuts:
            col = layout2.column()
            draw_hotkeys(col, "3D View")
            draw_hotkeys(col, "Object Mode")
            draw_hotkeys(col, "Node Editor")
            draw_hotkeys(col, 'Mesh')
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_panels", emboss=False,
                 icon="TRIA_DOWN" if self.show_panels else "TRIA_RIGHT")
        if self.show_panels:
            col = layout2.column()
            row = col.row(align=True)
            row.prop(self, "enable_curve_tools", toggle=True)
            row.prop(self, "enable_camera_tools", toggle=True)
            row = col.row(align=True)
            row.prop(self, "enable_backup", toggle=True)

            row.prop(self, "enable_random_tools", toggle=True)
            row = col.row(align=True)
            row.prop(self, "enable_material_tools", toggle=True)
            row.prop(self, "enable_bake_tools", toggle=True)
            row = col.row(align=True)
            row.prop(self, "enable_light_tools", toggle=True)
            #row.prop(self, "enable_asset_tools", toggle=True)

        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_asset_folders", emboss=False,
                 icon="TRIA_DOWN" if self.show_asset_folders else "TRIA_RIGHT")
        # row.prop(self,'show_misc_settings',toggle=True,icon="TRIA_DOWN")
        if self.show_asset_folders:
            layout3 = layout2.column()
            for index, folder in enumerate(self.asset_folders):
                row = layout3.row()
                row.prop(folder, 'location', text='')
                op = row.operator('rtools.remove_asset_path', text='',
                                  emboss=False, icon='PANEL_CLOSE')
                op.index = index

            row = layout3.row()
            split = row.split(factor=0.4)
            row = split.row()
            split = split.split(factor=0.333)
            split.operator('rtools.add_asset_path', text='Add Folder', icon='PLUS')
            row = layout3.column()

            row.operator("rtools.refresh_indexes",
                         text="Refresh Object Indexes", icon="FILE_REFRESH")
        # row.prop(self, "autoIndex",
        #         text="Auto update indexes whenever a new folder is added")
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_ui_settings", emboss=False,
                 icon="TRIA_DOWN" if self.show_ui_settings else "TRIA_RIGHT")
        # row.prop(self,'show_misc_settings',toggle=True,icon="TRIA_DOWN")
        if self.show_ui_settings:
            l1 = layout2.column()
            row= l1
            row.prop(self, "text_color1")
            row.prop(self, 'text_color2')

            row.prop(self, "text_color3")
            row.prop(self, "text_color4")
            row=l1.row()
            row.prop(self, "bg_color")

            row.prop(self, "bg_border_color")
            row=l1.row(align=True)
            row.prop(self, "border_radius")
            row.prop(self, "border_thickness")
            row=l1.row(align=True)
            row.prop(self, 'loc_x')
            row.prop(self, 'loc_y')
            row= l1.row(align=True)
            row.prop(self, 'loc_y_from_top')
            row.prop(self,'loc_x_from_right')
            row= l1.row(align=True)
            row.prop(self, 'flip_sides',toggle=True)
            row.prop(self, 'font_size')
            row=l1.row(align=True)
            row.prop(self, 'use_floating_text')
            row.prop(self,'floating_text_location',expand=True)
            
        
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_misc_settings", emboss=False,
                 icon="TRIA_DOWN" if self.show_misc_settings else "TRIA_RIGHT")
        # row.prop(self,'show_misc_settings',toggle=True,icon="TRIA_DOWN")
        if self.show_misc_settings:
            row = layout2.column()
            row.prop(self, "projects_path")
            row.prop(self, 'override_save')

            row.prop(self, "use_unique")
            row.prop(self, "auto_abs")

            row.prop(self, "useEevee")

            row.prop(self, "useBoxEmpty")

            row.prop(self, 'extract_from_only_solid_objects')
            row.prop(self,'bake_samples')
            row.prop(self, 'bake_margin')
            #row.prop(self,'cursor_overflow')
            row.prop(self,'use_master_pie')
            row.prop(self,'site_to_check_connection')
            row.prop(self,'use_up_down_keys')
            row.prop(self,'freezed_verts_for_simulations')
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_p_cutter_settings", emboss=False,
                 icon="TRIA_DOWN" if self.show_p_cutter_settings else "TRIA_RIGHT")
        # row.prop(self,'show_p_cutter_settings',toggle=True,icon="TRIA_DOWN")

        if self.show_p_cutter_settings:
            row = layout2.column()
            row.prop(self, 'grid_type')
            if self.grid_type == 'Points':
                row.prop(self, 'show_close_points')
            row2 = row.row()
            row2.prop(self, 'grid_color')
            row.prop(self, 'grid_size')
            row2 = row.row()
            row2.prop(self, 'shape_thickness')
            row2.prop(self, 'grid_line_width')
            row2.prop(self, 'grid_point_size')

            row2 = row.row()
            row2.prop(self, 'show_red_lines')
            row2.prop(self, 'show_inset_points')
            row2 = row.row()
            # row.prop(self,'adjust_segments_after_draw')
            row.prop(self, 'show_snapped_shape')
            row2.prop(self, "auto_hide_bools_after_drawing")
            row2.prop(self, 'apply_mods')
            row.prop(self, 'remember_last_shape')
            row.prop(self, 'apply_bools_slice_mod')
            row.prop(self, "auto_hide_bools")
            row.prop(self, 'bevel_threshold')
            row.prop(self,'sort_mirror_mod')
            row.prop(self, "use_ortho_view")
            row.prop(self, 'auto_ortho')
            row.prop(self, 'skip_adjustment_phase')
            row.prop(self, 'align__to_view_fc')
            row.prop(self, "use_only_active_object")
            row.prop(self,'industry_keymap')
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_presets_settings", emboss=False,
                 icon="TRIA_DOWN" if self.show_presets_settings else "TRIA_RIGHT")
        # row.prop(self,'show_presets_settings',toggle=True,icon="TRIA_DOWN")
        if self.show_presets_settings:
            row = layout2.column()
            row.operator("rtools.import_presets")
            row.prop(self, "mod_presets_favorites")
            row.prop(self, 'use_favorites_pie')
            row.prop(self,'draw_into_modifier_panel')
        layout2 = layout.box()
        row = layout2.row(align=True)
        row.alignment = 'LEFT'
        row.prop(self, "show_material_settings", emboss=False,
                 icon="TRIA_DOWN" if self.show_material_settings else "TRIA_RIGHT")
        # row.prop(self,'show_material_settings',toggle=True,icon="TRIA_DOWN")
        if self.show_material_settings:
            row = layout2.column()
            row.prop(self, "onlyDiffuse")
            #row.prop(self, "useBump")
            row.prop(self, "nodes")
            row.prop(self, "sockets")

            row.prop(self, 'materials_folder')
            
            row.prop(self, 'material_asset_library_folder')
            # row.prop(self,'hdri_preview_resolution')
            row.prop(self, 'imperfection_maps')
            row.prop(self, "delete_zips")
            row.prop(self, "custom_uv_texture")
            row.separator()
            row.prop(self, 'hdris_folder')
            row.operator("rtools.loadhdris")
            row.separator()
            row.operator("rtools.load_previews")
            row.separator()
            #row.prop(self, "wait_time_multiplier")
            row.operator('wm.url_open', text="Support AmbientCG on Patreon",
                         icon='FUND').url = "https://www.patreon.com/ambientCG"
            row.operator('wm.url_open', text="Support PolyHaven on Patreon",
                         icon='FUND').url = "https://www.patreon.com/polyhaven"
# RGB,MIX_RGB,BSDF_PRINCIPLED,BSDF_DIFFUSE,BSDF_GLASS,EMISSION,BSDF_TRANSLUCENT,BSDF_TRANSPARENT,BSDF_REFRACTION,BSDF_GLOSSY,VOLUME_ABSORPTION,VOLUME_SCATTER,PRINCIPLED_VOLUME
# Color1,Color2,Density,Roughness,Base Color,Color,Metallic,Transmission,Specular,Emission,Alpha,Emission Strength,IOR,Strength
__DIRNAME__ = os.path.dirname(os.path.dirname(__file__))
class RTOOLS_OT_Load_Previews(bpy.types.Operator,ImportHelper):
    bl_idname = 'rtools.load_previews'
    bl_label = 'Load Cached Previews'
    filename_ext = '.txt'
    
    filter_glob: bpy.props.StringProperty(
        default='*.zip',
        options={'HIDDEN'}
    )
    def execute(self, context):
        path=self.filepath
        if os.path.isfile(path):
            try:
                with zipfile.ZipFile(path, 'r') as zip_ref:
                                zip_ref.extractall(__DIRNAME__)
                                self.report({'INFO'},"Previews Loaded Successfully!")
            except:
                self.report({'WARNING'},"An Error Occured!")
        return {'FINISHED'}

class RTOOLS_OT_Add_Path(bpy.types.Operator):
    bl_idname = 'rtools.add_asset_path'
    bl_label = 'Add Asset Folder path'
    bl_description = 'Add a path to a Asset Folder'
    
    def execute(self, context):

        folder = bpy.context.preferences.addons[__package__].preferences.asset_folders.add(
        )
        folder.location = 'Choose Path'

        return {'FINISHED'}
class RTOOLS_OT_Add_Category(bpy.types.Operator):
    bl_idname = 'rtools.add_category'
    bl_label = 'Add New Category'
    to: bpy.props.StringProperty(default="Pie")
    def execute(self, context):
        if self.to=='Pie':
            preferences().panel_categories.add()
        elif self.to=='Workspace':
            preferences().workspace_categories.add()
        else:
            preferences().dropdown_categories.add()
        

        return {'FINISHED'}
class RTOOLS_OT_Remove_Category(bpy.types.Operator):
    bl_idname = 'rtools.remove_category'
    bl_label = 'Remove this Category'
    index: bpy.props.IntProperty()

    def execute(self, context):
        preferences().panel_categories.remove(
            self.index)
        return {'FINISHED'}
class RTOOLS_OT_Remove_Category_Dropdown(bpy.types.Operator):
    bl_idname = 'rtools.remove_category_from_dropdown'
    bl_label = 'Remove this Category'
    index: bpy.props.IntProperty()

    def execute(self, context):
        preferences().dropdown_categories.remove(
            self.index)
        return {'FINISHED'}
class RTOOLS_OT_Remove_Category_Workspace(bpy.types.Operator):
    bl_idname = 'rtools.remove_category_from_workspace'
    bl_label = 'Remove this Category'
    index: bpy.props.IntProperty()

    def execute(self, context):
        preferences().workspace_categories.remove(
            self.index)
        return {'FINISHED'}
class RTOOLS_OT_Remove_Asset_Path(bpy.types.Operator):
    bl_idname = 'rtools.remove_asset_path'
    bl_label = 'Remove Asset Folder path'
    bl_description = 'Remove this path'
    index: bpy.props.IntProperty()

    def execute(self, context):
        bpy.context.preferences.addons[__package__].preferences.asset_folders.remove(
            self.index)
        return {'FINISHED'}

class RTOOLS_OT_Import_Download_Data(bpy.types.Operator):
    bl_idname = 'rtools.importdownloaddata'
    bl_label = 'Import data from older versions of Blender'
    bl_description = 'Import Assets and Download data from previous versions of blender'

    def execute(self, context):
        current_version = str(sys.modules['RanTools'].bl_info['version']).replace(
            "(", "").replace(")", "").replace(", ", "")
        og_online_version, message = getCurrentVersion()
        online_version = og_online_version.replace(".", "")
        if online_version != "Disconnected":
            if int(online_version) < int(current_version):

                bpy.context.scene.update_status = "RanTools is Up To Date! (Beta)"
            elif int(online_version) == int(current_version):
                bpy.context.scene.update_status = "RanTools is Up To Date!"
            else:
                bpy.context.scene.update_status = f"Update Available! (v{og_online_version})"
            preferences().update_status = bpy.context.scene.update_status
        else:
            self.report({'WARNING'}, 'No Internet Available!')
        return {'FINISHED'}
class RTOOLS_OT_Check_For_Updates(bpy.types.Operator):
    bl_idname = 'rtools.checkupdates'
    bl_label = 'Check for Updates'
    bl_description = 'Check online if new updates are available'

    def execute(self, context):
        current_version = str(sys.modules['RanTools'].bl_info['version']).replace(
            "(", "").replace(")", "").replace(", ", "")
        og_online_version, message = getCurrentVersion()
        online_version = og_online_version.replace(".", "")
        if online_version != "Disconnected":
            if int(online_version) < int(current_version):

                bpy.context.scene.update_status = "RanTools is Up To Date! (Beta)"
            elif int(online_version) == int(current_version):
                bpy.context.scene.update_status = "RanTools is Up To Date!"
            else:
                bpy.context.scene.update_status = f"Update Available! (v{og_online_version})"
            preferences().update_status = bpy.context.scene.update_status
        else:
            self.report({'WARNING'}, 'No Internet Available!')
        return {'FINISHED'}


class RTOOLS_OT_Refresh(bpy.types.Operator):
    bl_idname = "rtools.refresh_indexes"
    bl_label = "Refresh Indexes Of Objects"
    bl_description = "Refresh Indexes Of Objects for appending"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        asset_folders = []
        for folder in bpy.context.preferences.addons[__package__].preferences.asset_folders:
            if os.path.isdir(folder.location):
                asset_folders.append(folder.location)
        indexAllObjects(asset_folders)
        return {'FINISHED'}
from .t3dn_bip.ops import InstallPillow

class RTOOLS_OT_install_pillow(bpy.types.Operator, InstallPillow):
    bl_idname = 'rtools.install_pillow'
def load_hdris(paths,tags):
    cmd = [bpy.app.binary_path]
    cmd.append("--background")
    cmd.append("--factory-startup")
    cmd.append("--python")
    cmd.append(os.path.join(os.path.dirname(
        os.path.abspath(__file__)), "load_hdris.py"))
    cmd.append('--')
    cmd.append(":--separator--:".join(paths) if paths else 'None')
    cmd.append(tags)
    run(cmd)
def get_all_files(path):
    blends = []
    for path, subdirs, files in os.walk(path):
        for name in files:
                blends.append(os.path.join(path, name))
                #print(os.path.join(path, name))
    return blends
class RTOOLS_OT_Load_HDRIs(bpy.types.Operator):
    bl_idname = "rtools.loadhdris"
    bl_label = "Load Offline HDRIs"
    bl_description = "Load your offline HDRIs into RanTools HDRI Library"
    bl_options = {'REGISTER', 'UNDO'}
    tags: bpy.props.StringProperty(default="",name="Tags")
    filepath: bpy.props.StringProperty(subtype="DIR_PATH")
    files : bpy.props.CollectionProperty(
            name="File Path",
            type=bpy.types.OperatorFileListElement,
            )
    filter_glob: bpy.props.StringProperty(default="*" + ";*".join(['hdr','exr','jpeg','jpg']),options={"HIDDEN"})
    use_jpg: bpy.props.BoolProperty(default=False,name="jpg")
    use_hdr: bpy.props.BoolProperty(default=True,name="hdr")
    use_exr: bpy.props.BoolProperty(default=True,name="exr")
    use_tif: bpy.props.BoolProperty(default=False,name="tif")
    def draw(self, context):
        self.layout.prop(self,'tags')
        row=self.layout.row(align=True)
        row.prop(self,'use_hdr',toggle=True)
        row.prop(self,'use_exr',toggle=True)
        row.prop(self,'use_jpg',toggle=True)
        row.prop(self,'use_tif',toggle=True)
    def execute(self, context):
        files=None
        filters=[]
        if self.use_jpg:
            filters.append(".jpg")
        if self.use_hdr:
            filters.append(".hdr")
        if self.use_exr:
            filters.append(".exr")
        if self.use_tif:
            filters.append(".tif")
        dir_path=os.path.dirname(self.filepath)
        if len([a.name for a in self.files if a.name])>0:
            files=[os.path.join(dir_path,a.name) for a in self.files if os.path.splitext(a.name)[1] in filters]
        else:
            files=[a for a in get_all_files(dir_path) if os.path.splitext(a)[1] in filters]
        
        load_hdris(files,self.tags)
        return {'FINISHED'}
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}