import bpy
import bmesh
from . utils import * 
class HTE_Vertex_Mask(bpy.types.Operator):
    bl_idname = "rtools.vertex_mask"
    bl_label = "Create Vertex Mask"
    bl_description = "Mirror around active object"
    bl_options = {'REGISTER', 'UNDO'}
    obj=None
    def execute(self,context):
        obj=bpy.context.object
        maskGroup=obj.vertex_groups.new(name="RT_Mask")
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        
        selected=[]
        for v in bm.verts:
            if v.select:
                #print(v.index)
                selected.append(v.index)
        bpy.ops.object.mode_set(mode='OBJECT')
        maskGroup.add(selected,1,'REPLACE')
        bpy.ops.object.mode_set(mode='EDIT')
        return{'FINISHED'}
class HTE_Vertex(bpy.types.Operator):
    bl_idname = "rtools.cleanbooleans"
    bl_label = "Boolean CleanUp"
    bl_description = "Quickly merge vertices around boolean cuts"
    bl_options = {'REGISTER', 'UNDO'}
    obj=None
    selected=None
    initX=None
    threshold=None
    thresholdSave=None
    useVGroup1=None
    speed=None
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"Threshold: {self.threshold}","Press A to Toggle",f"Retaining Vertices Of {'Boolean' if self.useVGroup1 else 'Object'}"])
    @classmethod
    def poll(cls, context):
        if context.active_object is not None:
            return context.active_object.mode == 'EDIT'
        else:
            return False
    def execute(self,context):
        rt_tools=context.scene.rt_tools
        selected=[]
        vGroup1=[]
        vGroup2=[]
        #threshold=rt_tools.threshold
        obj=bpy.context.object
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        for v in bm.verts:
            for v2 in self.selected:
                if v.index==v2[0]:
                    v.co=v2[1]
                    selected.append(v)
        #for v in self.selected:
        #    v[0].co=v[1]
        #for v in bm.verts:
        #    if v.select:
        #        selected.append(v)
        #for v in selected:
#            v.select = len(v.link_edges) in (2,)
        #    if len(v.link_edges) in (rt_tools.vGroup1ConEdges,):
        #        vGroup1.append(v)
        #for v in selected:
        #    if len(v.link_edges) in (rt_tools.vGroup2ConEdges,):
        #        vGroup2.append(v)     """
        #print(len(selected))
        
        #obj.vertex_groups.active = obj.vertex_groups[0]

        # Deselect all verts and select only current VG    
        #bpy.ops.mesh.select_all( action = 'DESELECT' )
        #bpy.ops.object.vertex_group_select()
        #bpy.ops.mesh.loop_to_region(select_bigger=True)
        bpy.ops.mesh.loop_to_region()
        vGroup = [ v for v in bm.verts if v.select ]
        #print(vGroup)
        vGroup=[item for item in vGroup if item not in selected]
        for v in vGroup:
            for e in v.link_edges:
                if e.other_vert(v) in selected:
                    vGroup2.append(e.other_vert(v))
        vGroup1=[item for item in selected if item not in vGroup2]
        bpy.ops.mesh.select_all( action = 'DESELECT' )
        for v in selected:
            v.select=True
        bm.select_flush_mode()    
        mesh.update()
        if self.useVGroup1:
            for v in vGroup1:
                    #print("Using VGroup1")
                    closest=(10000000,v)
                #for e in v.link_edges:
                #    v_other = e.other_vert(v)
                    #print((v.co-v_other.co).length)
                    for v_other in vGroup2:
                        if (v.co-v_other.co).length <=self.threshold:
                            if closest[0]>(v.co-v_other.co).length:
                                closest=((v.co-v_other.co).length,v_other)
                    v.co=closest[1].co
        else:
            for v in vGroup2:
                    closest=(10000000,v)
                #for e in v.link_edges:
                #    v_other = e.other_vert(v)
                    #print((v.co-v_other.co).length)
                    #print("Using VGroup2")
                    for v_other in vGroup1:
                        if (v.co-v_other.co).length <=self.threshold:
                            if closest[0]>(v.co-v_other.co).length:
                                closest=((v.co-v_other.co).length,v_other)
                    v.co=closest[1].co
    
        #print(selected)
        #print(vGroup1)
        #print(vGroup2)
        return {'FINISHED'}
    def modal(self, context,event):
        if event.type == 'LEFT_SHIFT':
            self.initX=event.mouse_x
            if event.value == 'PRESS':
                self.speed=10
            elif event.value == 'RELEASE':
                self.speed=1
            self.thresholdSave=self.threshold    
            context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            
            self.threshold=round(self.thresholdSave-(self.initX-event.mouse_x)/(1000*self.speed),3)
            #print(self.threshold)
            self.execute(context)
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            obj=bpy.context.object
            mesh = obj.data  # Get selected object's mesh
#            bm = bmesh.from_edit_mesh(mesh)
#            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.000001)
#            bm.select_flush_mode()    
#            mesh.update()
            self.remove_drawHandler(context)
            bpy.ops.mesh.remove_doubles(threshold=0.0000001)
            mesh.update()
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            
            obj=bpy.context.object
            mesh = obj.data  # Get selected object's mesh
            bm = bmesh.from_edit_mesh(mesh)
            for v in bm.verts:
                for v2 in self.selected:
                    if v.index==v2[0]:

                        v.co=v2[1]
            bm.select_flush_mode()    
            mesh.update()
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type == 'A' and event.value=="PRESS":
            self.useVGroup1=not self.useVGroup1
        return{'RUNNING_MODAL'}
    def invoke(self, context,event):
        bpy.ops.mesh.select_mode(type="VERT")
        obj=bpy.context.object
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        self.speed=1
        self.initX=event.mouse_x
        self.threshold=0
        self.thresholdSave=0
        self.selected=[]
        self.useVGroup1=True
        for v in bm.verts:
            if v.select:
                self.selected.append((v.index,v.co.copy()))
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        return{'RUNNING_MODAL'}
import time
class RTOOLS_Clean_Booleans(bpy.types.Operator):
    bl_idname = "rtools.cleanbooleans"
    bl_label = "Clean Booleans"
    bl_description = "Clean Booleans Cuts using merging and sliding"
    bl_options = {"REGISTER","UNDO"}
    #merge_threshold:bpy.props.FloatProperty(default=0.02,name="Merge Threshold")
    self_mergethreshold:bpy.props.FloatProperty(name="Merge Threshold",default=0.005,min=0)
    merge_threshold:bpy.props.FloatProperty(name="Nearby Merge Threshold",default=0.05,min=0)
    threshold:bpy.props.FloatProperty(name="Slide Selection Threshold",default=0.2,min=0)
    distance:bpy.props.FloatProperty(name="Slide Distance",default=0.4,soft_max=10,min=-1)
    
    
    proportional:bpy.props.BoolProperty(default=False,name="Use Distance Proportional to edge length")
    connect_verts:bpy.props.BoolProperty(default=True,name="Connect Vertices")
    def execute(self, context):
        object_mode=False
        if context.mode=='OBJECT':
            object_mode=True
            bpy.ops.object.editmode_toggle()    
        obj=context.active_object
        
        mesh=obj.data
        bm= bmesh.from_edit_mesh(mesh)
        selected=[v.index for v in bm.edges if v.select]
        if len(selected)==1:
            bpy.ops.rtools.loopselect('INVOKE_DEFAULT')
        og_selection=[v.index for v in bm.verts if v.select]
        
        bpy.ops.mesh.remove_doubles(threshold=self.self_mergethreshold)
        bpy.ops.mesh.dissolve_limited(angle_limit=0.03)
        bpy.ops.rtools.createbooleanvgroups('INVOKE_DEFAULT',threshold=self.merge_threshold)
        bpy.ops.mesh.dissolve_limited(angle_limit=0.03)
        
        bpy.ops.object.editmode_toggle()  
        bpy.ops.object.editmode_toggle() 
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.dissolve_limited(angle_limit=0.02)
        #bpy.ops.rtools.createbooleanvgroups('EXEC_DEFAULT')
        #bpy.ops.object.editmode_toggle()    
        #bpy.ops.rtools.mergevgroups('INVOKE_DEFAULT',threshold=self.merge_threshold,source=context.active_object.vertex_groups[len(context.active_object.vertex_groups)-1].name,target=context.active_object.vertex_groups[len(context.active_object.vertex_groups)-2].name)
        #bpy.ops.object.editmode_toggle()    
        obj=context.active_object
        
        mesh=obj.data
        bm= bmesh.from_edit_mesh(mesh)
        #bm=bmesh.new()
        #bm.from_mesh(mesh)
        selected=[v for v in bm.verts if v.select]
        nearby=set([])
        for v in selected:
            nearby.update([e.other_vert(v) for e in v.link_edges if e.other_vert(v) not in selected and (e.other_vert(v).co-v.co).length<self.threshold] )
        #print(len(nearby))
        #nearby=[v for v in nearby if v not in selected]
        #nearby=[v for v in bm.verts if v.select]
        nearby_with_edge=[]
        deselect_all()
        for v in nearby:
            distances=[(s,(s.co-v.co).length) for s in selected]
                #print([v.z for v in self.coords])
            closest=sorted(distances,key=lambda v:v[1])[0][0]
        
            nearby_with_edge.append((v,tuple([e.other_vert(v) for e in v.link_edges if e.other_vert(v) not in selected and e.other_vert(v) not in nearby]),closest))
            
        nearby_with_edge=set(nearby_with_edge)
        #bm.select_history.clear()
        for v in nearby_with_edge:
            max_angle=0
            selected_edge=None
            for e in v[1]:
                if (v[0].co-v[2].co).length>0 and (v[0].co-e.co).length >0 and  math.degrees((v[0].co-v[2].co).angle(v[0].co-e.co))>max_angle:
                    selected_edge=e
                    
                    max_angle=math.degrees((v[0].co-v[2].co).angle(v[0].co-e.co))
                
            if selected_edge:
                closest_distance=(v[0].co-v[2].co).length
                distance=min(self.distance,1)
                v[0].select=True
                
                #bm.select_history.add(v[0])
                if self.proportional:
                    v[0].co=v[0].co+(selected_edge.co-v[0].co)*distance
                else:
                    distance=min((self.distance/10)-closest_distance,(selected_edge.co-v[0].co).length)
                    v[0].co=v[0].co+(selected_edge.co-v[0].co).normalized()*distance      
        bpy.ops.mesh.remove_doubles(use_unselected=True,threshold=0.001)
        if self.connect_verts:
            #bpy.ops.mesh.vert_connect_path()
            bpy.ops.mesh.vert_connect()
        if object_mode:
            bpy.ops.object.editmode_toggle()
            bm.free()   
        #print(nearby_with_edge)
        return {'FINISHED'}
def get_angle(e1,e2,vert):
    v1=e1.other_vert(vert)
    v3=e2.other_vert(vert)
    a1=vert.co-v1.co
    a2=v3.co-vert.co
    angle=a1.angle(a2)
    return angle
class RTOOLS_OT_Select(bpy.types.Operator):
    bl_idname = "rtools.loopselect"
    bl_label = "Loop Select"
    bl_description = "Select Loop"
    bl_options = {"REGISTER", "UNDO"}
    edge_threshold:bpy.props.FloatProperty(default=math.radians(100),name="Edge Threshold",subtype ='ANGLE')
    face_threshold:bpy.props.FloatProperty(default=math.radians(60),name="Face Threshold",subtype ='ANGLE')
    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):

        active = context.active_object
        bm=bmesh.from_edit_mesh(active.data)
        if issubclass(type(bm.select_history.active),bmesh.types.BMEdge):
            active_edge=bm.select_history.active
            #print(active_edge)
            # bpy.ops.mesh.loop_multi_select(ring=False)
            # active.data.update()
            # bm=bmesh.from_edit_mesh(active.data)

            # new_selection=[a.index for a in bm.edges if a.select]
            # deselect_all()
            # active_edge=bm.edges[active_edge_index]
            # active_edge.select=True
            og_edge=active_edge
            if active_edge and len(active_edge.link_faces)==2:
                angle=active_edge.calc_face_angle_signed()
                vert=active_edge.other_vert(active_edge.verts[0])
                og_vert=vert
                other_vert=active_edge.verts[0]
                used=[]
                used.append(active_edge.verts[0])
                used.append(active_edge.verts[1])
                while vert:
                    #sorted_edge=sorted([e for e in vert.link_edges],key =lambda x:True if [f for f in x.link_faces if f in active_edge.link_faces] else False)
                    sorted_edge=sorted([e for e in vert.link_edges],key =lambda x:get_angle(x,active_edge,vert))
                    
                    l=filter(lambda x:get_angle(x,active_edge,vert)<self.edge_threshold,sorted_edge)
                    
                    for e in l:
                        if e!=active_edge and len(e.link_faces)==2:
                            
                            if abs(e.calc_face_angle_signed()-angle)<self.face_threshold:
                                e.select=True
                                active_edge=e
                                vert=[v for v in e.verts if v!=vert and v not in used]
                                if vert:
                                    vert=vert[0]
                                    used.append(vert)
                                break
                    else:
                                vert=None
                vert=other_vert
                active_edge=og_edge
                while vert:
                    sorted_edge=sorted([e for e in vert.link_edges],key =lambda x:get_angle(x,active_edge,vert))
                    
                    l=filter(lambda x:get_angle(x,active_edge,vert)<self.edge_threshold,sorted_edge)
                    for e in l:
                        if e!=active_edge  and len(e.link_faces)==2:
                            if abs(e.calc_face_angle_signed()-angle)<self.face_threshold:
                                e.select=True
                                active_edge=e
                                vert=[v for v in e.verts if v!=vert and v not in used]
                                if vert:
                                    vert=vert[0]
                                    used.append(vert)
                                break
                    else:
                                vert=None
                selected_verts=[v for v in bm.verts if v.select]
                vert=other_vert
                active_edge=og_edge
                #print(vert)
                split_verts=get_split_vert(vert,active_edge)
                edges_to_deselect=[]
                if split_verts:

                    for split_vert in split_verts:
                        
                        deselect=False
                        
                        for e in split_vert.link_edges:
                            if e.select:
                                (length,edges)=get_path_to_self(vert,e,split_vert)
                                
                                if length<99999:
                                    deselect=True
                                else:
                                    edges_to_deselect.append((length,edges))
                    edges_to_deselect=sorted(edges_to_deselect,key=lambda x : x[0])
                    if deselect:
                        for i,e in enumerate(edges_to_deselect):
                                for edge in e[1]:
                                    edge.select=False
                vert=og_vert
                active_edge=og_edge
                #print(vert)
                split_verts=get_split_vert(vert,active_edge)
                edges_to_deselect=[]
                if split_verts:

                    for split_vert in split_verts:
                        
                        deselect=False
                        
                        for e in split_vert.link_edges:
                            if e.select:
                                (length,edges)=get_path_to_self(vert,e,split_vert)
                                
                                if length<99999:
                                    deselect=True
                                else:
                                    edges_to_deselect.append((length,edges))
                    edges_to_deselect=sorted(edges_to_deselect,key=lambda x : x[0])
                    if deselect:
                        for i,e in enumerate(edges_to_deselect):
                                for edge in e[1]:
                                    edge.select=False
                context.active_object.data.update()
        return {'FINISHED'}

def get_split_vert(vert,active_edge):
    used=[]
    split_verts=[]
    while vert:
        sorted_edge=[e for e in vert.link_edges if e.select]
        if sorted_edge:
                
            for e in sorted_edge:
                if e!=active_edge:
                        active_edge=e
                        vert=[v for v in e.verts if v!=vert and v not in used]
                        if vert:
                            vert=vert[0]
                            used.append(vert)
                            #print(vert)
                            #print([e for e in vert.link_edges if e.select])
                            if len([e for e in vert.link_edges if e.select])==3:
                                split_verts.append(vert)
                                break

                        break
            else:
                        vert=None
        else:
            vert=None
    return split_verts
def get_path_to_self(vert,active_edge,split_vert):
    og_vert=vert
   # print("Target",vert)
    vert=active_edge.other_vert(split_vert)
    #print("OG",vert)
    used=[]
    length=0
    edges=[active_edge,]
    visited_edges=[]
    if vert==og_vert:
        return (active_edge.calc_length(),[])
    while vert:
        sorted_edge=[e for e in vert.link_edges if e.select]
        if sorted_edge:
                
            for e in sorted_edge:
                if e!=active_edge and e not in visited_edges:
                        length+=e.calc_length()
                        active_edge=e
                        edges.append(e)
                        visited_edges.append(e)
                        #print("Used",used)
                        #print("All",[v for v in e.verts])
                        vert=[v for v in e.verts if v!=vert and v not in used]
                        #print("Verts",vert)
                        if vert and vert[0]==og_vert:
                            return (length,edges)
                        if vert:
                            vert=vert[0]
                            used.append(vert)
                        
                        break
            else:
                        vert=None
        else:
            vert=None
    return (9999999999,edges)