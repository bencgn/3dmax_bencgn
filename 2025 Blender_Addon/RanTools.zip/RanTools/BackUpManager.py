import bpy
import bmesh
from .utils import *
from datetime import datetime
from bpy_extras import view3d_utils
class RTOOLS_OT_RefreshBackUps(bpy.types.Operator):
    bl_idname = "rtools.refreshbackup"
    bl_description = "Refresh Backups List"
    bl_label = "Refresh"
    bl_options = {"REGISTER", "UNDO"}
    def invoke(self, context,event):
        obj = context.active_object
        for i,ob in enumerate(obj.BackUps):
            if ob.name not in [o.name for o in context.scene.objects]:
                obj.BackUps.remove(i)
        return {'FINISHED'}
class RTOOLS_OT_RemoveBackUp(bpy.types.Operator):
    bl_idname = "rtools.deletebackup"
    bl_description = "Remove Backup\nCTRL+LMB: Delete Object"
    bl_label = "Delete"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        obj=bpy.context.active_object
        if obj.BackUpsIndex<len(obj.BackUps):
            BackUp=obj.BackUps[obj.BackUpsIndex].obj
            obj.BackUps.remove(obj.BackUpsIndex)
            if event.ctrl:
                delete_object_with_data(BackUp)
        
        return {'FINISHED'}
class RTOOLS_OT_Normal_Transfer(bpy.types.Operator):
    bl_idname = "rtools.normaltransfer"
    bl_description = "Transfer Normals From This Backup\nALT+LMB: Use any other object for normal transfer"
    bl_label = "Normal Transfers"
    bl_options = {"REGISTER", "UNDO"}
    apply_modifier:bpy.props.BoolProperty(name="Apply Modifier",)
    projection_method:bpy.props.EnumProperty(name="Mapping Method",items={('POLYINTERP_NEAREST','Nearest Face Interpolated','Nearest Face Interpolated'),('POLYINTERP_LNORPROJ','Projected Face Interpolated','Projected Face Interpolated')},default='POLYINTERP_NEAREST')
    flipped:bpy.props.BoolProperty(default=False,name="Flipped",description="Flip source normals",options={'SKIP_SAVE'})
    #@classmethod
    #def poll(cls,context):
        #return context.mode=='EDIT_MESH'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"Source: {self.current_object}",],start_x=self.mouse_x,start_y=self.mouse_y)
    def modal(self, context,event):
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        if event.type=='MOUSEMOVE':
            scene= context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            
            (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH')):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_viewport=True
                (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_viewport=s
            if object:
                self.current_object=object.name
            else:
                self.current_object=""
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            scene= context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            
            (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH')):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_viewport=True
                (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_viewport=s
            if object:
                bpy.ops.object.editmode_toggle()
                self.source=object.name
                object.hide_viewport=True
                self.remove_drawHandler(context)
                return self.execute(context)
        if event.type=='RIGHTMOUSE' and event.value=='PRESS':
            for c,s in self.child_hide:
                # bpy.data.objects[c].hide_set(s)
                bpy.data.objects[c].hide_viewport=True
            self.remove_drawHandler(context)
            return {'CANCELLED'}
        if event.type=='MIDDLEMOUSE' or event.type=="WHEELDOWNMOUSE" or (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            return {'PASS_THROUGH'}
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}
    def execute(self, context):
        obj=bpy.data.objects[self.obj]
        maskGroup=obj.vertex_groups.new(name="RT_Normal_Transfer")
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        source=bpy.data.objects[self.source]
        selected=[v.index for v in bm.verts if v.select]
        total_verts=len(bm.verts)
        bpy.ops.object.mode_set(mode='OBJECT')
        if not self.from_backup_list:
            source.hide_set(False)
        if self.flipped:
            hide=source.hide_get()
            source.hide_set(False)
            # source.hide_viewport=False
            deselect_all()
            select(source)
            bpy.ops.object.mode_set(mode='EDIT')
            select_all()
            bpy.ops.mesh.flip_normals()
            bpy.ops.object.mode_set(mode='OBJECT')
            deselect_all()
            select(obj)
            source.hide_set(hide)
            # source.hide_viewport=hide
        
        indices=[a for a in range(total_verts)]
        maskGroup.remove(indices)
        maskGroup.add(selected,1,'REPLACE')
        #bpy.ops.object.mode_set(mode='EDIT')
        data_transfer_mod=obj.modifiers.new(type='DATA_TRANSFER',name='RT_Data_Transfer')
        data_transfer_mod.object=source
        data_transfer_mod.use_loop_data=True
        data_transfer_mod.data_types_loops={'CUSTOM_NORMAL',}
        data_transfer_mod.loop_mapping=self.projection_method
        data_transfer_mod.vertex_group=maskGroup.name
        self.data_transfer_mod=data_transfer_mod
        
        if self.apply_modifier:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier=data_transfer_mod.name)
            bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False)
            #bpy.ops.object.mode_set(mode='EDIT')
        for c,s in self.child_hide:
            # bpy.data.objects[c].hide_set(s)
            bpy.data.objects[c].hide_viewport=True
        return {'FINISHED'}
    def invoke(self, context,event):
        self.apply_modifier=not event.ctrl
        self.alt=event.alt
        obj=context.active_object
        self.obj=obj.name
        self.child_hide=[]
        self.current_object=""
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        self.from_backup_list=False
        if self.alt:
            self.add_drawHandler(context)
            for c in obj.children:
                self.child_hide.append((c.name,c.hide_get()))
                c.hide_set(False)
                # c.hide_viewport=False
            bpy.ops.object.editmode_toggle()
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            if context.mode!='EDIT_MESH':
                self.report({'WARNING'},'Object needs to be in Edit mode')
                return {'CANCELLED'}
            if obj.BackUpsIndex<len(obj.BackUps) :
                self.from_backup_list=True
                source=obj.BackUps[obj.BackUpsIndex].obj
                source.location=obj.location
                source.rotation_euler=obj.rotation_euler
                source.scale=obj.scale
                self.source=source.name
            return self.execute(context)
class RTOOLS_OT_Normal_Transfer_2(bpy.types.Operator):
    bl_idname = "rtools.normaltransfer2"
    bl_description = "Transfer Normals From This Backup"
    bl_label = "Normal Transfers"
    bl_options = {"REGISTER", "UNDO"}
    source:bpy.props.StringProperty(default="")
    apply_modifier:bpy.props.BoolProperty(name="Apply Modifier",)
    projection_method:bpy.props.EnumProperty(name="Mapping Method",items={('POLYINTERP_NEAREST','Nearest Face Interpolated','Nearest Face Interpolated'),('POLYINTERP_LNORPROJ','Projected Face Interpolated','Projected Face Interpolated')},default='POLYINTERP_NEAREST')
    flipped:bpy.props.BoolProperty(default=False)
    #@classmethod
    #def poll(cls,context):
        #return context.mode=='EDIT_MESH'
    
    def execute(self, context):
        
        
        return {'FINISHED'}
class RTOOLS_OT_ViewBackUp(bpy.types.Operator):
    bl_idname = "rtools.viewbackup"
    bl_description = "View Backup"
    bl_label = "View"
    bl_options = {"REGISTER", "UNDO"}
    
    def invoke(self, context,event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        obj=bpy.context.active_object
        BackUp=obj.BackUps[obj.BackUpsIndex].obj
        BackUp.hide_viewport=False
        return {'FINISHED'}
class RTOOLS_OT_HideBackUp(bpy.types.Operator):
    
    bl_idname = "rtools.hidebackup"
    bl_description = "Hide Backup"
    bl_label = "Hide"
    bl_options = {"REGISTER", "UNDO"}
    
    def invoke(self, context,event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        obj=bpy.context.active_object
        BackUp=obj.BackUps[obj.BackUpsIndex].obj
        # BackUp.hide_set(True)
        BackUp.hide_viewport=True
        return {'FINISHED'}
class RTOOLS_OT_AddBackUp(bpy.types.Operator):
    bl_idname = "rtools.addbackup"
    bl_description = "Add Selected Backup\nCTRL+LMB: Add A Copy"
    bl_label = "Add"
    bl_options = {"REGISTER", "UNDO"}
    
    def invoke(self, context,event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        obj=bpy.context.active_object
        if obj.BackUpsIndex<len(obj.BackUps):
            BackUp=obj.BackUps[obj.BackUpsIndex].obj
            if obj is not None:
                if event.ctrl:
                    BackUp=duplicate_object(BackUp,col=obj.users_collection[0].name)
                BackUp.hide_viewport=False
                BackUp.hide_viewport=False
                BackUp.hide_render=False
                BackUp.location=obj.location
                BackUp.rotation_euler=obj.rotation_euler
                BackUp.scale=obj.scale
                BackUp.BackUps.clear()
                """children=obj.children[:]
                hidden_children=[]
                
                for c in children:
                    if c.hide_get():
                        hidden_children.append((c,c.hide_get(),c.hide_viewport))
                    c.hide_viewport=False
                    c.hide_viewport=False
                    select(c)
                
                bpy.ops.object.parent_set(keep_transform=True)
                for (c,h,v) in hidden_children:
                    c.hide_viewport=h
                    c.hide_viewport=v"""
                deselect_all()
                select(BackUp)
                if not event.ctrl:
                    for i in obj.BackUps:
                        if i.obj!=BackUp:
                            a=BackUp.BackUps.add()
                            a.obj=i.obj
                            a.name=i.name
                            a.time=i.time
                move_to_collection(BackUp,obj.users_collection[0].name)

        return {'FINISHED'}
class RTOOLS_OT_ReplaceBackup(bpy.types.Operator):
    bl_idname = "rtools.replacebackup"
    bl_description = "Replace Current Object with Selected Backup\nCTRL+LMB: Retain A Copy"
    bl_label = "Swap"
    bl_options = {"REGISTER", "UNDO"}
    
    def invoke(self, context,event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        obj=bpy.context.active_object
        colOg=obj.users_collection[0]
        tempName=obj.name
        BackUpObj=duplicate_object(obj,col=obj.backup_collection_name)
        BackUpObj.name=obj.name
        BackUpObj.hide_render=True
        BackUpObj.hide_viewport=True
        temp=context.active_object.BackUps.add()
        temp.obj=BackUpObj
        temp.name=BackUpObj.name
        temp.time="\nCreated: "+str(datetime.now().strftime('%H:%M:%S-%d/%m'))
        BackUp=obj.BackUps[obj.BackUpsIndex].obj
        BackUpCopy=BackUp
        BackUpTimeCopy=obj.BackUps[obj.BackUpsIndex].time
        if event.ctrl:
            
            BackUp=duplicate_object(BackUp,col=obj.backup_collection_name)
        if BackUp is not None:
            BackUp.location=obj.location
            BackUp.rotation_euler=obj.rotation_euler
            BackUp.scale=obj.scale
            BackUp.hide_viewport=False
            BackUp.hide_render=False
            BackUp.hide_viewport=False
            move_to_collection(BackUp,colOg.name)
            obj.BackUps.remove(obj.BackUpsIndex)
            children=obj.children[:]
            hidden_children=[]
            deselect_all()
            for c in children:
                if c.hide_get():
                    hidden_children.append((c,c.hide_get(),c.hide_viewport))
                c.hide_viewport=False
                c.hide_viewport=False
                select(c)
            select(BackUp)
            bpy.ops.object.parent_set(keep_transform=True)
            for (c,h,v) in hidden_children:
                c.hide_viewport=h
                c.hide_viewport=v
            BackUp.BackUps.clear()
        for i in obj.BackUps:
            if i.obj!=BackUp:
                a=BackUp.BackUps.add()
                a.obj=i.obj
                a.name=i.name
                a.time=i.time
        if event.ctrl:
            t=BackUp.BackUps.add()
            t.obj=BackUpCopy
            t.name=BackUpCopy.name
            t.time=BackUpTimeCopy
        delete_object_with_data(obj)
        #BackUp.name=tempName
        select(BackUp,active=True)
        return {"FINISHED"}
class RTOOLS_OT_CreateBackUp(bpy.types.Operator):
    bl_idname = "rtools.createbackup"
    bl_label = "Create Backup"
    bl_description = "Create New Backup"
    bl_options = {"REGISTER", "UNDO"}
    name:bpy.props.StringProperty(default="")
    def invoke(self, context,event):
        bpy.ops.rtools.refreshbackup('INVOKE_DEFAULT')
        c=get_collection("RT_BackUps")
        c=bpy.data.collections[c]
        if type(c)!=bool:
            c.color_tag='COLOR_04'

        obj_col=get_collection(bpy.context.active_object.name if context.active_object.backup_collection_name=="" else context.active_object.backup_collection_name)
        obj_col=bpy.data.collections[obj_col]
        #print(context.scene.collection.children[:])
        if obj_col.name in [a.name for a in context.scene.collection.children]:
            context.scene.collection.children.unlink(obj_col)
        if obj_col.name not in [a.name for a in c.children]:
            c.children.link(obj_col)
        if context.active_object.backup_collection_name=="":
            
            context.active_object.backup_collection_name=obj_col.name
        BackUpObj=duplicate_object(bpy.context.active_object,col=obj_col.name)
        if self.name=="":
            BackUpObj.name=bpy.context.active_object.name+str(datetime.now().strftime('_%H:%M'))
        else:
            BackUpObj.name=self.name
            context.scene.rt_tools.backup_name=""
        BackUpObj.hide_render=True
        BackUpObj.hide_viewport=True
        BackUpObj.BackUps.clear()
        temp=context.active_object.BackUps.add()
        temp.obj=BackUpObj
        temp.name=BackUpObj.name
        temp.time="\nCreated: "+str(datetime.now().strftime('%H:%M:%S-%d/%m'))
        return {"FINISHED"}