import bpy
import bmesh
from . utils import *
class RTOOLS_OT_Instance_At_Vertices(bpy.types.Operator):
    bl_idname = "rtools.instanceatverts"
    bl_label = "Instance At Vertices"
    bl_description = "Instance Selected Object At Each Face of Active Object"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        mode=context.mode
        obj=context.active_object
        obj_to_instance=Diff(context.selected_objects,[obj])[0]
        evaluated_obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        #if len(obj.particle_systems) == 0:
        maskGroup=obj.vertex_groups.new(name="RT_Instance_Verts")
        bpy.ops.object.mode_set(mode='EDIT')
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        selected=[]
        for v in bm.verts:
            if v.select:
                selected.append(v.index)
        bpy.ops.object.mode_set(mode='OBJECT')
        maskGroup.add(selected,1,'REPLACE')
        mod=obj.modifiers.new("RT_PS_Vert_Instanced", type='PARTICLE_SYSTEM')
        
        particle_system = context.active_object.particle_systems[context.active_object.particle_systems.active_index]
        #particle_system = obj.particle_systems[0]
        settings=particle_system.settings
        settings.type='HAIR'
        settings.use_advanced_hair=True
        settings.hair_length=0.05
        settings.emit_from='VERT'
        settings.use_modifier_stack=True
        settings.use_emit_random=False
        settings.use_even_distribution=False
        settings.userjit=1
        settings.use_rotations=True
        settings.rotation_mode='NOR'
        settings.particle_size=1
        settings.jitter_factor=0
        settings.render_type='OBJECT'
        settings.instance_object=obj_to_instance
        if mode=='EDIT_MESH':
            particle_system.vertex_group_density=maskGroup.name
            settings.count=len(selected)
        else:
            settings.count=len(evaluated_obj.data.vertices)
        settings.use_rotation_instance=True
        return {'FINISHED'}
class RTOOLS_OT_Convert_And_Apply_PS(bpy.types.Operator):
    bl_idname = "rtools.convertandapply"
    bl_label = "Make Instances Real"
    bl_description = "Convert Instances To Real Objects And Remove Particle System\nCTRL+LMB:Dont Make Object Data Single User"
    bl_options = {"REGISTER","UNDO"}
    def invoke(self,context,event):
        obj=context.active_object
        bpy.ops.object.duplicates_make_real()
        for m in obj.modifiers:
            if 'RT_PS_Vert_Instanced' in m.name or 'RT_PS_Face_Instanced' in m.name:
                #print(m.name)
                bpy.ops.object.modifier_apply(modifier=m.name)
                #bpy.ops.object.apply_modifier({"active_object" : obj},name=m.name)
        if not event.ctrl:
            bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)
            select(context.selected_objects[0])
            bpy.ops.object.join()
        return {'FINISHED'}
class RTOOLS_OT_Instance_At_Faces(bpy.types.Operator):
    bl_idname = "rtools.instanceatfaces"
    bl_label = "Instance At Faces"
    bl_description = "Instance Selected Object At Each Face of Active Object Using Particle Systems\nCTRL+LMB:Use Instancing To Create Instances"
    bl_options = {"REGISTER","UNDO"}
    def invoke(self,context,event):
        obj=context.active_object
        obj_to_instance=Diff(context.selected_objects,[obj])[0]
        if event.ctrl: 
            obj_to_instance.location=obj.location
            obj_to_instance.parent=obj
            obj.instance_type='FACES'
            obj.use_instance_faces_scale=True
        else:
            evaluated_obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
            #if len(obj.particle_systems) == 0:
            mod=obj.modifiers.new("RT_PS_Face_Instanced", type='PARTICLE_SYSTEM')
            
            particle_system = context.active_object.particle_systems[context.active_object.particle_systems.active_index]
            #particle_system = obj.particle_systems[0]
            settings=particle_system.settings
            settings.type='HAIR'
            settings.use_advanced_hair=True
            settings.hair_length=0.05
            settings.emit_from='VOLUME'
            settings.use_modifier_stack=True
            settings.use_emit_random=False
            settings.use_even_distribution=False
            settings.userjit=1
            settings.use_rotations=True
            settings.rotation_mode='NOR_TAN'
            settings.particle_size=1
            settings.jitter_factor=0
            settings.render_type='OBJECT'
            settings.instance_object=obj_to_instance
            settings.count=len(evaluated_obj.data.polygons)
        return {'FINISHED'}
class RTOOLS_OT_IAF_Subdivide(bpy.types.Operator):
    bl_idname = "rtools.iafsubdivide"
    bl_label = "SubDivide"
    #bl_description = "Subdivide Source Object"
    bl_options = {"REGISTER","UNDO"}
    unsubdivide :bpy.props.BoolProperty(default=False)
    @classmethod
    def description(cls,context,properties):
        return 'Subdivide Source Object' if not properties.unsubdivide else 'UnSubdivide Source Object'
    def execute(self,context):
        obj=context.active_object
        if self.unsubdivide:
            if obj.modifiers.get("RT_IAF_Subsurf") is not None:
                subsurfMod=obj.modifiers.get("RT_IAF_Subsurf")
                subsurfMod.levels-=1
                subsurfMod.render_levels=subsurfMod.levels
        else:
            if obj.modifiers.get("RT_IAF_Subsurf") is None:
                subsurfMod=obj.modifiers.new(type="SUBSURF",name="RT_IAF_Subsurf")
                index=0
                for m in obj.modifiers:
                    index+=1
                    if  'RT_PS_Face_Instanced' in m.name:
                        break
                offset=len(obj.modifiers)-index
                for i in range(0,offset):
                    bpy.ops.object.modifier_move_up(modifier="RT_IAF_Subsurf")
            else:
                subsurfMod=obj.modifiers.get("RT_IAF_Subsurf")
                subsurfMod.levels+=1
                subsurfMod.render_levels=subsurfMod.levels
        
        #mod=obj.modifiers.new("RT_PS_Face_Instanced", type='PARTICLE_SYSTEM')
        evaluated_obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        for ps in obj.particle_systems:
            if 'RT_PS_Face_Instanced' in ps.name:
                #particle_system = context.active_object.particle_systems[context.active_object.particle_systems.active_index]
                #particle_system = obj.particle_systems[0]
                settings=ps.settings

                settings.count=len(evaluated_obj.data.polygons)
        return {'FINISHED'}
class RTOOLS_OT_Update_IAF(bpy.types.Operator):
    bl_idname = "rtools.updateiaf"
    bl_label = "Update Instances"
    bl_description = "Update Instance Count"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        obj=context.active_object
        
        
        evaluated_obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        for ps in obj.particle_systems:
            if 'RT_PS_Face_Instanced' in ps.name:
                settings=ps.settings
                settings.count=len(evaluated_obj.data.polygons)
        return {'FINISHED'}
class RTOOLS_OT_Boid_Paritcles(bpy.types.Operator):
    bl_idname = "rtools.createboids"
    bl_label = "Create Boids"
    bl_description = "Add Lattice and Lattice Modifier"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        
        obj=context.active_object
        objs_to_instance=Diff(context.selected_objects,[obj])
        evaluated_obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        #if len(obj.particle_systems) == 0:
        initPS=bpy.data.particles[:]
        mod=obj.modifiers.new(obj.name+"_Boid_System", type='PARTICLE_SYSTEM')
        particle_system=Diff(bpy.data.particles,initPS)[0]
        
        t=context.scene.boidSystems.add()
        t.name=particle_system.name
        t.particle_system=particle_system
        #print(t.particle_system)
        #particle_system = context.active_object.particle_systems[context.active_object.particle_systems.active_index]
        #particle_system = obj.particle_systems[0]
        settings=particle_system
        get_collection(settings.name+"_Objects")
        for obj_to_instance in objs_to_instance:
            link_to_collection(obj_to_instance,settings.name+"_Objects")
        settings.render_type='COLLECTION'
        settings.instance_collection=get_collection(settings.name+"_Objects")
        settings.count=100
        #settings.count=context.scene.rt_tools.boid_count
        settings.lifetime=context.scene.frame_end
        settings.physics_type='BOIDS'
        settings.boids.air_speed_min=0.1
        settings.boids.air_personal_space=3
        settings.use_modifier_stack
        settings.boids.land_stick_force=1
        while settings.boids.active_boid_state.rules:
            bpy.ops.boid.rule_del({"particle_settings" : settings})
        state = settings.boids.active_boid_state
        rules = ('SEPARATE','GOAL',)
        for rule in rules:
            bpy.ops.boid.rule_add({"particle_settings" : settings}, type=rule)
        obj.show_instancer_for_render=False
        return {'FINISHED'}
class RTOOLS_OT_Add_Instance_Object(bpy.types.Operator):
    bl_idname = "rtools.addinstanceobject"
    bl_label = "Add Objects"
    bl_description = "Add Lattice and Lattice Modifier"
    bl_options = {"REGISTER","UNDO"}
    
    def execute(self,context):
        settings=context.scene.boidSystems[context.scene.active_boid_system].particle_system
        get_collection(settings.name+"_Objects")
        for obj in context.selected_objects:
            try:
                link_to_collection(obj,settings.name+"_Objects")
            except:
                pass
        return {'FINISHED'}
class RTOOLS_OT_Add_Collision_Object(bpy.types.Operator):
    bl_idname = "rtools.addcollisionobject"
    bl_label = "Add Collision"
    bl_description = "Add Lattice and Lattice Modifier"
    bl_options = {"REGISTER","UNDO"}
    
    def execute(self,context):
        settings=context.scene.boidSystems[context.scene.active_boid_system].particle_system
        #print(settings.boids.active_boid_state.rules[0].type)
        if 'AVOID_COLLISION' not in [r.type for r in settings.boids.active_boid_state.rules]:
            bpy.ops.boid.rule_add({"particle_settings" : settings}, type='AVOID_COLLISION')
            bpy.ops.boid.rule_move_up({"particle_settings" : settings})
            settings.boids.active_boid_state.rules["Avoid Collision"].use_avoid_collision=True
            settings.boids.active_boid_state.rules["Avoid Collision"].look_ahead=5
        get_collection(settings.name+"_Collision")
        for obj in context.selected_objects:
            try:
                if [m for m in obj.modifiers if m.type=='COLLISION']:
                    collisionMod=[m for m in obj.modifiers if m.type=='COLLISION'].pop()
                else:
                    collisionMod=obj.modifiers.new(type='COLLISION',name=settings.name+"_Collision")
                if settings.boids.use_land:
                    collisionMod.settings.stickiness=1
                else:
                    collisionMod.settings.stickiness=0
                link_to_collection(obj,settings.name+"_Collision")
            except:
                pass
        settings.collision_collection=get_collection(settings.name+"_Collision")

        return {'FINISHED'}