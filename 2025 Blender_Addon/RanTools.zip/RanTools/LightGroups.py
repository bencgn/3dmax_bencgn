import bpy
from . utils import * 
import mathutils
import time
import random
def refreshLightGroups(context):
    for i,group in enumerate(context.scene.lightGroups):
        lightNames=[i.name for i in group.lights]
        for light in lightNames:
            if light not in [o.name for o in bpy.context.scene.objects]:
                #print([i.name for i in group.lights])
                #print(light.name," ",group.lights.find(light.name))
                group.lights.remove(group.lights.find(light))
        if len(group.lights) <= 0:
            group.lights.clear()
            context.scene.lightGroups.remove(i)
class RTOOLS_OT_Light_Color_From_Clipboard(bpy.types.Operator):
    bl_idname = "rtools.copyfromclipboard"
    bl_label = "From Clipboard"
    bl_description = "Set color of all lights from the clipboard"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        group=context.scene.lightGroups[self.index]
        try:
            for light in group.lights:
                light.light.data.color=eval(bpy.context.window_manager.clipboard)[:3]
        except:
            self.report({'WARNING'},'Clipboard value is not a color!')
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Solo_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.sololightgroup"
    bl_label = "Solo"
    bl_description = "Solo this Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        all_lights=[n for n in context.scene.objects if n.type=='LIGHT']
        lights_in_group=[light.light for light in context.scene.lightGroups[self.index].lights]
        lights_to_hide=Diff(all_lights,lights_in_group)
        for light in lights_to_hide:
            if not light.hide_get():
                t=context.scene.lightGroups[self.index].hidden_lights.add()
                t.name=light.name
                t.light=light
            light.hide_view=True
        for light in lights_in_group:
            light.hide_view=False
        for group in context.scene.lightGroups:
            if group !=context.scene.lightGroups[self.index]:
                group.solo=False
                group.hidden_lights.clear()
        context.scene.lightGroups[self.index].solo=True
        return {"FINISHED"}
class RTOOLS_OT_UnSolo_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.unsololightgroup"
    bl_label = "Unsolo"
    bl_description = "Unsolo this Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        for light in context.scene.lightGroups[self.index].hidden_lights:
            light.light.hide_view=False
        context.scene.lightGroups[self.index].hidden_lights.clear()
        context.scene.lightGroups[self.index].solo=False
        return {"FINISHED"}
class RTOOLS_OT_Remove_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.removelightgroup"
    bl_label = "Dissolve"
    bl_description = "Dissolve this Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        context.scene.lightGroups.remove(self.index)
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Multiply_Light_Energy(bpy.types.Operator):
    bl_idname = "rtools.multiplylightenergy"
    bl_label = "Powers"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    factor:bpy.props.FloatProperty()
    @classmethod
    def description(cls,context,properties):
        return f"{translate_text('Multiply All Lights Powers by')} {properties.factor}\nCtrl+LMB: {translate_text('Divide All Lights Powers by')} {properties.factor}"
    def invoke(self,context,event):
        
            
        group=context.scene.lightGroups[self.index]
        for light in group.lights:
            if event.ctrl:
                light_power_multiply(1/self.factor,light.light)
            else:
                light_power_multiply(self.factor,light.light)
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Randomise_Light_Color(bpy.types.Operator):
    bl_idname = "rtools.randomiselightcolor"
    bl_label = "Randomise Colors"
    bl_description = "Assign Random Colors To Each Light"
    bl_options = {"REGISTER","UNDO"}
    index:bpy.props.IntProperty(options={'HIDDEN'})
    seed:bpy.props.IntProperty()
    def execute(self,context):
        group=context.scene.lightGroups[self.index]
        random.seed(self.seed)
        i=1
        for light in group.lights:
            
            random.seed(self.seed-i)
            color=mathutils.Color(light.light.data.color)
            color.h=random.uniform(0,1)
            color.s=random.uniform(0,1)
            light.light.data.color=color
            i+=1
        refreshLightGroups(context)
            
        
        return {"FINISHED"}
class RTOOLS_OT_Select_Light(bpy.types.Operator):
    bl_idname = "rtools.selectlight"
    bl_label = "Select"
    bl_description = "Select Light\nShift+LMB: Add Light To Selection"
    bl_options = {"UNDO"}
    light:bpy.props.StringProperty()
    def invoke(self,context,event):
        if not event.shift:
            bpy.ops.object.select_all(action='DESELECT')
        select(bpy.data.objects[self.light])
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Select_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.selectlightgroup"
    bl_label = "Select"
    bl_description = "Select All Lights From This Group\nShift+LMB: Add All Lights To Selection"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def invoke(self,context,event):
        if not event.shift:
            bpy.ops.object.select_all(action='DESELECT')
        group=context.scene.lightGroups[self.index]
        for light in group.lights:
            select(light.light)
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Remove_Light_From_Group(bpy.types.Operator):
    bl_idname = "rtools.removelightfromgroup"
    bl_label = "Remove"
    bl_description = "Remove Light From This Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    indexLight:bpy.props.IntProperty()
    def execute(self,context):
        group=context.scene.lightGroups[self.index]
        group.lights.remove(self.indexLight)
        if len(group.lights)<=0:
            context.scene.lightGroups.remove(self.index)
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Add_Light_To_Group(bpy.types.Operator):
    bl_idname = "rtools.addlighttogroup"
    bl_label = "Add Light"
    bl_description = "Add Selected Lights to This Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        group=context.scene.lightGroups[self.index]
        selected_Lights=[light for light in context.selected_objects if light.type=="LIGHT" and light not in [light.light for light in group.lights]]
        for obj in selected_Lights:
            light=group.lights.add()
            light.name=obj.name
            light.light=obj
        refreshLightGroups(context)
        return {"FINISHED"}
class RTOOLS_OT_Delete_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.deletelightgroup"
    bl_label = "Delete Group"
    bl_description = "Delete All Lights in this Group"
    bl_options = {"UNDO"}
    index:bpy.props.IntProperty()
    def execute(self,context):
        group=context.scene.lightGroups[self.index]
        for light in group.lights:
            delete_object(light.light)
        bpy.ops.rtools.removelightgroup('INVOKE_DEFAULT',index=self.index)
        refreshLightGroups(context)
        return {"FINISHED"}

class RTOOLS_OT_Create_Light_Group(bpy.types.Operator):
    bl_idname = "rtools.createlightgroup"
    bl_label = "Create Group"
    bl_description = "Create New Light Group with Selected Lights"
    bl_options = {"REGISTER","UNDO"}

    
    def execute(self, context):
        selected_Lights=[light for light in context.selected_objects if light.type=="LIGHT"]
        if len(selected_Lights)>0:
            group=context.scene.lightGroups.add()
            if context.scene.rt_tools.light_group_name =="":
                name="Light Group"
                ogName="Light Group"
            else:
                name=context.scene.rt_tools.light_group_name
                ogName=name
            i=1
            while(name in [l.name for l in context.scene.lightGroups]):
                name=ogName+f" {i}"
                i+=1
            group.name=name
            
            context.scene.rt_tools.light_group_name =""    
            for obj in selected_Lights:
                
                light=group.lights.add()
                light.name=obj.name
                light.light=obj
        else:
            self.report({"WARNING"},"No Lights Selected!")
        refreshLightGroups(context)
        return {"FINISHED"}