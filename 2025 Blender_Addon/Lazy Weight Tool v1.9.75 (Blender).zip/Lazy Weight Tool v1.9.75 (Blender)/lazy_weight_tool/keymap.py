import bpy
# Paint Vertex Selection (Weight, Vertex)

addon_keymaps = []
def add_hotkey():
	addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon

	if kc:
		########################################################
		km = wm.keyconfigs.addon.keymaps.new('Pose', space_type='EMPTY', region_type='WINDOW', modal=False)
		kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',shift=True)
		kmi.properties.name = "LAZYWEIGHT_MT_pie_menu"
		addon_keymaps.append((km, kmi))

		km = wm.keyconfigs.addon.keymaps.new(name = 'Mesh')
		kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',shift=True,alt=True)
		kmi.properties.name = "LAZYWEIGHT_MT_pie_menu"
		addon_keymaps.append((km, kmi))


		########################################################
		km = wm.keyconfigs.addon.keymaps.new(name = 'Weight Paint', space_type = 'EMPTY')
		kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',shift=True)
		kmi.properties.name = "LAZYWEIGHT_MT_pie_menu"
		addon_keymaps.append((km, kmi))
		kmi = km.keymap_items.new('lazyweight.adjust_weight_gesture', 'F', 'PRESS',shift=True,alt=True)
		addon_keymaps.append((km, kmi))

		########################################################
		km = wm.keyconfigs.addon.keymaps.new(name = 'Vertex Paint', space_type = 'EMPTY')
		kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',shift=True)
		kmi.properties.name = "LAZYWEIGHT_MT_pie_menu"
		addon_keymaps.append((km, kmi))

		########################################################
		km = wm.keyconfigs.addon.keymaps.new(name = 'Image Paint', space_type = 'EMPTY')
		kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',shift=True)
		kmi.properties.name = "LAZYWEIGHT_MT_pie_menu"
		addon_keymaps.append((km, kmi))

		kmi = km.keymap_items.new("lazyweight.select_less", 'NUMPAD_MINUS', 'PRESS', ctrl=True)
		addon_keymaps.append((km, kmi))

		kmi = km.keymap_items.new("lazyweight.select_more", 'NUMPAD_PLUS', 'PRESS', ctrl=True)
		addon_keymaps.append((km, kmi))

		kmi = km.keymap_items.new("lazyweight.select_link", 'LEFTMOUSE', 'DOUBLE_CLICK', shift=True)
		addon_keymaps.append((km, kmi))

		kmi = km.keymap_items.new("lazyweight.select_link", 'L', 'PRESS')
		addon_keymaps.append((km, kmi))

		########################################################
		if bpy.app.version >= (2, 83, 00):
			km = wm.keyconfigs.addon.keymaps.new('Paint Vertex Selection (Weight, Vertex)', space_type='EMPTY', region_type='WINDOW', modal=False)
		else:
			km = wm.keyconfigs.addon.keymaps.new('Weight Paint Vertex Selection', space_type='EMPTY', region_type='WINDOW', modal=False)

		add_select_op(km)
		kmi = km.keymap_items.new("paint.vert_select_all", 'A', 'PRESS', ctrl=True)
		addon_keymaps.append((km, kmi))

		########################################################
		km = wm.keyconfigs.addon.keymaps.new('Paint Face Mask (Weight, Vertex, Texture)', space_type='EMPTY', region_type='WINDOW', modal=False)

		add_select_op(km)
		kmi = km.keymap_items.new("paint.face_select_all", 'A', 'PRESS', ctrl=True)
		addon_keymaps.append((km, kmi))


def add_select_op(km):
	kmi = km.keymap_items.new('lazyweight.select_edgeloop_click', 'LEFTMOUSE', 'DOUBLE_CLICK',alt=True)
	kmi.properties.extend = False
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new('lazyweight.select_edgeloop_click', 'LEFTMOUSE', 'DOUBLE_CLICK',shift=True,alt=True)
	kmi.properties.extend = True
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new('lazyweight.shortest_path_pick', 'LEFTMOUSE', 'PRESS',ctrl=True,shift=True)
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.select_link", 'LEFTMOUSE', 'DOUBLE_CLICK', shift=True)
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.select_link", 'L', 'PRESS')
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.select_less", 'NUMPAD_MINUS', 'PRESS', ctrl=True)
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.select_more", 'NUMPAD_PLUS', 'PRESS', ctrl=True)
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.paste_weight", 'V', 'PRESS', ctrl=True,shift=True)
	addon_keymaps.append((km, kmi))

	kmi = km.keymap_items.new("lazyweight.copy_weight", 'C', 'PRESS', ctrl=True,shift=True)
	addon_keymaps.append((km, kmi))







class AMLIST_OT_Add_Hotkey(bpy.types.Operator):
	''' Add hotkey entry '''
	bl_idname = "am_list.add_hotkey"
	bl_label = "Addon Preferences Example"
	bl_options = {'REGISTER', 'INTERNAL'}

	def execute(self, context):
		add_hotkey()

		self.report({'INFO'}, "Hotkey added in Preferences -> Keymap")
		return {'FINISHED'}


def remove_hotkey():
	for km, kmi in addon_keymaps:
		km.keymap_items.remove(kmi)
	addon_keymaps.clear()
