import bpy, re
from bpy.types import Operator
from bpy.props import *
from .op_other import set_actvg_of_selobjs


class LAZYWEIGHT_OT_vgroup_lock_toggle(Operator):
	bl_idname = "lazyweight.vgroup_lock_toggle"
	bl_label = "Toggle Lock"
	bl_options = {'REGISTER', 'UNDO'}
	name : StringProperty(default="")

	def execute(self, context):
		# lw = bpy.context.object.vertex_groups[self.name].lock_weight
		if bpy.context.object.vertex_groups[self.name].lock_weight:
			bpy.context.object.vertex_groups[self.name].lock_weight = False
		else:
			bpy.context.object.vertex_groups[self.name].lock_weight = True

		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_active_select_move(Operator):
	bl_idname = "lazyweight.vgroup_active_select_move"
	bl_label = "Active Select Move"
	bl_options = {'REGISTER', 'UNDO'}
	down : BoolProperty(default=False)

	def execute(self, context):
		if self.down:
			bpy.context.object.vertex_groups.active_index = bpy.context.object.vertex_groups.active.index + 1
			if bpy.context.object.vertex_groups.active_index == -1:
				bpy.context.object.vertex_groups.active_index = 0
		else:
			bpy.context.object.vertex_groups.active_index = bpy.context.object.vertex_groups.active.index - 1
			if bpy.context.object.vertex_groups.active_index == -1:
				bpy.context.object.vertex_groups.active_index = 0
		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_set_active(Operator):
	bl_idname = "lazyweight.vgroup_set_active"
	bl_label = "Set Active Vgroup"
	bl_description = "Set Active Vgroup.\nShift + click to rename"
	bl_options = {'REGISTER', 'UNDO'}

	name : StringProperty(default="")
	after_name : StringProperty(default="", name = "After Name")

	def invoke(self, context, event):
		# if event.type == 'LEFTMOUSE' and event.value == "DOUBLE_CLICK":
		if event.shift:
			self.after_name = self.name
			wm = context.window_manager
			# return wm.invoke_props_dialog(self,width=200)
			return wm.invoke_props_dialog(self,width=200)
		else:
			bpy.context.object.vertex_groups.active_index = bpy.context.object.vertex_groups[self.name].index

			props = bpy.context.scene.lazyweight
			if props.auto_set_actvg_of_selobjs:
				set_actvg_of_selobjs()

			return {'FINISHED'}

	def draw(self, context):
		layout = self.layout
		layout.prop(self, 'after_name', text="")

	def execute(self, context):
		# bpy.data.collections[self.name].name = self.after_name
		bpy.context.object.vertex_groups[self.name].name = self.after_name


		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_RemoveEmpty(Operator):
	bl_idname = "lazyweight.vgroup_remove_empty"
	bl_label = "Delete empty vertex groups"
	bl_description = "Delete vertex groups that have no vertex assigned"
	bl_options = {'REGISTER', 'UNDO'}

	pass_lock_weight : BoolProperty(name="Pass Rock weight Vertex Group")

	@classmethod
	def poll(cls, context):
		ob = context.active_object
		if (ob):
			if (ob.type == 'MESH'):
				if (len(ob.vertex_groups)):
					return True
		return False

	def execute(self, context):
		obj = context.active_object
		if (obj.type == "MESH"):
			use_vg_l = [i.group for v in obj.data.vertices for i in v.groups]
			use_vg_l = list(set(use_vg_l))
			del_l = []
			for vg in reversed(obj.vertex_groups):
				if self.pass_lock_weight:
					if vg.lock_weight:
						continue
				if not vg.index in use_vg_l:
					obj.vertex_groups.remove(vg)
					del_l.append(vg)

			self.report({'INFO'}, "remove [%s]" % len(del_l))

		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_AddSymmetry(Operator):
	bl_idname = "lazyweight.vgroup_add_symmetry"
	bl_label = "Add empty symmetry vertex group"
	bl_description = "Creates a new pair of empty vertices according to the instruction rules such as .L and .R"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		ob = context.active_object
		if (ob):
			if (ob.type == 'MESH'):
				if (len(ob.vertex_groups)):
					return True
		return False

	def execute(self, context):
		obj = context.active_object
		if (obj.type == "MESH"):
			vgs = obj.vertex_groups[:]
			for vg in vgs:
				oldName = vg.name
				newName = re.sub(r'([_\.-])L$', r'\1R', vg.name)
				if (oldName == newName):
					newName = re.sub(r'([_\.-])R$', r'\1L', vg.name)
					if (oldName == newName):
						newName = re.sub(r'([_\.-])l$', r'\1r', vg.name)
						if (oldName == newName):
							newName = re.sub(r'([_\.-])r$', r'\1l', vg.name)
							if (oldName == newName):
								newName = re.sub(r'[lL][eE][fF][tT]$', r'Right', vg.name)
								if (oldName == newName):
									newName = re.sub(r'[rR][iI][gG][hH][tT]$', r'Left', vg.name)
									if (oldName == newName):
										newName = re.sub(r'^[lL][eE][fF][tT]', r'Right', vg.name)
										if (oldName == newName):
											newName = re.sub(r'^[rR][iI][gG][hH][tT]', r'Left', vg.name)
				for v in vgs:
					if (newName.lower() == v.name.lower()):
						break
				else:
					obj.vertex_groups.new(name=newName)
		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_ApplyDynamicPaint(Operator):
	bl_idname = "lazyweight.apply_dynamic_paint"
	bl_label = "Weighting object intersections"
	bl_description = "Weight the overlapping parts of the selected objects with dynamic paint"
	bl_options = {'REGISTER', 'UNDO'}

	new_vertex_group : BoolProperty(name="New Vertex Group")
	distance : FloatProperty(name="Distance", default=0.0, min=0, max=100, soft_min=0, soft_max=100, step=10, precision=3)
	items = [
		("REPLACE", "Replace", "","IMPORT", 0),
		("ADD", "Add", "","ADD", 1),
		("SUBTRACT", "Subtract", "","REMOVE", 2),
		]
	mix_mode : EnumProperty(items=items, name="Mix Mode",default="ADD")
	wireframe_other_object : BoolProperty(name="Wireframe Display Other Object")
	strength : FloatProperty(name="Strength",min=0,max=1,default=1)

	items = [
		("REPLACE", "Replace", "", 1),
		("ADD", "Add", "", 2),
		("SUBTRACT", "Subtract", "", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Mix Mode")
	apply : BoolProperty(name="Apply",default=True)

	@classmethod
	def poll(cls, context):
		obj = bpy.context.object
		if (obj):
			if (obj.type == 'MESH'):
				if len(bpy.context.selected_objects) >= 2:
					return True


	def draw(self, context):
		layout = self.layout
		layout.prop(self,"new_vertex_group")

		row = layout.row(align=True)
		row.prop(self,"mix_mode",expand=True)

		row = layout.row(align=True)
		row.use_property_split = True
		row.use_property_decorate = False
		row.prop(self,"distance")
		row = layout.row(align=True)
		row.active= (not self.new_vertex_group)
		row.use_property_split = True
		row.use_property_decorate = False
		row.prop(self,"strength")

		layout.separator()
		layout.prop(self,"wireframe_other_object")
		layout.prop(self,"apply")


	def execute(self, context):
		activeObj = context.active_object
		old_mode = activeObj.mode
		if old_mode == "EDIT":
			bpy.ops.object.mode_set(mode="OBJECT")

		act_vg = activeObj.vertex_groups.active
		if not act_vg:
			self.new_vertex_group = True
		brushObjs = [obj for obj in bpy.context.selected_objects if activeObj != obj]


		# ダイナミックペイント設定
		dp_group = activeObj.vertex_groups.new(name="dp_group")
		dyna_mod = activeObj.modifiers.new("overlap_brush","DYNAMIC_PAINT")
		bpy.ops.dpaint.type_toggle(type='CANVAS')
		dyna_mod.canvas_settings.canvas_surfaces[-1].surface_type = 'WEIGHT'
		dyna_mod.canvas_settings.canvas_surfaces[-1].output_name_a = dp_group.name


		# その他の選択オブジェクトにブラシを設定
		for obj in brushObjs:
			bpy.context.view_layer.objects.active = obj
			dyna_mod = obj.modifiers.new("overlap_brush","DYNAMIC_PAINT")
			dyna_mod.ui_type = 'BRUSH'
			bpy.ops.dpaint.type_toggle(type='BRUSH')
			dyna_mod.brush_settings.paint_source = 'VOLUME_DISTANCE'
			dyna_mod.brush_settings.paint_distance = self.distance
			# self.report({'INFO'}, "other " + obj.name)

		bpy.context.view_layer.objects.active = activeObj

		if self.apply:
			bpy.ops.object.modifier_apply(modifier=dyna_mod.name)

		# 頂点グループに割り当て
		if not self.new_vertex_group:
			me = activeObj.data
			for vert in me.vertices:
				for vg in vert.groups:
					print(activeObj.vertex_groups[vg.group].name)
					if activeObj.vertex_groups[vg.group].name == dp_group.name:
						act_vg.add([vert.index], vg.weight * self.strength, self.mix_mode)
			activeObj.vertex_groups.remove(dp_group)
			activeObj.vertex_groups.active_index = act_vg.index

		if self.apply:
			for mod in activeObj.modifiers:
				if mod.name == "overlap_brush":
					activeObj.modifiers.remove(mod)


		#その他オブジェクトのブラシモディファイアを削除
		for obj in brushObjs:
			if self.wireframe_other_object:
				obj.display_type = 'WIRE'

			if self.apply:
				for mod in obj.modifiers:
					if mod.name == "overlap_brush":
						obj.modifiers.remove(mod)


		if old_mode == "EDIT":
			bpy.ops.object.mode_set(mode=old_mode)
		return {'FINISHED'}
