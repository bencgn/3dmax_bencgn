import bpy
from bpy.types import Operator
from bpy.props import *


class LAZYWEIGHT_OT_table_add_v_weight(Operator):
	bl_idname = "lazyweight.add_v_weight"
	bl_label = "Add Weight to Vertex"
	bl_description = "Add Weight to Vertex"
	bl_options = {'REGISTER', 'UNDO'}

	weight : FloatProperty(default=1.0, name = "Value",min=0,max=1.0)
	index : IntProperty(name="Index",min=0)
	group : IntProperty(name="Index",min=0)

	items = [
	("Deform Pose Bone", "Deform Pose Bone","Deform Bone Only\nBone must be selected", "BONE_DATA",1),
	("Selected Pose Bone", "Selected Pose Bone","Select Bone\nBone must be selected", "MOD_SIMPLEDEFORM",2),
	("All", "All","All", "RNA_ADD",3),
	("Active", "Active","Active", "RNA",4),
	("None", "None","None", "RADIOBUT_OFF",5),
		]
	normalize : EnumProperty(default="Deform Pose Bone",items=items, name="Normalize")
	normalize_lock_active : BoolProperty(default=False,name="Lock Active")
	items = [
		("REPLACE", "Replace", "", 1),
		("ADD", "Add", "", 2),
		("SUBTRACT", "Subtract", "", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Type")

	def execute(self, context):
		obj = bpy.context.object
		v_name = bpy.context.object.vertex_groups[self.group]
		vlist = obj.data.vertices[self.index]

		v_name.add(index=(self.index,self.index),weight=self.weight,type=self.type)

		return {'FINISHED'}


class LAZYWEIGHT_OT_table_remove_v_weight(Operator):
	bl_idname = "lazyweight.remove_v_weight"
	bl_label = "Remove Weight to Vertex"
	bl_description = "Remove Weight to Vertex"
	bl_options = {'REGISTER', 'UNDO'}

	weight : FloatProperty(default=0, name = "Value",min=0,max=1.0)
	index : IntProperty(name="Index",min=0)
	group : IntProperty(name="Index",min=0)

	items = [
	("Deform Pose Bone", "Deform Pose Bone","Deform Bone Only\nBone must be selected", "BONE_DATA",1),
	("Selected Pose Bone", "Selected Pose Bone","Select Bone\nBone must be selected", "MOD_SIMPLEDEFORM",2),
	("All", "All","All", "RNA_ADD",3),
	("Active", "Active","Active", "RNA",4),
	("None", "None","None", "RADIOBUT_OFF",5),
		]
	normalize : EnumProperty(default="Deform Pose Bone",items=items, name="Normalize")
	normalize_lock_active : BoolProperty(default=False,name="Lock Active")
	items = [
		("REPLACE", "Replace", "", 1),
		("ADD", "Add", "", 2),
		("SUBTRACT", "Subtract", "", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Type")

	def execute(self, context):
		obj = bpy.context.object
		v_name = bpy.context.object.vertex_groups[self.group]
		vlist = obj.data.vertices[self.index]
		v_name.remove((self.index,self.index))

		return {'FINISHED'}
