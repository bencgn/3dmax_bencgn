import bpy
from bpy.types import Operator
from bpy.props import *


class LAZYWEIGHT_OT_weight_brush_set(Operator):
	bl_idname = "lazyweight.weight_brush_set"
	bl_label = "Set Weight to Brush"
	bl_description = "Set the value to the brush weight"
	bl_options = {'REGISTER', 'UNDO'}

	weight : FloatProperty(default=0, name = "Value",min=0,max=1.0)

	def execute(self, context):
		bpy.context.scene.tool_settings.unified_paint_settings.weight = self.weight

		return {'FINISHED'}


class LAZYWEIGHT_OT_weight_brush_add(Operator):
	bl_idname = "lazyweight.weight_brush_add"
	bl_label = "Weight Brush Add"
	bl_description = "Switch tool to Weight Brush 'Add'"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.tool_settings.weight_paint.brush = bpy.data.brushes["Add"]
		return {'FINISHED'}


class LAZYWEIGHT_OT_weight_brush_mix(Operator):
	bl_idname = "lazyweight.weight_brush_mix"
	bl_label = "Weight Brush Mix"
	bl_description = "Switch tool to Weight Brush 'Mix'"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.tool_settings.weight_paint.brush = bpy.data.brushes["Mix"]
		return {'FINISHED'}


class LAZYWEIGHT_OT_weight_brush_sub(Operator):
	bl_idname = "lazyweight.weight_brush_sub"
	bl_label = "Weight Brush SUB"
	bl_description = "Switch tool to Weight Brush 'SUB'"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.tool_settings.weight_paint.brush = bpy.data.brushes["Subtract"]
		return {'FINISHED'}
