
class LAZYWEIGHT_OT_new_weight_set(Operator):
	bl_idname = "lazyweight.new_weight_set"
	bl_label = "new_weight_set"
	bl_options = {'REGISTER', 'UNDO'}

	weight : FloatProperty(default=0, name = "Value",min=0,max=1.0)

	items = [
	("Deform Pose Bone", "Deform Pose Bone","Deform Bone Only\nBone must be selected", "BONE_DATA",1),
	("Selected Pose Bone", "Selected Pose Bone","Select Bone\nBone must be selected", "MOD_SIMPLEDEFORM",2),
	("All", "All","All", "RNA_ADD",3),
	("Active", "Active","Active", "RNA",4),
	("None", "None","None", "RADIOBUT_OFF",5),
		]

	normalize : EnumProperty(default="Deform Pose Bone",items=items, name="Normalize")
	normalize_lock_active : BoolProperty(default=False,name="Lock Active")

	items = [
		("REPLACE", "Replace","'Replace' existing weights", "IMPORT", 1),
		("ADD", "Add","'Add' existing weights", "ADD", 2),
		("SUBTRACT", "Subtract","'Subtract' existing weights", "REMOVE", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Mix Mode")
	threshold : FloatProperty(name="Mirror Threshold", default=0.0001, step=0.1, precision=10,max=0.1)

	use_symmetry_x : BoolProperty(name="X")
	use_symmetry_y : BoolProperty(name="Y")
	use_symmetry_z : BoolProperty(name="Z")

	items = [
		("NONE","None","","RADIOBUT_OFF",0),
		("ACTIVE","Active Vertex Group","","DOT",1),
		("ALL","All Vertex Groups","","SNAP_VERTEX",2),
		]
	set_weight_clean_mode : EnumProperty(default="ACTIVE",items=items, name="Clean")
	set_weight_clean_limit : FloatProperty(name="Limit",min=0,max=0.99)
	set_weight_clean_keep_single : BoolProperty(name="Keep Single")

	def draw(self, context):
		layout = self.layout
		layout.prop(self,"weight")
		layout.separator()

		row = layout.row(align=True)
		row.prop(self,"type",expand=True)
		row = layout.row(align=True)
		layout.separator()

		row = layout.row(align=True)
		row.prop(self,"use_symmetry_x",toggle=True)
		row.prop(self,"use_symmetry_y",toggle=True)
		row.prop(self,"use_symmetry_z",toggle=True)
		layout.prop(self,"threshold")
		layout.separator()

		row = layout.row(align=True)
		row.prop(self,"normalize",expand=True)
		if self.normalize in {"All", "Deform Pose Bone", "Selected Pose Bone"}:
			row = layout.row(align=True)
			row.prop(self,"normalize_lock_active",expand=True)
		else:
			row = layout.row(align=True)
			row.label(text="")



	def invoke(self, context,event):
		wpaint = bpy.context.scene.tool_settings.weight_paint
		props = bpy.context.scene.lazyweight

		self.type = props.type
		self.normalize = props.normalize

		symmetry_x, symmetry_y, symmetry_z = get_symmetry_option(obj)

		self.use_symmetry_x = symmetry_x
		self.use_symmetry_y = symmetry_y
		self.use_symmetry_z = symmetry_z

		self.set_weight_clean_mode = props.set_weight_clean_mode
		self.set_weight_clean_limit = props.set_weight_clean_limit
		self.set_weight_clean_keep_single = props.set_weight_clean_keep_single

		return self.execute(context)


	def execute(self, context):
		props = bpy.context.scene.lazyweight
		obj = bpy.context.object
		me = obj.data
		if not obj.vertex_groups:
			obj.vertex_groups.new()
			self.report({'INFO'}, "Add Vertex Group")

		vg_count = len(obj.vertex_groups)

		actInd = obj.vertex_groups.active_index # アクティブな頂点グループ
		wpaint = bpy.context.scene.tool_settings.weight_paint

		if bpy.context.mode == "EDIT_MESH":
			bm = bmesh.from_edit_mesh(obj.data)
		else:
			bm = bmesh.new()
			bm.from_mesh(obj.data)

		wlay = bm.verts.layers.deform.verify() # データレイヤーを確認して、なければ作成

		# 選択頂点
		verts_all = [vert for vert in bm.verts]
		verts = [vert for vert in bm.verts if vert.select]
		old_vsel = verts

		###################################################
		# ミラーがある場合、反対側の頂点を探して、対象頂点リストに追加する
		if self.use_symmetry_x or self.use_symmetry_y or self.use_symmetry_z:

			co_l = []
			axis_list = []
			if self.use_symmetry_x:
				co_x = [(vert.co.x *-1, vert.co.y,vert.co.z) for vert in verts]
				co_l += co_x

				# 反対位置に近い頂点を取得する
				axis_list = [vert for vert in verts_all if not vert.select and vert.hide == False for co in co_l if (vert.co - Vector(co)).length < self.threshold]
				# axis_list = [vert for vert in verts_all if not vert.select and vert.hide == False for x,y,z in co_l if math.isclose(vert.co.x, x, rel_tol=self.threshold) and math.isclose(vert.co.y, y, rel_tol=self.threshold) and math.isclose(vert.co.z, z, rel_tol=self.threshold)]

				for v in axis_list:
					v.select = True
				verts = axis_list + verts

			if self.use_symmetry_y:
				co_y = [(vert.co.x, vert.co.y *-1,vert.co.z) for vert in verts]
				co_l += co_y

				# 反対位置に近い頂点を取得する
				axis_list = [vert for vert in verts_all if not vert.select and vert.hide == False for co in co_l if (vert.co - Vector(co)).length < self.threshold]

				for v in axis_list:
					v.select = True
				verts = axis_list + verts

			if self.use_symmetry_z:
				co_z = [(vert.co.x, vert.co.y,vert.co.z *-1) for vert in verts]
				co_l += co_z

				# 反対位置に近い頂点を取得する
				axis_list = [vert for vert in verts_all if not vert.select and vert.hide == False for co in co_l if (vert.co - Vector(co)).length < self.threshold]

				for v in axis_list:
					v.select = True
				verts = axis_list + verts

			verts = [vert for vert in bm.verts if vert.select]


		###################################################
		# 実行
		if not bpy.context.mode == "EDIT_MESH":
			# 0 なら頂点を頂点グループから削除
			if self.weight == 0:
				bpy.ops.object.vertex_group_remove_from()

			else:
				self.set_v_weight(bm,verts, self.weight,actInd,wlay,True)
			bm.to_mesh(me)

		else: # 編集モードなら
			# 0 なら頂点を頂点グループから削除
			if self.weight == 0:
				bpy.ops.object.vertex_group_remove_from()

			else:
				if len(verts) == 1:
					self.set_v_weight(bm,verts[0],self.weight,actInd,wlay,False)

				else:
					self.set_v_weight(bm,verts,self.weight,actInd,wlay,True)


		# 自家製 正規化
		# deform = bm.verts.layers.deform.active
		# cunt = 0
		# all_gweight = 0
		# for v in verts:
		# 	# all_gweight = 0
		# 	g = v[deform]
		# 	for i in range(vg_count):
		# 		all_gweight += g[cunt]
		# 		# g[cunt] = 0.5
		# 		cunt += 1

		if self.normalize == "Active":
			bpy.ops.object.vertex_weight_normalize_active_vertex()
		elif self.normalize == "All":
			bpy.ops.object.vertex_group_normalize_all(group_select_mode="ALL",lock_active=self.normalize_lock_active)

		elif self.normalize == "Deform Pose Bone":
			try:
				bpy.ops.object.vertex_group_normalize_all(group_select_mode="BONE_DEFORM",lock_active=self.normalize_lock_active)
			except:
				self.report({'INFO'}, "Normalize 'Deform Pose Bone' Optin failed. Pose Bone must be selected.")
		elif self.normalize == "Selected Pose Bone":
			try:
				bpy.ops.object.vertex_group_normalize_all(group_select_mode="BONE_SELECT",lock_active=self.normalize_lock_active)
			except:
				self.report({'INFO'}, "Normalize 'Selected Pose Bone' Optin failed. Pose Bone must be selected.")

		# 選択を戻す
		if self.use_symmetry_x or self.use_symmetry_y or self.use_symmetry_z:
			for v in verts_all:
				v.select = False
			for v in old_vsel:
				v.select = True



		me.update()

		return{'FINISHED'}



	def set_v_weight(self,bm,verts,weight,actInd,wlay,multiple):
		props = bpy.context.scene.lazyweight

		if multiple:
			for v in verts:
				if self.type =="ADD":
					v[wlay][actInd] += weight
				elif self.type =="SUBTRACT":
					# if (v[wlay][actInd] - weight) < 0:
					# 	v[wlay][actInd] == 0
					# else:
					v[wlay][actInd] -= weight

				elif self.type =="REPLACE":
					v[wlay][actInd] = weight
		else:
			verts[wlay][actInd] = weight
