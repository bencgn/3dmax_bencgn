import bpy, bmesh, ast,time, json
from bpy.types import Operator
from mathutils import Vector, kdtree
import numpy as np
from bpy.props import *

from bpy_extras.io_utils import (
		ImportHelper,
		ExportHelper
		)

# コピー
class LAZYWEIGHT_OT_copy_weight(Operator):
	bl_idname = "lazyweight.copy_weight"
	bl_label = "Copy Weight"
	bl_description = "Saves the weight of the selected vertex and the data of the vertex position to the clipboard"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		obj = bpy.context.object
		if obj and obj.type in {"MESH"}:
			if obj.vertex_groups:
				return True

	def execute(self, context):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype

		obj = bpy.context.object
		old_mode = obj.mode
		info_text = "Copy Weight"

		# オブジェクトモードにする
		if old_mode == "WEIGHT_PAINT":
			sel_vert_l = [v for v in obj.data.vertices if v.select]
			# モードを戻す
			if not sel_vert_l:
				bpy.ops.object.mode_set(mode=old_mode)

				self.report({'WARNING'}, "No Selected Vertex")
				return {'CANCELLED'}

		elif old_mode == "EDIT":
			bpy.ops.object.mode_set(mode="OBJECT")
			sel_vert_l = [v for v in obj.data.vertices if v.select]
			# モードを戻す
			if not sel_vert_l:
				bpy.ops.object.mode_set(mode=old_mode)
				self.report({'WARNING'}, "No Selected Vertex")
				return {'CANCELLED'}

		else:
			bpy.ops.object.mode_set(mode="OBJECT")
			sel_vert_l = obj.data.vertices
			info_text = "Copy All Vertex Weight"

		v_count = 0
		all_dic = {}
		weight_dic = {}
		for vert in sel_vert_l: # 頂点
			if len(vert.groups):
				one_vert_dic = {}
				gp_dic = {}
				for g in vert.groups: # 「頂点の」グループ
					try:
						gp_dic[obj.vertex_groups[g.group].name] = g.weight
					except IndexError as e: print(e)

				one_vert_dic["co"] = obj.matrix_world @ vert.co # グローバル位置で保存
				one_vert_dic["local_co"] =  vert.co # ローカル位置で保存
				# one_vert_dic["local_co"] = obj.matrix_world.inverted() @ vert.co # ローカル位置で保存
				one_vert_dic["vg_weight"] = gp_dic # 各頂点グループがまとまった頂点のウェイトを保存
				weight_dic[vert.index] = one_vert_dic
				v_count += 1

		all_dic["weight_dic"] = weight_dic
		all_dic["vg_names"] = [i.name for i in obj.vertex_groups]
		all_dic["actvg_names"] = obj.vertex_groups.active.name

		# print(weight_dic)
		# {頂点インデックス：グローバル座標位置、ローカル座標位置、頂点グループごとのウェイト、}
		# {368: {'co': Vector((-1.0751234292984009, 0.1171875, 0.6171875))}}
		props_cy.clipboard = str(all_dic)


		# モードを戻す
		if not obj.mode == old_mode:
			bpy.ops.object.mode_set(mode=old_mode)

		self.report({'INFO'}, "%s [%s]" % (info_text,str(v_count)))

		return {'FINISHED'}


# 書き出し
class LAZYWEIGHT_OT_clipboard_export(Operator, ExportHelper):
	bl_idname = "lazyweight.clipboard_export"
	bl_label = "Export the clipboard to a file"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	filename_ext = ".json"
	filter_glob : StringProperty( default="*.json", options={'HIDDEN'}, )

	@classmethod
	def poll(cls, context):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype

		return bool(
		bpy.context.object
		and props_cy.clipboard
		)


	def execute(self, context):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype


		with open (self.filepath, "w") as file:
			file.write(props_cy.clipboard)


		self.report({'INFO'}, 'Exported [%s]' % self.filepath)

		return{'FINISHED'}


# ペースト
class LAZYWEIGHT_OT_paste_weight(Operator, ImportHelper):
	bl_idname = "lazyweight.paste_weight"
	bl_label = "Paste Weight"
	bl_description = "Paste the clipboard weight data to the selected vertices"
	bl_options = {'REGISTER', 'UNDO'}

	items = [
	("SINGLE","Single","Paste single vertex weights","RADIOBUT_ON",0),
	("ORIENTATION_LOCAL","Local","Paste weights for close vertices relative to the object's local coordinates.\nYou can paste exactly for meshes with the same vertex position relative to the origin","ORIENTATION_LOCAL",1),
	("ORIENTATION_GLOBAL","Global","Paste weights for close vertices relative to global coordinates.\nYou can paste exactly for close meshes regardless of the origin of the object","ORIENTATION_GLOBAL",2),
	("INDEX","Index","Paste weights for vertices with the same vertex index","IPO_SINE",3),
	]
	mode : EnumProperty(default="ORIENTATION_LOCAL",name = "Mode", items= items)
	items = [
		("REPLACE", "Replace","'Replace' existing weights", "IMPORT", 1),
		("ADD", "Add","'Add' existing weights", "ADD", 2),
		("SUBTRACT", "Subtract","'Subtract' existing weights", "REMOVE", 3),
		]
	mix_mode : EnumProperty(default="REPLACE",items=items, name="Blend Mode",description="Blend mode for existing weights")
	distance : FloatProperty(name="Distance",description="How close vertices are near",min=0,default=0.1,step=0.1,precision=3,subtype="DISTANCE")
	# all_vertex_groups : BoolProperty(name="All Vertex Groups",default=True)
	weight_strength : FloatProperty(name="Strength",description="Adjust the value of the weight to be pasted. This value will be multiplied",min=0,default=1,step=0.1,precision=3,soft_max=1)
	add_blank_bg : BoolProperty(name="Generate Data Layers",default=True,description="If there is no destination vertex group, a new one will be created")
	find_type : EnumProperty(default="find",name = "Find Type", items= [ ("find","One Point","Find nearest one point"), ("find_range","Range","Find all points within radius.\nThis is useful when there are multiple vertices at overlapping positions") ])

	items = [
	("CLIPBOARD","Clipboard",""),
	("FILE","File",""),
	]
	source_type : EnumProperty(default="CLIPBOARD",name = "Source Type", items= items)

	filename_ext = ".json"
	filter_glob : StringProperty( default="*.json", options={'HIDDEN'}, )
	# only_active_vg : BoolProperty(name="Only Active Vertex Groups")
	items = [
	("ALL","All VG","Paste weights to all VGs with the same name"),
	("SAME_ACTIVE","Same name 1VG","Paste weights only to VGs with the same name as the active VG when copied"),
	("ONLY_ACTIVE","Only Active 1VG","Paste the copied active VG weights into the current active VG"),
	]
	target_type : EnumProperty(default="ALL",name="Target Type",items= items)


	@classmethod
	def poll(cls, context):
		return bpy.context.object and bpy.context.object.type == "MESH"


	def draw(self, context):
		layout = self.layout

		row = layout.row(align=True)
		row.prop(self,"target_type",expand=True)

		col = layout.column()
		col.prop(self,"add_blank_bg")

		layout.separator()

		row = layout.row(align=True)
		row.prop(self,"mode",expand=True)

		row = layout.row(align=True)
		row.prop(self,"mix_mode",expand=True)

		col = layout.column(align=True)
		col.use_property_split = True
		col.use_property_decorate = False
		col.prop(self,"weight_strength")

		layout.separator()
		row = layout.row(align=True)
		row.active = bool(self.mode in {"ORIENTATION_LOCAL","ORIENTATION_GLOBAL"})
		row.label(text="Find Type")
		row.prop(self,"find_type",expand=True)

		col = layout.column(align=True)
		col.use_property_split = True
		col.use_property_decorate = False
		col.active = bool(self.mode in {"ORIENTATION_LOCAL","ORIENTATION_GLOBAL"})
		col.prop(self,"distance")


	def invoke(self, context,event):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype
		self.mix_mode = props_cy.mix_mode
		self.mode = props_cy.mode
		self.distance = props_cy.distance
		self.add_blank_bg = props_cy.add_blank_bg
		self.finished_v_l = []


		# オブジェクトモードにする
		obj = bpy.context.object
		self.old_mode = obj.mode
		if not self.old_mode == "WEIGHT_PAINT":
			bpy.ops.object.mode_set(mode="OBJECT")

		obj = bpy.context.object
		self.sel_vert_l = [v for v in obj.data.vertices if v.select]
		if not self.sel_vert_l:
			# モードを戻す
			if not obj.mode == self.old_mode:
				bpy.ops.object.mode_set(mode=self.old_mode)

			self.report({'WARNING'}, "No Selected Mesh")
			return {'CANCELLED'}


		# kdtree を登録
		self.kd_dic = {}
		old_act = bpy.context.view_layer.objects.active

		for obj in bpy.context.selected_objects:
			if not obj.type == "MESH":
				continue

			bpy.context.view_layer.objects.active = obj
			obj_dic = {}
			bm_v = obj.data.vertices
			size = len(bm_v)

			kd_local = kdtree.KDTree(size)
			for i, v in enumerate(bm_v):
				kd_local.insert(v.co, i)
			kd_local.balance()

			kd_global = kdtree.KDTree(size)
			for i, v in enumerate(bm_v):
				kd_global.insert(obj.matrix_world @ v.co, i)
			kd_global.balance()

			obj_dic["kd_global"] = kd_global
			obj_dic["kd_local"] = kd_local
			self.kd_dic[obj.name] = obj_dic

		bpy.context.view_layer.objects.active = old_act


		if self.source_type == "CLIPBOARD":
			return self.execute(context)
		elif self.source_type == "FILE":
			context.window_manager.fileselect_add(self)
			return {'RUNNING_MODAL'}


	def execute(self, context):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype
		old_act = bpy.context.view_layer.objects.active
		# start = time.time()


		if self.source_type == "CLIPBOARD":
			if not props_cy.clipboard:
				self.report({'WARNING'}, "No Clipboard !")
				return{'FINISHED'}
			self.clipb_l = eval(props_cy.clipboard)
			# self.clipb_l = ast.literal_eval(props_cy.clipboard)
		elif self.source_type == "FILE":
			with open (self.filepath, "r") as file:
				file = file.read()
				# data_file = json.load(file)
				self.clipb_l = eval(file)
				# self.clipb_l = ast.literal_eval(str(file))


		if not self.old_mode == "WEIGHT_PAINT":
			bpy.ops.object.mode_set(mode="OBJECT")

		for obj in bpy.context.selected_objects:
			if not obj.type == "MESH":
				continue
			bpy.context.view_layer.objects.active = obj
			# 頂点グループがなければ新規作成
			self.create_blank_vg(obj)


			self.sel_vert_l = [v.index for v in obj.data.vertices if v.select]

			# クリップボードを展開
			# {151: {'vg_weight': {'hoge': 0.0027364674024283886}, 'co': Vector((-1.1298109292984009, -0.65625, 0.375))}}
			for vert_index in self.clipb_l["weight_dic"].keys(): # 頂点番号
				self.paste_weight_to_vertex(obj,vert_index)


		# モードを戻す
		bpy.context.view_layer.objects.active = old_act
		if not obj.mode == self.old_mode:
			bpy.ops.object.mode_set(mode=self.old_mode)

		props_cy.mix_mode = self.mix_mode
		props_cy.mode = self.mode
		props_cy.distance = self.distance

		# print("time : %s seond" % round(time.time() - start,2))

		self.report({'INFO'}, "Paste Weight [%s]" % str(len(self.finished_v_l)))
		return {'FINISHED'}


	# 空頂点グループを生成
	def create_blank_vg(self,obj):
		# 全てを作る
		old_act_name = None
		if obj.vertex_groups:
			old_act_name = obj.vertex_groups.active

		if self.add_blank_bg:
			use_vg_name_l = [
				vg_name for vert_index in self.clipb_l["weight_dic"].keys()
				for vg_name in self.clipb_l["weight_dic"][vert_index]["vg_weight"].keys() # 頂点グループ
			]
			use_vg_name_l = sorted(set(use_vg_name_l), key=use_vg_name_l.index)

			for vg_name in use_vg_name_l:
				if vg_name not in obj.vertex_groups.keys():
					obj.vertex_groups.new(name=vg_name)

		else: # 頂点グループが1つもない場合は作る
			if not obj.vertex_groups:
				vg_name = self.clipb_l["actvg_names"]
				if vg_name not in obj.vertex_groups.keys():
					obj.vertex_groups.new(name=vg_name)

		if old_act_name:
			obj.vertex_groups.active = old_act_name



	# 貼り付けを実行
	def paste_weight_to_vertex(self,obj,vert_index):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype

		# シングルのインデックスの場合
		if self.mode in {"SINGLE" , "INDEX"}:
			for vg_name in self.clipb_l["weight_dic"][vert_index]["vg_weight"].keys(): # 頂点グループ
				if not self.target_type in {"ONLY_ACTIVE"}:
					if not vg_name == self.clipb_l["actvg_names"]:
						continue

				if not vg_name in obj.vertex_groups:
					continue
				tgt_vg = obj.vertex_groups[vg_name]
				if tgt_vg.lock_weight:
					continue

				# 全て同じ値で割り当て
				if self.mode == "SINGLE":
					if self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name]:
						tgt_vg.add(index=self.sel_vert_l,weight=self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name],type=props_cy.mix_mode)
						self.finished_v_l.append(1)


				# 頂点インデックス1つずつに割り当て
				elif self.mode == "INDEX":
					if vert_index in self.sel_vert_l:
						if self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name]:
							tgt_vg.add(index=[vert_index],weight=self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name],type=props_cy.mix_mode)
							self.finished_v_l.append(vert_index)


		# ローカル・グローバルの場合
		elif self.mode in {"ORIENTATION_LOCAL","ORIENTATION_GLOBAL"}:
			vert_global_co = self.clipb_l["weight_dic"][vert_index]["co"]
			vert_local_co = self.clipb_l["weight_dic"][vert_index]["local_co"]

			tgt_index = self.find_nearest_co(obj,vert_global_co,vert_local_co)

			if not tgt_index:
				return

			# ウェイト割り当て
			for vg_name in self.clipb_l["weight_dic"][vert_index]["vg_weight"].keys(): # 頂点グループ
				if self.target_type in {"ONLY_ACTIVE"}:
					old_act_vg_name = self.clipb_l["actvg_names"]
					for vg_name in self.clipb_l["weight_dic"][vert_index]["vg_weight"].keys(): # 頂点グループ
						if vg_name == old_act_vg_name:
							tgt_vg = obj.vertex_groups.active

							# ウェイト割り当て
							tgt_vg.add(
							index=tgt_index,
							weight=self.clipb_l["weight_dic"][vert_index]["vg_weight"][old_act_vg_name] * self.weight_strength,
							type=props_cy.mix_mode
							)
				else:
					if not self.target_type in {"ALL","ONLY_ACTIVE"}:
						if not vg_name == self.clipb_l["actvg_names"]:
							continue

					if self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name]:
						if not vg_name in obj.vertex_groups:
							continue
						tgt_vg = obj.vertex_groups[vg_name]
						if tgt_vg.lock_weight:
							continue

						# ウェイト割り当て
						tgt_vg.add(
						index=tgt_index,
						weight=self.clipb_l["weight_dic"][vert_index]["vg_weight"][vg_name] * self.weight_strength,
						type=props_cy.mix_mode
						)

			self.finished_v_l += [tgt_index]


	# 近い位置を検索
	def find_nearest_co(self,obj,clip_global_co,clip_local_co):
		props = bpy.context.scene.lazyweight
		props_cy = props.copype


		v_index_list = []
		# グローバル
		if self.mode == "ORIENTATION_GLOBAL":
			if self.find_type == "find_range":
				rt_l = self.kd_dic[obj.name]["kd_global"].find_range(clip_global_co,self.distance)
			elif self.find_type == "find":
				rt_l = self.kd_dic[obj.name]["kd_global"].find(clip_global_co)
				rt_l = [rt_l]

		# ローカル
		elif self.mode == "ORIENTATION_LOCAL":
			# co, index, dist = self.kd_local.find(props_cy.base_object.matrix_world.inverted() @ clip_co)
			if self.find_type == "find_range":
				rt_l = self.kd_dic[obj.name]["kd_local"].find_range(clip_local_co,self.distance)
			elif self.find_type == "find":
				rt_l = self.kd_dic[obj.name]["kd_local"].find(clip_local_co)
				rt_l = [rt_l]

		index_l = [
		index for co, index, dist in rt_l
		if obj.data.vertices[index].select
		if dist <= self.distance
		]
		return index_l

		return None
