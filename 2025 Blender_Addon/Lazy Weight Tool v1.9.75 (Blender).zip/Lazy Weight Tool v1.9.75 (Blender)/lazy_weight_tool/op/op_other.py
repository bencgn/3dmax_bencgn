import bpy, bmesh, re
import numpy as np
from math import sqrt
from mathutils import Vector
from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN

from bpy.types import Operator
from bpy.props import *


class LAZYWEIGHT_OT_vertex_groups_set_actvg_of_selobjs(Operator):
	bl_idname = "lazyweight.vertex_groups_set_actvg_of_selobjs"
	bl_label = "Switch the Active VG of the SelObjs to the Same"
	bl_description = "Set the active vertex group of the selected object the same name as the active vertex group of the active object.\nIt works if you have a vertex group with the same name"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		return len(bpy.context.selected_objects) >= 2

	def execute(self, context):

		finish_obj_l = set_actvg_of_selobjs()

		self.report({'INFO'}, "Finish %s" % len(finish_obj_l))
		return {'FINISHED'}


class LAZYWEIGHT_OT_mesh_deselect_active_vertex(Operator):
	bl_idname = "lazyweight.mesh_deselect_active_vertex"
	bl_label = "Allow editing by mouse dragging"
	bl_description = "Solves the problem that since Blender 3.6, you cannot edit values by mouse dragging if there is an active vertex. \ɑn (makes it so that there are no active vertices)\nIncidentally, box and circle selections can be used to make selections without generating active vertices"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		return bpy.context.object

	def execute(self, context):
		obj = bpy.context.object
		v_all = obj.data.vertices
		# 選択を保存
		np_old_sel = np.zeros(len(v_all), dtype=np.bool)
		v_all.foreach_get('select', np_old_sel)

		# 選択解除
		# np_desel_l = [False] * len(v_all)
		# v_all.foreach_set('select', np_desel_l)
		if obj.mode =="EDIT":
			bpy.ops.mesh.select_all(action="DESELECT")
		else:
			bpy.ops.paint.vert_select_all(action="DESELECT")

		# 選択を戻す
		v_all.foreach_set('select', np_old_sel)

		obj.data.update_tag()
		return {'FINISHED'}


def set_actvg_of_selobjs():
	src_obj = bpy.context.view_layer.objects.active
	finish_obj_l = []
	if not src_obj.mode == "EDIT":
		return finish_obj_l

	actvg_name = src_obj.vertex_groups.active.name
	for tgt_obj in bpy.context.selected_objects:
		bpy.context.view_layer.objects.active = tgt_obj

		if not tgt_obj.vertex_groups:
			continue

		if actvg_name in tgt_obj.vertex_groups:
			tgt_obj.vertex_groups.active = tgt_obj.vertex_groups[actvg_name]

		finish_obj_l.append(tgt_obj)

	bpy.context.view_layer.objects.active = src_obj
	return finish_obj_l


class LAZYWEIGHT_OT_vertex_groups_generate_blank_vg(Operator):
	bl_idname = "lazyweight.vertex_groups_generate_blank_vg"
	bl_label = "Generate Blank Vertex Groups"
	bl_description = "Generates a vertex group that the selected object does not have compared to the vertex group of the active object"
	bl_options = {'REGISTER', 'UNDO'}

	only_active_vertex_group : BoolProperty(name="Only Active Vertex Group")

	@classmethod
	def poll(cls, context):
		return len(bpy.context.selected_objects) >= 2

	def execute(self, context):
		src_obj = bpy.context.view_layer.objects.active

		finish_obj_l = []
		for tgt_obj in bpy.context.selected_objects:
			if tgt_obj == src_obj:
				continue
			bpy.context.view_layer.objects.active = tgt_obj

			# add blank cg:
			is_already_vg = False
			if tgt_obj.vertex_groups:
				is_already_vg = True

			for vg in src_obj.vertex_groups:
				if is_already_vg: # 既存VGがある場合は名前がかぶらないようにする
					if not vg.name in tgt_obj.vertex_groups:
						if self.only_active_vertex_group:
							if not vg.name == tgt_obj.vertex_groups.active.name:
								continue
						tgt_obj.vertex_groups.new(name=vg.name)

				else:
					if self.only_active_vertex_group:
						if not vg.name == tgt_obj.vertex_groups.active.name:
							continue
					tgt_obj.vertex_groups.new(name=vg.name)

			finish_obj_l.append(tgt_obj)


		bpy.context.view_layer.objects.active = src_obj
		self.report({'INFO'}, "Finish %s" % len(finish_obj_l))

		return {'FINISHED'}


class LAZYWEIGHT_OT_remove_0_vertex(Operator):
	bl_idname = "lazyweight.remove_0_vertex"
	bl_label = "Remove 0.0"
	bl_description = "Remove 0.0 Weight vertex in Vertex Group"
	bl_options = {'REGISTER', 'UNDO'}

	all : BoolProperty(name="All")

	def execute(self, context):
		obj = bpy.context.object
		vlist = []
		if self.all:
			for vgroup in obj.vertex_groups:
				for v in obj.data.vertices:
					for g in v.groups: # 頂点のグループ
						if g.group == vgroup.index: # 頂点グループ
							if g.weight == 0:
								vlist.append(v.index)

				obj.vertex_groups[vgroup.name].remove(index=vlist)
		else:

			act_v = obj.vertex_groups[obj.vertex_groups.active.name]
			for v in obj.data.vertices:
				for g in v.groups: # 頂点のグループ
					if g.group == act_v.index: # 頂点グループ
						if g.weight == 0:
							vlist.append(v.index)

			act_v.remove(index=vlist)


		return {'FINISHED'}


class LAZYWEIGHT_OT_table_other(Operator):
	bl_idname = "lazyweight.table_other"
	bl_label = "Highlight Option"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	def invoke(self, context, event):
		dpi_value = bpy.context.preferences.system.dpi
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		return context.window_manager.invoke_popup(self)

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		row = layout.row(align=True)
		row.prop(props,"table_highlight_type",expand=True)
		layout.prop(props,"table_highlight_hitrange",text="Hit Range")
		layout.prop(props,"table_highlight_emboss")

	def execute(self, context):
		return {'FINISHED'}


class LAZYWEIGHT_OT_set_weight_other(Operator):
	bl_idname = "lazyweight.set_weight_other"
	bl_label = "Option"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	def invoke(self, context, event):
		dpi_value = bpy.context.preferences.system.dpi
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		return context.window_manager.invoke_popup(self)

	def draw(self, context):
		props = bpy.context.scene.lazyweight
		set_weight_option_menu(self,context,props,False)

	def execute(self, context):
		return {'FINISHED'}


class LAZYWEIGHT_OT_auto_weight_only_select(Operator):
	bl_idname = "lazyweight.auto_weight_only_select"
	bl_label = "Auto Weight (Only Select)"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	def invoke(self, context, event):
		dpi_value = bpy.context.preferences.system.dpi
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		return context.window_manager.invoke_popup(self)

	def draw(self, context):
		props = bpy.context.scene.lazyweight
		set_weight_option_menu(self,context,props,False)

	def execute(self, context):
		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_batch_rename(Operator):
	bl_idname = "lazyweight.vgroup_batch_rename"
	bl_label = "Batch Rename of Vertex Group"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	replace_src : StringProperty(name="Replace Text",default="")
	replace_dst : StringProperty(name="Target Text",default="")
	items = [
	("REPLACE","Replace","","FILE_REFRESH",0),
	("FIRST","First","","FRAME_NEXT",1),
	("END","End","","FRAME_PREV",2),
	]
	rename_type : EnumProperty(default="REPLACE",name = "Type", items=items)
	items = [
	("vertex_groups","Vertex Groups","","GROUP_VERTEX",0),
	("uv_layers","UV Maps","","GROUP_UVS",1),
	("vertex_colors","Vertex Colors","","GROUP_VCOL",2),
	("face_maps","Face Maps","","FACE_MAPS",3),
	("shape_keys","Shape Keys","","SHAPEKEY_DATA",4),
	("gpencil_layers","GPencil Layers","","GP_SELECT_STROKES",5),
	]
	data_type : EnumProperty(default="vertex_groups",name = "Data Type", items=items)
	items = [
	("MESH","Mesh Data","","GROUP_VERTEX",0),
	("BLEND","Blend Data","","GROUP_UVS",1),
	("GPENCIL","GPencil Layer","","GROUP_VCOL",2),
	]
	mode : EnumProperty(default="MESH",name = "Mode", items=items)
	all_selected_obj: BoolProperty(name="All Selected Object")
	replace_match_case: BoolProperty(name="Case sensitive",default=True)
	use_replace_regex: BoolProperty(name="Use Regular expressions")


	items = [
		('objects',"Object","","OBJECT_DATA",0),
		('collections',"Collection","","GROUP",1),
		('materials',"Material","","MATERIAL_DATA",2),
		('node_groups',"Node Groups","","NODETREE",3),
		None,
		('actions',"Action","","ACTION",4),
		('armatures',"Armature","","ARMATURE_DATA",5),
		('brushes',"Brush","","BRUSH_DATA",6),
		('cache_files',"Cache File","","BLANK1",7),
		('cameras',"Camera","","CAMERA_DATA",8),
		('curves',"Curve","","CURVE_DATA",9),
		('fonts',"Font","","FONT_DATA",10),
		('grease_pencils',"Grease Pencil","","OUTLINER_OB_GREASEPENCIL",11),
		('hairs',"Hair","","HAIR_DATA",12),
		('images',"Image","","IMAGE_DATA",13),
		('lattices',"Lattice","","LATTICE_DATA",14),
		('lightprobes',"Light Probe","","OUTLINER_OB_LIGHTPROBE",15),
		('lights',"Light","","LIGHT_DATA",16),
		('linestyles',"Line Style","","LINE_DATA",17),
		('masks',"Mask","","MOD_MASK",18),
		('meshes',"Mesh","","MESH_DATA",19),
		('metaballs',"Metaball","","META_DATA",20),
		('movieclips',"Movie Clip","","FILE_MOVIE",21),
		('paint_curves',"Paint Curve","","CURVE_DATA",22),
		('palettes',"Palette","","COLOR",23),
		('particles',"Particle","","PARTICLE_DATA",24),
		('pointclouds',"Pointcloud","","POINTCLOUD_DATA",25),
		('scenes',"Scene","","SCENE_DATA",26),
		('screens',"Screen","","RESTRICT_VIEW_ON",27),
		('simulations',"Simulation","","MOD_FLUID",28),
		('sounds',"Sound","","SOUND",29),
		('speakers',"Speaker","","PLAY_SOUND",30),
		('texts',"Text","","TEXT",31),
		('textures',"Texture","","TEXTURE_DATA",32),
		('volumes',"Volume","","VOLUME_DATA",33),
		('workspaces',"Workspace","","NETWORK_DRIVE",34),
		('worlds',"World","","WORLD_DATA",35),
	]
	blend_data_type : EnumProperty(default="objects",name = "Other Data Types", items= items)

	def invoke(self, context, event):
		dpi_value = bpy.context.preferences.system.dpi
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		return context.window_manager.invoke_props_dialog(self)

	def draw(self, context):
		layout = self.layout
		row = layout.row(align=True)
		row.prop(self,"mode",expand=True)
		if self.mode == "MESH":
			layout.prop(self,"data_type")
		elif self.mode == "BLEND":
			layout.prop(self,"blend_data_type")

		row = layout.row(align=True)
		row.prop(self,"rename_type",expand=True)

		col = layout.column(align=True)
		if self.rename_type == "REPLACE":
			row = col.row(align=True)
			row.prop(self,"replace_src",text="Target")
			row.prop(self,"use_replace_regex",text="",icon="SORTBYEXT")

			row = col.row(align=True)
			row.prop(self,"replace_dst",text="Replace")
			row.label(text="",icon="BLANK1")
		else:
			col.label(text="",icon="NONE")
			col.prop(self,"replace_dst",text="Add")

		col.separator()
		col.prop(self,"all_selected_obj")
		col.prop(self,"replace_match_case")
		col.separator()

		sample_text = ""

		obj = bpy.context.active_object
		data_l = self.get_data_list(context,obj)
		if self.rename_type == "REPLACE":
			hit_items = self.get_match(context)
			col.label(text="Hit : %s / %s" % (str(len(hit_items)),len(data_l)),icon="NONE")

		if self.mode == "MESH":
			if data_l:
				act_data = data_l.active
				if act_data:
					if type(self.get_nameattr(context,act_data)) is str:
						tgt_act_text = act_data
					else:
						tgt_act_text = str(self.get_nameattr(context,act_data).name)

					print(self.get_nameattr(context,act_data))
					rt_text = self.get_rename_text(context,tgt_act_text)
					sample_text = "Sample : " + rt_text

		col.label(text=sample_text,icon="NONE")


	def execute(self, context):
		if self.all_selected_obj:
			obj_l = bpy.context.selected_objects
		else:
			obj_l = [bpy.context.object]

		for obj in obj_l:
			for dt in self.get_data_list(context,obj):
				rt_text = self.get_rename_text(context,self.get_nameattr(context,item).name)
				self.get_nameattr(context,item).name = rt_text

		return {'FINISHED'}


	# 対象のデータリストを取得
	def get_data_list(self,context,obj):
		data_l = []

		if self.mode == "MESH":
			if self.data_type == "vertex_groups":
				data_l = obj.vertex_groups

			elif self.data_type == "uv_layers":
				if obj.type in {"MESH"}:
					data_l = obj.data.uv_layers

			elif self.data_type == "vertex_colors":
				if obj.type in {"MESH"}:
					data_l = obj.data.vertex_colors

			elif self.data_type == "face_maps":
				if obj.type in {"MESH"}:
					data_l = obj.data.face_maps

			elif self.data_type == "shape_keys":
				if obj.type in {"MESH","CURVE"}:
					data_l = obj.data.shape_keys.key_blocks

			elif self.data_type == "gpencil_layers":
				if obj.type in {"GPENCIL"}:
					data_l = obj.data.layers

		elif self.mode == "BLEND":
			data_l = getattr(bpy.data,self.blend_data_type)

		return data_l


	# マッチを取得
	def get_match(self,context):
		hit_items = []
		if not self.replace_src:
			return hit_items

		if self.all_selected_obj and self.mode == "MESH":
			obj_l = bpy.context.selected_objects
		else:
			obj_l = [bpy.context.object]

		for obj in obj_l:
			for dt in self.get_data_list(context,obj):
				hit_dt = self.get_match_text(context,dt)
				if hit_dt:
					hit_items.append(hit_dt)

		return hit_items


	# グリースペンシルデータ型の例外処理
	def get_nameattr(self,context,item):
		if self.mode == "MESH" and self.data_type == "gpencil_layers":
			return  item.info
		else:
			return  item


	# ヒットしたテキストを取得
	def get_match_text(self,context,item):
		rt_dt = None
		if self.replace_match_case:
			tgt_name = self.get_nameattr(context,item).name
		else:
			tgt_name = self.get_nameattr(context,item).name.lower()

		if self.rename_type == "REPLACE":
			if self.use_replace_regex:
				if len(re.findall(self.replace_src,tgt_name)):
					rt_dt = item
			else:
				if self.replace_src in tgt_name:
					rt_dt = item

		return rt_dt


	# リネーム済みのテキストを取得
	def get_rename_text(self,context,dataname):
		if self.replace_match_case:
			tgt_name = dataname
		else:
			tgt_name = dataname.lower()

		if self.rename_type == "REPLACE":
			if self.use_replace_regex:
				rt_text = re.sub(self.replace_src,self.replace_dst,tgt_name)
			else:
				rt_text = tgt_name.replace(self.replace_src,self.replace_dst)

		elif self.rename_type == "FIRST":
			rt_text = self.replace_dst + dataname

		elif self.rename_type == "END":
			rt_text = dataname + self.replace_dst

		return rt_text



def set_weight_option_menu(self,context,props,is_op):
	layout = self.layout

	if is_op:
		layout.label(text="Value",icon="DOT")
		box = layout.box()
		box.prop(props,"weight",slider = True)

	layout.separator()
	layout.label(text="Type",icon="OPTIONS")
	box = layout.box()
	row = box.row(align=True)
	row.prop(props,"type",expand=True)

	layout.separator()
	layout.label(text="Normalize",icon="RNA")
	box = layout.box()

	row = box.row(align=True)
	row.prop(props,"normalize",expand=True)
	if props.normalize in {"All", "Deform Pose Bone", "Selected Pose Bone"}:
		row = box.row(align=True)
		row.prop(props,"normalize_lock_active",expand=True)
	else:
		row = box.row(align=True)
		row.label(text="")

	layout.separator()
	layout.label(text="Clean",icon="TRASH")
	box = layout.box()
	row = box.row(align=True)
	row.prop(props,"set_weight_clean_mode",expand=True)
	if not props.set_weight_clean_mode == "NONE":
		row = box.row(align=True)
		row.prop(props,"set_weight_clean_limit")
		row.prop(props,"set_weight_clean_keep_single")

	if is_op:
		layout.separator()
		layout.label(text="Symmetry",icon="MOD_MIRROR")
		box = layout.box()
		# vpaint = bpy.context.scene.tool_settings.weight_paint

		row = box.row(align=True)
		row.prop(self, "use_symmetry_x", text="X", toggle=True)
		row.prop(self, "use_symmetry_y", text="Y", toggle=True)
		row.prop(self, "use_symmetry_z", text="Z", toggle=True)

	row = box.row(align=True)
	row.use_property_split = True
	row.use_property_decorate = False
	# row.active = bool(props.symmetry_dist)
	row.prop(props,"symmetry_dist")
	if is_op:
		if self.is_multi_objs:
			col = layout.column(align=True)
			col.use_property_split = False
			col.use_property_decorate = False
			col.prop(props,"set_actvg_of_selobjs")

	if not is_op:
		obj = bpy.context.object
		layout.separator()
		layout.prop(obj.data,"use_mirror_vertex_groups")


	if not is_op:
		layout.separator()
		layout.prop(props,"auto_set_actvg_of_selobjs")


class LAZYWEIGHT_OT_convert_bone_to_mesh(Operator):
	bl_idname = "lazyweight.convert_bone_to_mesh"
	bl_label  = "Convert Bone to Mesh"
	bl_options = {'REGISTER', 'UNDO'}

	mesh_type : StringProperty(name="Tapered",default="Tapered")

	@classmethod
	def poll(cls, context):
		return bpy.context.selected_objects

	def execute(self, context):
		for obj in bpy.context.selected_objects:
			if obj.type != 'ARMATURE':
				continue
			bpy.context.view_layer.objects.active = obj
			self.processArmature(context, obj, meshType = self.mesh_type )

		return {'FINISHED'}


	#Create the base object from the armature
	def meshFromArmature(self, arm ):
		name = arm.name + "_mesh"
		meshData = bpy.data.meshes.new( name + "Data" )
		meshObj = bpy.data.objects.new( name, meshData )
		meshObj.matrix_world = arm.matrix_world.copy()
		return meshObj

	#Create the bone geometry (vertices and faces)
	def boneGeometry(self, l1, l2, x, z, baseSize, l1Size, l2Size, base, meshType ):

		if meshType == 'Tapered':
			print(meshType)
			x1 = x * baseSize * l1Size
			z1 = z * baseSize * l1Size

			x2 = x * baseSize * l2Size
			z2 = z * baseSize * l2Size

		elif meshType == 'Box':
			print(meshType)
			lSize = (l1Size + l2Size) / 2
			x1 = x * baseSize * lSize
			z1 = z * baseSize * lSize

			x2 = x * baseSize * lSize
			z2 = z * baseSize * lSize

		else: # default to Pyramid
			print(meshType)
			x1 = x * baseSize * l1Size
			z1 = z * baseSize * l1Size

			x2 = Vector( (0, 0, 0) )
			z2 = Vector( (0, 0, 0) )

		verts = [
			l1 - x1 + z1,
			l1 + x1 + z1,
			l1 - x1 - z1,
			l1 + x1 - z1,
			l2 - x2 + z2,
			l2 + x2 + z2,
			l2 - x2 - z2,
			l2 + x2 - z2
			]

		faces = [
			(base+3, base+1, base+0, base+2),
			(base+6, base+4, base+5, base+7),
			(base+4, base+0, base+1, base+5),
			(base+7, base+3, base+2, base+6),
			(base+5, base+1, base+3, base+7),
			(base+6, base+2, base+0, base+4)
			]

		return verts, faces

	#Process the armature, goes through its bones and creates the mesh
	def processArmature(self,context, arm, genVertexGroups = True, meshType = 'Pyramid'):
		print("processing armature {0} {1}".format(arm.name, meshType) )

		#Creates the mesh object
		meshObj = self.meshFromArmature(arm)
		context.collection.objects.link( meshObj )

		verts = []
		edges = []
		faces = []
		vertexGroups = {}

		bpy.ops.object.mode_set(mode='EDIT')

		# try:
		#Goes through each bone
		for editBone in [b for b in arm.data.edit_bones if b.use_deform]:
			boneName = editBone.name
			# print( boneName )
			poseBone = arm.pose.bones[boneName]

			#Gets edit bone informations
			editBoneHead = editBone.head
			editBoneTail = editBone.tail
			editBoneVector = editBoneTail - editBoneHead
			editBoneSize = editBoneVector.dot( editBoneVector )
			editBoneRoll = editBone.roll
			editBoneX = editBone.x_axis
			editBoneZ = editBone.z_axis
			editBoneHeadRadius = editBone.head_radius
			editBoneTailRadius = editBone.tail_radius

			#Creates the mesh data for the bone
			baseIndex = len(verts)
			baseSize = sqrt( editBoneSize )
			newVerts, newFaces = self.boneGeometry( editBoneHead, editBoneTail, editBoneX, editBoneZ, baseSize, editBoneHeadRadius, editBoneTailRadius, baseIndex, meshType )

			verts.extend( newVerts )
			faces.extend( newFaces )

			#Creates the weights for the vertex groups
			vertexGroups[boneName] = [(x, 1.0) for x in range(baseIndex, len(verts))]

		#Assigns the geometry to the mesh
		meshObj.data.from_pydata(verts, edges, faces)

		bpy.ops.object.mode_set(mode='OBJECT')

		#Assigns the vertex groups
		if genVertexGroups:
			for name, vertexGroup in vertexGroups.items():
				groupObject = meshObj.vertex_groups.new(name=name)
				for (index, weight) in vertexGroup:
					groupObject.add([index], weight, 'REPLACE')

		#Creates the armature modifier
		modifier = meshObj.modifiers.new('ArmatureMod', 'ARMATURE')
		modifier.object = arm
		modifier.use_bone_envelopes = False
		modifier.use_vertex_groups = True

		meshObj.data.update()

		return meshObj


class LAZYWEIGHT_OT_vgroup_add_weightmix(Operator):
	bl_idname = "lazyweight.vgroup_add_weightmix"
	bl_label  = "Add Adjust Layer (Weight Mix Modifier)"
	bl_description  = "Add new vertex group to adjust the active vertex group. Use the Weight Mix modifier.\nYou can change the blend mode and adjust the degree of influence like a layer"
	bl_options = {'REGISTER', 'UNDO'}

	items = [
	("SET", "Replace", "Replace VGroup A’s weights by VGroup B’s ones"),
	("ADD", "Add", "Add VGroup B’s weights to VGroup A’s ones"),
	("SUB", "Subtract", "Subtract VGroup B’s weights from VGroup A’s ones"),
	("MUL", "Multiply", "Multiply VGroup A’s weights by VGroup B’s ones"),
	("DIV", "Divide", "Divide VGroup A’s weights by VGroup B’s ones"),
	("DIF", "Difference", "Difference between VGroup A’s and VGroup B’s weights"),
	("AVG", "Average", "Average value of VGroup A’s and VGroup B’s weights"),
	]
	mix_mode : EnumProperty(default="ADD",name = "Mix Mode", items= items)
	mask_constant : FloatProperty(name="Global Influence",description="Global influence of current modifications on vgroup",default=1)
	# vertex_group_a : StringProperty(name="Vertex Group A")
	# vertex_group_b : StringProperty(name="Vertex Group B")
	normalize : BoolProperty(name="Normalize",default=True)

	@classmethod
	def poll(cls, context):
		obj = bpy.context.active_object
		return obj and obj.type == "MESH" and obj.vertex_groups


	def execute(self, context):
		obj = bpy.context.object
		act_vg = obj.vertex_groups.active
		new_vg = obj.vertex_groups.new(name=act_vg.name + "_adjust")


		last_mix_mod = None
		for mod in reversed(obj.modifiers):
		    if mod.type == "VERTEX_WEIGHT_MIX":
		        last_mix_mod = mod
		        break

		if last_mix_mod:
		    mod_l = list(obj.modifiers)
		    tgt_index = mod_l.index(last_mix_mod) + 1
		else:
		    tgt_index = 0


		mod_name = "VertexWeightMix %s" % act_vg.name
		mod = obj.modifiers.new(name=mod_name, type='VERTEX_WEIGHT_MIX')

		bpy.ops.object.modifier_move_to_index(modifier=mod.name, index=tgt_index)

		mod.vertex_group_a = act_vg.name
		mod.vertex_group_b = new_vg.name
		mod.mix_set = 'ALL'
		mod.mix_mode = self.mix_mode
		mod.mask_constant = self.mask_constant
		# mod.normalize = self.normalize

		self.report({'INFO'}, "Add [%s] Modifier" % mod.name)
		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_add_weightmix_apply(Operator):
	bl_idname = "lazyweight.vgroup_add_weightmix_apply"
	bl_label  = "Apply(and Remove Adjust VGroup B)"
	bl_description  = "Shift : Apply Only Modifier"
	bl_options = {'REGISTER', 'UNDO'}

	modifier : StringProperty(name="Modifier Name")
	apply_only_mod : BoolProperty()

	@classmethod
	def poll(cls, context):
		obj = bpy.context.active_object
		return obj and obj.type == "MESH"


	def invoke(self, context,event):
		if event.shift:
			self.apply_only_mod = True
		else:
			self.apply_only_mod = False


		return self.execute(context)


	def execute(self, context):
		obj = bpy.context.object
		if not self.modifier in obj.modifiers:
			self.report({'INFO'}, "No Modifier Name Item")
			return{'FINISHED'}

		mod = obj.modifiers[self.modifier]
		del_v_name = mod.vertex_group_b

		bpy.ops.object.modifier_apply(modifier=self.modifier)
		obj.update_tag()

		if self.apply_only_mod:
			self.report({'INFO'}, "Apply Modifier [%s]" % self.modifier)
			return {'FINISHED'}
		else:
			if del_v_name in obj.vertex_groups:
				obj.vertex_groups.remove(obj.vertex_groups[del_v_name])

			self.report({'INFO'}, "Apply Modifier(and Remove Adjust VGroup) [%s]" % self.modifier)
			return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_add_weightmix_remove(Operator):
	bl_idname = "lazyweight.vgroup_add_weightmix_remove"
	bl_label  = "Remove Modifier(and Remove Adjust VGroup B)"
	bl_description  = "Shift : Remove Only Modifier"
	bl_options = {'REGISTER', 'UNDO'}

	modifier : StringProperty(name="Modifier Name")
	remove_only_mod : BoolProperty()

	@classmethod
	def poll(cls, context):
		obj = bpy.context.active_object
		return obj and obj.type == "MESH"


	def invoke(self, context,event):
		if event.shift:
			self.remove_only_mod = True
		else:
			self.remove_only_mod = False

		return self.execute(context)

	def execute(self, context):
		obj = bpy.context.object
		if not self.modifier in obj.modifiers:
			self.report({'INFO'}, "No Modifier Name Item")
			return{'FINISHED'}

		mod = obj.modifiers[self.modifier]
		del_v_name = mod.vertex_group_b
		bpy.ops.object.modifier_remove(modifier=self.modifier)


		if self.remove_only_mod:
			self.report({'INFO'}, "Remove Modifier [%s]" % self.modifier)
			return {'FINISHED'}
		else:
			if del_v_name in obj.vertex_groups:
				obj.vertex_groups.remove(obj.vertex_groups[del_v_name])

			self.report({'INFO'}, "Remove Modifier(and Remove Adjust VGroup) [%s]" % self.modifier)
			return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_add_weightmix_rename(Operator):
	bl_idname = "lazyweight.vgroup_add_weightmix_rename"
	bl_label  = "Rename Vertex Group"
	bl_description  = ""
	bl_options = {'REGISTER', 'UNDO'}

	modifier : StringProperty(name="Modifier Name")
	new_name : StringProperty(name="New Name")

	@classmethod
	def poll(cls, context):
		obj = bpy.context.active_object
		return obj and obj.type == "MESH"


	def invoke(self, context, event):
		obj = bpy.context.object
		self.new_name = obj.modifiers[self.modifier].vertex_group_b
		wm = context.window_manager
		return wm.invoke_props_dialog(self,width=200)

	def draw(self, context):
		layout = self.layout
		layout.prop(self, 'new_name', text="")

	def execute(self, context):
		obj = bpy.context.object

		mod = obj.modifiers[self.modifier]
		vg = obj.vertex_groups[mod.vertex_group_b]
		vg.name = self.new_name
		mod.vertex_group_b = self.new_name

		self.report({'INFO'}, "Rename [%s]" % self.new_name)
		return {'FINISHED'}


class LAZYWEIGHT_OT_vgroup_round_weight(Operator):
	bl_idname = "lazyweight.vgroup_round_weight"
	bl_label  = "Round Weight Value"
	bl_description  = "Simplifies weight data by truncating the small decimal value of the weight"
	bl_options = {'REGISTER', 'UNDO'}

	round_number : IntProperty(name="Number of decimal places",min=1,default=3)
	only_active_vgroup : BoolProperty(name="Only Active Vertex Group")
	only_select : BoolProperty(name="Only Select")
	normalize : BoolProperty(name="Normalize All",description="All vertices are normalized even if the select only option is enabled")

	@classmethod
	def poll(cls, context):
		obj = bpy.context.active_object
		return obj and obj.type == "MESH"

	def invoke(self, context, event):
		wm = context.window_manager
		return wm.invoke_props_dialog(self,width=250)

	def draw(self, context):
		layout = self.layout
		col = layout.column(align=True)
		col.use_property_split = True
		col.use_property_decorate = False
		col.prop(self, 'round_number')
		layout.prop(self, 'only_active_vgroup')
		layout.prop(self, 'only_select')
		layout.prop(self, 'normalize')


	def execute(self, context):
		if self.round_number == 1:
			num_text = '0.1'
		else:
			num_text = '0.%s1' %  ("0" * (self.round_number - 1))

		old_act = bpy.context.view_layer.objects.active
		for obj in bpy.context.selected_objects:
			bpy.context.view_layer.objects.active = obj

			if not obj.type == "MESH":
				continue
			if not obj.vertex_groups:
				continue
			for v in obj.data.vertices:
				if self.only_select:
					if not v.select:
						continue

				for g in v.groups:
					if self.only_active_vgroup:
						if not g.group == obj.vertex_groups.active_index:
							continue
					g.weight = Decimal(str(g.weight)).quantize(Decimal(num_text), rounding=ROUND_HALF_UP)
					# g.weight = round(g.weight,self.round_number)


			if self.normalize:
				# if self.only_active_vgroup:
				# 	bpy.ops.object.vertex_group_normalize()
				# else:
				bpy.ops.object.vertex_group_normalize_all()

		bpy.context.view_layer.objects.active = old_act

		self.report({'INFO'}, "Rounded weights with [%s] decimal places or less" % self.round_number)
		return {'FINISHED'}


class LAZYWEIGHT_OT_bone_select_in_hierarchy_menu(Operator):
	bl_idname = "lazyweight.bone_select_in_hierarchy_menu"
	bl_label  = "Select Bone"
	bl_description  = "Set the Bind bone object to pause mode and active select the bone with the same name.\nShift: Multiple selection\nAlt: Only deselect bones"

	bone_name : StringProperty(name="Bone Name")
	b_obj_name : StringProperty(name="Bone Obj Name")

	def invoke(self, context, event):
		old_sel = bpy.context.selected_objects
		for obj in old_sel:
			obj.select_set(False)
		old_act = bpy.context.object
		tgt_obj = bpy.data.objects[self.b_obj_name]

		bpy.context.view_layer.objects.active = tgt_obj
		bpy.ops.object.mode_set(mode="POSE")

		if not event.alt:
			tgt_obj.data.bones.active = tgt_obj.data.bones[self.bone_name]

		if not event.shift and not event.alt:
			for bone in tgt_obj.data.bones:
				bone.select = False

		if event.alt:
			tgt_obj.data.bones[self.bone_name].select = False
		else:
			tgt_obj.data.bones[self.bone_name].select = True

		for obj in old_sel:
			obj.select_set(True)
		bpy.context.view_layer.objects.active =  old_act

		if not event.alt:
			bpy.context.object.vertex_groups.active_index = bpy.context.object.vertex_groups[self.bone_name].index


		return {'FINISHED'}
