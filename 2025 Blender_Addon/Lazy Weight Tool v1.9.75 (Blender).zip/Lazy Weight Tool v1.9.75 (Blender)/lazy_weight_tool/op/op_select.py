import bpy
from bpy.types import Operator
from bpy.props import *


def go_to_editmode():
	obj = bpy.context.object
	old_mode = obj.mode


	bpy.ops.object.mode_set(mode="EDIT")
	if obj.data.use_paint_mask:
		bpy.ops.mesh.select_mode(type='FACE')
	else:
		bpy.ops.mesh.select_mode(type='VERT')

	return old_mode


def pre_mod_adjust():
	obj = bpy.context.object
	deform_mod_l = [
	'ARMATURE',
	'CAST',
	'CURVE',
	'DISPLACE',
	'HOOK',
	'LAPLACIANDEFORM',
	'LATTICE',
	'MESH_DEFORM',
	'SHRINKWRAP',
	'SIMPLE_DEFORM',
	'SMOOTH',
	'CORRECTIVE_SMOOTH',
	'LAPLACIANSMOOTH',
	'SURFACE_DEFORM',
	'WARP',
	'WAVE',
	]
	restore_mod = []
	for mod in obj.modifiers:
		if mod.type in deform_mod_l:
			restore_mod.append((mod, mod.show_on_cage, mod.show_in_editmode))
			mod.show_on_cage = True
			mod.show_in_editmode = True

	return restore_mod

def restore_mod(restore_arm_mod):
	for mod, old_show_on_cage, old_show_in_editmode in restore_arm_mod:
		mod.show_on_cage = old_show_on_cage
		mod.show_in_editmode = old_show_in_editmode


def xray_adjust():
	old_show_xray = False
	if bpy.context.space_data.shading.show_xray:
		bpy.context.space_data.shading.show_xray = False
		old_show_xray = True

	return old_show_xray

def xray_restore(old_show_xray):
	if old_show_xray:
		bpy.context.space_data.shading.show_xray = True


class LAZYWEIGHT_OT_select_edgeloop_click(Operator):
	bl_idname = "lazyweight.select_edgeloop_click"
	bl_label = "Select Edge Loop Click"
	bl_description = "Select Edge Loop Click"
	bl_options = {'REGISTER', 'UNDO'}

	extend : BoolProperty(default= False)


	def execute(self, context):
		old_mode = go_to_editmode()
		restore_mod_l = pre_mod_adjust()
		old_show_xray_bool = xray_adjust()

		if self.extend:
			bpy.ops.mesh.loop_select('INVOKE_DEFAULT',extend=self.extend)
		else:
			bpy.ops.mesh.loop_select('INVOKE_DEFAULT')

		bpy.ops.object.mode_set(mode=old_mode)
		restore_mod(restore_mod_l)
		xray_restore(old_show_xray_bool)
		return {'FINISHED'}


class LAZYWEIGHT_OT_shortest_path_pick(Operator):
	bl_idname = "lazyweight.shortest_path_pick"
	bl_label = "Select Shortest Path Click"
	bl_description = "Select Shortest Path Click"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		old_mode = go_to_editmode()
		restore_mod_l = pre_mod_adjust()
		old_show_xray_bool = xray_adjust()

		bpy.ops.mesh.shortest_path_pick('INVOKE_DEFAULT')

		bpy.ops.object.mode_set(mode=old_mode)

		restore_mod(restore_mod_l)
		xray_restore(old_show_xray_bool)

		return {'FINISHED'}


class LAZYWEIGHT_OT_select_link(Operator):
	bl_idname = "lazyweight.select_link"
	bl_label = "Select Link"
	bl_description = "Select Link"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		old_mode = go_to_editmode()
		# restore_mod_l = pre_mod_adjust()
		# old_show_xray_bool = xray_adjust()


		bpy.ops.mesh.select_linked()

		bpy.ops.object.mode_set(mode=old_mode)
		# restore_mod(restore_mod_l)
		# xray_restore(old_show_xray_bool)
		return {'FINISHED'}


class LAZYWEIGHT_OT_select_more(Operator):
	bl_idname = "lazyweight.select_more"
	bl_label = "Select More"
	bl_description = "Select More"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		old_mode = bpy.context.object.mode

		old_mode = go_to_editmode()

		bpy.ops.mesh.select_more()
		bpy.ops.object.mode_set(mode=old_mode)

		return {'FINISHED'}


class LAZYWEIGHT_OT_select_less(Operator):
	bl_idname = "lazyweight.select_less"
	bl_label = "Select Less"
	bl_description = "Select Less"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		old_mode = go_to_editmode()

		bpy.ops.mesh.select_less()
		bpy.ops.object.mode_set(mode=old_mode)

		return {'FINISHED'}


class LAZYWEIGHT_OT_select_mirror(Operator):
	bl_idname = "lazyweight.select_mirror"
	bl_label = "Select Mirror"
	bl_description = "Select Mirror"
	bl_options = {'REGISTER', 'UNDO'}

	extend : BoolProperty(default=True,name="Extend")
	items = [
		("X", "X", "", 1),
		("Y", "Y", "", 2),
		("Z", "Z", "", 3),
		]
	axis : EnumProperty(default="X",items=items, name="Axis")


	def draw(self, context):
		layout = self.layout
		layout.alignment = "RIGHT"
		row = layout.row(align=True)
		row.prop(self,"axis",expand=True)
		layout.prop(self,"extend")

	def execute(self, context):
		old_mode = go_to_editmode()

		bpy.ops.mesh.select_mirror(axis={self.axis}, extend=self.extend)
		bpy.ops.object.mode_set(mode=old_mode)
		return {'FINISHED'}


class LAZYWEIGHT_OT_select_edgeloop(Operator):
	bl_idname = "lazyweight.select_edgeloop"
	bl_label = "Select Edge Loop"
	bl_description = "Select Edge Loop"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		old_mode = go_to_editmode()

		bpy.ops.mesh.loop_multi_select(ring=False)

		bpy.ops.object.mode_set(mode=old_mode)

		return {'FINISHED'}


class LAZYWEIGHT_OT_select_multiLoop(Operator):
	bl_idname = "lazyweight.select_multiloop"
	bl_label = "Select Multi Loop"
	bl_description = "Select Multi Loop"
	bl_options = {'REGISTER', 'UNDO'}


	def execute(self, context):
		old_mode = bpy.context.object.mode

		old_mode = go_to_editmode()
		bpy.ops.mesh.loop_multi_select(ring=True)

		bpy.ops.object.mode_set(mode=old_mode)

		return {'FINISHED'}


class LAZYWEIGHT_OT_select_half(Operator):
	bl_idname = "lazyweight.select_half"
	bl_label = "Select Half"
	bl_description = "Select half based on axis"
	bl_options = {'REGISTER', 'UNDO'}

	items = [
		("0", "X Axis", "", 1),
		("1", "Y Axis", "", 2),
		("2", "Z Axis", "", 3),
		]
	axis : EnumProperty(items=items, name="Axis")
	items = [
		("-1", "Negative", "","REMOVE", 1),
		("1", "Positive", "","ADD", 2),
		]
	direction : EnumProperty(items=items, name="Direction")
	offset : FloatProperty(name="Offset", default=0, step=10, precision=3)
	threshold : FloatProperty(name="Threshold", default=0.0000001, step=0.1, precision=10)

	def draw(self, context):
		layout = self.layout
		row = layout.row(align=True)
		row.prop(self,"axis",expand=True)
		row = layout.row(align=True)
		row.prop(self,"direction",expand=True)
		layout.separator()
		layout.prop(self,"offset")
		layout.prop(self,"threshold")



	def execute(self, context):
		old_mode = bpy.context.object.mode

		obj = context.active_object

		bpy.ops.object.mode_set(mode="OBJECT")
		sel_mode = context.tool_settings.mesh_select_mode[:]
		bpy.context.tool_settings.mesh_select_mode = [True, False, False]
		me = obj.data
		if (obj.type == "MESH"):
			for vert in me.vertices:
				co = [vert.co.x, vert.co.y, vert.co.z][int(self.axis)]
				direct = int(self.direction)
				if (self.offset * direct <= co * direct + self.threshold):
					vert.select = True
		bpy.ops.object.mode_set(mode="EDIT")
		context.tool_settings.mesh_select_mode = sel_mode


		bpy.ops.object.mode_set(mode=old_mode)

		return {'FINISHED'}


# class LAZYWEIGHT_OT_hide_vgroup(Operator):
# 	bl_idname = "lazyweight.hide_vgroup"
# 	bl_label = "hide_vgroup"
# 	bl_description = "hide_vgroup"
# 	bl_options = {'REGISTER', 'UNDO'}
#
#
# 	@classmethod
# 	def poll(cls, context):
# 		obj = bpy.context.active_object
# 		return obj and obj.type == "MESH"
#
# 	def execute(self, context):
# 		# bpy.ops.object.vertex_group_select()
# 		# bpy.ops.mesh.hide()
#
# 		import bpy, bmesh
#
#
# 		old_mode = bpy.context.object.mode
# 		sel_mode = bpy.context.tool_settings.mesh_select_mode[:]
# 		bpy.context.tool_settings.mesh_select_mode = [True, False, False]
# 		bpy.ops.object.mode_set(mode="OBJECT")
#
# 		obj = bpy.context.active_object
# 		vgroup = obj.vertex_groups[0]
# 		hide_v_l = [v.index
# 		for v in obj.data.vertices
# 			for g in v.groups # 「頂点の」グループ
# 				if g.group == vgroup.index # 頂点グループ
# 				]
#
# 		bm = bmesh.new()
# 		bm.from_mesh(obj.data)
# 		# old_sel = [v for v in bm.verts if v.select]
#
# 		if sel_mode[2]:
# 			for v in bm.verts:
# 				if v.index in hide_v_l:
# 					v.select = True
# 				else:
# 					v.select = False
# 			# bm.select_flush_mode()
# 			bm.to_mesh(obj.data)
# 			bpy.ops.object.mode_set(mode="EDIT")
# 			bpy.context.tool_settings.mesh_select_mode = (False, False, True)
# 			bpy.ops.object.mode_set(mode="OBJECT")
# 			bm = bmesh.new()
# 			bm.from_mesh(obj.data)
# 			for f in bm.faces:
# 				if f.select:
# 					f.hide = True
# 			two_edge = []
# 			for e in bm.edges:
# 				if e in two_edge:
# 					e.hide = True
# 				if e.select:
# 					two_edge += [e.index]
# 					print(999999,e.index)
# 			bm.to_mesh(obj.data)
#
# 		# for f in bm.faces:
# 		# 	if f.select:
# 		# 		f.hide = True
# 		# else:
# 		# 	for v in bm.verts:
# 		# 		if v.index in hide_v_l:
# 		# 			v.hide = True
# 		# 			v.select = False
# 		# 			# link_edges
# 		# 			for e in v.link_edges:
# 		# 				e.hide = True
# 		# 				e.select = False
# 		# 			# link_faces
# 		# 			for f in v.link_faces:
# 		# 				f.hide = True
# 		# 				f.select = False
#
#
# 		bpy.context.tool_settings.mesh_select_mode = sel_mode
# 		bpy.ops.object.mode_set(mode=old_mode)
#
#
#
# 		return {'FINISHED'}
