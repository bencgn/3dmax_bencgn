import bpy
from bpy.types import Operator
from bpy.props import *

from ..utils import preference
import bgl
import blf


class LAZYWEIGHT_OT_adjust_weight_gesture(Operator):
	bl_idname = "lazyweight.adjust_weight_gesture"
	bl_label = "Adjust Weight Gesture"
	bl_description = "Adjust the weight by moving the mouse"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		if bpy.context.view_layer.objects.active:
			obj = bpy.context.view_layer.objects.active
			if obj.type in {"MESH"}:
				if obj.vertex_groups.active:
					return True


	def invoke(self, context, event):
		if not context.area.type == 'VIEW_3D':
			return {'CANCELLED'}
		obj = bpy.context.object
		if obj.vertex_groups.active.lock_weight:
			self.report({'WARNING'}, "Active vertex group is locked")
			return {'CANCELLED'}

		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		self.orig_x = event.mouse_x
		self.def_mouse_point = event.mouse_x
		self.m_x = event.mouse_x
		self.value = 0 # 1回のマウス移動で追加する値
		self.total_value = 0 # 合計値
		self.use_normalize = True


		context.window_manager.modal_handler_add(self)
		self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")
		if bpy.context.region:
			bpy.context.region.tag_redraw()

		return {'RUNNING_MODAL'}


	def modal(self, context, event):
		addon_prefs = preference()
		self.m_x = event.mouse_x
		bpy.context.area.header_text_set(text="← → : Adjust Weight ,  Left Mouse : Confirm")

		# 修飾キーでの調整
		if event.shift:
			addon_prefs.adjust_weight_status_shift = True
		else:
			addon_prefs.adjust_weight_status_shift = False

		if event.ctrl:
			addon_prefs.adjust_weight_status_ctrl = True
		else:
			addon_prefs.adjust_weight_status_ctrl = False


		# ターゲット
		if event.type == "T" and event.value == 'PRESS':
			if addon_prefs.adjust_weight_status_target == "ACTIVE":
				addon_prefs.adjust_weight_status_target = "SELECTED"
			elif addon_prefs.adjust_weight_status_target == "SELECTED":
				addon_prefs.adjust_weight_status_target = "ACTIVE"

		# ノーマライズ
		if event.type == "N" and event.value == 'PRESS':
			if addon_prefs.adjust_weight_status_normalize:
				addon_prefs.adjust_weight_status_normalize = False
			else:
				addon_prefs.adjust_weight_status_normalize = True


		if event.type == 'MOUSEMOVE':

			# 対象オブジェクトを決定
			act_obj = bpy.context.object
			main_act_vg = act_obj.vertex_groups.active
			if addon_prefs.adjust_weight_status_target == "SELECTED":
				obj_l = [o for o in bpy.context.selected_objects if o.type == "MESH"]
			elif addon_prefs.adjust_weight_status_target == "ACTIVE":
				obj_l = [bpy.context.object]

			# オブジェクトリストを反復する
			for obj in obj_l:
				bpy.context.view_layer.objects.active = obj
				if addon_prefs.adjust_weight_status_target == "SELECTED":
					if not main_act_vg.name in obj.vertex_groups:
						continue
					act_vg = obj.vertex_groups[main_act_vg.name]
					if act_vg.lock_weight:
						bpy.context.view_layer.objects.active = act_obj
						continue
				elif addon_prefs.adjust_weight_status_target == "ACTIVE":
					act_vg = obj.vertex_groups.active

				v_index_l = [v.index for v in obj.data.vertices if v.select]

				# 値をゆっくり
				if event.shift:
					self.value = (event.mouse_region_x - self.orig_x) * 0.000001
				else:
					self.value = (event.mouse_region_x - self.orig_x) * 0.00010

				# 値を丸める
				if event.ctrl:
					if event.shift:
						self.value = round(self.value,4)
					else:
						self.value = round(self.value,2)
				else:
					self.value = round(self.value,4)

				self.total_value += self.value

				# -1< >1  の範囲をはみ出ないようにする
				if self.total_value >= 1:
					self.total_value = 1
				elif self.total_value <= -1:
					self.total_value = -1

				if -1 <= self.total_value <= 1:
					if self.value < 0: # マイナス
						act_vg.add(index=v_index_l,weight=self.value*-1,type="SUBTRACT")
					else:
						act_vg.add(index=v_index_l,weight=self.value,type="ADD")


				if addon_prefs.adjust_weight_status_normalize:
					old_act_vg = obj.vertex_groups.active
					obj.vertex_groups.active = act_vg
					bpy.ops.object.vertex_group_normalize_all()
					obj.vertex_groups.active = old_act_vg
					act_obj.update_tag()

				bpy.context.view_layer.objects.active = act_obj


		if event.type in {'LEFTMOUSE', 'SPACE', 'RET', "ESC"} and event.value == 'PRESS':
			return self.finish()


		if bpy.context.region:
			bpy.context.region.tag_redraw()

		return {'RUNNING_MODAL'}


	def finish(self):
		bpy.context.area.header_text_set(None)
		try:
			bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
		except: pass

		if bpy.context.region:
			bpy.context.region.tag_redraw()

		return {"FINISHED"}


	def draw_ui(self, context):
		addon_prefs = preference()
		rh = context.region.height
		rw = context.region.width
		obj = bpy.context.object
		act_vg = obj.vertex_groups.active


		# ポジションを設定
		posi_y_mode_hide = 0
		posi_x_des_hide = 0
		font_size = 20

		font_id = 0
		p_x  = 50
		p_y  = 410 - font_size
		posi_x_km_key = p_x
		posi_x_km_des = p_x + 170 + posi_x_des_hide
		posi_y_mode = p_y + 170 + posi_y_mode_hide
		col_size = -30

		#Set font color
		bgl.glEnable(bgl.GL_BLEND)
		blf.color(0, 1, 0.75, 0.1, 1)
		bgl.glLineWidth(2)

		blf.size(font_id, font_size, 72)


		# モード
		blf.position(font_id, p_x, posi_y_mode + (col_size*-1.5), 0)
		blf.draw(font_id, "Adjust Weight Gesture")
		blf.position(font_id, p_x, posi_y_mode + (col_size*+0), 0)
		blf.draw(font_id, "Target [%s]" % act_vg.name)
		blf.position(font_id, p_x, posi_y_mode + (col_size*+1), 0)
		blf.draw(font_id, f'{self.total_value:.04f}')


		if addon_prefs.adjust_weight_status_shift:
			blf.color(0, 1, 0.75, 0.1, 1)
		else:
			blf.color(0, 1, 0.75, 0.1, .3)
		blf.position(font_id, p_x, posi_y_mode + (col_size*+3), 0)
		blf.draw(font_id, "Shift : Tweak")


		if addon_prefs.adjust_weight_status_ctrl:
			blf.color(0, 1, 0.75, 0.1, 1)
		else:
			blf.color(0, 1, 0.75, 0.1, .3)
		blf.position(font_id, p_x, posi_y_mode + (col_size*+4), 0)
		blf.draw(font_id, "Ctrl : Round the value")


		# ターゲット
		blf.color(0, 1, 0.75, 0.1, 1)
		blf.position(font_id, p_x, posi_y_mode + (col_size*+5), 0)
		if addon_prefs.adjust_weight_status_target == "ACTIVE":
			text_target = "Active Object"
		if addon_prefs.adjust_weight_status_target == "SELECTED":
			text_target = "Selected Objects"
		blf.draw(font_id, "T : Target [%s]" % text_target)

		# ノーマライズ
		if addon_prefs.adjust_weight_status_normalize:
			blf.color(0, 1, 0.75, 0.1, 1)
		else:
			blf.color(0, 1, 0.75, 0.1, .3)
		blf.position(font_id, p_x, posi_y_mode + (col_size*+6), 0)
		text_normalize = "ON" if addon_prefs.adjust_weight_status_normalize else "OFF"
		blf.draw(font_id, "N : Normalize [%s]" % text_normalize)
