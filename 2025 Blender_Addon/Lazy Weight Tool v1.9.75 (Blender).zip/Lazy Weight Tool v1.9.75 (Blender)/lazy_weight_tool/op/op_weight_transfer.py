import bpy
from bpy.types import Operator
from bpy.props import *
from ..ui.ui_main_weight_transfer import draw_weight_transfer_option


class LAZYWEIGHT_OT_weight_transfer_modifier_add(Operator):
	bl_idname = "lazyweight.weight_transfer_modifier_add"
	bl_label = "Weight Transfer Modifier"
	bl_description = "Set the weight transfer modifier on the active object.\Transfers the weight of the selected object to the active object.\nCtrl : Allpy Modifier"
	bl_options = {'REGISTER', 'UNDO', 'PRESET'}

	only_select : BoolProperty(name="Only Selected",description="Transfer weights only to the selected vertex")
	add_blank_bg : BoolProperty(name="Generate Data Layers",default=True,description="If there is no destination vertex group, a new one will be created")
	only_active_vertex_group : BoolProperty(name="Only Active Vertex Group")
	modifier_apply : BoolProperty(name="Apply Modifier")

	items = [
	("TOPOLOGY","Topology","Copy from identical topology meshes","MESH_DATA",0),
	("NEAREST","Nearest Vertex","Copy from closest vertex","VERTEXSEL",1),
	("EDGE_NEAREST","Nearest Edge Vertex","Copy from closest vertex of closest edge","EDGESEL",2),
	("EDGEINTERP_NEAREST","Nearest Edge Interpolated","Copy from interpolated values of vertices from closest point on closest edge","EDGESEL",3),
	("POLY_NEAREST","Nearest Face Vertex","Copy from closest vertex of closest face","FACESEL",4),
	("POLYINTERP_NEAREST","Nearest Face Interpolated","Copy from interpolated values of vertices from closest point on closest face","MOD_UVPROJECT",5),
	("POLYINTERP_VNORPROJ","Projected Face Interpolated","Copy from interpolated values of vertices from point on closest face hit by normal-projection","MOD_UVPROJECT",6),
	]
	vert_mapping : EnumProperty(name = "Mapping", items=items,default="NEAREST",)
	use_max_distance : BoolProperty(name="Use Max Distance")
	max_distance : FloatProperty(name="Max Distance",default=1,min=0,subtype="DISTANCE")
	ray_radius : FloatProperty(name="Ray Radius",default=0,min=0,subtype="DISTANCE")
	mix_factor : FloatProperty(name="Mix Factor",default=1,min=0,max=1)
	items = [
		("REPLACE","Replace","Overwrite all elements’ data","ADD",0),
		("ABOVE_THRESHOLD","Above Threshold","Only replace destination elements where data is above given threshold (exact behavior depends on data type)","SORT_DESC",1),
		("BELOW_THRESHOLD","Below Threshold","Only replace destination elements where data is below given threshold (exact behavior depends on data type)","SORT_ASC",2),
		("MIX","Mix","Mix source value into destination one, using given threshold as factor","SELECT_EXTEND",3),
		("ADD","Add","Add source value to destination one, using given threshold as factor","ADD",4),
		("SUB","Subtract","Subtract source value to destination one, using given threshold as factor","REMOVE",5),
		("MUL","Multiply","Multiply source value to destination one, using given threshold as factor","XRAY",6),
		]
	mix_mode : EnumProperty(default="REPLACE",items=items, name="Mix Mode")
	is_only_select_button : BoolProperty()
	use_object_transform : BoolProperty(name="Object Transform",description="Evaluate source and destination meshes in global space",default=True)
	# return_active_select_on_exit : BoolProperty(name="Return active selection on exit")

	@classmethod
	def poll(cls, context):
		return len(bpy.context.selected_objects) >= 2


	def draw(self, context):
		layout = self.layout
		draw_weight_transfer_option(self,context,layout)


	def invoke(self, context,event):
		sc = bpy.context.scene
		props = sc.lazyweight
		props_wt = props.weight_transfer

		self.only_select = props_wt.only_select
		self.add_blank_bg = props_wt.add_blank_bg
		self.only_active_vertex_group = props_wt.only_active_vertex_group
		self.modifier_apply = props_wt.modifier_apply
		self.vert_mapping = props_wt.vert_mapping
		self.use_max_distance = props_wt.use_max_distance
		self.max_distance = props_wt.max_distance
		self.ray_radius = props_wt.ray_radius
		self.mix_factor = props_wt.mix_factor
		self.mix_mode = props_wt.mix_mode
		self.use_object_transform = props_wt.use_object_transform
		# self.return_active_select_on_exit = props_wt.return_active_select_on_exit

		self.is_ctrl = False
		if self.is_only_select_button:
			self.only_select = True

		if event.ctrl:
			self.is_ctrl = True
			self.modifier_apply = True

		self.old_mode = None


		return self.execute(context)


	def execute(self, context):
		props_wt = bpy.context.scene.lazyweight.weight_transfer

		act_obj = bpy.context.view_layer.objects.active
		if act_obj.mode == "EDIT":
			self.old_mode = act_obj.mode
			bpy.ops.object.mode_set(mode="OBJECT")


		for selsrc_obj in bpy.context.selected_objects:
			if not selsrc_obj.type == "MESH":
				continue
			if selsrc_obj == act_obj:
				continue
			# bpy.context.view_layer.objects.active = selsrc_obj
			old_actindex = selsrc_obj.vertex_groups.active_index
			blank_vg = False
			if not selsrc_obj.vertex_groups:
				blank_vg = True


			# add blank vg:
			self.add_blank_vg(act_obj, selsrc_obj)


			# mask vg
			mask_vg = None
			if self.only_select:
				mask_vg = act_obj.vertex_groups.new(name="__select_mask__")
				v_l = [i.index for i in act_obj.data.vertices if i.select]
				mask_vg.add(v_l,1.0,"ADD")
			if not blank_vg:
				act_obj.vertex_groups.active_index = old_actindex


			# DATA_TRANSFER
			self.add_mod_transfer(act_obj ,selsrc_obj,mask_vg)
			bpy.ops.object.mode_set(mode="WEIGHT_PAINT")

		# if self.return_active_select_on_exit:
		# 	bpy.context.view_layer.objects.active = act_obj

		if self.old_mode:
			bpy.ops.object.mode_set(mode=self.old_mode)
			self.old_mode = None

		# 設定を保存
		self.after_set_properties()


		return {'FINISHED'}


	def add_blank_vg(self, act_obj, selsrc_obj):
		if self.add_blank_bg:
			is_all_copy = False
			if act_obj.vertex_groups:
				is_all_copy = True

			for vg in selsrc_obj.vertex_groups:
				if is_all_copy:
					if not vg.name in act_obj.vertex_groups:
						if self.only_active_vertex_group:
							if vg.name == act_obj.vertex_groups.active.name:
								act_obj.vertex_groups.new(name=vg.name)
						else:
							act_obj.vertex_groups.new(name=vg.name)
				else:
					act_obj.vertex_groups.new(name=vg.name)


	def add_mod_transfer(self, act_obj, selsrc_obj,mask_vg):

		mod = act_obj.modifiers.new(type='DATA_TRANSFER',name="Weight transfer")

		# 一番上に移動
		if len(act_obj.modifiers) > 1:
			modindex = len(act_obj.modifiers) - 1
			for i in range(modindex):
				bpy.ops.object.modifier_move_up(modifier=mod.name)


		# モディファイアの設定
		mod.object = selsrc_obj
		mod.use_vert_data = True
		mod.data_types_verts = {'VGROUP_WEIGHTS'}
		if self.only_select:
			mod.vertex_group = mask_vg.name

		mod.mix_mode = self.mix_mode
		mod.mix_factor = self.mix_factor
		mod.vert_mapping = self.vert_mapping
		mod.use_max_distance = self.use_max_distance
		mod.max_distance = self.max_distance
		mod.ray_radius = self.ray_radius
		mod.use_object_transform = self.use_object_transform

		if self.only_active_vertex_group:
			tgt_act_vg = selsrc_obj.vertex_groups.active
			try:
				mod.layers_vgroup_select_src = tgt_act_vg.name
			except:
				self.report({'WARNING'}, "'%s' could not be set" % tgt_act_vg.name)


		if self.modifier_apply:
			bpy.ops.object.modifier_apply(modifier=mod.name)
			self.report({'INFO'}, "Apply Weight Transfer Modifier")

			if self.only_select:
				act_obj.vertex_groups.remove(mask_vg)


	def after_set_properties(self):
		props_wt = bpy.context.scene.lazyweight.weight_transfer

		if not self.is_only_select_button:
			props_wt.only_select = self.only_select

		props_wt.add_blank_bg = self.add_blank_bg
		props_wt.only_active_vertex_group = self.only_active_vertex_group
		if not self.is_ctrl:
			props_wt.modifier_apply = self.modifier_apply

		props_wt.vert_mapping = self.vert_mapping
		props_wt.use_max_distance = self.use_max_distance
		props_wt.max_distance = self.max_distance
		props_wt.ray_radius = self.ray_radius
		props_wt.mix_factor = self.mix_factor
		props_wt.mix_mode = self.mix_mode
		props_wt.use_object_transform = self.use_object_transform
		# props_wt.return_active_select_on_exit = self.return_active_select_on_exit
