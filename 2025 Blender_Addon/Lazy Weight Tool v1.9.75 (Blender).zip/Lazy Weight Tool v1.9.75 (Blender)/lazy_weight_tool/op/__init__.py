import bpy


from .op_brush import *
from .op_display_index import *
from .op_other import *
from .op_select import *
from .op_set_weight import *
from .op_table import *
from .op_vgroup import *
from .op_weight_transfer import *
from .op_copype import *
from .op_adjust_weight_gesture import *



classes = (
LAZYWEIGHT_OT_mesh_deselect_active_vertex,
# LAZYWEIGHT_OT_new_weight_set,
LAZYWEIGHT_OT_adjust_weight_gesture,
LAZYWEIGHT_OT_clipboard_export,
LAZYWEIGHT_OT_convert_bone_to_mesh,
LAZYWEIGHT_OT_copy_weight,
LAZYWEIGHT_OT_index_display,
LAZYWEIGHT_OT_paste_weight,
LAZYWEIGHT_OT_remove_0_vertex,
LAZYWEIGHT_OT_select_edgeloop_click,
LAZYWEIGHT_OT_select_edgeloop,
LAZYWEIGHT_OT_select_half,
LAZYWEIGHT_OT_select_less,
LAZYWEIGHT_OT_select_link,
LAZYWEIGHT_OT_select_mirror,
LAZYWEIGHT_OT_select_more,
LAZYWEIGHT_OT_select_multiLoop,
LAZYWEIGHT_OT_set_weight_other,
LAZYWEIGHT_OT_shortest_path_pick,
LAZYWEIGHT_OT_table_add_v_weight,
LAZYWEIGHT_OT_table_other,
LAZYWEIGHT_OT_table_remove_v_weight,
LAZYWEIGHT_OT_vertex_groups_generate_blank_vg,
LAZYWEIGHT_OT_vertex_groups_set_actvg_of_selobjs,
LAZYWEIGHT_OT_vgroup_active_select_move,
LAZYWEIGHT_OT_vgroup_add_weightmix_apply,
LAZYWEIGHT_OT_vgroup_add_weightmix_remove,
LAZYWEIGHT_OT_vgroup_add_weightmix_rename,
LAZYWEIGHT_OT_vgroup_add_weightmix,
LAZYWEIGHT_OT_vgroup_AddSymmetry,
LAZYWEIGHT_OT_vgroup_ApplyDynamicPaint,
LAZYWEIGHT_OT_vgroup_batch_rename,
LAZYWEIGHT_OT_vgroup_lock_toggle,
LAZYWEIGHT_OT_vgroup_RemoveEmpty,
LAZYWEIGHT_OT_vgroup_round_weight,
LAZYWEIGHT_OT_vgroup_set_active,
LAZYWEIGHT_OT_weight_brush_add,
LAZYWEIGHT_OT_weight_brush_mix,
LAZYWEIGHT_OT_weight_brush_set,
LAZYWEIGHT_OT_weight_brush_sub,
LAZYWEIGHT_OT_weight_set,
LAZYWEIGHT_OT_weight_transfer_modifier_add,
LAZYWEIGHT_OT_bone_select_in_hierarchy_menu,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)


def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)


if __name__ == "__main__":
	register()
