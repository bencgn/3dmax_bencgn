import bpy, time
import numpy as np
from bpy.types import Operator
from bpy.props import *
from mathutils import Vector, kdtree
from .op_other import set_weight_option_menu, set_actvg_of_selobjs
from ..utils import get_symmetry_option,  preference


class LAZYWEIGHT_OT_weight_set(Operator):
	bl_idname = "lazyweight.set_weight"
	bl_label = "Set Weight"
	bl_description = "Set weight values ​​to selected vertices.\nIn edit mode, it works for selected vertices of all multiple objects"
	bl_options = {'REGISTER', 'UNDO'}

	weight : FloatProperty(default=0, name = "Value",min=0,max=1.0)

	items = [
	("Deform Pose Bone", "Deform Pose Bone","Deform Bone Only\nBone must be selected", "BONE_DATA",1),
	("Selected Pose Bone", "Selected Pose Bone","Select Bone\nBone must be selected", "MOD_SIMPLEDEFORM",2),
	("All", "All","All", "RNA_ADD",3),
	("Active", "Active","Active", "RNA",4),
	("None", "None","None", "RADIOBUT_OFF",5),
		]

	normalize : EnumProperty(default="Deform Pose Bone",items=items, name="Normalize")
	normalize_lock_active : BoolProperty(default=True,name="Lock Active")
	items = [
		("REPLACE", "Replace", "", 1),
		("ADD", "Add", "", 2),
		("SUBTRACT", "Subtract", "", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Mix Mode")

	items = [
		("NONE", "None", "", 0),
		("REPLACE", "Replace", "", 1),
		("ADD", "Add", "", 2),
		("SUBTRACT", "Subtract", "", 3),
		]
	type_another_mode : EnumProperty(default="NONE",items=items, name="Mix Mode")

	items = [
		("NONE","None","","RADIOBUT_OFF",0),
		("ACTIVE","Active Vertex Group","","DOT",1),
		("ALL","All Vertex Groups","","SNAP_VERTEX",2),
		]
	set_weight_clean_mode : EnumProperty(default="ACTIVE",items=items, name="Clean",description="Remove Cvertex group assignments which are not required")
	set_weight_clean_limit : FloatProperty(name="Limit",min=0,max=0.99)
	set_weight_clean_keep_single : BoolProperty(name="Keep Single")
	use_symmetry_x : BoolProperty(name="Symmetry X")
	use_symmetry_y : BoolProperty(name="Symmetry Y")
	use_symmetry_z : BoolProperty(name="Symmetry Z")
	symmetry_dist : FloatProperty(name="Symmetry Distance",description="Allowable distance of vertices for symmetry", default=0.001, min=0, step=0.01, precision=4,subtype="DISTANCE")
	set_actvg_of_selobjs : BoolProperty(name="Switch the Active VG of the SelObjs to the Same",description="Set the active vertex group of the selected object the same name as the active vertex group of the active object.\nIt works if you have a vertex group with the same name")
	is_multi_objs : BoolProperty()


	def invoke(self, context,event):
		wpaint = bpy.context.scene.tool_settings.weight_paint
		props = bpy.context.scene.lazyweight
		self.old_time = time.time()



		if not self.type_another_mode == "NONE":
			self.type = self.type_another_mode
		else:
			self.type = props.type
		self.normalize = props.normalize

		self.set_weight_clean_mode = props.set_weight_clean_mode
		self.set_weight_clean_limit = props.set_weight_clean_limit
		self.set_weight_clean_keep_single = props.set_weight_clean_keep_single
		self.symmetry_dist = props.symmetry_dist

		if bpy.app.version >= (2,91,0):
			obj = bpy.context.object
			self.use_symmetry_x = obj.data.use_mirror_x
			self.use_symmetry_y = obj.data.use_mirror_y
			self.use_symmetry_z = obj.data.use_mirror_z
		else:
			wpaint = bpy.context.scene.tool_settings.weight_paint
			self.use_symmetry_x = wpaint.use_symmetry_x
			self.use_symmetry_y = wpaint.use_symmetry_y
			self.use_symmetry_z = wpaint.use_symmetry_z



		self.kd_dic = {}
		self.old_act = bpy.context.view_layer.objects.active
		self.old_mode = self.old_act.mode

		for obj in bpy.context.selected_objects:
			if not obj.type == "MESH":
				continue

			bpy.context.view_layer.objects.active = obj
			obj_dic = {}
			bm_v = obj.data.vertices
			size = len(bm_v)

			kd_local = kdtree.KDTree(size)
			for i, v in enumerate(bm_v):
				kd_local.insert(v.co, i)
			kd_local.balance()

			obj_dic["kd_local"] = kd_local
			self.kd_dic[obj.name] = obj_dic


		return self.execute(context)


	def draw(self, context):
		set_weight_option_menu(self,context,self,True)


	def execute(self, context):
		addon_prefs = preference()
		props = bpy.context.scene.lazyweight


		# 複数選択の場合
		if len(bpy.context.selected_objects) >= 2 and bpy.context.object.mode == "EDIT":
			obj_l = bpy.context.selected_objects
			self.is_multi_objs = True


			# 実行前に、自動でアクティブと同じ頂点グループを他の選択オブジェクトでも選択する
			if props.auto_set_actvg_of_selobjs:
				if len(bpy.context.selected_objects) >= 2:
					set_actvg_of_selobjs()

		else:
			obj_l = [bpy.context.object]
			self.is_multi_objs = False


		# アクティブ頂点グループ名を取得
		actvg_name = ""
		if len(obj_l) >= 2:
			if self.old_act.type == "MESH":
				if self.old_act.vertex_groups:
					actvg_name = self.old_act.vertex_groups.active.name


		# 選択オブジェクトを回す
		for obj in obj_l:
			if not obj.type == "MESH":
				continue
			bpy.context.view_layer.objects.active = obj

			# オブジェクトモードにする
			if not self.old_mode in {"WEIGHT_PAINT", "OBJECT"}:
				bpy.ops.object.mode_set(mode="OBJECT")

			# なければ頂点グループを追加
			self.add_blank_vg(obj)

			# アクティブ選択を切り替え
			if not obj == self.old_act:
				if self.set_actvg_of_selobjs:
					if len(obj_l) >= 2:
						if obj.vertex_groups:
							if actvg_name in obj.vertex_groups:
								obj.vertex_groups.active = obj.vertex_groups[actvg_name]


			act_vg = obj.vertex_groups.active
			v_all = obj.data.vertices
			v_index_l = [v.index for v in v_all if v.select]
			old_sel_l = v_index_l


			# Xミラーの場合は反対側の頂点名を探す
			x_mirror_vg_l = []
			if self.old_act.data.use_mirror_vertex_groups and self.use_symmetry_x:
				v_index_l, x_mirror_vg_l = self.set_x_mirror_weight(obj, act_vg, v_all, v_index_l)

				# 正規化
				self.weight_normalize(v_all, v_index_l, False)

				# Xミラーの頂点グループがある場合は、それに一時的に切り替えて再度正規化を実行
				if x_mirror_vg_l:
					obj.vertex_groups.active = x_mirror_vg_l[0]
					self.weight_normalize(v_all, v_index_l, True)
					obj.vertex_groups.active = act_vg

			else:
				# シンメトリの頂点インデックスをリストに追加
				v_index_l = self.add_symmetry_vindex(obj, v_all,v_index_l)

				# ウェイトを割り当て
				act_vg.add(index=v_index_l,weight=self.weight,type=self.type)


				# 正規化
				self.weight_normalize(v_all, v_index_l, False)



			# 掃除
			if not self.set_weight_clean_mode == "NONE":
				bpy.ops.object.vertex_group_clean(
					group_select_mode=self.set_weight_clean_mode,
					limit=self.set_weight_clean_limit,
					keep_single=self.set_weight_clean_keep_single
					)



		bpy.context.view_layer.objects.active = self.old_act


		# モードを戻す
		if not self.old_act.mode == self.old_mode:
			bpy.ops.object.mode_set(mode=self.old_mode)


		# self.PropertyをシーンPropertyに設定
		self.after_set_properties(self.old_act)


		time_text = time.time() - self.old_time
		self.report({'INFO'}, "Process Time [%s]" % str(round(time_text,2)))

		return {'FINISHED'}


	# 空の頂点グループを追加
	def add_blank_vg(self,obj):
		if not obj.vertex_groups:
			bpy.ops.object.vertex_group_add()
			obj.vertex_groups.active_index = 0

		if not obj.vertex_groups.active:
			if bpy.context.active_pose_bone:
				bone_name = bpy.context.active_pose_bone.name
				vg_name = [vg.name for vg in obj.vertex_groups]
				if not bone_name in vg_name:
					obj.vertex_groups.new(name=bone_name)
					obj.vertex_groups.active_index = len(obj.vertex_groups) - 1
			else:
				bpy.ops.object.vertex_group_add()
				obj.vertex_groups.active_index = len(obj.vertex_groups) - 1


	# シンメトリの頂点インデックスをリストに追加
	def add_symmetry_vindex(self, obj, v_all,v_index_l):
		if not (self.use_symmetry_x or self.use_symmetry_y or self.use_symmetry_z):
			return v_index_l

		x_minus = 1
		y_minus = 1
		z_minus = 1

		if self.use_symmetry_x:
			x_minus = -1
		if self.use_symmetry_y:
			y_minus = -1
		if self.use_symmetry_z:
			z_minus = -1

		# kdtree を利用して、リストにミラー頂点のインデックスを追加
		for v in v_all:
			if v.select:
				co, index, dist = self.kd_dic[obj.name]["kd_local"].find(Vector((v.co[0] * x_minus, v.co[1] * y_minus, v.co[2] * z_minus)))
				if dist <= self.symmetry_dist:
					v_index_l += [index]

		return v_index_l


	# ミラーウェイトを設定
	def set_x_mirror_weight(self, obj, act_vg, v_all, v_index_l):
		addon_prefs = preference()
		props = bpy.context.scene.lazyweight

		# 通常のウェイトを割り当て
		act_vg.add(index=v_index_l,weight=self.weight,type=self.type)

		# 反対側のウェイト名を探す
		namesets = eval(addon_prefs.mirror_vg_namesets)
		used_mirror_vg = False
		x_mirror_vg_l = []
		for ns in namesets:  # ('.L','.R'),('_L','_R')
			sym_name = "" # 反対側の名前
			if ns[0] in act_vg.name: # L > R
				sym_name = act_vg.name.replace(ns[0],ns[1])
			elif ns[1] in act_vg.name: # R > L
				sym_name = act_vg.name.replace(ns[1],ns[0])

			# 反対ウェイトがあった場合は、反対側にウェイトを割り当て
			if sym_name in obj.vertex_groups:
				sym_vg = obj.vertex_groups[sym_name]
				v_index_l = self.add_symmetry_vindex(obj, v_all,[])
				sym_vg.add(index=v_index_l,weight=self.weight,type=self.type)
				used_mirror_vg = True
				x_mirror_vg_l += [sym_vg]


		if not used_mirror_vg:
			v_index_l = self.add_symmetry_vindex(obj, v_all,[])
			act_vg.add(index=v_index_l,weight=self.weight,type=self.type)


		return v_index_l, x_mirror_vg_l


	# 正規化
	def weight_normalize(self, v_all, v_index_l, use_x_mirror):
		# # オペレーター実行用に一時的にミラー部分を選択
		if use_x_mirror:
			if not self.normalize == "None":
				if (self.use_symmetry_x or self.use_symmetry_y or self.use_symmetry_z):

					# 選択を保存
					np_old_sel = np.zeros(len(v_all), dtype=np.bool)
					v_all.foreach_get('select', np_old_sel)

					# 選択解除
					np_desel_l = [False] * len(v_all)
					v_all.foreach_set('select', np_desel_l)

					# ミラーを選択
					for i in v_index_l:
						v_all[i].select = True



		# 正規化オペレーターを実行
		if self.normalize == "Active":
			bpy.ops.object.vertex_group_normalize()


		elif self.normalize == "All":
			bpy.ops.object.vertex_group_normalize_all(group_select_mode="ALL",lock_active=self.normalize_lock_active)


		elif self.normalize == "Deform Pose Bone":
			try:
				bpy.ops.object.vertex_group_normalize_all(group_select_mode="BONE_DEFORM",lock_active=self.normalize_lock_active)
			except:
				self.report({'INFO'}, "Normalize 'Deform Pose Bone' Optin failed. Pose Bone must be selected.")


		elif self.normalize == "Selected Pose Bone":
			try:
				bpy.ops.object.vertex_group_normalize_all(group_select_mode="BONE_SELECT",lock_active=self.normalize_lock_active)
			except:
				self.report({'INFO'}, "Normalize 'Selected Pose Bone' Optin failed. Pose Bone must be selected.")



		# ミラー選択を戻す
		if use_x_mirror:
			if not self.normalize == "None":
				if (self.use_symmetry_x or self.use_symmetry_y or self.use_symmetry_z):
					# 選択解除
					v_all.foreach_set('select', np_desel_l)
					# 選択を戻す
					v_all.foreach_set('select', np_old_sel)


	def after_set_properties(self, obj):
		props = bpy.context.scene.lazyweight

		if self.type_another_mode == "NONE":
			props.type = self.type
		props.normalize = self.normalize
		props.set_weight_clean_mode = self.set_weight_clean_mode
		props.set_weight_clean_limit = self.set_weight_clean_limit
		props.set_weight_clean_keep_single = self.set_weight_clean_keep_single
		props.symmetry_dist = self.symmetry_dist

		if bpy.app.version >= (2,91,0):
			obj.data.use_mirror_x = self.use_symmetry_x
			obj.data.use_mirror_y = self.use_symmetry_y
			obj.data.use_mirror_z = self.use_symmetry_z
		else:
			wpaint = bpy.context.scene.tool_settings.weight_paint
			wpaint.use_symmetry_x = self.use_symmetry_x
			wpaint.use_symmetry_y = self.use_symmetry_y
			wpaint.use_symmetry_z = self.use_symmetry_z
