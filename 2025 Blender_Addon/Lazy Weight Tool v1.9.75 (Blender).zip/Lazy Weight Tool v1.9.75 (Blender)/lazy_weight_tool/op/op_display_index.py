import bpy, bmesh, blf
import gpu
import bgl
from bgl import *
import bpy_extras.view3d_utils

from bpy.props import *
from bpy.types import Operator
from ..utils import preference
 

class LAZYWEIGHT_OT_index_display(Operator):
	bl_idname = "lazyweight.index_display"
	bl_label = "Display Index"
	bl_options = {'REGISTER', 'UNDO'}

	bl_description = ""

	draw_index_handler = None

	def invoke(self, context, event):
		sc = context.scene
		props = bpy.context.scene.lazyweight


		if context.area.type == 'VIEW_3D':
			# スタート
			if props.vindex_is_running:
				LAZYWEIGHT_OT_index_display.draw_index_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_index_text, (context, ), "WINDOW", "POST_PIXEL")


			# エンド
			else:
				if LAZYWEIGHT_OT_index_display.draw_index_handler is not None:
					bpy.types.SpaceView3D.draw_handler_remove(LAZYWEIGHT_OT_index_display.draw_index_handler, "WINDOW")



			# 画面更新
			if context.area:
				context.area.tag_redraw()
			return {'FINISHED'}

		else:
			return {'CANCELLED'}



	def draw_index_text(self, context):
		prefs = preference()
		props = bpy.context.scene.lazyweight
		sc = context.scene

		if not bpy.context.view_layer.objects.active:
			context.area.tag_redraw()
			return {'RUNNING_MODAL'}


		# モディファイアーを考慮したオブジェクトを取得
		depsgraph = bpy.context.evaluated_depsgraph_get()
		obj = bpy.context.view_layer.objects.active
		obj = obj.evaluated_get(depsgraph)
		matrix_world = obj.matrix_world

		if not obj.type == "MESH":
			context.area.tag_redraw()
			return {'RUNNING_MODAL'}

		# 条件に当てはまらないものはスルー #
		# スルー ここまで #



		# if not props.vindex_use_other_mode:
		# 	# 編集モードではなく、ユーズ編集である
		# 	if not bpy.context.mode in {"EDIT_MESH", "WEIGHT_PAINT"} and props.vindex_use_edit_mode:
		# 		context.area.tag_redraw()
		# 		return {'RUNNING_MODAL'}
		#
		# else:
		# 	if not bpy.context.mode == "EDIT_MESH":
		# 		bm = obj.data
		# 		bm_v = bm.vertices
		bm_v = None
		if obj.mode == "WEIGHT_PAINT":
			if obj.data.use_paint_mask_vertex == False:
				context.area.tag_redraw()
				return {'RUNNING_MODAL'}
			bm = obj.data
			bm_v = bm.vertices

		elif obj.mode == "EDIT" and props.vindex_use_edit_mode:
			bm: bmesh.types.BMesh = bmesh.from_edit_mesh(obj.data)
			bm_v = bm.verts
			bm_e = bm.edges
			bm_f = bm.faces

			if not bm_v or not bm_e or not bm_f: # 空ならパス
				context.area.tag_redraw()
				return {'RUNNING_MODAL'}


		if not bm_v: # 空ならパス
			context.area.tag_redraw()
			return {'RUNNING_MODAL'}

		rh = context.region.height
		rw = context.region.width

		font_id = 0
		font_size = prefs.index_font_size


		#Set font color
		bgl.glEnable(bgl.GL_BLEND)
		col_0 = prefs.index_text_color[0]
		col_1 = prefs.index_text_color[1]
		col_2 = prefs.index_text_color[2]
		col_3 = prefs.index_text_color[3]
		blf.color(0, col_0, col_1, col_2, col_3)

		bgl.glLineWidth(2)

		#Draw text
		p_x  = 0
		p_y  = 0
		v_index = ""
		col_size = -30
		blf.size(font_id, font_size, 72)

		r = bpy.context.region
		rv3d = bpy.context.space_data.region_3d

		if bpy.context.mode == "EDIT_MESH" and props.vindex_use_edit_mode:
			sel_mode = bpy.context.tool_settings.mesh_select_mode

			if sel_mode[0]:
				for item in bm_v:
					render_text(item,font_id,font_size,col_size,p_x,p_y,v_index,r,rv3d,matrix_world,item.co)

			if sel_mode[1]:
				for item in bm_e:
					item_co = (item.verts[0].co + item.verts[1].co) / 2
					render_text(item,font_id,font_size,col_size,p_x,p_y,v_index,r,rv3d,matrix_world,item_co)

			if sel_mode[2]:
				for item in bm_f:
					item_co = item.calc_center_median()
					render_text(item,font_id,font_size,col_size,p_x,p_y,v_index,r,rv3d,matrix_world,item_co)

		else:
			for item in bm_v:
				render_text(item,font_id,font_size,col_size,p_x,p_y,v_index,r,rv3d,matrix_world,item.co)


		# restore opengl defaults
		bgl.glLineWidth(1)
		blf.color(0, 0.0, 0.0, 0.0, 1.0)
		bgl.glDisable(bgl.GL_BLEND)



def render_text(item,font_id,font_size,col_size,p_x,p_y,v_index,r,rv3d,matrix_world,item_co):
	if item.select:

		p = bpy_extras.view3d_utils.location_3d_to_region_2d(
			r, rv3d, matrix_world @ item_co)

		p_x = p.x
		p_y = p.y - 130
		v_index = str(item.index)

	blf.position(font_id, p_x, p_y + (col_size*-5) - font_size, 0)
	blf.draw(font_id, v_index)
