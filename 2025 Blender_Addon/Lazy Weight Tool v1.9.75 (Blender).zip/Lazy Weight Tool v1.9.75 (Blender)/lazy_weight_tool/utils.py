import bpy

def preference():
	preference = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

	return preference


def get_symmetry_option(obj):
	if bpy.app.version >= (2,91,0):
		symmetry_x = obj.data.use_mirror_x
		symmetry_y = obj.data.use_mirror_y
		symmetry_z = obj.data.use_mirror_z
	else:
		wpaint = bpy.context.scene.tool_settings.weight_paint
		symmetry_x = wpaint.use_symmetry_x
		symmetry_y = wpaint.use_symmetry_y
		symmetry_z = wpaint.use_symmetry_z

	return symmetry_x, symmetry_y, symmetry_z


def draw_mod_vg_mix(item,layout):
	addon_prefs = preference()

	if not addon_prefs.ui.show_mod_vg_mix_menu:
		return

	mod_w_mix_l = []
	obj = item.id_data

	if not obj.modifiers:
		return
	mod_w_mix_l = [m for m in obj.modifiers if m.type == "VERTEX_WEIGHT_MIX" if m.vertex_group_a == item.name]

	for mod in mod_w_mix_l:
		box = layout.box()
		row_main = box.row(align=True)
		hlt_emboss = bool(obj.vertex_groups.active.name == mod.vertex_group_b)
		if mod.vertex_group_b:
			row_main.operator("lazyweight.vgroup_set_active",text="",icon="RESTRICT_SELECT_OFF",emboss=hlt_emboss).name=mod.vertex_group_b
		else:
			row_main.label(text="",icon="BLANK1")
		row_main.separator()

		box_col = row_main.column(align=True)
		sp = box_col.split(factor=0.5)
		row = sp.row(align=True)
		row.prop_search(mod, "vertex_group_b", obj, "vertex_groups",text="")
		op = row.operator("lazyweight.vgroup_add_weightmix_rename",text="",icon="SYNTAX_OFF",emboss=False)
		op.modifier = mod.name

		row = sp.row(align=True)
		row.alignment="RIGHT"
		row.prop(mod,"show_viewport",text="")
		row.prop(mod,"show_render",text="")
		row.separator()
		row.operator("lazyweight.vgroup_add_weightmix_apply",text="",icon="FILE_TICK",emboss=False).modifier=mod.name
		row.operator("lazyweight.vgroup_add_weightmix_remove",text="",icon="X",emboss=False).modifier=mod.name

		# if len(obj.modifiers) > 1:
		col = row.column(align=True)
		col.scale_y = .5
		op = col.operator("object.modifier_move_up",text="",icon="LAYER_ACTIVE",emboss=False)
		op.modifier=mod.name
		op = col.operator("object.modifier_move_down",text="",icon="LAYER_USED",emboss=False)
		op.modifier=mod.name

		row = box_col.row(align=True)
		row.label(text="",icon="MOD_VERTEX_WEIGHT")
		sp = row.split(align=True,factor=0.3)
		sp.prop(mod,"mix_mode",text="")
		sp.prop(mod,"mask_constant",text="")
		layout.separator()
