import bpy
from bpy.types import PropertyGroup
from bpy.props import *
from .ui.def_regi_panel import *


def update_index_is_running(self,context):
	props = bpy.context.scene.lazyweight
	bpy.ops.lazyweight.index_display("INVOKE_DEFAULT")


class LAZYWEIGHT_PR_copype(PropertyGroup):
	clipboard : StringProperty(name="Clipboard")


	items = [
	("SINGLE","Single","Paste single vertex weights","RADIOBUT_ON",0),
	("ORIENTATION_LOCAL","Local","Paste weights for close vertices relative to the object's local coordinates.\nYou can paste exactly for meshes with the same vertex position relative to the origin","ORIENTATION_LOCAL",1),
	("ORIENTATION_GLOBAL","Global","Paste weights for close vertices relative to global coordinates.\nYou can paste exactly for close meshes regardless of the origin of the object","ORIENTATION_GLOBAL",2),
	("INDEX","Index","Paste weights for vertices with the same vertex index","IPO_SINE",3),
	]
	mode : EnumProperty(default="ORIENTATION_LOCAL",name = "Mode", items= items)

	items = [
		("REPLACE", "Replace","'Replace' existing weights", "IMPORT", 1),
		("ADD", "Add","'Add' existing weights", "ADD", 2),
		("SUBTRACT", "Subtract","'Subtract' existing weights", "REMOVE", 3),
		]
	mix_mode : EnumProperty(default="REPLACE",items=items, name="Mix Mode",description="Blend mode for existing weights")
	distance : FloatProperty(name="Distance",description="How close vertices are near",min=0,default=0.1,step=1,subtype="DISTANCE")
	weight_strength : FloatProperty(name="Strength",description="Adjust the value of the weight to be pasted. This value will be multiplied",min=0,default=1,step=0.1,precision=3,soft_max=1)
	add_blank_bg : BoolProperty(name="Generate Data Layers",default=True,description="If there is no destination vertex group, a new one will be created")
	find_type : EnumProperty(default="find",name = "Find Type", items= [ ("find","One Point","Find nearest one point"), ("find_range","Range","Find all points within radius.\nThis is useful when there are multiple vertices at overlapping positions") ])


class LAZYWEIGHT_PR_weight_transfer(PropertyGroup):
	only_select : BoolProperty(name="Only Selected",description="Transfer weights only to the selected vertex")
	add_blank_bg : BoolProperty(name="Generate Data Layers",default=True,description="If there is no destination vertex group, a new one will be created")
	only_active_vertex_group : BoolProperty(name="Only Active Vertex Group")
	modifier_apply : BoolProperty(name="Apply Modifier")

	items = [
	("TOPOLOGY","Topology","Copy from identical topology meshes","MESH_DATA",0),
	("NEAREST","Nearest Vertex","Copy from closest vertex","VERTEXSEL",1),
	("EDGE_NEAREST","Nearest Edge Vertex","Copy from closest vertex of closest edge","EDGESEL",2),
	("EDGEINTERP_NEAREST","Nearest Edge Interpolated","Copy from interpolated values of vertices from closest point on closest edge","EDGESEL",3),
	("POLY_NEAREST","Nearest Face Vertex","Copy from closest vertex of closest face","FACESEL",4),
	("POLYINTERP_NEAREST","Nearest Face Interpolated","Copy from interpolated values of vertices from closest point on closest face","MOD_UVPROJECT",5),
	("POLYINTERP_VNORPROJ","Projected Face Interpolated","Copy from interpolated values of vertices from point on closest face hit by normal-projection","MOD_UVPROJECT",6),
	]
	vert_mapping : EnumProperty(name = "Mapping", items=items,default="NEAREST",)
	use_max_distance : BoolProperty(name="Use Max Distance")
	max_distance : FloatProperty(name="Max Distance",default=1,min=0,subtype="DISTANCE")
	ray_radius : FloatProperty(name="Ray Radius",default=0,min=0,subtype="DISTANCE")
	mix_factor : FloatProperty(name="Mix Factor",default=1,min=0,max=1)
	items = [
		("REPLACE","Replace","Overwrite all elements’ data","ADD",0),
		("ABOVE_THRESHOLD","Above Threshold","Only replace destination elements where data is above given threshold (exact behavior depends on data type)","SORT_DESC",1),
		("BELOW_THRESHOLD","Below Threshold","Only replace destination elements where data is below given threshold (exact behavior depends on data type)","SORT_ASC",2),
		("MIX","Mix","Mix source value into destination one, using given threshold as factor","SELECT_EXTEND",3),
		("ADD","Add","Add source value to destination one, using given threshold as factor","ADD",4),
		("SUB","Subtract","Subtract source value to destination one, using given threshold as factor","REMOVE",5),
		("MUL","Multiply","Multiply source value to destination one, using given threshold as factor","XRAY",6),
		]
	mix_mode : EnumProperty(default="REPLACE",items=items, name="Mix Mode")
	use_object_transform : BoolProperty(name="Object Transform",description="Evaluate source and destination meshes in global space",default=True)
	# return_active_select_on_exit : BoolProperty(name="Return active selection on exit")


class LAZYWEIGHT_PR_ui(PropertyGroup):
	ui_main_select                : BoolProperty(name="Select")
	ui_main_3column_vg               : BoolProperty(name="3-Column Vertex Group")
	ui_main_v_table               : BoolProperty(name="Table")
	ui_main_weight_set            : BoolProperty(name="Set Weight",default=True)
	ui_main_operator              : BoolProperty(name="Operator")
	ui_main_weight_transfer       : BoolProperty(name="Weight Transfer")
	ui_main_copype                : BoolProperty(name="Copy / Paste")
	toggle_menu_weight_transfer : BoolProperty(name="Option")
	copype_clipboard : BoolProperty(name="Clipboard")


	hierarchy_color_0 : FloatVectorProperty(name="Color 0", subtype='COLOR', default=(0.356400, 0.144128, 0.029556), min=0.0, max=1.0)
	hierarchy_color_1 : FloatVectorProperty(name="Color 1", subtype='COLOR', default=(0.341914, 0.356400, 0.029556), min=0.0, max=1.0)
	hierarchy_color_2 : FloatVectorProperty(name="Color 2", subtype='COLOR', default=(0.138432, 0.356400, 0.029556), min=0.0, max=1.0)
	hierarchy_color_3 : FloatVectorProperty(name="Color 3", subtype='COLOR', default=(0.029556, 0.356400, 0.109462), min=0.0, max=1.0)
	hierarchy_color_4 : FloatVectorProperty(name="Color 4", subtype='COLOR', default=(0.029556, 0.356400, 0.356400), min=0.0, max=1.0)
	hierarchy_color_5 : FloatVectorProperty(name="Color 5", subtype='COLOR', default=(0.029556, 0.135633, 0.356400), min=0.0, max=1.0)
	hierarchy_color_6 : FloatVectorProperty(name="Color 6", subtype='COLOR', default=(0.158961, 0.029556, 0.356400), min=0.0, max=1.0)
	hierarchy_color_7 : FloatVectorProperty(name="Color 7", subtype='COLOR', default=(0.356400, 0.029556, 0.144128), min=0.0, max=1.0)
	hierarchy_menu_scroll : IntProperty(name="Scroll",min=0)
	hierarchy_menu_range : IntProperty(name="Range",min=0,default=20)
	vgroup_use_bone_hierarchy : BoolProperty(name="Use Bone Hierarchy Display")
	show_mod_vg_mix_menu : BoolProperty(name="Show Weight Mix Modifier Menu",default=True)


	usepanel_3column_vg : BoolProperty(name="3-Column Vertex Group", default=True,update=update_regipanel_3column_vg)
	usepanel_copype : BoolProperty(name="Copy / Paste", default=True,update=update_regipanel_copype)
	usepanel_operator : BoolProperty(name="Operator", default=True,update=update_regipanel_operator)
	usepanel_select : BoolProperty(name="Select", default=True,update=update_regipanel_select)
	usepanel_weight_transfer : BoolProperty(name="Weight Transfer", default=True,update=update_regipanel_weight_transfer)
	usepanel_table : BoolProperty(name="Table", default=True,update=update_regipanel_table)
	usepanel_vertex_groups : BoolProperty(name="Vertex Groups", default=True,update=update_regipanel_vertex_groups)


class LAZYWEIGHT_PR_vg(PropertyGroup):
	colle_name : StringProperty(name="Colle Name")


class LAZYWEIGHT_PR_bone(PropertyGroup):
	show_expanded : BoolProperty(name="Show Expanded",default=True)


class LAZYWEIGHT_PR_Other(PropertyGroup):
	weight_transfer : PointerProperty(type=LAZYWEIGHT_PR_weight_transfer)
	copype : PointerProperty(type=LAZYWEIGHT_PR_copype)
	vgroup_empty_to_darken   : BoolProperty(name="Darken empty vertex group",default=True,description="Since unassigned vertex group names are searched from all vertices, the menu display will be slow in the case of high poly mesh")
	vgroup_empty_to_hide   : BoolProperty(name="Hide empty vertex group",description="Since unassigned vertex group names are searched from all vertices, the menu display will be slow in the case of high poly mesh")
	vgroup_empty_only_select   : BoolProperty(name="Target only selected vertices",description="Only unused vertex groups in the selected vertices are searched for empty vertex groups")
	vgroup_hide_by_hide_bone   : BoolProperty(name="Hide hidden bones",description="Hide bones that are hidden in the bone object bind with the armature modifier")
	vgroup_hide_only_select_bone   : BoolProperty(name="Show only selected bones",description="Shows only the bones selected in the bone object bind with the armature modifier")


	filter                       : StringProperty(default="", name="Filter",description="Filter by string. Regular Expressions can be used")
	filter_2_l                   : StringProperty(default="", name="Filter L",description="Filter by string. Regular Expressions can be used")
	filter_2_r                   : StringProperty(default="", name="Filter R",description="Filter by string. Regular Expressions can be used")
	filter_l                     : StringProperty(default="\.L", name="Filter L",description="Filter by string. Regular Expressions can be used")
	filter_r                     : StringProperty(default="\.R", name="Filter R",description="Filter by string. Regular Expressions can be used")


	table_slider                 : BoolProperty(default=True,name="Slider")
	table_filter_hide            : BoolProperty(default=True,name="Exclude hide Vertex")
	table_filter_selected        : BoolProperty(default=True,name="Filter Selected Vertex")
	table_highlight_hitrange     : IntProperty(default=3, name="Hit Range",min=1,max=12,description="Makes the specified number of digits an acceptable range\n(If you want to match the small number of digits, set it larger,\nif it is a rough match, set it smaller)")
	table_highlight_toggle       : BoolProperty(name="Display Highlight",description="Highlight cells that match numbers and settings")
	table_highlight_value        : FloatProperty(default=1.0, name="Value",min=0,max=1.0,description="Highlight cells with the same value.")
	table_scroll                 : IntProperty(name="Scroll", description="Scroll cell position to display",min=0)
	table_scroll_num             : IntProperty(default=20,name="Scroll Num", min=1, description="Blender may crash when displaying too many cells at once.\nDepending on the PC specifications, more than 500 are dangerous")
	table_toggle_filter          : BoolProperty(name="Filter")
	table_ui_add_remove          : BoolProperty(name="Add / Remove Button", description="Add / remove cell weights")
	table_v_obj                  : PointerProperty(name="Obj", type=bpy.types.Object)


	toggle_brush                 : BoolProperty(name="Brush")
	toggle_case_insensitive      : BoolProperty(default=True, name="Case Insensitive",description="Filters in assignment menu are case insensitive")
	toggle_ui_warning            : BoolProperty(name="Warning")
	toggle_weight_volume_setting : BoolProperty(name="Values Setting",description="You can change the default values")
	use_axis                     : BoolProperty(name="UseAxis")
	use_filter                   : BoolProperty(default=True, name="Use Filter")
	use_filter_l                 : BoolProperty(default=True, name="Use Filter L")
	use_filter_r                 : BoolProperty(default=True, name="Use Filter R")
	vindex_is_running            : BoolProperty(name="Display Mesh Vertex Index",update=update_index_is_running,description="the index of the selected vertex is displayed in the 3D view in weight painting mode.\nThis makes it easier to see which vertices are displayed in the weight table.\nSince the index of all selected vertices is displayed, the fewer the number of selected vertices, the easier it is to see")
	vindex_use_edit_mode         : BoolProperty(name="Also Display in Edit Mode")
	vindex_use_other_mode        : BoolProperty(name="Also Display in other modes")
	vindex_use_weightpaint_mode  : BoolProperty(default=True,name="Also Display in Weight Paint Mode")
	weight                       : FloatProperty(default=0.05, name="Another Value",min=0,max=1.0,description="Values ​​other than the above button.\nYou can replace / add / subtract directly from the menu on the right")
	weight_01                    : FloatProperty(default=0.00, name="Value",min=0,max=1.0)
	weight_02                    : FloatProperty(default=0.1,  name="Value",min=0,max=1.0)
	weight_03                    : FloatProperty(default=0.25, name="Value",min=0,max=1.0)
	weight_04                    : FloatProperty(default=0.50, name="Value",min=0,max=1.0)
	weight_05                    : FloatProperty(default=0.75, name="Value",min=0,max=1.0)
	weight_06                    : FloatProperty(default=0.90, name="Value",min=0,max=1.0)
	weight_07                    : FloatProperty(default=1.00, name="Value",min=0,max=1.0)

	items = [
	("Deform Pose Bone", "Deform Pose Bone","Normalize the weight of the 'vertex group used in the deform bone' with the total weight per vertex as 1.0.\nBone must be selected", "BONE_DATA",0),
	("Selected Pose Bone", "Selected Pose Bone","Normalize the weight of the 'vertex group used in the selected bone' with the total weight per vertex as 1.0.\nBone must be selected", "MOD_SIMPLEDEFORM",1),
	("All", "All","Normalize the weights of 'all vertex groups' with the sum of the weights per vertex being 1.0", "RNA_ADD",2),
	("Active", "Active","Normalize the highest value to 1.0 for the 'active vertex group' weight", "RNA",3),
	("None", "None","No normalize", "RADIOBUT_OFF",4),
		]
	normalize : EnumProperty(default="Deform Pose Bone",items=items, name="Normalize")
	normalize_lock_active : BoolProperty(default=True,name="Lock Active")

	items = [
		("NONE","None","","RADIOBUT_OFF",0),
		("ACTIVE","Active Vertex Group","","DOT",1),
		("ALL","All Vertex Groups","","SNAP_VERTEX",2),
		]
	set_weight_clean_mode : EnumProperty(default="NONE",items=items, name="Clean",description="Remove Cvertex group assignments which are not required")
	set_weight_clean_limit : FloatProperty(name="Limit",min=0,max=0.99)
	set_weight_clean_keep_single : BoolProperty(name="Keep Single")



	items = [
		("X", "X", "", 0),
		("Y", "Y", "", 1),
		("Z", "Z", "", 2),
		]
	axis : EnumProperty(default="X",items=items, name="Axis")

	items = [
		("Match", "Match","Same as value", "LAYER_ACTIVE", 0),
		("More", "More","Greater than or equal to value", "SORT_DESC", 1),
		("Less", "Less","Less than or equal to value", "SORT_ASC", 2),
		]
	table_highlight_type : EnumProperty(default="Match",items=items, name="Type")
	table_highlight_emboss : BoolProperty(name="No Emboss")

	#(identifier, name, description, icon, number)
	items = [
		("REPLACE", "Replace","'Replace' existing weights", "IMPORT", 1),
		("ADD", "Add","'Add' existing weights", "ADD", 2),
		("SUBTRACT", "Subtract","'Subtract' existing weights", "REMOVE", 3),
		]
	type : EnumProperty(default="REPLACE",items=items, name="Mix Mode",description="Blend mode for existing weights")
	symmetry_dist : FloatProperty(name="Symmetry Distance",description="Allowable distance of vertices for symmetry", default=0.001, min=0, step=0.01, precision=4,subtype="DISTANCE")
	# symmetry_dist : FloatProperty(name="Symmetry Distance",description="Allowable distance of vertices for symmetry", default=0.001, min=0, step=0.01, precision=0.0001)
	use_symmetry_x : BoolProperty(name="Symmetry X")
	use_symmetry_y : BoolProperty(name="Symmetry Y")
	use_symmetry_z : BoolProperty(name="Symmetry Z")
	set_actvg_of_selobjs : BoolProperty(name="Switch the Active VG of the SelObjs to the Same",description="Set the active vertex group of the selected object the same name as the active vertex group of the active object.\nIt works if you have a vertex group with the same name")


	colle_active_name : StringProperty()

	auto_set_actvg_of_selobjs : BoolProperty(name="Auto switching of active VG of select objs",description="When switching the active vertex group in the set weight function or in the 3-column vertex group menu\nautomatically switch the active vertex group of all selected objects to the same vertex group. \nThis only works in edit mode with multiple objects selected. \nIt is useful when editing weights of parts that are divided into objects at once",default=True)
