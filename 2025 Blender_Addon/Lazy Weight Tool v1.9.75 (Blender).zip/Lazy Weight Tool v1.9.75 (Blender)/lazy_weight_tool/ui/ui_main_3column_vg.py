import bpy, re
from bpy.props import *
from ..utils import preference, draw_mod_vg_mix
from .ui_bone_hierarchy import *

# item
def draw_vgroup_item(col,vgroup,obj,use_vg_l,bone_data):
	props = bpy.context.scene.lazyweight

	if props.vgroup_hide_by_hide_bone:
		if vgroup.name in bone_data:
			bone = bone_data[vgroup.name]
			if bone.bone.hide:
				return
	if props.vgroup_hide_only_select_bone:
		if vgroup.name in bone_data:
			bone = bone_data[vgroup.name]
			if not bone.bone.select:
				return

	props = bpy.context.scene.lazyweight

	sp = col.split(align=True,factor=0.9)
	row = sp.row(align=True)

	if props.vgroup_empty_to_darken:
		row.active = bool(vgroup.index in use_vg_l)

	row.alignment ="LEFT"

	if obj.vertex_groups.active_index == vgroup.index:
		emboss_hlt = True
	else:
		emboss_hlt = False

	row.operator("lazyweight.vgroup_set_active",text=vgroup.name,emboss=emboss_hlt).name = vgroup.name
	sp.prop(vgroup,"lock_weight", icon="LOCKED" if vgroup.lock_weight else "UNLOCKED", text="", emboss=emboss_hlt)


	draw_mod_vg_mix(vgroup,col)

#
def ui_3column_vg(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	if not addon_prefs.ui.usepanel_3column_vg:
		row = layout.row(align=True)
		sp = layout.split(factor=0.8,align=True)
		row = sp.row(align=True)
		row.alignment = "LEFT"
		row.label(text="",icon="GROUP_VERTEX")
		row.prop(addon_prefs.ui, "ui_main_3column_vg", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_3column_vg else "TRIA_RIGHT", emboss=False)
		ui_3column_vg_header_item(self,sp)


	if addon_prefs.ui.ui_main_3column_vg or addon_prefs.ui.usepanel_3column_vg:
		ui_3column_vg_main(self,layout)


def ui_3column_vg_header_item(self,layout):
	row = layout.row(align=True)
	if bpy.context.object:
		obj = bpy.context.object
		if obj.type == "MESH":
			layout.label(text=str(len(obj.vertex_groups)))
		else:
			layout.label(text="")
	else:
		layout.label(text="")
	layout.operator("lazyweight.vgroup_other_popup_menu",text="",icon="DOWNARROW_HLT")
	# layout.menu("LAZYWEIGHT_MT_vertex_group",text="",icon="DOWNARROW_HLT")
	layout.menu("MESH_MT_vertex_group_context_menu", icon='DOWNARROW_HLT', text="")

def ui_3column_vg_main(self,layout):
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	if not bpy.context.object:
		box = layout.box()
		box.label(text="No Active Object")
		return
	if not bpy.context.object.type == "MESH":
		box = layout.box()
		box.label(text="No Mesh Object")
		return


	ob = bpy.context.object
	group = ob.vertex_groups.active
	row = layout.row()

	if (
			ob.vertex_groups and
			(ob.mode == 'EDIT' or
			 (ob.mode == 'WEIGHT_PAINT' and ob.type == 'MESH' and ob.data.use_paint_mask_vertex))
		):
		row = layout.row()
		sub = row.row(align=True)
		sub.scale_x = 1.2
		sub.operator("object.vertex_group_assign", text="",icon="IMPORT")
		sub.operator("object.vertex_group_remove_from", text="",icon="DRIVER_TRANSFORM")

		sub = row.row(align=True)
		sub.scale_x = 1.2
		sub.operator("object.vertex_group_select", text="",icon="RESTRICT_SELECT_OFF")
		sub.operator("object.vertex_group_deselect", text="",icon="RESTRICT_SELECT_ON")

		row.prop(bpy.context.tool_settings, "vertex_group_weight", text="Weight")
		row.prop(addon_prefs.ui, "vgroup_use_bone_hierarchy", text="",icon="SORTSIZE")
		rows = row.row(align=True)
		rows.scale_x = 1.4
		rows.prop(props,"table_toggle_filter",text="",icon="VIEWZOOM")
	else:
		# row.prop(bpy.context.tool_settings, "vertex_group_weight", text="Weight")
		row.label(text="",icon="NONE")
		row.prop(addon_prefs.ui, "vgroup_use_bone_hierarchy", text="",icon="SORTSIZE")
		rows = row.row(align=True)
		rows.scale_x = 1.4
		rows.prop(props,"table_toggle_filter",text="",icon="VIEWZOOM")



	if props.table_toggle_filter:
		box = layout.box()
		col = box.column(align=True)
		sp = col.split(align=True,factor=0.33)
		sub = sp.row(align=True)
		sub.scale_x = .6

		sub.prop(props,"use_filter",text="M",icon="BLANK1")
		sub.prop(props,"use_filter_l",text="L",icon="BLANK1")
		sub.prop(props,"use_filter_r",text="R",icon="BLANK1")
		sub.prop(props,"toggle_case_insensitive",text="",icon="SORTALPHA")

		if props.use_filter_l:
			sp.prop(props,"filter_l",text="",icon="VIEWZOOM")
		if props.use_filter_r:
			sp.prop(props,"filter_r",text="",icon="VIEWZOOM")

		row = col.row(align=True)
		row.prop(props,"filter",text="",icon="VIEWZOOM")
		if props.use_filter_l:
			row.prop(props,"filter_2_l",text="",icon="VIEWZOOM")
		if props.use_filter_r:
			row.prop(props,"filter_2_r",text="",icon="VIEWZOOM")



	if not bpy.context.object:
		layout.label(text="No Active Object")
		return

	obj = bpy.context.object

	rows = layout.row()
	#####################################################
	if len(bpy.context.object.vertex_groups) == 0:
		box = rows.box()
		box.label(text="No Vertex Groups")
		row_add = box.row(align=True)
		row_add.scale_y = 1.5
		row_add.operator("object.vertex_group_add", icon='ADD', text="Add")

	else:
		if addon_prefs.ui.vgroup_use_bone_hierarchy:
			sp = rows.split(factor=1)
			bone_hierarchy_menu(self,bpy.context,sp)
		else:
			draw_column_vgroup(self,bpy.context,rows,obj)


	col = rows.column(align=True)


	col.operator("object.vertex_group_add", icon='ADD', text="")
	remove = col.operator("object.vertex_group_remove", icon='REMOVE', text="")
	remove.all_unlocked = remove.all = False
	#
	col.separator()
	#
	col.menu("MESH_MT_vertex_group_context_menu", icon='DOWNARROW_HLT', text="")

	if group:
		col.separator()
		col.operator("object.vertex_group_move", icon='TRIA_UP', text="").direction = 'UP'
		col.operator("object.vertex_group_move", icon='TRIA_DOWN', text="").direction = 'DOWN'

	col.separator()
	col.operator("object.vertex_group_lock",text="", icon="UV_SYNC_SELECT").action='INVERT'
	col.operator("object.vertex_group_lock",text="", icon="LOCKED").action='LOCK'
	col.operator("object.vertex_group_lock",text="", icon="UNLOCKED").action='UNLOCK'
	col.separator()
	col.operator("lazyweight.vgroup_active_select_move",text="", icon="SORT_DESC").down=False
	col.operator("lazyweight.vgroup_active_select_move",text="", icon="SORT_ASC").down=True


# filter
def draw_column_vgroup(self,context,rows,obj):
	props = bpy.context.scene.lazyweight

	use_vg_l = []
	if props.vgroup_empty_to_hide or props.vgroup_empty_to_darken:
		if props.vgroup_empty_only_select:
			use_vg_l = [i.group for v in obj.data.vertices if v.select for i in v.groups]
		else:
			use_vg_l = [i.group for v in obj.data.vertices for i in v.groups]
		use_vg_l = list(set(use_vg_l))


	bone_data = None
	if props.vgroup_hide_by_hide_bone or props.vgroup_hide_only_select_bone:
		mod_l = [m.object for m in obj.modifiers if m.type == "ARMATURE" and m.object]
		b_obj = mod_l[0]
		bone_data = b_obj.pose.bones


	# その他の名前
	if props.use_filter:
		colscale = rows.column(align=True)
		box = colscale.box()

		col = box.column(align=True)

		for vgroup in obj.vertex_groups:
			if props.vgroup_empty_to_hide:
				if not vgroup.index in use_vg_l:
					continue

			if not props.filter_l:
				if not re.findall(props.filter_l.lower(),vgroup.name.lower())and not re.findall(props.filter_r.lower(),vgroup.name.lower()):
					draw_vgroup_item(col, vgroup,obj,use_vg_l,bone_data)
					continue

			if props.toggle_case_insensitive:
				if not re.findall(props.filter_l.lower(),vgroup.name.lower())and not re.findall(props.filter_r.lower(),vgroup.name.lower()):
					if re.findall(props.filter.lower(),vgroup.name.lower()):
						draw_vgroup_item(col, vgroup,obj,use_vg_l,bone_data)
					else:
						row = col.row(align=True)
						row.label(text="",icon="BLANK1")
						row.label(text="")
						break

			else:
				if not re.findall(props.filter_l.lower(),vgroup.name.lower())and not re.findall(props.filter_r.lower(),vgroup.name.lower()):
					if re.findall(props.filter,vgroup.name):
						draw_vgroup_item(col, vgroup,obj,use_vg_l,bone_data)
					else:
						row = col.row(align=True)
						row.label(text="",icon="BLANK1")
						row.label(text="")
						break

		colscale_y = colscale.column(align=True)
		colscale_y.scale_y = .1
		colscale_y.label(text="                                      ") # Misc 列の文字が少ないと幅が狭くなる問題の対処


	# 左
	if props.use_filter_l:
		box = rows.box()
		col = box.column(align=True)
		vg_l = get_r_vg_list(obj, use_vg_l, props.filter_l, props.filter_2_l)
		if vg_l:
			for vgroup in vg_l:
				draw_vgroup_item(col, vgroup,obj,use_vg_l,bone_data)
		else:
			row = col.row(align=True)
			row.ui_units_x = 6.2
			row.label(text="",icon="NONE")

	# 右
	if props.use_filter_r:
		box = rows.box()
		col = box.column(align=True)
		vg_l = get_r_vg_list(obj, use_vg_l, props.filter_r, props.filter_2_r)
		if vg_l:
			for vgroup in vg_l:
				draw_vgroup_item(col, vgroup,obj,use_vg_l,bone_data)
		else:
			row = col.row(align=True)
			row.ui_units_x = 6.2
			row.label(text="",icon="NONE")


def get_r_vg_list(obj, use_vg_l, sym_name, filter_name):
	props = bpy.context.scene.lazyweight
	vg_l = [] # ヒットしたアイテムを入れるリスト

	for vgroup in obj.vertex_groups: # 全頂点グループ

		# "空の頂点グループを非表示"オプションが有効の場合はスルー
		if props.vgroup_empty_to_hide:
			if not vgroup.index in use_vg_l:
				continue

		# フィルター名なしなら、シンメトリーネームがあるものだけをフィルター
		if not filter_name:
			if re.findall(sym_name.lower(),vgroup.name.lower()):
				vg_l += [vgroup]
				continue

		# 大文字・小文字判別
		if props.toggle_case_insensitive:
			if re.findall(sym_name.lower(),vgroup.name.lower()):
				if re.findall(filter_name.lower(),vgroup.name.lower()):
					vg_l += [vgroup]

		else:
			if re.findall(sym_name,vgroup.name):
				if re.findall(filter_name.lower(),vgroup.name.lower()):
					vg_l += [vgroup]

	return vg_l
