import bpy, math, bmesh
from bpy.types import UIList
from bpy.props import *


class LAZYWEIGHT_UL_test(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
		props = bpy.context.scene.lazyweight

		layout.label(text=str(item.index))
		v = obj.data.vertices[item.index]
		for i in v.groups:
			layout.label(text=str(i))

		sp = layout.split(align=True,factor=0.1)
		col = sp.column(align=True)
		col.alignment = "RIGHT"

		for g in v.groups: # 「頂点の」グループ
			if g.group == vgroup.index: # 頂点グループ
				rows.enabled = not vgroup.lock_weight
				if g.weight == 0:
					rows.prop(g,"weight",text="",emboss= False)
				elif props.table_highlight_toggle:
					if g.weight == props.table_highlight_value:
						rowx = rows.row(align=True)
						rowx.alert = True
						rowx.prop(g,"weight",text="")
					else:
						rows.prop(g,"weight",text="")
				else:
					rows.prop(g,"weight",text="")


def ui_table(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight

	box = layout.box()
	if not bpy.context.object:
		box.label(text="No Active Object")
		return

	obj = bpy.context.object

	# test menu (1 vert weight)
	# layout.prop(obj.data.vertices[0].groups[0],"weight",text="", slider=True)
	# layout.prop(obj.data.vertices[0],"bevel_weight",text="", slider=True)

	if not obj.vertex_groups:
		row = box.row(align=True)
		row.label(text="No Vertex Group")
		row.operator("object.vertex_group_add", icon='ADD', text="")
		return

	if not obj.type =="MESH":
		box.label(text="Not Mesh Object")
		return


	s_v,o_count = target_vertex(self,context,obj)
	# if obj.mode == "EDIT": # 編集モードではウェイトをUIに表示できない？
	# 	bm: bmesh.types.BMesh = bmesh.from_edit_mesh(obj.data)
	#
	# 	# Ensure custom data exists.
	# 	bm.verts.layers.deform.verify()
	# 	deform = bm.verts.layers.deform.active
	# 	for v in bm.verts:
	# 		if v.select:
	# 		    g = v[deform]
	# 		    # First & second vertex group (by index)
	# 		    g[0] = 0.5
	# 		    g[1] = 0.75
	#
	# 		    # Print the weights
	# 		    layout.prop(v,"deform")
	# else:
	header_menu(self,context,box,s_v,o_count)
	if not len(s_v):
		row = box.row(align=True)
		row.alignment = "CENTER"
		row.label(text="No Vertex Item",icon="NONE")
		return


	# 頂点グループ名
	if props.table_scroll_num > 500 and not props.toggle_ui_warning:
		box.label(text="You are trying to display more than 500 vertices at a time.")
		box.label(text="Blender will crash if there are too many menus to display at once.")
		box.label(text="Do you want to display the table?")
		row = box.row(align=True)
		row.label(text="",icon="ERROR")
		row.prop(props,"toggle_ui_warning",text="Yes. Display Table")
		return


	vertex_groups_menu(self,context,box,obj,s_v)
	# インデックス名
	sp = box.split(align=True,factor=0.1)
	col = sp.column(align=True)
	col.alignment = "RIGHT"
	for v in s_v:
		row = col.row(align=True)
		if v.select:
			row.prop(v,"select",text=str(v.index),icon="RESTRICT_SELECT_OFF",emboss=False)
		else:
			row.prop(v,"select",text=str(v.index),icon="RESTRICT_SELECT_ON",emboss=False)



	# 割り当てのある頂点グループをフィルターする
	assign_vg = [vgroup for vgroup in obj.vertex_groups for v in s_v for g in v.groups if g.group == vgroup.index]
	assign_vg = sorted(set(assign_vg), key=assign_vg.index)



	row = sp.row(align=True)
	for vgroup in assign_vg: #オブジェクトの持つ頂点グループ
		col = row.column(align=True)

		for v in s_v: # 頂点
			rows = col.row(align=True) # 空白にもメニューが存在するようにする

			# 新規追加・除去ボタン
			add_remove_button(self,context,rows,v,vgroup)

			for g in v.groups: # 「頂点の」グループ
				if g.group == vgroup.index: # 頂点グループ
					cell_item_menu(self,context,rows,g,vgroup)


	if o_count > props.table_scroll_num:
		scroll(self,context,box,o_count)


	if obj.mode=="EDIT":
		row = layout.row(align=True)
		row.alert = True
		row.label(text="Can't display the exact mesh in edit mode",icon="ERROR")


	if bpy.app.version >= (3,6,0):
		layout.operator("lazyweight.mesh_deselect_active_vertex",icon="KEYFRAME")

def add_remove_button(self,context,rows,v,vgroup):
	props = bpy.context.scene.lazyweight

	rowx = rows.row(align=True)

	if props.table_ui_add_remove:
		rowx.scale_x = .7
		rowx.active=False
		v_w = rowx.operator("lazyweight.add_v_weight",text="",icon="ADD",emboss=False)
		v_w.index = v.index
		v_w.group = vgroup.index
		v_w = rowx.operator("lazyweight.remove_v_weight",text="",icon="X",emboss=False)
		v_w.index = v.index
		v_w.group = vgroup.index

	else:
		rowx.scale_x = .1
		rowx.label(text="",icon="BLANK1") # 小さなラベル


def header_menu(self,context,box,s_v,o_count):
	props = bpy.context.scene.lazyweight

	sp = box.split(align=True,factor=0.1)
	rows = sp.row(align=True)
	rows.alignment ="RIGHT"
	rows.label(text=str(len(s_v)))

	row = sp.row(align=True)
	row.prop(props,"table_filter_hide",text="",icon="MOD_MASK")
	row.prop(props,"table_filter_selected",text="",icon="RESTRICT_SELECT_OFF")
	row.separator()
	row.prop(props,"table_ui_add_remove",text="",icon="LAYER_ACTIVE")
	row.separator()
	col = row.column(align=True)
	col.active = (bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"})
	col.prop(props, "vindex_is_running",text="",icon="LINENUMBERS_ON")
	row.separator()
	row.prop(props,"table_highlight_toggle",text="",icon="OUTLINER_DATA_LIGHT")

	if props.table_highlight_toggle:
		row.prop(props,"table_highlight_value",text="")
		rows = row.row(align=True)
		rows.scale_x = 1
		# rows.menu("LAZYWEIGHT_MT_table_other",text="",icon="DOWNARROW_HLT")
		rows.operator("lazyweight.table_other",text="",icon="DOWNARROW_HLT")
	else:
		row.label(text="")
		row.label(text="",icon="BLANK1")



	row_scroll = row.row(align=True)
	row = row_scroll.row(align=True)
	row.alignment="RIGHT"
	box = row.box()
	box = box.row(align=True)
	box.label(text="",icon="UV_SYNC_SELECT")
	if o_count <= props.table_scroll:
		rows = box.row(align=True)
		rows.alert=True
		rows.prop(props, "table_scroll",text="",emboss=False)
	else:
		box.prop(props, "table_scroll",text="",emboss=False)

	box.separator(factor=2)
	rows = box.row(align=True)
	rows.scale_x=0.7
	rows.prop(props, "table_scroll_num",text="",emboss=False)
	box.label(text="/   "+str(o_count))


def vertex_groups_menu(self,context,box,obj,s_v):
	props = bpy.context.scene.lazyweight
	vglist = [vgroup.name for vgroup in obj.vertex_groups for v in s_v for g in v.groups if g.group == vgroup.index]
	vglist = dict.fromkeys(vglist)

	sp = box.split(align=True,factor=0.1)
	rows = sp.row(align=True)
	for v in vglist:
		sps = sp.split(align=True,factor=0.2)
		vg = bpy.context.object.vertex_groups[v]
		if vg.lock_weight:
			sps.operator("lazyweight.vgroup_lock_toggle",text="",icon="LOCKED").name = v
		else:
			sps.operator("lazyweight.vgroup_lock_toggle",text="",icon="UNLOCKED").name = v
		if bpy.context.object.vertex_groups.active_index ==vg.index:
			sps.operator("lazyweight.vgroup_set_active",text=v).name = v
		else:
			sps.active=False
			sps.operator("lazyweight.vgroup_set_active",text=v).name = v


def cell_item_menu(self,context,rows,g,vgroup):
	props = bpy.context.scene.lazyweight
	slider = props.table_slider

	if vgroup.lock_weight:
		rows.enabled = False
	if g.weight == 0:
		rows.prop(g,"weight",text="",emboss= False)
	elif props.table_highlight_toggle:
		bool_type = False
		if props.table_highlight_type == "Match":
			if item_highlight(self,context,g.weight):
				bool_type = True
		if props.table_highlight_type == "More":
			if g.weight >= props.table_highlight_value:
				bool_type = True
		if props.table_highlight_type == "Less":
			if g.weight <= props.table_highlight_value:
				bool_type = True

		rowx = rows.row(align=True)
		if props.table_highlight_emboss:
			rowx.prop(g,"weight",text="",emboss=(not bool_type), slider=slider)
		else:
			rowx.alert = bool_type
			rowx.prop(g,"weight",text="", slider=slider)

	else:
		rows.prop(g,"weight",text="", slider=slider)


def scroll(self,context,box,o_count):
	props = bpy.context.scene.lazyweight
	row = box.row(align=True)
	row.label(text="more...",icon="NONE")
	rows = row.row(align=True)

	if o_count <= props.table_scroll:
		rowx = rows.row(align=True)
		rowx.alert=True
		rowx.prop(props, "table_scroll",text="",emboss=False)
	else:
		rows.prop(props, "table_scroll",text="",emboss=False)
	rows.scale_x=0.7
	rows.prop(props, "table_scroll_num",text="",emboss=False)
	row.label(text="/ "+str(o_count))



def target_vertex(self,context,obj):
	props = bpy.context.scene.lazyweight

	# if obj.mode == "EDIT":
	# 	bm: bmesh.types.BMesh = bmesh.from_edit_mesh(obj.data)
	# 	bm_v = bm.verts
	#
	# else:
	bm_v = obj.data.vertices

	if props.table_filter_hide:
		if props.table_filter_selected:
			s_v = list(filter(lambda v: v.select and not v.hide, bm_v))
		else:
			s_v = list(filter(lambda v: not v.hide, bm_v))
	else:
		if props.table_filter_selected:
			s_v = list(filter(lambda v: v.select, bm_v))
		else:
			s_v = list(filter(lambda v: v, bm_v))




	o_count = len(s_v)
	s = props.table_scroll
	s_min = s
	s_max = s + props.table_scroll_num
	return s_v[s_min:s_max], o_count


def item_highlight(self,context,item):
	props = bpy.context.scene.lazyweight

	a = item
	b = props.table_highlight_value

	range = props.table_highlight_hitrange

	if range == 1:
		rel = 1e-01
	if range == 2:
		rel = 1e-02
	if range == 3:
		rel = 1e-03
	if range == 4:
		rel = 1e-04
	if range == 5:
		rel = 1e-05
	if range == 6:
		rel = 1e-06
	if range == 7:
		rel = 1e-07
	if range == 8:
		rel = 1e-08
	if range == 9:
		rel = 1e-09
	if range == 10:
		rel = 1e-010
	if range == 11:
		rel = 1e-011
	if range == 12:
		rel = 1e-012


	return math.isclose(a, b, rel_tol=rel, abs_tol=0.0)
