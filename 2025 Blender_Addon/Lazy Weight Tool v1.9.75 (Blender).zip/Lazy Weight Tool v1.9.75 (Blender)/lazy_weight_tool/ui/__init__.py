import bpy


from .ui_bone_hierarchy import *
from .ui_main_brush import *
from .ui_main_operator import *
from .ui_main_select import *
from .ui_main_set_weight import *
from .ui_main_table import *
from .ui_main_3column_vg import *
from .ui_main_weight_transfer import *
from .ui_main_copype import *
from .ui_menu import *
from .ui_menu_other import *
from .ui_panel import *
from .ui_panel_v_group import *
from .ui_pie import *
from .ui_list import *
from .def_regi_panel import *
from .ui_panel_props_editor import *




classes = (
LAZYWEIGHT_MT_pie_menu,
LAZYWEIGHT_MT_table_other,
LAZYWEIGHT_UL_test,
# LAZYWEIGHT_PT_panel,
# LAZYWEIGHT_PT_table,
# LAZYWEIGHT_PT_vertex_groups,
LAZYWEIGHT_MT_vertex_group,
LAZYWEIGHT_MT_operator_menu,
LAZYWEIGHT_UL_vg_colle,
LAZYWEIGHT_OT_vgroup_other_popup_menu,
LAZYWEIGHT_MT_copype,


LAZYWEIGHT_PT_table_props_editor,
LAZYWEIGHT_PT_panel_props_editor,
LAZYWEIGHT_PT_copype_props_editor,
LAZYWEIGHT_PT_operator_props_editor,
LAZYWEIGHT_PT_select_props_editor,
LAZYWEIGHT_PT_3column_vg_props_editor,
LAZYWEIGHT_PT_weight_transfer_props_editor,



# LAZYWEIGHT_PT_table,
# LAZYWEIGHT_PT_operator,
# LAZYWEIGHT_PT_weight_transfer,
# LAZYWEIGHT_PT_copype,
# LAZYWEIGHT_PT_select,
# LAZYWEIGHT_PT_3column_vg,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

	bpy.types.MESH_MT_vertex_group_context_menu.append(vgroup_menu_other)


	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

	bpy.utils.register_class(LAZYWEIGHT_PT_panel)

	regi_panel(prefs.ui.usepanel_operator,LAZYWEIGHT_PT_operator)
	regi_panel(prefs.ui.usepanel_weight_transfer,LAZYWEIGHT_PT_weight_transfer)
	regi_panel(prefs.ui.usepanel_copype,LAZYWEIGHT_PT_copype)
	regi_panel(prefs.ui.usepanel_select,LAZYWEIGHT_PT_select)
	regi_panel(prefs.ui.usepanel_3column_vg,LAZYWEIGHT_PT_3column_vg)

	regi_panel(prefs.ui.usepanel_table,LAZYWEIGHT_PT_table)
	regi_panel(prefs.ui.usepanel_vertex_groups,LAZYWEIGHT_PT_vertex_groups)


def unregister():
	bpy.types.MESH_MT_vertex_group_context_menu.remove(vgroup_menu_other)
	bpy.utils.unregister_class(LAZYWEIGHT_PT_panel)

	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_weight_transfer)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_copype)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_operator)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_select)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_3column_vg)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_table)
	except: pass
	try: bpy.utils.unregister_class(LAZYWEIGHT_PT_vertex_groups)
	except: pass


	for cls in reversed(classes):
		try:
			bpy.utils.unregister_class(cls)
		except: pass


if __name__ == "__main__":
	register()
