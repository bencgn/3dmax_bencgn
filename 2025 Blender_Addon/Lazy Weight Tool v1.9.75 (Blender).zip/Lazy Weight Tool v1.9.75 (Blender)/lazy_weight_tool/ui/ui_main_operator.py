import bpy
from bpy.props import *
from ..utils import preference


def ui_operator(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	if not addon_prefs.ui.usepanel_operator:
		row = layout.row(align=True)
		sp = layout.split(factor=0.5,align=True)
		row = sp.row(align=True)
		row.alignment = "LEFT"
		row.label(text="",icon="DOT")
		row.prop(addon_prefs.ui,"ui_main_operator", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_operator else "TRIA_RIGHT", text="Operator", emboss=False)
		if not addon_prefs.ui.ui_main_operator:
			ui_operator_header_item(self,sp)


	if addon_prefs.ui.ui_main_operator or addon_prefs.ui.usepanel_operator:
		ui_operator_main(self,layout)


def ui_operator_header_item(self,layout):
	row = layout.row(align=True)
	row.alignment = "RIGHT"
	row.operator("object.vertex_group_normalize_all", text="", icon="RNA_ADD")
	row.operator("object.vertex_group_normalize", text="", icon="RNA")
	row.separator()
	row.operator("object.vertex_group_clean", text="", icon="TRASH")
	row.operator("object.vertex_group_smooth", text="", icon="MOD_SMOOTH")

	row.separator()
	row.operator("object.vertex_group_mirror",text="", icon="MOD_MIRROR")


def ui_operator_main(self,layout):
	box = layout.box()
	col = box.column(align=True)
	col.scale_y = 1.2
	row = col.row(align=True)
	row.operator("object.vertex_group_normalize_all", text="Normalize All", icon="RNA_ADD")
	row.operator("object.vertex_group_normalize", text="Normalize", icon="RNA")
	col.separator()
	sp = col.split(align=True,factor=0.1)
	sp.operator("lazyweight.select_half",text="", icon="RESTRICT_SELECT_OFF")
	sp.operator("object.vertex_group_mirror",text="Mirror", icon="MOD_MIRROR")
	col.separator()

	col.operator("object.vertex_group_invert", text="Invert", icon="UV_SYNC_SELECT")
	col.operator("object.vertex_group_clean", text="Clean", icon="TRASH")
	col.operator("object.vertex_group_quantize", text="Quantize", icon="COLORSET_10_VEC")
	col.operator("object.vertex_group_levels", text="Levels", icon="ADD")
	col.operator("object.vertex_group_smooth", text="Smooth", icon="MOD_SMOOTH")
	col.operator("object.vertex_group_limit_total", text="Limit Total", icon="PARTICLE_POINT")

	if bpy.app.version <= (3,5,0):
		col.operator("object.vertex_group_fix", text="Fix Deforms", icon="MOD_SIMPLEDEFORM")

	col = layout.column()
	col.operator("paint.weight_gradient",icon="FORCE_FORCE")
	col.operator("lazyweight.vgroup_round_weight",icon="MOD_SMOOTH")
	col.operator("lazyweight.apply_dynamic_paint",icon="MOD_DYNAMICPAINT")
	col.operator("lazyweight.adjust_weight_gesture",icon="MOUSE_MMB_DRAG")
