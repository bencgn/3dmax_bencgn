import bpy, re
from ..utils import draw_mod_vg_mix,preference
used_vg_l = []

# ボーンを階層表示するメニュー
def bone_hierarchy_menu(self,context,layout):
	if not bpy.context.active_object:
		return
	if not bpy.context.object.type == "MESH":
		return
	if not bpy.context.object.vertex_groups:
		return

	props = bpy.context.scene.lazyweight
	m_obj = bpy.context.object
	mod_l = [m.object for m in m_obj.modifiers if m.type == "ARMATURE" and m.object]
	if not mod_l:
		box = layout.box()
		box.label(text="No Armature Modifier",icon="NONE")
		return

	global used_vg_l


	b_obj = mod_l[0]
	bone_data = b_obj.pose.bones
	prefs = preference()



	# 頂点データ
	use_vg_l = []
	if props.vgroup_empty_to_hide or props.vgroup_empty_to_darken:
		if props.vgroup_empty_only_select:
			use_vg_l = [i.group for v in m_obj.data.vertices if v.select for i in v.groups]
		else:
			use_vg_l = [i.group for v in m_obj.data.vertices for i in v.groups]
		use_vg_l = list(set(use_vg_l))



	box = layout.box()
	col = box.column(align=True)
	row = col.row(align=True)
	row.prop(prefs.ui,"hierarchy_menu_range")
	row.prop(prefs.ui,"hierarchy_menu_scroll")

	# used_vg_l = []
	# ボーンの最上階層(親なし)リスト
	top_bone_l = [b for b in bone_data if not b.parent]
	item_l = []
	for bone in top_bone_l:

		# アクティブなボーンのアイコン
		if bone.children: # トップ
			item_l += [[bone,0,False]]
			# draw_bone_child_item(m_obj,b_obj,bone,col,0,False,use_vg_l)

		else: # 子がないトップ
			item_l += [[bone,0,True]]
			# draw_bone_child_item(m_obj,b_obj,bone,col,0,True,use_vg_l)
			continue

		# メイン
		rt_item_l = bone_hierarchy_loop(m_obj,b_obj,bone,col,1,True,use_vg_l,item_l)
		if rt_item_l:
			item_l = rt_item_l

		item_l += ["is_space"]


	range = prefs.ui.hierarchy_menu_range
	srt = prefs.ui.hierarchy_menu_scroll
	end = srt + range
	item_l = item_l[srt:end]
	for i in item_l:
		if i == "is_space":
			cols = col.column(align=True)
			cols.scale_y = 0.5
			cols.separator()
			continue
		bone = i[0]
		if bone.name in m_obj.vertex_groups:
			vg = m_obj.vertex_groups[bone.name]
			used_vg_l.append(bone.name)
		draw_bone_child_item(m_obj,b_obj,bone,col,i[1],i[2],use_vg_l)



	col.separator()

	# ボーンで利用されていない頂点グループ
	vg_l = [i for i in m_obj.vertex_groups if not i.name in used_vg_l]
	if vg_l:
		box = col.box()
		col = box.column(align=True)
	for vg in vg_l:
		draw_no_bone_vg_item(m_obj, b_obj, vg, col, 0, True)


# ループ
def bone_hierarchy_loop(m_obj, b_obj, bone, col, count, is_top, use_vg_l, item_l):
	for b in bone.children:
		if bone.lazyweight.show_expanded:
			item_l += [[b,count,False]]
			# draw_bone_child_item(m_obj,b_obj,b,col,count,False,use_vg_l)
			bone_hierarchy_loop(m_obj,b_obj,b,col,count + 1,False,use_vg_l, item_l)
		else:
			loop_no_display(bone)



	if not bone.children:
		return item_l


def loop_no_display(bone):
	for b in bone.children:
		global used_vg_l
		used_vg_l.append(b.name)
		loop_no_display(b)
	if not bone.children:
		return


# 各ボーンのメニュー
def draw_bone_child_item(m_obj, b_obj, bone, col, range_count, is_top, use_vg_l):
	if not bone.name in m_obj.vertex_groups:
		return

	# global used_vg_l
	vg = m_obj.vertex_groups[bone.name]
	# used_vg_l.append(bone.name)


	props = bpy.context.scene.lazyweight
	if props.vgroup_empty_to_hide:
		if not vg.index in use_vg_l:
			return

	if props.vgroup_hide_by_hide_bone:
		if bone.bone.hide:
			return
	if props.vgroup_hide_only_select_bone:
		if not bone.bone.select:
			return

	if props.filter:
		if props.toggle_case_insensitive:
			if not re.findall(props.filter,vg.name):
				return
		else:
			if not re.findall(props.filter.lower(),vg.name.lower()):
				return


	addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

	emboss_hlt = False

	if m_obj.vertex_groups.active_index == vg.index:
		emboss_hlt = True

	sp = col.split(align=True,factor=0.15)
	row = sp.row(align=True)

	#階層の色
	if range_count:
		num_l = [0,1,2,3,4,5,6,7]
		if range_count >= len(num_l):
			color_num = num_l[range_count%len(num_l)]
		else:
			color_num = num_l[range_count]
	else:
		color_num = 0

	row_color = row.row(align=True)
	row_color.scale_x = 0.2
	row_color.prop(addon_prefs.ui,"hierarchy_color_" + str(color_num),text="")
	row.prop(vg,"lock_weight", icon="LOCKED" if vg.lock_weight else "UNLOCKED", text="", emboss=emboss_hlt)
	if not bone.child:
		row.label(text="",icon="BLANK1")
	else:
		row_x = row.row(align=True)
		row_x.active = bone.lazyweight.show_expanded
		row_x.prop(bone.lazyweight,"show_expanded",text="",icon="TRIA_DOWN" if bone.lazyweight.show_expanded else "TRIA_RIGHT", emboss=emboss_hlt)


	row = sp.row(align=True)
	if props.vgroup_empty_to_darken:
		row.active = bool(vg.index in use_vg_l)


	# 階層のインデント
	if not range_count == 0:
		if not is_top:
			fac = 0
			for i in range(range_count):
				fac +=.5
			row_sep = row.row(align=True)
			row_sep.ui_units_x = fac
			row_sep.label(text="",icon="BLANK1")

	col = row.column(align=True)
	row_item = col.row(align=True)
	row_item.alignment="LEFT"
	row_item.operator("lazyweight.vgroup_set_active",text=vg.name,icon="GROUP_VERTEX",emboss=emboss_hlt).name = vg.name

	if bone.lazyweight.show_expanded:
		draw_mod_vg_mix(vg,col)


# 各ボーンのメニュー
def draw_no_bone_vg_item(m_obj,b_obj,vg,col,range_count,is_top):
	addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

	emboss_hlt = False
	if m_obj.vertex_groups.active_index == vg.index:
		emboss_hlt = True

	sp = col.split(align=True,factor=0.15)
	row = sp.row(align=True)


	row_color = row.row(align=True)
	row_color.scale_x = 0.2
	row_color.prop(addon_prefs.ui,"hierarchy_color_0",text="")
	row.label(text="",icon="BLANK1")

	row = sp.row(align=True)
	row_item = row.row(align=True)
	row_item.alignment="LEFT"
	row_item.operator("lazyweight.vgroup_set_active",text=vg.name,icon="GROUP_VERTEX",emboss=emboss_hlt).name = vg.name

	draw_mod_vg_mix(vg,col)
