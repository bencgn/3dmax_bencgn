import bpy
from bpy.props import *
from ..utils import preference


def ui_copype(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	props_cy = props.copype
	addon_prefs = preference()


	if not addon_prefs.ui.usepanel_copype:
		row = layout.row(align=True)
		sp = layout.split(factor=0.7,align=True)
		row = sp.row(align=True)
		row.alignment = "LEFT"
		row.label(text="",icon="COPYDOWN")
		row.prop(addon_prefs.ui, "ui_main_copype", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_copype else "TRIA_RIGHT", emboss=False)

		if not addon_prefs.ui.ui_main_copype:
			ui_copype_header_item(self,sp)
		else:
			row = sp.row(align=True)
			row.alignment="RIGHT"
			row.label(text="",icon="BLANK1")
			row.label(text="",icon="BLANK1")
			row.menu("LAZYWEIGHT_MT_copype",text="",icon="DOWNARROW_HLT")


	if addon_prefs.ui.ui_main_copype or addon_prefs.ui.usepanel_copype:
		ui_copype_main(self,layout)


# header
def ui_copype_header_item(self,layout):
	row = layout.row(align=True)
	row.alignment="RIGHT"
	row.operator("lazyweight.copy_weight",text="",icon="COPYDOWN")
	row.separator()
	op = row.operator("lazyweight.paste_weight",text="",icon="PASTEDOWN")
	op.source_type = "CLIPBOARD"
	row.separator()
	# row.prop(props_cy,"mode",text="",icon_only=True)
	row.menu("LAZYWEIGHT_MT_copype",text="",icon="DOWNARROW_HLT")


# main
def ui_copype_main(self,layout):
	props = bpy.context.scene.lazyweight
	props_cy = props.copype
	addon_prefs = preference()

	col_main = layout.column(align=True)
	box = col_main.box()
	col = box.column()
	col.scale_y = 1.2
	col.operator("lazyweight.copy_weight",icon="COPYDOWN")
	col_main.separator()

	box = col_main.box()
	col = box.column()
	col.scale_y = 1.2

	op = col.operator("lazyweight.paste_weight",icon="PASTEDOWN")
	op.source_type = "CLIPBOARD"
	col.separator()
	row = col.row(align=True)
	row.prop(props_cy,"mode",expand=True)


	cols = col.column(align=True)
	cols.scale_y = .8

	row = cols.row(align=True)
	row.prop(props_cy,"mix_mode",expand=True)

	row = cols.row(align=True)
	row.use_property_split = True
	row.use_property_decorate = False
	row.label(text="",icon="BLANK1")
	row.prop(props_cy,"weight_strength",slider=True)

	cols.separator()
	row = cols.row(align=True)
	row.active = bool(props_cy.mode in {"ORIENTATION_LOCAL","ORIENTATION_GLOBAL"})
	row.label(text="Find Type")
	row.prop(props_cy,"find_type",expand=True)
	row = cols.row(align=True)
	row.prop(addon_prefs.ui, "copype_clipboard",text="", icon="TRIA_DOWN" if addon_prefs.ui.copype_clipboard else "TRIA_RIGHT", emboss=False)
	row.use_property_split = True
	row.use_property_decorate = False
	rows = row.row(align=True)
	rows.active = bool(props_cy.mode in {"ORIENTATION_LOCAL","ORIENTATION_GLOBAL"})
	rows.prop(props_cy,"distance")

	if addon_prefs.ui.copype_clipboard:
		box.prop(props_cy,"clipboard")
