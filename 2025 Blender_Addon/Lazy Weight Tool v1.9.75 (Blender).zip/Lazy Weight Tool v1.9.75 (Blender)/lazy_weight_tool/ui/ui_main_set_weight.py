import bpy
from bpy.props import *
from ..utils import preference

def ui_set_weight(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	# if not addon_prefs.ui.usepanel_set_weight:
	row = layout.row(align=True)
	sp = layout.split(factor=0.95,align=True)
	row = sp.row(align=True)
	row.alignment = "LEFT"
	row.label(text="",icon="MOD_VERTEX_WEIGHT")
	row.prop(addon_prefs.ui, "ui_main_weight_set", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_weight_set else "TRIA_RIGHT", text="Set Weight", emboss=False)
	sp.operator("lazyweight.set_weight_other",text="",icon="DOWNARROW_HLT")

	# # if addon_prefs.ui.ui_main_weight_set or addon_prefs.ui.usepanel_set_weight:
	if addon_prefs.ui.ui_main_weight_set:
		ui_set_weight_main(self,layout)



# # header
# def ui_set_weight_header_item(self,layout):


# main
def ui_set_weight_main(self,layout):
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	box = layout.box()


	row = box.row(align=True)
	row.scale_y = 1.3
	rowx = row.row(align=True)
	rowx.scale_x = .8
	rowx.scale_y = 1.5
	rowx.prop(props,"toggle_weight_volume_setting",text="",icon="DOWNARROW_HLT")

	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_01
	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_01",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_01,2)))
		setw.weight = props.weight_01
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_02

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_02",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_02,2)))
		setw.weight = props.weight_02
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_03

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_03",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_03,2)))
		setw.weight = props.weight_03
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_04

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_04",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_04,2)))
		setw.weight = props.weight_04
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_05

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_05",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_05,2)))
		setw.weight = props.weight_05
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_06

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_06",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_06,2)))
		setw.weight = props.weight_06
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize


	col = row.column(align=True)
	rows = col.row(align=True)
	rows.scale_y = 0.5
	rows.scale_x = 3
	setw = rows.operator("lazyweight.weight_brush_set",text="",icon="DOT")
	setw.weight = props.weight_07

	if props.toggle_weight_volume_setting:
		rows = col.row(align=True)
		rows.prop(props,"weight_07",text="",emboss=False)
	else:
		setw = col.operator("lazyweight.set_weight",text=str(round(props.weight_07,2)))
		setw.weight = props.weight_07
		setw.type = props.type
		setw.type_another_mode = "NONE"
		setw.normalize = props.normalize




	#####################################################
	# オプション
	row = box.row(align=True)
	row.scale_x = 1.8
	box = row.box()
	rows = box.row(align=True)
	rows.prop(props,"normalize",text="",icon="RNA",expand=True)
	box = row.box()
	rows = box.row(align=True)

	if bpy.app.version >= (2,91,0):
		if bpy.context.object:
			obj = bpy.context.object
			if obj.type == "MESH":
				rows.prop(obj.data, "use_mirror_x", text="X", toggle=True)
				rows.prop(obj.data, "use_mirror_y", text="Y", toggle=True)
				rows.prop(obj.data, "use_mirror_z", text="Z", toggle=True)
			else:
				rows.label(text="",icon="NONE")
		else:
			rows.label(text="",icon="NONE")
	else:
		vpaint = bpy.context.scene.tool_settings.weight_paint
		rows.prop(vpaint, "use_symmetry_x", text="X", toggle=True)
		rows.prop(vpaint, "use_symmetry_y", text="Y", toggle=True)
		rows.prop(vpaint, "use_symmetry_z", text="Z", toggle=True)

	rows.separator()
	box = row.box()
	rows = box.row(align=True)
	rows.prop(props,"type",text="", expand=True)


	#####################################################
	box = layout.box()
	row = box.row(align=True)
	row.operator("object.vertex_group_smooth",text="Smooth",icon="MOD_SMOOTH")
	row.separator()
	rowz = row.row(align=True)
	rowz.scale_x = .7
	rowz.prop(props,"weight",text="")
	rows = row.row(align=True)
	row.scale_x = 1.8
	row.scale_y = 1.3
	setw = rows.operator("lazyweight.set_weight",text="",icon="IMPORT",emboss=False)
	setw.weight = props.weight
	setw.type_another_mode = "REPLACE"
	setw.normalize = props.normalize
	setw = rows.operator("lazyweight.set_weight",text="",icon="ADD",emboss=False)
	setw.weight = props.weight
	setw.type_another_mode = "ADD"
	setw.normalize = props.normalize
	setw = rows.operator("lazyweight.set_weight",text="",icon="REMOVE",emboss=False)
	setw.weight = props.weight
	setw.type_another_mode = "SUBTRACT"
	setw.normalize = props.normalize
