import bpy

def ui_brush(self, context):
	p_weight = bpy.context.scene.tool_settings.unified_paint_settings
	tool_set_wp = bpy.context.tool_settings.weight_paint



	layout = self.layout
	row = layout.row(align=True)
	box = row.box()
	boxrow = box.row(align=True)
	boxrow.label(text="",icon="BRUSH_DATA")
	boxrow.separator()
	if tool_set_wp.brush == bpy.data.brushes["Mix"]:
		boxrow.operator("lazyweight.weight_brush_mix", icon='IMPORT', text="",emboss = True)
	else:
		boxrow.operator("lazyweight.weight_brush_mix", icon='IMPORT', text="",emboss = False)

	if tool_set_wp.brush == bpy.data.brushes["Add"]:
		boxrow.operator("lazyweight.weight_brush_add", icon='ADD', text="",emboss = True)
	else:
		boxrow.operator("lazyweight.weight_brush_add", icon='ADD', text="",emboss = False)

	if tool_set_wp.brush == bpy.data.brushes["Subtract"]:
		boxrow.operator("lazyweight.weight_brush_sub", icon='REMOVE', text="",emboss = True)
	else:
		boxrow.operator("lazyweight.weight_brush_sub", icon='REMOVE', text="",emboss = False)

	boxrow.separator()
	boxrow.operator("brush.curve_preset", icon='SMOOTHCURVE', text="").shape = 'SMOOTH'
	boxrow.operator("brush.curve_preset", icon='NOCURVE', text="").shape = 'MAX'
	boxrow.separator()

	boxrow.prop(p_weight,"weight")
	boxrow.prop(p_weight,"size")
	if tool_set_wp.brush == bpy.data.brushes["Mix"]:
		boxrow.prop(bpy.data.brushes["Mix"],"strength")
	elif tool_set_wp.brush == bpy.data.brushes["Add"]:
		boxrow.prop(bpy.data.brushes["Add"],"strength")
	elif tool_set_wp.brush == bpy.data.brushes["Subtract"]:
		boxrow.prop(bpy.data.brushes["Subtract"],"strength")

	if bpy.context.object:
		if bpy.context.object.mode == "EDIT":
			row.separator()
			overlay = bpy.context.area.spaces[0].overlay
			row.prop(overlay, "show_weight",text="",icon="OVERLAY")
		else:
			row.separator()
			row.label(text="",icon="BLANK1")
	else:
		row.separator()
		row.label(text="",icon="BLANK1")
