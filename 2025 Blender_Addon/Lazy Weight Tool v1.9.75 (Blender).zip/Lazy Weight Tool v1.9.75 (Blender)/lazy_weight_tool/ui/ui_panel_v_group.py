import bpy
from bpy.types import Panel
from bpy.props import *


class LAZYWEIGHT_PT_vertex_groups(Panel):
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_label = "Vertex Groups"
	# COMPAT_ENGINES = {'BLENDER_RENDER', 'BLENDER_EEVEE', 'BLENDER_WORKBENCH'}

	@classmethod
	def poll(cls, context):
		engine = context.engine
		obj = context.object
		# return context.mode == 'PAINT_WEIGHT'
		return (obj and obj.type in {'MESH', 'LATTICE'})
		# return (obj and obj.type in {'MESH', 'LATTICE'} and (engine in cls.COMPAT_ENGINES))

	def draw(self, context):
		layout = self.layout

		obj = bpy.context.object
		group = obj.vertex_groups.active
		rows = 3
		if group:
			rows = 5

		row = layout.row()
		row.template_list(
			"LAZYWEIGHT_UL_vg_colle","",
			obj, "vertex_groups",
			obj.vertex_groups, "active_index",
			rows = rows
		)
		col = row.column(align=True)


		col.operator("object.vertex_group_add", icon='ADD', text="")
		props = col.operator("object.vertex_group_remove", icon='REMOVE', text="")
		props.all_unlocked = props.all = False

		col.separator()
		col.operator("lazyweight.vgroup_add_weightmix",text="",icon="MOD_VERTEX_WEIGHT")
		col.separator()

		col.menu("MESH_MT_vertex_group_context_menu", icon='DOWNARROW_HLT', text="")

		if obj.vertex_groups.active:
			col.separator()
			col.operator("object.vertex_group_move", icon='TRIA_UP', text="").direction = 'UP'
			col.operator("object.vertex_group_move", icon='TRIA_DOWN', text="").direction = 'DOWN'

		if (
				obj.vertex_groups and
				(obj.mode == 'EDIT' or
				 (obj.mode == 'WEIGHT_PAINT' and obj.type == 'MESH' and obj.data.use_paint_mask_vertex))
		):
			row = layout.row()

			sub = row.row(align=True)
			sub.operator("object.vertex_group_assign", text="Assign")
			sub.operator("object.vertex_group_remove_from", text="Remove")

			sub = row.row(align=True)
			sub.operator("object.vertex_group_select", text="Select")
			sub.operator("object.vertex_group_deselect", text="Deselect")

			layout.prop(context.tool_settings, "vertex_group_weight", text="Weight")




		# ob = context.object
		# group = ob.vertex_groups.active
		#
		# rows = 3
		# if group:
		# 	rows = 5
		#
		# row = layout.row()
		# row.template_list("MESH_UL_vgroups", "", ob, "vertex_groups", ob.vertex_groups, "active_index", rows=rows)
		#
		# col = row.column(align=True)
		#
		# col.operator("object.vertex_group_add", icon='ADD', text="")
		# props = col.operator("object.vertex_group_remove", icon='REMOVE', text="")
		# props.all_unlocked = props.all = False
		#
		# col.separator()
		#
		# col.menu("MESH_MT_vertex_group_context_menu", icon='DOWNARROW_HLT', text="")
		#
		# if group:
		# 	col.separator()
		# 	col.operator("object.vertex_group_move", icon='TRIA_UP', text="").direction = 'UP'
		# 	col.operator("object.vertex_group_move", icon='TRIA_DOWN', text="").direction = 'DOWN'
		#
		# if (
		# 		ob.vertex_groups and
		# 		(ob.mode == 'EDIT' or
		# 		 (ob.mode == 'WEIGHT_PAINT' and ob.type == 'MESH' and ob.data.use_paint_mask_vertex))
		# ):
		# 	row = layout.row()
		#
		# 	sub = row.row(align=True)
		# 	sub.operator("object.vertex_group_assign", text="Assign")
		# 	sub.operator("object.vertex_group_remove_from", text="Remove")
		#
		# 	sub = row.row(align=True)
		# 	sub.operator("object.vertex_group_select", text="Select")
		# 	sub.operator("object.vertex_group_deselect", text="Deselect")
		#
		# 	layout.prop(context.tool_settings, "vertex_group_weight", text="Weight")
