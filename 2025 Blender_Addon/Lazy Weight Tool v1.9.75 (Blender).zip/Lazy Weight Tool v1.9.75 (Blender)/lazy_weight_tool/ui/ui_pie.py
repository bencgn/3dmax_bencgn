import bpy
from bpy.types import Menu
from bpy.props import *

class LAZYWEIGHT_MT_pie_menu(Menu):
	bl_label = "Lazy Weight Tool"
	bl_idname = "LAZYWEIGHT_MT_pie_menu"

	@classmethod
	def poll(cls, context):
		return bpy.context.object and bpy.context.object.type == "MESH"

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		props_cy = props.copype

		pie = layout.menu_pie()
		obj = bpy.context.object


		#6 - LEFT
		pie.operator("lazyweight.select_edgeloop", icon='PARTICLE_PATH', text="Edge Loops")
		#6 - RIGHT
		if obj.mode=="WEIGHT_PAINT":
			pie.operator("object.vertex_group_smooth",text="Smooth",icon="MOD_SMOOTH")
		elif obj.mode=="VERTEX_PAINT":
			pie.operator("paint.vertex_color_set",text="Fill",icon="FILTER")
		else:
			pie.separator()
		#2 - BOTTOM
		if obj.mode=="TEXTURE_PAINT":
			pie.prop(obj.data,"use_paint_mask")
		else:
			pie.prop(obj.data,"use_paint_mask_vertex")


		#7 - TOP
		if obj.mode in {"WEIGHT_PAINT","EDIT"}:
			col_main = pie.column(align=True)
			col_main.separator()
			col_main.separator()
			col_main.separator()
			col_main.separator()
			col_main.separator()
			box = col_main.box()

			# #####################################################
			row = box.row(align=True)
			row.operator("object.vertex_group_smooth",text="Smooth",icon="MOD_SMOOTH")
			row.separator()
			rowz = row.row(align=True)
			rowz.scale_x = .7
			rowz.prop(props,"weight",text="")
			rows = row.row(align=True)
			row.scale_x = 1.8
			row.scale_y = 1.3
			setw = rows.operator("lazyweight.set_weight",text="",icon="IMPORT",emboss=False)
			setw.weight = props.weight
			setw.type = "REPLACE"
			setw.normalize = props.normalize
			setw = rows.operator("lazyweight.set_weight",text="",icon="ADD",emboss=False)
			setw.weight = props.weight
			setw.type = "ADD"
			setw.normalize = props.normalize
			setw = rows.operator("lazyweight.set_weight",text="",icon="REMOVE",emboss=False)
			setw.weight = props.weight
			setw.type = "SUBTRACT"
			setw.normalize = props.normalize



			#####################################################
			# オプション
			rows = box.row(align=True)
			rows.prop(props,"normalize",text="",icon="RNA",expand=True)

			rows.separator()
			if bpy.app.version >= (2,91,0):
				rows.prop(obj.data, "use_mirror_x", text="X", toggle=True,icon="BLANK1")
				rows.prop(obj.data, "use_mirror_y", text="Y", toggle=True,icon="BLANK1")
				rows.prop(obj.data, "use_mirror_z", text="Z", toggle=True,icon="BLANK1")
			else:
				vpaint = bpy.context.scene.tool_settings.weight_paint
				rows.prop(vpaint, "use_symmetry_x", text="X", toggle=True,icon="BLANK1")
				rows.prop(vpaint, "use_symmetry_y", text="Y", toggle=True,icon="BLANK1")
				rows.prop(vpaint, "use_symmetry_z", text="Z", toggle=True,icon="BLANK1")
			rows.separator()
			rowx = rows.row(align=True)
			rowx.scale_x = 1.5
			rowx.prop(props,"type",text="", expand=True)




			#######################################################
			row = box.row(align=True)
			row.scale_y = 1.3
			rowx = row.row(align=True)
			rowx.scale_x = .8
			rowx.scale_y = 1.5
			rowx.prop(props,"toggle_weight_volume_setting",text="",icon="DOWNARROW_HLT")


			cols = row.column(align=True)
			sub = cols.row(align=True)
			sub.scale_y = .5
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_01
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_01
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_01
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_02
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_02
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_02
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_03
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_03
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_03
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_04
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_04
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_04
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_05
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_05
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_05
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_06
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_06
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_06
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_07
			sub.operator("lazyweight.weight_brush_set",text="",icon="DOT").weight = props.weight_07
			sub.operator("lazyweight.weight_brush_set",text="",icon="BLANK1").weight = props.weight_07



			rows = cols.row(align=True)
			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_01",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_01,2)))
				setw.weight = props.weight_01
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_02",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_02,2)))
				setw.weight = props.weight_02
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_03",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_03,2)))
				setw.weight = props.weight_03
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_04",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_04,2)))
				setw.weight = props.weight_04
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_05",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_05,2)))
				setw.weight = props.weight_05
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_06",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_06,2)))
				setw.weight = props.weight_06
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize

			if props.toggle_weight_volume_setting:
				row_props = rows.row(align=True)
				row_props.scale_x = 0.5
				row_props.prop(props,"weight_07",text="",emboss=False)
			else:
				setw = rows.operator("lazyweight.set_weight",text=str(round(props.weight_07,2)))
				setw.weight = props.weight_07
				setw.type = props.type
				setw.type_another_mode = "NONE"
				setw.normalize = props.normalize
		else:
			if obj.mode=="TEXTURE_PAINT":
				box = pie.box()
				paint_data = bpy.context.scene.tool_settings.unified_paint_settings
				brush = bpy.context.scene.tool_settings.image_paint.brush
				box.prop(paint_data,"size")
				box.prop(brush,"strength")
			else:
				box = pie.box()
				paint_data = bpy.context.scene.tool_settings.unified_paint_settings
				brush = bpy.context.scene.tool_settings.vertex_paint.brush
				box.prop(paint_data,"size")
				box.prop(brush,"strength")

		 #7 - TOP - LEFT
		if obj.mode=="VERTEX_PAINT":
			pie.prop(obj.data,"use_paint_mask")
		else:
			pie.separator()

		#9 - TOP - RIGHT
		pie.separator()
		# 1 - BOTTOM - LEFT
		pie.operator("lazyweight.select_more",text="More", icon='ADD')
		#1 - BOTTOM - LEFT
		pie.operator("lazyweight.select_less",text="Less", icon='REMOVE')




		if obj.mode=="WEIGHT_PAINT":
			pie.separator()
			pie.separator()
			pie.separator()
			pie.separator()
			pie.separator()
			pie.separator()
			row = pie.row(align=True)
			col = row.column(align=True)
			col.separator(factor=14)
			col.operator("lazyweight.copy_weight",icon="COPYDOWN")
			col.operator("lazyweight.paste_weight",icon="PASTEDOWN")
			col.separator()
			col.prop(props_cy,"mode",text="")
			row.label(text="",icon="BLANK1")


			row = pie.row(align=True)
			row.label(text="",icon="BLANK1")
			col = row.column(align=True)
			# col.scale_x = .6
			col.separator(factor=12)
			box = col.box()
			box.menu("LAZYWEIGHT_MT_operator_menu")



			# col_ic = col.column(align=True)
			# col_ic.scale_x = 1.2
			# col_ic.scale_y = 1.2
			# row = col_ic.row(align=True)
			# row.operator("object.vertex_group_normalize_all", text="", icon="RNA_ADD")
			# row.operator("object.vertex_group_normalize", text="", icon="RNA")
			# row.label(text="",icon="BLANK1")
			#
			# row.operator("lazyweight.select_half",text="", icon="RESTRICT_SELECT_OFF") # Select Half
			# row.operator("object.vertex_group_mirror",text="", icon="MOD_MIRROR") # Mirror
			# row.operator("object.vertex_group_invert", text="", icon="UV_SYNC_SELECT") # Invert
			# row.operator("object.vertex_group_clean", text="", icon="TRASH") # Clean
			#
			# row = col_ic.row(align=True)
			# row.operator("object.vertex_group_quantize", text="", icon="COLORSET_10_VEC") # Quantize
			# row.operator("object.vertex_group_levels", text="", icon="ADD") # Levels
			# row.operator("object.vertex_group_smooth", text="", icon="MOD_SMOOTH") # Smooth
			# row.operator("object.vertex_group_limit_total", text="", icon="PARTICLE_POINT") # Limit Total
			# row.operator("object.vertex_group_fix", text="", icon="MOD_SIMPLEDEFORM") # Fix Deforms
			# row.operator("paint.weight_gradient",text="", icon="ADD")
			#
			#
			# row = col_ic.row(align=True)
			# op = row.operator("object.data_transfer", text="",icon="MOD_DATA_TRANSFER")
			# op.use_reverse_transfer = True
			# op.data_type = 'VGROUP_WEIGHTS'
			#
			# op = row.operator("lazyweight.weight_transfer_modifier_add",text="",icon="MODIFIER")
			# op.is_only_select_button = False
			# op = row.operator("lazyweight.weight_transfer_modifier_add",text="",icon="RESTRICT_SELECT_OFF")
			# op.is_only_select_button = True
			#
			# col_ic.prop(props_cy,"mix_mode",text="")
			# col_ic.prop(props_cy,"distance")
