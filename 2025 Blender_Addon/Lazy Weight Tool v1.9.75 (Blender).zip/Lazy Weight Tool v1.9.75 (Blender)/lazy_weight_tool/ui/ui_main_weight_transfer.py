import bpy
from bpy.props import *
from ..utils import preference

def ui_weight_transfer(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	if not addon_prefs.ui.usepanel_weight_transfer:
		row = layout.row(align=True)
		sp = layout.split(factor=0.7,align=True)
		row = sp.row(align=True)
		row.alignment = "LEFT"
		row.label(text="",icon="MOD_DATA_TRANSFER")
		row.prop(addon_prefs.ui, "ui_main_weight_transfer", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_weight_transfer else "TRIA_RIGHT", emboss=False)


		if not addon_prefs.ui.ui_main_weight_transfer:
			ui_weight_transfer_header_item(self,sp)


	if addon_prefs.ui.ui_main_weight_transfer or addon_prefs.ui.usepanel_weight_transfer:
		ui_weight_transfer_main(self,layout)


def ui_weight_transfer_header_item(self,layout):
	row = layout.row(align=True)
	row.alignment="RIGHT"
	op = row.operator("object.data_transfer", text="",icon="MOD_DATA_TRANSFER")
	op.use_reverse_transfer = True
	op.data_type = 'VGROUP_WEIGHTS'
	row.separator()
	op = row.operator("lazyweight.weight_transfer_modifier_add",text="",icon="MODIFIER")
	op.is_only_select_button = False
	op = row.operator("lazyweight.weight_transfer_modifier_add",text="",icon="RESTRICT_SELECT_OFF")
	op.is_only_select_button = True



def ui_weight_transfer_main(self,layout):
		props = bpy.context.scene.lazyweight
		addon_prefs = preference()

		box = layout.box()
		col = box.column(align=True)
		col.scale_y = 1.2
		op = col.operator("object.data_transfer", text="Weight Transfer",icon="MOD_DATA_TRANSFER")
		op.use_reverse_transfer = True
		op.data_type = 'VGROUP_WEIGHTS'
		box = layout.box()
		col = box.column(align=True)
		col.scale_y = 1.2

		op = col.operator("lazyweight.weight_transfer_modifier_add",text="Weight Transfer Modifier",icon="MODIFIER")
		op.is_only_select_button = False
		op = col.operator("lazyweight.weight_transfer_modifier_add",text="Weight Transfer Modifier (Only Selected)",icon="RESTRICT_SELECT_OFF")
		op.is_only_select_button = True
		# row = col.row(align=True)
		# row.alignment="LEFT"
		row = box.row(align=True)
		row.alignment="LEFT"
		row.prop(addon_prefs.ui,"toggle_menu_weight_transfer",icon="TRIA_DOWN" if addon_prefs.ui.toggle_menu_weight_transfer else "TRIA_RIGHT", emboss=False)
		if addon_prefs.ui.toggle_menu_weight_transfer:
			box_option = box.box()
			col_sub = box_option.column(align=True)

			draw_weight_transfer_option(props.weight_transfer,bpy.context,col_sub)



def draw_weight_transfer_option(self,context,layout):
	# flow = layout.column_flow(columns=2, align=True)
	# flow.prop(self, "mix_mode", expand=True)
	row = layout.row(align=True)
	row.label(text="",icon="ORIENTATION_GLOBAL")
	row.prop(self, "use_object_transform")
	layout.prop(self, "mix_mode")

	layout.separator()
	row = layout.row(align=True)
	row.label(text="",icon="MOD_UVPROJECT")
	row.prop(self,"vert_mapping")

	layout.separator()
	row = layout.row(align=True)
	row.label(text="Mix Factor",icon="NONE")
	row.prop(self,"mix_factor",text="")

	col = layout.column()
	row = col.row(align=True)
	row.label(text="Max Distance",icon="NONE")
	row.prop(self,"use_max_distance",text="")
	rows = row.row(align=True)
	rows.active = self.use_max_distance
	rows.prop(self,"max_distance")

	row = col.row(align=True)
	row.label(text="Ray Radius",icon="NONE")
	row.prop(self,"ray_radius",text="")

	# row = layout.row(align=True)
	# row.label(text="",icon="RESTRICT_SELECT_OFF")
	# row.prop(self,"only_select")

	row = layout.row(align=True)
	row.label(text="",icon="ADD")
	row.prop(self,"add_blank_bg")

	row = layout.row(align=True)
	row.label(text="",icon="GROUP_VERTEX")
	row.prop(self,"only_active_vertex_group")

	# layout.separator()
	# row = layout.row(align=True)
	# row.label(text="",icon="BLANK1")
	# row.prop(self,"return_active_select_on_exit")

	row = layout.row(align=True)
	row.label(text="",icon="FILE_TICK")
	row.prop(self,"modifier_apply")
