import bpy
from bpy.types import Panel, Menu
from bpy.props import *

from .ui_main_brush import *
from .ui_main_operator import *
from .ui_main_select import *
from .ui_main_set_weight import *
from .ui_main_table import *
from .ui_main_3column_vg import *
from .ui_main_weight_transfer import *
from .ui_main_copype import *


class LAZYWEIGHT_PT_table(Panel):
	bl_label = "Weight Table"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="VIEW_ORTHO")

	def draw_header_preset(self, context):
		layout = self.layout

		layout.menu("LAZYWEIGHT_MT_table_other",text="",icon="DOWNARROW_HLT")

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences


		#####################################################
		# テーブル
		ui_table(self, context)


class LAZYWEIGHT_PT_panel(Panel):
	bl_label = "Lazy Weight Tool"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		# return bpy.context.active_object
		return bpy.context.active_object and bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"}

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences


		# brush
		try:
			ui_brush(self, context)
		except: pass


		#####################################################
		# 数値設定
		# if not addon_prefs.ui.usepanel_set_weight:
		ui_set_weight(self, context)

		# オペレーター
		if not addon_prefs.ui.usepanel_operator:
			ui_operator(self, context)

		# ウェイト転送モディファイア
		if not addon_prefs.ui.usepanel_weight_transfer:
			ui_weight_transfer(self, context)

		# コピペ
		if not addon_prefs.ui.usepanel_copype:
			ui_copype(self, context)

		# 選択
		if not addon_prefs.ui.usepanel_select:
			ui_select(self, context)


		# 頂点グループ
		if not addon_prefs.ui.usepanel_3column_vg:
			ui_3column_vg(self, context)


# Copype
class LAZYWEIGHT_PT_copype(Panel):
	bl_label = "Copy / Paste"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object and bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"}


	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="COPYDOWN")

	def draw_header_preset(self, context):
		layout = self.layout
		ui_copype_header_item(self,layout)

	def draw(self, context):
		layout = self.layout
		ui_copype_main(self,layout)


# Operator
class LAZYWEIGHT_PT_operator(Panel):
	bl_label = "Operator"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object and bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"}

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="DOT")

	def draw_header_preset(self, context):
		layout = self.layout
		ui_operator_header_item(self,layout)

	def draw(self, context):
		layout = self.layout
		ui_operator(self,context)


# Select
class LAZYWEIGHT_PT_select(Panel):
	bl_label = "Select"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object and bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"}

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="RESTRICT_SELECT_OFF")

	def draw_header_preset(self, context):
		layout = self.layout
		ui_select_header_item(self,layout)

	def draw(self, context):
		layout = self.layout
		ui_select(self,context)


# 3column_vg
class LAZYWEIGHT_PT_3column_vg(Panel):
	bl_label = "3-Column Vertex Group"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="GROUP_VERTEX")

	def draw_header_preset(self, context):
		layout = self.layout
		ui_3column_vg_header_item(self,layout)

	def draw(self, context):
		layout = self.layout
		ui_3column_vg(self,context)


# Weight_transfer
class LAZYWEIGHT_PT_weight_transfer(Panel):
	bl_label = "Weight Transfer"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "Item"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return bpy.context.active_object and bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT","OBJECT"}

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="",icon="MOD_DATA_TRANSFER")

	def draw_header_preset(self, context):
		layout = self.layout
		ui_weight_transfer_header_item(self,layout)

	def draw(self, context):
		layout = self.layout
		ui_weight_transfer(self,context)
