import bpy
from .ui_panel_v_group import *
from .ui_panel import *


# 起動時に実行。パネルが有効の場合は読み込み
# アドオン設定のパネルメニュー切り替えをした時に実行
def regi_panel(prop_name,class_name):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

	try:
		if prefs.category:
			if "bl_rna" in class_name.__dict__:
				bpy.utils.unregister_class(class_name)

			class_name.bl_category = prefs.category
			if prop_name: # パネル表示設定が有効の場合
				bpy.utils.register_class(class_name)
		else:
			bpy.utils.unregister_class(class_name)


	except Exception as e:
		print("\n[{}]\n{}\n\nError:\n{}".format(__name__,"  !!  NO  !!  "  + str(class_name), e))
		pass


def update_regipanel_vertex_groups(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_vertex_groups,LAZYWEIGHT_PT_vertex_groups)

def update_regipanel_table(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_table,LAZYWEIGHT_PT_table)

def update_regipanel_3column_vg(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_3column_vg,LAZYWEIGHT_PT_3column_vg)

def update_regipanel_copype(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_copype,LAZYWEIGHT_PT_copype)

def update_regipanel_operator(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_operator,LAZYWEIGHT_PT_operator)

def update_regipanel_select(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_select,LAZYWEIGHT_PT_select)

def update_regipanel_weight_transfer(self,context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	regi_panel(prefs.ui.usepanel_weight_transfer,LAZYWEIGHT_PT_weight_transfer)


def update_panel(self, context):
	prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences
	cate = prefs.category
	message = ": Updating Panel locations has failed"

	for panel in panels:
		try:
			if cate:
				# パネルが無効の場合は再登録から無視する
				if panel == LAZYWEIGHT_PT_3column_vg:
					if not prefs.ui.usepanel_3column_vg:
						continue
				elif panel == LAZYWEIGHT_PT_weight_transfer:
					if not prefs.ui.usepanel_weight_transfer:
						continue
				elif panel == LAZYWEIGHT_PT_copype:
					if not prefs.ui.usepanel_copype:
						continue
				elif panel == LAZYWEIGHT_PT_operator:
					if not prefs.ui.usepanel_operator:
						continue
				elif panel == LAZYWEIGHT_PT_select:
					if not prefs.ui.usepanel_select:
						continue
				if panel == LAZYWEIGHT_PT_table:
					if not prefs.ui.usepanel_table:
						continue
				if panel == LAZYWEIGHT_PT_vertex_groups:
				  if not prefs.ui.usepanel_vertex_groups:
				    continue
				if "bl_rna" in panel.__dict__:
					bpy.utils.unregister_class(panel)

				panel.bl_category = cate
				bpy.utils.register_class(panel)

			else:
				try:
					bpy.utils.unregister_class(panel)
				except RuntimeError: pass

		except Exception as e:
			print("\n[{}]\n{}\n\nError:\n{}".format(__name__.partition('.')[0], message, e))
			pass


panels = ( # ここの順番でパネルが読み込まれる
		LAZYWEIGHT_PT_panel,

		LAZYWEIGHT_PT_operator,
		LAZYWEIGHT_PT_weight_transfer,
		LAZYWEIGHT_PT_copype,
		LAZYWEIGHT_PT_select,
		LAZYWEIGHT_PT_3column_vg,

		LAZYWEIGHT_PT_table,
		LAZYWEIGHT_PT_vertex_groups,
		)
