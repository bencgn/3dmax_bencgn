import bpy
from bpy.types import Operator, Menu
from ..utils import preference


class LAZYWEIGHT_MT_table_other(Menu):
	bl_label = "Other Menu"

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight

		layout.label(text="Vertex Index",icon="NONE")
		col = layout.column(align=True)
		col.active = (bpy.context.mode in {"EDIT_MESH","PAINT_WEIGHT"})
		col.prop(props, "vindex_is_running")
		col = col.column(align=True)
		if not props.vindex_is_running:
			col.active = False
		col.prop(props, "vindex_use_edit_mode")
		layout.separator(factor=3)
		layout.label(text="Highlight",icon="NONE")
		layout.prop(props,"table_highlight_toggle",icon="OUTLINER_DATA_LIGHT")
		col = layout.column(align=True)
		if not props.table_highlight_toggle:
			col.active = False

		col.prop(props,"table_highlight_value")
		col.operator("lazyweight.table_other",icon="DOWNARROW_HLT")
		layout.separator(factor=3)
		layout.label(text="Weight Table",icon="NONE")
		layout.prop(props,"table_filter_selected",icon="RESTRICT_SELECT_OFF")
		layout.prop(props,"table_filter_hide",icon="MOD_MASK")
		layout.prop(props,"table_slider",icon="NONE")
		layout.separator()
		layout.operator("lazyweight.vgroup_round_weight",icon="MOD_SMOOTH")


class LAZYWEIGHT_MT_table_highlight(Menu):
	bl_label = "Highlight Hit Range"

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		layout.prop(props,"table_highlight_type",expand=True)
		layout.prop(props,"table_highlight_hitrange",text="Highlight Hit Range")


class LAZYWEIGHT_MT_copype(Menu):
	bl_label = "Other Menu"

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		props_cy = props.copype

		layout.label(text="Paste Type",icon="NONE")
		layout.prop(props_cy,"mode",text="")
		layout.separator()
		layout.operator("lazyweight.clipboard_export",icon="EXPORT")
		# layout.operator("lazyweight.paste_weight",text="Paste (From the clipboard)",icon="PASTEDOWN").source_type = "CLIPBOARD"
		layout.operator("lazyweight.paste_weight",text="Paste (From the File)",icon="PASTEDOWN").source_type = "FILE"


class LAZYWEIGHT_MT_vertex_group(Menu):
	bl_label = "Other"

	def draw(self, context):
		layout = self.layout
		draw_vgroup_other_menu(self,layout)


def draw_vgroup_other_menu(self,layout):
	addon_prefs = preference()

	props = bpy.context.scene.lazyweight
	col = layout.column(align=True)
	row = col.row(align=True)
	row.label(text="",icon="RADIOBUT_OFF")
	row.prop(props,"vgroup_empty_to_darken")
	row = col.row(align=True)
	row.label(text="",icon="RADIOBUT_OFF")
	row.prop(props,"vgroup_empty_to_hide")
	row = col.row(align=True)
	row.label(text="",icon="RESTRICT_SELECT_OFF")
	row.prop(props,"vgroup_empty_only_select")
	col.separator()
	row = col.row(align=True)
	row.label(text="",icon="HIDE_ON")
	row.prop(props,"vgroup_hide_by_hide_bone")
	row = col.row(align=True)
	row.label(text="",icon="RESTRICT_SELECT_OFF")
	row.prop(props,"vgroup_hide_only_select_bone")
	col.separator()
	row = col.row(align=True)
	row.label(text="",icon="SORTSIZE")
	row.prop(addon_prefs.ui,"vgroup_use_bone_hierarchy")
	col.separator()
	row = col.row(align=True)
	row.label(text="",icon="MOD_VERTEX_WEIGHT")
	row.prop(addon_prefs.ui,"show_mod_vg_mix_menu")


class LAZYWEIGHT_MT_operator_menu(Menu):
	bl_label = "Operator"
	bl_idname = 'LAZYWEIGHT_MT_operator_menu'

	def draw(self, context):
		layout = self.layout
		props = bpy.context.scene.lazyweight
		props_cy = props.copype
		layout.operator("object.vertex_group_normalize_all", text="Normalize All", icon="RNA_ADD")
		layout.operator("object.vertex_group_normalize", text="Normalize", icon="RNA")
		layout.separator()
		layout.operator("lazyweight.select_half",text="Select Half", icon="RESTRICT_SELECT_OFF")
		layout.operator("object.vertex_group_mirror",text="Mirror", icon="MOD_MIRROR")

		layout.operator("object.vertex_group_invert", text="Invert", icon="UV_SYNC_SELECT")
		layout.operator("object.vertex_group_clean", text="Clean", icon="TRASH")
		layout.operator("object.vertex_group_quantize", text="Quantize", icon="COLORSET_10_VEC")
		layout.operator("object.vertex_group_levels", text="Levels", icon="ADD")
		layout.operator("object.vertex_group_smooth", text="Smooth", icon="MOD_SMOOTH")
		layout.operator("object.vertex_group_limit_total", text="Limit Total", icon="PARTICLE_POINT")
		layout.operator("object.vertex_group_fix", text="Fix Deforms", icon="MOD_SIMPLEDEFORM")

		layout.operator("paint.weight_gradient")
		layout.separator()


		op = layout.operator("object.data_transfer", text="Weight Transfer",icon="MOD_DATA_TRANSFER")
		op.use_reverse_transfer = True
		op.data_type = 'VGROUP_WEIGHTS'

		op = layout.operator("lazyweight.weight_transfer_modifier_add",text="Weight Transfer Modifier",icon="MODIFIER")
		op.is_only_select_button = False
		op = layout.operator("lazyweight.weight_transfer_modifier_add",text="Weight Transfer Modifier (Only Selected)",icon="RESTRICT_SELECT_OFF")
		op.is_only_select_button = True

		layout.separator()
		layout.label(text="Copy / Paste",icon="NONE")
		layout.prop(props_cy,"mix_mode",text="")
		layout.prop(props_cy,"distance")


class LAZYWEIGHT_OT_vgroup_other_popup_menu(Operator):
	bl_idname = "lazyweight.vgroup_other_popup_menu"
	bl_label = "Other Menu"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}

	def invoke(self, context, event):
		dpi_value = bpy.context.preferences.system.dpi
		addon_prefs = bpy.context.preferences.addons[__name__.partition('.')[0]].preferences

		return context.window_manager.invoke_popup(self)

	def draw(self, context):
		draw_vgroup_other_menu(self,self.layout)

	def execute(self, context):
		return {'FINISHED'}
