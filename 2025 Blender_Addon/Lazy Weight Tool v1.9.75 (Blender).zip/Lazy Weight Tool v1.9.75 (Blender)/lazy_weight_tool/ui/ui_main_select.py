import bpy
from bpy.props import *
from ..utils import preference


def ui_select(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight
	addon_prefs = preference()

	if not addon_prefs.ui.usepanel_select:
		row = layout.row(align=True)
		sp = layout.split(factor=0.5,align=True)
		row = sp.row(align=True)
		row.alignment = "LEFT"
		row.label(text="",icon="RESTRICT_SELECT_OFF")
		row.prop(addon_prefs.ui, "ui_main_select", icon="TRIA_DOWN" if addon_prefs.ui.ui_main_select else "TRIA_RIGHT", emboss=False)
		if not addon_prefs.ui.ui_main_select:
			ui_select_header_item(self,sp)


	if addon_prefs.ui.ui_main_select or addon_prefs.ui.usepanel_select:
		ui_select_main(self,layout)


def ui_select_header_item(self,layout):
	row = layout.row(align=True)
	row.alignment = "RIGHT"
	if bpy.context.object:
		obj = bpy.context.object
		if obj.type=="MESH":
			row.prop(obj.data,"use_paint_mask_vertex",text="")
			row.separator()

		if obj.mode in {'WEIGHT_PAINT','VERTEX_PAINT','TEXTURE_PAINT'}:
			row.operator("lazyweight.select_more",text="", icon="ADD")
			row.operator("lazyweight.select_less",text="", icon="REMOVE")


			row.operator("lazyweight.select_multiloop",text="", icon="MOD_INSTANCE")
			row.operator("lazyweight.select_edgeloop",text="", icon="PARTICLE_PATH")

			row.operator("lazyweight.select_half",text="", icon="AXIS_FRONT")
			row.operator("lazyweight.select_mirror",text="", icon="MOD_MIRROR")

		else:
			row.operator("mesh.select_more",text="", icon="ADD")
			row.operator("mesh.select_less",text="", icon="REMOVE")
			sel = row.operator("mesh.loop_multi_select",text="", icon="MOD_INSTANCE")
			sel.ring = True
			sel = row.operator("mesh.loop_multi_select",text="", icon="PARTICLE_PATH")
			sel.ring = False
			row.operator("lazyweight.select_half",text="", icon="AXIS_FRONT")
			row.operator("mesh.select_mirror",text="", icon="MOD_MIRROR")



def ui_select_main(self,layout):
	if bpy.context.object:
		obj = bpy.context.object
		if obj.type=="MESH":
			if obj.mode in {'WEIGHT_PAINT'}:
				layout.prop(obj.data,"use_paint_mask_vertex")
			elif obj.mode in {'VERTEX_PAINT'}:
				row = layout.row(align=True)
				row.prop(obj.data,"use_paint_mask")
				row.prop(obj.data,"use_paint_mask_vertex")
			elif obj.mode in {'TEXTURE_PAINT'}:
				layout.prop(obj.data,"use_paint_mask")
			else:
				layout.label(text="",icon="NONE")
		box = layout.box()
		sp = box.split(factor=0.5)
		sp.scale_y = 1.3
		rows = sp.row(align=True)
		rows.scale_x = 10
		if obj.mode in {'WEIGHT_PAINT','VERTEX_PAINT','TEXTURE_PAINT'}:
			rows.operator("lazyweight.select_more",text="", icon="ADD")
			rows.operator("lazyweight.select_less",text="", icon="REMOVE")

			row = sp.row(align=True)

			row.operator("lazyweight.select_multiloop",text="Ring", icon="MOD_INSTANCE")
			row.operator("lazyweight.select_edgeloop",text="Loop", icon="PARTICLE_PATH")

		else:
			rows.operator("mesh.select_more",text="", icon="ADD")
			rows.operator("mesh.select_less",text="", icon="REMOVE")


			row = sp.row(align=True)
			sel = row.operator("mesh.loop_multi_select",text="Ring", icon="MOD_INSTANCE")
			sel.ring = True
			sel = row.operator("mesh.loop_multi_select",text="Loop", icon="PARTICLE_PATH")
			sel.ring = False

		row = box.row(align=True)
		row.operator("lazyweight.select_half",text="Select Half", icon="AXIS_FRONT")

		if not obj.mode == 'EDIT':
			row.operator("lazyweight.select_mirror",text="Mirror", icon="MOD_MIRROR")
			try:
				# row.operator("paint.vert_select_all",text="", icon="UV_SYNC_SELECT").action='INVERT'
				if obj.data.use_paint_mask_vertex:
					row.operator("paint.vert_select_all",text="", icon="UV_SYNC_SELECT").action='INVERT'
				else:
					row.operator("paint.face_select_all",text="", icon="UV_SYNC_SELECT").action='INVERT'

			except: pass
		else:
			row.operator("mesh.select_mirror",text="Mirror", icon="MOD_MIRROR")
			row.operator("mesh.select_all",text="", icon="UV_SYNC_SELECT").action='INVERT'

	else:
		box = layout.box()
		box.label(text="No Active Object",icon="NONE")
