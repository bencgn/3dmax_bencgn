import bpy
from bpy.types import Menu
from bpy.props import *


def vgroup_menu_other(self, context):
	layout = self.layout
	props = bpy.context.scene.lazyweight

	layout.separator()
	layout.operator("lazyweight.vgroup_remove_empty",icon="DRIVER_TRANSFORM")
	layout.operator("lazyweight.vgroup_round_weight",icon="MOD_SMOOTH")
	layout.operator("lazyweight.vgroup_add_symmetry",icon="MOD_MIRROR")
	layout.operator("lazyweight.vertex_groups_generate_blank_vg",icon="OBJECT_DATAMODE")
	layout.operator("lazyweight.vertex_groups_set_actvg_of_selobjs",icon="OBJECT_DATAMODE")
	layout.prop(props,"auto_set_actvg_of_selobjs")
	layout.operator("lazyweight.vgroup_add_weightmix",icon="MOD_VERTEX_WEIGHT")
	layout.operator("lazyweight.apply_dynamic_paint",icon="MOD_DYNAMICPAINT")
	layout.operator("lazyweight.adjust_weight_gesture",icon="MOUSE_MMB_DRAG")

	# layout.separator()
	# layout.operator("lazyweight.vgroup_batch_rename",icon="SORTALPHA")
	# layout.operator("lazyweight.apply_dynamic_paint",icon="MOD_DYNAMICPAINT")
