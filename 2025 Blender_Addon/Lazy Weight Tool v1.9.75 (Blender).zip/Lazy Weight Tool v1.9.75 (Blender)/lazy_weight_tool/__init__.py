# Lazy Weight Tool Addon (C) 2019-2023 Bookyakuno
# Created by Bookyakuno
# Some operators : Scramble Addon (by Saidenka)
	# - Weighting object intersections

bl_info = {
	"name": "Lazy Weight Tool",
	"author": "Bookyakuno",
	"version": (1, 9, 75),
	"blender": (3,6,0),
	"location": "Weight Paint Mode → Property Panel(N key) → Item",
	"description": "Simplify vertex selection in the Weight Paint and assign numerical weights",
	"category": "3D View",
}

import bpy
import os, csv, codecs #辞書
from bpy.types import AddonPreferences
from bpy.props import *
import rna_keymap_ui # キーマップリストに必要



if 'bpy' in locals():
    from importlib import reload
    import sys
    for k, v in list(sys.modules.items()):
        if k.startswith('lazy_weight_tool.'):
            reload(v)


# このモジュールごとに分ける配置は必要
from .keymap import *
from .property import *

from . import (
op,
ui,
utils,
)

from .ui.ui_panel_v_group import LAZYWEIGHT_PT_vertex_groups
from .ui.def_regi_panel import update_panel
from .property import LAZYWEIGHT_PR_ui


class LAZYWEIGHT_MT_AddonPreferences(AddonPreferences):
	bl_idname = __name__

	category : StringProperty(name="Tab Category", description="Choose a name for the category of the panel", default="Item", update=update_panel )
	tab_addon_menu : EnumProperty(name="Tab", description="", items=[('OPTION', "Option", "","DOT",0),('DISPLAY', "Display", "","DOT",1),('KEYMAP', "Keymap", "","KEYINGSET",2), ('Link', "Link", "","URL",3)], default='OPTION')
	index_text_color    : FloatVectorProperty(name="Index Text Color", default=(0.8, 0.8, 0.8, 1.0), size=4, subtype="COLOR", min=0, max=1)
	index_font_size : IntProperty(name="Font Size",default=20,min=1)
	ui : PointerProperty(name="ui",type=LAZYWEIGHT_PR_ui)

	adjust_weight_status_shift : BoolProperty()
	adjust_weight_status_ctrl : BoolProperty()
	adjust_weight_status_normalize : BoolProperty(default=True)
	adjust_weight_status_target : EnumProperty(default="ACTIVE",name = "Target Object", items=
	[
	("ACTIVE","Active Object",""),
	("SELECTED","Selected Objects",""),

	 ])

	mirror_vg_namesets : StringProperty(name="Mirror Vertex Group Name Sets",default="('.L','.R'),('_L','_R')",description="A name sets that is recognized as mirror symmetry by the set weight function.\nYou can add new name sets like, ('hoge','huga')")



	def draw(self, context):
		layout = self.layout


		row = layout.row(align=True)
		row.prop(self, "tab_addon_menu",expand=True)


		if self.tab_addon_menu=="OPTION":
			box = layout.box()
			col = box.column()
			col.use_property_split = True
			col.use_property_decorate = False
			col.label(text="Vertex Index Text (Weight Table > Other Menu)",icon="DOT")
			col.prop(self, "index_text_color")
			col.prop(self, "index_font_size")

			col = layout.column(align=True)
			col.prop(self,"mirror_vg_namesets")



		if self.tab_addon_menu=="DISPLAY":
			row = layout.row()
			row.label(text="Tab Category:")
			row.prop(self, "category", text="")
			box = layout.box()
			col = box.column(align=True)
			col.label(text="Display in individual panel menu",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_operator",text="",icon="DOT")
			row.label(text="Operator",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_weight_transfer",text="",icon="MOD_DATA_TRANSFER")
			row.label(text="Weight Transfer",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_copype",text="",icon="COPYDOWN")
			row.label(text="Copy / Paste",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_select",text="",icon="RESTRICT_SELECT_OFF")
			row.label(text="Select",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_3column_vg",text="",icon="GROUP_VERTEX")
			row.label(text="3-Column Vertex Group",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_table",text="",icon="VIEW_ORTHO")
			row.label(text="Table",icon="NONE")
			row = col.row()
			row.prop(self.ui,"usepanel_vertex_groups",text="",icon="GROUP_VERTEX")
			row.label(text="Vertex Groups",icon="NONE")


		# KEYMAP
		if self.tab_addon_menu=="KEYMAP":
			box = layout.box()
			col = box.column()
			col.label(text="Keymap List:",icon="KEYINGSET")


			wm = bpy.context.window_manager
			kc = wm.keyconfigs.user
			old_km_name = ""
			get_kmi_l = []
			for km_add, kmi_add in addon_keymaps:
				for km_con in kc.keymaps:
					if km_add.name == km_con.name:
						km = km_con
						break

				for kmi_con in km.keymap_items:
					if kmi_add.idname == kmi_con.idname:
						if kmi_add.name == kmi_con.name:
							get_kmi_l.append((km,kmi_con))

			get_kmi_l = sorted(set(get_kmi_l), key=get_kmi_l.index)

			for km, kmi in get_kmi_l:
				if not km.name == old_km_name:
					col.label(text=str(km.name),icon="DOT")
				col.context_pointer_set("keymap", km)
				rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
				col.separator()
				old_km_name = km.name



		################################################
		# URL
		if self.tab_addon_menu=="Link":
			layout.operator("wm.url_open", text="gumroad", icon="URL").url = "https://gum.co/gPWgE"
			layout.operator("wm.url_open", text="Blender Market", icon="URL").url = "https://blendermarket.com/products/lazy-weight-tool"
			layout.operator("wm.url_open", text="BOOTH", icon="URL").url = "https://booth.pm/ja/items/1551357"
			layout.separator()
			layout.operator("wm.url_open", text="Documents", icon="URL").url = "https://bookyakuno.com/lazy-weight-tool"


classes = (
LAZYWEIGHT_PR_ui,
LAZYWEIGHT_PR_copype,
LAZYWEIGHT_PR_weight_transfer,
LAZYWEIGHT_PR_Other,
LAZYWEIGHT_PR_vg,
LAZYWEIGHT_PR_bone,

LAZYWEIGHT_MT_AddonPreferences,
)


# 翻訳辞書の取得
def GetTranslationDict():
	dict = {}
	path = os.path.join(os.path.dirname(__file__), "translation_dictionary.csv")
	with codecs.open(path, 'r', 'utf-8') as f:
		reader = csv.reader(f)
		dict['ja_JP'] = {}
		for row in reader:
			for context in bpy.app.translations.contexts:
				dict['ja_JP'][(context, row[1].replace('\\n', '\n'))] = row[0].replace('\\n', '\n')

	return dict



def register():
	for cls in classes:
		bpy.utils.register_class(cls)

	try:
		translation_dict = GetTranslationDict()
		bpy.app.translations.register(__name__, translation_dict)
	except: pass


	ui.register()
	op.register()
	add_hotkey()

	bpy.types.Scene.lazyweight = PointerProperty(type=LAZYWEIGHT_PR_Other)
	bpy.types.PoseBone.lazyweight = PointerProperty(type=LAZYWEIGHT_PR_bone)

def unregister():
	try:
		bpy.app.translations.unregister(__name__)
	except: pass

	ui.unregister()
	op.unregister()
	remove_hotkey()

	del bpy.types.Scene.lazyweight
	del bpy.types.PoseBone.lazyweight

	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)


if __name__ == "__main__":
	register()
