import bpy
from bpy.types import Operator
from . import classes
from . import utils
from . import ui
from . import props

class OBJECT_MT_curves_to_mesh(bpy.types.Menu):
    bl_idname = 'OBJECT_MT_curves_to_mesh'
    bl_label = 'Curves To Mesh'

    def draw(self, context):
        layout = self.layout
        layout.operator(OBJECT_MT_CurvesToMeshPreviewOperator.bl_idname, icon='IPO_BACK')
        layout.operator(OBJECT_MT_CurvesToMeshCommitOperator.bl_idname, icon='PARTICLE_PATH')

class OBJECT_MT_CurvesToMeshPreviewOperator(Operator, classes.CurvesToSurface):
    """Tooltip"""
    bl_idname = "curvestomesh.preview_operator"
    bl_label = "Preview Curves To Mesh"
    bl_options = {'REGISTER', 'INTERNAL'}

    def modal(self, context, event):
        """Modal execution method for the addon."""

        try:
            if not self.validate_region() or \
                not context.scene.c2m_preview_mode \
                or not self.poll(context):
                self.cancel(context)
                return {'CANCELLED'}

            # standard running mode: get the curve and determine whether anything has changed.
            curves = utils.get_curves(context.scene)
            has_mesh_changed = utils.has_changed(self, context.scene, curves, self.new_curves, self.old_curves)

            # if something has changed, recalculate the mesh.
            if has_mesh_changed:
                self.generate_mesh(context, context.scene)
                bpy.context.area.tag_redraw()
                context.region.tag_redraw()
                layer = context.view_layer
                layer.update()
            # just pass through so the user can keep interacting with Blender after the mesh has been recalculated.
            return {'PASS_THROUGH'}
        except Exception as e:
            self.cancel(context)
            self.report({'ERROR'}, "An error occured: " + str(e))
            return {'CANCELLED'}

    def invoke(self, context, event):
        """Initialise the operator."""

        if context.area.type == 'VIEW_3D':
            self.initialise(context, event)
            # set up modal handler.
            context.window_manager.modal_handler_add(self)
            if hasattr(context.scene, 'c2m_preview_mode'):
                context.scene.c2m_preview_mode = True
            # ...and away we go...
            return {'RUNNING_MODAL'}
        else:
            return {'CANCELLED'}

class OBJECT_MT_CurvesToMeshCommitOperator(Operator, classes.CurvesToSurface):
    """Tooltip"""
    bl_idname = "curvestomesh.commit_operator"
    bl_label = "Apply Curves To Mesh"
    bl_options = {'REGISTER', 'INTERNAL', 'UNDO'}

    def invoke(self, context, event):
        """Initialise the operator."""
        if context.area.type == 'VIEW_3D':
            self.initialise(context, event)
            # ...and away we go...
            return self.execute(context)

    def execute(self, context):
        """Standard operator execute function."""
        if hasattr(context.scene, 'c2m_preview_mode'):
            context.scene.c2m_preview_mode = False
        self.generate_mesh(context, context.scene, True)
        self.create_mesh(context, context.scene)
        self.cancel(context)
        return {'FINISHED'}

class OBJECT_MT_CurvesToMeshGlobalOperator(Operator, classes.CurvesToSurface):
    """Tooltip"""
    bl_idname = "curvestomesh.global_operator"
    bl_label = "Curves To Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    c2m_curve_method : bpy.props.EnumProperty(items= props.creation_method_items,
                                                     name = "Conversion Type", default='curve_surface_to_mesh')

    c2m_collection : bpy.props.StringProperty(name="Operate on", default="Collection")

    c2m_number_of_cuts_across : bpy.props.IntProperty(
                name="Cuts Across",
                description="Number of divisions across the surface",
                min=0,
                default=10
            )

    c2m_number_of_cuts_down : bpy.props.IntProperty(
            name="Cuts down",
            description="Number of divisions down the surface",
            min=0,
            default=10
        )

    c2m_flip_normals : bpy.props.BoolProperty(
            name="Flip Normals",
            description="Flip normals of surface",
            default=False
        )

    c2m_shade_smooth : bpy.props.BoolProperty(
            name="Shade Smooth",
            description="Shade smooth the faces",
            default=True
            )

    c2m_show_all_edges : bpy.props.BoolProperty(
            name="Show All Edges",
            description="Show all the created edges of the surface",
            default=False
        )

    c2m_show_wire : bpy.props.BoolProperty(
            name="Show Wire",
            description="Show the wireframe of the surface",
            default=False
        )

    c2m_mirror_x : bpy.props.BoolProperty(
            name="Mirror X",
            description="Mirror along X axis",
            default=False
            )

    c2m_mirror_y : bpy.props.BoolProperty(
            name="Mirror Y",
            description="Mirror along Y axis",
            default=False
            )

    c2m_mirror_z : bpy.props.BoolProperty(
            name="Mirror Z",
            description="Mirror along Z axis",
            default=False
            )

    c2m_direction_check : bpy.props.BoolProperty(
            name="Direction Check",
            description="Check that curves loops are in a cyclic direction before creating geometry",
            default=False
        )

    c2m_use_resolution : bpy.props.BoolProperty(
            name="Use Resolution",
            description="Use resolution settings on curves to control subdivisions",
            default=False
        )

    c2m_samples_between_points : bpy.props.IntProperty(
            name="Samples Between Points",
            description="Number of samples between points used to distribute evenly",
            min=1,
            default=1000
        )

    c2m_number_of_nudges : bpy.props.IntProperty(
            name="Number of Nudges",
            description="Number of nudges to distribute points evenly",
            min=0,
            default=10
        )

    c2m_precision : bpy.props.IntProperty(
            name="Precision",
            description="Precision when interpolating between bezier points",
            min=1,
            default=100
        )

    c2m_round_to_decimals : bpy.props.IntProperty(
            name="Round corner points to",
            description="Merge vertices by rounding them to a number of decimal places.",
            min=0,
            default=3
        )

    c2m_snap_verts : bpy.props.BoolProperty(
            name="Snap Vertices",
            description="Snap vertices to closest curve points",
            default=True
        )

    c2m_twist : bpy.props.IntProperty(
            name="Twist",
            description="Twist offset for closed loops",
            default=0
        )

    c2m_bridge_order : bpy.props.EnumProperty(items= props.bridge_order_items,
                                                     name = "Bridging Order", default='PROXIMITY')

    c2m_bridge_order_reversed : bpy.props.BoolProperty(
            name="Reverse",
            description="Reverse the order of the curves.  Try if an incorrect result occurs.",
            default=False
        )

    def invoke(self, context, event):
        """Initialise the operator."""
        if context.area.type == 'VIEW_3D':
            self.initialise(context, event)
            # ...and away we go...
            return self.execute(context)

    def execute(self, context):
        """Standard operator execute function."""
        if hasattr(context.scene, 'c2m_preview_mode'):
            context.scene.c2m_preview_mode = False
        self.generate_mesh(context, self, True)
        self.create_mesh(context, self)
        self.cancel(context)
        return {'FINISHED'}

class OBJECT_MT_CurvesToMeshIncreaseSubDAcrossOperator(Operator):
   """Tooltip"""
   bl_idname = "curvestomesh.increase_subd_across_operator"
   bl_label = "C2M Increase Subdivisions Across"
   bl_options = {'INTERNAL'}


   def execute(self, context):
       context.scene.c2m_number_of_cuts_across+=1
       return {'FINISHED'}

class OBJECT_MT_CurvesToMeshDecreaseSubDAcrossOperator(Operator):
   """Tooltip"""
   bl_idname = "curvestomesh.decrease_subd_across_operator"
   bl_label = "C2M Decrease Subdivisions Across"
   bl_options = {'INTERNAL'}

   def execute(self, context):
       context.scene.c2m_number_of_cuts_across-=1
       return {'FINISHED'}

class OBJECT_MT_CurvesToMeshIncreaseSubDDownOperator(Operator):
   """Tooltip"""
   bl_idname = "curvestomesh.increase_subd_down_operator"
   bl_label = "C2M Increase Subdivisions Down"
   bl_options = {'INTERNAL'}

   def execute(self, context):
       context.scene.c2m_number_of_cuts_down+=1
       return {'FINISHED'}

class OBJECT_MT_CurvesToMeshDecreaseSubDOperator(Operator):
   """Tooltip"""
   bl_idname = "curvestomesh.decrease_subd_down_operator"
   bl_label = "C2M Decrease Subdivision Down"
   bl_options = {'INTERNAL'}

   def execute(self, context):
       context.scene.c2m_number_of_cuts_down-=1
       return {'FINISHED'}

class OBJECT_MT_CurvesToMeshForceRefreshOperator(Operator):
   """Tooltip"""
   bl_idname = "curvestomesh.force_refresh_operator"
   bl_label = "C2M Force Refresh"
   bl_options = {'INTERNAL'}

   def execute(self, context):
       context.scene.c2m_is_dirty=True
       return {'FINISHED'}

class OBJECT_MT_CurvesToMeshCancelOperator(Operator, classes.CurvesToSurface):
   """Tooltip"""
   bl_idname = "curvestomesh.cancel_operator"
   bl_label = "C2M Cancel"
   bl_options = {'INTERNAL'}

   def execute(self, context):
       context.scene.c2m_preview_mode = False
       return {'FINISHED'}

def menu_func_curves_to_surface(self, context):
    self.layout.menu(OBJECT_MT_curves_to_mesh.bl_idname, icon='IPO_BOUNCE')

def menu_func_curves_to_surface_context(self, context):
    self.layout.operator(OBJECT_MT_CurvesToMeshCommitOperator.bl_idname, text='Apply Curves To Mesh', icon='PARTICLE_PATH')

def append_to_menu():
    bpy.types.VIEW3D_MT_object.append(menu_func_curves_to_surface)
    bpy.types.VIEW3D_MT_edit_curve.append(menu_func_curves_to_surface)
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func_curves_to_surface_context)
    bpy.types.VIEW3D_MT_edit_curve_context_menu.append(menu_func_curves_to_surface_context)

def remove_from_menu():
    bpy.types.VIEW3D_MT_object.remove(menu_func_curves_to_surface)
    bpy.types.VIEW3D_MT_edit_curve.remove(menu_func_curves_to_surface)
    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func_curves_to_surface_context)
    bpy.types.VIEW3D_MT_edit_curve_context_menu.remove(menu_func_curves_to_surface_context)
