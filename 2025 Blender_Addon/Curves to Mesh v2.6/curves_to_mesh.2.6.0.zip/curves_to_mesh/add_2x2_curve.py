import bpy
from bpy.types import Operator
from bpy.props import FloatVectorProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector


def add_2x2_curve(self, context):
    scale_x = self.scale.x
    scale_y = self.scale.y

    verts = [
        Vector((-1 * scale_x, 1 * scale_y, 0)),
        Vector((1 * scale_x, 1 * scale_y, 0)),
        Vector((1 * scale_x, -1 * scale_y, 0)),
        Vector((-1 * scale_x, -1 * scale_y, 0)),
    ]

    curve = bpy.data.curves.new(name="2x2 Bezier Curve", type='CURVE')
    curve.dimensions = '3D'

    for i in range(0,4):
        spline = curve.splines.new(type='BEZIER')

        spline.bezier_points.add(1)


    top = curve.splines[0]
    right = curve.splines[1]
    bottom = curve.splines[2]
    left = curve.splines[3]

    top.bezier_points[0].handle_left = verts[0] + Vector((-0.5,0,0))
    top.bezier_points[0].co = verts[0]
    top.bezier_points[0].handle_right = verts[0] + Vector((0.5,0,0))
    top.bezier_points[1].handle_left  = verts[1] + Vector((-0.5,0,0))
    top.bezier_points[1].co  = verts[1]
    top.bezier_points[1].handle_right = verts[1] + Vector((0.5,0,0))

    right.bezier_points[0].handle_left = verts[1] + Vector((0,0.5,0))
    right.bezier_points[0].co  = verts[1]
    right.bezier_points[0].handle_right = verts[1] + Vector((0,-0.5,0))
    right.bezier_points[1].handle_left = verts[2] + Vector((0,0.5,0))
    right.bezier_points[1].co  = verts[2]
    right.bezier_points[1].handle_right = verts[2] + Vector((0,-0.5,0))

    bottom.bezier_points[0].handle_left  = verts[2] + Vector((0.5,0,0))
    bottom.bezier_points[0].co  = verts[2]
    bottom.bezier_points[0].handle_right  = verts[2] + Vector((-0.5,0,0))
    bottom.bezier_points[1].handle_left  = verts[3] + Vector((0.5,0,0))
    bottom.bezier_points[1].co  = verts[3]
    bottom.bezier_points[1].handle_right  = verts[3] + Vector((-0.5,0,0))

    left.bezier_points[0].handle_left = verts[3] + Vector((0,-0.5,0))
    left.bezier_points[0].co  = verts[3]
    left.bezier_points[0].handle_right = verts[3] + Vector((0,0.5,0))
    left.bezier_points[1].handle_left  = verts[0]  + Vector((0,-0.5,0))
    left.bezier_points[1].co  = verts[0]
    left.bezier_points[1].handle_right  = verts[0] + Vector((0,0.5,0))

    object_data_add(context, curve)


class OBJECT_OT_add_2x2_curve(Operator, AddObjectHelper):
    """Create a new 2x2 Bezier Curve"""
    bl_idname = "curve.add_2x2"
    bl_label = "Add 2x2 Curve Object"
    bl_options = {'REGISTER', 'UNDO'}

    scale : FloatVectorProperty(
        name="scale",
        default=(1.0, 1.0, 1.0),
        subtype='TRANSLATION',
        description="scaling",
    )

    def execute(self, context):

        add_2x2_curve(self, context)

        return {'FINISHED'}


# Registration
def append_to_menu():
    bpy.types.VIEW3D_MT_curve_add.append(add_2x2_curve_button)


def remove_from_menu():
    bpy.types.VIEW3D_MT_curve_add.remove(add_2x2_curve_button)


def add_2x2_curve_button(self, context):
    self.layout.operator(
        OBJECT_OT_add_2x2_curve.bl_idname,
        text="2x2 Bezier Patch",
        icon='OUTLINER_OB_SURFACE')


# This allows you to right click on a button and link to the manual
def add_object_manual_map():
    url_manual_prefix = "https://docs.blender.org/manual/en/dev/"
    url_manual_mapping = (
        ("bpy.ops.mesh.add_object", "editors/3dview/object"),
    )
    return url_manual_prefix, url_manual_mapping
