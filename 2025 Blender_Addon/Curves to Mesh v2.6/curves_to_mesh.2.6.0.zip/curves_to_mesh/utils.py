import bpy
import bmesh
from collections import deque
import mathutils
from mathutils import Vector, Quaternion, Matrix
from . import props
import numpy as np
from math import sqrt, radians

def scene_chosenobject_poll(self, object):
    """Filters the object chooser."""
    return object.type == 'CURVE' and object.users > 0

def add_properties(container):

    container.c2m_preview_mode = bpy.props.BoolProperty(
            name="Is Preview Mode",
            default=False,
            options={'SKIP_SAVE'}
        )

    container.c2m_is_dirty = bpy.props.BoolProperty(
            name="Is Dirty",
            description="Show the wireframe of the surface",
            default=True,
            options={'SKIP_SAVE'}
        )

    def set_dirty(self, context):
        """Set whether the operator should update itself"""
        context.scene.c2m_is_dirty = True

    container.c2m_curve_method = bpy.props.EnumProperty(items= (('curve_surface_to_mesh', 'Surface to Mesh', ''),
                                                     ('curve_profiles_to_mesh', 'Profiles to Mesh', ''),
                                                     ('curve_sweep_to_mesh', 'Sweep to Mesh', '')),
                                                     name = "Conversion Type", default='curve_surface_to_mesh',
                                                     update=set_dirty)

    container.c2m_collection = bpy.props.StringProperty(name="Operate on", default="Collection", update=set_dirty)

    container.c2m_number_of_cuts_across = bpy.props.IntProperty(
                name="Cuts Across",
                description="Number of divisions across the surface",
                min=0,
                default=10,
                update=set_dirty
            )

    container.c2m_number_of_cuts_down = bpy.props.IntProperty(
            name="Cuts down",
            description="Number of divisions down the surface",
            min=0,
            default=10,
            update=set_dirty
        )

    container.c2m_flip_normals = bpy.props.BoolProperty(
            name="Flip Normals",
            description="Flip normals of surface",
            default=False,
            update=set_dirty
        )

    container.c2m_shade_smooth = bpy.props.BoolProperty(
            name="Shade Smooth",
            description="Shade smooth the faces",
            default=True,
            update=set_dirty
            )

    container.c2m_show_all_edges = bpy.props.BoolProperty(
            name="Show All Edges",
            description="Show all the created edges of the surface",
            default=False,
            update=set_dirty
        )

    container.c2m_show_wire = bpy.props.BoolProperty(
            name="Show Wire",
            description="Show the wireframe of the surface",
            default=False,
            update=set_dirty
        )

    container.c2m_mirror_x = bpy.props.BoolProperty(
            name="Mirror X",
            description="Mirror along X axis",
            default=False,
            update=set_dirty
            )

    container.c2m_mirror_y = bpy.props.BoolProperty(
            name="Mirror Y",
            description="Mirror along Y axis",
            default=False,
            update=set_dirty
            )

    container.c2m_mirror_z = bpy.props.BoolProperty(
            name="Mirror Z",
            description="Mirror along Z axis",
            default=False,
            update=set_dirty
            )

    container.c2m_direction_check = bpy.props.BoolProperty(
            name="Direction Check",
            description="Check that curves loops are in a cyclic direction before creating geometry",
            default=False,
            update=set_dirty
        )

    container.c2m_remove_double_distance = bpy.props.FloatProperty(
            name="Remove Double Distance",
            description="Distance when removing doubles in calculation",
            default=0.001,
            precision=5,
            update=set_dirty
        )

    container.c2m_use_resolution = bpy.props.BoolProperty(
            name="Use Resolution",
            description="Use resolution settings on curves to control subdivisions",
            default=False,
            update=set_dirty
        )

    container.c2m_samples_between_points = bpy.props.IntProperty(
            name="Samples Between Points",
            description="Number of samples between points used to distribute evenly",
            min=1,
            default=1000,
            update=set_dirty
        )

    container.c2m_number_of_nudges = bpy.props.IntProperty(
            name="Number of Nudges",
            description="Number of nudges to distribute points evenly",
            min=0,
            default=10,
            update=set_dirty
        )

    container.c2m_precision = bpy.props.IntProperty(
            name="Precision",
            description="Precision when interpolating between bezier points",
            min=1,
            default=100,
            update=set_dirty
        )

    container.c2m_round_to_decimals = bpy.props.IntProperty(
            name="Decimal places to round to",
            description="Merge connected points by rounding them to a number of decimal places.",
            min=0,
            default=3,
            update=set_dirty
        )

    container.c2m_snap_verts = bpy.props.BoolProperty(
            name="Snap Vertices",
            description="Snap vertices to closest curve points",
            default=True,
            update=set_dirty
        )

    container.c2m_twist = bpy.props.IntProperty(
            name="Twist",
            description="Twist offset for closed loops",
            default=0,
            update=set_dirty
        )

    container.c2m_bridge_order = bpy.props.EnumProperty(items= props.bridge_order_items,
                                                     name = "Bridging Order", default='PROXIMITY', update=set_dirty)


    container.c2m_bridge_order_reversed = bpy.props.BoolProperty(
            name="Reverse",
            description="Reverse the order of the curves.  Try if an incorrect result occurs.",
            default=False,
            update=set_dirty
        )

    container.c2m_sweep_curve = bpy.props.PointerProperty(
                name="Profile Curve",
                type=bpy.types.Object,
                update=set_dirty,
                poll=scene_chosenobject_poll
            )

    container.c2m_sweep_curve_subd = bpy.props.IntProperty(
            name="Sweep Curve Accuracy",
            description="Accuracy level when aligning cross sections to the sweep curve.  Higher levels will improve accuracy of placed points",
            default=500,
            update=set_dirty
        )

def del_properties(container):
    del container.c2m_number_of_cuts_across
    del container.c2m_is_dirty
    del container.c2m_number_of_cuts_down
    del container.c2m_flip_normals
    del container.c2m_shade_smooth
    del container.c2m_show_all_edges
    del container.c2m_show_wire
    del container.c2m_mirror_x
    del container.c2m_mirror_y
    del container.c2m_mirror_z
    del container.c2m_direction_check
    del container.c2m_use_resolution
    del container.c2m_samples_between_points
    del container.c2m_number_of_nudges
    del container.c2m_precision
    del container.c2m_round_to_decimals
    del container.c2m_snap_verts
    del container.c2m_twist
    del container.c2m_sweep_curve
    del container.c2m_sweep_curve_subd
    del container.c2m_curve_method
    del container.c2m_preview_mode
    del container.c2m_collection

def dpi():
    """Determine Dots Per Inch for operating system."""
    systemPreferences = bpy.context.preferences.system
    retinaFactor = getattr(systemPreferences, "pixel_size", 1)
    return int(systemPreferences.dpi * retinaFactor)

def interpBez3(bp0, t, bp3):
    """Interpolate two beziers at t"""
    return interpBez3_(bp0.co, bp0.handle_right, bp3.handle_left, bp3.co, t)

def interpBez3_(p0, p1, p2, p3, t):
    """Interpolate four points at t"""
    r = 1-t
    return (r*r*r*p0 +
            3*r*r*t*p1 +
            3*r*t*t*p2 +
            t*t*t*p3)

def section_length(bezier_point_1, bezier_point_2, precision):
    """Calculate the length between two bezier points"""
    length = 0.0

    prec = precision
    inc = 1/prec #increments

    #subdivide the curve in 'precision' lines and sum its magnitudes
    for i in range(0, prec):
        ti = i*inc
        tf = (i+1)*inc
        a = find_curve_pos(bezier_point_1, bezier_point_2, ti)
        b = find_curve_pos(bezier_point_1, bezier_point_2, tf)
        r = (b-a).magnitude
        length+=r

    return length

def find_curve_pos(bezier_point_1, bezier_point_2, t):
    """Return position along a bezier curve"""
    return interpBez3(bezier_point_1, t, bezier_point_2)

def find_spline_pos(bezier_points, section_lengths, length, t):
    """find a postion along a curve with several segments"""
    i = 0
    section_start_percent = 0
    for sec_length in section_lengths:
        section_end_percent = section_start_percent + (sec_length / length)
        if (section_start_percent <= t <= section_end_percent):
            bezier_point_1 = bezier_points[i]
            bezier_point_2 = bezier_points[i+1]
            percent_along_section = (t - section_start_percent) / (section_end_percent - section_start_percent)
            point_co = find_curve_pos(bezier_point_1, bezier_point_2, percent_along_section)
            return point_co
        section_start_percent = section_end_percent
        i+=1
    return -1

def create_edge_points(spline, number_of_cuts, snap=False, precision=100, samples_between_points=1000, number_of_nudges=10):
    """Create a set of distributed edge point coordinates"""
    edge_points = []

    #curve = obj.data
    bezier_points = spline.bezier_points

    if (spline.use_cyclic_u or spline.use_cyclic_v):
        new_bezier_points = []
        for bezier_point in bezier_points:
            new_bezier_points.append(bezier_point)
        new_bezier_points.append(bezier_points[0])
        bezier_points = new_bezier_points

    #go through all the points and work out their relative magnitudes.
    length = 0.0

    section_lengths = []
    if len(bezier_points) > 1:
        for i in range(0, len(bezier_points) - 1):
            bezier_point_1 = bezier_points[i]
            bezier_point_2 = bezier_points[i+1]
            sec_length = section_length(bezier_point_1, bezier_point_2, precision)
            section_lengths.append(sec_length)
            length += sec_length

    #go through each identified section, and determine which points need to be
    #created in that section.

    curve_increment_percent = 1 / (number_of_cuts + 1)
    curve_point_percent = curve_increment_percent

    i = 0

    section_start_percent = 0
    #create first point
    first_point_co =  bezier_points[0].co
    edge_points.append(first_point_co)

    for sec_length in section_lengths:

        section_end_percent = section_start_percent + (sec_length / length)

        while (section_start_percent <= curve_point_percent <= section_end_percent):
            bezier_point_1 = bezier_points[i]
            bezier_point_2 = bezier_points[i+1]

            percent_along_section = (curve_point_percent - section_start_percent) / (section_end_percent - section_start_percent)

            point_co = find_curve_pos(bezier_point_1, bezier_point_2, percent_along_section)
            edge_points.append(point_co)
            curve_point_percent += curve_increment_percent

        #move on to the next
        section_start_percent = section_end_percent

        i+=1

    last_point_co = bezier_points[len(bezier_points)-1].co
    edge_points.append(last_point_co)

    #self correct - sometimes we may have created one too few/many points because of rounding errors on the upper bounds.
    while len(edge_points) > (number_of_cuts + 2):
        edge_points = edge_points[:-1]
    while len(edge_points) < (number_of_cuts + 2):
        edge_points.append(last_point_co)

    #these edge points are not distributed evenly. We need to iterate over them and move them
    #evenly along the curve. here goes!
    if (number_of_cuts > 0):
        i=0

        #initially set up the curve increments
        increment = 1 / (number_of_cuts * samples_between_points)
        t_values = [None] * len(edge_points)
        for c in range(0, len(t_values)):
            t_values[c] = c * curve_increment_percent

        #nudge the vertices along attempting to make the distances between them even.
        while (i < number_of_nudges):

            left_edge_point = edge_points[0]
            for n in range (1, len(edge_points) - 1):
                current_edge_point = edge_points[n]
                right_edge_point = edge_points[n+1]
                left_length = (left_edge_point - current_edge_point).magnitude
                right_length = (right_edge_point - current_edge_point).magnitude

                t = t_values[n]
                new_point = current_edge_point
                while (left_length < right_length):
                    t += increment
                    if (0 <= t <= 1):
                        new_point = find_spline_pos(bezier_points, section_lengths, length, t)
                        left_length = (left_edge_point - new_point).magnitude
                        right_length = (right_edge_point - new_point).magnitude
                    else:
                        break
                while (right_length < left_length):
                    t -= increment
                    if (0 <= t <= 1):
                        new_point = find_spline_pos(bezier_points, section_lengths, length, t)
                        left_length = (left_edge_point - new_point).magnitude
                        right_length = (right_edge_point - new_point).magnitude
                    else:
                        break

                t_values[n] = t
                edge_points[n] = new_point
                left_edge_point = edge_points[n]

            i+=1

    if snap and len(edge_points) > 2:
        for bezier_point in bezier_points:
            bezier_co = mathutils.Vector(bezier_point.co)
            closest_points = {}
            for i, edge_point in enumerate(edge_points):
                distance = (bezier_co - edge_point).magnitude
                closest_points[distance] = i
            closest_key = min(closest_points.keys())
            closest_edge_point_index = closest_points[closest_key]
            edge_points[closest_edge_point_index] = bezier_co

    return edge_points

def create_surface_1_spline(bm, spline,
                            number_of_cuts_across=10,
                            use_resolution=False,
                            snap_verts=False,
                            precision=100,
                            samples_between_points=1000,
                            number_of_nudges=10
                            ):
    """Create a mesh given 1 spline"""

    result_to_return = {}
    result_to_return['edges'] = []
    result_to_return['verts'] = []

    #increase tge cuts if we are dividing a cyclic spline.
    if use_resolution:
        cuts = spline.resolution_u
    else:
        cuts = number_of_cuts_across

    is_cyclic = (spline.use_cyclic_u or spline.use_cyclic_v)
    if is_cyclic:
        cuts += 1

    edge_loop = create_edge_points(spline, cuts, snap_verts, precision, samples_between_points, number_of_nudges)

    #go through the points and create the requisite vertices and edges.
    point_1 = cornerA = bm.verts.new(edge_loop[0])
    edge_index = 0
    for i in range(0, len(edge_loop) - 1):
        point_2 = cornerB = bm.verts.new(edge_loop[i+1])
        verts = []
        verts.append(point_1)
        verts.append(point_2)
        edge = bm.edges.new(verts)
        edge.index = edge_index
        result_to_return['edges'].append(edge)
        result_to_return['verts'].extend(verts)
        edge_index+=1
        point_1 = point_2

    #merge the last two points if the curve was cyclic.
    if is_cyclic:
        bmesh.ops.pointmerge(bm, verts=[cornerA, cornerB], merge_co=cornerA.co)

    bm.verts.ensure_lookup_table()

    index = 0
    for vert in bm.verts:
        vert.index = index
        index+=1

    result_to_return['edges'] = list(set([e for e in result_to_return['edges'] if e.is_valid]))
    result_to_return['verts'] = list(set([e for e in result_to_return['verts'] if e.is_valid]))

    return result_to_return

def order_loops(highest_spline, spline_loop_map, remaining_unordered_loops, loops):
    connected_loops = spline_loop_map[highest_spline['uuid']]

    if len(connected_loops) > 0:
        # get the first one as we only need one to start re-ordering
        first_highest_loop = connected_loops[0]
        # get the location of the spline in the loop.
        highest_spline_position = first_highest_loop.index(highest_spline)
        # now we have the position, we actually need to reposition this into the first in the list for this case...
        new_loop_deque = deque(first_highest_loop)
        new_loop_deque.rotate((0 - highest_spline_position) * -1)
        new_ordered_loop = list(new_loop_deque)
        connected_loops[0] = new_ordered_loop
        loops[loops.index(first_highest_loop)] = new_ordered_loop
        remaining_unordered_loops.remove(first_highest_loop)

        order_loop(new_ordered_loop, spline_loop_map, remaining_unordered_loops, loops)

def order_loop(new_ordered_loop, spline_loop_map, remaining_unordered_loops, loops):
    # now we have an ordered loop, we need to do this for all the other loops as well...
    # get surrounding loops.
    for spline in new_ordered_loop:
        expected_position = abs(new_ordered_loop.index(spline) - 2)
        expected_position_is_even = (expected_position % 2 == 0)
        connected_loops = spline_loop_map[spline['uuid']]
        for connected_loop in connected_loops:
            if connected_loop in remaining_unordered_loops:
                spline_position = connected_loop.index(spline)
                spline_position_is_even = (spline_position % 2 == 0)

                if expected_position_is_even != spline_position_is_even:
                    # shift the connected loop along by one.
                    new_loop_deque = deque(connected_loop)
                    new_loop_deque.rotate(1)
                    new_ordered_loop2 = list(new_loop_deque)
                    loops[loops.index(connected_loop)] = new_ordered_loop2
                    remaining_unordered_loops.remove(connected_loop)
                    connected_loop = new_ordered_loop2
                else:
                    remaining_unordered_loops.remove(connected_loop)

                # ok, so we have a new ordered a loop...so we need to go around again!
                # recursion point here...
                order_loop(connected_loop, spline_loop_map, remaining_unordered_loops, loops)

def find_loop(current_spline, potential_loop, all_loops, edge_to_spline_cache, direction_check):

    potential_loop.append(current_spline)

    potential_loop_len = len(potential_loop)
    if potential_loop_len < 4:

        # find next potential item and go to the next level of recursion
        last_spline_endpoints = potential_loop[-1]['endpoints']
        for endpoint in last_spline_endpoints:
            connected_splines = edge_to_spline_cache[endpoint]
            for connected_spline in connected_splines:
                if connected_spline['uuid'] != current_spline['uuid']:
                    loop = find_loop(connected_spline, potential_loop.copy(), all_loops, edge_to_spline_cache, direction_check)
                    if loop is not None:

                        potential_loop_ids =  [s['uuid'] for s in loop]

                        already_present = False
                        for existing_loop in all_loops:
                            loop_ids =  [s['uuid'] for s in existing_loop]
                            if len(set(potential_loop_ids).intersection(loop_ids)) == len(potential_loop_ids):
                                already_present = True
                                break
                        if not already_present:
                            all_loops.append(loop)

    elif potential_loop_len == 4:
        #is this chain valid enough to proceed?

        # check for dupes
        potential_loop_uuids = [s['uuid'] for s in potential_loop]
        if (len(potential_loop_uuids)!=len(set(potential_loop_uuids))):
            # invalid loop.
            return None

        # check endpoints are unique enough.
        all_endpoints = []
        for s in potential_loop:
            if len(s['spline'].bezier_points) < 2:
                return None
            endpoints = s['endpoints']
            all_endpoints.extend(endpoints)

        if ( len(set(all_endpoints)) != 4 ):
            return None

        if direction_check:
            if not ((potential_loop[0]['endpoints'][-1] - potential_loop[1]['endpoints'][0]).magnitude == 0 and \
                (potential_loop[1]['endpoints'][-1] - potential_loop[2]['endpoints'][0]).magnitude == 0 and \
                (potential_loop[2]['endpoints'][-1] - potential_loop[3]['endpoints'][0]).magnitude == 0 and \
                (potential_loop[3]['endpoints'][-1] - potential_loop[0]['endpoints'][0]).magnitude == 0):
                return None

        # are the first and the last splnes connected?
        first_spline = potential_loop[0]
        last_spline = potential_loop[3]

        connected = False
        first_spline_endpoints = first_spline['endpoints']
        for first_spline_endpoint in first_spline_endpoints:
            last_spline_endpoints = last_spline['endpoints']
            for last_spline_endpoint in last_spline_endpoints:
                if (first_spline_endpoint - last_spline_endpoint).magnitude == 0:
                    connected = True
                    break
            if connected:
                break

        if connected:
            return potential_loop

    # if we got here, we got nowhere...
    return None


def create_surface_4_splines(bm, splines,
                                use_resolution=False,
                                number_of_cuts_across=10,
                                number_of_cuts_down=10,
                                snap_verts=False,
                                precision=100,
                                samples_between_points=1000,
                                number_of_nudges=10,
                                edge_point_cache={}):
    """Create a quad surface given a set of 4 curves"""

    sorted_splines = splines

    if use_resolution:
        resolution_first_edge = sorted_splines[0]['spline'].resolution_u
        resolution_adj_loop1 = sorted_splines[1]['spline'].resolution_u
        resolution_adj_loop2 = sorted_splines[3]['spline'].resolution_u
        resolution_op_edge = sorted_splines[2]['spline'].resolution_u
    else:
        resolution_first_edge = number_of_cuts_across
        resolution_adj_loop1 = number_of_cuts_down
        resolution_adj_loop2 = number_of_cuts_down
        resolution_op_edge = number_of_cuts_across


    #now, assign the loops - the first loop, the two adjacent loops, and the opposite loop.
    if sorted_splines[0]['uuid'] in edge_point_cache:
        first_edge_loop = edge_point_cache[sorted_splines[0]['uuid']]
    else:
        first_edge_loop = create_edge_points(sorted_splines[0]['spline'], resolution_first_edge, snap_verts, precision, samples_between_points, number_of_nudges)

    if sorted_splines[1]['uuid'] in edge_point_cache:
        adj_loop1 = edge_point_cache[sorted_splines[1]['uuid']]
    else:
        adj_loop1 = create_edge_points(sorted_splines[1]['spline'], resolution_adj_loop1, snap_verts, precision, samples_between_points, number_of_nudges)

    if sorted_splines[3]['uuid'] in edge_point_cache:
        adj_loop2 = edge_point_cache[sorted_splines[3]['uuid']]
    else:
        adj_loop2 = create_edge_points(sorted_splines[3]['spline'], resolution_adj_loop2, snap_verts, precision, samples_between_points, number_of_nudges)

    if sorted_splines[2]['uuid'] in edge_point_cache:
        op_edge_loop = edge_point_cache[sorted_splines[2]['uuid']]
    else:
        op_edge_loop = create_edge_points(sorted_splines[2]['spline'], resolution_op_edge, snap_verts, precision, samples_between_points, number_of_nudges)


    edge_point_cache[sorted_splines[0]['uuid']] = first_edge_loop
    edge_point_cache[sorted_splines[1]['uuid']] = adj_loop1
    edge_point_cache[sorted_splines[3]['uuid']] = adj_loop2
    edge_point_cache[sorted_splines[2]['uuid']] = op_edge_loop


    #first pair up all 4 of the end points on the loops.
    main_loops = [first_edge_loop, op_edge_loop]
    adj_loops = [adj_loop1, adj_loop2]
    for main_loop in main_loops:
        end1 = main_loop[0]
        end2 = main_loop[-1]

        points = []
        for i in range(0, len(adj_loops)):
            adj_loop = adj_loops[i]
            end3 = adj_loop[0]
            end4 = adj_loop[-1]
            points.append({'loop_id': i, 'point_id': 0, 'point': end3})
            points.append({'loop_id': i, 'point_id': -1, 'point': end4})

        closest_point_to_end1 = sorted(points, key=lambda point: (end1 - point['point']).magnitude )[0]
        closest_point_to_end2 = sorted(points, key=lambda point: (end2 - point['point']).magnitude )[0]

        average_end1_point = (end1 + closest_point_to_end1['point']) / 2
        average_end2_point = (end2 + closest_point_to_end2['point']) / 2

        main_loop[0] = average_end1_point
        main_loop[-1] = average_end2_point
        adj_loops[closest_point_to_end1['loop_id']][closest_point_to_end1['point_id']] = average_end1_point
        adj_loops[closest_point_to_end2['loop_id']][closest_point_to_end2['point_id']] = average_end2_point

    #now, actually create the edge loops and do a grid fill.
    fill_edge_prop = bm.edges.layers.int.new('fill_edge_prop')

    #go through the points and create the requisite vertices and edges.
    point_1 = cornerA = bm.verts.new(first_edge_loop[0])
    for i in range(0, len(first_edge_loop) - 1):
        point_2 = cornerB = bm.verts.new(first_edge_loop[i+1])
        verts = []
        verts.append(point_1)
        verts.append(point_2)
        edge = bm.edges.new(verts)
        edge[fill_edge_prop] = 1
        point_1 = point_2

    point_1 = cornerC = bm.verts.new(adj_loop1[0])
    for i in range(0, len(adj_loop1) - 1):
        point_2 = cornerD = bm.verts.new(adj_loop1[i+1])
        verts = []
        verts.append(point_1)
        verts.append(point_2)
        bm.edges.new(verts)
        point_1 = point_2

    point_1 = cornerE = bm.verts.new(op_edge_loop[0])
    for i in range(0, len(op_edge_loop) - 1):
        point_2 = cornerF = bm.verts.new(op_edge_loop[i+1])
        verts = []
        verts.append(point_1)
        verts.append(point_2)
        edge = bm.edges.new(verts)
        edge[fill_edge_prop] = 1
        point_1 = point_2

    point_1 = cornerG = bm.verts.new(adj_loop2[0])
    for i in range(0, len(adj_loop2) - 1):
        point_2 = cornerH = bm.verts.new(adj_loop2[i+1])
        verts = []
        verts.append(point_1)
        verts.append(point_2)
        bm.edges.new(verts)
        point_1 = point_2

    #knit edges together.
    verts = [cornerA, cornerB, cornerC, cornerD, \
                cornerE, cornerF, cornerG, cornerH]

    #initialise some indexes to tell the vertices apart.
    index = 0
    for vert in verts:
        vert.index = index
        index += 1

    #merge co-located vertices together.
    bm.verts.ensure_lookup_table()
    for vert in verts:
        for vert2 in verts:
            if (vert.is_valid and vert2.is_valid and vert.index != vert2.index):
                if ((vert.co - vert2.co).magnitude == 0):
                    bmesh.ops.pointmerge(bm, verts=[vert, vert2], merge_co=vert.co)

    edges_to_fill = []
    for edge in bm.edges:
        if edge[fill_edge_prop]:
            edges_to_fill.append(edge)

    try:
        bmesh.ops.grid_fill(bm, edges=edges_to_fill)
    except Exception as e:
        pass

    bm.edges.layers.int.remove(fill_edge_prop)

def has_changed(self, args, curves, new_curves, old_curves):
    """Determines whether a change has occured in the curves."""

    # collate all bezier points from the new curves
    new_curves.clear()
    for new_curve in curves:
        curve = new_curves.add()
        curve.name = new_curve.name
        curve.location = new_curve.location
        curve.no_splines = len(new_curve.data.splines)
        for new_spline in new_curve.data.splines:
            for new_bezier_point in new_spline.bezier_points:
                curve_point = curve.bezier_points.add()
                curve_point.co = new_curve.matrix_world @ new_bezier_point.co.copy()
                curve_point.lh_co = new_curve.matrix_world @ new_bezier_point.handle_left.copy()
                curve_point.rh_co =new_curve.matrix_world @  new_bezier_point.handle_right.copy()
                curve_point.resolution = new_spline.resolution_u

    if len(old_curves) != len(new_curves):
        old_curves.clear()
        for new_curve in new_curves:
            old_curve = old_curves.add()
            old_curve.name = new_curve.name
            old_curve.location = new_curve.location
            old_curve.no_splines = new_curve.no_splines
            for curve_point in new_curve.bezier_points:
                old_bezier_point = old_curve.bezier_points.add()
                old_bezier_point.co = curve_point.co
                old_bezier_point.lh_co = curve_point.lh_co
                old_bezier_point.rh_co = curve_point.rh_co
                old_bezier_point.resolution = curve_point.resolution
        return True

    found_count = 0
    index = 0

    for new_curve in new_curves:
        try:
            old_curve = None
            for old_curve in old_curves:
                if old_curve is not None and \
                    old_curve.name == new_curve.name and \
                     compare_location(old_curve.location,new_curve.location) and \
                     old_curve.no_splines == new_curve.no_splines and \
                     compare_vectors(args, old_curve.bezier_points, new_curve.bezier_points):
                    found_count+=1
        except IndexError:
            pass
        index+=1

    if found_count != len(old_curves):

        old_curves.clear()
        for new_curve in new_curves:
            old_curve = old_curves.add()
            old_curve.name = new_curve.name
            old_curve.location = new_curve.location
            old_curve.no_splines = new_curve.no_splines
            for curve_point in new_curve.bezier_points:
                old_bezier_point = old_curve.bezier_points.add()
                old_bezier_point.co = curve_point.co
                old_bezier_point.lh_co = curve_point.lh_co
                old_bezier_point.rh_co = curve_point.rh_co
                old_bezier_point.resolution = curve_point.resolution
        return True

    if args.c2m_is_dirty:
        args.c2m_is_dirty = False
        return True

    return False

def compare_location(loc1, loc2):
    return loc1[0] == loc2[0] and \
            loc1[1] == loc2[1] and \
            loc1[2] == loc2[2]

def compare_vectors(args, old_bezier_points, new_bezier_points):
    if len(old_bezier_points) != len(new_bezier_points):
        return False

    found_count = 0
    index = 0

    for new_bezier_point in new_bezier_points:
        try:
            old_bezier_point = old_bezier_points[index]
            if compare_vector(old_bezier_point['co'], new_bezier_point['co']) and \
                compare_vector(old_bezier_point['lh_co'], new_bezier_point['lh_co']) and \
                compare_vector(old_bezier_point['rh_co'], new_bezier_point['rh_co']) and \
                compare_resolution(args.c2m_use_resolution, old_bezier_point['resolution'], new_bezier_point['resolution']):
                found_count+=1
        except IndexError:
            pass
        index+=1
    return found_count == len(old_bezier_points)

def compare_vector(vec1,vec2):
    """Custom function to compare two vectors by coordinates."""
    return vec1[0] == vec2[0] and \
            vec1[1] == vec2[1] and \
            vec1[2] == vec2[2]

def compare_resolution(use_resolution, res1, res2):
    if not use_resolution:
        return True
    else:
        return res1 == res2

def region_exists(r):
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            for region in area.regions:
                if region == r: return True
    return False

def get_curves(args):
    curves_to_return = []
    collection_name = args.c2m_collection
    if collection_name in bpy.data.collections:
        for object in bpy.data.collections[collection_name].objects:
            if object.type == 'CURVE':
                valid = True
                spline_count = 0
                for spline in object.data.splines:
                    if spline.type != 'BEZIER':
                        valid=False
                        break
                    else:
                        spline_count+=1
                valid = valid and spline_count > 0
                if valid:
                    curves_to_return.append(object)
    return curves_to_return

# Standard Operator
def get_transformed_splines(curves, round_to_decimals=3):
    
    test_splines = []
    spline_pos_map = {}
    for curve in curves:

        # before we go anywhere, let's identify intersection points...
        for spline in curve.data.splines:
            for bezier_point in spline.bezier_points:
                co = curve.matrix_world @ bezier_point.co
                rounded = np.around(co, round_to_decimals)
                rounded_vec = Vector(rounded)
                rounded_vec.freeze()
                if rounded_vec not in spline_pos_map:
                    spline_pos_map[rounded_vec] = []
                spline_pos_map[rounded_vec].append(spline)

    for curve in curves:
        for spline in curve.data.splines:
            if (len(spline.bezier_points) > 1):
                new_spline = props.C2M_Spline(spline.type, spline.resolution_u, spline.use_cyclic_u, spline.use_cyclic_v)
                test_splines.append(new_spline)
                
                # add the first point.
                bezier_point = spline.bezier_points[0]
                process_curve_point(bezier_point, new_spline, curve.matrix_world)

                # go through the middle parts, if we have a middle part...checking for intersections along the way.
                if (len(spline.bezier_points) > 2):
                    for bezier_point in spline.bezier_points[1:-1]:
                        
                        new_bezier_point, co = process_curve_point(bezier_point, new_spline, curve.matrix_world)
                        
                        rounded = np.around(co, round_to_decimals)
                        rounded_vec = Vector(rounded)
                        rounded_vec.freeze()

                        if rounded_vec in spline_pos_map and \
                            len(spline_pos_map[rounded_vec])  > 1 and \
                                len(new_spline.bezier_points) > 1:
                            # Finish this one up and create a new one.
                            new_spline = props.C2M_Spline(spline.type, spline.resolution_u, spline.use_cyclic_u, spline.use_cyclic_v)
                            test_splines.append(new_spline)
                            new_spline.bezier_points.append(new_bezier_point)

                # add the last point.
                bezier_point = spline.bezier_points[-1]
                process_curve_point(bezier_point, new_spline, curve.matrix_world)

    return test_splines

def process_curve_point(bezier_point, new_spline, matrix_world):
    co = matrix_world @ bezier_point.co
    handle_left = matrix_world @ bezier_point.handle_left
    handle_right = matrix_world @ bezier_point.handle_right
    new_bezier_point = props.C2M_BezierPoint(co,handle_left,handle_right)
    new_spline.bezier_points.append(new_bezier_point)
    return new_bezier_point, co

def lerp_f(v, d):
    return v[0] * (1 - d) + v[1] * d

def generate_cross_sections(bm_segment, args, edge_loop,
                                    spline_a_key,
                                    spline_a,
                                    spline_a_rot,
                                    spline_b_key,
                                    spline_b,
                                    spline_b_rot,
                                    spline_a_origin_dist,
                                    spline_b_origin_dist,
                                    twist_amounts):

    for spline in spline_a:
        result = create_surface_1_spline(bm_segment,
                                spline,
                                number_of_cuts_across=args.c2m_number_of_cuts_across,
                                use_resolution=args.c2m_use_resolution,
                                snap_verts=args.c2m_snap_verts,
                                precision=args.c2m_precision,
                                samples_between_points=args.c2m_samples_between_points, 
                                number_of_nudges=args.c2m_number_of_nudges)
                                
        

    for spline in spline_b:
        result = create_surface_1_spline(bm_segment,
                                spline,
                                number_of_cuts_across=args.c2m_number_of_cuts_across,
                                use_resolution=args.c2m_use_resolution,
                                snap_verts=args.c2m_snap_verts,
                                precision=args.c2m_precision,
                                samples_between_points=args.c2m_samples_between_points,
                                number_of_nudges=args.c2m_number_of_nudges)


    result = bmesh.ops.bridge_loops(bm_segment, edges=bm_segment.edges)

    result = bmesh.ops.subdivide_edges(bm_segment, edges=result['edges'], cuts=   args.c2m_number_of_cuts_down)

    # go through all the vertices and separate them into layers with a layer index corresponding to the nearest point on the straight curve.
    layers = {}

    for v in bm_segment.verts:
        co = v.co
        z_index = co.z
        approx_index = round( z_index )#* (len(edge_loop) -1 ) )
        if approx_index not in layers:
            layers[approx_index] = []
        layers[approx_index].append(v)

    i = 0
    for key in layers:
        index = key
        layer_verts = layers[key]

        if len(layer_verts):

            z_center = Vector((0,0,layer_verts[0].co.z))
            
            edge_loop_position = edge_loop[index]
            
            lerp_fac = (layer_verts[0].co.z - spline_a_key ) / (spline_b_key - spline_a_key)

            lerped_distance = spline_a_origin_dist.lerp(spline_b_origin_dist, lerp_fac)
            
            lerped_rot = spline_a_rot.to_matrix().lerp(spline_b_rot.to_matrix(), lerp_fac)

            twist = twist_amounts[index]
            mat_twist = mathutils.Matrix.Rotation(radians(twist), 4, 'Z')
            
            bmesh.ops.rotate(bm_segment, cent = z_center, matrix=mat_twist, verts = layer_verts)
            bmesh.ops.rotate(bm_segment, cent = z_center, matrix=lerped_rot, verts = layer_verts)
            bmesh.ops.translate(bm_segment, vec = (edge_loop_position - z_center) + lerped_distance, verts = layer_verts)

        i+=1


def create_spline_cross_section_info(cross_section_curve, edge_loop, args):



        # find spline mid section

        origin = cross_section_curve.location

        # find closest point along sweep spline
        def dist_to_curve_point(co):
            return (origin - co).magnitude
        
        closest_point = min(edge_loop, key=dist_to_curve_point)

        origin_difference = (origin - closest_point)

        edge_loop_index = edge_loop.index(closest_point)

        # temporarily alter curve for calculation by resetting it's orientation to world coords.
        euler = cross_section_curve.rotation_euler.copy()
        old_matrix_world = cross_section_curve.matrix_world.copy()
        cross_section_curve_copy = cross_section_curve.copy()
        try:
            
            # # find the smallest acute angle and assign the relevant euler. TODO redundant code but might come in handy later...
            # cross_section_up_vector = Vector((0,0,1)) 
            # cross_section_down_vector = Vector((0,0,-1)) 
            # cross_section_up_vector.rotate(euler)
            # cross_section_down_vector.rotate(euler)
            # offset = 1
            # for offset in range(1, len(edge_loop) + 1):
            #     edge_loop_vector = (edge_loop[    (edge_loop_index + offset) % len(edge_loop)      ] - edge_loop[edge_loop_index] ).normalized()
            #     if edge_loop_vector.magnitude > 0:
            #         break
            # angle_up = cross_section_up_vector.angle(edge_loop_vector, 0)
            # angle_down = cross_section_down_vector.angle(edge_loop_vector, 180)

            # if angle_up > angle_down:
            #     euler.rotate_axis('X', radians(180))
            #     euler.rotate_axis('Z', radians(180))


            cross_section_curve_copy.matrix_world = Matrix()
            lerp = edge_loop_index 
            cross_section_curve_copy.matrix_world.translation.z = lerp

            orig_loc, orig_rot, orig_scale = old_matrix_world.decompose()


            orig_scale_mat = Matrix.Scale(orig_scale[0],4,(sqrt(2),0,0)) * Matrix.Scale(orig_scale[1],4,(0,1,0)) * Matrix.Scale(orig_scale[2],4,(0,0,sqrt(2)))

            cross_section_curve_copy.matrix_world = cross_section_curve_copy.matrix_world @ orig_scale_mat

            cross_section_splines = get_transformed_splines([cross_section_curve_copy], args.c2m_round_to_decimals)

            return cross_section_splines, edge_loop_index, euler, origin_difference
        finally:
            bpy.data.objects.remove(cross_section_curve_copy)


