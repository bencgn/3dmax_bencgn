def hotkey_entry_item(km, kmi_name, kmi_value, properties):
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if properties == 'name':
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item
            elif properties == 'tab':
                if km.keymap_items[i].properties.tab == kmi_value:
                    return km_item
            elif properties == 'none':
                return km_item
    return None


def hotkey_entry_items(km, kmi_names):
    km_items = []
    kmi_names_to_remove = kmi_names.copy()
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] in kmi_names:
            km_items.append(km_item)
            kmi_names_to_remove.remove(km.keymap_items.keys()[i])
            if len(kmi_names_to_remove) == 0:
                break
    return km_items

keymap_operators = [
                 "curvestomesh.commit_operator",
                 "curvestomesh.preview_operator",
                 "curvestomesh.increase_subd_across_operator",
                 "curvestomesh.decrease_subd_across_operator",
                 "curvestomesh.increase_subd_down_operator",
                 "curvestomesh.decrease_subd_down_operator",
                 "curvestomesh.force_refresh_operator",
                 "curvestomesh.cancel_operator"]
