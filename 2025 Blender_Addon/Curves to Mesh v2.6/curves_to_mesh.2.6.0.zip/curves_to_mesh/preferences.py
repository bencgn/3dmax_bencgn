import bpy
from bpy.types import AddonPreferences
from bpy.props import FloatVectorProperty
import rna_keymap_ui
from . import keymaps
from . import operators
import os

def addon_name():
    return os.path.basename(os.path.dirname(os.path.realpath(__file__)))

class CurvesToMeshAddonPreferences(AddonPreferences):
    """Custom preferences and associated UI for add on properties."""
    # this must match the addon name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = addon_name()

    vertex_color : FloatVectorProperty(name="Preview Vertex Color",
                                        subtype='COLOR',
                                        size=4,
                                        default=[0, 1, 0, 0.5])

    edge_color : FloatVectorProperty(name="Preview Edge Color",
                                        subtype='COLOR',
                                        size=4,
                                        default=[0.5, .71, 1, 0.4])


    face_color : FloatVectorProperty(name="Preview Face Color",
                                        subtype='COLOR',
                                        size=4,
                                        default=[0.4, .5, 0.9, 0.3])

    border_color : FloatVectorProperty(name="Border Color",
                                        subtype='COLOR',
                                        size=4,
                                        default=[1, 0.266, 0, 1])

    def draw(self, context):
        layout = self.layout
        # layout.label(text="Colors:")
        col = layout.column()
        col.alignment = 'CENTER'
        row = col.row()
        row.prop(self, "vertex_color")
        row = col.row()
        row.prop(self, "edge_color")
        row = col.row()
        row.prop(self, "face_color")
        row = col.row()
        row.prop(self, "border_color")

        col = col.column()
        col.separator()
        col.label(text='Keyboard shortcuts:')
        col = col.column()

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.user

        km = kc.keymaps['3D View']
        kmis = keymaps.hotkey_entry_items(km, keymaps.keymap_operators)

        if len(kmis) != len(keymaps.keymap_operators):
            col.alert = True
            col = col.column()
            row = col.row()
            row.alignment = 'CENTER'
            row.label(text="Not all hotkey entries found")
            col = col.column()
            row = col.row()
            row.alignment = 'CENTER'
            row.label(text="restore hotkeys from Keymap tab")

        for kmi in kmis:
            col.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
