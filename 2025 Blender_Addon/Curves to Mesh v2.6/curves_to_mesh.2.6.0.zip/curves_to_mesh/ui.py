"""
    Contains UI reference function for the addon.
"""
import bpy
import blf
import math
from . import utils
from . import classes
from . import curve_uis
from . import props

import gpu
from gpu_extras.batch import batch_for_shader

def draw_callback_3d(self, context):
    """Draw in 3D a representaion of the mesh"""

    try:
        if not (classes.CurvesToSurface.running_curves_to_meshes.get(self._region) is self): return
        if not hasattr(self, 'verts'): return

        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences

        # curve = context.scene.objects.get(self.curve_name)
        # curve_matrix_world = curve.matrix_world

        gpu.state.blend_set("ALPHA")



        # coords = [curve_matrix_world @ self.verts[i] for i in self.verts.keys()]
        coords = [self.verts[i] for i in self.verts.keys()]

        # Draw Edges
        indices = self.edges.values()
        shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINES', {"pos": coords}, indices= indices)
        shader.bind()
        shader.uniform_float("color", addon_prefs.edge_color)
        batch.draw(shader)

        # Draw faces
        shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        indices = []
        for face_index in self.faces.keys():
            face_vert_indexes = self.faces[face_index]['vert_indexes']
            iv0 = face_vert_indexes[0]
            for iv1,iv2 in zip(face_vert_indexes[1:-1], face_vert_indexes[2:]):
                indice = (iv0, iv1, iv2)
                indices.append(indice)
        batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices= indices)
        shader.bind()
        shader.uniform_float("color", addon_prefs.face_color)
        batch.draw(shader)

        # Draw vertices
        gpu.state.point_size_set(5)
        
        shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", addon_prefs.vertex_color)
        batch.draw(shader)

        gpu.state.blend_set("NONE")

    except ReferenceError:
        pass

class OBJECT_PT_curves_to_mesh(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh"
    bl_label = "Curves To Mesh"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'

    def draw(self, context):
        draw_options(self, context)


class OBJECT_PT_curves_to_mesh_adv(bpy.types.Panel):
    bl_idname = "OBJECT_PT_curves_to_mesh_advanced"
    bl_label = "Advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curves To Mesh'
    bl_parent_id = 'OBJECT_PT_curves_to_mesh'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_options_adv(self, context)



def draw_options(self, context):
    layout = self.layout
    col = layout.column()
    col.label(text="Preview")
    row = col.row()
    row.operator("curvestomesh.preview_operator", text="Enable")
    row.operator("curvestomesh.cancel_operator", text="Disable")

    col = layout.column()
    col.separator()
    col.label(text="Collection to operate on")
    col.prop_search(data = context.scene,
                            property = 'c2m_collection',
                            search_data = bpy.data,
                            search_property = 'collections',
                            text="")

    col = layout.column()
    col.separator()
    col.label(text="Conversion Method")
    c2m_method_text = ""
    for creation_method_item in props.creation_method_items:
        if creation_method_item[0] == context.scene.c2m_curve_method:
            c2m_method_text = creation_method_item[1]
            break
    col.prop_menu_enum(context.scene, "c2m_curve_method", text=c2m_method_text)

    col = layout.column()
    custom_draw_func = getattr(curve_uis, context.scene.c2m_curve_method, None)
    if custom_draw_func is not None:
        custom_draw_func(col, context)


    col = layout.column()
    col.separator()
    col.label(text="Mesh Settings")
    col = col.box()
    col.prop(context.scene, "c2m_snap_verts", text="Snap to control point")
    col.prop(context.scene, "c2m_mirror_x")
    col.prop(context.scene, "c2m_mirror_y")
    col.prop(context.scene, "c2m_mirror_z")
    col.prop(context.scene, "c2m_flip_normals")
    col.prop(context.scene, "c2m_shade_smooth")
    col.prop(context.scene, "c2m_show_all_edges")
    col.prop(context.scene, "c2m_show_wire")

    col = layout.column()
    col.separator()
    col.operator("curvestomesh.commit_operator", text="Create Mesh")


def draw_options_adv(self, context):
    layout = self.layout
    col = layout.column()

    col.separator()
    col.label(text="Vertex Settings")
    col.prop(context.scene, "c2m_number_of_nudges", text="Nudges")
    col.prop(context.scene, "c2m_samples_between_points", text="Samples")
    col.prop(context.scene, "c2m_precision", text="Definition")
    col.separator()
    col.prop(context.scene, "c2m_remove_double_distance", text="Remove Double Precision")

    col = layout.column()
    col.separator()
    col.label(text="Curve Connections")
    col.prop(context.scene, "c2m_round_to_decimals")