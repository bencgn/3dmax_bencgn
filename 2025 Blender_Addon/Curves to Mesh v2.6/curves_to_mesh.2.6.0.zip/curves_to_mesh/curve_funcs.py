import bpy
import uuid
from mathutils import Vector
from . import utils
import bmesh
from . import props
import numpy as np
from collections import deque
from math import degrees, radians

import re

def sorted_nicely( l ): 
    """ Sort the given iterable in the way that humans expect.""" 
    convert = lambda text: int(text) if text.isdigit() else text
    alphanum_key = lambda curve: [ convert(c) for c in re.split('([0-9]+)', curve.name) ] 
    return sorted(l, key = alphanum_key)

def curve_profiles_to_mesh(self, bm, args, curves):
    """Create a quad surface given multiple curves ordered like cross sections"""
    splines = utils.get_transformed_splines(sorted_nicely(curves), args.c2m_round_to_decimals)

    if len(splines) == 1:
        utils.create_surface_1_spline(bm,splines[0],
                            number_of_cuts_across=args.c2m_number_of_cuts_across,
                            use_resolution=args.c2m_use_resolution,
                            snap_verts=args.c2m_snap_verts,
                            precision=args.c2m_precision,
                            samples_between_points=args.c2m_samples_between_points,
                            number_of_nudges=args.c2m_number_of_nudges)
        return


    if args.c2m_bridge_order == 'PROXIMITY':

        for spline in splines:
            utils.create_surface_1_spline(bm,spline,
                                number_of_cuts_across=args.c2m_number_of_cuts_across,
                                use_resolution=args.c2m_use_resolution,
                                snap_verts=args.c2m_snap_verts,
                                precision=args.c2m_precision,
                                samples_between_points=args.c2m_samples_between_points,
                                number_of_nudges=args.c2m_number_of_nudges)

        result = bmesh.ops.bridge_loops(bm, edges=bm.edges, twist_offset=args.c2m_twist)

        bmesh.ops.subdivide_edges(bm, edges=result['edges'], cuts=args.c2m_number_of_cuts_down)


    elif args.c2m_bridge_order == 'ORDER':

        edge_loops = []
        edge_loops = []
        for i in range(0, len(splines)):

            spline = splines[i]

            for edge in bm.edges:
                edge.tag = True

            utils.create_surface_1_spline(bm,spline,
                                number_of_cuts_across=args.c2m_number_of_cuts_across,
                                use_resolution=args.c2m_use_resolution,
                                snap_verts=args.c2m_snap_verts,
                                precision=args.c2m_precision,
                                samples_between_points=args.c2m_samples_between_points,
                                number_of_nudges=args.c2m_number_of_nudges)

            edge_loops.append([e for e in bm.edges if not e.tag])

        if args.c2m_bridge_order_reversed:
            edge_loops.reverse()
        
        for i in range(0, len(edge_loops) - 1):

            edge_loopA = edge_loops[i]
            edge_loopB = edge_loops[i+1]

            all_edges = []
            all_edges.extend(edge_loopA)
            all_edges.extend(edge_loopB)

            result = bmesh.ops.bridge_loops(bm, edges=all_edges, twist_offset=args.c2m_twist)
            
            bmesh.ops.subdivide_edges(bm, edges=result['edges'], cuts=args.c2m_number_of_cuts_down)


def curve_sweep_to_mesh(self, bm, args, curves):
    """Create a sweep based on a guiding path and path cross sections"""

    sweep_curve = args.c2m_sweep_curve

    # for the sweep curve, convert this to a bmesh of edges and order the vertices....
    if sweep_curve is not None and hasattr(sweep_curve, 'data'):

        # get the remaining cross sections from the supplied curves
        cross_section_curves = []
        cross_section_converted_splines = []
        for curve in curves:
            if curve.name != sweep_curve.name:
                cross_section_curves.append(curve)

        if len(cross_section_curves):

            bm_sweep = bmesh.new()

            sweep_splines = utils.get_transformed_splines([sweep_curve], args.c2m_round_to_decimals)

            for sweep_spline in sweep_splines:
                # for each complete segment, assign an order index to each vertex position.
                is_cyclic = (sweep_spline.use_cyclic_u or sweep_spline.use_cyclic_v)

                edge_loop = utils.create_edge_points(sweep_spline,
                                                number_of_cuts=args.c2m_sweep_curve_subd,
                                                            snap=args.c2m_snap_verts,
                                                            precision=args.c2m_precision,
                                                            samples_between_points=args.c2m_samples_between_points,
                                                            number_of_nudges=args.c2m_number_of_nudges)

                twist_amounts = []
                # if it is cyclic, we only want the twist increments to go up to but not including the end amount.
                if is_cyclic:
                    twist_inc = args.c2m_twist / len(edge_loop)
                else:
                    twist_inc = args.c2m_twist / (len(edge_loop) - 1) 

                for i in range(0, len(edge_loop)):
                    twist = i * twist_inc
                    twist_amounts.append(twist)



                # order splines based on closest point to cross section
                cross_section_map = {}
                cross_section_rot_map = {}
                cross_section_dist_map = {}
                cross_section_curve_map = {}

                for cross_section_curve in cross_section_curves:

                    cross_section_splines, edge_loop_index, cross_section_curve_euler, origin_difference = utils.create_spline_cross_section_info(cross_section_curve, edge_loop, args)

                    
                    cross_section_map[edge_loop_index] = cross_section_splines
                    cross_section_rot_map[edge_loop_index] = cross_section_curve_euler
                    cross_section_dist_map[edge_loop_index] = origin_difference
                    cross_section_curve_map[edge_loop_index] = cross_section_curve


                ordered_cross_section_splines = []
                ordered_cross_section_curves = []
                for key in sorted(cross_section_map):
                    ordered_cross_section_splines.append((key, cross_section_map[key]))
                    ordered_cross_section_curves.append(cross_section_curve_map[key])

                for i in range(len(ordered_cross_section_splines[:-1])):
                    
                    # we now have a set of ordered points.  For each cross section, determine its nearest point.
                    spline_a_key = ordered_cross_section_splines[i][0]
                    spline_a = ordered_cross_section_splines[i][1]

                    spline_a_rot = cross_section_rot_map[spline_a_key]

                    spline_b_key = ordered_cross_section_splines[i+1][0]
                    spline_b = ordered_cross_section_splines[i+1][1]

                    spline_b_rot = cross_section_rot_map[spline_b_key]

                    spline_a_origin_dist = cross_section_dist_map[spline_a_key]
                    spline_b_origin_dist = cross_section_dist_map[spline_b_key]


                    bm_segment = bmesh.new()

                    utils.generate_cross_sections(bm_segment,
                                        args,
                                        edge_loop,
                                        spline_a_key,
                                        spline_a,
                                        spline_a_rot,
                                        spline_b_key,
                                        spline_b,
                                        spline_b_rot,
                                        spline_a_origin_dist,
                                        spline_b_origin_dist,
                                        twist_amounts)


                    me = bpy.data.meshes.new("joined bmeshes")
                    bm_segment.to_mesh(me)
                    bm_segment.free()
                    bm_sweep.from_mesh(me)
                    bpy.data.meshes.remove(me)

                if is_cyclic:

                    # add the last segment by shifting the edge loop to the remaining part, and selecting the last and first curves.
                    spline_a_key = ordered_cross_section_splines[0][0]
                    spline_b_key = ordered_cross_section_splines[-1][0]
                    last_twist = twist_amounts[spline_a_key]
                    
                    # shift the edge loop backwards so the last curve will be positioned at the start of the loop.
                    edge_loop = deque(edge_loop)
                    rotate_offset = -(spline_b_key)
                    edge_loop.rotate(rotate_offset)
                    twist_amounts = deque(twist_amounts)
                    twist_amounts.rotate(rotate_offset)

                    #Select the last curve
                    cross_section_curve = ordered_cross_section_curves[-1]
                    cross_section_splines, edge_loop_index, cross_section_curve_euler, origin_difference = utils.create_spline_cross_section_info(cross_section_curve, edge_loop, args)
                    spline_a_key = edge_loop_index                    
                    spline_a = cross_section_splines
                    spline_a_rot = cross_section_curve_euler
                    spline_a_origin_dist = origin_difference

                    #Select the first curve
                    cross_section_curve = ordered_cross_section_curves[0]
                    cross_section_splines, edge_loop_index, cross_section_curve_euler, origin_difference = utils.create_spline_cross_section_info(cross_section_curve, edge_loop, args)
                    spline_b_key = edge_loop_index                    
                    spline_b = cross_section_splines
                    spline_b_rot = cross_section_curve_euler
                    spline_b_origin_dist = origin_difference

                    bm_segment = bmesh.new()

                    # set the last twist to be the end twist amount in cyclic cases.
                    twist_amounts[spline_b_key] = last_twist

                    utils.generate_cross_sections(bm_segment,
                                        args,
                                        edge_loop,
                                        spline_a_key,
                                        spline_a,
                                        spline_a_rot,
                                        spline_b_key,
                                        spline_b,
                                        spline_b_rot,
                                        spline_a_origin_dist,
                                        spline_b_origin_dist,
                                        twist_amounts)


                    me = bpy.data.meshes.new("joined bmeshes")
                    bm_segment.to_mesh(me)
                    bm_segment.free()
                    bm_sweep.from_mesh(me)
                    bpy.data.meshes.remove(me)


                me = bpy.data.meshes.new("sweep mesh")
                bm_sweep.to_mesh(me)
                bm.from_mesh(me)
                bm_sweep.free()
                bpy.data.meshes.remove(me)        

    # sew up the patches by removing the patches and then make sure the normals are uniform.
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=args.c2m_remove_double_distance)#0.0001)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)



def curve_surface_to_mesh(self, bm, args, curves):
    curve_surfaces_to_mesh(bm, curves,
                                use_resolution=args.c2m_use_resolution,
                                number_of_cuts_across=args.c2m_number_of_cuts_across,
                                number_of_cuts_down=args.c2m_number_of_cuts_down,
                                snap_verts=args.c2m_snap_verts,
                                precision=args.c2m_precision,
                                samples_between_points=args.c2m_samples_between_points,
                                number_of_nudges=args.c2m_number_of_nudges,
                                round_to_decimals=args.c2m_round_to_decimals,
                                direction_check=args.c2m_direction_check,
                                remove_double_distance=args.c2m_remove_double_distance)




def curve_splines_to_mesh(bm, splines,
                                use_resolution=False,
                                number_of_cuts_across=10,
                                number_of_cuts_down=10,
                                snap_verts=False,
                                precision=100,
                                samples_between_points=1000,
                                number_of_nudges=10,
                                round_to_decimals=3,
                                direction_check=False,
                                remove_double_distance=0.001):
    """create a quad mesh representation in a bm object from given multiple splines"""


    if len(splines) == 1:
        utils.create_surface_1_spline(bm,splines[0],
                            number_of_cuts_across=number_of_cuts_across,
                            use_resolution=use_resolution,
                            snap_verts=snap_verts,
                            precision=precision,
                            samples_between_points=samples_between_points,
                            number_of_nudges=number_of_nudges)
        return

    edge_to_spline_cache = {}
    spline_dict_list = []
    all_endpoints = []
    # create a spline dict representation with unique ids and other helper info.
    for spline in splines:
        # Assign splines based on end
        spline_dict = {}
        spline_dict['uuid'] = uuid.uuid4()
        spline_dict['spline'] = spline

        # determine and keep references to end points.
        bezier_points = spline.bezier_points
        endpoint1 = Vector(np.around(bezier_points[0].co, round_to_decimals))
        endpoint1.freeze()
        endpoint2 = Vector(np.around(bezier_points[-1].co, round_to_decimals))
        endpoint2.freeze()
        endpoints = [endpoint1, endpoint2]
        all_endpoints.extend(endpoints)
        spline_dict['endpoints'] = endpoints

        # add this to a list for reference later.
        spline_dict_list.append(spline_dict)

        # also generate a mapping so that splines can be retrieved based on
        # an endpoint.
        for endpoint in endpoints:
            if endpoint not in edge_to_spline_cache:
                edge_to_spline_cache[endpoint] = []
            edge_to_spline_cache[endpoint].append(spline_dict)


    # go through and find all quad edge loops.
    loops = []
    for spline_dict in spline_dict_list:
        potential_loop = []
        utils.find_loop(spline_dict, potential_loop, loops, edge_to_spline_cache, direction_check)

    # build up a mapping between a spline uuid and related loops.
    spline_loop_map = {}
    for loop in loops:
        for spline in loop:
            if spline['uuid'] not in spline_loop_map:
                spline_loop_map[spline['uuid']] = []
            spline_loop_map[spline['uuid']].append(loop)

    # go through remaining unordered loops and order them...
    if not use_resolution:
        remaining_unordered_loops = list(loops)
        highest_spline = None
        while len(remaining_unordered_loops) > 0:
            for loop in remaining_unordered_loops:
                for spline_dict in loop:
                    # find the highest spline.
                    if highest_spline is None:
                        highest_spline = spline_dict
                        highest_spline['location_z'] = sum([bp.co[2] for bp in spline_dict['spline'].bezier_points]) / len(spline_dict['spline'].bezier_points)
                    else:
                        spline_dict['location_z'] = sum([bp.co[2] for bp in spline_dict['spline'].bezier_points]) / len(spline_dict['spline'].bezier_points)
                        if spline_dict['location_z'] > highest_spline['location_z']:
                            highest_spline = spline_dict

            # For all remaining loops, rearrange order of splines so they are uniform.
            utils.order_loops(highest_spline, spline_loop_map, remaining_unordered_loops, loops)
            highest_spline = None

    # Go through and create each patch of faces for a loop.
    # cache is to remember the splines that already have points that are generated for the edges.
    edge_point_cache = {}
    # keep a record of any remaining splines that may not have been part of a loop.
    remaining_splines = {spline['uuid']: spline for spline in spline_dict_list}


    for loop in loops:
        utils.create_surface_4_splines(bm,
                                        loop,
                                        use_resolution=use_resolution,
                                        number_of_cuts_across=number_of_cuts_across,
                                        number_of_cuts_down=number_of_cuts_down,
                                        snap_verts=snap_verts,
                                        precision=precision,
                                        samples_between_points=samples_between_points,
                                        number_of_nudges=number_of_nudges,
                                        edge_point_cache=edge_point_cache)
        for spline in loop:
            spline_uuid = spline['uuid']
            if spline_uuid in remaining_splines.keys():
                del remaining_splines[spline_uuid]

    # If there are remaining splines then just create edges along them.
    for spline_uuid in remaining_splines.keys():
        utils.create_surface_1_spline(bm,remaining_splines.get(spline_uuid)['spline'],
                            number_of_cuts_across=number_of_cuts_across,
                            use_resolution=use_resolution,
                            snap_verts=snap_verts,
                            precision=precision,
                            samples_between_points=samples_between_points,
                            number_of_nudges=number_of_nudges)



    # sew up the patches by removing the patches and then make sure the normals are uniform.
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=remove_double_distance)#0.0001)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

def curve_surfaces_to_mesh(bm, curves,
                                use_resolution=False,
                                number_of_cuts_across=10,
                                number_of_cuts_down=10,
                                snap_verts=False,
                                precision=100,
                                samples_between_points=1000,
                                number_of_nudges=10,
                                round_to_decimals=3,
                                direction_check=False,
                                remove_double_distance=0.001):

    splines = utils.get_transformed_splines(curves, round_to_decimals)

    curve_splines_to_mesh(bm, splines,
                                    use_resolution=use_resolution,
                                    number_of_cuts_across=number_of_cuts_across,
                                    number_of_cuts_down=number_of_cuts_down,
                                    snap_verts=snap_verts,
                                    precision=precision,
                                    samples_between_points=samples_between_points,
                                    number_of_nudges=number_of_nudges,
                                    round_to_decimals=round_to_decimals,
                                    direction_check=direction_check,
                                    remove_double_distance=remove_double_distance)
