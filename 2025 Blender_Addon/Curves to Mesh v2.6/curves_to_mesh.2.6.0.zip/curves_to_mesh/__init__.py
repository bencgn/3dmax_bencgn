bl_info = {
    "name": "Curves to Mesh",
    "author": "Mark Kingsnorth",
    "version": (2, 6, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Object > Curves to Mesh",
    "description": "Creates mesh object from selected curves",
    "warning": "",
    "wiki_url": "",
    "category": "Add Mesh",
    }

# To support reload properly, try to access a package var,
# if it's there, reload everything
if "bpy" in locals():
    import imp
    imp.reload(props)
    imp.reload(utils)
    imp.reload(ui)
    imp.reload(preferences)
    imp.reload(classes)
    imp.reload(operators)
    imp.reload(add_2x2_curve)
    imp.reload(keymaps)
    imp.reload(curve_funcs)
    imp.reload(curve_uis)
    print("Reloaded Curves To Mesh files...")
else:
    from . import props
    from . import utils
    from . import ui
    from . import preferences
    from . import classes
    from . import operators
    from . import add_2x2_curve
    from . import keymaps
    from . import curve_funcs
    from . import curve_uis

    print("Imported Curves To Mesh...")

import bpy

addon_keymaps = []
def add_to_key_map():
    kc = bpy.context.window_manager.keyconfigs.addon
    # create the mode switch menu hotkey
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshCancelOperator.bl_idname, 'ESC', 'PRESS', alt=False, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshForceRefreshOperator.bl_idname, 'R', 'PRESS', alt=False, ctrl=True, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshDecreaseSubDOperator.bl_idname, 'LEFT_ARROW', 'PRESS', alt=True, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshIncreaseSubDDownOperator.bl_idname, 'RIGHT_ARROW', 'PRESS', alt=True, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshDecreaseSubDAcrossOperator.bl_idname, 'DOWN_ARROW', 'PRESS', alt=True, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshIncreaseSubDAcrossOperator.bl_idname, 'UP_ARROW', 'PRESS', alt=True, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshCommitOperator.bl_idname, 'RET', 'PRESS', alt=True, ctrl=False, shift=False)
    kmi.active = True
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new(operators.OBJECT_MT_CurvesToMeshPreviewOperator.bl_idname, 'V', 'PRESS', alt=False, ctrl=False, shift=True)
    kmi.active = True
    addon_keymaps.append((km, kmi))

def remove_from_key_map():
    # handle the keymap
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

addon_classes = [props.OBJECT_OT_CurvePointPropertiesGroup,
            props.OBJECT_OT_CurvePropertiesGroup,
            add_2x2_curve.OBJECT_OT_add_2x2_curve,
            operators.OBJECT_MT_CurvesToMeshPreviewOperator,
            preferences.CurvesToMeshAddonPreferences,
            operators.OBJECT_MT_CurvesToMeshCommitOperator,
            operators.OBJECT_MT_CurvesToMeshGlobalOperator,
            operators.OBJECT_MT_CurvesToMeshIncreaseSubDAcrossOperator,
            operators.OBJECT_MT_CurvesToMeshDecreaseSubDAcrossOperator,
            operators.OBJECT_MT_CurvesToMeshIncreaseSubDDownOperator,
            operators.OBJECT_MT_CurvesToMeshDecreaseSubDOperator,
            operators.OBJECT_MT_CurvesToMeshForceRefreshOperator,
            operators.OBJECT_MT_CurvesToMeshCancelOperator,
            operators.OBJECT_MT_curves_to_mesh,
            ui.OBJECT_PT_curves_to_mesh,
            ui.OBJECT_PT_curves_to_mesh_adv
            ]

def register():
    """register operator"""
    utils.add_properties(bpy.types.Scene)

    from bpy.utils import register_class
    for cls in addon_classes:
        register_class(cls)

    operators.append_to_menu()
    add_to_key_map()
    add_2x2_curve.append_to_menu()

def unregister():
    """unregister operator"""
    operators.remove_from_menu()
    remove_from_key_map()
    add_2x2_curve.remove_from_menu()
    from bpy.utils import unregister_class
    for cls in reversed(addon_classes):
        unregister_class(cls)

    utils.del_properties(bpy.types.Scene)


if __name__ == "__main__":
    register()
