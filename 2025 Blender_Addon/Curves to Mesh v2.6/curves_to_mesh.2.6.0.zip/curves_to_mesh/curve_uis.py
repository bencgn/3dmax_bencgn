import uuid
from mathutils import Vector
from . import utils
import bmesh

def curve_profiles_to_mesh(layout, context):
    col = layout.column()
    col.separator()
    col.label(text="Profile Subdivisions")

    box = col.box()
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_across", text="Curve Subdivisions")
    col.enabled = not context.scene.c2m_use_resolution
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_down", text="Bridging Subdivisions")
    col.separator()
    col = box.column()
    col.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")
    col = box.column()
    col.label(text="Bridge creation")
    col.prop(context.scene, "c2m_twist", text="Twist")
    col.label(text="Bridge Ordering")
    col.prop(context.scene, "c2m_bridge_order", text="")
    if context.scene.c2m_bridge_order == 'ORDER':
        col.prop(context.scene, "c2m_bridge_order_reversed", text='Reverse')

def curve_sweep_to_mesh(layout, context):
    col = layout.column()

    box = col.box()
    box.label(text="Sweep Curve")
    box.prop(context.scene, "c2m_sweep_curve", text="")
    box.prop(context.scene, "c2m_number_of_cuts_down", text="Subdivisions")
    box.prop(context.scene, "c2m_sweep_curve_subd", text="Accuracy")

    col.separator()

    box = col.box()
    box.label(text="Cross Sections")
    col1 = box.column()
    col1.prop(context.scene, "c2m_number_of_cuts_across", text="Subdivisions")
    col1.enabled = not context.scene.c2m_use_resolution
    box.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")

    col.separator()
    box = col.box()
    box.label(text="Bridge creation (degrees)")
    box.prop(context.scene, "c2m_twist", text="Twist")


def curve_surface_to_mesh(layout, context):
    col = layout.column()
    col.separator()
    col.label(text="Surface Subdivisions")

    box = col.box()
    col = box.column()
    col.prop(context.scene, "c2m_number_of_cuts_across", text="Across")
    col.prop(context.scene, "c2m_number_of_cuts_down", text="Down")
    col.enabled = not context.scene.c2m_use_resolution
    col = box.column()
    col.prop(context.scene, "c2m_use_resolution", text="Use Curve Resolution")
    col = box.column()
    col.separator()
    col.label(text="Surface Creation:")
    col.prop(context.scene, "c2m_direction_check", text="Check direction of curve")
