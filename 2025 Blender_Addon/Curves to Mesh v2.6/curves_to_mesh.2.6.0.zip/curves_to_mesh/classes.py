'''
    Classes that implement the curves to mesh operators
'''
import bpy
import bmesh
from . import utils
from . import ui
from . import props
from . import curve_funcs
from bpy.props import (
        BoolProperty,
        IntProperty,
        FloatProperty,
        StringProperty,
        CollectionProperty
        )
import os

class CurvesToSurface():
    """Create a mesh from curves"""
    bl_idname = "mesh.curves_to_mesh"
    bl_label = "Curves To Mesh"

    running_curves_to_meshes = {}

    def validate_region(self):
        if not (CurvesToSurface.running_curves_to_meshes.get(self._region) is self): return False
        return utils.region_exists(self._region)

    # internal handling variables.curve_name
    old_curves : CollectionProperty(type=props.OBJECT_OT_CurvePropertiesGroup, options={'SKIP_SAVE', 'HIDDEN'})
    new_curves : CollectionProperty(type=props.OBJECT_OT_CurvePropertiesGroup, options={'SKIP_SAVE', 'HIDDEN'})
    faces : {}
    verts : {}
    edges : {}

    def create_mesh(self, context, args):
        """Create the mesh given the curve calculations that have taken place"""


        # create the new mesh.
        mesh = bpy.data.meshes.new("mesh")
        new_obj = bpy.data.objects.new("MeshFromCurve", mesh)
        bm = bmesh.new()
        bm.from_mesh(mesh)

        # apply the geometry we will have saved.
        for vert_index in self.verts.keys():
            vert = self.verts[vert_index]
            new_vert = bm.verts.new((vert[0],vert[1],vert[2]))
            new_vert.index = vert_index

        bm.verts.ensure_lookup_table()

        # maintain a record of any remaining edges to create once faces have been created.
        edges_to_create = [edge_index for edge_index in self.edges.keys()]

        # now apply face data.
        for face_index in self.faces.keys():
            face_vert_indexes = self.faces[face_index]['vert_indexes']
            face = bm.faces.new([bm.verts[i] for i in face_vert_indexes])
            face.index = face_index
            face_edge_indexes = self.faces[face_index]['edge_indexes']
            for face_edge_index in face_edge_indexes:
                if face_edge_index in edges_to_create:
                    edges_to_create.remove(face_edge_index)

        # pick up any remaining edges to create that aren't part of  a face.
        for edge_to_create_index in edges_to_create:
            vert_indexes = self.edges[edge_to_create_index]
            verts = []
            verts.append(bm.verts[vert_indexes[0]])
            verts.append(bm.verts[vert_indexes[1]])
            bm.edges.new(verts)

        # finish a mesh off once it is done.

        #flip the normals if necessary.
        if args.c2m_flip_normals:
            bmesh.ops.reverse_faces(bm, faces=bm.faces)

        #shade all the faces as smooth if needed.
        if args.c2m_shade_smooth:
            for f in bm.faces:
                f.smooth = True

        bm.to_mesh(mesh)
        mesh.update()
        bm.free()

        # new_obj.matrix_world = curve.matrix_world

        new_obj.show_all_edges = args.c2m_show_all_edges
        new_obj.show_wire = args.c2m_show_wire


        # add the object to the scene.
        context.scene.collection.objects.link(new_obj)
        # curve.select_set(False)
        for selected_object in context.selected_objects:
            selected_object.select_set(False)
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj
        layer = context.view_layer
        layer.update()

        #apply mirror modifier if needed.
        if args.c2m_mirror_x or args.c2m_mirror_y or args.c2m_mirror_z:
            bpy.ops.object.modifier_add(type='MIRROR')
            context.object.modifiers["Mirror"].use_axis[0] = args.c2m_mirror_x
            context.object.modifiers["Mirror"].use_axis[1] = args.c2m_mirror_y
            context.object.modifiers["Mirror"].use_axis[2] = args.c2m_mirror_z
            context.object.modifiers["Mirror"].use_clip = True
            context.object.modifiers["Mirror"].show_expanded = False


    def generate_mesh(self, context, args, stop_modifier_creation = False):
        """Calculate the mesh based on the given curves."""
        curves = utils.get_curves(args)

        if len(curves):
            # temporarily create a bm to calculate the geometry.
            bm = bmesh.new()

            # do the calculation.
            getattr(curve_funcs, args.c2m_curve_method)(self, bm, args, curves)

            # copy over modifiers
            if not stop_modifier_creation and (args.c2m_mirror_x or args.c2m_mirror_y or args.c2m_mirror_z):
                try:
                    mesh = bpy.data.meshes.new("mesh")
                    bm.to_mesh(mesh)
                    mesh.update()
                    new_obj = bpy.data.objects.new("MeshFromCurve", mesh)

                    old_active = context.view_layer.objects.active
                    if old_active is not None:
                        old_mode = context.view_layer.objects.active.mode
                    context.scene.collection.objects.link(new_obj)
                    context.view_layer.objects.active = new_obj

                    #apply mirror modifier.
                    bpy.ops.object.modifier_add(type='MIRROR')
                    context.object.modifiers["Mirror"].use_axis[0] = args.c2m_mirror_x
                    context.object.modifiers["Mirror"].use_axis[1] = args.c2m_mirror_y
                    context.object.modifiers["Mirror"].use_axis[2] = args.c2m_mirror_z
                    context.object.modifiers["Mirror"].use_clip = True
                    context.object.modifiers["Mirror"].show_expanded = False

                    for mod in new_obj.modifiers:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    context.view_layer.objects.active = old_active
                    if old_active is not None:
                        bpy.ops.object.mode_set(mode = old_mode)

                    bm = bmesh.new()
                    bm.from_mesh(new_obj.data)

                finally:
                    bpy.data.objects.remove(new_obj)

            # cache the geometry generated from the bm so that it can be reated later.
            self.verts = {}
            self.faces = {}
            self.edges = {}

            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            for face in bm.faces:
                vert_indexes = []
                for vert in face.verts:
                    vert_indexes.append(vert.index)
                edge_indexes = []
                for edge in face.edges:
                    edge_indexes.append(edge.index)
                self.faces[face.index] = {'vert_indexes' : vert_indexes, 'edge_indexes' : edge_indexes}

            for vert in bm.verts:
                self.verts[vert.index] = vert.co.copy()

            for edge in bm.edges:
                edge_verts = edge.verts
                self.edges[edge.index] = [edge.verts[0].index, edge.verts[1].index]

            bm.free()

    def initialise(self, context, event):

        #get information about the viewing region.
        region = context.region
        self.region_x = region.x
        self.region_y = region.y
        self._region = context.region
        CurvesToSurface.running_curves_to_meshes[self._region] = self

        # initialise variables.
        self.old_curves.clear()
        self.new_curves.clear()

        #draw a framing user interface for generating the mesh before commiting to it.
        if context.area.type == 'VIEW_3D':
            self._handle_3d = bpy.types.SpaceView3D.draw_handler_add(ui.draw_callback_3d, (self, context), 'WINDOW', 'POST_VIEW')


    def cancel(self, context):
        """Reset the screen by removing custom draw handlers."""
        try:
            if hasattr(context.scene, 'c2m_preview_mode'):
                context.scene.c2m_preview_mode = False
            bpy.types.SpaceView3D.draw_handler_remove(self._handle_3d, 'WINDOW')
            context.area.tag_redraw()
            context.region.tag_redraw()
            layer = context.view_layer
            layer.update()
            if CurvesToSurface.running_curves_to_meshes.get(self._region) is self:
                del CurvesToSurface.running_curves_to_meshes[self._region]
        except Exception as e:
            pass


    @classmethod
    def poll(cls, context):
        """Poll function to determine whether the operator should be run"""
        #must be in edit and face select mode.
        return len(utils.get_curves(context.scene)) > 0
