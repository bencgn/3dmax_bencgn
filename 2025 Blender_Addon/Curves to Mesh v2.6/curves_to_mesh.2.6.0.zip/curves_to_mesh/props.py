from bpy.types import PropertyGroup
from bpy.props import StringProperty, FloatVectorProperty, IntProperty, CollectionProperty
from mathutils import Vector

class OBJECT_OT_CurvePointPropertiesGroup(PropertyGroup):
    """Properties Group representation of a spline handle."""
    co : FloatVectorProperty()
    lh_co : FloatVectorProperty()
    rh_co : FloatVectorProperty()
    resolution : IntProperty()

class OBJECT_OT_CurvePropertiesGroup(PropertyGroup):
    """Properties Group representation of a spline handle."""
    name : StringProperty()
    location: FloatVectorProperty()
    no_splines: IntProperty()
    bezier_points: CollectionProperty(type=OBJECT_OT_CurvePointPropertiesGroup)

class C2M_Spline():
    def __init__(self, type, resolution_u, use_cyclic_u, use_cyclic_v):
        self.bezier_points = []
        self.type = type
        self.resolution_u = resolution_u
        self.use_cyclic_u = use_cyclic_u
        self.use_cyclic_v = use_cyclic_v

class C2M_BezierPoint():
        def __init__(self, co, handle_left, handle_right):
            self.co = co
            self.handle_left = handle_left
            self.handle_right = handle_right

creation_method_items = (('curve_surface_to_mesh', 'Surface to Mesh', ''),
                                                     ('curve_profiles_to_mesh', 'Profiles to Mesh', ''),
                                                     ('curve_sweep_to_mesh', 'Sweep to Mesh', ''))

bridge_order_items = (('PROXIMITY', 'Position', ''),
                                                     ('ORDER', 'Curve Name', ''))
