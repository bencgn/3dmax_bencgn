from . import utils
from curves_to_mesh import curve_funcs

def curve_surfaces_to_mesh(bm, splines,
                                use_resolution=False,
                                number_of_cuts_across=10,
                                number_of_cuts_down=10,
                                snap_verts=False,
                                precision=100,
                                samples_between_points=1000,
                                number_of_nudges=10,
                                round_to_decimals=3,
                                direction_check=False):


    converted_splines = utils.get_transformed_splines(splines, round_to_decimals)

    curve_funcs.curve_splines_to_mesh(bm, converted_splines,
                                    use_resolution=use_resolution,
                                    number_of_cuts_across=number_of_cuts_across,
                                    number_of_cuts_down=number_of_cuts_down,
                                    snap_verts=snap_verts,
                                    precision=precision,
                                    samples_between_points=samples_between_points,
                                    number_of_nudges=number_of_nudges,
                                    round_to_decimals=round_to_decimals,
                                    direction_check=direction_check)
