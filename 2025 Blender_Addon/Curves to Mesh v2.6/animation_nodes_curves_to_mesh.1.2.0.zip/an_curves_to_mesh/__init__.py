bl_info = {
    "name": "Animation Nodes: Curves To Mesh",
    "author": "Mark Kingsnorth",
    "version": (1, 2, 0),
    "blender": (2, 80, 0),
    "description": "Animation Nodes version of Curves To Mesh",
    "warning": "",
    "wiki_url": "",
    "category": "Add Mesh",
    }


try: import curves_to_mesh
except: pass

if "curves_to_mesh" not in globals():
    message = ("\n\n"
        "This addon depends on the Curves To Mesh addon 2.2 and above.\n"
        "This is available at https://blendermarket.com/creators/mark-kingsnorth")
    raise Exception(message)


try: import animation_nodes
except: pass

if "animation_nodes" not in globals():
    message = ("\n\n"
        "The addon depends on the Animation Nodes addon.\n"
        "This is freely available at https://animation-nodes.com/#download")
    raise Exception(message)

from . import node_curves_to_mesh


print("Imported curves_to_mesh for animation nodes")

import bpy

def register():
    from bpy.utils import register_class
    register_class(node_curves_to_mesh.CurvesToMeshNode)

def unregister():
    from bpy.utils import unregister_class
    unregister_class(node_curves_to_mesh.CurvesToMeshNode)

if __name__ == "__main__":
    register()
