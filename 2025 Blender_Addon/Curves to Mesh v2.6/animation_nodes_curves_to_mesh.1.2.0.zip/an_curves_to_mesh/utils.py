from curves_to_mesh import props
from mathutils import Vector
import numpy as np

def get_transformed_splines(splines, round_to_decimals):
    
    test_splines = []
    spline_pos_map = {}

    # before we go anywhere, let's identify intersection points...
    for spline in splines:
        for i in range(0, len(spline.points)):
            co = spline.points[i]
            rounded = np.around(co, round_to_decimals)
            rounded_vec = Vector(rounded)
            rounded_vec.freeze()
            if rounded_vec not in spline_pos_map:
                spline_pos_map[rounded_vec] = []
            spline_pos_map[rounded_vec].append(spline)


    for spline in splines:
        if (len(spline.points) > 1):

            new_spline = props.C2M_Spline(spline.type, None, spline.cyclic, spline.cyclic)
            test_splines.append(new_spline)
            
            # add the first point.
            process_curve_point(spline, 0, new_spline)

            # go through the middle parts, if we have a middle part...checking for intersections along the way.
            if (len(spline.points) > 2):
                index = 1
                for pt in spline.points[1:-1]:
                    
                    new_bezier_point, co = process_curve_point(spline, index, new_spline)
                    
                    rounded = np.around(co, round_to_decimals)
                    rounded_vec = Vector(rounded)
                    rounded_vec.freeze()

                    if rounded_vec in spline_pos_map and \
                        len(spline_pos_map[rounded_vec])  > 1 and \
                            len(new_spline.bezier_points) > 1:
                        # Finish this one up and create a new one.
                        new_spline = props.C2M_Spline(spline.type, None, spline.cyclic, spline.cyclic)
                        test_splines.append(new_spline)
                        new_spline.bezier_points.append(new_bezier_point)

                    index+=1

            # add the last point.
            process_curve_point(spline, len(spline.points) - 1, new_spline)

    return test_splines

def process_curve_point(spline, index, new_spline):
    co = spline.points[index]
    handle_left = spline.leftHandles[index]
    handle_right = spline.rightHandles[index]
    new_bezier_point = props.C2M_BezierPoint(co,handle_left,handle_right)
    new_spline.bezier_points.append(new_bezier_point)
    return new_bezier_point, co