import bpy
from bpy.props import BoolProperty, FloatProperty
from animation_nodes.base_types import AnimationNode

from . import curve_funcs

import bmesh
from animation_nodes.data_structures import Vector3DList, EdgeIndicesList, PolygonIndicesList, Mesh

class CurvesToMeshNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_CurvesToMeshNode"
    bl_label = "Splines to Surface"

    snap_verts : bpy.props.BoolProperty(
            name="Snap Vertices",
            description="Snap vertices to closest curve points",
            default=True
        )

    round_to_decimals : bpy.props.IntProperty(
            name="Round corner points to",
            description="Merge vertices by rounding them to a number of decimal places.",
            min=0,
            default=3
        )

    def getVertexLocations(self, bMesh):
        return Vector3DList.fromValues(v.co for v in bMesh.verts)

    def getEdgeIndices(self, bMesh):
        return EdgeIndicesList.fromValues(tuple(v.index for v in edge.verts) for edge in bMesh.edges)

    def getPolygonIndices(self, bMesh):
        return PolygonIndicesList.fromValues(tuple(v.index for v in face.verts) for face in bMesh.faces)


    def create(self):
        self.newInput("Spline List", "Splines", "splines", defaultDrawType = "TEXT_ONLY")
        self.newInput("Integer", "Subdivisions", "subdivisions", value = 10, minValue=0)


        self.newOutput("Vector List", "Vertices", "vertices")
        self.newOutput("Edge Indices List", "Edge Indices", "edgeIndices")
        self.newOutput("Polygon Indices List", "Polygon Indices", "polygonIndices")

    def drawAdvanced(self, layout):

        col = layout.column()
        col.prop(self, "snap_verts")
        col.prop(self, "round_to_decimals")


    def execute(self,
                splines,
                subdivisions
                ):

        bm = bmesh.new()   # create an empty BMesh

        curve_funcs.curve_surfaces_to_mesh(bm, splines,
                                number_of_cuts_across=subdivisions,
                                number_of_cuts_down=subdivisions,
                                snap_verts=self.snap_verts,
                                round_to_decimals=self.round_to_decimals)


        vertices, edgeIndices, polygonIndices = None, None, None

        if self.outputs["Vertices"].isLinked: vertices = self.getVertexLocations(bm)
        if self.outputs["Edge Indices"].isLinked: edgeIndices = self.getEdgeIndices(bm)
        if self.outputs["Polygon Indices"].isLinked: polygonIndices = self.getPolygonIndices(bm)


        bm.free()  # free and prevent further access

        return vertices, edgeIndices, polygonIndices
