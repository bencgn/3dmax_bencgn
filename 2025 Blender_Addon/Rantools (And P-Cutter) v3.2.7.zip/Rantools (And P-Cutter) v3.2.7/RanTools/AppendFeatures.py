from . utils import *
import math
import bpy


class Append_Button(bpy.types.Operator):
    bl_idname = "rtools.append_button"
    bl_label = "Button"
    bl_description = "Append This Object/Collection/Material\nHold CTRL to use existing Material"
    bl_options = {'REGISTER', 'UNDO'}
    path: bpy.props.StringProperty()
    obj: bpy.props.StringProperty()
    ctrlDown = None

    @classmethod
    def description(cls, context, properties):
        if "Object" in properties.path:
            return translate_text("Append This Object")
        elif "Collection" in properties.path:
            return translate_text("Append This Collection")
        elif "NodeTree" in properties.path:
            return translate_text("Append This Node Group")
        elif "Material" in properties.path:
            return translate_text("Append This Material\nCTRL+LMB: use existing Material")
        
        else:
            return translate_text("Append This Object/Collection/Material\nCTRL+LMB: use existing Material")

    def execute(self, context):
        type=os.path.basename(os.path.dirname(self.path))
        
        if "Material" in self.path and self.ctrlDown and bpy.data.materials.get(self.obj) is not None:
            #print("Using Existing")
            mat = bpy.data.materials.get(self.obj)
            selected = bpy.context.selected_objects
            for ob in selected:
                if ob.type in {'MESH', 'CURVE'}:
                    if ob.data.materials:
                        # assign to 1st material slot
                        ob.data.materials[ob.active_material_index] = mat
                    else:
                        # no slots
                        ob.data.materials.append(mat)
        else:
            #print("Using New")
            matInit = []
            if "Material" in type:
                for m in bpy.data.materials:
                    matInit.append(m.name)
            bpy.ops.wm.append(
                directory=self.path,
                filename=self.obj, autoselect=not "Material" in self.path
            )
            matAfter = []
            if "Material" in type:
                for m in bpy.data.materials:
                    matAfter.append(m.name)
                mat = Diff(matInit, matAfter)
                #print(mat)
                mat = bpy.data.materials.get(mat[0])
                selected = bpy.context.selected_objects
                #print(selected)
                for ob in selected:
                    if ob.type in {'MESH', 'CURVE'}:
                        if ob.data.materials:
                            # assign to 1st material slot
                            ob.data.materials[ob.active_material_index] = mat
                        else:
                            # no slots
                            ob.data.materials.append(mat)
        return {'FINISHED'}

    def invoke(self, context, event):
        if event.ctrl:
            self.ctrlDown = True
        else:
            self.ctrlDown = False
        return self.execute(context)


class Call_Append_Panel(bpy.types.Operator):
    bl_idname = "rtools.call_append_panel"
    bl_label = "Append Object Panel"
    bl_description = "Append Object matching this name"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "name"

    name: bpy.props.StringProperty(
        name="Append Object",
        description="Used to Append file matching this Name",
        default="",
        update=AppendNameUpdated
    )
    Materials: bpy.props.BoolProperty(default=False)
    Objects: bpy.props.BoolProperty(default=False)
    Collections: bpy.props.BoolProperty(default=False)
    NodeGroups: bpy.props.BoolProperty(default=False)
    def draw(self, context):
        i = 0
        itemAdded = True
        layout = self.layout

        scene = context.scene
        layout.label(text="Append Object")
        column = layout.column()
        column = column.box()

        row = column.row()

        row = row.split(factor=0.65)
        row.prop(self, "name", text="", text_ctxt="", icon='OBJECT_DATA')
        row.prop(preferences(), "use_unique", text="Unique",toggle=True)
        row.operator("rtools.refresh_indexes", text="", icon="FILE_REFRESH")
        row = column.row(align=True)

        row.prop(self, "Objects", text="Objects")
        row.prop(self, "Collections", text="Collections")
        row.prop(self, "Materials", text="Materials")
        row.prop(self, "NodeGroups", text="Node Groups")
        row = layout.row()
        #column = row.column()
        for item in context.scene.rt_props:
            if i >= 150:
                break
            if i % 30 == 0 and itemAdded:
                itemAdded = False
                column = row.column()
            if not self.Materials and not self.Objects and not self.Collections and not self.NodeGroups:
                # row=column.column()
                button = column.operator(
                    "rtools.append_button", text=item.type)
                button.path = item.path
                button.obj = item.name
                itemAdded = True
                i = i+1
            else:
                if "World" in item.type and self.Materials:
                    # row=column.row()
                    button = column.operator(
                        "rtools.append_button", text=item.type)
                    button.path = item.path
                    button.obj = item.name
                    itemAdded = True
                    i = i+1
                if "Material" in item.type and self.Materials:
                    # row=column.row()
                    button = column.operator(
                        "rtools.append_button", text=item.type)
                    button.path = item.path
                    button.obj = item.name
                    itemAdded = True
                    i = i+1
                if "Object" in item.type and self.Objects:
                    # row=column.row()
                    button = column.operator(
                        "rtools.append_button", text=item.type)
                    button.path = item.path
                    button.obj = item.name
                    itemAdded = True
                    i = i+1
                if "Collection" in item.type and self.Collections:
                    # row=column.row()
                    button = column.operator(
                        "rtools.append_button", text=item.type)
                    button.path = item.path
                    button.obj = item.name
                    itemAdded = True
                    i = i+1
                if "NodeTree" in item.type and self.NodeGroups:
                    # row=column.row()
                    button = column.operator(
                        "rtools.append_button", text=item.type)
                    button.path = item.path
                    button.obj = item.name
                    itemAdded = True
                    i = i+1
        layout.ui_units_x = min(15 * math.ceil(i/30), 80)

        #RT_PT_Append_Panel.draw(self, context)

    def invoke(self, context, event):
        context.scene.rt_props.clear()
        return context.window_manager.invoke_popup(self)

    def execute(self, context):

        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}


class appendObjectInfo(bpy.types.PropertyGroup):
    path: bpy.props.StringProperty(name="path", default="")
    name: bpy.props.StringProperty(name="name", default="")
    type: bpy.props.StringProperty(name="type", default="")


class RTOOLS_OT_Append(bpy.types.Operator):
    # Calling Select All Including
    bl_idname = "rtools.append_by_name"
    bl_label = "Append Object"
    bl_description = "Append Object matching this name"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty()

    def execute(self, context):

        appendAsset(context, self.name)
        return {'FINISHED'}
