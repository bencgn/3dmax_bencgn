import inspect
import json
from logging import exception
import bpy
from bpy.props import *
from .utils import *
from bpy_extras.io_utils import ImportHelper
from .modifier_layouts import *
requiresSet = [
    "data_types_edges",
    "data_types_loops",
    "data_types_polys",
    "data_types_verts",
    "flip_axis",
    "read_data",
    "proximity_geometry",
]
requiresObject = ["curve", "object", "offset_object", "mirror_object", "target"]
activeProps={"ARRAY":'count',
'BEVEL':'width',
'SCREW':'screw_offset',
'SOLIDIFY':'thickness',
'SUBSURF':'levels',
'WELD':'merge_threshold',
'CAST':'radius',
'DISPLACE':'strength',
'SHRINKWRAP':'offset',
'SIMPLE_DEFORM':'angle',
'SMOOTH':'factor',
'WEIGHTED_NORMAL':'weight',
'WIREFRAME':'thickness',}
int_props=['count','iterations','weight','segments','steps','render_steps','levels','render_levels','frame_start','frame_duration']
icons={'MULTIRES': 'MOD_MULTIRES',
'ARRAY': 'MOD_ARRAY',
'BEVEL': 'MOD_BEVEL',
'BOOLEAN': 'MOD_BOOLEAN',
'BUILD': 'MOD_BUILD',
'DECIMATE': 'MOD_DECIM',
'EDGE_SPLIT': 'MOD_EDGESPLIT',
'NODES': 'MOD_NODES',
'MASK': 'MOD_MASK',
'MIRROR': 'MOD_MIRROR',
'REMESH': 'MOD_REMESH',
'SCREW': 'MOD_SCREW',
'SKIN': 'MOD_SKIN',
'SOLIDIFY': 'MOD_SOLIDIFY',
'SUBSURF': 'MOD_SUBSURF',
'TRIANGULATE': 'MOD_TRIANGULATE',
'VOLUME_TO_MESH': 'VOLUME_DATA',
'WELD': 'AUTOMERGE_ON',
'WIREFRAME': 'MOD_WIREFRAME',
'ARMATURE': 'MOD_ARMATURE',
'CAST': 'MOD_CAST',
'CURVE': 'MOD_CURVE',
'DISPLACE': 'MOD_DISPLACE',
'HOOK': 'HOOK',
'LAPLACIANDEFORM': 'MOD_MESHDEFORM',
'LATTICE': 'MOD_LATTICE',
'MESH_DEFORM': 'MOD_MESHDEFORM',
'SHRINKWRAP': 'MOD_SHRINKWRAP',
'SIMPLE_DEFORM': 'MOD_SIMPLEDEFORM',
'SMOOTH': 'MOD_SMOOTH',
'CORRECTIVE_SMOOTH': 'MOD_SMOOTH',
'LAPLACIANSMOOTH': 'MOD_SMOOTH',
'SURFACE_DEFORM': 'MOD_MESHDEFORM',
'WARP': 'MOD_WARP',
'WAVE': 'MOD_WAVE',
'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
'MESH_CACHE': 'MOD_MESHDEFORM',
'MESH_SEQUENCE_CACHE': 'MOD_MESHDEFORM',
'NORMAL_EDIT': 'MOD_NORMALEDIT',
'WEIGHTED_NORMAL': 'MOD_NORMALEDIT',
'UV_PROJECT': 'MOD_UVPROJECT',
'UV_WARP': 'MOD_UVPROJECT',
'VERTEX_WEIGHT_EDIT': 'MOD_VERTEX_WEIGHT',
'VERTEX_WEIGHT_MIX': 'MOD_VERTEX_WEIGHT',
'VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
'OCEAN':'MOD_OCEAN',
'EXPLODE': 'MOD_EXPLODE'}
modifier_properties={'WEIGHTED_NORMAL':('weight',),
'ARRAY': ('fit_type','count','use_merge_vertices'),
'BEVEL': ('width','segments','use_clamp_overlap'),
'BOOLEAN': ('object','solver'),
'BUILD': ('frame_start','frame_duration'),
'EDGE_SPLIT': ('use_edge_angle','split_angle','use_edge_sharp'),
'MIRROR': ('use_axis','use_bisect_axis','use_bisect_flip_axis','use_mirror_merge','merge_threshold'),
'SCREW': ('angle','screw_offset','steps','render_steps'),
'SOLIDIFY': ('thickness','offset'),
'SUBSURF': ('subdivision_type','levels',),
'WELD': ('merge_threshold',),
'CAST': ('cast_type','factor'),
'CURVE': ('object','deform_axis'),
'DISPLACE': ('strength','mid_level'),
'HOOK': ('strength',),
'LAPLACIANDEFORM': ('iterations',),
'LATTICE': ('strength',),
'MESH_DEFORM': ('precision',),
'SHRINKWRAP': ('offset',),
'SIMPLE_DEFORM': ('angle','factor'),
'SMOOTH': ('factor','iterations'),
'CORRECTIVE_SMOOTH': ('factor','iterations','scale'),
'LAPLACIANSMOOTH': ('iterations',),
'SURFACE_DEFORM': ('falloff','strength'),
'WARP': ('strength',),
'WAVE': ('falloff_radius','height','width','narrowness'),}
events={'MINUS':'-','NUMPAD_MINUS':'-','ZERO' :0,'ONE':1,'TWO' :2,'THREE': 3,'FOUR': 4,'FIVE': 5,'SIX' :6,'SEVEN': 7,'EIGHT': 8,'NINE': 9,'PERIOD':'.','NUMPAD_1':1,'NUMPAD_2':2,'NUMPAD_3':3,'NUMPAD_4':4,'NUMPAD_5':5,'NUMPAD_6':6,'NUMPAD_7':7,'NUMPAD_8':8,'NUMPAD_9':9,'NUMPAD_0':0,'NUMPAD_PERIOD':'.'}
def copyProp(prop):
    if type(prop) == Vector:
        return (prop[0], prop[1], prop[2])
    elif prop == set():
        return []
    elif type(prop) == set:
        return [value for value in prop]
    return (
        [value for value in prop]
        if hasattr(prop, "__iter__") and type(prop) != str
        else prop
    )
def sync_modifiers(modifiers,active):
    mod=modifiers[len(modifiers)-1][1]
    
    if "Synced Modifiers" in bpy.context.preferences.addons.keys():
        t=active.SyncedModifierInfo.add()
        t.name=mod.name
        active.SyncedModifierIndex=len(active.SyncedModifierInfo)-1
    for obj,o_mod in modifiers[:-1]:
        if o_mod:
                        props=[ key for key, value in inspect.getmembers(o_mod) if key not in requiresObject and key not in {'name','is_active','vertex_group','filepath','driver','end_cap','start_cap','collection','armature','rim_vertex_group','shell_vertex_group','grid_name','execution_time',
                                "execution_time","is_cached",
                                "is_bound",
                                "is_bind",
                                "vertex_indices",
                                "vertex_indices_set",
                                "matrix_inverse",
                                "falloff_curve",
                                "vertex_velocities",
                                "read_velocity",
                                "has_velocity",
                                "map_curve",
                                "projectors",
                                "__doc__",
                                "__module__",
                                "__slotnames__",
                                "__slots__",
                                "bl_rna",
                                "rna_type",
                                "debug_options",
                                "type",
                                "object",
                                "delimit",
                                "custom_profile",
                                "face_count",
                                "is_external","cache_file","object_path","mask_tex_map_bone","mask_tex_map_object","mask_tex_uv_layer","mask_texture","mask_vertex_group","vertex_group_a","vertex_group_b","use_bone_envelopes","use_vertex_groups",
                                "total_levels",'texture','texture_coords_bone','texture_coords_object','uv_layer','auxiliary_target','origin','bone_from','bone_to','object_from','object_to','start_position_object',
                                "subtarget","is_override_data"
                            }]
                            
                        props=do_props(props,o_mod.type)
                        #print(props)
                        add_driver(props,o_mod,mod,active)
                        if "Synced Modifiers" in bpy.context.preferences.addons.keys():
                            t=obj.SyncedModifierInfo.add()
                            t.name=o_mod.name
                            obj.SyncedModifierIndex=len(obj.SyncedModifierInfo)-1
class RTOOLS_OT_Apply_All_Modifiers(bpy.types.Operator):
    bl_label = "Apply All"
    bl_idname = "rtools.applyallmodifiers"
    bl_options = {'REGISTER','UNDO'}
    object:bpy.props.StringProperty()
    def execute(self, context):
        apply_all_modifiers(bpy.data.objects[self.object])
        return {'FINISHED'}
class RTOOLS_MT_Modifier_Adjust_Panel2(bpy.types.Operator):
    bl_label = "Modifier Adjust Panel"
    bl_idname = "rtools.modifieradjustpanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}
    show_booleans:bpy.props.BoolProperty(default=False,name="Show Booleans")
    def draw(self, context):
        layout = self.layout
        layout.ui_units_x=15*len([o for o in context.selected_objects if len(o.modifiers)>0])
        layout.label(text="Quick Modifier Adjust")
        layout.operator_context = "INVOKE_DEFAULT"
        layout.prop(self,'show_booleans')
        layout=layout.row()
        
        #col= layout.column()
        
        for obj in [o for o in context.selected_objects if len(o.modifiers)>0]:
            col= layout.column()
            col.label(text=obj.name)
            col.operator('rtools.applyallmodifiers',text="Apply All").object=obj.name
            
            for m in obj.modifiers:
                if m.type in modifier_properties.keys():
                    if m.type=='BOOLEAN' and not self.show_booleans:
                        pass
                    else:
                        box=col.box()
                        row=box.row()
                        row=row.split(factor=0.25)
                        row.label(text=m.name)
                        if m.type=='BOOLEAN' and m.object:
                            if m.object.hide_view:
                                row.prop(m.object, "hide_view", text="",emboss=False, icon="HIDE_ON")
                            else:
                                row.prop(m.object, "hide_view", text="",emboss=False, icon="HIDE_OFF")
                        row.operator('object.modifier_remove',icon='PANEL_CLOSE',text='Remove').modifier=m.name
                        row.operator('object.modifier_apply',icon='CHECKMARK',text='Apply').modifier=m.name
                        if m.type =='MIRROR':
                            box=box.grid_flow(row_major=True,columns=3)
                        for prop in modifier_properties[m.type]:
                            box.prop(obj.modifiers.get(m.name),prop)
                        if m.type=='ARRAY':
                            if m.use_relative_offset:
                                box.prop(obj.modifiers.get(m.name),'relative_offset_displace')
                            if m.use_constant_offset:
                                box.prop(obj.modifiers.get(m.name),'constant_offset_displace')
                
    def invoke(self, context, event):
        if  len([o for o in context.selected_objects if len(o.modifiers)>0])>0:
            return context.window_manager.invoke_popup(self)
        else:
            self.report({'WARNING'},'No Modifiers Found!')
            return {'FINISHED'}
    def execute(self, context):
        return {'FINISHED'}
class RTOOLS_MT_Modifier_Adjust_Panel(bpy.types.Operator):
    bl_label = "Modifier Adjust"
    bl_idname = "rtools.modifieradjustpanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}
    show_booleans:bpy.props.BoolProperty(default=False,name="Show Booleans")
    def draw(self, context):
        layout = self.layout
        layout.ui_units_x=15*len([o for o in context.selected_objects if len(o.modifiers)>0])
        layout.label(text="Quick Modifier Adjust")
        layout.operator_context = "INVOKE_DEFAULT"
        layout.prop(self,'show_booleans')
        layout=layout.row()
        
        #col= layout.column()
        
        for obj in [o for o in context.selected_objects if len(o.modifiers)>0]:
            col= layout.column()
            col.label(text=obj.name)
            col.operator('rtools.applyallmodifiers',text="Apply All").object=obj.name
            
            for m in obj.modifiers:
                if m.type in modifier_properties.keys():
                    if m.type=='BOOLEAN' and not self.show_booleans:
                        pass
                    else:
                        col.separator()
                        col.separator()
                        box=col.box()
                        
                        box=box.column()
                        row=box.row(align=True)
                        row=row.split(factor=0.6)
                        row.label(text=m.name)
                        row.operator('object.modifier_apply',icon='CHECKMARK',text='').modifier=m.name
                        row.operator('object.modifier_remove',icon='PANEL_CLOSE',text='').modifier=m.name
                        row.prop(m,'show_viewport',text="",icon="RESTRICT_VIEW_ON")
                        row.prop(m,'show_render',text="",icon="RESTRICT_RENDER_ON")
                        eval(f'{m.type}(self,box,obj,m)')
                
    def invoke(self, context, event):
        if  len([o for o in context.selected_objects if len(o.modifiers)>0])>0:
            return context.window_manager.invoke_popup(self)
        else:
            self.report({'WARNING'},'No Modifiers Found!')
            return {'FINISHED'}
    def execute(self, context):
        return {'FINISHED'}
class MenuInfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    isStack: bpy.props.BoolProperty(default=False)
    type: bpy.props.StringProperty()


class subMenuInfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    isStack: bpy.props.BoolProperty(default=False)
    type: bpy.props.StringProperty()



class RTOOLS_MT_Mods_Sub_Menu(bpy.types.Menu):
    bl_label = "Modifier Presets"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        row = layout.row()
        column = row.column()
        for item in context.scene.modSubMenuInfo:
            if not item.isStack:
                button = column.operator(
                    "rtools.add_modifier_preset",
                    text=item.name,
                    icon=f"MOD_{item.type.replace('_','')}",
                )
                button.name = item.name
class RTOOLS_MT_Mods_Favorites_Menu(bpy.types.Menu):
    bl_label = "Favorite Modifier Presets "

    def draw(self, context):
        layout = self.layout
        layout.operator_context = "INVOKE_DEFAULT"
        column = layout
        if preferences().use_favorites_pie:
            column = layout.menu_pie()
        else:
            column=layout.column()
        #row = layout.row()
        #column = row.column()
        
        if os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresetsFavorites.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresetsFavorites.txt",
                    ),
                    mode="r",
                )
                favs=f.readline()
                preferences().mod_presets_favorites=favs
                f.close()
                for item in [a.strip() for a in favs.split(',') if a.replace(" ","") in [b.name.replace(" ","") for b in context.scene.modMenuInfo]]:
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item,
                    )
                    button.name = item
                    if preferences().use_favorites_pie:
                        button.ignore_alt=True

class RTOOLS_MT_Mods_Stacks_Menu(bpy.types.Menu):
    bl_label = "Modifier Presets"

    def draw(self, context):
        layout = self.layout
        
        layout.operator_context = "INVOKE_DEFAULT"
        row = layout.row()
        #column = row.column()
        i=0
        count=0
        for item in context.scene.modMenuInfo:
            if item.isStack:
                count=count+1
        #layout.ui_units_x=min(12 *math.ceil(count/18),30)
        
        #for item in [x for x in context.scene.modMenuInfo][::-1]:
        for item in [x for x in context.scene.modMenuInfo]:
            if item.isStack:
                if i%18==0:
                    column=row.column(heading="Modifier Presets Available")
                   
                button = column.operator("rtools.add_modifier_preset", text=item.name)
                button.name = item.name
                i=i+1
        


class RTOOLS_MT_Mods_Menu(bpy.types.Menu):
    bl_label = "Modifier Presets"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        column = row.column()
        if len(set([i for i in context.scene.modMenuInfo if i.isStack])) > 0:
            column.menu("RTOOLS_MT_Mods_Stacks_Menu", text="Stack Presets", icon="MODIFIER")
        for item in unique([i.type for i in context.scene.modMenuInfo if not i.isStack]):
            """button = column.operator(
                "rtools.invoke_modifier_sub_menu",
                text=item.capitalize(),
                icon=f"MOD_{item.replace('_','')}",
            )
            button.type = item"""
            column.menu(f"RTOOLS_MT_{item}_Mod_Menu", text=f"{item.replace('_',' ').title()}", icon=icons[item])
        
        


class RTOOLS_OT_Invoke_Modifier_Sub_Menu(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.invoke_modifier_sub_menu"
    bl_label = "Call Modifier Preset Sub Menu"
    bl_description = "Call Modifier Preset Sub Menu"
    bl_options = {"REGISTER", "UNDO"}
    type: bpy.props.StringProperty()

    def execute(self, context):
        context.scene.modSubMenuInfo.clear()

        try:
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                ),
                mode="r",
            ) as json_file:

                data = json.load(json_file)
                for p in data:

                    if "isStack" not in p[1] and p[1]["ModType"] == self.type:
                        item = context.scene.modSubMenuInfo.add()
                        item.name = p[0]
                        item.type = self.type
                        item.isStack = "isStack" in p[1]
        except:
            #print("E")
            self.report({"WARNING"}, "No Presets Found")

        bpy.ops.wm.call_menu(name="RTOOLS_MT_Mods_Sub_Menu")
        return {"FINISHED"}

    def invoke(self, context, event):

        return {"FINISHED"}


class RTOOLS_OT_Add_Modifier_Preset(bpy.types.Operator):
    bl_idname = "rtools.add_modifier_preset"
    bl_label = "Add Modifier Preset"
    bl_description = "Add this Modifier Preset\nSHIFT+CTRL+LMB:Add to all selected objects and sync modifiers\nSHIFT+LMB:Apply After Adding\nALT+LMB:Add/Remove from Favorites\nCTRL+LMB:Delete Preset"
    bl_options = {"REGISTER", "UNDO"}
    name: bpy.props.StringProperty(options={'HIDDEN'})
    ignore_alt: bpy.props.BoolProperty(options={'SKIP_SAVE','HIDDEN'},default=False)
    @classmethod
    def description(cls, context,properties):
        if properties.ignore_alt:
            return "Add this Modifier Preset\nSHIFT+CTRL+LMB:Add to all selected objects and sync modifiers\nSHIFT+LMB:Apply After Adding\nCTRL+LMB:Delete Preset"
        else:
            return "Add this Modifier Preset\nSHIFT+CTRL+LMB:Add to all selected objects and sync modifiers\nSHIFT+LMB:Apply After Adding\nALT+LMB:Add/Remove from Favorites\nCTRL+LMB:Delete Preset"
    @classmethod
    def poll(cls, context):
        if context.active_object is not None:# and len(bpy.context.selected_objects) in range(1, 3):
            return True
        else:
            return False
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        if self.mod is not None and self.activeProp is not None and self.activeProp2 is not None:
            s1=self.activeProp.replace("_"," ").capitalize()
            s2=self.activeProp2.replace("_"," ").capitalize()
            draw_Text(context,0,preferences().font_size,text=[f"{s1} : {format(round(getattr(self.mod,self.activeProp),4),'0.4f')}",f"{s2} : {getattr(self.mod,self.activeProp2)}"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y)
        elif self.mod is not None and self.activeProp is not None:
            s1=self.activeProp.replace("_"," ").capitalize()
            
            draw_Text(context,0,preferences().font_size,text=[f"{s1} : {format(round(getattr(self.mod,self.activeProp),4),'0.4f')}"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y)
        draw_Text(context,0,preferences().font_size,text=[f"X : 2x",f"Z : 1/2x"],alignH="RIGHT",activeKey=self.activeKey)
    def execute(self, context):
        
        if len(bpy.context.selected_objects) == 1:
            active=None
            obj = bpy.context.active_object
            if obj.type not in {'MESH','CURVE','SURFACE','FONT'}:
                self.report({"WARNING"}, "Active Object Does Not Support Modifiers")
                return {'FINISHED'}
        elif len(bpy.context.selected_objects)>1 and not self.add_drivers:
            #active = Diff(bpy.context.selected_objects, [bpy.context.active_object])[0]
            active = bpy.context.active_object
            for o in context.selected_objects:
                if o.type not in {'MESH','CURVE','SURFACE','FONT'}:
                    self.report({"WARNING"}, "Some Objects Do Not Support Modifiers")
                    return {'FINISHED'}
        elif self.add_drivers:
            active=context.active_object
            #return {"FINISHED"}
        else:
            return {'FINISHED'}
        with open(
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
            ),
            mode="r",
        ) as json_file:
            try:
                source=active
                objects=[a for a in context.selected_objects if a!=active]# if self.add_drivers else [obj,]
                if active and self.add_drivers:
                    objects.append(active)
                data = json.load(json_file)
                for p in data:
                    if p[0] == self.name:
                        
                            if "isStack" in p[1]:

                                for a, b in p[1].items():
                                    if a != "isStack":
                                        modifiers_to_sync=[]
                                        for obj in objects:
                                            mod = obj.modifiers.new(name=a, type=b["ModType"])
                                            #print(mod)
                                            if mod:
                                                mod.show_expanded=False
                                                source=obj
                                                modifiers_to_sync.append((obj,mod))
                                            self.modifiers_added.append((obj,mod))
                                            if 'ActiveProp' in b.keys():
                                                self.mod=mod
                                                self.activeProp=b['ActiveProp']
                                                self.activePropCopy=getattr(self.mod,self.activeProp)
                                                if mod.type=='BEVEL':
                                                    self.activeProp2='segments'
                                            
                                            if mod is not None and mod.type in {'WEIGHTED_NORMAL'}:
                                                obj.data.use_auto_smooth=True
                                            if mod is not None:
                                                for key, val in b.items():
                                                    if key != "ModType" and key!='ActiveProp':
                                                        if key in requiresSet:
                                                            setattr(mod, key, set(val))
                                                        else:
                                                            if key in requiresObject:
                                                                if len(bpy.context.selected_objects)>= 2 :
                                                                    if mod.type=='BOOLEAN' and preferences().auto_hide_bools:
                                                                        active.hide_view=True
                                                                        active.hide_render=True
                                                                        active.display_type='WIRE'
                                                                    if active!=obj and mod.type!='CAST':
                                                                        setattr(mod, key, active)
                                                            else:
                                                                try:
                                                                    setattr(mod, key, val)
                                                                except:
                                                                    pass
                                                            
                                        #if self.add_drivers:
                                        if len(modifiers_to_sync)>1:
                                            sync_modifiers(modifiers_to_sync,source)
                                if self.activeProp is not None:
                                    context.window_manager.modal_handler_add(self)
                                    self.add_drawHandler(context)
                                    return {'RUNNING_MODAL'}
                                if self.apply:
                                    for obj,mod in self.modifiers_added:
                                        try:
                                            bpy.ops.object.modifier_apply({'object':obj},modifier=mod.name)
                                        except:
                                            pass
                                #return {"FINISHED"}    

                            else:
                                modifiers_to_sync=[]
                                for obj in objects:
                                    self.mod = obj.modifiers.new(name=p[0], type=p[1]["ModType"])
                                    if self.mod:
                                        self.mod.show_expanded=False
                                        source=obj
                                        modifiers_to_sync.append((obj,self.mod))
                                    if self.mod.type in {'WEIGHTED_NORMAL'}:
                                                obj.data.use_auto_smooth=True
                                    mod=self.mod
                                    if 'ActiveProp' in p[1].keys():
                                        self.activeProp=p[1]['ActiveProp']
                                        self.activePropCopy=getattr(self.mod,self.activeProp)
                                        if mod.type=='BEVEL':
                                            self.activeProp2='segments'

                                    if mod is not None:
                                        for key, val in p[1].items():
                                            if key != "ModType" and key!='ActiveProp':
                                                if key in requiresSet:
                                                    setattr(mod, key, set(val))
                                                else:
                                                    if key in requiresObject:
                                                        if len(bpy.context.selected_objects)>= 2 :
                                                            if mod.type=='BOOLEAN' and preferences().auto_hide_bools:
                                                                active.hide_view=True
                                                                active.hide_render=True
                                                                active.display_type='WIRE'    
                                                            if active!=obj and mod.type!='CAST':
                                                                setattr(mod, key, active)
                                                    else:
                                                        try:
                                                            setattr(mod, key, val)
                                                        except:
                                                            pass
                                        
                                    #if self.add_drivers:
                                if len(modifiers_to_sync)>1:
                                    sync_modifiers(modifiers_to_sync,source)
                                
                                if self.activeProp is not None:
                                    context.window_manager.modal_handler_add(self)
                                    self.add_drawHandler(context)
                                    return {'RUNNING_MODAL'}
                                if self.apply:
                                    for obj,mod in self.modifiers_added:
                                        try:
                                            bpy.ops.object.modifier_apply({'object':obj},modifier=mod.name)
                                        except:
                                            pass
                            
            except Exception as e:
                print(e)
        return {'FINISHED'}
        
    def modal(self, context, event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.activePropCopy=getattr(self.mod,self.activeProp)
            self.init_x=context.region.x
        elif event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.init_x=context.region.x+context.region.width
            self.activePropCopy=getattr(self.mod,self.activeProp)
        elif self.activePropCopy is not None and event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.activePropCopy=getattr(self.mod,self.activeProp)
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=5 
        elif self.activePropCopy is not None and event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            self.activePropCopy=getattr(self.mod,self.activeProp)
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=2
            elif event.value == 'RELEASE':
                self.speed=5 
        elif self.mod is not None and self.activeProp is not None and self.activePropCopy is not None and event.type=='MOUSEMOVE':
            #print((self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else 100))
            value=self.activePropCopy-(self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else (20 *self.speed))
            global int_props
            if self.activeProp in int_props:
                value=int(value)
            setattr(self.mod,self.activeProp,value)
            self.valueString='0'
        elif self.mod is not None and self.activeProp2 is not None and (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)+1)
            return {'RUNNING_MODAL'}
        elif self.mod is not None and self.activeProp2 is not None and (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)-1)
            return {'RUNNING_MODAL'}
        elif (event.type=='LEFTMOUSE' and event.value=='PRESS')  :
            if self.apply:
                for obj,mod in self.modifiers_added:
                            bpy.ops.object.modifier_apply({'object':obj},modifier=mod.name)
            self.remove_drawHandler(context)
            return {"FINISHED"}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS') or event.type=='ESC':
            for obj,m in self.modifiers_added:
                obj.modifiers.remove(m)
            self.remove_drawHandler(context)
            return {"FINISHED"}
        elif event.type=='Z':
            if  event.value=='PRESS':
                self.activePropCopy=getattr(self.mod,self.activeProp)/2
                if self.activeProp in int_props:
                    self.activePropCopy=int(self.activePropCopy)
                setattr(self.mod,self.activeProp,self.activePropCopy)
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='Z'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='X':
            if  event.value=='PRESS':
                self.activePropCopy=2*getattr(self.mod,self.activeProp)
                if self.activeProp in int_props:
                    self.activePropCopy=int(self.activePropCopy)
                setattr(self.mod,self.activeProp,self.activePropCopy)
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='X'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type in events.keys() and event.value=='PRESS':
            if (event.type!='PERIOD' and event.type!='NUMPAD_PERIOD') or '.' not in self.valueString:
                if event.type=='NUMPAD_MINUS' or event.type=='MINUS' or event.type=='NDOF_BUTTON_MINUS':
                    value=-getattr(self.mod,self.activeProp)
                    if self.activeProp in int_props:
                        value=int(value)
                    setattr(self.mod,self.activeProp,value)
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.negate*=-1
                else:
                    self.valueString+=f"{events[event.type]}"
                    value=self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0  else eval("0")
                    if self.activeProp in int_props:
                        value=int(value)
                    setattr(self.mod,self.activeProp,value)
                    self.activePropCopy=getattr(self.mod,self.activeProp)
            return {'RUNNING_MODAL'}
        elif event.type=='BACK_SPACE' and event.value=='PRESS':
            self.valueString=self.valueString[:-1] if len(self.valueString)>1 else self.valueString

            value=self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0 else eval("0")
            if self.activeProp in int_props:
                value=int(value)
            setattr(self.mod,self.activeProp,value)
            self.activePropCopy=getattr(self.mod,self.activeProp)
        
        elif event.type=='MIDDLEMOUSE' or (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) or (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        self.valueString='0'
        self.negate=1
        self.activeKey=None
        self.add_drivers=False
        if not os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresets.txt",
                    ),
                    mode="w+",
                )
                f.close()
        if event.ctrl and event.shift:
            self.add_drivers=True
        elif event.ctrl:

            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                ),
                mode="r",
            ) as json_file:

                dataNew = []
                data = json.load(json_file)
                for p in data:
                    if p[0] != self.name:
                        dataNew.append(p)
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                ),
                mode="w+",
            ) as json_file:
                json.dump(dataNew, json_file, indent=4)

            #print("Deleting...")
            updateModPresets(False)
            return {"FINISHED"}
        elif event.alt and not self.ignore_alt:
            if not os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresetsFavorites.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresetsFavorites.txt",
                    ),
                    mode="w+",
                )
                f.close()
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresetsFavorites.txt"
                ),
                mode="r",
            ) as fav_file:
                favs=fav_file.readline()
                fav_file.close()
            if self.name.replace(" ","") not in [b.replace(" ","") for b in favs.split(',')]:
                favs=favs+","+self.name
            else:
                favorites=[a for a in favs.split(',') if a.replace(" ","")!=self.name.replace(" ","") and a.replace(" ","")!=""]

                favs=",".join(favorites)
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresetsFavorites.txt"
                ),
                mode="w",
            ) as fav_file:
                fav_file.write(favs)
                preferences().mod_presets_favorites=favs
                fav_file.close()
            return {"FINISHED"}
        self.modifiers_added=[]
        self.apply=event.shift and not self.add_drivers
        self.init_x=event.mouse_x
        self.activeProp=None
        self.activeProp2=None
        self.mod=None
        self.activePropCopy=None
        self.speed=5
        self.obj = bpy.context.active_object
        

        return self.execute(context)

class RTOOLS_OT_Load_Presets(bpy.types.Operator, ImportHelper):
    bl_idname = 'rtools.import_presets'
    bl_label = 'Load Modifier Presets'
    bl_description = "Load Modifier Presets From txt file"
    bl_options = {'PRESET', 'UNDO'}
 
    filename_ext = '.txt'
    
    filter_glob: bpy.props.StringProperty(
        default='*.txt',
        options={'HIDDEN'}
    )
 
    
    def execute(self, context):
        success=True
        path=self.filepath
        dataNew = []
        if not os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets-BackUp.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresets-BackUp.txt",
                    ),
                    mode="w+",
                )
                f.close()
        if not os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresets.txt",
                    ),
                    mode="w+",
                )
                f.close()
        else:
            try:
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"),mode="r",) as json_file:

                        
                        data = json.load(json_file)
                        for p in data:
                                dataNew.append(p)
            except:
                pass
        with open(
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets-BackUp.txt"
            ),
            mode="w+",
        ) as json_file:
            json.dump(dataNew, json_file, indent=4)
        with open(path,mode="r",) as json_file:

            try:
                data = json.load(json_file)
                for p in data:
                        dataNew.append(p)
            except:
                success=False
                self.report({'WARNING'},"Not Valid Json File!")
                pass
        
        with open(
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
            ),
            mode="w+",
        ) as json_file:
            json.dump(dataNew, json_file, indent=4)
        if success:
            self.report({'INFO'},"Presets loaded successfully!")
        return {'FINISHED'}
class RTOOLS_OT_Invoke_Modifier_Menu(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.invoke_modifier_menu"
    bl_label = "Call Modifier Presets Menu"
    bl_description = "Call Modifier Presets Menu"
    bl_options = {"UNDO"}

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        context.scene.modMenuInfo.clear()

        try:
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                ),
                mode="r",
            ) as json_file:

                data = json.load(json_file)
                for p in data:
                    item = context.scene.modMenuInfo.add()
                    item.name = p[0]
                    item.isStack = "isStack" in p[1]
                    item.type = p[1]["ModType"] if not item.isStack else ""
            bpy.ops.wm.call_menu(name="RTOOLS_MT_Mods_Menu")
        except:

            self.report({"WARNING"}, "No Presets Found")

        return {"FINISHED"}
        # return context.window_manager.invoke_popup(self)
class RTOOLS_OT_Invoke_Modifier_Favorites_Menu(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.invoke_modifier_favorites_menu"
    bl_label = "Call Favorite Modifier Presets Menu"
    bl_description = "Call Favorite Modifier Presets Menu"
    bl_options = {"UNDO"}

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        context.scene.modMenuInfo.clear()

        try:
            with open(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                ),
                mode="r",
            ) as json_file:

                data = json.load(json_file)
                for p in data:
                    #print(p[0])
                    item = context.scene.modMenuInfo.add()
                    item.name = p[0]
                    item.isStack = "isStack" in p[1]
                    item.type = p[1]["ModType"] if not item.isStack else ""
            if preferences().use_favorites_pie:
                bpy.ops.wm.call_menu_pie(name="RTOOLS_MT_Mods_Favorites_Menu")
            else:
                bpy.ops.wm.call_menu(name="RTOOLS_MT_Mods_Favorites_Menu")
        except:

            self.report({"WARNING"}, "No Presets Found")

        return {"FINISHED"}

class RTOOLS_OT_Create_Modifier_Preset_Menu(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.create_modifier_preset_menu"
    bl_label = "Create Preset"
    bl_description = "Create Modifier Preset Menu"
    bl_options = {"REGISTER", "UNDO"}
    bl_property = "name"
    name: bpy.props.StringProperty()

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        layout.label(text="Create Preset")
        column = layout.column()
        column = column.box()

        row = column.row()

        row.prop(self, "name", text="", text_ctxt="", icon="OBJECT_DATA")
        row = column.row(align=True)

        row = layout.row()
        if len(context.active_object.modifiers) > 0:
            button = column.operator(
                "rtools.create_modifier_preset", text="Complete Stack"
            )
            button.name = "FullStack"
            button.newName = self.name
        for item in context.active_object.modifiers:
            if item.type not in {
                "PARTICLE_INSTANCE",
                "PARTICLE_SYSTEM",
                "FLUID",
                "DYNAMIC_PAINT",
                "SOFT_BODY",
                "COLLISION",
                "CLOTH",'NODES'
            }:
                button = column.operator(
                    "rtools.create_modifier_preset", text=item.name
                )
                button.name = item.name
                button.newName = self.name

    def invoke(self, context, event):

        return context.window_manager.invoke_popup(self)

    def execute(self, context):

        return {"FINISHED"}


class RTOOLS_OT_Create_Modifier_Preset(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.create_modifier_preset"
    bl_label = "Create Modifer Preset"
    #bl_description = "Create Modifier Preset For This Modifier/Stack"
    bl_options = {"REGISTER", "UNDO"}
    obj = None
    name: bpy.props.StringProperty()
    newName: bpy.props.StringProperty()
    @classmethod
    def description(cls,context,properties):
        return "Create Modifier Preset For This Modifier" if properties.name!="FullStack" else "Create Modifier Preset For This Stack\n CTRL+LMB: Don't Use Active Property"
    def invoke(self, context,event):
        if self.newName != "":
            
            values = []
            if not os.path.isfile(
                os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","ModPresets.txt"
                )
            ):
                f = open(
                    os.path.join(
                        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "RanTools-Indexes","ModPresets.txt",
                    ),
                    mode="w+",
                )
                f.close()

            if self.name == "FullStack":
                net_values = []
                net_values.append(("isStack", True))
                for m in context.active_object.modifiers:
                    if m.type not in {
                        "PARTICLE_INSTANCE",
                        "PARTICLE_SYSTEM",
                        "FLUID",
                        "DYNAMIC_PAINT",
                        "SOFT_BODY",
                        "COLLISION",
                        "CLOTH",'NODES'
                    }:
                        data = []

                        values = []
                        # setattr(m,'name',f"{m.name}_{self.newName}")
                        values.append(("ModType", m.type))
                        if m.is_active and not event.ctrl:
                            if m.type=='SIMPLE_DEFROM' and (m.deform_method=='TAPER' or m.deform_method=='STRETCH'):
                                values.append(('ActiveProp','factor'))
                            else:
                                if m.type in activeProps.keys():
                                    values.append(("ActiveProp",activeProps[m.type]))
                        for key, value in inspect.getmembers(m):
                            if key == "name":
                                values.append((key, f"{m.name}"))
                            elif key in requiresObject:
                                values.append((key, "ObjectRequired"))
                            elif key not in {
                                "execution_time","is_cached",
                                "is_bound",
                                "is_bind",
                                "vertex_indices",
                                "vertex_indices_set",
                                "matrix_inverse",
                                "falloff_curve",
                                "vertex_velocities",
                                "read_velocity",
                                "has_velocity",
                                "map_curve",
                                "projectors",
                                "__doc__",
                                "__module__",
                                "__slotnames__",
                                "__slots__",
                                "bl_rna",
                                "rna_type",
                                "debug_options",
                                "type",
                                "object",
                                "delimit",
                                "custom_profile",
                                "face_count",
                                "is_external",
                                "total_levels",'is_override_data'
                            }:
                                values.append((key, copyProp(value)))

                        # print(values)

                        net_values.append((m.name, dict(values)))
                if len(net_values)>1:
                    with open(
                        os.path.join(
                            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "RanTools-Indexes","ModPresets.txt",
                        ),
                        mode="r",
                    ) as json_file:
                        
                        try:
                            data = json.load(json_file)
                            ogData=data.copy()
                            i = 1
                            name = self.newName
                            while self.newName.lower() in [j[0].lower() for j in data]:
                                self.newName = f"{name} {i}"
                                i=i+1

                            data.append((self.newName.capitalize(), dict(net_values)))
                        except:
                            ogData=""
                            data.append((self.newName.capitalize(), dict(net_values)))
                    try:
                        with open(
                            os.path.join(
                                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "RanTools-Indexes","ModPresets.txt",
                            ),
                            mode="w+",
                        ) as json_file:
                            json.dump(data, json_file, indent=4)
                    except:
                        with open(
                            os.path.join(
                                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "RanTools-Indexes","ModPresets.txt",
                            ),
                            mode="w+",
                        ) as json_file:
                            json.dump(ogData, json_file, indent=4)
                else:
                    self.report({"WARNING"}, "Can't Make Preset For These Modifiers")
            else:
                for m in context.active_object.modifiers:
                    if m.name == self.name:
                        with open(
                            os.path.join(
                                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "RanTools-Indexes","ModPresets.txt",
                            ),
                            mode="r",
                        ) as json_file:
                            data = []
                            net_values = []
                            values = []
                            # setattr(m,'name',self.newName)
                            values.append(("ModType", m.type))
                            if m.type=='SIMPLE_DEFROM' and (m.deform_method=='TAPER' or m.deform_method=='STRETCH'):
                                values.append(('ActiveProp','factor'))
                            else:
                                if m.type in activeProps.keys():
                                    values.append(("ActiveProp",activeProps[m.type]))
                            
                            for key, value in inspect.getmembers(m):
                                if key == "name":
                                    values.append((key, self.newName))
                                elif key in requiresObject:
                                    values.append((key, "ObjectRequired"))
                                elif key not in {
                                    "execution_time","is_cached",
                                    "is_bound",
                                    "is_bind",
                                    "vertex_indices",
                                    "vertex_indices_set",
                                    "matrix_inverse",
                                    "falloff_curve",
                                    "vertex_velocities",
                                    "read_velocity",
                                    "has_velocity",
                                    "map_curve",
                                    "projectors",
                                    "__doc__",
                                    "__module__",
                                    "__slotnames__",
                                    "__slots__",
                                    "bl_rna",
                                    "rna_type",
                                    "debug_options",
                                    "type",
                                    "object",
                                    "delimit",
                                    "custom_profile",
                                    "face_count",
                                    "is_external",
                                    "total_levels",'is_override_data'
                                }:
                                    values.append((key, copyProp(value)))

                            # print(values)

                            net_values.append((m.name, dict(values)))
                            try:
                                data = json.load(json_file)
                                ogData=data
                                i = 1
                                name = self.newName
                                while self.newName.lower() in [
                                    j[0].lower() for j in data
                                ]:
                                    self.newName = f"{name} {i}"
                                    i=i+1
                                data.append((self.newName.capitalize(), dict(values)))
                            except:
                                ogData=""
                                data.append((self.newName.capitalize(), dict(values)))
                        with open(
                            os.path.join(
                                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "RanTools-Indexes","ModPresets.txt",
                            ),
                            mode="w+",
                        ) as json_file:
                            try:
                                json.dump(data, json_file, indent=4)
                            except:
                                json.dump(ogData, json_file, indent=4)
        else:
            self.report({"WARNING"}, "Enter A Name For The Preset")
        context.scene.rt_tools.presetName=""
        updateModPresets(False)
        return {"FINISHED"}
array_props2={'use_axis':3,'use_bisect_axis':3,'use_bisect_flip_axis':3,'constant_offset_displace':3,'relative_offset_displace':3,'limits':2}
def do_props2(props):
    props_present=[prop for prop in array_props.keys() if prop in props]
    array=props
    for p in props_present:
        pos = array.index(p)
        array=props[:pos]
        rem_array=props[pos+1:]
        for i in range(0,array_props[p]):
            array.append(f'{p}[{i}]')  
        array = array + rem_array
        props=array
    return array
array_props={'MIRROR_use_axis':3,'MIRROR_use_bisect_axis':3,'MIRROR_use_bisect_flip_axis':3,'ARRAY_constant_offset_displace':3,'ARRAY_relative_offset_displace':3,'SIMPLE_DEFORM_limits':2,'NORMAL_EDIT_offset':3,'UV_WARP_center':2,'UV_WARP_offset':2,'UV_WARP_scale':2,'HOOK_center':2}
def do_props(props,mod_type):
    props_present=[prop for prop in [a.replace(mod_type+"_","") for a in array_props.keys()] if prop in props]
    array=props
    for p in props_present:
        pos = array.index(p)
        array=props[:pos]
        rem_array=props[pos+1:]
        for i in range(0,array_props[mod_type+"_"+p]):
            array.append(f'{p}[{i}]')  
        array = array + rem_array
        props=array
    return array
class RTOOLS_OT_Sync_Modifiers(bpy.types.Operator):
    bl_idname = "rtools.syncmodifiers"
    bl_label = "Sync Modifiers"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object and len(context.selected_objects)>1
    def execute(self,context):
        active=context.active_object
        object=Diff(context.selected_objects,[active])[0]
        for m in object.modifiers:
            if m.name in [a.name for a in active.modifiers]:
                props=[ key for key, value in inspect.getmembers(m) if key not in requiresObject and key not in {'name','is_active','vertex_group','filepath','driver','end_cap','start_cap','collection','armature','rim_vertex_group','shell_vertex_group','grid_name','execution_time',
                        "execution_time","is_cached",
                        "is_bound",
                        "is_bind",
                        "vertex_indices",
                        "vertex_indices_set",
                        "matrix_inverse",
                        "falloff_curve",
                        "vertex_velocities",
                        "read_velocity",
                        "has_velocity",
                        "map_curve",
                        "projectors",
                        "__doc__",
                        "__module__",
                        "__slotnames__",
                        "__slots__",
                        "bl_rna",
                        "rna_type",
                        "debug_options",
                        "type",
                        "object",
                        "delimit",
                        "custom_profile",
                        "face_count",
                        "is_external",
                        "total_levels",'texture','texture_coords_bone','texture_coords_object','uv_layer','auxiliary_target','origin','bone_from','bone_to','object_from','object_to','start_position_object','is_override_data'
                    }]
                
                props=do_props(props)
                #print(props)
                add_driver(props,m,active.modifiers[m.name],active)
        return {'FINISHED'}

                    