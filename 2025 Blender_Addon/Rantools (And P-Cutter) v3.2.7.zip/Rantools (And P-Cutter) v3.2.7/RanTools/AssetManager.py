import bpy
from . utils import *
from bpy.props import *
import time
import csv
import bpy.utils.previews
preview_collections = {}
preview_list = {}

def clearpcoll(self, context):
    bpy.ops.rtools.importassets(
        'INVOKE_DEFAULT', name=self.preview.replace(".png", "").lower())


def enum_previews_from_directory_items(self, context):
    enum_items = []
    name = self.name
    list = preview_list[name]
    if context is None:
        return enum_items
    directory = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs/")
    pcoll = preview_collections[name]
    if len(pcoll.my_previews) > 0:
        return pcoll.my_previews
    def_dir = directory
    if directory and os.path.exists(def_dir):
        image_paths = []
        for fn in os.listdir(def_dir):

            if fn.lower().startswith(name.lower()) and fn.replace(".png", "") in list:

                image_paths.append(fn)
        for i, name in enumerate(image_paths):
            filepath = os.path.join(def_dir, name)
            thumb = pcoll.load(filepath, filepath, 'IMAGE')
            enum_items.append(
                (name, name.replace(".png", ""), "", thumb.icon_id, i))
    pcoll.my_previews = enum_items
    return pcoll.my_previews


class AssetInfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="name", default="")
    preview: bpy.props.EnumProperty(
        items=enum_previews_from_directory_items, update=clearpcoll)

class RTOOLS_OT_Create_Asset(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.createassets"
    bl_label = "Create Asset"
    bl_description = "Add Selected Object To A Collection And Create an Asset"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty()
    """@classmethod
    def poll(cls,context):
        if bpy.data.is_saved:
            return True
        return False"""
    # @classmethod
    # def poll(cls, context):
    #    return context.mode == 'OBJECT'

    def execute(self, context):
        
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
            csvReader = csv.reader(csvFile, delimiter=',')
            column = []
            for row in csvReader:
                column.append(row[1])
        # if not os.path.isdir(os.path.join(path1,self.name)):
        #    os.mkdir(os.path.join(path1,self.name))

        # savePath=os.path.join(path1,self.name)
        i = 0
        while f"{self.name}_{i}" in column:
            i += 1
        name = f"{self.name}_{i}"
        if len(bpy.context.selected_objects) > 0:
            trackToObj=None
            empty=None
            if not self.dontParent:
                (empty, trackToObj) = duplicateAndParentToEmpty(bpy.context.selected_objects, name)
            else:
                col=get_collection(name)
                move_objects_to_collection(context.selected_objects,col)
            fpBackup = bpy.context.scene.render.filepath
            if not os.path.exists(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs")):
                os.mkdir(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs"))
            bpy.context.scene.render.filepath = os.path.join(os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs/"), name)
            captureThumbnail(
                context, trackToObj, useEevee=preferences().useEevee)
            if empty is not None and trackToObj is not None:
                delete_object(trackToObj)
                
                select(empty, active=True)
            bpy.context.scene.render.filepath = fpBackup
            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='a', newline='', encoding='utf-8') as csvFile:
                csvFileWriter = csv.writer(
                    csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
                csvFileWriter.writerow(
                    [self.name, name, os.path.join(bpy.data.filepath, f"Collection")])
        else:
            self.report({'WARNING'}, "No Objects Selected")

        """print(bpy.data.filepath)
        #bpy.ops.wm.save_mainfile(filepath=bpy.data.filepath)
        
        empty.location=[0,0,0]
        empty.rotation_euler=[0,0,0]
        
        for col in bpy.data.collections:
            if col.name!=name:
                delete_collection(col,delete_objects =True)
        colref=bpy.data.scenes['Scene'].collection
        if len(colref.objects) > 0:
            for co in colref.objects:
                print(co.name)
                delete_object(co)
        clear_unwanted_data()
        bpy.ops.wm.save_as_mainfile(filepath=os.path.join(savePath,f"{name}.blend"), copy=True)
        bpy.ops.wm.open_mainfile(filepath=bpy.data.filepath)"""

        # bpy.ops.ed.undo()
        return {'FINISHED'}

    def invoke(self, context, event):
        if not bpy.data.is_saved:
            self.report({'ERROR'}, "File Is Not Saved")
            return {'FINISHED'}
        self.dontParent=event.ctrl
        return self.execute(context)


class Import_Asset(bpy.types.Operator):
    # Add Lights
    bl_idname = "rtools.importassets"
    bl_label = "Import Asset"

    bl_options = {'REGISTER', 'UNDO'}
    lights = []
    LightsCol = None
    active = None
    i = 0
    active_obj = None
    paths = []
    lastCol = None
    lastMats = None
    name: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        nl = '\n'
        return f"Append From {properties.name}{nl}Ctrl-Delete This Library"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        if not bpy.data.filepath == os.path.dirname(self.paths[self.i][0]):
            if self.lastCol is not None:
                delete_collection(self.lastCol, delete_objects=True)
            if self.lastMats is not None:
                for m in self.lastMats:
                    bpy.data.materials.remove(bpy.data.materials.get(m))

            initCols = []
            for c in bpy.data.collections:
                initCols.append(c.name)

            initMats = []
            for c in bpy.data.materials:
                initMats.append(c.name)
            bpy.ops.wm.append(
                directory=self.paths[self.i][0],
                filename=self.paths[self.i][1], autoselect=True
            )
            newCols = []
            for c in bpy.data.collections:
                newCols.append(c.name)
            newMats = []
            for c in bpy.data.materials:
                newMats.append(c.name)
            # print(bpy.context.selected_objects)
            self.lastCol = Diff(initCols, newCols)[0]
            self.lastMats = Diff(initMats, newMats)
            obj = None
            if self.lastCol in bpy.data.objects:
                for ob in bpy.data.collections[self.lastCol].objects:
                    if ob.type == "EMPTY":
                        obj = ob
            if obj is not None:
                obj.location = self.location
                obj.rotation_euler = self.rotation

            context.area.tag_redraw()
        """else:
            self.report({'ERROR'},"Cant Import From Current File")"""
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i = (self.i+1) % len(self.paths)
            # self.currentL=self.lights[self.i]
            return self.execute(context)
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i = (self.i-1) % len(self.paths)
            # self.currentL=self.lights[self.i]
            return self.execute(context)
        elif event.type == 'LEFTMOUSE':
            self.remove_drawHandler(context)
            if self.active_obj is not None:
                delete_object(self.active_obj)
            # clear_unwanted_data()
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            self.remove_drawHandler(context)
            if self.active_obj is not None:
                self.active_obj.hide_viewport = False
            delete_collection(self.lastCol, delete_objects=True)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):

        self.location = bpy.context.active_object.location.copy(
        ) if bpy.context.active_object is not None else [0, 0, 0]
        self.rotation = bpy.context.active_object.rotation_euler.copy(
        ) if bpy.context.active_object is not None else [0, 0, 0]
        if len(bpy.context.selected_objects) > 0 and bpy.context.active_object is not None and self.name.lower() in bpy.context.active_object.name.lower():
            self.active_obj = bpy.context.active_object
            self.active_obj.hide_viewport = True

        if event.ctrl:
            data = []
            toDelete = []
            if '_' not in self.name:
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                    csvReader = csv.reader(csvFile, delimiter=',')
                    for row in csvReader:
                        if self.name.lower() != row[0].lower():
                            data.append(row)
                        else:
                            toDelete.append(row[1])
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8') as csvFile:
                    csvWriter = csv.writer(
                        csvFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                    csvWriter.writerows(data)
                for item in toDelete:

                    if os.path.isfile(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs/"), f"{item}.png")):

                        os.remove(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs/"), f"{item}.png"))
            else:
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                    csvReader = csv.reader(csvFile, delimiter=',')
                    for row in csvReader:
                        if self.name.lower() != row[1].lower():
                            data.append(row)
                        else:
                            toDelete.append(row[1])
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8') as csvFile:
                    csvWriter = csv.writer(
                        csvFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                    csvWriter.writerows(data)
                for item in toDelete:

                    if os.path.isfile(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Thumbs/"), f"{item}.png")):

                        os.remove(os.path.join(os.path.join(os.path.dirname(
                            os.path.abspath(__file__)), "RanTools-Thumbs/"), f"{item}.png"))
            bpy.ops.rtools.refresh_asset('EXEC_DEFAULT')
            return {'FINISHED'}
        else:
            self.paths = []
            rows = []
            with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
                csvReader = csv.reader(csvFile, delimiter=',')

                for row in csvReader:
                            if self.name.lower() in row[1].lower():
                                rows.append(row)
                if '_' not in self.name:
                    
                    for path in set([row[2] for row in rows]):
                        if os.path.isfile(os.path.dirname(path)):
                            with bpy.data.libraries.load(os.path.dirname(path)) as (data_from, _):
                                for row in colsfromblend(path, rows):
                                    if row[1].lower() in [x.lower() for x in data_from.collections]:
                                        self.paths.append((row[2], row[1]))

                    """if self.name.lower() in row[1].lower():
                        if os.path.isfile(str(row[2]).replace("\Collection","")):
                            with bpy.data.libraries.load(str(row[2]).replace("\Collection","")) as (data_from, _):
                            
                                if row[1].lower() in [x.lower() for x in data_from.collections]:
                                        self.paths.append((row[2],row[1]))"""

                else:
                    for path in set([row[2] for row in rows]):
                        #print(path)
                        if os.path.isfile(os.path.dirname(path)):
                            with bpy.data.libraries.load(os.path.dirname(path)) as (data_from, _):
                                for row in colsfromblend(path, rows):
                                    if row[1].lower() in [x.lower() for x in data_from.collections]:
                                        self.paths.append((row[2], row[1]))

            self.lastCol = None
            self.lastMats = None
            self.i = 0
            self.activeBackUp = bpy.context.active_object
            if len(self.paths) == 0:
                self.report({'WARNING'}, "No Longer Available")
                return {'FINISHED'}

            if len(self.paths) == 1:
                if not bpy.data.filepath == os.path.dirname(self.paths[0][0]):
                    initCols = []
                    for c in bpy.data.collections:
                        initCols.append(c.name)

                    bpy.ops.wm.append(
                        directory=self.paths[self.i][0],
                        filename=self.paths[self.i][1], autoselect=True
                    )
                    newCols = []
                    for c in bpy.data.collections:
                        newCols.append(c.name)

                    # print(bpy.context.selected_objects)
                    self.lastCol = Diff(initCols, newCols)[0]
                    obj = None
                    if self.lastCol in bpy.data.objects:
                        for ob in bpy.data.collections[self.lastCol].objects:
                            if ob.type == "EMPTY":
                                obj = ob
                    if obj is not None:
                        obj.location = self.location
                        obj.rotation_euler = self.rotation
                else:
                    self.report({'WARNING'}, "Cannot Append From Current File")
                return {'FINISHED'}
            self.execute(context)
            context.window_manager.modal_handler_add(self)
            self.add_drawHandler(context)
            return{'RUNNING_MODAL'}

    def add_drawHandler(self, context):
        self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_px, (context,), "WINDOW", "POST_PIXEL")

    def remove_drawHandler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, "WINDOW")

    def draw_callback_px(self, context):
        draw_Text(context,0,preferences().font_size, text=[f"{self.name} : {self.lastCol}"])


class RTOOLS_OT_Create_Asset_Panel(bpy.types.Operator):
    bl_idname = "rtools.create_asset"
    bl_label = "Create Assets Panel"
    bl_description = "Create Assets Panel"
    bl_options = {'REGISTER', 'UNDO'}
    # bl_property="name"

    name: bpy.props.StringProperty(
        name="Append Object",
        description="Used to Append file matching this Name",
        default="New",
        update=AssetNameUpdated
    )
    # @classmethod
    # def poll(cls, context):
    #    return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout

        layout.label(text="Create Asset")
        column = layout.column()

        row = column.row()

        row.prop(self, "name", text="", text_ctxt="", icon='OBJECT_DATA')
        for item in context.scene.rt_assets:
            row = column.row()
            button = row.operator("rtools.createassets", text=item.name)
            button.name = item.name
        #RT_PT_Append_Panel.draw(self, context)

    def invoke(self, context, event):
        if not bpy.data.is_saved:
            self.report({'WARNING'}, "File Is Not Saved")
            return {'FINISHED'}
        context.scene.rt_assets.clear()
        Libs = []
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
            csvReader = csv.reader(csvFile, delimiter=',')
            for row in csvReader:
                Libs.append(row[0])

        for lib in set(Libs):
            temp = context.scene.rt_assets.add()
            temp.name = lib

        return context.window_manager.invoke_popup(self)

    def execute(self, context):

        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}


def colsfromblend(path, csvFile):
    cols = []
    for row in csvFile:
        if row[2] == path:
            cols.append(row)
    return cols


class Import_Asset_Panel(bpy.types.Operator):
    bl_idname = "rtools.import_asset"
    bl_label = "Import Assets Panel"
    bl_description = "Import Assets Panel"
    bl_options = {'REGISTER', 'UNDO'}
    # bl_property="name"
    # bl_property="name"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'
    name: bpy.props.StringProperty(
        name="Search Assets",
        description="Search Assets",
        default="Search",
    )

    def draw(self, context):
        count = 0
        for item in context.scene.rt_assets:
            if self.name.lower() in item.name.lower() or self.name == "Search" or self.name == "":
                count = count+1
        layout = self.layout
        layout.ui_units_x = 5*min(count, 5)
        layout.label(text="Import Asset")
        column = layout.column()
        row = layout.row()
        row = row.split(factor=0.8) if count == 1 else row.split(factor=0.95)
        row.prop(self, "name", text="", text_ctxt="", icon='VIEWZOOM')
        row.operator("rtools.refresh_asset", text="", icon="FILE_REFRESH")
        column = layout.grid_flow(row_major=True, columns=5)
        if len(preview_list) > 0:
            for item in context.scene.rt_assets:

                # column2=column.column()P
                if self.name.lower() in item.name.lower() or self.name == "Search" or self.name == "":
                    column2 = column.box()
                    column2.template_icon_view(
                        item, "preview", show_labels=True, scale=5, scale_popup=6)
                    button = column2.operator(
                        "rtools.importassets", text=item.name)
                    button.name = item.name

    def invoke(self, context, event):

        Libs = []
        paths = []
        rows = []
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()

        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
            csvReader = csv.reader(csvFile, delimiter=',')
            for row in csvReader:
                rows.append(row)
            #print(set([row[2] for row in csvReader]))
            if len(preview_collections) == 0:

                for path in set([row[2] for row in rows]):
                    if os.path.isfile(os.path.dirname(path)):
                        with bpy.data.libraries.load(os.path.dirname(path)) as (data_from, _):
                            for row in colsfromblend(path, rows):
                                if row[1].lower() in [x.lower() for x in data_from.collections]:
                                    #print(row[1])
                                    #print(row[0])
                                    paths.append(row[1])
                                    Libs.append(row[0])
            else:
                # for path in set([row[2] for row in rows]):

                for row in rows:
                    # with bpy.data.libraries.load(str(path).replace("\Collection","")) as (data_from, _):
                    #    for row in colsfromblend(path,rows):
                    #       if row[1].lower() in [x.lower() for x in data_from.collections]:
                    # paths.append(row[1])
                    Libs.append(row[0])
        """
        for pcoll in preview_collections.values():
                bpy.utils.previews.remove(pcoll)
        preview_collections.clear()
        preview_list.clear()"""
        if len(preview_collections) == 0:
            context.scene.rt_assets.clear()
            for lib in set(Libs):
                temp = context.scene.rt_assets.add()
                temp.name = lib
                preview_list[lib] = paths
                pcoll = bpy.utils.previews.new()
                pcoll.my_previews = ()
                preview_collections[lib] = pcoll
        if len(bpy.context.selected_objects) > 0 and bpy.context.active_object is not None:
            activeName = bpy.context.active_object.name
            if activeName.lower() in [x.lower() for x in Libs]:
                return bpy.ops.rtools.importassets('INVOKE_DEFAULT', name=activeName.lower())
            elif ('.' in activeName and activeName[:activeName.index('.')].lower() in [x.lower() for x in Libs]):
                return bpy.ops.rtools.importassets('INVOKE_DEFAULT', name=bpy.context.active_object.name[:bpy.context.active_object.name.index('.')].lower())

        return context.window_manager.invoke_popup(self)

    def execute(self, context):

        return {'FINISHED'}


class RTOOLS_OT_Refresh_Asset_Panel(bpy.types.Operator):
    bl_idname = "rtools.refresh_asset"
    bl_label = "Refresh Thumbnails"
    bl_description = "Refresh Thumbnails"
    bl_options = {'REGISTER', 'UNDO'}

    # bl_property="name"

    def execute(self, context):
        context.scene.rt_assets.clear()
        Libs = []
        paths = []
        rows = []
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt")):
            f = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                  "RanTools-Indexes","AssetIndexes.txt"), mode='w+', newline='', encoding='utf-8')
            f.close()
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes","AssetIndexes.txt"), mode='r', newline='', encoding='utf-8') as csvFile:
            csvReader = csv.reader(csvFile, delimiter=',')
            for row in csvReader:
                rows.append(row)
            #print(set([row[2] for row in csvReader]))
            for path in set([row[2] for row in rows]):
                # for row in rows:
                if os.path.isfile(os.path.dirname(path)):
                    with bpy.data.libraries.load(os.path.dirname(path)) as (data_from, _):
                        for row in colsfromblend(path, rows):
                            #print([x.lower() for x in data_from.collections])
                            if row[1].lower() in [x.lower() for x in data_from.collections]:
                                #print(row)
                                paths.append(row[1])
                                Libs.append(row[0])
        for pcoll in preview_collections.values():
            bpy.utils.previews.remove(pcoll)
        preview_collections.clear()
        preview_list.clear()

        for lib in set(Libs):
            temp = bpy.context.scene.rt_assets.add()
            temp.name = lib
            preview_list[lib] = paths
            pcoll = bpy.utils.previews.new()
            pcoll.my_previews = ()
            preview_collections[lib] = pcoll

        return {'FINISHED'}
