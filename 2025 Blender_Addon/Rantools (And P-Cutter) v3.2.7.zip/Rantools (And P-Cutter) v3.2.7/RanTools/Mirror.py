
from . utils import * 
import bpy
import statistics
import math
import bmesh
import statistics
from bpy_extras import view3d_utils
def swap(x,y):
    t=x
    x=y
    y=t
    return x,y
def findFlipAxis(obj,axis,mod):
    selected_objects=bpy.context.selected_objects
    active_object=bpy.context.active_object
    #
    dup=obj
    hiddenModifiers=[]
    
    ogType=dup.type
    if dup.type == 'CURVE':
        return (False,False,False)
    #apply_all_modifiers(dup,'BOOLEAN')
    for m in dup.modifiers:
                if m.type=='BEVEL':
                    if m.segments>1:
                        if m.show_viewport:
                            hiddenModifiers.append(m)
                        m.show_viewport=False
                        #try:
                        #    bpy.ops.object.modifier_apply({'object':dup},modifier=m.name)
                        #except:
                        #    pass
                else:
                    if m.name==mod.name:
                        if m.show_viewport:
                            hiddenModifiers.append(m)
                        m.show_viewport=False
                        
                        #try:
                        #    bpy.ops.object.modifier_apply({'object':dup},modifier=m.name)
                        #except:
                        #    pass
    #apply_all_modifiers(dup,'BEVEL',exc=mod)
    mesh = dup.evaluated_get(bpy.context.evaluated_depsgraph_get()).data  # Get selected object's mesh
    #mean_x=sum([v.co[0] for v in mesh.vertices])/len(mesh.vertices)
    #mean_y=sum([v.co[1] for v in mesh.vertices])/len(mesh.vertices)
    #mean_z=sum([v.co[2] for v in mesh.vertices])/len(mesh.vertices)
    #location=Vector((mean_x,mean_y,mean_z))
    vertexSideA=0
    vertexSideB=0
    #bpy.ops.object.select_all(action='DESELECT')
    #select(dup)
    #bpy.ops.object.mode_set(mode='EDIT')
    bm=bmesh.new()
    bm.from_mesh(mesh)
    density=10
    area = sum([f.calc_area() for f in bm.faces])
    #distancesA=[]
    #distancesB=[]
    for v in bm.verts:
        if v.co[axis]<0:
            #distancesA.append(abs(v.co[axis]))
            vertexSideA=vertexSideA+1
        
        elif v.co[axis]>0:
            #distancesB.append(abs(v.co[axis]))
            vertexSideB=vertexSideB+1
    for m in hiddenModifiers:
        m.show_viewport=True
    #print(statistics.mean(distancesA),statistics.mean(distancesB))
    if area!=0:
        density=len(bm.verts)/area
    #print(density)
    #print(abs(vertexSideA-vertexSideB))
    is_highpoly=density>30 #and abs(vertexSideA-vertexSideB)<(vertexSideB+vertexSideA)/2
    #print(is_highpoly)
    #is_highpoly=False
    #print(f"-ve: {vertexSideA} , +ve: {vertexSideB}")
    #bpy.ops.object.mode_set(mode='OBJECT')
    #delete_object(dup)
    select(obj,active=True)
    #if statistics.mean(distancesA)>statistics.mean(distancesB):
    #    vertexSideB=1
    #    vertexSideA=0
    #else:
    #    vertexSideB=0
    #    vertexSideA=1
    if ogType=='CURVE':
        vertexSideA,vertexSideB= swap(vertexSideA,vertexSideB)
    if vertexSideA==vertexSideB:
        return (False,False,False)
    elif vertexSideA<vertexSideB and axis==0:
        if is_highpoly:
            return (True,False,False)
        return (False,False,False)
    elif vertexSideA<vertexSideB and axis==1:
        if is_highpoly:
            return (False,True,False)
        return (False,False,False)
    elif vertexSideA<vertexSideB and axis==2:
        if is_highpoly:
            return (False,False,True)
        return (False,False,False)
    elif vertexSideA>vertexSideB and axis==0:
        if is_highpoly:
            return (False,False,False)
        return (True,False,False)
    elif vertexSideA>vertexSideB and axis==1:
        if is_highpoly:
            return (False,False,False)
        return (False,True,False)
    elif vertexSideA>vertexSideB and axis==2:
        if is_highpoly:
            return (False,False,False)
        return (False,False,True)
def copyProp(prop):
    toReturn = [value for value in prop]
    #print(toReturn)
    return[value for value in prop]
class RTOOLS_OT_Quick_Mirror(bpy.types.Operator):
    # Quick Decimate
    bl_idname = "rtools.quick_mirror"
    bl_label = "Mirror"
    bl_description = "Mirror around active object"
    bl_options = {'REGISTER', 'UNDO'}
    obj=None
    first=True
    addNew:bpy.props.BoolProperty(default=False,options={'HIDDEN'})
    initX:bpy.props.FloatProperty(options={'HIDDEN'})
    active_object=None
    objInitialLoc=None
    objMove=None
    EmptyRotate=None
    Bisecting=None
    Flipping=None
    base=0.1
    speed=10
    mod=None
    gizmo=None
    constraintAxis="Z"
    initAxis=None
    backupMod=None
    selected_count:bpy.props.IntProperty(options={'HIDDEN'})
    @classmethod
    def poll(cls, context):
        if context.active_object is not None and len(bpy.context.selected_objects) in range(1,3):
            return True or context.active_object.mode == 'OBJECT'
        else:
            return False
    def execute(self, context):
        selected_objects=bpy.context.selected_objects
        
        
        if len(selected_objects) == 2:
            selected_objects.remove(bpy.context.active_object)        
        self.obj=selected_objects[0]
        self.mirror_object=context.active_object
        mirror_object=self.mirror_object
        isNew=False
        mirror_mods=[m for m in self.obj.modifiers if m.type == 'MIRROR']
        if len(mirror_mods)>0 and 'RT_Mirror' in mirror_mods[len(mirror_mods)-1].name and not self.addNew and context.mode=='OBJECT':
            
            self.mod=mirror_mods[len(mirror_mods)-1]
            if self.mod.mirror_object is not None: 
                self.selected_count=2
                select(self.mod.mirror_object,active=True)
            #print(f"{self.mod.use_axis[0]}{self.mod.use_axis[1]}{self.mod.use_axis[2]}")
            #print(self.mod.use_bisect_axis)
            self.backupMod.append(copyProp(self.mod.use_axis))
            self.backupMod.append(copyProp(self.mod.use_bisect_axis))
            self.backupMod.append(copyProp(self.mod.use_bisect_flip_axis))
            self.backupMod.append(self.mod.mirror_object)
            
        else:
            self.addNew=False
            self.mod=self.obj.modifiers.new(name='RT_Mirror',type='MIRROR')
            if context.mode=='EDIT_MESH':
                bpy.ops.object.modifier_move_to_index(modifier=self.mod.name, index=0)
                self.mod.show_on_cage=True
            self.backupMod=None
            isNew=True
        
        if self.selected_count!=1:
            #mirrorAxis=findMirrorAxis(self.obj,bpy.context.active_object)
            mirrorAxis=self.initAxis
            if not isNew:
                self.mod.use_axis=(self.mod.use_axis[0] or mirrorAxis[0],self.mod.use_axis[1] or mirrorAxis[1],self.mod.use_axis[2] or mirrorAxis[2]) 
                self.mod.use_bisect_axis=self.mod.use_axis
            else:
                self.mod.use_axis=mirrorAxis
                #self.mod.use_bisect_axis=self.mod.use_axis
        else:
            if not isNew:
                self.mod.use_axis=(self.initAxis[0] or self.mod.use_axis[0],self.initAxis[1] or self.mod.use_axis[1],self.initAxis[2] or self.mod.use_axis[2]) 
                self.mod.use_bisect_axis=(self.initAxis[0] or self.mod.use_bisect_axis[0],self.initAxis[1] or self.mod.use_bisect_axis[1],self.initAxis[2] or self.mod.use_bisect_axis[2])
            else:
                self.mod.use_axis=self.initAxis
                self.mod.use_bisect_axis=self.initAxis
        
                
        x=0
        if self.initAxis[1]:
            x=1
        elif self.initAxis[2]:
            x=2
        #if findMirrorAxis(self.obj,bpy.context.active_object)==(False,False,True):
        #    x=2
        if self.selected_count==1:
            flipAxis=findFlipAxis(self.obj,x,self.mod)
            if not isNew:
                self.mod.use_bisect_flip_axis=(flipAxis[0] or self.mod.use_bisect_flip_axis[0],flipAxis[1] or self.mod.use_bisect_flip_axis[1],flipAxis[2] or self.mod.use_bisect_flip_axis[2])    
            else:
                self.mod.use_bisect_flip_axis=flipAxis
        
        if self.selected_count>1:
            #print(mirror_object,context.active_object)
            if mirror_object!=self.obj:
                self.mod.mirror_object=mirror_object
        self.mod.use_clip=True
                
        return {'FINISHED'}
    def modal(self, context,event):
        
        if event.type == 'LEFT_CTRL':
            
            if event.value == 'PRESS':
                self.base=15
            elif event.value == 'RELEASE':
                self.base=0.1    
            context.area.tag_redraw()
        if event.type == 'LEFT_SHIFT':
            self.initX=event.mouse_x
            self.emptyRotationCopy=self.mirror_object.rotation_euler.copy()
            self.objLocationCopy=self.obj.location.copy()
            if event.value == 'PRESS':
                self.speed=100
            elif event.value == 'RELEASE':
                self.speed=10    
            context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            if self.objMove==True:
                if self.constraintAxis=="X":
                    self.obj.location[0]=self.objLocationCopy[0]+(self.initX-event.mouse_x)/(self.speed*10)
                
                if self.constraintAxis=="Y":
                    self.obj.location[1]=self.objLocationCopy[1]+(self.initX-event.mouse_x)/(self.speed*10)
                if self.constraintAxis=="Z":
                    self.obj.location[2]=self.objLocationCopy[2]+(self.initX-event.mouse_x)/(self.speed*10)
            if self.EmptyRotate==True:
                if self.constraintAxis=="X":
                    self.mirror_object.rotation_euler[0]=math.radians(myround(eulerToDegreeS(self.emptyRotationCopy[0])+(self.initX-event.mouse_x)/self.speed,base=self.base))
                
                if self.constraintAxis=="Y":
                    self.mirror_object.rotation_euler[1]=math.radians(myround(eulerToDegreeS(self.emptyRotationCopy[1])+(self.initX-event.mouse_x)/self.speed,base=self.base))
                if self.constraintAxis=="Z":
                    
                    self.mirror_object.rotation_euler[2]=math.radians(myround(eulerToDegreeS(self.emptyRotationCopy[2])+(self.initX-event.mouse_x)/self.speed,base=self.base))
        
            context.area.tag_redraw()
            
        elif event.type == 'X' and event.value=="PRESS":
            if self.Bisecting:
                self.mod.use_bisect_axis[0]=not self.mod.use_bisect_axis[0]
            #elif self.Flipping:
            elif event.alt:
                self.mod.use_bisect_flip_axis[0]=not self.mod.use_bisect_flip_axis[0]
            elif event.shift:
                self.mod.use_bisect_axis[0]=not self.mod.use_bisect_axis[0]
            elif self.objMove or self.EmptyRotate:
                self.constraintAxis="X"
                self.objInitialLoc=self.obj.location.copy()
                self.initX=event.mouse_x
            else:
                self.mod.use_axis[0]=not self.mod.use_axis[0]
                
                if self.selected_count==1:
                    self.mod.use_bisect_axis[0]=not self.mod.use_bisect_axis[0]
                    self.mod.use_bisect_flip_axis[0]=findFlipAxis(self.obj,0,self.mod)[0]
            if not event.shift and not event.alt and not event.ctrl and not self.Bisecting and not self.Flipping and not self.objMove and not self.EmptyRotate:
                
                self.mod.use_axis[1]=False
                self.mod.use_bisect_axis[1]=False
                self.mod.use_bisect_flip_axis[1]=False
                self.mod.use_axis[2]=False
                self.mod.use_bisect_axis[2]=False
                self.mod.use_bisect_flip_axis[2]=False
            context.area.tag_redraw()
        elif event.type == 'Y' and event.value=="PRESS":
            if self.Bisecting:
                self.mod.use_bisect_axis[1]=not self.mod.use_bisect_axis[1]
            #elif self.Flipping:
            elif event.alt:
                self.mod.use_bisect_flip_axis[1]=not self.mod.use_bisect_flip_axis[1]
            elif event.shift:
                self.mod.use_bisect_axis[1]=not self.mod.use_bisect_axis[1]
            elif self.objMove or self.EmptyRotate:
                self.constraintAxis="Y"
                self.objInitialLoc=self.obj.location.copy()
                self.initX=event.mouse_x
            else:
                self.mod.use_axis[1]=not self.mod.use_axis[1]
                
                if self.selected_count==1:
                    self.mod.use_bisect_axis[1]=not self.mod.use_bisect_axis[1]
                    self.mod.use_bisect_flip_axis[1]=findFlipAxis(self.obj,1,self.mod)[1]
            if not event.shift and not event.alt and not event.ctrl and not self.Bisecting and not self.Flipping and not self.objMove and not self.EmptyRotate:
                
                self.mod.use_axis[0]=False
                self.mod.use_bisect_axis[0]=False
                self.mod.use_bisect_flip_axis[0]=False
                self.mod.use_axis[2]=False
                self.mod.use_bisect_axis[2]=False
                self.mod.use_bisect_flip_axis[2]=False
            context.area.tag_redraw()
        elif event.type == 'Z' and event.value=="PRESS":
            if self.Bisecting:
                self.mod.use_bisect_axis[2]=not self.mod.use_bisect_axis[2]
            #elif self.Flipping:
            elif event.alt:
                self.mod.use_bisect_flip_axis[2]=not self.mod.use_bisect_flip_axis[2]
            elif event.shift:
                self.mod.use_bisect_axis[2]=not self.mod.use_bisect_axis[2]
            elif self.objMove or self.EmptyRotate:
                self.constraintAxis="Z"
                self.objInitialLoc=self.obj.location.copy()
                self.initX=event.mouse_x
            else:
                self.mod.use_axis[2]=not self.mod.use_axis[2]
                if self.selected_count==1:
                    self.mod.use_bisect_axis[2]=not self.mod.use_bisect_axis[2]
                    self.mod.use_bisect_flip_axis[2]=findFlipAxis(self.obj,2,self.mod)[2]
            if not event.shift and not event.alt and  not event.ctrl and not self.Bisecting and not self.Flipping and not self.objMove and not self.EmptyRotate:
                
                self.mod.use_axis[1]=False
                self.mod.use_bisect_axis[1]=False
                self.mod.use_bisect_flip_axis[1]=False
                self.mod.use_axis[0]=False
                self.mod.use_bisect_axis[0]=False
                self.mod.use_bisect_flip_axis[0]=False
            context.area.tag_redraw()
        elif event.type == 'R' and event.value=="PRESS":
            self.constraintAxis="Z"
            self.EmptyRotate = not self.EmptyRotate
            self.objMove=False
            self.initX=event.mouse_x
            context.area.tag_redraw()
        elif event.type == 'G' and event.value=="PRESS":
            self.emptyRotationCopy=bpy.context.active_object.rotation_euler.copy()
            self.constraintAxis=findConstraintAxis(self.mod)
            self.EmptyRotate = False
            self.objMove=not self.objMove
            self.initX=event.mouse_x
            context.area.tag_redraw()
        #elif event.type == 'B' and event.value=="PRESS":
        #    self.Bisecting=not self.Bisecting
        #    self.Flipping=False
        #    self.EmptyRotate = False
        #    self.objMove=False
        #    self.emptyRotationCopy=bpy.context.active_object.rotation_euler.copy()
        #    #self.mod.use_bisect_axis=(True,False,False)
        #    self.initX=event.mouse_x
        #    context.area.tag_redraw()
        #elif event.type == 'F' and event.value=="PRESS":
        #    self.Bisecting=False
        #    self.Flipping=not self.Flipping
        #    self.EmptyRotate = False
        #    self.objMove=False
        #    self.emptyRotationCopy=bpy.context.active_object.rotation_euler.copy()
            #self.mod.use_bisect_flip_axis=(True,False,False)
        #    self.initX=event.mouse_x
        #    context.area.tag_redraw()
            
        
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            #delete_object(self.gizmo)
            if context.mode=='EDIT_MESH':
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.modifier_apply(modifier=self.mod.name)
                bpy.ops.object.editmode_toggle()
            select(self.obj,active=True)
            if self.selected_count==2:
                select(self.activeBackUp,active=True)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
            sort_modifiers(self.obj)
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC':
            #delete_object(self.gizmo)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
            self.obj.location=self.objInitialLoc
            bpy.context.active_object.rotation_euler=self.EmptyInitialRot
            if self.backupMod is None:
                self.obj.modifiers.remove(self.mod)
            else:
                self.mod.use_axis=self.backupMod[0]
                self.mod.use_bisect_axis=self.backupMod[1]
                self.mod.use_bisect_flip_axis=self.backupMod[2]
            select(self.obj,active=True)
            if self.selected_count==2:
                select(self.activeBackUp,active=True)
            return {'CANCELLED'}
        elif event.type == 'E' and event.value=="PRESS" and context.mode=='OBJECT':
            if self.selected_count==1:
                if event.alt:
                    meanX=statistics.mean([(self.obj.matrix_world @ v.co).x for v in self.obj.data.vertices]) if self.obj.type=="MESH" else self.obj.location[0]
                    meanY=statistics.mean([(self.obj.matrix_world @ v.co).y for v in self.obj.data.vertices]) if self.obj.type=="MESH" else self.obj.location[1]
                    meanZ=statistics.mean([(self.obj.matrix_world @ v.co).z for v in self.obj.data.vertices]) if self.obj.type=="MESH" else self.obj.location[2]
                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(meanX,meanY,meanZ), scale=(10, 10, 10))
                    new_empty=context.active_object
                else:
                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=self.objInitialLoc, scale=(10, 10, 10))
                    new_empty=context.active_object
                
                select(self.obj)
                select(new_empty)
                #delete_object(self.gizmo)
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
                self.obj.modifiers.remove(self.mod)
                bpy.ops.rtools.quick_mirror('INVOKE_DEFAULT')

                return {'FINISHED'}
        elif event.type == 'A' and event.value=="PRESS":
            #delete_object(self.gizmo)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
            self.obj.location=self.objInitialLoc
            bpy.context.active_object.rotation_euler=self.EmptyInitialRot
            if self.backupMod is None:
                self.obj.modifiers.remove(self.mod)
            else:
                self.mod.use_axis=self.backupMod[0]
                self.mod.use_bisect_axis=self.backupMod[1]
                self.mod.use_bisect_flip_axis=self.backupMod[2]
                self.mod.mirror_object=self.backupMod[3]
            deselect_all()
            select(self.obj,active=True)
            if self.selected_count==2:
                select(self.activeBackUp,active=True)
            bpy.ops.rtools.quick_mirror('INVOKE_DEFAULT',addNew=True)
            return {'FINISHED'}
        elif event.type =='MIDDLEMOUSE':
            return{'PASS_THROUGH'}
        return {'RUNNING_MODAL'}   
    def invoke(self, context,event):
        self.initAxis=(True,False,False)
        viewRot=eulerToDegree(bpy.context.region_data.view_matrix.transposed().to_euler())
        obj_vector_x=context.active_object.rotation_euler.to_matrix()@Vector((1,0,0))
        obj_vector_z=context.active_object.rotation_euler.to_matrix()@Vector((0,0,1))
        obj_vector_y=context.active_object.rotation_euler.to_matrix()@Vector((0,1,0))
        #print(obj_vector)
        direction=bpy.context.region_data.view_matrix.transposed().to_euler().to_matrix()@Vector((0,0,1))
        #angle_x=math.degrees(direction.angle(obj_vector_x))
        #angle_y=math.degrees(direction.angle(obj_vector_y))
        #angle_z=math.degrees(direction.angle(obj_vector_z))
        #if angle_x>135:
        #        angle_x=180-angle_x
        #if angle_y>135:
        #        angle_y=180-angle_y
        #if angle_z>135:
        #    angle_z=180-angle_z
        if abs(direction.y)>max(abs(direction.x),abs(direction.z)):
            object_angle_z=math.degrees(Vector((1,0,0)).angle(obj_vector_z))
            object_angle_x=math.degrees(Vector((1,0,0)).angle(obj_vector_x))
            object_angle_y=math.degrees(Vector((1,0,0)).angle(obj_vector_y))
            if object_angle_x>135:
                object_angle_x=180-object_angle_x
            if object_angle_z>135:
                object_angle_z=180-object_angle_z
            if object_angle_y>135:
                object_angle_y=180-object_angle_y
            if object_angle_x<min(object_angle_z,object_angle_y):
                self.initAxis=(True,False,False)
            elif object_angle_z<min(object_angle_x,object_angle_y):
                self.initAxis=(False,False,True)
            elif object_angle_y<min(object_angle_x,object_angle_z):
                self.initAxis=(False,True,False)
        elif abs(direction.x)>max(abs(direction.z),abs(direction.y)):
            object_angle_z=math.degrees(Vector((0,1,0)).angle(obj_vector_z))
            object_angle_x=math.degrees(Vector((0,1,0)).angle(obj_vector_x))
            object_angle_y=math.degrees(Vector((0,1,0)).angle(obj_vector_y))
            if object_angle_x>135:
                object_angle_x=180-object_angle_x
            if object_angle_z>135:
                object_angle_z=180-object_angle_z
            if object_angle_y>135:
                object_angle_y=180-object_angle_y
            if object_angle_x<min(object_angle_z,object_angle_y):
                self.initAxis=(True,False,False)
            elif object_angle_z<min(object_angle_x,object_angle_y):
                self.initAxis=(False,False,True)
            elif object_angle_y<min(object_angle_x,object_angle_z):
                self.initAxis=(False,True,False)
        else:
            object_angle_z=math.degrees(Vector((0,0,1)).angle(obj_vector_z))
            object_angle_x=math.degrees(Vector((0,0,1)).angle(obj_vector_x))
            object_angle_y=math.degrees(Vector((0,0,1)).angle(obj_vector_y))
            if object_angle_x>135:
                object_angle_x=180-object_angle_x
            if object_angle_z>135:
                object_angle_z=180-object_angle_z
            if object_angle_y>135:
                object_angle_y=180-object_angle_y
            if object_angle_x<min(object_angle_z,object_angle_y):
                self.initAxis=(True,False,False)
            elif object_angle_z<min(object_angle_x,object_angle_y):
                self.initAxis=(False,False,True)
            elif object_angle_y<min(object_angle_x,object_angle_z):
                self.initAxis=(False,True,False)
        #print(angle)
        #if angle>45 and angle<135:
        #    self.initAxis=(True,False,False)
        #elif angle<=45 or angle>=135:
        #    self.initAxis=(False,True,False)
        #print(direction)
        #self.initAxis=(abs(direction.y)>max(abs(direction.x),abs(direction.z)),abs(direction.x)>max(abs(direction.z),abs(direction.y)),abs(direction.z)-0.1>max(abs(direction.x),abs(direction.y)))
        #if abs(direction.z)>max(abs(direction.x),abs(direction.y)):
        #    self.initAxis=(False,False,True)
        #elif (viewRot[2]<45 and viewRot[2]>-45) or (viewRot[2]>145 and viewRot[2]<180) or (viewRot[2]<-145 and viewRot[2]>-180):
        #    self.initAxis=(True,False,False)
        #else:
        #    self.initAxis=(False,True,False)
        self.objMove=False
        self.EmptyRotate=False
        self.Bisecting=False
        self.Flipping=False
        self.backupMod=[]
        selected_objects=bpy.context.selected_objects
        self.selected_count=len(selected_objects)
        if len(selected_objects) == 2:
            selected_objects.remove(bpy.context.active_object)        
        self.obj=selected_objects[0]
        #print(self.selected_count)

        self.objInitialLoc=self.obj.location.copy()
        self.objLocationCopy=self.obj.location.copy()
        self.EmptyInitialRot=bpy.context.active_object.rotation_euler.copy()
        self.emptyRotationCopy=self.EmptyInitialRot.copy()
        self.initX=event.mouse_x 
        self.mod=None
        self.execute(context)
        self.activeBackUp=bpy.context.active_object
        #if context.mode=='EDIT_MESH':
        #    bpy.ops.object.editmode_toggle()
        #    bpy.ops.object.empty_add(type='ARROWS', align='WORLD', location=bpy.context.active_object.location, scale=(50, 50, 50))
        #    select(self.obj)
        #    bpy.ops.object.editmode_toggle()
        #else:
        #    bpy.ops.object.empty_add(type='ARROWS', align='WORLD', location=bpy.context.active_object.location, scale=(50, 50, 50))
        #self.gizmo=bpy.context.active_object
        #self.gizmo.scale=(3,3,3)
        #self.gizmo.show_in_front=True
        self.speed=10
        #deselect(self.gizmo)
        bpy.context.view_layer.objects.active=self.activeBackUp
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return{'RUNNING_MODAL'} 

    def draw_callback_px(self,context):
        Axis="Mirror Axis (X/Y/Z): "+("X-Axis " if self.mod.use_axis[0] else "")+("Y-Axis " if self.mod.use_axis[1] else "")+("Z-Axis" if self.mod.use_axis[2] else "")
        Bisect="Bisect (SHIFT + X/Y/Z): "+("X-Axis " if self.mod.use_bisect_axis[0] else "")+("Y-Axis " if self.mod.use_bisect_axis[1] else "")+("Z-Axis" if self.mod.use_bisect_axis[2] else "")
        Flip="Flip (ALT + X/Y/Z): "+("X-Axis " if self.mod.use_bisect_flip_axis[0] else "")+("Y-Axis " if self.mod.use_bisect_flip_axis[1] else "")+("Z-Axis" if self.mod.use_bisect_flip_axis[2] else "")
        
        if self.EmptyRotate:
            draw_Text(context,0,preferences().font_size,text=[Axis,Bisect,Flip,"R : Go Back",f"G : Move",f"Press X,Y or Z to rotate on that Axis",f"Angle: {eulerToDegree(bpy.context.active_object.rotation_euler)}"],alignH='LEFT')
        elif self.objMove:
            draw_Text(context,0,preferences().font_size,text=[Axis,Bisect,Flip,f"R : Rotate","G : Go Back",f"Press X,Y or Z to move on that Axis"],alignH='LEFT')
        elif self.Flipping:
            draw_Text(context,0,preferences().font_size,text=["F: Back",Flip],alignH='LEFT')
        elif self.Bisecting:
            draw_Text(context,0,preferences().font_size,text=["B: Back",Bisect],alignH='LEFT')
        else:
            draw_Text(context,0,preferences().font_size,text=[Axis,Bisect,Flip,f"Angle: {eulerToDegree(bpy.context.active_object.rotation_euler)}","G : Move Object","R : Angle of mirror","E : Add Empty" if context.mode=='OBJECT' else '',"A : New Mirror Modifier" if context.mode=='OBJECT' else ''],alignH='LEFT')
     