#from math import e
import bpy
from . utils import *


class RTOOLS_OT_SetupMaterials(bpy.types.Operator):
    # Calling Select All Including
    bl_idname = "rtools.setup_materials"
    bl_label = "Setup Materials"
    bl_description = "Setup All PBR Materials From A Directory\nCTRL+LMB: Mark created materials as asset"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        # bpy.ops.preferences.asset_library_add('INVOKE_DEFAULT')
        #og_libs=[a for a in context.preferences.filepaths.asset_libraries]
        # print(bpy.context.preferences.filepaths.asset_libraries[:])
        if event.ctrl and "RanTools Materials" not in [a.name for a in bpy.context.preferences.filepaths.asset_libraries]:
            self.report(
                {'WARNING'}, "No 'RanTools Materials' asset library found (Create in preferences)!")
            return {'CANCELLED'}
            # bpy.ops.preferences.asset_library_add('INVOKE_DEFAULT')

        #new_libs=[a for a in context.preferences.filepaths.asset_libraries]
        # print(context.preferences.filepaths.asset_libraries[:])
        # new=Diff(og_libs,new_libs)
        # print(new)
        # if new:
        #    new[0].name="RanTools Materials"
        path = None
        lib_path = ensure_library("RanTools Materials",preferences().material_asset_library_folder)
        if lib_path:
            blendname = "RanTools_Assets"
            if bpy.data.is_saved:
                filename = bpy.path.basename(bpy.data.filepath)
                filename = os.path.splitext(filename)[0]
                blendname = bpy.path.basename(
                    bpy.data.filepath).rpartition('.')[0]
            files = [file for file in os.listdir(lib_path)]
            i = 0
            name = blendname
            fname = blendname
            while(fname+".blend" in files):
                fname = f"{name}_{i}"
                # print(fname)
                i += 1
            #final_name = os.path.join(lib_path[0], fname+".blend")
            path = os.path.join(lib_path, fname+".blend")
        setup_materials(self, context, folder_path=context.scene.rt_tools.MaterialFolderPath,
                        mark_asset=event.ctrl and bpy.app.version >= (3, 0, 0) and path, lib_path=path, fromsetupmats=True)

        #bpy.ops.wm.save_as_mainfile(filepath =path,copy=True)
        return {'FINISHED'}


class RTOOLS_OT_Change_Material(bpy.types.Operator):
    bl_idname = "rtools.change_material"
    bl_label = "Change Material"
    bl_description = "Add This Material To Active Material Slot\nCTRL+LMB : Make Material Emissive and Add\nSHIFT+LMB: Add Copy\nALT+LMB: Adjust Material"
    name: bpy.props.StringProperty()

    def add_drawHandler(self, context):
        self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_px, (context,), "WINDOW", "POST_PIXEL")

    def remove_drawHandler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, "WINDOW")
        context.area.tag_redraw()

    def draw_callback_px(self, context):
        draw_Text(context, 0, 15, text=[
                  f"Emission Strength: {round(self.node_emission.inputs[1].default_value,4) if self.node_emission is not None else '0'}"])

    @classmethod
    def poll(cls, context):
        if len(context.selected_objects) > 0 and context.active_object is not None:
            return True 
        else:
            return False

    def execute(self, context):
        if context.mode != 'EDIT_MESH' or len(context.selected_objects) > 1:
            for ob in context.selected_objects:
                if ob.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'}:
                    if len(ob.data.materials) > 0:
                        if self.UseEmissive:
                            ob.data.materials[ob.active_material_index] = bpy.data.materials.get(
                                self.name)
                            mat = makeEmissive(context)
                            ob.data.materials[ob.active_material_index] = mat[0]
                            self.node_emission = mat[1]
                            self.add_drawHandler(context)
                            return {'RUNNING_MODAL'}
                        else:
                            if self.copy:
                                ob.data.materials[ob.active_material_index] = bpy.data.materials.get(
                                    self.name).copy()
                            else:
                                ob.data.materials[ob.active_material_index] = bpy.data.materials.get(
                                    self.name)
                    else:
                        if self.UseEmissive:

                            ob.data.materials.append(
                                bpy.data.materials.get(self.name))
                            mat = makeEmissive(context)
                            ob.data.materials[ob.active_material_index] = mat[0]
                            self.node_emission = mat[1]
                            self.add_drawHandler(context)
                            return {'RUNNING_MODAL'}
                        else:
                            if self.copy:
                                ob.data.materials.append(
                                    bpy.data.materials.get(self.name).copy())
                            else:
                                ob.data.materials.append(
                                    bpy.data.materials.get(self.name))
        else:
            ob = bpy.context.active_object
            offset = len(ob.data.materials)
            if bpy.data.materials.get(self.name).name not in [m.name for m in ob.data.materials] or self.UseEmissive or self.copy:
                if self.copy:
                    ob.data.materials.append(
                        bpy.data.materials.get(self.name).copy())
                else:
                    ob.data.materials.append(bpy.data.materials.get(self.name))
            else:
                for i, a in enumerate(ob.data.materials):
                    if a.name == bpy.data.materials.get(self.name).name:
                        offset = i
                        break
            mesh = ob.data
            for face in mesh.polygons:
                if face.select:
                    ob.active_material_index = offset
                    bpy.ops.object.material_slot_assign()
            if self.UseEmissive:
                mat = makeEmissive(context)
                ob.data.materials[ob.active_material_index] = mat[0]
                self.node_emission = mat[1]
                self.add_drawHandler(context)
                return {'RUNNING_MODAL'}
        return {'FINISHED'}

    def modal(self, context, event):
        if event.type == 'LEFT_SHIFT':
            self.initX = event.mouse_x
            if event.value == 'PRESS':
                self.speed = 10
            elif event.value == 'RELEASE':
                self.speed = 1
            self.strength = self.node_emission.inputs[1].default_value
            context.area.tag_redraw()
        if event.type == 'MOUSEMOVE':
            if self.node_emission is not None:
                self.node_emission.inputs[1].default_value = max(
                    round(self.strength-(self.initX-event.mouse_x)/(100*self.speed), 2), 0)
            context.area.tag_redraw()
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        return{'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.node_emission = None
        self.speed = 1
        self.strength = 2
        self.initX = event.mouse_x
        self.copy = event.shift
        if event.alt:
            bpy.ops.rtools.singlematerialadjustpanel(
                'INVOKE_DEFAULT', mat=self.name)
            return {'FINISHED'}
        if event.ctrl:
            self.UseEmissive = True
            context.window_manager.modal_handler_add(self)
        else:
            self.UseEmissive = False

        return self.execute(context)


class RTOOLS_OT_New_Material(bpy.types.Operator):
    bl_idname = "rtools.newmaterial"
    bl_label = "New Material"
    bl_description = "Create New Material"
    bl_options = {"REGISTER", "UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object
    def execute(self, context):
        mat = bpy.data.materials.new("Material")
        mat.use_nodes = True
        for o in context.selected_objects:
            if len(o.data.materials) != 1 or context.mode == 'EDIT_MESH':
                o.data.materials.append(mat)
            else:
                o.data.materials[o.active_material_index] = mat
            offset = 0
            for i, m in enumerate(o.data.materials):
                if mat.name == m.name:
                    offset = i
            context.active_object.active_material_index = offset
            if context.mode == 'EDIT_MESH':
                mesh = o.data
                for face in mesh.polygons:
                    if face.select:

                        bpy.ops.object.material_slot_assign()
        return {'FINISHED'}


class RTOOLS_MT_Material_Menu(bpy.types.Menu):
    bl_label = "Materials"

    def draw(self, context):
        layout = self.layout
        layout.template_modifiers()
        column = layout.column()
        layout.operator_context = 'INVOKE_DEFAULT'
        for item in bpy.data.materials:
            if item.name != "Dots Stroke":

                column.operator("rtools.change_material", text=item.name,
                                icon_value=layout.icon(item)).name = item.name
                # column.operator("rtools.singlematerialadjustpanel",icon='GREASEPENCIL',text="").mat=item.name
        column.operator("rtools.newmaterial", text="New Material", icon="ADD")


class RTOOLS_OT_call_material_menu(bpy.types.Operator):
    bl_idname = "rtools.call_material_menu"
    bl_label = "Material Menu"
    @classmethod
    def poll(cls, context):
        return context.active_object
    def execute(self, context):
        bpy.ops.wm.call_menu(name="RTOOLS_MT_Material_Menu")
        return {'FINISHED'}


class RTOOLS_MT_Single_Material_Adjust_Panel(bpy.types.Operator):
    bl_label = "Material Menu"
    bl_idname = "rtools.singlematerialadjustpanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}
    mat: bpy.props.StringProperty()

    def draw(self, context):
        layout = self.layout
        layout.label(text="Quick Material Adjust")
        layout.operator_context = "INVOKE_DEFAULT"
        layout.ui_units_x = 10*len(context.active_object.data.materials)
        pieMenu = layout
        #pieMenu = layout.menu_pie()
        box = pieMenu.row()
        sockets = preferences().sockets.split(',')
        nodesToUse = preferences().nodes.split(',')

        m = bpy.data.materials[self.mat]
        if m is not None:
            #print([n.type for n in m.node_tree.nodes])
            nodes = [n for n in m.node_tree.nodes if n.type in nodesToUse and any(
                [a.is_linked for a in n.outputs])]
            for group in [n for n in m.node_tree.nodes if n.type == 'GROUP']:
                nodes += [n for n in group.node_tree.nodes if n.type in nodesToUse and any(
                    [a.is_linked for a in n.outputs])]
            if len(nodes) > 0:
                col = box.column()
                # col=col.box()
                col.prop(m, 'name', text="")

                for node in nodes:
                    if node.type == 'MIX_RGB':
                        inputs = [
                            n for n in node.inputs if n.name in sockets and not n.is_linked]
                    else:
                        inputs = [n for n in node.inputs if n.name in sockets]

                    inputs += [n for n in node.outputs if node.type ==
                               "RGB" and n.is_linked]
                    inputs += [n for n in node.outputs if node.type ==
                               "VALUE" and n.is_linked]
                    if len(inputs) > 0:
                        col2 = col.box()
                        col2.label(text=f"Node: {node.name}")
                        col2.separator(factor=0)
                        for input in inputs:

                            if input.is_linked and input.node.type != 'RGB' and input.node.type != 'VALUE':
                                # if input.links[0].from_node.type!='TEX_IMAGE':
                                row = col2.row()
                                row = row.split(factor=0.89)
                                col1 = row.row()

                                if 'RT_Math_Adjust' in input.links[0].from_node.name:
                                    col1.enabled = True
                                    col1.prop(
                                        input.links[0].from_node.inputs[1], 'default_value', text=f"{input.name}(UnLocked)")
                                elif 'RT_Color_Adjust' in input.links[0].from_node.name:
                                    col1.enabled = True
                                    col1.prop(input.links[0].from_node.inputs[0], 'default_value',
                                              text=f"{input.links[0].from_node.inputs[0].name}(UnLocked)")
                                    col1.prop(input.links[0].from_node.inputs[1], 'default_value',
                                              text=f"{input.links[0].from_node.inputs[1].name}(UnLocked)")
                                else:
                                    if input.links[0].from_node.type == 'TEX_IMAGE':
                                        col1.prop(
                                            input.links[0].from_node, 'image', text=input.name)
                                    else:
                                        col1.enabled = False
                                        col1.prop(input, 'default_value',
                                                  text=f"{input.name}(Linked)")
                                col3 = row.row()
                                col3.enabled = True
                                op = col3.operator('rtools.unlock', icon="UNLOCKED" if 'RT_Math_Adjust' in input.links[
                                                   0].from_node.name or 'RT_Color_Adjust' in input.links[0].from_node.name else 'LOCKED', text="")

                                op.nodeName = node.name
                                op.mat = m.name
                                op.socket_name = input.name
                                # elif input.links[0].from_node.type=='TEX_IMAGE':
                                #    if input.links[0].from_node.type=='TEX_IMAGE':
                                #       col2.prop(input.links[0].from_node,'image',text=input.name)

                            else:
                                col2.prop(input, 'default_value',
                                          text=input.name)

    def invoke(self, context, event):
        if context.active_object.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'} and len(context.active_object.data.materials) > 0:
            return context.window_manager.invoke_popup(self)
        else:
            self.report({'WARNING'}, 'No Materials Found!')
            return {'FINISHED'}

    def execute(self, context):
        return {'FINISHED'}


class RTOOLS_MT_Node_Unlock(bpy.types.Operator):
    bl_label = "Material Menu"
    bl_idname = "rtools.unlock"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}
    nodeName: bpy.props.StringProperty()
    mat: bpy.props.StringProperty()
    socket_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        mat = bpy.data.materials[self.mat]
        for n in mat.node_tree.nodes:
            if n.name == self.nodeName:
                # print(n.name,mat.name)
                # print(n.inputs[self.socket_name].type)
                from_soc = n.inputs[self.socket_name].links[0].from_socket
                to_soc = n.inputs[self.socket_name].links[0].to_socket
                if n.inputs[self.socket_name].type != 'RGBA':
                    mathNode = mat.node_tree.nodes.new(type="ShaderNodeMath")
                    mathNode.use_clamp = True
                    mathNode.inputs[1].default_value = 0
                    mathNode.name = 'RT_Math_Adjust'
                    mat.node_tree.links.new(from_soc, mathNode.inputs[0])
                else:
                    mathNode = mat.node_tree.nodes.new(
                        type="ShaderNodeHueSaturation")
                    mathNode.name = 'RT_Color_Adjust'
                    mat.node_tree.links.new(from_soc, mathNode.inputs[4])
                mathNode.location = n.inputs[self.socket_name].links[0].from_node.location.x + \
                    250, n.inputs[self.socket_name].links[0].from_node.location.y

                mat.node_tree.links.new(mathNode.outputs[0], to_soc)
        return {'FINISHED'}


class RTOOLS_MT_Material_Adjust_Panel(bpy.types.Operator):
    bl_label = "Quick Material Adjust Panel"
    bl_idname = "rtools.materialadjustpanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def draw(self, context):
        layout = self.layout
        layout.label(text="Quick Material Adjust")
        layout.operator_context = "INVOKE_DEFAULT"
        layout.ui_units_x = 10*len(context.active_object.data.materials)
        pieMenu = layout
        #pieMenu = layout.menu_pie()
        box = pieMenu.row()
        sockets = preferences().sockets.split(',')
        nodesToUse = preferences().nodes.split(',')
        if len(context.active_object.data.materials) > 0:
            m = context.active_object.data.materials[context.active_object.active_material_index]
            if m is not None:
                #print([n.type for n in m.node_tree.nodes])
                nodes = [n for n in m.node_tree.nodes if n.type in nodesToUse and any(
                    [a.is_linked for a in n.outputs])]
                for group in [n for n in m.node_tree.nodes if n.type == 'GROUP']:
                    nodes += [n for n in group.node_tree.nodes if n.type in nodesToUse and any(
                        [a.is_linked for a in n.outputs])]
                if len(nodes) > 0:
                    col = box.column()
                    # col=col.box()
                    col.prop(m, 'name', text="")

                    for node in nodes:
                        if node.type == 'MIX_RGB':
                            inputs = [
                                n for n in node.inputs if n.name in sockets and not n.is_linked]
                        else:
                            inputs = [
                                n for n in node.inputs if n.name in sockets]

                        inputs += [n for n in node.outputs if node.type ==
                                   "RGB" and n.is_linked]
                        inputs += [n for n in node.outputs if node.type ==
                                   "VALUE" and n.is_linked]
                        if len(inputs) > 0:
                            col2 = col.box()
                            col2.label(text=f"Node: {node.name}")
                            col2.separator(factor=0)
                            for input in inputs:

                                if input.is_linked and input.node.type != 'RGB' and input.node.type != 'VALUE':
                                    # if input.links[0].from_node.type!='TEX_IMAGE':
                                    row = col2.row()
                                    row = row.split(factor=0.89)
                                    col1 = row.row()

                                    if 'RT_Math_Adjust' in input.links[0].from_node.name:
                                        col1.enabled = True
                                        col1.prop(
                                            input.links[0].from_node.inputs[1], 'default_value', text=f"{input.name}(UnLocked)")
                                    elif 'RT_Color_Adjust' in input.links[0].from_node.name:
                                        col1.enabled = True
                                        col1.prop(input.links[0].from_node.inputs[0], 'default_value',
                                                  text=f"{input.links[0].from_node.inputs[0].name}(UnLocked)")
                                        col1.prop(input.links[0].from_node.inputs[1], 'default_value',
                                                  text=f"{input.links[0].from_node.inputs[1].name}(UnLocked)")
                                    else:
                                        if input.links[0].from_node.type == 'TEX_IMAGE':
                                            col1.prop(
                                                input.links[0].from_node, 'image', text=input.name)
                                        else:
                                            col1.enabled = False
                                            col1.prop(
                                                input, 'default_value', text=f"{input.name}(Linked)")
                                    col3 = row.row()
                                    col3.enabled = True
                                    op = col3.operator('rtools.unlock', icon="UNLOCKED" if 'RT_Math_Adjust' in input.links[
                                                       0].from_node.name or 'RT_Color_Adjust' in input.links[0].from_node.name else 'LOCKED', text="")

                                    op.nodeName = node.name
                                    op.mat = m.name
                                    op.socket_name = input.name
                                # elif input.links[0].from_node.type=='TEX_IMAGE':
                                #    if input.links[0].from_node.type=='TEX_IMAGE':
                                #       col2.prop(input.links[0].from_node,'image',text=input.name)

                                else:

                                    col2.prop(input, 'default_value',
                                              text=input.name)
            for m in Diff(context.active_object.data.materials, [context.active_object.data.materials[context.active_object.active_material_index]]):
                nodes = [n for n in m.node_tree.nodes if n.type in nodesToUse and any(
                    [a.is_linked for a in n.outputs])]
                for group in [n for n in m.node_tree.nodes if n.type == 'GROUP']:
                    nodes += [n for n in group.node_tree.nodes if n.type in nodesToUse and any(
                        [a.is_linked for a in n.outputs])]
                if len(nodes) > 0:
                    col = box.column()
                    # col=col.box()
                    col.prop(m, 'name', text="")
#                    col.label(text=m.name)
                    for node in nodes:
                        if node.type == 'MIX_RGB':
                            inputs = [
                                n for n in node.inputs if n.name in sockets and not n.is_linked]
                        else:
                            inputs = [
                                n for n in node.inputs if n.name in sockets]
                        inputs += [n for n in node.outputs if node.type ==
                                   "RGB" and n.is_linked]

                        inputs += [n for n in node.outputs if node.type ==
                                   "VALUE" and n.is_linked]
                        if len(inputs) > 0:
                            col2 = col.box()
                            col2.label(text=f"Node: {node.name}")
                            col2.separator(factor=0)
                            for input in inputs:
                                if input.is_linked and input.node.type != 'RGB' and input.node.type != 'VALUE':
                                    row = col2.row()
                                    row = row.split(factor=0.89)
                                    col1 = row.row()

                                    if 'RT_Math_Adjust' in input.links[0].from_node.name:
                                        col1.enabled = True
                                        col1.prop(
                                            input.links[0].from_node.inputs[1], 'default_value', text=f"{input.name}(UnLocked)")
                                    elif 'RT_Color_Adjust' in input.links[0].from_node.name:
                                        col1.enabled = True
                                        col1.prop(input.links[0].from_node.inputs[0], 'default_value',
                                                  text=f"{input.links[0].from_node.inputs[0].name}(UnLocked)")
                                        col1.prop(input.links[0].from_node.inputs[1], 'default_value',
                                                  text=f"{input.links[0].from_node.inputs[1].name}(UnLocked)")
                                    else:
                                        if input.links[0].from_node.type == 'TEX_IMAGE':
                                            col1.prop(
                                                input.links[0].from_node, 'image', text=input.name)
                                        else:
                                            col1.enabled = False
                                            col1.prop(
                                                input, 'default_value', text=f"{input.name}(Linked)")
                                    col3 = row.row()
                                    col3.enabled = True
                                    op = col3.operator('rtools.unlock', icon="UNLOCKED" if 'RT_Math_Adjust' in input.links[
                                                       0].from_node.name or 'RT_Color_Adjust' in input.links[0].from_node.name else 'LOCKED', text="")

                                    op.nodeName = node.name
                                    op.mat = m.name
                                    op.socket_name = input.name

                                else:
                                    col2.prop(input, 'default_value',
                                              text=input.name)

    def invoke(self, context, event):
        if context.active_object.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'} and len(context.active_object.data.materials) > 0:
            return context.window_manager.invoke_popup(self)
        else:
            self.report({'WARNING'}, 'No Materials Found!')
            return {'FINISHED'}

    def execute(self, context):
        return {'FINISHED'}
