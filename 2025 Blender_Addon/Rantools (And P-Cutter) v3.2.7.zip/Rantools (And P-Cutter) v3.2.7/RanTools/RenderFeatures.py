from . utils import *
import bpy
import os
from bpy_extras import view3d_utils

class RTOOLS_OT_Resolution(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.res"
    bl_label = "Multiply Render Resolution"

    @classmethod
    def description(cls, context, properties):
        if bpy.context.preferences.view.language == "ja_JP":
            return f"解像度に{properties.Factor}を掛けます\nCTRL + LMB：解像度を{properties.Factor}で割ってください"
        return f"Multiply Render Resolution by {properties.Factor}\nCTRL+LMB: Divide Render Resolution by {properties.Factor}"
    bl_options = {'REGISTER', 'UNDO'}
    Factor: bpy.props.StringProperty()

    def invoke(self, context, event):
        bpy.context.scene.render.use_border = True
        if event.ctrl:
            bpy.context.scene.render.resolution_x =int(bpy.context.scene.render.resolution_x/ eval(self.Factor))
            bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y/ eval(self.Factor))
        else:
            bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x* eval(self.Factor))
            bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y* eval(self.Factor))
        return {'FINISHED'}
class RTOOLS_OT_Lens(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.cameralens"
    bl_label = "Set Camera Focal Length"
    bl_description = "Set Camera Focal Length"
    bl_options = {'REGISTER', 'UNDO'}
    lens: bpy.props.IntProperty()
    @classmethod
    def description(cls, context, properties):
        return f"{translate_text('Set Camera Lens Focal Length to')} {properties.lens}mm"
    

    def invoke(self, context, event):
        #bpy.context.scene.render.use_border = True
        bpy.context.scene.camera.data.lens=self.lens
        return {'FINISHED'}

class RTOOLS_OT_RenderPath(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.render_path"
    bl_label = "Set Render Path with FileName"
    bl_description = "Set Render Path with FileName"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        enable_abs(context)
        if not bpy.data.is_saved:
            self.report({'ERROR'}, "Save The File First!")
            return {'CANCELLED'}
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]

        if filename:
            if not os.path.isdir(os.path.join(os.path.dirname(bpy.data.filepath), filename)):
                os.mkdir(os.path.join(os.path.dirname(bpy.data.filepath), filename))
            folderPath = os.path.join(os.path.dirname(bpy.data.filepath), filename)
            # print(f"Hi{os.listdir(folderPath)}")
            bpy.context.scene.render.filepath = os.path.join(
                folderPath, f"{filename}")
            if not bpy.context.scene.use_nodes:

                bpy.context.scene.use_nodes = True
            nodesField = bpy.context.scene.node_tree
            #renderLayerNode=nodesField.nodes.new(type = 'CompositorNodeRLayers')
            fileOutputNode = nodesField.nodes.new(
                type='CompositorNodeOutputFile')
            fileOutputNode.name="RT_File_Output"
            fileOutputNode.location = 300, -50
            links = nodesField.links

            for link in links:
                if link.to_node.bl_idname == "CompositorNodeComposite":
                    # print(link.from_socket)
                    links.new(
                        link.from_node.outputs[0], fileOutputNode.inputs[0])
            # link=links.new(renderLayerNode.outputs[0],fileOutputNode.inputs[0])
        return {'FINISHED'}
def disableOverlays(context):
    #overlays=[]

    overlays=[ 'show_annotation', 'show_axis_x', 'show_axis_y', 'show_axis_z', 'show_bones',
       'show_cursor', 'show_curve_normals', 'show_edge_bevel_weight', 'show_edge_crease', 'show_edge_seams', 'show_edge_sharp', 'show_edges', 'show_extra_edge_angle', 
       'show_extra_edge_length', 'show_extra_face_angle', 'show_extra_face_area', 'show_extra_indices', 'show_extras', 'show_face_center', 'show_face_normals', 
       'show_face_orientation', 'show_faces', 'show_fade_inactive', 'show_floor', 'show_freestyle_edge_marks', 'show_freestyle_face_marks', 'show_look_dev', 
       'show_motion_paths', 'show_object_origins', 'show_object_origins_all', 'show_occlude_wire', 'show_onion_skins', 'show_ortho_grid', 'show_outline_selected', 
        'show_paint_wire', 'show_relationship_lines', 'show_split_normals', 'show_stats', 'show_statvis', 'show_text', 'show_vertex_normals', 'show_weight',
        'show_wireframes', 'show_wpaint_contours', 'show_xray_bone',
         'use_gpencil_show_directions', 'use_gpencil_show_material_name']
    save=[]
    for overlay in overlays:
        save.append((overlay,getattr(context.space_data.overlay,overlay)))
        setattr(context.space_data.overlay,overlay,False)
        #context.space_data.overlay[overlay]=False
    context.space_data.overlay.show_wireframes=True
    return save
def enableOverlays(context,overlays):
    for overlay in overlays:
        setattr(context.space_data.overlay,overlay[0],overlay[1])
def setup_wireframe_node(mix):
    bpy.context.scene.use_nodes = True
    nodesField = bpy.context.scene.node_tree
    if bpy.data.node_groups.get('RT_WireFrame') is None:
            
            path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
            bpy.ops.wm.append(
                    directory=path,
                    filename='RT_WireFrame', autoselect=False
                )
    if not nodesField.nodes.get('RT_WireFrame'):
        WireFrameGroupNode=nodesField.nodes.new('CompositorNodeGroup')
        WireFrameGroupNode.name="RT_WireFrame"
        WireFrameGroupNode.node_tree = bpy.data.node_groups.get('RT_WireFrame')
        
    else:
        WireFrameGroupNode=nodesField.nodes.get('RT_WireFrame')
    WireFrameGroupNode.inputs[1].default_value=mix
    #renderLayerNode=nodesField.nodes.new(type = 'CompositorNodeRLayers')
    links = []
    for link in nodesField.links:
        links.append(link)
    # compositeNode=findNode(nodesField,"COMPOSITE")
    for link in links:
        if link.to_node.bl_idname == "CompositorNodeComposite":
            
            RLayer = link.from_socket
            outSocket = link.to_socket

                # print(link.from_socket)
            nodesField.links.new(
                RLayer, WireFrameGroupNode.inputs[0])
            nodesField.links.new(
                WireFrameGroupNode.outputs[0],outSocket)
                
        # link=links.new(renderLayerNode.outputs[0],fileOutputNode.inputs[0])
    AONode=WireFrameGroupNode.node_tree.nodes['AO']
    return AONode 
def create_wireframe_image(context,index=""):
        deselect_all()
        #print([x for x,y in inspect.getmembers(context.space_data.overlay)])
        show_overlays=context.space_data.overlay.show_overlays
        context.space_data.overlay.show_overlays=True
        saved_overlays=disableOverlays(context)
        taa_samples=context.scene.eevee.taa_samples
        context.scene.eevee.taa_samples=32
        view_transform=bpy.context.scene.view_settings.view_transform
        bpy.context.scene.view_settings.view_transform='Standard'
        #bpy.context.scene.render.resolution_x*=2
        #bpy.context.scene.render.resolution_y*=2
        show_cavity=context.space_data.shading.show_cavity
        wireframe_opacity=context.space_data.overlay.wireframe_opacity
        gtao_distance=context.scene.eevee.gtao_distance
        context.space_data.shading.show_cavity=False
        context.space_data.overlay.wireframe_opacity=0.9
        context.scene.eevee.gtao_distance=0.5
        
        if bpy.context.area:
            if bpy.context.area.type == 'VIEW_3D':
                bpy.context.area.spaces[0].region_3d.view_perspective = 'CAMERA'
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]
        blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
        filepath = os.path.splitext(bpy.data.filepath)[0] if not os.path.isdir(context.scene.projectInfo.renders_folder_path) else context.scene.projectInfo.renders_folder_path
        #print(filepath)
        fname=blendname+f"_{index}" if index else ""
        
        if bpy.data.is_saved:
            if not os.path.exists(os.path.join(filepath,"Intermediate")):
                if not os.path.isdir(filepath):
                        os.mkdir(filepath)
                os.mkdir(os.path.join(filepath,"Intermediate"))
            files = [file for file in os.listdir(filepath)
                    if file.startswith(blendname)]
            i=0
            name=fname
            while(fname+"."+context.scene.render.image_settings.file_format.lower() in files):
                fname = f"{name}_{i}"
                i+=1
        show_wireframes=context.space_data.overlay.show_wireframes
        context.space_data.overlay.show_wireframes=True
        shading_type=context.space_data.shading.type
        render_pass=context.space_data.shading.render_pass
        context.space_data.shading.type='MATERIAL'
        context.space_data.shading.render_pass="AO"
        #print(os.path.join(filepath,"Intermediate"))
        final_name = os.path.join(os.path.join(filepath,"Intermediate"), fname+"_AO."+context.scene.render.image_settings.file_format.lower())
        bpy.context.scene.render.filepath = final_name
        bpy.ops.render.opengl(write_still=True)
        image=bpy.data.images.load(final_name)
        enableOverlays(context,saved_overlays)
        context.scene.eevee.taa_samples=taa_samples
        bpy.context.scene.view_settings.view_transform=view_transform
        context.space_data.shading.show_cavity=show_cavity
        context.space_data.overlay.wireframe_opacity=wireframe_opacity
        context.scene.eevee.gtao_distance=gtao_distance
        context.space_data.shading.type=shading_type
        context.space_data.shading.render_pass=render_pass
        context.space_data.overlay.show_wireframes=show_wireframes
        context.space_data.overlay.show_overlays=show_overlays
        return image
class RTOOLS_OT_WireFrameRender(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.wireframerender"
    bl_label = "Wire Frame Render"
    bl_description = "Add WireFrame Node"
    bl_options = {'REGISTER', 'UNDO'}
    mix: bpy.props.FloatProperty(default=1,name="Mix")
    @classmethod
    def poll(cls, context):
        return bpy.data.is_saved

    def execute(self, context):
        AONode=setup_wireframe_node(self.mix)
        AONode.image=create_wireframe_image(context)
        return {'FINISHED'}
class RTOOLS_OT_WireFrameRender2(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.wireframerender"
    bl_label = "Wire Frame Render"
    bl_description = "Setup Denoise Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy.context.active_object is None or (bpy.context.active_object is not None and bpy.context.active_object.mode == 'OBJECT')

    def execute(self, context):
        #import inspect
        deselect_all()
        #print([x for x,y in inspect.getmembers(context.space_data.overlay)])
        disableOverlays(context)
        context.scene.eevee.taa_samples=32
        bpy.context.scene.view_settings.view_transform='Standard'
        #bpy.context.scene.render.resolution_x*=2
        #bpy.context.scene.render.resolution_y*=2
        context.space_data.shading.type='SOLID'
        context.space_data.shading.light='FLAT'
        context.space_data.shading.color_type='SINGLE'
        context.space_data.shading.show_cavity=False
        context.space_data.shading.single_color=[1,1,1]
        context.space_data.shading.background_type='VIEWPORT'
        context.space_data.shading.background_color=[1,1,1]
        context.space_data.overlay.wireframe_opacity=0.9
        bpy.context.scene.use_nodes = True
        nodesField = bpy.context.scene.node_tree
        if bpy.data.node_groups.get('RT_WireFrame') is None:
            
            path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
            bpy.ops.wm.append(
                    directory=path,
                    filename='RT_WireFrame', autoselect=False
                )
        WireFrameGroupNode=nodesField.nodes.new('CompositorNodeGroup')
        WireFrameGroupNode.name="RT_WireFrame"
        WireFrameGroupNode.node_tree = bpy.data.node_groups.get('RT_WireFrame')
        

        #renderLayerNode=nodesField.nodes.new(type = 'CompositorNodeRLayers')
        links = []
        for link in nodesField.links:
            links.append(link)
        # compositeNode=findNode(nodesField,"COMPOSITE")
        for link in links:
            if link.to_node.bl_idname == "CompositorNodeComposite":
                
                RLayer = link.from_socket
                outSocket = link.to_socket

                    # print(link.from_socket)
                nodesField.links.new(
                    RLayer, WireFrameGroupNode.inputs[0])
                nodesField.links.new(
                    WireFrameGroupNode.outputs[0],outSocket)
                    
            # link=links.new(renderLayerNode.outputs[0],fileOutputNode.inputs[0])
        AONode=WireFrameGroupNode.node_tree.nodes['AO']
        WireFrameNode=WireFrameGroupNode.node_tree.nodes['WireFrame']
        OutlineNode=WireFrameGroupNode.node_tree.nodes['Outline']
        bpy.ops.view3d.view_camera()
        filename = bpy.path.basename(bpy.data.filepath)
        filename = os.path.splitext(filename)[0]
        blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
        filepath = os.path.splitext(bpy.data.filepath)[0]
        fname=blendname
        
        if not os.path.exists(filepath):
            os.mkdir(filepath)
        
        files = [file for file in os.listdir(filepath)
                if file.startswith(blendname)]
        i=0
        name=fname
        #while(fname+"."+context.scene.render.image_settings.file_format.lower() in files):
        #    fname = f"{name}_{i}"
        #    i+=1
        context.space_data.overlay.show_wireframes=True
        final_name = os.path.join(filepath, fname+"_WIREFRAME."+context.scene.render.image_settings.file_format.lower())
        bpy.context.scene.render.filepath = final_name
        bpy.ops.render.opengl(write_still=True)
        WireFrameNode.image=bpy.data.images.load(final_name)
        
        final_name = os.path.join(filepath, fname+"_Outline."+context.scene.render.image_settings.file_format.lower())
        bpy.context.scene.render.filepath = final_name
        context.space_data.overlay.show_wireframes=False
        bpy.ops.render.opengl(write_still=True)
        OutlineNode.image=bpy.data.images.load(final_name)
        context.space_data.shading.type='MATERIAL'
        context.space_data.shading.render_pass="AO"
        
        final_name = os.path.join(filepath, fname+"_AO."+context.scene.render.image_settings.file_format.lower())
        bpy.context.scene.render.filepath = final_name
        bpy.ops.render.opengl(write_still=True)
        AONode.image=bpy.data.images.load(final_name)
        #bpy.context.scene.render.resolution_x/=2
        #bpy.context.scene.render.resolution_y/=2
        return {'FINISHED'}
class RTOOLS_OT_SetupDenoise(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.denoise"
    bl_label = "Setup Denoise"
    bl_description = "Setup Denoise Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy.context.active_object is None or (bpy.context.active_object is not None and bpy.context.active_object.mode == 'OBJECT')

    def execute(self, context):
        enable_abs(context)
        engine = bpy.context.scene.render.engine
        DenoiseNode = None
        bpy.context.scene.render.engine = 'CYCLES'
        bpy.context.view_layer.cycles.denoising_store_passes = True

        if not bpy.context.scene.use_nodes:

            bpy.context.scene.use_nodes = True
        nodesField = bpy.context.scene.node_tree

        #renderLayerNode=nodesField.nodes.new(type = 'CompositorNodeRLayers')
        if findNode(nodesField, "DENOISE") is None:
            DenoiseNode = nodesField.nodes.new(type='CompositorNodeDenoise')
            DenoiseNode.location = 500, -100
        else:
            DenoiseNode = findNode(nodesField, "DENOISE")
        links = []
        for link in nodesField.links:
            links.append(link)
        # compositeNode=findNode(nodesField,"COMPOSITE")
        for link in links:
            if link.from_node.bl_idname == "CompositorNodeRLayers":
                RLayer = link.from_node
                outNode = link.to_node
                if bpy.context.scene.render.engine == "CYCLES" and outNode.type != 'DENOISE':

                    # print(link.from_socket)
                    nodesField.links.new(
                        RLayer.outputs[0], DenoiseNode.inputs[0])
                    nodesField.links.new(
                        RLayer.outputs[4], DenoiseNode.inputs[1])
                    nodesField.links.new(
                        RLayer.outputs[5], DenoiseNode.inputs[2])
                    nodesField.links.new(DenoiseNode.outputs[0], outNode.inputs[int(
                        link.to_socket.path_from_id()[-2:-1])])
            # link=links.new(renderLayerNode.outputs[0],fileOutputNode.inputs[0])
        bpy.context.scene.render.engine = engine
        return {'FINISHED'}
class RTOOLS_OT_Change_Active_Camera(bpy.types.Operator):
    bl_idname = "rtools.changeactivecamera"
    bl_label = "Create Camera Markers"
    bl_description = "Create Camera Markers And Keyframes"
    bl_options = {'REGISTER', 'UNDO'}
    camera: bpy.props.StringProperty()
    def execute(self, context):
        scene=context.scene
        
        marker = scene.timeline_markers.new(self.camera, frame=scene.frame_current)
        marker.camera = scene.objects.get(self.camera)
        scene.objects.get(self.camera).keyframe_insert(data_path="location", frame=scene.frame_current)
        scene.objects.get(self.camera).keyframe_insert(data_path="rotation_euler", frame=scene.frame_current)
        scene.objects.get(self.camera).data.keyframe_insert(data_path="lens", frame=scene.frame_current)
        
        return {'FINISHED'}
class RTOOLS_OT_Shutter_Speed(bpy.types.Operator):
    bl_idname = "rtools.shutter"
    bl_label = "Set Shutter Speed"
    bl_options = {'REGISTER', 'UNDO'}
    shutter: bpy.props.FloatProperty()
    def execute(self, context):
        fps=bpy.context.scene.render.fps
        bpy.context.scene.eevee.motion_blur_shutter=fps*self.shutter
        bpy.context.scene.render.motion_blur_shutter=fps*self.shutter
        return{'FINISHED'}
class RTOOLS_OT_Ratio(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.ratio"
    bl_label = "Set aspect ratio"
    
    
    bl_options = {'REGISTER', 'UNDO'}
    Ratio: bpy.props.StringProperty()
    Resolution: bpy.props.StringProperty(default="NA")
    @classmethod
    def description(cls, context, properties):
        if properties.Resolution != "NA":
            return f"{translate_text('Set Render Resolution to')} {properties.Resolution}"
        return f"{translate_text('Set aspect ratio to')} {properties.Ratio}\nCTRL+LMB: {translate_text('Set aspect ratio to')} {properties.Ratio.split(':')[1]}:{properties.Ratio.split(':')[0]}"
    #bl_description = "Set aspect ratio to 2:1"
    def invoke(self, context, event):
        lowerRes = bpy.context.scene.render.resolution_x if bpy.context.scene.render.resolution_x < bpy.context.scene.render.resolution_y else bpy.context.scene.render.resolution_y
        equal = bpy.context.scene.render.resolution_x == bpy.context.scene.render.resolution_y
        bpy.context.scene.render.use_border = True
        Ratio = self.Ratio.replace(":", "/")
        isLandscape = bpy.context.scene.render.resolution_x > bpy.context.scene.render.resolution_y
        if self.Resolution != "NA":
            Ratio = f"{bpy.context.scene.render.resolution_x/bpy.context.scene.render.resolution_y}"

            if isLandscape:
                bpy.context.scene.render.resolution_y = int(
                    self.Resolution.replace("p", ""))
                bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * \
                    eval(Ratio))

            else:
                bpy.context.scene.render.resolution_x = int(
                    self.Resolution.replace("p", ""))
                bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_x / \
                    eval(Ratio))
            self.Resolution = "NA"
        else:
            if event.ctrl:

                bpy.context.scene.render.resolution_x = int(lowerRes)
                bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_x * \
                    eval(Ratio))
            else:
                bpy.context.scene.render.resolution_y = int(lowerRes)
                bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * \
                    eval(Ratio))
                # t=bpy.context.scene.render.resolution_x
                # bpy.context.scene.render.resolution_x=bpy.context.scene.render.resolution_y
                # bpy.context.scene.render.resolution_y=t
                # bpy.context.scene.render.resolution_y=bpy.context.scene.render.resolution_x*eval(Ratio)
        return {'FINISHED'}


class RTOOLS_OT_RatioSwitch(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.ratioswitch"
    bl_label = "Adjust Camera Settings"
    bl_description = "Interactive Camera Settings Tool"
    bl_options = {'REGISTER', 'UNDO'}
    ratios = ["21/9", "16/9", "2/1", "1/1"]
    prevRatiox = 0
    prevRatioy = 0
    initFStop = 2.8
    FStopSave = None
    zoomSave = None
    initX = None
    fScroll = None
    objects = []
    index = None
    speed = 1
    changeCamera=None
    adjustFStop = None
    adjustZoom = None
    ratio = ratios[0]

    @classmethod
    def poll(cls, context):
        if bpy.context.scene.camera is not None:
            return True
        else:
            return False

    def add_drawHandler(self, context):
        self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_px, (context,), "WINDOW", "POST_PIXEL")

    def remove_drawHandler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, "WINDOW")
        context.area.tag_redraw()

    

    def execute(self, context):
        
        bpy.context.scene.render.use_border = True
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * \
            eval(self.ratio))
        context.area.tag_redraw()
        return {'FINISHED'}

    def modal(self, context, event):
        rt_tools = context.scene.rt_tools
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.FStopSave = bpy.context.scene.camera.data.dof.aperture_fstop
            self.zoomSave = bpy.context.scene.camera.data.sensor_width
            self.initX=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.initX=context.region.x+context.region.width
            self.FStopSave = bpy.context.scene.camera.data.dof.aperture_fstop
            self.zoomSave = bpy.context.scene.camera.data.sensor_width
        if event.type == 'LEFT_SHIFT':
            if event.value == "PRESS":
                self.speed = 0.1
            elif event.value == 'RELEASE':
                self.speed = 1
            self.FStopSave = bpy.context.scene.camera.data.dof.aperture_fstop
            self.zoomSave = bpy.context.scene.camera.data.sensor_width
            self.initX = event.mouse_x
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            if self is not None:
                #if self.fScroll:
                #    self.index = (self.index+1) % len(self.objects)
                #    bpy.context.scene.camera.data.dof.focus_object = self.objects[self.index]
                #    context.area.tag_redraw()
                if self.changeCamera:
                    cams=[o for o in context.scene.objects if o.type=='CAMERA']
                    self.camIndex=int((1+self.camIndex)% len(cams))
                    bpy.context.scene.camera=cams[self.camIndex]
                    context.area.tag_redraw()
                elif not self.changeCamera and not self.adjustFStop and not self.adjustZoom:
                    rt_tools.choice = int((rt_tools.choice+1) % len(self.ratios))
                    self.ratio = self.ratios[rt_tools.choice]
                    self.execute(context)
                

        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            if self is not None:
                #if self.fScroll:
                #    self.index = (self.index-1) % len(self.objects)
                #    bpy.context.scene.camera.data.dof.focus_object = self.objects[self.index]
                #    context.area.tag_redraw()
                if self.changeCamera:
                    cams=[o for o in context.scene.objects if o.type=='CAMERA']
                    self.camIndex=int((self.camIndex-1)% len(cams))
                    bpy.context.scene.camera=cams[self.camIndex]
                    context.area.tag_redraw()
                elif not self.changeCamera and not self.adjustFStop and not self.adjustZoom:
                    rt_tools.choice = int((rt_tools.choice-1) % len(self.ratios))
                    self.ratio = self.ratios[rt_tools.choice]
                    self.execute(context)
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self.adjustFStop:
                self.adjustFStop = False
                context.area.tag_redraw()
            elif self.fScroll:
                self.fScroll = False
                context.area.tag_redraw()
            elif self.changeCamera:
                self.changeCamera = False
                context.area.tag_redraw()
            elif self.adjustZoom:
                self.adjustZoom = False
                context.area.tag_redraw()
            elif self.fScroll:
                scene= context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                
                (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                hidden_objs=[]
                while ( object and (not object.visible_get() or object.type!='MESH')):
                    
                    hidden_objs.append((object,object.hide_get()))
                    object.hide_view=True
                    (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                for o,s in hidden_objs:
                    o.hide_view=s
                if object:
                    bpy.context.scene.camera.data.dof.focus_object=object
                
            else:
                bpy.context.space_data.show_region_hud = True
                self.remove_drawHandler(context)
            #print(f"Saving State: {rt_tools.choice}")
                return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type == 'ESC':
            self.remove_drawHandler(context)
            bpy.context.scene.render.resolution_y = int(self.prevRatioy)
            bpy.context.scene.render.resolution_x = int(self.prevRatiox)
            bpy.context.scene.camera.data.dof.aperture_fstop = self.initFStop
            bpy.context.scene.camera.data.sensor_width = self.initZoom
            bpy.context.space_data.show_region_hud = True
            return {'CANCELLED'}
        elif event.type == 'F':
            if event.value =='PRESS':
                self.fScroll = not self.fScroll
                self.adjustFStop = False
                self.adjustZoom = False
                self.changeCamera = False
                bpy.context.scene.camera.data.dof.focus_object = bpy.context.active_object
                self.activeKey='F'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        elif event.type == 'D' :
            if event.value =='PRESS':
                self.fScroll = False
                self.adjustFStop = False
                bpy.context.scene.camera.data.dof.use_dof = not bpy.context.scene.camera.data.dof.use_dof
                if not bpy.context.scene.camera.data.dof.use_dof:
                    self.adjustFStop = False
                if self.init_active_object and self.init_active_object.type in {'MESH', 'EMPTY', 'CURVE'}:
                    bpy.context.scene.camera.data.dof.focus_object = self.init_active_object
                bpy.context.scene.camera.data.dof.focus_object
                self.activeKey='D'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        elif event.type == 'A' :
            if event.value =='PRESS':
                self.fScroll = False
                self.adjustZoom = False
                self.changeCamera = False
                self.initX = event.mouse_x
                self.adjustFStop = not self.adjustFStop
                self.FStopSave = bpy.context.scene.camera.data.dof.aperture_fstop
                self.activeKey='A'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        elif event.type == 'C':
            if event.value =='PRESS':
                self.fScroll = False
                self.adjustFStop = False
                self.adjustZoom = False
                self.initX = event.mouse_x
                self.changeCamera = not self.changeCamera
                self.FStopSave = bpy.context.scene.camera.data.dof.aperture_fstop
                self.activeKey='C'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        elif event.type == 'Z' :
            if event.value =='PRESS':
                self.fScroll = False
                self.adjustFStop = False
                self.changeCamera = False
                self.initX = event.mouse_x
                self.adjustZoom = not self.adjustZoom
                self.zoomSave = bpy.context.scene.camera.data.sensor_width
                self.activeKey='Z'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        elif event.type == 'MOUSEMOVE':

            if self.adjustFStop:
                bpy.context.scene.camera.data.dof.aperture_fstop = max(
                    0.1, (self.FStopSave-(self.initX-event.mouse_x)/(200/self.speed)))
            if self.adjustZoom:
                bpy.context.scene.camera.data.sensor_width = max(
                    1, (self.zoomSave+(self.initX-event.mouse_x)/(50/self.speed)))
            if self.fScroll:
                self.mouse_x=event.mouse_region_x
                self.mouse_y=event.mouse_region_y
                scene= context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                
                (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                hidden_objs=[]
                while ( object and (not object.visible_get() or object.type!='MESH')):
                    
                    hidden_objs.append((object,object.hide_get()))
                    object.hide_view=True
                    (result, location1, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                for o,s in hidden_objs:
                    o.hide_view=s
                if object:
                    bpy.context.scene.camera.data.dof.focus_object=object
                else:
                    bpy.context.scene.camera.data.dof.focus_object=None
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.context.space_data.show_region_hud = False
        self.activeKey=None
        self.init_active_object=context.active_object
        context.space_data.region_3d.view_perspective = 'CAMERA'
        deselect_all()
        select(context.scene.camera)
        if preferences().auto_abs:
            enable_abs(context)
        rt_tools = context.scene.rt_tools
        #print(f"Retrieving State: {rt_tools.choice}")
        ratio = self.ratios[rt_tools.choice]
        self.prevRatiox = bpy.context.scene.render.resolution_x
        self.prevRatioy = bpy.context.scene.render.resolution_y
        context.window_manager.modal_handler_add(self)
        self.initX = event.mouse_x
        self.adjustFStop = False
        self.adjustZoom = False
        self.speed = 1
        self.index = 0
        self.fScroll = False
        self.changeCamera= False
        self.camIndex=0
        self.objects=[o for o in context.scene.objects if o.type in {"MESH", "EMPTY","CURVE"}].copy()
        if bpy.context.scene.camera.data.dof.use_dof:
            self.initfStop = bpy.context.scene.camera.data.dof.aperture_fstop
            self.FStopSave = self.initFStop
        self.initZoom = bpy.context.scene.camera.data.sensor_width
        self.zoomSave = self.initZoom
        self.add_drawHandler(context)
        context.area.tag_redraw()
        return{'RUNNING_MODAL'}
    def draw_callback_px(self, context):
        rt_tools = context.scene.rt_tools
        Focus = f"Focus Object: {bpy.context.scene.camera.data.dof.focus_object.name}" if bpy.data.cameras[
            bpy.context.scene.camera.data.name].dof.focus_object is not None else f"Focus Distance: {bpy.context.scene.camera.data.dof.focus_distance}"
        if self.changeCamera:
            draw_Text(context,0,preferences().font_size, text=[
                      "Press C to Go Back", "Camera Switch Mode"], alignV='TOP')
        elif self.fScroll:
            draw_Text(context,0,preferences().font_size, text=[
                      "Press F to Go Back", "Change Focus Object Mode"], alignV='TOP')
        elif self.adjustFStop:
            draw_Text(context,0,preferences().font_size, text=[
                      "Press A to Go Back", "F-Stop Adjust Mode"], alignV='TOP')
        elif self.adjustZoom:
            draw_Text(context,0,preferences().font_size, text=[
                      "Press Z to Go Back", "Zoom Adjust Mode"], alignV='TOP')
        else:
            draw_Text(context,0,preferences().font_size, text=[
                      "Aspect Ratio Adjust Mode"], alignV='TOP')
        draw_Text(context,0,preferences().font_size, text=["Z: Adjust Zoom(Sensor Width)",
                                        "A : Adjust Aperture", "D: Toggle DOF", "F: Change Focus Object ","C: Camera Switch Mode"],activeKey=self.activeKey)
        draw_Text(context,0,preferences().font_size, text=[f"Aspect Ratio: {self.ratios[rt_tools.choice]}", f"F-Stop: {round(bpy.context.scene.camera.data.dof.aperture_fstop,2)}",
                                        f"Sensor Width: {round(bpy.context.scene.camera.data.sensor_width,2)}mm", Focus, f"Depth Of Field: {'Enabled' if bpy.context.scene.camera.data.dof.use_dof  else 'Disabled'}",f"Camera: {bpy.context.scene.camera.name}"], alignH='LEFT')


"""def searchObject(path,object):
    with bpy.data.libraries.load(str(path)) as (data_from, _):
        results=[]
        for obj in data_from.objects:
            if object in obj:
                results.append(("obj",obj,path))
        for col in data_from.collections:
            if object in col:
                results.append(("col",col,path))
        if len(results)>0:
            return results
    return None"""
class RTOOLS_OT_Add_Camera(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.addcamera"
    bl_label = "Add Camera (RanTools)"
    bl_description = "Add camera at current location and enter adjustment modal"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        region = context.region
        rv3d = context.region_data
        location=view3d_utils.region_2d_to_origin_3d(region, rv3d, (region.width/2.0, region.height/2.0))
        bpy.ops.object.camera_add()
        cam=context.active_object
        cam.location=location
        context.scene.camera=cam
        bpy.ops.rtools.ratioswitch('INVOKE_DEFAULT')
        return {'FINISHED'}
