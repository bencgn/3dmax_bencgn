import bpy
icons={'MULTIRES': 'MOD_MULTIRES',
'ARRAY': 'MOD_ARRAY',
'BEVEL': 'MOD_BEVEL',
'BOOLEAN': 'MOD_BOOLEAN',
'BUILD': 'MOD_BUILD',
'DECIMATE': 'MOD_DECIMATE',
'EDGE_SPLIT': 'MOD_EDGESPLIT',
'NODES': 'MOD_NODES',
'MASK': 'MOD_MASK',
'MIRROR': 'MOD_MIRROR',
'REMESH': 'MOD_REMESH',
'SCREW': 'MOD_SCREW',
'SKIN': 'MOD_SKIN',
'SOLIDIFY': 'MOD_SOLIDIFY',
'SUBSURF': 'MOD_SUBSURF',
'TRIANGULATE': 'MOD_TRIANGULATE',
'VOLUME_TO_MESH': 'VOLUME_DATA',
'WELD': 'AUTOMERGE_ON',
'WIREFRAME':'MOD_WIREFRAME',
'ARMATURE': 'MOD_ARMATURE', 'CAST': 'MOD_CAST', 'CURVE': 'MOD_CURVE', 'DISPLACE': 'MOD_DISPLACE', 'HOOK': 'MOD_HOOK', 'LAPLACIANDEFORM': 'MOD_MESHDEFORM', 'LATTICE': 'MOD_LATTICE', 'MESH_DEFORM': 'MOD_MESHDEFORM', 'SHRINKWRAP': 'MOD_SHRINKWRAP', 'SIMPLE_DEFORM': 'MOD_SIMPLEDEFORM', 'SMOOTH': 'MOD_SMOOTH', 'CORRECTIVE_SMOOTH': 'MOD_SMOOTH', 'LAPLACIANSMOOTH': 'MOD_SMOOTH', 'SURFACE_DEFORM': 'MOD_MESHDEFORM', 'WARP': 'MOD_WARP', 'WAVE': 'MOD_WAVE',
'DATA_TRANSFER': 'MOD_DATA_TRANSFER',
'MESH_CACHE': 'MOD_MESHDEFORM',
'MESH_SEQUENCE_CACHE': 'MOD_MESHDEFORM',
'NORMAL_EDIT': 'MOD_NORMALEDIT',
'WEIGHTED_NORMAL': 'MOD_NORMALEDIT',
'UV_PROJECT': 'MOD_UVPROJECT',
'UV_WARP': 'MOD_UVPROJECT',
'VERTEX_WEIGHT_EDIT': 'MOD_VERTEX_WEIGHT',
'VERTEX_WEIGHT_MIX': 'MOD_VERTEX_WEIGHT',
'VERTEX_WEIGHT_PROXIMITY': 'MOD_VERTEX_WEIGHT',
'OCEAN':'MOD_OCEAN','EXPLODE': 'MOD_EXPLODE'}
class RTOOLS_MT_EXPLODE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="EXPLODE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_OCEAN_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="OCEAN":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MULTIRES_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MULTIRES":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_ARRAY_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="ARRAY":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_BEVEL_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="BEVEL":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_BOOLEAN_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="BOOLEAN":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_BUILD_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="BUILD":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_EDGE_SPLIT_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="EDGE_SPLIT":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_DECIMATE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="DECIMATE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_DECIM",
                    )
                    button.name = item.name
class RTOOLS_MT_NODES_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="NODES":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MASK_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MASK":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MASK_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MASK":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MIRROR_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MIRROR":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_REMESH_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="REMESH":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SCREW_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SCREW":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SKIN_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SKIN":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SOLIDIFY_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SOLIDIFY":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SUBSURF_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SUBSURF":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_VOLUME_TO_MESH_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="VOLUME_TO_MESH":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_TRIANGULATE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="TRIANGULATE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_WELD_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="WELD":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_WIREFRAME_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="WIREFRAME":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_ARMATURE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="ARMATURE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_CAST_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="CAST":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_CURVE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="CURVE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_DISPLACE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="DISPLACE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_HOOK_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="HOOK":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_LAPLACIANDEFORM_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="LAPLACIANDEFORM":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_LATTICE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="LATTICE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SHRINKWRAP_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SHRINKWRAP":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MESH_DEFORM_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MESH_DEFORM":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SIMPLE_DEFORM_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SIMPLE_DEFORM":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SMOOTH_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SMOOTH":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_CORRECTIVE_SMOOTH_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="CORRECTIVE_SMOOTH":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_LAPLACIANSMOOTH_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="LAPLACIANSMOOTH":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_SURFACE_DEFORM_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="SURFACE_DEFORM":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_WARP_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="WARP":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_WAVE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="WAVE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_DATA_TRANSFER_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="DATA_TRANSFER":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MESH_CACHE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MESH_CACHE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_MESH_SEQUENCE_CACHE_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="MESH_SEQUENCE_CACHE":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_NORMAL_EDIT_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="NORMAL_EDIT":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_NORMALEDIT",
                    )
                    button.name = item.name
class RTOOLS_MT_WEIGHTED_NORMAL_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="WEIGHTED_NORMAL":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_NORMALEDIT",
                    )
                    button.name = item.name
class RTOOLS_MT_UV_PROJECT_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="UV_PROJECT":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=icons[item.type],
                    )
                    button.name = item.name
class RTOOLS_MT_UV_WARP_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="UV_WARP":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_UVPROJECT",
                    )
                    button.name = item.name
class RTOOLS_MT_VERTEX_WEIGHT_EDIT_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="VERTEX_WEIGHT_EDIT":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_VERTEX_WEIGHT",
                    )
                    button.name = item.name
class RTOOLS_MT_VERTEX_WEIGHT_MIX_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="VERTEX_WEIGHT_MIX":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_VERTEX_WEIGHT",
                    )
                    button.name = item.name
class RTOOLS_MT_VERTEX_WEIGHT_PROXIMITY_Mod_Menu(bpy.types.Menu):
        bl_label = "Modifier Presets"
        def draw(self, context):
            layout = self.layout
            layout.operator_context = "INVOKE_DEFAULT"
            row = layout.row()
            column = row.column()
            for item in context.scene.modMenuInfo:
                if item.type=="VERTEX_WEIGHT_PROXIMITY":
                    button = column.operator(
                        "rtools.add_modifier_preset",
                        text=item.name,
                        icon=f"MOD_VERTEX_WEIGHT",
                    )
                    button.name = item.name
