import bpy
from . utils import *
from mathutils import Vector,Matrix,geometry,Euler
import bmesh
from mathutils.bvhtree import BVHTree
import random
from bpy_extras import view3d_utils
import gpu
import bgl
from math import pi
from gpu_extras.batch import batch_for_shader
import functools
import time
activeProps={"ARRAY":('count',),
'BEVEL':('width','profile','angle_limit'),
'SCREW':('screw_offset','angle'),
'SOLIDIFY':('thickness','offset'),
'SUBSURF':('levels',),
'WELD':('merge_threshold',),
'CAST':('radius',),
'DISPLACE':('strength','mid_level'),
'SHRINKWRAP':('offset',),
'SIMPLE_DEFORM':('angle',),
'SMOOTH':('factor',),
'WEIGHTED_NORMAL':('weight',)}
#events={'MINUS':'-','NUMPAD_MINUS':'-','ZERO' :0,'ONE':1,'TWO' :2,'THREE': 3,'FOUR': 4,'FIVE': 5,'SIX' :6,'SEVEN': 7,'EIGHT': 8,'NINE': 9,'PERIOD':'.','NUMPAD_1':1,'NUMPAD_2':2,'NUMPAD_3':3,'NUMPAD_4':4,'NUMPAD_5':5,'NUMPAD_6':6,'NUMPAD_7':7,'NUMPAD_8':8,'NUMPAD_9':9,'NUMPAD_0':0,'NUMPAD_PERIOD':'.'}
number_events={'ONE':1,'TWO' :2,'THREE': 3,'FOUR': 4,'FIVE': 5,'SIX' :6,'SEVEN': 7,'EIGHT': 8,'NINE': 9}
events={'MINUS':'-','NUMPAD_MINUS':'-','ZERO' :0,'PERIOD':'.','NUMPAD_1':1,'NUMPAD_2':2,'NUMPAD_3':3,'NUMPAD_4':4,'NUMPAD_5':5,'NUMPAD_6':6,'NUMPAD_7':7,'NUMPAD_8':8,'NUMPAD_9':9,'NUMPAD_0':0,'NUMPAD_PERIOD':'.'}
def Break(scene):
    bpy.ops.rtools.breakoperator('INVOKE_DEFAULT')
class RTOOLS_OT_GroupIt(bpy.types.Operator):
    bl_idname = "rtools.groupit"
    bl_label = "Group It"
    bl_description="Create Group By Parenting Selected Objects To Box Empty"
    bl_options = {'REGISTER', 'UNDO'}
    name:bpy.props.StringProperty(default="None",name="Name",options={'SKIP_SAVE'})
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def execute(self, context):
        GroupIt(context,active_name=self.name)
        return {'FINISHED'}
    def invoke(self, context, event):
        self.name=context.active_object.name
        return self.execute(context)
def alignToNormal(context,objToAlign,obj,index):
    dup_obj=duplicate_object(obj)
    bpy.ops.object.select_all( action='DESELECT')
    select(dup_obj)
    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
    
    obj_rotation=dup_obj.evaluated_get(context.evaluated_depsgraph_get()).rotation_euler.to_matrix()
    
    object_evaluated=obj.evaluated_get(context.evaluated_depsgraph_get())
    delete_object_with_data(dup_obj)
    bm= bmesh.new()
    bm.from_mesh(object_evaluated.data)
    bm.faces.ensure_lookup_table()
    local_normal=bm.faces[index].normal
    z = Vector((0,0,1))
    bm.free()
    if not (math.isclose(abs(local_normal.x), 0, abs_tol=0.003)and math.isclose(abs(local_normal.y), 0, abs_tol=0.003)):
        
        a1=Vector((0,-1)).angle_signed(Vector((local_normal.x,local_normal.y)))
        
        if local_normal!=Vector((0,0,0)):
            rot = z.rotation_difference( local_normal ).to_euler()
            objToAlign.rotation_euler= rot
            
            objToAlign.rotation_euler = (objToAlign.rotation_euler.to_matrix() @ Matrix.Rotation(-a1, 3, 'Z')).to_euler()
            
    objToAlign.rotation_euler=(obj_rotation@objToAlign.rotation_euler.to_matrix() ).to_euler()
class RTOOLS_OT_SnapIt(bpy.types.Operator):
    bl_idname = "rtools.snapit"
    bl_label = "Snap Objects To Ground "
    bl_description="Snap Selected Objects To Ground"
    bl_options = {'REGISTER', 'UNDO'}
    onlyGround:bpy.props.BoolProperty(default=False,name="Snap only to ground objects")
    flip:bpy.props.BoolProperty(default=False,name="Flip")
    location:bpy.props.FloatProperty(default=0,name='Location Randomise')
    ctrl:bpy.props.BoolProperty(default=False,name="Move Followed By Rotation(Bounding Box)")
    alt:bpy.props.BoolProperty(default=False,name="Only Location(Bounding Box)")
    shift:bpy.props.BoolProperty(default=False,name="Rotate Followed By Move(Bounding Box)")
    @classmethod
    def description(cls,context,properties):
        if properties.onlyGround:
            return translate_text("Snap Selected Objects To Objects Marked as Ground")
        else:
            return translate_text("Snap Selected Objects To First Object Below")
    def draw(self,context):
        layout=self.layout
        layout.prop(self,'onlyGround')
        layout.prop(self,'flip')
        layout.prop(self,'location')
        layout.prop(self,'ctrl')
        layout.prop(self,'alt')
        layout.prop(self,'shift')
    def execute(self, context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()

        for obj in context.selected_objects:
            obj.location=[obj.location[0]+random.uniform(0,self.location) ,obj.location[1]+random.uniform(0,self.location) ,obj.location[2]]
            if obj.type in {'MESH','CURVE','SURFACE'} or True:
                evaluated_obj=obj.evaluated_get(depsgraph)
                mx = obj.matrix_world
                if obj.type=='EMPTY' :
                    if obj.empty_display_type in {'CUBE','SPHERE','CONE'}:
                        obj.rotation_euler.x=0
                        obj.rotation_euler.y=0
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        minz-=obj.empty_display_size*obj.scale.z
                        minz-=0.01
                        origin=(obj.location[0],obj.location[1],minz)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.location.z-=minz-location[2]
                        depsgraph.update()
                        evaluated_obj=obj.evaluated_get(depsgraph)
                        mx = obj.matrix_world
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        minz-=obj.empty_display_size*obj.scale.z
                        origin=(obj.location[0],obj.location[1],minz-0.01)
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        z = Vector((0,0,1))
                        if self.flip:
                            normal=-1*normal
                        if normal!=Vector((0,0,0)):
                            rot = z.rotation_difference( normal ).to_euler()
                            obj.rotation_euler= rot
                            depsgraph.update()
                    else:
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        obj.location.z-=minz-location[2]
                else:
                    if self.ctrl:
                        
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        obj.location.z-=minz-location[2]
                        depsgraph.update()
                        evaluated_obj=obj.evaluated_get(depsgraph)
                        mx = obj.matrix_world
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        z = Vector((0,0,1))
                        if self.flip:
                            normal=-1*normal
                        if normal!=Vector((0,0,0)):
                            rot = z.rotation_difference( normal ).to_euler()
                            obj.rotation_euler= rot
                            depsgraph.update()
                    
                    elif self.alt:
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        obj.location.z-=minz-location[2]
                    elif self.shift:
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        z = Vector((0,0,1))
                        if self.flip:
                            normal=-1*normal
                        if normal!=Vector((0,0,0)):
                            rot = z.rotation_difference( normal ).to_euler()
                            obj.rotation_euler= rot
                            depsgraph.update()
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        obj.location.z-=minz-location[2]
                    else:
                        
                        obj.rotation_euler.x=0
                        obj.rotation_euler.y=0
                        minz = min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box])
                        origin=(obj.location[0],obj.location[1],minz)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                            
                        obj.hide_viewport=False
                        z = Vector((0,0,1))
                        if self.flip:
                            normal=-1*normal
                        if normal!=Vector((0,0,0)):
                            rot = z.rotation_difference( normal ).to_euler()
                            obj.rotation_euler= rot
                            depsgraph.update()
                        depsgraph.update()
                        mx = obj.matrix_world 
                        mini=Vector((1,1,1000000))
                        if obj.type in {'MESH'}:
                            for v in evaluated_obj.data.vertices:
                                    a=mx@v.co
                                    if a[2]<mini[2]:
                                        mini=a
                        else:
                            mini=(obj.location[0],obj.location[1],min([(obj.matrix_world @Vector(corner))[2] for corner in obj.bound_box]))
                        #x,y=obj.location[0]-mini[0],obj.location[1]-mini[1]
                        #print(x,y)
                        obj.hide_viewport=True
                        (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,mini,(0,0,-1))
                        while((object is not None and not object.isGround and self.onlyGround) or object == obj):
                            origin=(location[0],location[1],location[2]-0.001)
                            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,origin,(0,0,-1))
                        obj.hide_viewport=False
                        obj.location.z-=mini[2]-location[2]
                    obj.select_set(True)
                        #obj.location.x-=x
                        #obj.location.y-=y
        
        return{'FINISHED'}
    def invoke(self, context,event):
            self.ctrl=event.ctrl
            self.alt=event.alt
            self.shift=event.shift
            return self.execute(context)
class RTOOLS_OT_Spin_Ninty(bpy.types.Operator):
    bl_idname = "rtools.spinninty"
    bl_label = "Spin 90"
    bl_description="Spin 90"
    bl_options = {'REGISTER', 'UNDO'}
    def invoke(self, context,event):
        #region = context.region
        #rv3d = context.region_data
        #coord = event.mouse_region_x,event.mouse_region_y
        #view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        #print(view_vector)
        #if abs(view_vector.x)>abs(view_vector.y):
        #    axis=0
        #    sign=-1 if abs(view_vector.y)<0.5 else 1
        #    sign=-sign if view_vector.x<0 else sign
        #else:
        #    axis=1
        #    sign=-1 if abs(view_vector.x)<0.5 else 1
        #    sign=sign if view_vector.y<0 else -sign
            
        normal=[v.normal for v in bmesh.from_edit_mesh(context.active_object.data).verts if v.select][0]

        viewRot=eulerToDegree(bpy.context.region_data.view_matrix.transposed().to_euler())
        if (viewRot[2]<45 and viewRot[2]>-45) or (viewRot[2]>145 and viewRot[2]<180) or (viewRot[2]<-145 and viewRot[2]>-180):
            axis=1
            if viewRot[2]<45 and viewRot[2]>=0:
                sign=-1
            elif viewRot[2]<0 and viewRot[2]>-45:
                sign=1
            elif viewRot[2]>145 and viewRot[2]<180:
                sign=-1
            else:
                sign=1

        else:
            axis=0
            if viewRot[2]>=45 and viewRot[2]<90:
                sign=1
            elif viewRot[2]<-45 and viewRot[2]>=-90:
                sign=1
            elif viewRot[2]>90 and viewRot[2]<=135:
                sign=-1
            elif viewRot[2]<-90 and viewRot[2]>=-135:
                sign=-1
        axis_2=0 if axis==1 else 1
        selected=[v.co.to_tuple() for v in bmesh.from_edit_mesh(context.active_object.data).verts if v.select]
        center=sorted(selected,key =lambda v:v[axis_2])[-1] if sign==1 else sorted(selected,key =lambda v:v[axis_2])[0]
        
        #bpy.context.scene.cursor.location=center
        if axis==0:
            sign*=-1
        if normal.z>0:
            sign*=-1
        bpy.ops.mesh.spin(angle=math.radians(sign*90), center=center, axis=(1, 0, 0) if axis==0 else (0,1,0))

        return {'FINISHED'}
class RTOOLS_OT_Shade_Smooth(bpy.types.Operator):
    bl_idname = "rtools.shadesmooth"
    bl_label = "Shade Smooth"
    bl_description="Shade Smooth And Set Auto Smooth\nCTRL+LMB : Clear Split Normals"
    bl_options = {'REGISTER', 'UNDO'}
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"Auto Smooth Angle : {format(round(math.degrees(self.active.data.auto_smooth_angle),3),'0.3f')}"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y)
        draw_Text(context,0,preferences().font_size,text=[f"Hold CTRL : Adjust auto smooth angle"],alignH="RIGHT")
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and context.active_object
    def modal(self, context,event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        if event.mouse_x>context.region.x+context.region.width-5:
            self.smooth_angle_copy=self.active.data.auto_smooth_angle
            context.window.cursor_warp(context.region.x,event.mouse_y)
            
            self.init_x=context.region.x
        if event.mouse_x<context.region.x+2:
            self.smooth_angle_copy=self.active.data.auto_smooth_angle
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.init_x=context.region.x+context.region.width
            
        if event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.smooth_angle_copy=self.active.data.auto_smooth_angle
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=5 
        if event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            self.smooth_angle_copy=self.active.data.auto_smooth_angle
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=2
            elif event.value == 'RELEASE':
                self.speed=5 
        if event.type=='MOUSEMOVE' and event.ctrl:
            self.active.data.auto_smooth_angle=self.smooth_angle_copy-(self.init_x-event.mouse_x)/((200 *self.speed))  
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='RIGHTMOUSE' or event.type=='ESC':
            self.active.data.auto_smooth_angle=self.init_angle
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='MIDDLEMOUSE':
            return {'PASS_THROUGH'}
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        active=bpy.context.active_object
        self.speed=5
        self.active=active
        bpy.ops.object.shade_smooth()
        self.init_x=event.mouse_x
        
        if active.type=='MESH':
            if event.ctrl:
                bpy.ops.mesh.customdata_custom_splitnormals_clear()
                return {'FINISHED'}
            active.data.use_auto_smooth=True
            self.smooth_angle_copy=active.data.auto_smooth_angle
            self.init_angle=active.data.auto_smooth_angle
            self.add_drawHandler(context)
            context.window_manager.modal_handler_add(self)
            
            return {'RUNNING_MODAL'}    
        else:
            return {'FINISHED'}
class RTOOLS_OT_Display_Type(bpy.types.Operator):
    bl_idname = "rtools.switchdisplaytype"
    bl_label = "Switch Display Type"
    bl_description="Switch Object Display Type: (Wire/Solid)\nCTRL+LMB:Bounds"
    bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and context.active_object
    def invoke(self, context, event):
        active=bpy.context.active_object
        if event.ctrl:
            active.display_type='BOUNDS'
        else:
            active.display_type='SOLID' if active.display_type!='SOLID' else 'WIRE'
        return {'FINISHED'}       
class RTOOLS_OriginToGeometryWithModifiers(bpy.types.Operator):
    bl_idname = "rtools.origintogeometrywithmodifiers"
    bl_label = "Origin To Geometry"
    bl_description="Set Origin To Geometry Calculated After Considering Modifiers"
    bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def execute(self, context):
        
        active=bpy.context.active_object
        #dup=duplicate_object(tocopy=active,col=None)
        dup=active.evaluated_get(context.evaluated_depsgraph_get())
        #apply_all_modifiers(dup,onlyVisible=True)
        meanX=mean([(dup.matrix_world @ v.co).x for v in dup.data.vertices]) if dup.type=="MESH" else dup.location[0]
        meanY=mean([(dup.matrix_world @ v.co).y for v in dup.data.vertices]) if dup.type=="MESH" else dup.location[1]
        meanZ=mean([(dup.matrix_world @ v.co).z for v in dup.data.vertices]) if dup.type=="MESH" else dup.location[2]
        #delete_object(dup)
        cursorLocBackUp=context.scene.cursor.location.copy()
        context.scene.cursor.location = (meanX,meanY,meanZ)
        select(active,active=True)
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        context.scene.cursor.location=cursorLocBackUp
        return {'FINISHED'}

def recursive_visibility_match_rtv(col):
    for a in col.children:
        bpy.data.collections[a.name].hide_render=a.hide_viewport or bpy.data.collections[a.name].hide_viewport
        recursive_visibility_match_rtv(a)
def recursive_visibility_match_vtr(col):
    for a in col.children:
        a.hide_viewport=bpy.data.collections[a.name].hide_render
        recursive_visibility_match_vtr(a)
class RTOOLS_Match_Visiblity(bpy.types.Operator):
    bl_idname = "rtools.matchvisiblity"
    bl_label = "Match Viewport and Render Visiblity"
    bl_description = "Match  Render Visiblity To Viewport Visiblity\nCTRL+LMB: Match Viewport Visiblity To Render Visiblity"
    bl_options = {'REGISTER', 'UNDO'}
    def invoke(self, context,event):
        if not event.ctrl:
            for ob in bpy.data.objects:
                ob.hide_render=ob.hide_get() or ob.hide_viewport
                #ob.hide_viewport=ob.hide_get()
            vlayer = bpy.context.scene.view_layers[0]
            recursive_visibility_match_rtv(vlayer.layer_collection)
        else:
            for ob in bpy.data.objects:
                ob.hide_set(ob.hide_render)
                #ob.hide_viewport=ob.hide_render
            vlayer = bpy.context.scene.view_layers[0]
            recursive_visibility_match_vtr(vlayer.layer_collection)     
        return {'FINISHED'}
class RTOOLS_OT_Add_Tube(bpy.types.Operator):
    bl_idname = "rtools.addtube"
    bl_label = "Create Tube"
    bl_description = "Create Non Destructive Tube"
    bl_options = {"REGISTER","UNDO"}
    radius:bpy.props.FloatProperty(default=0.5)
    resolution:bpy.props.IntProperty(default=16)
    thickness: bpy.props.FloatProperty(default=0.2)
    length:bpy.props.FloatProperty(default=1)
    count: bpy.props.IntProperty(default=16)
    def execute(self, context):
        
        
        circle=createvert(context)
        select(circle)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        circle.name="Tube"
        circle.data.use_auto_smooth=True
        circle.instance_type='VERTS'
        displaceMod=circle.modifiers.new(type='DISPLACE',name="RT_ST_Displace")
        displaceMod.show_expanded=False
        displaceMod.direction='X'
        displaceMod.strength=self.radius
        displaceMod.mid_level=0
        displaceMod.show_expanded=False
        screwMod=circle.modifiers.new(type='SCREW',name="RT_ST_Screw")
        screwMod.show_expanded=False
        screwMod.use_merge_vertices=True
        screwMod.steps=self.count
        screwMod.render_steps=self.count
        screwMod.show_expanded=False
        screwMod2=circle.modifiers.new(type='SCREW',name="RT_ST_Screw_2")
        screwMod2.show_expanded=False
        screwMod2.use_merge_vertices=True
        screwMod2.angle=0
        screwMod2.screw_offset=self.length
        screwMod2.steps=self.resolution
        screwMod2.render_steps=self.resolution
        screwMod2.show_expanded=False
        solidifyMod=circle.modifiers.new(type='SOLIDIFY',name="RT_ST_Solidify")
        solidifyMod.show_expanded=False
        solidifyMod.thickness=self.thickness
        solidifyMod.offset=1
        solidifyMod.show_expanded=False
        return {'FINISHED'}
class RTOOLS_OT_Dice(bpy.types.Operator):
    bl_idname = "rtools.dice"
    bl_label = "Dice"
    bl_description = "Dice Object From View Angle"
    bl_options = {"REGISTER","UNDO"}
    enum_items=[('Horizontal','Horizontal',"Horizontal"),('Vertical','Vertical','Vertical')]
    axis:bpy.props.EnumProperty(items=enum_items,name="Axis",default='Vertical')
    segments:bpy.props.IntProperty(default=16,name="Dicing Scale",min=0,max=500)
    scaleX: bpy.props.FloatProperty(default=1,name='Size X',step=1)
    scaleY: bpy.props.FloatProperty(default=1,name='Size Y',step=1)
    dissolve:bpy.props.BoolProperty(default=False,name="Limited Dissolve")
    cut_through:bpy.props.BoolProperty(default=False,name="Cut Through")
    origin_to_geometry:bpy.props.BoolProperty(default=True,name="Align To Geometry")
    tX:bpy.props.FloatProperty(default=0,name="Offset X")
    tY:bpy.props.FloatProperty(default=0,name="Offset Y")
    remove_doubles:bpy.props.BoolProperty(default=True,options={'SKIP_SAVE','HIDDEN'})
    @classmethod
    def poll(cls,context):
        return context.active_object is not None and context.active_object.type=='MESH' and context.mode=='OBJECT'
    def execute(self, context):
        obj=context.active_object
        if self.dissolve:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all( action = 'SELECT' )
            bpy.ops.mesh.dissolve_limited()
            bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(2, 1, 1))
        bpy.ops.object.editmode_toggle()
        

        if self.axis=='Horizontal':
            bpy.ops.mesh.loopcut_slide(MESH_OT_loopcut={"number_cuts":self.segments, "smoothness":0, "falloff":'INVERSE_SQUARE', "object_index":0, "edge_index":0,})
        else:
            bpy.ops.mesh.loopcut_slide(MESH_OT_loopcut={"number_cuts":self.segments, "smoothness":0, "falloff":'INVERSE_SQUARE', "object_index":0, "edge_index":1,})
        bpy.ops.object.editmode_toggle()
        bbverts = [obj.matrix_world @
               Vector(corner) for corner in obj.bound_box]
        meanX = mean([v[0] for v in bbverts])
        meanY = mean([v[1] for v in bbverts])
        meanZ = mean([v[2] for v in bbverts])

        plane=context.active_object
        plane.scale=(self.scaleX,self.scaleY,self.scaleY)
        plane.rotation_euler=bpy.context.region_data.view_matrix.transposed().to_euler()
        plane.location=(meanX,meanY,meanZ) if self.origin_to_geometry else obj.location
        bpy.ops.transform.translate(value=(self.tX,self.tY,0), orient_type='VIEW', orient_matrix_type='VIEW', mirror=True)
        #bevelMod=plane.modifiers.new(type='BEVEL',name='RT_Bevel_Dice')
        #bevelMod.show_expanded=False
        #bevelMod.width=100
        #bevelMod.segments=self.segments+1
        #bevelMod.limit_method='NONE'
        #bpy.ops.object.modifier_apply(modifier=bevelMod.name)
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all( action = 'SELECT' )
        bpy.ops.mesh.delete(type='ONLY_FACE')
        bpy.ops.object.editmode_toggle()
        deselect_all()
        select(obj,active=True)
        bpy.ops.object.editmode_toggle()
        select(plane,active=False)
        bpy.ops.mesh.knife_project(cut_through=self.cut_through)
        bpy.ops.mesh.select_all( action = 'SELECT' )
        if self.remove_doubles:
            #print("Remove")
            bpy.ops.mesh.remove_doubles(threshold=0.0001)
        bpy.ops.mesh.select_all( action = 'DESELECT' )
        bpy.ops.object.editmode_toggle()
        delete_object(plane)
        return {'FINISHED'}
    def invoke(self, context, event):
        bpy.context.space_data.overlay.show_wireframes = True

        obj=context.active_object
        maxDim=max(obj.dimensions[:])
        maxDim/=1.99
        self.scaleX=obj.dimensions[0]/1.99
        self.scaleY=obj.dimensions[1]/1.99
        self.tX,self.tY=0,0
        return self.execute(context)
class RTOOLS_OT_Circle_Array(bpy.types.Operator):
    bl_idname = "rtools.circlearray"
    bl_label = "Instance Circular Array"
    bl_description = "Create Instance Based Circular Array"
    bl_options = {"REGISTER","UNDO"}
    radius:bpy.props.FloatProperty(default=1,name="Radius")
    offset:bpy.props.FloatProperty(default=0,name="Offset")
    count:bpy.props.IntProperty(default=16,name="Count",min=1)
    shrinkwrap:bpy.props.BoolProperty(default=False,name="Shrinkwrap")
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT'

    def execute(self, context):
        objToWrapArround=context.active_object
        if self.selected_count==1:
            obj=objToWrapArround
        else:
            obj=Diff(context.selected_objects,[objToWrapArround])[0]
        ob = bpy.data.objects.get(obj.name)
        ob_dup = ob.copy()
        bpy.context.collection.objects.link(ob_dup)
        obj.rotation_euler=objToWrapArround.rotation_euler
        obj.location=objToWrapArround.location
        #bpy.ops.object.mode_set(mode='OBJECT')
        circle=createvert(context)
        #circle=context.active_object
        circle.location=obj.location
        circle.rotation_euler=objToWrapArround.rotation_euler
        deselect_all()
        select(obj)
        select(circle,active=True)
        bpy.ops.object.parent_set()
        obj.hide_view=True
        circle.instance_type='VERTS'
        circle.show_instancer_for_viewport=False
        circle.show_instancer_for_render=False
        circle.use_instance_vertices_rotation=True
        displaceMod=circle.modifiers.new(type='DISPLACE',name="RT_ST_Displace")
        displaceMod.show_expanded=False
        displaceMod.direction='X'
        displaceMod.strength=self.radius
        displaceMod.mid_level=0
        screwMod=circle.modifiers.new(type='SCREW',name="RT_ST_Screw")
        screwMod.show_expanded=False
        screwMod.use_merge_vertices=True
        screwMod.steps=self.count
        screwMod.render_steps=self.count
        if self.selected_count>1 and self.shrinkwrap:
            shrinkwrap=circle.modifiers.new(type='SHRINKWRAP',name='RT_Shrink')
            shrinkwrap.wrap_method="TARGET_PROJECT"
            shrinkwrap.wrap_mode="ABOVE_SURFACE"
            shrinkwrap.show_expanded=False
            shrinkwrap.target=objToWrapArround
            shrinkwrap.offset=self.offset
        return {"FINISHED"}
    def invoke(self, context, event):
        self.selected_count=len(context.selected_objects)
        objToWrapArround=context.active_object
        if len(context.selected_objects)<=1:
            obj=objToWrapArround
        else:
            obj=Diff(context.selected_objects,[objToWrapArround])[0]
        self.radius=math.sqrt(sum(i**2 for i in obj.location-objToWrapArround.location))
        self.radius=self.radius if self.radius!=0 else 1
        return self.execute(context)
class RTOOLS_OT_Project_From_View(bpy.types.Operator):
    bl_idname = "rtools.projectfromview"
    bl_label = "Project From View (Correct Aspect Ratio)"
    bl_description = "Project From View with Correct Aspect Ratio"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        bpy.ops.uv.project_from_view(camera_bounds=False, correct_aspect=True, scale_to_bounds=False)
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        uv_layer = bm.loops.layers.uv.verify()
        size=[1,1]
        for area in bpy.context.screen.areas :
            if area.type == 'IMAGE_EDITOR' :
                if area.spaces.active.image is not None :
                    size=area.spaces.active.image.size
        ScaleMatrix = Matrix.Diagonal((size[1]/size[0],1))
        for face in bm.faces:
            if face.select:
                for loop in face.loops:
                    loop_uv = loop[uv_layer]
                    loop_uv.uv=Vector((loop_uv.uv[0]-0.5,loop_uv.uv[1]-0.5))
                    loop_uv.uv = loop_uv.uv@ScaleMatrix
                    loop_uv.uv=Vector((loop_uv.uv[0]+1/2,loop_uv.uv[1]+1/2))
        bmesh.update_edit_mesh(me)
        return {"FINISHED"}
class RTOOLS_OT_Slice(bpy.types.Operator):
    bl_idname = "rtools.slice"
    bl_label = "Slice Object"
    bl_description = "Slice Object using a Plane"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        
        obj=context.active_object
        boolMod=obj.modifiers.new(name="RT_Slice",type="BOOLEAN")
        boolMod.use_self=True
        boolMod.show_expanded=False
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        plane=context.active_object
        #solidifyMod=plane.modifiers.new(name="RT_Solidify",type='SOLIDIFY')
        #solidifyMod.show_viewport=False
        #solidifyMod.show_render=False
        #solidifyMod.show_in_editmode=False
        #solidifyMod.thickness=20
        plane.display_type='WIRE'
        plane.location=obj.location
        plane.dimensions=[max(obj.dimensions[:])*2,max(obj.dimensions[:])*2,max(obj.dimensions[:])*2]
        boolMod.object=plane
        return {"FINISHED"}
class RTOOLS_OT_Break(bpy.types.Operator):
    bl_idname = "rtools.break"
    bl_label = "Add Keyframes at Hit Point"
    bl_description = "Add Keyframes at Hit Point"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        bpy.context.scene.frame_set(0)
        bpy.ops.screen.animation_cancel()
        obj=context.active_object
        context.scene.rt_tools.brokenObjs.clear()
        broken_objs=Diff(context.selected_objects,[obj])
        context.scene.rt_tools.ogObj=obj
        if any(map(lambda x:x.rigid_body is None,broken_objs)):
            self.report({'WARNING'},"All Objects Need To Have Rigid Body")
            return {'CANCELLED'}
        for o in broken_objs:
            t=context.scene.rt_tools.brokenObjs.add()
            t.obj=o
        for broken_obj in broken_objs:
                broken_obj.hide_viewport=True
                broken_obj.hide_render=True
                broken_obj.hide_view=True
                broken_obj.rigid_body.collision_collections=[False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True]
                broken_obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current)
                broken_obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current)

        bpy.app.handlers.frame_change_post.clear()
        bpy.app.handlers.frame_change_post.append(Break)
        bpy.ops.screen.animation_play()
        return {"FINISHED"}
class RTOOLS_OT_Break_Op(bpy.types.Operator):
    bl_idname = "rtools.breakoperator"
    bl_label = "Break Operator"
    bl_description = "Break Operator"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()
        obj=context.scene.rt_tools.ogObj
        broken_objs=context.scene.rt_tools.brokenObjs
        hitting_obj=context.scene.rt_tools.hittingObject
        if obj is not None and broken_objs is not None and hitting_obj is not None:
            hitting_obj.rigid_body.collision_collections=[False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True]
            evaluated_obj=obj.evaluated_get(depsgraph)
            hitting_obj=hitting_obj.evaluated_get(depsgraph)
            bm1 = bmesh.new()
            bm2 = bmesh.new()
            bm1.from_mesh(evaluated_obj.data)
            bm2.from_mesh(hitting_obj.data)
            bm1.transform(evaluated_obj.matrix_world)
            bm2.transform(hitting_obj.matrix_world)
            obj1BVHtree = BVHTree.FromBMesh(bm1)
            obj2BVHtree = BVHTree.FromBMesh(bm2)
            intersections=obj1BVHtree.overlap(obj2BVHtree)
            
            if len(intersections)>0:
                self.report({'INFO'},f"Hit Frame: {context.scene.frame_current}")
                for broken_obj in [o.obj for o in broken_objs]:
                    broken_obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current-1)
                    broken_obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current-1)
                
                obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current-1)
                obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current-1)
                obj.hide_viewport=True
                obj.hide_render=True
                for broken_obj in [o.obj for o in broken_objs]:
                    broken_obj.hide_viewport=False
                    broken_obj.hide_render=False
                    broken_obj.hide_view=False
                    broken_obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current)
                    broken_obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current)
                obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current)
                obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current)
                context.scene.rt_tools.brokenObjs.clear()
                bpy.app.handlers.frame_change_post.clear()
                
        return {"FINISHED"}
class RT_Break_Op2(bpy.types.Operator):
    bl_idname = "rtools.breakoperator"
    bl_label = "Break Operator"
    bl_description = "Break Operator"
    bl_options = {"REGISTER","UNDO"}
    def execute(self,context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()
        obj=context.scene.rt_tools.ogObj
        broken_objs=context.scene.rt_tools.brokenObjs

        if obj is not None and broken_objs is not None:
            
            evaluated_obj=obj.evaluated_get(depsgraph)
            mx = obj.matrix_world 
            mini=Vector((1,1,1000000))
            if obj.type in {'MESH','CURVE','SURFACE'}:
                for v in evaluated_obj.data.vertices:
                        a=mx@v.co
                        if a[2]<mini[2]:
                            mini=a
            mini=[mini[0],mini[1],mini[2]-0.01]
            (result, location, normal, index, object, matrix)=bpy.context.scene.ray_cast(depsgraph,mini,(0,0,-1))
            if object is not None:
                object.rigid_body.collision_collections=[False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True]
                #object.rigid_body.collision_collections[0]=False
            distance=mini[2]-location[2]
            if distance <= 0.03:
                self.report({'INFO'},f"Hit Frame: {context.scene.frame_current}")
                for broken_obj in [o.obj for o in broken_objs]:
                    broken_obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current-1)
                    broken_obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current-1)
                
                obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current-1)
                obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current-1)
                obj.hide_viewport=True
                obj.hide_render=True
                for broken_obj in [o.obj for o in broken_objs]:
                    broken_obj.hide_viewport=False
                    broken_obj.hide_render=False
                    broken_obj.hide_view=False
                    broken_obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current)
                    broken_obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current)
                obj.keyframe_insert(data_path="hide_viewport", frame=context.scene.frame_current)
                obj.keyframe_insert(data_path="hide_render", frame=context.scene.frame_current)
                context.scene.rt_tools.brokenObjs.clear()
                bpy.app.handlers.frame_change_post.clear()
                
        return {"FINISHED"}
class RTOOLS_OT_Add_Lattice(bpy.types.Operator):
    bl_idname = "rtools.addlattice"
    bl_label = "Add Lattice"
    bl_description = "Add Lattice and Lattice Modifier"
    bl_options = {"REGISTER","UNDO"}
    resolution:bpy.props.IntVectorProperty(size=3,default=[2,2,2])
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def execute(self,context):
        obj=context.active_object.evaluated_get(bpy.context.evaluated_depsgraph_get())
        og_obj=context.active_object
        bbverts = [obj.matrix_world @
               Vector(corner) for corner in obj.bound_box]
        #print(obj.bound_box)
        if obj.parent:
            bbverts=[obj.parent.matrix_world @
               Vector(corner) for corner in bbverts]
        meanX = mean([v[0] for v in bbverts])
        meanY = mean([v[1] for v in bbverts])
        meanZ = mean([v[2] for v in bbverts])
        #print(meanX,meanZ,meanY)       
        bpy.ops.object.add(type='LATTICE')
        lattice=context.active_object
        lattice.location=(meanX,meanY,meanZ)
        lattice.scale=[a for a in obj.dimensions[:]]
        lattice.rotation_euler=obj.rotation_euler
        lattice.data.points_u=self.resolution[0]
        lattice.data.points_v=self.resolution[1]
        lattice.data.points_w=self.resolution[2]
        #bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        lattice_mod=og_obj.modifiers.new(type='LATTICE',name='RT_Lattice')
        lattice_mod.object=lattice
        lattice_mod.show_expanded=False
        return {'FINISHED'}
class RTOOLS_OT_Taper(bpy.types.Operator):
    bl_idname = "rtools.taper"
    bl_label = "Taper"
    bl_description = "Taper Object Using Lattice"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"A: Apply ({'Yes' if self.apply else 'NO'})",f"X/Y/Z: Axis ({self.axis})"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y,activeKey=self.activeKey)
        
    def execute(self,context):
        obj=context.active_object.evaluated_get(bpy.context.evaluated_depsgraph_get())
        og_obj=context.active_object
        self.obj=og_obj
        bbverts = [obj.matrix_world @
               Vector(corner) for corner in obj.bound_box]
        #print(obj.bound_box)
        if obj.parent:
            bbverts=[obj.parent.matrix_world @
               Vector(corner) for corner in bbverts]
        meanX = mean([v[0] for v in bbverts])
        meanY = mean([v[1] for v in bbverts])
        meanZ = mean([v[2] for v in bbverts])
        #print(meanX,meanZ,meanY)       
        bpy.ops.object.add(type='LATTICE')
        lattice=context.active_object
        lattice.location=(meanX,meanY,meanZ)
        lattice.scale=[a for a in obj.dimensions[:]]
        lattice.rotation_euler=obj.rotation_euler
        
        lattice.data.points_u=2
        lattice.data.points_v=2
        lattice.data.points_w=2
        #bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        lattice_mod=og_obj.modifiers.new(type='LATTICE',name='RT_Lattice')
        lattice_mod.object=lattice
        lattice_mod.strength=2
        lattice_mod.show_expanded=False
        self.lattice_mod=lattice_mod
        bpy.ops.object.editmode_toggle()
        lattice.data.points[0].select=True
        lattice.data.points[2].select=True
        lattice.data.points[1].select=True
        lattice.data.points[3].select=True
        lattice.data.interpolation_type_u='KEY_LINEAR'
        lattice.data.interpolation_type_v='KEY_LINEAR'
        lattice.data.interpolation_type_w='KEY_LINEAR'
        initObjects=[o for o in bpy.data.objects]
        bpy.ops.object.hook_add_newob()
        self.empty=Diff(initObjects,bpy.data.objects)[0]
        
        self.scaleCopy=self.empty.scale.copy()
        bpy.ops.object.editmode_toggle()
        
        self.lattice=lattice
        select(lattice)
        select(self.obj)
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        bpy.ops.object.select_all( action='DESELECT')
        select(self.empty)
        select(lattice)
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        
        self.empty.hide_view=True
        lattice.hide_view=True
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        self.mouse_x=event.mouse_x
        self.mouse_y=event.mouse_y
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.scaleCopy=self.empty.scale.copy()
            self.init_x=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.init_x=context.region.x+context.region.width
            self.scaleCopy=self.empty.scale.copy()
        if event.type=='X':
            if event.value=='PRESS':
                self.axis='X' if self.axis!='X' else "All"
                self.init_x=event.mouse_x
                self.scaleCopy=self.empty.scale.copy()
                self.activeKey='X'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        if event.type=='Y':
            if event.value=='PRESS':
                self.axis='Y' if self.axis!='Y' else "All"
                self.init_x=event.mouse_x
                self.scaleCopy=self.empty.scale.copy()
                self.activeKey='Y'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        if event.type=='Z':
            if event.value=='PRESS':
                self.axis='Z' if self.axis!='Z' else "All"
                self.init_x=event.mouse_x
                self.scaleCopy=self.empty.scale.copy()
                self.activeKey='Z'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        if event.type=='MOUSEMOVE':
            if self.axis=='X':
                self.empty.scale.x=self.scaleCopy.x+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
            elif self.axis=='Y':
                self.empty.scale.y=self.scaleCopy.y+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
            elif self.axis=='Z':
                self.empty.scale.z=self.scaleCopy.z+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
            else:
                self.empty.scale.x=self.scaleCopy.x+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
                self.empty.scale.y=self.scaleCopy.y+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
                self.empty.scale.z=self.scaleCopy.z+(self.init_x-event.mouse_x)/(100 if not event.shift else 1000)
            context.area.tag_redraw()
        if event.type=='BACK_SPACE' and event.value=='PRESS':
            if self.axis=='X':
                self.empty.scale.x=1
            elif self.axis=='Y':
                self.empty.scale.y=1
            elif self.axis=='Z':
                self.empty.scale.z=1
            else:
                self.empty.scale.x=1
                self.empty.scale.y=1
                self.empty.scale.z=1
            self.init_x=event.mouse_x
            self.scaleCopy=self.empty.scale.copy()
            context.area.tag_redraw()
        if event.type=='A':
            if event.value=='PRESS':
                self.apply=not self.apply
                self.activeKey='A'
            else:
                self.activeKey=None
            context.area.tag_redraw()
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            if self.apply:
                smart_apply_modifiers(self.obj)
                bpy.ops.object.modifier_apply({'object':self.obj},modifier=self.lattice_mod.name)
                delete_object(self.lattice)
                delete_object(self.empty)
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='RIGHTMOUSE' and event.value=='PRESS':
            self.remove_drawHandler(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.init_x=event.mouse_x
        self.axis='All'
        self.mouse_x=event.mouse_x
        self.mouse_y=event.mouse_y
        #self.apply=context.active_object.display_type=='WIRE'
        self.apply=False
        self.activeKey=None
        return self.execute(context)
class RTOOLS_OT_Material_Picker(bpy.types.Operator):
    bl_idname = "rtools.materialpick"
    bl_label = "Material Transfer"
    bl_description = "Transfer materials from one face to other\nCTRL+LMB: Select All objects with the selected Material"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    
    def execute(self, context):
        scene = context.scene
        region = context.region
        rv3d = context.region_data
        coord = self.X,self.Y
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        hidden_objs=[]
        while ( object and (not object.visible_get() or object.type!='MESH') ):
            
            hidden_objs.append((object,object.hide_get()))
            object.hide_view=True
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
        for o,s in hidden_objs:
            o.hide_view=s
        def fade_out(area):
            self.color=(self.color[0],self.color[1],self.color[2],self.alpha)
            self.alpha-=0.1
            area.tag_redraw()
            if self.alpha<0:
                self.fade_done=True
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                return None
            return 0.02
        if self.mat is None and object is not None:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            depsgraph.update()
            evaluated_object=object.evaluated_get(depsgraph)
            
            if len(object.data.materials)>0:
                self.mat=object.data.materials[evaluated_object.data.polygons[index].material_index]
                self.color=(0,1,0,0.6)
                if self.ctrl:
                    for o in context.scene.objects:
                        if o.type in {'MESH','CURVE','SURFACE','TEXT'}:
                            if self.mat.name in [a.name for a in o.data.materials]:
                                select(o)
                    self.alpha=1
                    self.timer_started=True
                    bpy.app.timers.register(functools.partial(fade_out,context.area))
                    return {'FINISHED'}
            else:
                self.report({'WARNING'},'No Material Found')
            
        elif self.mat is not None and object is not None:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            depsgraph.update()
            evaluated_object=object.evaluated_get(depsgraph)
            
            if len(object.data.materials)>0:
                object.data.materials[evaluated_object.data.polygons[index].material_index]=self.mat
            else:
                object.data.materials.append(self.mat)
            object.data.update()
            depsgraph = bpy.context.evaluated_depsgraph_get()
            depsgraph.update()
            self.alpha=1
            self.timer_started=True
            bpy.app.timers.register(functools.partial(fade_out,context.area))
            #bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            #return {'FINISHED'}
            
            
        return {'RUNNING_MODAL'}
    def modal(self,context,event):
        if self.fade_done:
                return {'FINISHED'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            
            self.X=event.mouse_region_x
            self.Y=event.mouse_region_y
            
            return self.execute(context)
        if event.type=='MOUSEMOVE' and  not self.timer_started:
            
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH') ):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_view=True
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_view=s
            if object is not None and object.type=='MESH':
                obj=object
                obj=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                #bm.verts.ensure_lookup_table()
                #bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
                coords = [obj.matrix_world@v.co for v in bm.verts]
                indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges if e in bm.faces[index].edges] 
                
                self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
                bm.free() 
            else:
                self.batch = None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS') or event.type=='ESC':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            return {'FINISHED'}
        else:
            
            return {'PASS_THROUGH'}
        #return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.ctrl=event.ctrl
        self.timer_started=False
        self.alpha=1
        self.fade_done=False
        bpy.ops.wm.tool_set_by_id(name="builtin.select")
        bpy.context.window.cursor_set("EYEDROPPER")
        context.window_manager.modal_handler_add(self)
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.color=(1,0,0,0.6)
        self.mat=None
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(4)
                gpu.state.blend_set("ALPHA") 
                gpu.state.depth_test_set("LESS")
                
                self.shader.bind()
                self.shader.uniform_float("color", self.color)
                self.batch.draw(self.shader)
                gpu.state.depth_test_set("NONE")
                gpu.state.blend_set("NONE")
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Object_Brush(bpy.types.Operator):
    bl_idname = "rtools.objectbrush"
    bl_label = "Place Copies"
    bl_description = "Click To Place Linked Copies Of Object"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def execute(self, context):
        self.obj=context.active_object
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.type=='RET' or event.type=='RIGHTMOUSE'and event.value=='PRESS':
            return {'FINISHED'}
        if event.type=='ESC' and event.value=='PRESS':
            for o in self.copies:
                delete_object(o)
            return {'FINISHED'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            scene= context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            while ( object and (not object.visible_get() or object.type!='MESH') ):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_view=True
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_view=s
            if object:
                
                dup=duplicate_linked(self.obj)
                self.copies.append(dup)
                dup.location = location
                z = Vector((0,0,1))
                if normal!=Vector((0,0,0)):
                    rot = z.rotation_difference( normal ).to_euler()
                    dup.rotation_euler= rot
                    bpy.context.evaluated_depsgraph_get().update()
            return {'RUNNING_MODAL'}
        elif event.ctrl and event.type=='Z':
            return {'RUNNING_MODAL'}
        else:
            return {'PASS_THROUGH'}
    def invoke(self, context, event):
        self.copies=[]
        return self.execute(context)
class RTOOLS_OT_Separate_Solidify(bpy.types.Operator):
    bl_idname = "rtools.separatesolidify"
    bl_label = "Plate"
    bl_description = "Separate and Solidify\nCTRL+LMB : Inset>P-Cutter\nSHIFT+LMB : Inset>Solidify"
    bl_options = {"REGISTER","UNDO"}
    
    def invoke(self, context, event):
        obj=context.active_object
        bm= bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        if [f for f in bm.faces if f.select]:
            bpy.ops.mesh.duplicate_move()
            bpy.ops.mesh.separate(type='SELECTED')
            bpy.ops.object.editmode_toggle()
            new_obj=Diff(context.selected_objects,[obj])[0]
            bpy.ops.object.select_all( action='DESELECT')
            select(new_obj)
            if event.ctrl:
                bpy.ops.rtools.insetshrink('INVOKE_DEFAULT',object=obj.name,inset_shrink_pcutter=True,inset_shrink_solidify=False)
            elif event.shift:
                bpy.ops.rtools.insetshrink('INVOKE_DEFAULT',object=obj.name,inset_shrink_pcutter=False,inset_shrink_solidify=True)
            else:
                bpy.ops.rtools.solidify('INVOKE_DEFAULT')
        return {'FINISHED'}
class RTOOLS_OT_Solidify(bpy.types.Operator):
    bl_idname = "rtools.solidify"
    bl_label = "Solidify"
    bl_description = "Solidify"
    bl_options = {"REGISTER","UNDO"}
    
    def execute(self, context):
        obj=context.active_object
        self.obj=obj
        self.solidifyMod=obj.modifiers.new(type='SOLIDIFY',name="RT_Solidify")
        self.solidifyMod.show_expanded=False
        self.solidifyMod.offset=1
        self.solidifyMod.use_even_offset=True
        self.solidifyMod.show_expanded=False
        self.thicknessSave=self.solidifyMod.thickness
        sort_modifiers(obj)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.thicknessSave=self.solidifyMod.thickness
            self.initX=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.initX=context.region.x+context.region.width
            self.thicknessSave=self.solidifyMod.thickness
        if event.type == 'LEFT_SHIFT':
            if event.value == "PRESS":
                self.speed =20
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type == 'LEFT_CTRL':
            if event.value == "PRESS":
                self.speed =1
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type=='MOUSEMOVE':
            self.solidifyMod.thickness=self.thicknessSave-(self.initX-event.mouse_x)/(100*self.speed)
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            
            return {'FINISHED'}
        if event.type=='RIGHTMOUSE' or event.type=='ESC' and event.value=='PRESS':
            delete_object_with_data(self.obj)
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        
        self.speed=3
        self.initX=event.mouse_x
        return self.execute(context)
class RTOOLS_OT_Inset_Boolean(bpy.types.Operator):
    bl_idname = "rtools.insetbool"
    bl_label = "Inset Boolean"
    bl_description = "Inset Boolean"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and len(context.selected_objects)==2
    def execute(self, context):
        obj=context.active_object
        bool=Diff(context.selected_objects,[obj])[0]
        obj_dup=duplicate_object(obj)
        self.extra_objects_created=[obj_dup,]
        for m in obj_dup.modifiers:
            if m.type=='BEVEL':
                bpy.ops.object.modifier_remove({'object':obj_dup},modifier=m.name)
        #apply_all_modifiers(obj_dup,'BEVEL')
        select(bool)
        select(obj_dup)
        select(obj)
        bpy.ops.object.parent_set()
        rt_cutters=get_collection(name='RT_Cutters')
        move_to_collection(obj_dup,rt_cutters)
        move_to_collection(bool,rt_cutters)
        bool.hide_render=True
        bool.hide_view=True
        obj_dup.hide_render=True
        obj_dup.hide_view=True
        bool.display_type='WIRE'
        obj_dup.display_type='WIRE'
        
        self.solidifyMod=obj_dup.modifiers.new(type='SOLIDIFY',name="RT_Inset_Bool_Solidify")
        self.solidifyMod.show_expanded=False
        self.solidifyMod.offset=0
        self.solidifyMod.use_even_offset=True
        self.solidifyMod.solidify_mode='NON_MANIFOLD'
        self.thicknessSave=self.solidifyMod.thickness
        
        boolMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Inset_Bool")
        boolMod.solver='FAST'
        boolMod.show_expanded=False
        boolMod.operation='INTERSECT'
        boolMod.object=bool
        self.obj=obj
        self.bool_obj=bool
        self.inset_solidify_mod=self.solidifyMod
        self.bool_mod=boolMod
        mod=obj.modifiers.new(type='BOOLEAN',name="RT_Inset_Bool")
        mod.object=obj_dup
        mod.solver='FAST'
        sort_modifiers(obj)
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        def fade_out(area):
            self.color=(self.color[0],self.color[1],self.color[2],self.alpha)
            self.alpha-=0.1
            area.tag_redraw()
            if self.alpha<0:
                self.fade_done=True
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                return None
            return 0.04
        if event.type == 'LEFT_SHIFT':
            if event.value == "PRESS":
                self.speed =20
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type == 'LEFT_CTRL':
            if event.value == "PRESS":
                self.speed =1
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type=='MOUSEMOVE':
            self.solidifyMod.thickness=self.thicknessSave+(self.initX-event.mouse_x)/(100*self.speed)
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            context.scene.rt_tools.last_cutter_object=self.obj
            
            t=self.obj.CuttersInfo.add()
            t.mods_applied=True
            t.direction=1
            t.center_location=self.bool_obj.location
            t.normal=Vector((1,1,1))
            t.last_cutter=self.bool_obj.name
            #if self.bool_obj.CutterId=="None":
            self.bool_obj.CutterId=get_id()
            t.cutter_id=self.bool_obj.CutterId
            t.name=self.bool_obj.CutterId
            #print("ID",self.bool_obj.CutterId)
            if self.extra_objects_created:
                if self.extra_objects_created[0].CutterId=="None":
                    self.extra_objects_created[0].CutterId=get_id()
                    #print("ID1",self.extra_objects_created[0].CutterId)
                t.cutter_extra_1=self.extra_objects_created[0].CutterId
            else:
                t.cutter_extra_1="Not"
            t.last_bool_type="INSET"
            t.last_mod_name=self.bool_mod.name if  self.bool_mod else ""
            context.scene.rt_tools.last_cutter_index=self.obj.CuttersInfo.find(self.bool_obj.CutterId)
            if self.inset_solidify_mod:
                t.last_inset_mod=self.inset_solidify_mod.name
            else:
                t.last_inset_mod=""
            obj=context.active_object.evaluated_get(bpy.context.evaluated_depsgraph_get())
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            #bm.verts.ensure_lookup_table()
            #bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            coords = [obj.matrix_world@v.co for v in bm.verts]
            indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges] 
            self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
            self.alpha=1
            self.timer_started=True
            bpy.app.timers.register(functools.partial(fade_out,context.area))
            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        if len(context.selected_objects)!=2:
            self.report({'WARNING'},'Select 2 Objects')
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        self.speed=3
        self.initX=event.mouse_x
        self.alpha=1
        self.timer_started=False
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.color=(1,0,0,0.6)
        self.mat=None
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(2)
                gpu.state.blend_set("ALPHA") 
                gpu.state.depth_test_set("LESS")
                
                self.shader.bind()
                self.shader.uniform_float("color", self.color)
                self.batch.draw(self.shader)
                gpu.state.depth_test_set("NONE")
                gpu.state.blend_set("NONE")
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        return self.execute(context)
class RTOOLS_OT_Slice_Boolean(bpy.types.Operator):
    bl_idname = "rtools.slicebool"
    bl_label = "Slice Boolean"
    bl_description = "Inset Boolean"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and len(context.selected_objects)==2
    def execute(self, context):
        obj=context.active_object
        bool=Diff(context.selected_objects,[obj])[0]
        obj_dup=duplicate_object(obj)
        bool_dup=duplicate_object(bool)
        self.extra_objects_created=[]
        self.extra_objects_created.append(bool_dup)
        self.extra_objects_created.append(obj_dup)
        #apply_all_modifiers(obj_dup,'BEVEL')
        
        select(bool)
        select(bool_dup)
        select(obj_dup)
        select(obj)
        rt_cutters=get_collection(name='RT_Cutters')
        move_to_collection(bool_dup,rt_cutters)
        move_to_collection(bool,rt_cutters)
        bpy.ops.object.parent_set()
        bool.hide_render=True
        bool_dup.hide_render=True
        bool_dup.hide_view=True
        bool.hide_view=True
        bool.display_type='WIRE'
        bool_dup.display_type='WIRE'
        intersectMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Intersect_Bool")
        intersectMod.show_expanded=False
        intersectMod.object=bool
        intersectMod.operation='INTERSECT'
        intersectMod.solver='FAST'
        diffMod=obj_dup.modifiers.new(type='BOOLEAN',name="RT_Intersect_Bool")
        diffMod.show_expanded=False
        diffMod.object=bool_dup
        diffMod.solver='FAST'
        self.solidifyMod=bool_dup.modifiers.new(type='SOLIDIFY',name="RT_Slice_Bool_Solidify")
        self.solidifyMod.show_expanded=False
        self.solidifyMod.offset=0
        self.solidifyMod.use_even_offset=True
        self.solidifyMod.solidify_mode='NON_MANIFOLD'
        #self.solidifyMod.thickness=0.5
        self.thicknessSave=self.solidifyMod.thickness
        
        mod=obj.modifiers.new(type='BOOLEAN',name="RT_Diff_Bool")
        mod.show_expanded=False
        mod.object=bool
        self.obj=obj
        self.bool_obj=bool
        self.bool_dup=bool_dup
        self.inset_solidify_mod=self.solidifyMod
        self.bool_mod=diffMod
        sort_modifiers(obj)
        sort_modifiers(obj_dup)
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        def fade_out(area):
            self.color=(self.color[0],self.color[1],self.color[2],self.alpha)
            self.alpha-=0.1
            area.tag_redraw()
            if self.alpha<0:
                self.fade_done=True
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                return None
            return 0.04
        if event.type == 'LEFT_SHIFT':
            if event.value == "PRESS":
                self.speed =20
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type == 'LEFT_CTRL':
            if event.value == "PRESS":
                self.speed =1
            elif event.value == 'RELEASE':
                self.speed = 3
            self.initX = event.mouse_x
            self.thicknessSave=self.solidifyMod.thickness
        if event.type=='MOUSEMOVE':
            self.solidifyMod.thickness=self.thicknessSave+(self.initX-event.mouse_x)/(100*self.speed)
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            self.bool_dup.hide_view=False
            deselect_all()
            select(self.bool_dup)
            select(self.bool_obj)
            bpy.ops.object.make_links_data(type='OBDATA')
            self.bool_dup.hide_view=True
            t=self.obj.CuttersInfo.add()
            t.mods_applied=True
            t.direction=1
            t.center_location=self.bool_obj.location
            t.normal=Vector((1,1,1))
            t.last_cutter=self.bool_obj.name
            #if self.bool_obj.CutterId=="None":
            self.bool_obj.CutterId=get_id()
            t.cutter_id=self.bool_obj.CutterId
            t.name=self.bool_obj.CutterId
            #print("ID",self.bool_obj.CutterId)
            if self.extra_objects_created:
                if self.extra_objects_created[0].CutterId=="None":
                    self.extra_objects_created[0].CutterId=get_id()
                    #print("ID1",self.extra_objects_created[0].CutterId)
                t.cutter_extra_1=self.extra_objects_created[0].CutterId
            else:
                t.cutter_extra_1="Not"
            t.last_bool_type="SLICE"
            t.last_mod_name=self.bool_mod.name if  self.bool_mod else ""
            context.scene.rt_tools.last_cutter_index=self.obj.CuttersInfo.find(self.bool_obj.CutterId)
            if self.inset_solidify_mod:
                t.last_inset_mod=self.inset_solidify_mod.name
            else:
                t.last_inset_mod=""
            obj=self.obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            #bm.verts.ensure_lookup_table()
            #bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            coords = [obj.matrix_world@v.co for v in bm.verts]
            indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges] 
            self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
            self.alpha=1
            self.timer_started=True
            bpy.app.timers.register(functools.partial(fade_out,context.area))
            return {'FINISHED'}
        if event.type=='RIGHTMOUSE' and event.value=='PRESS':
            return {'CANCELLED'}
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        if len(context.selected_objects)!=2:
            self.report({'WARNING'},'Select 2 Objects')
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        self.speed=3
        self.initX=event.mouse_x
        self.alpha=1
        self.timer_started=False
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.color=(1,0,0,0.6)
        self.mat=None
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(2)
                gpu.state.blend_set("ALPHA") 
                gpu.state.depth_test_set("LESS")
                
                self.shader.bind()
                self.shader.uniform_float("color", self.color)
                self.batch.draw(self.shader)
                gpu.state.depth_test_set("NONE")
                gpu.state.blend_set("NONE")
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        return self.execute(context)
        
class RTOOLS_OT_Booleans(bpy.types.Operator):
    bl_idname = "rtools.booleans"
    bl_label = "Booleans"
    bl_description = "Booleans"
    bl_options = {"REGISTER","UNDO"}
    type:bpy.props.StringProperty(default='DIFFERENCE')
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and len(context.selected_objects)>1
    def execute(self, context):
        #if len(context.selected_objects)!=2:
        #    self.report({'WARNING'},'Select 2 Objects')
        #    return {'CANCELLED'}
        obj=context.active_object
        bool_objs=Diff(context.selected_objects,[obj])
        
        def fade_out(area):
            self.color=(self.color[0],self.color[1],self.color[2],self.alpha)
            self.alpha-=0.1
            area.tag_redraw()
            if self.alpha<0:
                self.fade_done=True
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                return None
            return 0.04
        for bool_obj in bool_objs:
            bpy.ops.object.select_all( action='DESELECT')
            select(bool_obj)
            bpy.ops.object.shade_smooth()
            if bool_obj.type=='CURVE':
                bpy.ops.object.convert(target='MESH')
            bool_obj.data.use_auto_smooth=True
            obj.data.use_auto_smooth=True
            select(obj)
            if obj.parent!=bool_obj:
                bpy.ops.object.parent_set()
            rt_cutters=get_collection(name='RT_Cutters')
            move_to_collection(bool_obj,rt_cutters)
            bool_obj.hide_render=True
            bool_obj.hide_view=True
            bool_obj.display_type='WIRE'
            
            mod=obj.modifiers.new(type='BOOLEAN',name="RT_Difference_Bool")
            mod.solver='FAST'
            mod.show_expanded=False
            mod.show_expanded=False
            mod.operation=self.type
            mod.object=bool_obj
            bool_mod=mod
            #obj=bool
            t=obj.CuttersInfo.add()
            t.mods_applied=True
            t.direction=1
            t.center_location=bool_obj.location
            t.normal=Vector((1,1,1))
            t.last_cutter=bool_obj.name
            #if bool_obj.CutterId=="None":
            bool_obj.CutterId=get_id()
            t.cutter_id=bool_obj.CutterId
            t.name=bool_obj.CutterId
            t.cutter_extra_1="Not"
            t.last_bool_type=self.type
            t.last_mod_name=bool_mod.name if bool_mod else ""
            context.scene.rt_tools.last_cutter_index=obj.CuttersInfo.find(bool_obj.CutterId)
            
            t.last_inset_mod=""
        obj_evaluated=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        bm = bmesh.new()
        bm.from_mesh(obj_evaluated.data)
        #bm.verts.ensure_lookup_table()
        #bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        coords = [obj_evaluated.matrix_world@v.co for v in bm.verts]
        indices = [(e.verts[0].index,e.verts[1].index) for e in bm.edges] 
        self.batch = batch_for_shader(self.shader, 'LINES', {"pos": coords},indices=indices)
        self.alpha=1
        self.timer_started=True
        sort_modifiers(obj)
        bpy.app.timers.register(functools.partial(fade_out,context.area))
        #context.area.tag_redraw()
        
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.type=='LEFTMOUSE':
            return {'FINISHED'}
        return {'PASS_THROUGH'}
    def invoke(self, context, event):
        self.alpha=1
        self.timer_started=False
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.color=(1,0,0,0.6)
        self.mat=None
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(2)
                gpu.state.blend_set("ALPHA") 
                gpu.state.depth_test_set("LESS")
                
                self.shader.bind()
                self.shader.uniform_float("color", self.color)
                self.batch.draw(self.shader)
                gpu.state.depth_test_set("NONE")
                gpu.state.blend_set("NONE")
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        return self.execute(context)
class RTOOLS_OT_BoolTest(bpy.types.Operator):
    bl_idname = "rtools.booltest"
    bl_label = "Bool Test"
    bl_description = "Create Cable Between 2 Points"
    bl_options = {"REGISTER","UNDO"}
    
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
   
    def modal(self,context,event):
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
                self.clickCount+=1
        if event.type=='A':
            bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cube_add")
            return {'RUNNING_MODAL'}
        elif event.type=='S':
            bpy.ops.wm.tool_set_by_id(name="builtin.primitive_uv_sphere_add")
            return {'RUNNING_MODAL'}
        elif event.type=='V':
            bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cone_add")
            return {'RUNNING_MODAL'}
        elif event.type=='C':
            bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cylinder_add")
            return {'RUNNING_MODAL'}
        elif event.type=='F':
            bpy.ops.wm.tool_set_by_id(name="builtin.primitive_ico_sphere_add")
            return {'RUNNING_MODAL'}
        elif event.type=='X':
            self.boolType='SLICE'
            return {'RUNNING_MODAL'}
        elif event.type=='Z':
            self.boolType='INSET'
            return {'RUNNING_MODAL'}
        elif event.type=='U':
            self.boolType='UNION'
            return {'RUNNING_MODAL'}
        elif event.type=='I':
            self.boolType='INTERSECT'
            return {'RUNNING_MODAL'}
        elif event.type=='D':
            self.boolType='INTERSECT'
            return {'RUNNING_MODAL'}
        elif (len(context.scene.objects)>len(self.initObjects)):
            
            boolObj=Diff(context.scene.objects,self.initObjects)[0]
            select(boolObj)
            select(self.obj)
            displaceMod=boolObj.modifiers.new(type='DISPLACE',name="DISPLACE")
            displaceMod.show_expanded=False
            displaceMod.strength=0.0001
            displaceMod.mid_level=0
            #boolObj.hide_view=True
            """boolMod=self.obj.modifiers.new(type='BOOLEAN',name="aA")
            boolMod.object=boolObj
            boolObj.display_type='WIRE'
            boolObj.hide_view=True
            displaceMod=boolObj.modifiers.new(type='DISPLACE',name="DISPLACE")
            displaceMod.strength=0.001
            displaceMod.mid_level=0"""
            if self.boolType=='SLICE':
                bpy.ops.rtools.slicebool('INVOKE_DEFAULT')
            elif self.boolType=='INSET':
                bpy.ops.rtools.insetbool('INVOKE_DEFAULT')
            else:
                bpy.ops.rtools.booleans('INVOKE_DEFAULT',type=self.boolType)
                #boolMod=self.obj.modifiers.new(type='BOOLEAN',name="aA")
                #boolMod.object=boolObj
                #boolObj.display_type='WIRE'
                #boolObj.hide_view=True
            bpy.ops.wm.tool_set_by_id(name="builtin.select")
            return {'FINISHED'}
        elif event.type=='RIGHTMOUSE' or event.type=='ESC':
            bpy.ops.wm.tool_set_by_id(name="builtin.select")
            return {'CANCELLED'}
        else:
            return {'PASS_THROUGH'}
        #return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        
        bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cube_add")
        self.initObjects=[]
        for obj in context.scene.objects:
            self.initObjects.append(obj)
        self.obj=context.active_object
        
        self.clickCount=0
        self.boolType='DIFFERENCE'
        context.window_manager.modal_handler_add(self)
        
        
        return {'RUNNING_MODAL'}

class RTOOLS_OT_AdjustModifier(bpy.types.Operator):
    bl_idname = "rtools.adjustmodifier"
    bl_label = "Adjust Modifier"
    bl_description = "Adjust\nCTRL+LMB:Remove Modifier"
    bl_options = {"REGISTER","UNDO"}
    name:bpy.props.StringProperty()
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        if self.mod is not None and self.activeProp is not None and self.activeProp2 is not None:
            s1=self.activeProp.replace("_"," ").capitalize()
            s2=self.activeProp2.replace("_"," ").capitalize()
            draw_Text(context,0,preferences().font_size,text=[f'D : {activeProps[self.mod.type][2].replace("_"," ").capitalize()}' if 2<len(activeProps[self.mod.type]) else '',f'S : {activeProps[self.mod.type][1].replace("_"," ").capitalize()}' if 1<len(activeProps[self.mod.type]) else '',f'A : {activeProps[self.mod.type][0].replace("_"," ").capitalize()}' if 0<len(activeProps[self.mod.type]) else "",f"{s1} : {round(getattr(self.mod,self.activeProp),4) if 'angle' not in s1.lower() else round(math.degrees(getattr(self.mod,self.activeProp)))}",f"{s2} : {getattr(self.mod,self.activeProp2)}"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y,activeKey=self.activeKey)
        elif self.mod is not None and self.activeProp is not None:
            s1=self.activeProp.replace("_"," ").capitalize()
            
            draw_Text(context,0,preferences().font_size,text=[f'D : {activeProps[self.mod.type][2].replace("_"," ").capitalize()}' if 2<len(activeProps[self.mod.type]) else '',f'S : {activeProps[self.mod.type][1].replace("_"," ").capitalize()}' if 1<len(activeProps[self.mod.type]) else '',f'A : {activeProps[self.mod.type][0].replace("_"," ").capitalize()}' if 0<len(activeProps[self.mod.type]) else "",f"{s1} : {round(getattr(self.mod,self.activeProp),4)}"],alignH="CENTER",start_x=self.mouse_x,start_y=self.mouse_y,activeKey=self.activeKey)
        draw_Text(context,0,preferences().font_size,text=[f"X : 2X",f"Z : 1/2X"],alignH="RIGHT",activeKey=self.activeKey)
        draw_Text(context,0,preferences().font_size,text=[(f"{i+1} : {a.name}" if a.name!=self.mod.name else f"{i+1} : [{a.name}]" ) for i,a in enumerate(self.adjustable_mods)]+["line",f"Q : Previous Modifier",f"W : Next Modifier"],alignH="LEFT",activeKey=self.activeKey)

    def modal(self,context,event):
        self.mouse_x=event.mouse_region_x
        self.mouse_y=event.mouse_region_y
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.activePropCopy=getattr(self.mod,self.activeProp)
            self.init_x=context.region.x
        elif event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.init_x=context.region.x+context.region.width
            self.activePropCopy=getattr(self.mod,self.activeProp)
        elif event.type=='A':
            if event.value=='PRESS':
                if 0<len(activeProps[self.mod.type]):
                    self.index=0
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.init_x=event.mouse_x
                    self.valueString='0'
                    self.activeKey='A'
                    
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='S':
            if event.value=='PRESS':
                if 1<len(activeProps[self.mod.type]):
                    self.index=1
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.init_x=event.mouse_x
                    self.valueString='0'
                    self.activeKey='S'
                    
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='D' :
            if event.value=='PRESS':
                if 2<len(activeProps[self.mod.type]):
                    self.index=2
                    self.activeProp=activeProps[self.mod.type][self.index]
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.init_x=event.mouse_x
                    self.valueString='0'
                    self.activeKey='D'
                    
            else:
                self.activeKey=None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif self.activePropCopy is not None and event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.activePropCopy=getattr(self.mod,self.activeProp)
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=5 
        elif self.activePropCopy is not None and event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            self.activePropCopy=getattr(self.mod,self.activeProp)
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=2
            elif event.value == 'RELEASE':
                self.speed=5 
        elif self.mod is not None and self.activeProp is not None and self.activePropCopy is not None and event.type=='MOUSEMOVE':
            
            #print((self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else 100))
            setattr(self.mod,self.activeProp,self.activePropCopy-(self.init_x-event.mouse_x)/((200 *self.speed) if self.activeProp in {'width','thickness','radius','strength','merge_threshold','factor','offset'}else (20 *self.speed)))
            self.valueString='0'
        elif self.mod is not None and self.activeProp2 is not None and (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)+1)
            return {'RUNNING_MODAL'}
        elif self.mod is not None and self.activeProp2 is not None and (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) :
            setattr(self.mod,self.activeProp2,getattr(self.mod,self.activeProp2)-1)
            return {'RUNNING_MODAL'}
        if (event.type=='LEFTMOUSE' and event.value=='PRESS') or event.type=='RET' or event.type=='NUMPAD_ENTER':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif (event.type=='RIGHTMOUSE' and event.value=='PRESS') or event.type=='ESC':
            if self.init_activeProp2 is not None :
                setattr(self.mod,self.activeProp2,self.init_activeProp2)
            for p in self.init_activeProps:
                setattr(self.mod,p[0],p[1])
            self.remove_drawHandler(context)
            return {'FINISHED'}
        elif event.type in number_events.keys() and event.value=='PRESS':
            if number_events[event.type]-1<len(self.adjustable_mods):
                self.remove_drawHandler(context)
                bpy.ops.rtools.adjustmodifier('INVOKE_DEFAULT',name=self.adjustable_mods[number_events[event.type]-1].name)
                return {'FINISHED'}
            return {'RUNNING_MODAL'}
        elif event.type =='Q' and event.value=='PRESS':
                
                new_mod_index=self.adjustable_mods.index(self.mod)-1
                if new_mod_index<len(self.adjustable_mods):
                    self.remove_drawHandler(context)
                    bpy.ops.rtools.adjustmodifier('INVOKE_DEFAULT',name=self.adjustable_mods[new_mod_index].name)
                    return {'FINISHED'}
                return {'RUNNING_MODAL'}
        elif event.type =='W' and event.value=='PRESS':
                new_mod_index=self.adjustable_mods.index(self.mod)+1
                if new_mod_index<len(self.adjustable_mods):
                    self.remove_drawHandler(context)
                    bpy.ops.rtools.adjustmodifier('INVOKE_DEFAULT',name=self.adjustable_mods[new_mod_index].name)
                    return {'FINISHED'}
                return {'RUNNING_MODAL'}
        elif event.type in events.keys() and event.value=='PRESS':
            if (event.type!='PERIOD' and event.type!='NUMPAD_PERIOD') or '.' not in self.valueString:
                if event.type=='NUMPAD_MINUS' or event.type=='MINUS' or event.type=='NDOF_BUTTON_MINUS':
                    setattr(self.mod,self.activeProp,-getattr(self.mod,self.activeProp))
                    self.activePropCopy=getattr(self.mod,self.activeProp)
                    self.negate*=-1
                else:
                    self.valueString+=f"{events[event.type]}"
                    setattr(self.mod,self.activeProp,self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0  else eval("0"))
                    self.activePropCopy=getattr(self.mod,self.activeProp)
            return {'RUNNING_MODAL'}
        elif event.type=='Z':
            if  event.value=='PRESS':
                self.activePropCopy=getattr(self.mod,self.activeProp)/2
                setattr(self.mod,self.activeProp,self.activePropCopy)
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='X'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='X':
            if  event.value=='PRESS':
                self.activePropCopy=2*getattr(self.mod,self.activeProp)
                setattr(self.mod,self.activeProp,self.activePropCopy)
                self.activePropCopy=getattr(self.mod,self.activeProp)
                self.activeKey='X'
            else:
                self.activeKey=None
            return {'RUNNING_MODAL'}
        elif event.type=='BACK_SPACE' and event.value=='PRESS':
            self.valueString=self.valueString[:-1] if len(self.valueString)>1 else self.valueString
            setattr(self.mod,self.activeProp,self.negate*eval(self.valueString.lstrip('0')) if len(self.valueString.lstrip('0'))>0 and len(self.valueString.lstrip('0').lstrip('.'))>0 else eval("0"))
            self.activePropCopy=getattr(self.mod,self.activeProp)
        return {'PASS_THROUGH'}
    def invoke(self, context, event):
        self.mouse_x=event.mouse_x
        self.mouse_y=event.mouse_y
        self.obj=context.active_object
        self.mod=[mod for mod in self.obj.modifiers if mod.name==self.name][0]
        if context.active_object.animation_data and context.active_object.animation_data.drivers:
            for driver in context.active_object.animation_data.drivers:
                
                if f'modifiers["{self.mod.name}"]' in  driver.data_path:
                    #print(f'modifiers["{m.name}"]',driver.data_path)
                    path=driver.driver.variables[0].targets[0].data_path
                    ob2=driver.driver.variables[0].targets[0].id
                    m2=path[path.index("[")+2:path.index("]")-1]
                    if m2 in [a.name for a in ob2.modifiers]:
                        self.mod=ob2.modifiers[m2]
        self.adjustable_mods=[]
        for mod in context.active_object.modifiers:
            if  mod.type in {'BEVEL','SOLIDIFY','DISPLACE','SCREW','SIMPLE_DEFORM','SHRINKWRAP'} and len(self.adjustable_mods)<9:
                if context.active_object.animation_data and context.active_object.animation_data.drivers:
                    length=len(self.adjustable_mods)
                    for driver in context.active_object.animation_data.drivers:
                        
                        if f'modifiers["{mod.name}"]' in  driver.data_path:
                            #print(f'modifiers["{m.name}"]',driver.data_path)
                            path=driver.driver.variables[0].targets[0].data_path
                            ob2=driver.driver.variables[0].targets[0].id
                            m2=path[path.index("[")+2:path.index("]")-1]
                            if m2 in [a.name for a in ob2.modifiers] and ob2.modifiers[m2] not in self.adjustable_mods:
                                self.adjustable_mods.append(ob2.modifiers[m2])
                                break
                    else:
                        if mod  not in self.adjustable_mods:
                            self.adjustable_mods.append(mod)
                                
                else:
                    if mod  not in self.adjustable_mods:
                        self.adjustable_mods.append(mod)
        #print(self.adjustable_mods)
        #self.adjustable_mods=[mod for mod in context.active_object.modifiers if mod.type in {'BEVEL','SOLIDIFY','DISPLACE','SCREW','SIMPLE_DEFORM','SHRINKWRAP'} ][:9]

        self.adjustable_mods_sametype=[mod for mod in context.active_object.modifiers if mod.type ==self.mod.type ]
        if event.ctrl:
            bpy.ops.object.modifier_remove(modifier=self.mod.name)
            return {'FINISHED'}
        self.activeProp2=None
        self.valueString='0'
        self.negate=1
        self.init_activeProp2=None
        if self.mod.type=='BEVEL':
            self.activeProp2='segments'
            self.init_activeProp2=getattr(self.mod,self.activeProp2)
        self.activeProp=activeProps[self.mod.type][0]
        self.activePropCopy=getattr(self.mod,self.activeProp)
        self.index=0
        self.init_activeProps=[]
        for p in activeProps[self.mod.type]:
            self.init_activeProps.append((p,getattr(self.mod,p)))
        self.speed=5
        self.init_x=event.mouse_x
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        self.activeKey=None
        return {'RUNNING_MODAL'}
class RTOOLS_OT_ExtractFaces2(bpy.types.Operator):
    bl_idname = "rtools.extractfaces"
    bl_label = "Extract Faces"
    bl_description = "Click And Drag To Extract Faces\nCTRL+LMB: Extract>Inset>P-Cutter"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls,context):
        return context.mode=='OBJECT'
    def invoke(self,context,event):
        bpy.context.window.cursor_set("CROSSHAIR")
        self.obj=None
        self.mousedown=False
        self.faces=set([])
        context.window_manager.modal_handler_add(self)
        self.shader=None
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.depsgraph=context.evaluated_depsgraph_get()
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(4)
                gpu.state.blend_set("ALPHA") 
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                self.shader.bind()
                self.shader.uniform_float("color", (0,0.3 , 1, 0.4))
                self.batch.draw(self.shader)
                gpu.state.blend_set("NONE") 
                #bgl.glDisable(bgl.GL_LINE_SMOOTH)
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        self.ctrl=event.ctrl
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.type=='ESC'and event.value=='PRESS':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            context.area.tag_redraw()
            return {'CANCELLED'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            self.mousedown=True
            scene = context.scene
            region = context.region
            rv3d = context.region_data
            coord = event.mouse_region_x,event.mouse_region_y
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            hidden_objs=[]
            
            while ( object and (not object.visible_get() or (object.display_type=='WIRE' and preferences().extract_from_only_solid_objects))):
                
                hidden_objs.append((object,object.hide_get()))
                object.hide_view=True
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
            for o,s in hidden_objs:
                o.hide_view=s
            if self.obj and object!=self.obj:
                object=None
            if object:
                self.obj=object if self.obj is None else self.obj
                self.faces.add(index)
                mesh=object.evaluated_get(self.depsgraph).data
                mesh.calc_loop_triangles()
                self.coords=[self.obj.matrix_world@v.co for v in mesh.vertices]
                self.loops=mesh.loop_triangles
                if not self.loops:
                    mesh=object.evaluated_get(self.depsgraph).data
                    mesh.calc_loop_triangles()
                    self.coords=[self.obj.matrix_world@v.co for v in mesh.vertices]
                    self.loops=mesh.loop_triangles
                indices=[]
                for loop in self.loops:
                    if loop.polygon_index in [i for i in self.faces]:
                        indices.append(loop.vertices)
                #print(bm.faces[0].loops[0].vert,bm.faces[1].loops[0].vert)
                #print(indices)
                self.batch=batch_for_shader(self.shader, 'TRIS',{"pos": self.coords},indices=indices)
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE' and event.value=='RELEASE':
            self.mousedown=False
            return {'RUNNING_MODAL'}
        elif event.type=='MOUSEMOVE':
            if self.mousedown:
                scene = context.scene
                region = context.region
                rv3d = context.region_data
                coord = event.mouse_region_x,event.mouse_region_y
                view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                hidden_objs=[]
                
                while ( object and (not object.visible_get() or (object.display_type=='WIRE' and preferences().extract_from_only_solid_objects))):
                    
                    hidden_objs.append((object,object.hide_get()))
                    object.hide_view=True
                    (result, location, normal, index, object, matrix) = scene.ray_cast(bpy.context.evaluated_depsgraph_get(),ray_origin, view_vector)
                for o,s in hidden_objs:
                    o.hide_view=s
                if self.obj and object!=self.obj:
                    object=None
                if object:
                    self.obj=object if self.obj is None else self.obj
                    self.faces.add(index)
                    if not self.loops:
                        mesh=object.evaluated_get(context.evaluated_depsgraph_get()).data
                        mesh.calc_loop_triangles()
                        self.coords=[self.obj.matrix_world@v.co for v in mesh.vertices]
                        self.loops=mesh.loop_triangles
                    indices=[]
                    for loop in self.loops:
                        if loop.polygon_index in [i for i in self.faces]:
                            indices.append(loop.vertices)
                    #print(bm.faces[0].loops[0].vert,bm.faces[1].loops[0].vert)
                    self.batch=batch_for_shader(self.shader, 'TRIS',{"pos": self.coords},indices=indices)
                    context.area.tag_redraw()
                
        elif event.type=='RIGHTMOUSE' and event.value=='PRESS':
            self.mousedown=False
            if self.obj:
                dup_obj=duplicate_object(self.obj)
                deselect_all()
                select(dup_obj)
                bpy.ops.object.convert(target='MESH')
                bpy.ops.object.editmode_toggle()
                bm=bmesh.from_edit_mesh(dup_obj.evaluated_get(context.evaluated_depsgraph_get()).data)
                deselect_all()
                bm.faces.ensure_lookup_table()
                for f in bm.faces:
                    if f.index not in [a for a in self.faces]:
                        f.select=True
                bpy.ops.mesh.delete(type='FACE')
                #bpy.ops.mesh.duplicate_move()
                #bpy.ops.mesh.separate(type='SELECTED')
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                #new_obj=Diff(context.selected_objects,[context.active_object])[0]
                #deselect_all()
                #select(new_obj)
                bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
                if self.ctrl:
                    bpy.ops.rtools.insetshrink('INVOKE_DEFAULT',object=self.obj.name,inset_shrink_pcutter=True)
            return {"FINISHED"}
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}
class RTOOLS_OT_ExtractFaces(bpy.types.Operator):
    bl_idname = "rtools.extractfaces"
    bl_label = "Extract Faces"
    bl_description = "Click And Drag To Extract Faces\nCTRL+LMB: Extract>Inset>P-Cutter\nSHIFT+LMB: Extract>Inset>Solidify"
    bl_options = {"REGISTER","UNDO"}
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()   
    def draw_callback_px(self,context):
        if self.circle_select:
                gpu.state.blend_set("ALPHA") 
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
                indices=[[0,i,i+1] for i in range(1,len(self.circle_coords)-1)]
                batch = batch_for_shader(shader, 'TRIS', {"pos": self.circle_coords},indices=indices)
                shader.bind()
                shader.uniform_float("color", (0, 0,0 ,0.2))
                batch.draw(shader)
                batch = batch_for_shader(shader, 'LINES', {"pos": self.circle_coords},indices=[(i,i+1) for i in range(0,len(self.circle_coords),2)])
                shader.bind()
                shader.uniform_float("color", (1, 1,1 ,0.3))
                batch.draw(shader)
                gpu.state.blend_set("NONE") 
                #bgl.glDisable(bgl.GL_LINE_SMOOTH)
        draw_Text(context,0,preferences().font_size,text=[f"ESC : Cancel",f"RMB : Confirm","Hold CTRL : Deselect",f"E : Select Coplanar",f"C : Circle Select ({'ON' if self.circle_select else 'OFF'})","CTRL+SCROLL : Radius" if self.circle_select else ""],alignH="RIGHT")
    @classmethod
    def poll(cls,context):
        return context.mode=='OBJECT' and context.active_object and context.active_object.type=='MESH'
    def invoke(self,context,event):
        bpy.context.window.cursor_set("CROSSHAIR")
        self.obj=context.active_object
        self.obj_dup=duplicate_object(self.obj)
        self.obj_dup.hide_view=True
        for m in self.obj_dup.modifiers:
            if m.type=='BEVEL' and m.segments>1 and m.width<preferences().bevel_threshold:
                m.show_viewport=False
        self.object_evaluated=self.obj_dup.evaluated_get(context.evaluated_depsgraph_get())
        self.object_evaluated.data.calc_loop_triangles()
        self.coords=[self.object_evaluated.matrix_world@v.co for v in self.object_evaluated.data.vertices]
        self.loops_og=self.object_evaluated.data.loop_triangles
        self.loops=[]
        for i in range(0,len(self.object_evaluated.data.polygons)):
            self.loops.append([])
        for loop in self.loops_og:
            self.loops[loop.polygon_index].append(loop.vertices)
        self.bmesh=bmesh.new()
        self.bmesh.from_mesh(self.object_evaluated.data)
        self.bmesh.transform(self.obj.matrix_world)
        self.bmesh.faces.ensure_lookup_table()
        self.tree=BVHTree.FromBMesh(self.bmesh)
        self.mousedown=False
        self.middlemousedown=False
        self.faces=[]
        context.window_manager.modal_handler_add(self)
        self.shader=None
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch=None
        self.indices=[]
        self.depsgraph=context.evaluated_depsgraph_get()
        def draw():
            if self.shader is not None and self.batch is not None:
                gpu.state.line_width_set(4)
                gpu.state.blend_set("ALPHA") 
                #bgl.glEnable(bgl.GL_LINE_SMOOTH)
                self.shader.bind()
                self.shader.uniform_float("color", (0,0.3 , 1, 0.4))
                self.batch.draw(self.shader)
                gpu.state.blend_set("NONE") 
                #bgl.glDisable(bgl.GL_LINE_SMOOTH)
            
            
        self.drawHandle=bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
        self.add_drawHandler(context)
        self.ctrl=event.ctrl
        self.shift=event.shift
        circle_points=[(0.0, 1.0), (-0.195, 0.98), (-0.382, 0.923), (-0.556, 0.831), (-0.707, 0.707), (-0.831, 0.556), (-0.924, 0.383), (-0.981, 0.195), (-1.0, 0), (-0.981, -0.195), (-0.924, -0.383), (-0.831, -0.556), (-0.707, -0.707), (-0.556, -0.831), (-0.383, -0.924), (-0.195, -0.981), (0, -1.0), (0.195, -0.981), (0.383, -0.924), (0.556, -0.831), (0.707, -0.707), (0.831, -0.556), (0.924, -0.383), (0.981, -0.195), (1.0, 0), (0.981, 0.195), (0.924, 0.383), (0.831, 0.556), (0.707, 0.707), (0.556,0.831), (0.383, 0.924), (0.195, 0.981)]
        self.init_circle_points=list(map(lambda x:(round(x[0],3),round(x[1],3)),circle_points))
        #print(self.init_circle_points)
        self.circle_points=[]
        #self.circle_points=circle_points[::4]

        #print(self.circle_points)
        self.circle_coords=list(map(lambda x:(event.mouse_region_x+x[0],event.mouse_region_y+x[1]),self.init_circle_points))
        #for c in self.init_circle_points:
        #        self.circle_points.append((c[0]/2,c[1]/2))
        #        self.circle_points.append((c[0]/4,c[1]/4))
        #        self.circle_points.append((c[0]*3/4,c[1]*3/4))
        self.radius=20
        self.last_radius=20
        self.circle_select=False
        self.expand_angle=1
        return {'RUNNING_MODAL'}
    def modal(self, context,event):
        if event.type=='ESC'and event.value=='PRESS':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            self.remove_drawHandler(context)
            context.area.tag_redraw()
            return {'CANCELLED'}
        elif event.type=='Z' and event.value=='PRESS':
            pass
        elif event.ctrl and (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.radius+=5
            self.circle_coords=list(map(lambda x:(event.mouse_region_x+(x[0]*self.radius),event.mouse_region_y+(x[1]*self.radius)),self.init_circle_points))
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.ctrl and (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.radius-=5
            self.circle_coords=list(map(lambda x:(event.mouse_region_x+(x[0]*self.radius),event.mouse_region_y+(x[1]*self.radius)),self.init_circle_points))
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='LEFTMOUSE' and event.value=='PRESS' and not event.alt:
            self.mousedown=True
            if not event.ctrl:
                for i in [(0,0),]+self.circle_points:
                    scene = context.scene
                    region = context.region
                    rv3d = context.region_data
                    
                    coord = event.mouse_region_x+(i[0]*self.radius),event.mouse_region_y+(i[1]*self.radius)
                    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                    
                    (location, normal,index,distance)=self.tree.ray_cast(ray_origin, view_vector)
                    
                    if index  is not None:
                        
                        if index  not in self.faces:
                            for loop in self.loops[index]:
                                self.indices.append((loop,index))
                            self.faces.append(index)
            else:
                for i in [(0,0),]+self.circle_points:
                    scene = context.scene
                    region = context.region
                    rv3d = context.region_data
                    
                    coord = event.mouse_region_x+(i[0]*self.radius),event.mouse_region_y+(i[1]*self.radius)
                    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                    
                    (location, normal,index,distance)=self.tree.ray_cast(ray_origin, view_vector)
                    if index  is not None:
                        self.faces=[a for a in self.faces if a!=index]
                        self.indices=[a for a in self.indices if a[1]!=index]    
            self.batch=batch_for_shader(self.shader, 'TRIS',{"pos": self.coords},indices=[a for (a,b) in self.indices])
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='E' and event.value=='PRESS':
            og_faces=self.faces[:]
            for i in og_faces:
                _,cp_faces=coplanar_faces(self.bmesh,self.bmesh.faces[i],normal_difference_threshold=math.radians(self.expand_angle))
                for f in cp_faces:
                    if f.index not in self.faces:
                        for loop in self.loops[f.index]:
                                self.indices.append((loop,f.index))
                        self.faces.append(f.index)
            self.batch=batch_for_shader(self.shader, 'TRIS',{"pos": self.coords},indices=[a for (a,b) in self.indices])
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}    
        elif event.type=='LEFTMOUSE' and event.value=='RELEASE':
            self.mousedown=False
            return {'RUNNING_MODAL'}
        elif event.type=='C' and event.value=='PRESS':
            self.circle_select=not self.circle_select
            if self.circle_select:
                circle_points=[(0.0, 1.0), (-0.195, 0.98), (-0.382, 0.923), (-0.556, 0.831), (-0.707, 0.707), (-0.831, 0.556), (-0.924, 0.383), (-0.981, 0.195), (-1.0, 0), (-0.981, -0.195), (-0.924, -0.383), (-0.831, -0.556), (-0.707, -0.707), (-0.556, -0.831), (-0.383, -0.924), (-0.195, -0.981), (0, -1.0), (0.195, -0.981), (0.383, -0.924), (0.556, -0.831), (0.707, -0.707), (0.831, -0.556), (0.924, -0.383), (0.981, -0.195), (1.0, 0), (0.981, 0.195), (0.924, 0.383), (0.831, 0.556), (0.707, 0.707), (0.556,0.831), (0.383, 0.924), (0.195, 0.981)]
                
                self.circle_points=circle_points[::2]
                for c in self.init_circle_points:
                        self.circle_points.append((c[0]/2,c[1]/2))
                        self.circle_points.append((c[0]/4,c[1]/4))
                        self.circle_points.append((c[0]*6/8,c[1]*6/8))
                        self.circle_points.append((c[0]*7/8,c[1]*7/8))
                        self.circle_points.append((c[0]*5/8,c[1]*5/8))
                self.radius=self.last_radius
            else:
                self.circle_points=[]
                self.last_radius=self.radius
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type=='MOUSEMOVE':
            
            if self.mousedown and not event.ctrl :
                
                for i in [(0,0),]+self.circle_points:
                    scene = context.scene
                    region = context.region
                    rv3d = context.region_data
                    
                    coord = event.mouse_region_x+(i[0]*self.radius),event.mouse_region_y+(i[1]*self.radius)
                    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                    
                    (location, normal,index,distance)=self.tree.ray_cast(ray_origin, view_vector)
                    
                    if index  is not None:
                        
                        if index  not in self.faces:
                            for loop in self.loops[index]:
                                self.indices.append((loop,index))
                            self.faces.append(index)
                
            if self.mousedown and event.ctrl:
                for i in [(0,0),]+self.circle_points:
                    scene = context.scene
                    region = context.region
                    rv3d = context.region_data
                    
                    coord = event.mouse_region_x+(i[0]*self.radius),event.mouse_region_y+(i[1]*self.radius)
                    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
                    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
                    
                    (location, normal,index,distance)=self.tree.ray_cast(ray_origin, view_vector)
                    if index  is not None:
                        self.faces=[a for a in self.faces if a!=index]
                        self.indices=[a for a in self.indices if a[1]!=index]
            self.batch=batch_for_shader(self.shader, 'TRIS',{"pos": self.coords},indices=[a for (a,b) in self.indices])
            self.circle_coords=list(map(lambda x:(event.mouse_region_x+(x[0]*self.radius),event.mouse_region_y+(x[1]*self.radius)),self.init_circle_points))
            #print(self.circle_coords)
            context.area.tag_redraw()
        elif event.type=='RIGHTMOUSE' and event.value=='PRESS' and not event.alt:
            self.mousedown=False
            if self.obj_dup:
                delete_object_with_data(self.obj_dup)
            if self.obj and self.faces:
                dup_obj=duplicate_object(self.obj)
                deselect_all()
                select(dup_obj)
                for m in dup_obj.modifiers:
                    if m.type=='BEVEL' and m.segments>1 and m.width<preferences().bevel_threshold:
                        m.show_viewport=False
                    if m.type=='WEIGHTED_NORMAL':
                        m.show_viewport=False
                bpy.ops.object.convert(target='MESH')
                bpy.ops.object.editmode_toggle()
                bm=bmesh.from_edit_mesh(dup_obj.evaluated_get(context.evaluated_depsgraph_get()).data)
                deselect_all()
                bm.faces.ensure_lookup_table()
                for f in bm.faces:
                    if f.index not in [a for a in self.faces]:
                        f.select=True
                bpy.ops.mesh.delete(type='FACE')
                #bpy.ops.mesh.duplicate_move()
                #bpy.ops.mesh.separate(type='SELECTED')
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                #new_obj=Diff(context.selected_objects,[context.active_object])[0]
                #deselect_all()
                #select(new_obj)
                
                if self.ctrl:
                    bpy.ops.rtools.insetshrink('INVOKE_DEFAULT',object=self.obj.name,inset_shrink_pcutter=True,inset_shrink_solidify=False)
                elif self.shift:
                    bpy.ops.rtools.insetshrink('INVOKE_DEFAULT',object=self.obj.name,inset_shrink_pcutter=False,inset_shrink_solidify=True)
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandle,"WINDOW")
            self.remove_drawHandler(context)
            return {"FINISHED"}
        elif event.type =='MIDDLEMOUSE' or (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)) or (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            return {'PASS_THROUGH'}
        context.area.tag_redraw()
        return {'PASS_THROUGH'}
    
class RTOOLS_OT_Mesh_Deform(bpy.types.Operator):
    bl_idname = "rtools.meshdeform"
    bl_label = "Create Deform Mesh"
    bl_description = "Create Deform Mesh"
    bl_options = {"REGISTER","UNDO"}
    level:bpy.props.IntProperty(default=2)
    offset:bpy.props.FloatProperty(default=0.5)
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def execute(self, context):
        obj=context.active_object
        scale=max(obj.dimensions[:])
        bm=bmesh.new()
        
        bmesh.ops.create_cube(bm,size=scale)
        mesh_data = bpy.data.meshes.new('Deformer')
        bm.to_mesh(mesh_data)
        bm.free()
        deform_obj = bpy.data.objects.new('Deformer', mesh_data)
        bpy.context.collection.objects.link(deform_obj)
        deform_obj.location=obj.location
        deform_obj.rotation_euler=obj.rotation_euler
        deform_obj.display_type='WIRE'
        deform_subsurf=deform_obj.modifiers.new(type='SUBSURF',name="RT_Subsurf")
        deform_subsurf.show_expanded=False
        deform_subsurf.levels=self.level
        deform_subsurf.subdivision_type='SIMPLE'
        bpy.ops.object.modifier_apply({'object':deform_obj},modifier=deform_subsurf.name)
        shrinkwrap_mod=deform_obj.modifiers.new(type='SHRINKWRAP',name="RT_SW")
        shrinkwrap_mod.show_expanded=False
        shrinkwrap_mod.target=obj
        shrinkwrap_mod.offset=self.offset
        bpy.ops.object.modifier_apply({'object':deform_obj},modifier=shrinkwrap_mod.name)
        mesh_deform_mod=obj.modifiers.new(type='MESH_DEFORM',name='RT_Mesh_Deform')
        mesh_deform_mod.show_expanded=False
        mesh_deform_mod.object=deform_obj
        bpy.ops.object.meshdeform_bind({'object':obj},modifier=mesh_deform_mod.name)
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return self.execute(context)

class RTOOLS_OT_Convert_To_Plane(bpy.types.Operator):
    bl_idname = "rtools.converttoplane"
    bl_label = "Convert to Plane"
    bl_description = "Add Plane"
    bl_options = {"REGISTER","UNDO"}
    add_glass_material:bpy.props.BoolProperty(default=False)
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT' and context.active_object.type=='MESH'
    def execute(self,context):
        obj=context.active_object
        #obj=duplicate_object(obj)
        #obj.scale*=1.02
        solidify_mod=obj.modifiers.new(type='SOLIDIFY',name="RT_SOLIDIFY")
        solidify_mod.show_expanded=False
        solidify_mod.thickness=0.0001
        solidify_mod.offset=0
        bpy.ops.object.modifier_move_to_index(modifier=solidify_mod.name,index=0)
        smart_apply_modifiers(obj)
        #bpy.ops.object.convert(target='MESH')
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all( action = 'SELECT' )
        bpy.ops.mesh.remove_doubles(threshold=0.0005)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.editmode_toggle()
        if self.add_glass_material:
            if "Glass 2.4" in [m.name for m in bpy.data.materials]:
                mat=bpy.data.materials['Glass 2.4']
            else:
                path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","Material")
                matInit = [m for m in bpy.data.materials]
                bpy.ops.wm.append(
                    directory=path,
                    filename="Glass 2.4", autoselect=False
                )
                matAfter = [m for m in bpy.data.materials]
                mat=Diff(matInit,matAfter)[0]
            if len(obj.data.materials)>0:
                obj.data.materials[obj.active_material_index]=mat
            else:
                obj.data.materials.append(mat)

        #delete_object(obj)
        return {'FINISHED'}
    def invoke(self, context, event):
        self.add_glass_material=event.ctrl
        return self.execute(context)
class RTOOLS_OT_Add_Plane_To_Booleans(bpy.types.Operator):
    bl_idname = "rtools.addplanetoboolean"
    bl_label = "Add Plane"
    bl_description = "Add Plane"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls,context):
        return context.active_object and context.mode=='OBJECT'
    def execute(self,context):
        obj=context.active_object
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        plane=context.active_object
        plane.parent=obj
        bool_mod=plane.modifiers.new(type='BOOLEAN',name="RT_Boolean")
        bool_mod.show_expanded=False
        bool_mod.object=obj
        bool_mod.operation='INTERSECT'
        bool_mod.solver='FAST'
        if obj.modifiers.get('RT_SOLIDIFY'):
            bpy.ops.transform.translate(value=(0, 0, -0.04), orient_type='LOCAL')
        obj.hide_view=True
        return {'FINISHED'}
def displace_axes(self,context):
    if self.axis=='X':
        return {('Y','Y','Y'),('Z','Z','Z')}
    elif self.axis=='Y':
        return {('X','X','X'),('Z','Z','Z')}
    elif self.axis=='Z':
        return {('X','X','X'),('Y','Y','Y')}
def is_first_quadrant(angle):
    angle=math.degrees(angle)
    return (angle>0 and angle<=90) or (angle<-270 and angle>=-360)
def is_second_quadrant(angle):
    angle=math.degrees(angle)
    return (angle>90 and angle<=180) or (angle<-180 and angle>=-270)
def is_third_quadrant(angle):
    angle=math.degrees(angle)
    return (angle>180 and angle<=270) or (angle<-90 and angle>=-180)
def is_fourth_quadrant(angle):
    angle=math.degrees(angle)
    return (angle>270 and angle<=360) or (angle<0 and angle>=-90)
class RTOOLS_OT_Circular_Array(bpy.types.Operator):
    bl_idname = "rtools.circulararray"
    bl_label = "Circular Array"
    bl_description = "Create Circular Array"
    bl_options = {"REGISTER","UNDO"}
    count:bpy.props.IntProperty(default=8,name='Count')
    axis: bpy.props.EnumProperty(items={('X','X','X'),('Y','Y','Y'),('Z','Z','Z')},name='Array Axis')
    displace_axis:bpy.props.EnumProperty(items=displace_axes,name='Displace Axis')
    distance:bpy.props.FloatProperty(default=1,name='Radius')
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT' and context.active_object.type=='MESH'
    def draw(self, context):
        layout=self.layout
        layout.prop(self,'count')
        layout.prop(self,'axis')
        if self.selected_count==1:
            layout.prop(self,'displace_axis')
        layout.prop(self,'distance')
    def execute(self,context):
        if len(context.selected_objects)==1:
            axes={'Y':1,'X':0,'Z':2}
            obj=context.active_object
            #deselect_all()
            #select(obj)
            #bpy.ops.object.transform_apply({'object':obj},location=False, rotation=True, scale=False)
            bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD')
            empty=context.active_object
            empty.empty_display_type='SPHERE'
            empty.empty_display_size=0.2
            empty.parent=obj
            
            displace_mod=obj.modifiers.new(type='DISPLACE',name="RT_Displace")
            displace_mod.show_expanded=False
            displace_mod.direction=self.displace_axis
            displace_mod.strength=self.distance
            displace_mod.mid_level=0
            
            
            
            array_mod=obj.modifiers.new(type='ARRAY',name="RT_Array")
            array_mod.show_expanded=False
            array_mod.use_relative_offset=False
            array_mod.use_object_offset=True
            array_mod.offset_object=empty
            array_mod.count=self.count
            
            empty.hide_view=True
            driver=empty.driver_add("rotation_euler",axes[self.axis])
            var = driver.driver.variables.new()
            var.name = "Count"
            var.targets[0].data_path = f'modifiers["{array_mod.name}"].count'
            var.targets[0].id_type='OBJECT'
            var.targets[0].id = obj
            driver.driver.expression = "2*pi/Count"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]
            select(obj)
        elif len(context.selected_objects)==2:
            axes={'Y':1,'X':0,'Z':2}
            displace_axis={'Z':('X','Y'),'Y':('X','Z'),'X':('Y','Z')}
            active=context.active_object
            obj=Diff(context.selected_objects,[active])[0]
            #obj.location=active.location
            og_rot=active.rotation_euler.copy()
            active.rotation_euler=(0,0,0)
            normal=obj.rotation_euler.to_matrix()@Vector((0,0,1))
            if self.axis=='Z':
                x_sign=normal[0]
                y_sign=normal[1]
                z_rotation=obj.rotation_euler[2]
            elif self.axis=='Y':
                x_sign=normal[0]
                y_sign=normal[2]
                z_rotation=obj.rotation_euler[1]
            else:
                x_sign=normal[1]
                y_sign=normal[2]
                z_rotation=obj.rotation_euler[0]
            #print(z_rotation)
            #if is_first_quadrant(z_rotation): 
            #    x_sign=1
            #    y_sign=-1
            #elif is_third_quadrant(z_rotation):
            #    x_sign=-1
            #    y_sign=1
            #else:
            #    x_sign=1
            #    y_sign=1
            deselect_all()
            select(obj)
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

            bpy.ops.object.transform_apply({'object':obj},location=False, rotation=True, scale=False)
            bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD')
            
            empty=context.active_object
            empty.empty_display_type='SPHERE'
            
            empty.empty_display_size=0.2
            if self.axis=='Z':
                empty.location=(active.location[0],active.location[1],obj.location[2])
            elif self.axis=='Y':
                empty.location=(active.location[0],obj.location[1],active.location[2])
            elif self.axis=='X':
                empty.location=(obj.location[0],active.location[1],active.location[2])
            
            #saved_location = bpy.context.scene.cursor.location
            #bpy.context.scene.cursor.location = empty.location
            #bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            #bpy.context.scene.cursor.location = saved_location
            obj.location=empty.location
            empty.rotation_euler=active.rotation_euler
            
            displace_mod=obj.modifiers.new(type='DISPLACE',name="RT_Displace")
            displace_mod.show_expanded=False
            displace_mod.direction=displace_axis[self.axis][0]
            if math.isclose(x_sign,0,abs_tol=0.003) and math.isclose(y_sign,0,abs_tol=0.003):
                displace_mod.strength=self.distance
                displace_mod.mid_level=0
            else:
                displace_mod.strength=x_sign*self.distance if x_sign!=0 else self.distance
                displace_mod.mid_level=0
                displace_mod2=obj.modifiers.new(type='DISPLACE',name="RT_Displace")
                displace_mod2.show_expanded=False
                displace_mod2.direction=displace_axis[self.axis][1]
                #print(math.tan(z_rotation))
                #displace_mod2.strength=y_sign*(1/abs(math.tan(z_rotation)))*self.distance
                displace_mod2.mid_level=0
                driver_displace=displace_mod2.driver_add("strength")
                var = driver_displace.driver.variables.new()
                var.name = "Strength"
                var.targets[0].data_path = f'modifiers["{displace_mod.name}"].strength'
                var.targets[0].id_type='OBJECT'
                var.targets[0].id = obj
                driver_displace.driver.expression = f"{(y_sign/x_sign) if x_sign!=0 else 0}*Strength"
                driver_displace.driver.expression += " "
                driver_displace.driver.expression = driver_displace.driver.expression[:-1]
            
            
            array_mod=obj.modifiers.new(type='ARRAY',name="RT_Array")
            array_mod.show_expanded=False
            array_mod.use_relative_offset=False
            array_mod.use_object_offset=True
            array_mod.offset_object=empty
            array_mod.count=self.count
            deselect_all()
            select(obj)
            select(empty)
            select(active)
            bpy.ops.object.parent_set()
            active.rotation_euler=og_rot
            empty.hide_view=True
            driver=empty.driver_add("rotation_euler",axes[self.axis])
            var = driver.driver.variables.new()
            var.name = "Count"
            var.targets[0].data_path = f'modifiers["{array_mod.name}"].count'
            var.targets[0].id_type='OBJECT'
            var.targets[0].id = obj
            driver.driver.expression = "2*pi/Count"
            driver.driver.expression += " "
            driver.driver.expression = driver.driver.expression[:-1]
            select(obj)

        return {'FINISHED'}
    def invoke(self, context, event):
        active=context.active_object
        self.selected_count=len(context.selected_objects)
        if len(context.selected_objects)==2:
            obj=Diff(context.selected_objects,[active])[0]
            self.distance=(obj.location-active.location).length
        else:
            self.distance=active.dimensions[0]*2 if active.dimensions[0]>active.dimensions[1] else active.dimensions[1]*2
        self.axis='Z'
        return self.execute(context)
class RTOOLS_OT_Edge_To_Strip(bpy.types.Operator):
    bl_idname = "rtools.edgetostrip"
    bl_label = "Edge To Strip"
    bl_description = "Apply Modifiers\nCTRL+LMB: Apply Till Last Bevel Modifier\nSHIFT+LMB: Apply Till Last Mirror Modifier"
    bl_options = {"REGISTER","UNDO"}
    width:bpy.props.FloatProperty(default=0.05)
    bevel_width:bpy.props.FloatProperty(default=0.1)
    threshold:bpy.props.FloatProperty(default=0.005)
    segments:bpy.props.IntProperty(default=3)
    @classmethod
    def poll(cls, context):
        return context.active_object
    #def execute(self, context):
    #    return {'FINISHED'}
    def execute(self, context):
        obj=context.active_object
        bpy.ops.object.convert(target='CURVE')
        obj=context.active_object
        obj.data.extrude=0.0005
        bevelMod=obj.modifiers.new(type='BEVEL',name='RT_Bevel')
        bevelMod.width=self.bevel_width
        bevelMod.segments=self.segments
        solidifyMod=obj.modifiers.new(type='SOLIDIFY',name="RT_Solidify")
        solidifyMod.show_expanded=False
        solidifyMod.offset=0
        solidifyMod.thickness=self.width
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.editmode_toggle()
        select_all()
        bpy.ops.mesh.remove_doubles(threshold=self.threshold)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}
class RTOOLS_OT_Apply_Modifiers(bpy.types.Operator):
    bl_idname = "rtools.applymodifiers"
    bl_label = "Apply Modifiers"
    bl_description = "Apply Modifiers\nCTRL+LMB: Apply Till Last Bevel Modifier\nSHIFT+LMB: Apply Till Last Mirror Modifier"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object
    #def execute(self, context):
    #    return {'FINISHED'}
    def invoke(self, context,event):
        if event.ctrl:
            smart_apply_modifiers(context.active_object)
        elif event.shift:
            smart_apply_modifiers(context.active_object,mirror=True)
        else:
            bpy.ops.object.convert(target='MESH')
        return {'FINISHED'}
class RTOOLS_OT_Align_View_To_Face(bpy.types.Operator):
    bl_idname = "rtools.aligntoface"
    bl_label = "Align View To Face"
    bl_description = "Align View To Face Normal"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='EDIT_MESH'
    def execute(self, context):
        
        bpy.ops.object.editmode_toggle()
        obj=context.active_object
        dup_obj=duplicate_object(obj)
        bpy.ops.object.select_all( action='DESELECT')
        select(dup_obj)
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        
        obj_rotation=dup_obj.evaluated_get(context.evaluated_depsgraph_get()).rotation_euler.to_matrix()
        delete_object_with_data(dup_obj)
        deselect_all()
        select(obj)
        bpy.ops.object.editmode_toggle()
        
        mesh=context.active_object.data
        bm=bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        try:
            face=bm.faces.active if bm.faces.active and not bm.faces.active.hide else None
            
            if not face:
                face=[f for f in bm.faces if f.select and not f.hide]
                if face:
                    face=face[0]
            #print(face)
            if face.select:
                local_normal=face.normal
                eul = Euler((0.0, 0.0, 0.0), 'XYZ')
                if not (math.isclose(abs(local_normal.x), 0, abs_tol=0.003)and math.isclose(abs(local_normal.y), 0, abs_tol=0.003)):
                    a1=Vector((0,-1)).angle_signed(Vector((local_normal.x,local_normal.y)))
                    rot = Vector((0,0,1)).rotation_difference( local_normal ).to_euler()
                    eul= rot
                    eul = (eul.to_matrix() @ Matrix.Rotation(-a1, 3, 'Z')).to_euler()
                eul=obj_rotation@eul.to_matrix()
                context.space_data.region_3d.view_rotation=eul.to_quaternion()
        except:
            bpy.ops.view3d.view_axis(type='TOP',align_active=True, relative=False)
        return {'FINISHED'}
class RTOOLS_OT_Inset_Shrink2(bpy.types.Operator):
    bl_idname = "rtools.insetshrink"
    bl_label = "Inset Shrink"
    bl_description = "Shrink faces using Inset"
    bl_options = {"REGISTER","UNDO"}
    shrink:bpy.props.FloatProperty(default=0.1,name="Shrink Amount")
    use_individual:bpy.props.BoolProperty(default=False,name="Individual")
    @classmethod
    def poll(cls, context):
        return context.active_object #and context.mode=='OBJECT'
    def execute(self, context):
        
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        select_all()
        bpy.ops.mesh.inset(use_even_offset=True,use_edge_rail=True,thickness=self.shrink, depth=0,use_individual=self.use_individual)
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.delete(type='FACE')
        bpy.ops.object.editmode_toggle()
        
        return {'FINISHED'}
class RTOOLS_OT_Inset_Shrink(bpy.types.Operator):
    bl_idname = "rtools.insetshrink"
    bl_label = "Inset Shrink"
    bl_description = "Shrink faces using Inset"
    bl_options = {"REGISTER","UNDO"}
    use_individual:bpy.props.BoolProperty(default=False,name="Individual")
    pcutter:bpy.props.BoolProperty(default=True)
    object:bpy.props.StringProperty(default="Object",options={'HIDDEN'})
    inset_shrink_pcutter:bpy.props.BoolProperty(default=False,options={'HIDDEN','SKIP_SAVE'})
    inset_shrink_solidify:bpy.props.BoolProperty(default=False,options={'HIDDEN','SKIP_SAVE'})
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='OBJECT' and context.active_object.type=='MESH'
    
    def main(self,context):
        bm=bmesh.new()
        bm.from_mesh(self.duplicate_mesh)
        bm.faces.ensure_lookup_table()
        faces=[f for f in bm.faces]
        faces=bmesh.ops.inset_region(bm,faces=faces,thickness=self.inset_amount,use_boundary=True,use_even_offset=True)
        bm.faces.ensure_lookup_table()
        #print(faces)
        verts=set([])
        facesToKeep=[f for f in bm.faces if f not in faces['faces']]
        for f in facesToKeep:
            verts.update(f.verts)
        vertsToDelete=[v for v in bm.verts if v not in verts]
        #print(vertsToDelete)
        bmesh.ops.delete(bm,geom=list(vertsToDelete))
        bm.to_mesh(self.ogMesh)
        self.ogMesh.update()
        bm.free()
    def modal(self, context,event):
        if event.type=='ESC'and event.value=='PRESS':
            if self.inset_shrink_pcutter or self.inset_shrink_solidify:
                delete_object_with_data(self.ogObject)
            delete_object_with_data(self.dup)
            return {'CANCELLED'}
        if event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.inset_amount_copy=self.inset_amount
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=5 
        if event.type == 'LEFT_CTRL':
            self.init_x=event.mouse_x
            self.inset_amount_copy=self.inset_amount
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=2
            elif event.value == 'RELEASE':
                self.speed=5 
        if event.type=='MOUSEMOVE':
            self.inset_amount=self.inset_amount_copy-(self.init_x-event.mouse_x)/((200 *self.speed))  
            self.main(context)
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS':
            delete_object_with_data(self.dup)
            if self.inset_shrink_pcutter:
                select(self.ogObject)
                bpy.ops.object.editmode_toggle()
                select_all()
                bpy.ops.mesh.dissolve_limited(angle_limit=0.0174533)
                bpy.ops.object.editmode_toggle()
                select(bpy.data.objects[self.object])
                select(self.ogObject)
                bpy.ops.rtools.createboolean('INVOKE_DEFAULT',center_location=self.ogObject.location,draw=False,from_inset_shrink=True)
            elif self.inset_shrink_solidify:
                select(self.ogObject)
                bpy.ops.rtools.solidify('INVOKE_DEFAULT')
            return {'FINISHED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        self.speed=1
        self.init_x=event.mouse_x
        self.inset_amount_copy=0
        self.inset_amount=0
        self.ogObject=context.active_object
        self.ogMesh=context.active_object.data
        dup=duplicate_object(context.active_object)
        dup.hide_view=True
        self.dup=dup
        if len(self.dup.users_collection)>0:
            self.dup.users_collection[0].objects.unlink(self.dup)  
        self.duplicate_mesh=dup.data
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
def vgroups_enum_items(self, context):
    obj=context.active_object
    return {(g.name,g.name,g.name) for g in obj.vertex_groups}
class RTOOLS_OT_Create_Boolean_Cleanup_VGroups(bpy.types.Operator):
    bl_idname = "rtools.createbooleanvgroups"
    bl_label = "Merge Nearby Vertices"
    bl_description = "Merge adjacent vertices with the selected vertices(Selected Vertices are not merged with each other)"
    bl_options = {"REGISTER","UNDO"}
    threshold:bpy.props.FloatProperty(default=0.02,name="Distance",min=0.000001,step=0.1)
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='EDIT_MESH'
    def execute(self, context):
        bpy.ops.mesh.select_mode(type="VERT")
        bm=bmesh.from_edit_mesh(context.active_object.data)
        
        selected=[v for v in bm.verts if v.select]
        selected_locations=[v.co for v in selected]
        #print(selected)

        
        #maskGroup=context.active_object.vertex_groups.new(name="Selected")
        #context.active_object.vertex_groups.active_index=len(context.active_object.vertex_groups)-1
        #bpy.ops.object.vertex_group_select()
        #bpy.ops.object.vertex_group_remove_from()
        
        #bpy.ops.object.editmode_toggle() 
        #context.view_layer.update()
        #maskGroup.add(selected,1,'REPLACE')
        
        #bpy.ops.object.vertex_group_assign_new()
        #bpy.ops.object.editmode_toggle() 
        #deselect_all()
        #bpy.ops.object.vertex_group_select()
        bpy.ops.mesh.select_more(use_face_step=False)
        #bpy.ops.object.vertex_group_deselect()
        nearby=[v for v in bm.verts if v.select and v not in selected]
        
        for v in nearby:
                    closest=(10000000,v)
                    for v_other in selected:
                        if (v.co-v_other.co).length <=self.threshold:
                            if closest[0]>(v.co-v_other.co).length:
                                closest=((v.co-v_other.co).length,v_other)
                    v.co=closest[1].co
        #bpy.ops.object.editmode_toggle()
        hidden=[]
        for v in bm.verts:
            if v not in nearby+selected:
                hidden.append(v)
                v.hide=True
        select_all()
        use_auto_merge=bpy.context.scene.tool_settings.use_mesh_automerge
        use_mesh_automerge_and_split=bpy.context.scene.tool_settings.use_mesh_automerge_and_split
        double_threshold=bpy.context.scene.tool_settings.double_threshold
        bpy.context.scene.tool_settings.use_mesh_automerge = True
        bpy.context.scene.tool_settings.use_mesh_automerge_and_split = True
        bpy.context.scene.tool_settings.double_threshold = 0.01
        bpy.ops.transform.translate(value=(0, 0, 0), orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
        
        bpy.ops.mesh.remove_doubles(threshold=0.0001)
        for v in hidden:
            v.hide=False 
        deselect_all()
        #bpy.ops.object.editmode_toggle()
        for v in bm.verts:
            if v.co in selected_locations:
                v.select=True
        context.active_object.data.update()
        bm.free()
        bpy.ops.object.editmode_toggle()  
        bpy.ops.object.editmode_toggle() 
        #bpy.ops.object.vertex_group_assign_new()
        bpy.context.scene.tool_settings.use_mesh_automerge=use_auto_merge
        bpy.context.scene.tool_settings.use_mesh_automerge_and_split=use_mesh_automerge_and_split
        bpy.context.scene.tool_settings.double_threshold=double_threshold
        return {'FINISHED'}

class RTOOLS_OT_Slide_Vertices(bpy.types.Operator):
    bl_idname = "rtools.slidevertices"
    bl_label = "Slide nearby Vertices"
    bl_description = "Slide nearby vertices away from the selection"
    bl_options = {"REGISTER","UNDO"}
    #merge_threshold:bpy.props.FloatProperty(default=0.02,name="Merge Threshold")
    distance:bpy.props.FloatProperty(name="Slide Distance",default=0.25,soft_max=10,min=-1)
    threshold:bpy.props.FloatProperty(name="Threshold",default=0.05,min=0)
    
    proportional:bpy.props.BoolProperty(default=False,name="Use Distance Proportional to edge length")
    connect_verts:bpy.props.BoolProperty(default=True,name="Connect Vertices")
    def execute(self, context):

         
        object_mode=False
        if context.mode=='OBJECT':
            object_mode=True
            bpy.ops.object.editmode_toggle()    
        bpy.ops.object.editmode_toggle()  
        bpy.ops.object.editmode_toggle() 
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.dissolve_limited(angle_limit=0.02)
        #bpy.ops.rtools.createbooleanvgroups('EXEC_DEFAULT')
        #bpy.ops.object.editmode_toggle()    
        #bpy.ops.rtools.mergevgroups('INVOKE_DEFAULT',threshold=self.merge_threshold,source=context.active_object.vertex_groups[len(context.active_object.vertex_groups)-1].name,target=context.active_object.vertex_groups[len(context.active_object.vertex_groups)-2].name)
        #bpy.ops.object.editmode_toggle()    
        obj=context.active_object
        
        mesh=obj.data
        bm= bmesh.from_edit_mesh(mesh)
        #bm=bmesh.new()
        #bm.from_mesh(mesh)
        selected=[v for v in bm.verts if v.select]
        nearby=set([])
        for v in selected:
            nearby.update([e.other_vert(v) for e in v.link_edges if e.other_vert(v) not in selected and (e.other_vert(v).co-v.co).length<self.threshold] )
        #print(len(nearby))
        #nearby=[v for v in nearby if v not in selected]
        #nearby=[v for v in bm.verts if v.select]
        nearby_with_edge=[]
        deselect_all()
        for v in nearby:
            distances=[(s,(s.co-v.co).length) for s in selected]
                #print([v.z for v in self.coords])
            closest=sorted(distances,key=lambda v:v[1])[0][0]
        
            nearby_with_edge.append((v,tuple([e.other_vert(v) for e in v.link_edges if e.other_vert(v) not in selected and e.other_vert(v) not in nearby]),closest))
            
        nearby_with_edge=set(nearby_with_edge)
        #bm.select_history.clear()
        for v in nearby_with_edge:
            max_angle=0
            selected_edge=None
            for e in v[1]:
                if (v[0].co-v[2].co).length>0 and (v[0].co-e.co).length >0 and  math.degrees((v[0].co-v[2].co).angle(v[0].co-e.co))>max_angle:
                    selected_edge=e
                    
                    max_angle=math.degrees((v[0].co-v[2].co).angle(v[0].co-e.co))
                
            if selected_edge:
                closest_distance=(v[0].co-v[2].co).length
                distance=min(self.distance,1)
                v[0].select=True
                
                #bm.select_history.add(v[0])
                if self.proportional:
                    v[0].co=v[0].co+(selected_edge.co-v[0].co)*distance
                else:
                    distance=min((self.distance/10)-closest_distance,(selected_edge.co-v[0].co).length)
                    v[0].co=v[0].co+(selected_edge.co-v[0].co).normalized()*distance      
         
        bpy.ops.mesh.remove_doubles(use_unselected=True,threshold=0.001)
        if self.connect_verts:
            #bpy.ops.mesh.vert_connect_path()
            bpy.ops.mesh.vert_connect()
        if object_mode:
            bpy.ops.object.editmode_toggle()
            bm.free()   
        #print(nearby_with_edge)
        return {'FINISHED'}
class RTOOLS_OT_Merge_VGroups(bpy.types.Operator):
    bl_idname = "rtools.mergevgroups"
    bl_label = "Merge Vertices From Vertex Groups"
    bl_description = "Merge vertices of 2 vertex groups by distance"
    bl_options = {"REGISTER","UNDO"}
    threshold:bpy.props.FloatProperty(default=0.02,name="Distance",min=0.000001,step=0.1)
    source:bpy.props.EnumProperty(items=vgroups_enum_items,name="Source")
    target:bpy.props.EnumProperty(items=vgroups_enum_items,name="Target")
    def execute(self, context):
        
        obj=context.active_object
        if len(obj.vertex_groups)<2:
            self.report({'WARNING'},"Object needs to have atleast 2 Vertex Groups")
            return {'CANCELLED'}
        if self.source!='' and self.target!='':
            mesh = obj.data  # Get selected object's mesh
            bm =bmesh.new()
            bm.from_mesh(mesh)
            source_index=[v.index for v in  obj.vertex_groups if v.name==self.source][0]
            target_index=[v.index for v in  obj.vertex_groups if v.name==self.target][0]
            source=[v for v in mesh.vertices if source_index in [n.group for n in v.groups]]
            target=[v for v in mesh.vertices if target_index in [n.group for n in v.groups]]
            
            for v in source:
                        closest=(10000000,v)
                        for v_other in target:
                            if (v.co-v_other.co).length <=self.threshold:
                                if closest[0]>(v.co-v_other.co).length:
                                    closest=((v.co-v_other.co).length,v_other)
                        v.co=closest[1].co
            bpy.ops.object.editmode_toggle()
            
            select_all()
            bpy.context.scene.tool_settings.use_mesh_automerge = True
            bpy.context.scene.tool_settings.use_mesh_automerge_and_split = True
            bpy.context.scene.tool_settings.double_threshold = 0.002
            bpy.ops.transform.translate(value=(0, 0, 0), orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
            
            bpy.ops.mesh.remove_doubles(threshold=0.0001)
            bpy.ops.object.editmode_toggle()
            context.active_object.data.update()
        return {'FINISHED'}
class RTOOLS_OT_Align_Normal_To_Axis(bpy.types.Operator):
    bl_idname = "rtools.alignnormaltoaxis"
    bl_label = "Align normal to axis"
    bl_description = "Align Active face normal to any of the axes\nTip: Select 2 faces, first the face you want to align to horizontal axis and then the face you want to align to the vertical axis"
    bl_options = {"REGISTER","UNDO"}
    #('-X','-X','-X'),('-Y','-Y','-Y'),('-Z','-Z','-Z')
    axis: bpy.props.EnumProperty(items=(('X','X','X'),('Y','Y','Y'),('Z','Z','Z')),name="Axis",description="Does not matter when 2 faces are selected")
    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode=='EDIT_MESH'
    def execute(self,context):
        def main(face,context,axis):
            normal=face.normal
            normal=context.active_object.rotation_euler.to_matrix()@normal
            normal_on_xz=normal.copy()
            #print(angle)
            normal_on_xz.x=0
            
            d=0 if math.isclose(normal_on_xz.magnitude,0) else normal_on_xz.magnitude
            angle_y = -math.asin(normal.x)
            
            norm_by_d=1*(-1 if normal.z<0 else 1) if math.isclose(abs(normal.z),d,abs_tol=0.003) else normal.z / d 
            
            angle_x = 0 if math.isclose(d,0) else math.acos(norm_by_d) * (1 if normal.y >= 0 else -1)
            #print(math.degrees(angle_x),math.degrees(angle_y))
            rotatey     = Matrix.Rotation(angle_y, 4, 'Y')
            rotatex     = Matrix.Rotation(angle_x, 4, 'X')
            context.active_object.matrix_world=rotatey@rotatex@context.active_object.matrix_world
            if axis=='X':
                rotatey     = Matrix.Rotation(math.radians(90), 4, 'Y')
                context.active_object.matrix_world=rotatey@context.active_object.matrix_world
            elif axis=='Y':
                rotatey     = Matrix.Rotation(math.radians(90), 4, 'X')
                context.active_object.matrix_world=rotatey@context.active_object.matrix_world
        mesh=context.active_object.data
        bm=bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        face=bm.faces.active
        selected_faces=[f for f in bm.faces if f.select]
        if len(selected_faces)==2:
            selected_face=Diff(selected_faces,[face])[0]
            try:
                main(selected_face,context,'X')
                if face.select:
                    main(face,context,'Z')
                #axis=(1 if 'X' in self.axis else 0,1 if 'Y' in self.axis else 0,1 if 'Z' in self.axis else 0)
               # if '-' in self.axis:
               #     axis=(-axis[0],-axis[1],-axis[2])
                #rot = Vector(axis).rotation_difference(normal).to_euler()
                #print(math.degrees(rot[0]),math.degrees(rot[1]),math.degrees(rot[2]))
                #context.active_object.rotation_euler=rot
                #bpy.ops.object.editmode_toggle()
                #bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            except:
                pass
        else:
            try:
                if face.select:
                    main(face,context,self.axis)
                    #axis=(1 if 'X' in self.axis else 0,1 if 'Y' in self.axis else 0,1 if 'Z' in self.axis else 0)
                # if '-' in self.axis:
                #     axis=(-axis[0],-axis[1],-axis[2])
                    #rot = Vector(axis).rotation_difference(normal).to_euler()
                    #print(math.degrees(rot[0]),math.degrees(rot[1]),math.degrees(rot[2]))
                    #context.active_object.rotation_euler=rot
                    #bpy.ops.object.editmode_toggle()
                    #bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            except:
                pass
        return {'FINISHED'}
class RTOOLS_OT_Origin_To_Bottom(bpy.types.Operator):
    bl_idname = "rtools.origintobottom"
    bl_label = "Origin to Bottom"
    bl_description = "Move origin to the bottom of the object"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.selected_objects
    def execute(self,context):
        active=context.active_object
        for obj in context.selected_objects:
            #bbverts = 
            lowest_pt = min([(obj.matrix_world @
                   Vector(corner)).z for corner in obj.bound_box])
            cursorLocBackUp=bpy.context.scene.cursor.location.copy()
            bpy.context.scene.cursor.location=(obj.location[0],obj.location[1],lowest_pt)
            bpy.ops.object.origin_set({'selected_objects':[obj,],'acitve_object':obj,'object':obj,'selected_editable_objects':[obj,]},type='ORIGIN_CURSOR')
            bpy.context.scene.cursor.location=cursorLocBackUp
        return {'FINISHED'}
class RTOOLS_OT_Recall_Last_Cutter(bpy.types.Operator):
    bl_idname = "rtools.recalllastcutter"
    bl_label = "Recall Last Cutter"
    bl_description = "Recall Last Cutter used in P-Cutter"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and context.scene.rt_tools.last_cutter_object
    def execute(self,context):
        rt_tools=context.scene.rt_tools
        if rt_tools.last_cutter_object:
            deselect_all()
            select(rt_tools.last_cutter_object)
            if rt_tools.last_cutter_index<len(rt_tools.last_cutter_object.CuttersInfo):
                bpy.ops.rtools.recallcutter('INVOKE_DEFAULT',index=rt_tools.last_cutter_index)
        return {'FINISHED'}
class RTOOLS_OT_Select_Children(bpy.types.Operator):
    bl_idname = "rtools.selectchildren"
    bl_label = "Focus Children"
    bl_description = "Select and focus children"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT'
    def execute(self,context):
        active=context.active_object
        if active and active.type=='EMPTY':
            if active:
                if context.space_data.local_view:
                    bpy.ops.view3d.localview(frame_selected=False)
                deselect_all()
                for c in active.children:
                    c.hide_view=False
                    select(c)
                
                bpy.ops.view3d.localview(frame_selected=True)

            return {'FINISHED'}
        else:
            return {'PASS_THROUGH'}
class RTOOLS_OT_Select_Edges_Marked_Sharp(bpy.types.Operator):
    bl_idname = "rtools.selectsharp"
    bl_label = "Select Sharp Edges"
    bl_description = "Select all sharp enough edges\nCTRL+LMB:Also Set weights to 1\nSHIFT+LMB: Clear Weights"
    bl_options = {"REGISTER","UNDO"}
    angle:bpy.props.FloatProperty(default=0.523599,name="Sharpness",subtype ="ANGLE",min=0.0174533)
    mark_sharp:bpy.props.BoolProperty(default=False,name="Set Weight",options={'SKIP_SAVE'})
    clear_sharp:bpy.props.BoolProperty(default=False,name="Clear Weight",options={'SKIP_SAVE'})
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        
        active=context.active_object
        mesh=active.data
        """
        
        deselect_all()
        edges_to_select=[]
        for e in mesh.edges:
            if e.use_edge_sharp:
                edges_to_select.append(e.index)
        bm= bmesh.from_edit_mesh(mesh)
        bm.edges.ensure_lookup_table()
        for e in bm.edges:
            if e.index in edges_to_select:
                e.select_set(True)"""
        
        old_selection=[e.index for e in mesh.edges if e.select]
        if len(old_selection)==0:
            old_selection=[e.index for e in mesh.edges]
        deselect_all()
            
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.edges_select_sharp(sharpness=self.angle)
        bm= bmesh.from_edit_mesh(mesh)
        bm.edges.ensure_lookup_table()
        new_selection=[a.index for a in bm.edges if a.select]
        deselect_all()
        for a in bm.edges:
            if a.index in old_selection and a.index in new_selection:
                a.select_set(True)
        bmesh.update_edit_mesh(mesh)
        if self.mark_sharp:
            bpy.ops.transform.edge_bevelweight(value=1)

            #bpy.ops.rtools.marksharp('INVOKE_DEFAULT')
        if self.clear_sharp:
            bpy.ops.transform.edge_bevelweight(value=-1)
            #py.ops.mesh.mark_sharp('INVOKE_DEFAULT',clear=True)
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        #bmesh.update_edit_mesh(mesh)
        return {'FINISHED'}
    def invoke(self, context, event):
        if event.ctrl:
            self.mark_sharp=True
        elif event.shift:
            self.clear_sharp=True
        return self.execute(context)
class RTOOLS_OT_Mark_Sharp(bpy.types.Operator):
    bl_idname = "rtools.marksharp"
    bl_label = "Mark Sharp"
    bl_description = "Mark selected edges as sharp\nCTRL+LMB:Clear Sharp\nALT+LMB:Select edges marked as sharp"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        if self.ctrl:
            bpy.ops.mesh.mark_sharp('INVOKE_DEFAULT',clear=True)
        elif self.alt:
            bpy.ops.rtools.selectedgesbytrait('INVOKE_DEFAULT',trait='Sharp')
        else:
            bpy.ops.mesh.mark_sharp('INVOKE_DEFAULT')
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}
    def invoke(self, context, event):
        self.ctrl=event.ctrl
        self.alt=event.alt
        return self.execute(context)
class RTOOLS_OT_Mark_Seam(bpy.types.Operator):
    bl_idname = "rtools.markseam"
    bl_label = "Mark Seam"
    bl_description = "Mark selected edges as seam\nCTRL+LMB:Clear Seam\nALT+LMB:Select edges marked as seam"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        if self.ctrl:
            bpy.ops.mesh.mark_seam('INVOKE_DEFAULT',clear=True)
        elif self.alt:
            bpy.ops.rtools.selectedgesbytrait('INVOKE_DEFAULT',trait='Seam')
        else:
            bpy.ops.mesh.mark_seam('INVOKE_DEFAULT')
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}
    def invoke(self, context, event):
        self.ctrl=event.ctrl
        self.alt=event.alt
        return self.execute(context)
class RTOOLS_OT_Bevel_Weight(bpy.types.Operator):
    bl_idname = "rtools.bevelweight"
    bl_label = "Adjust Bevel Weight"
    bl_description = "Adjust Bevel Weights"
    bl_options = {"REGISTER","UNDO"}
    attribute:bpy.props.StringProperty(default='Bevel Weight',options={'HIDDEN'})
    @classmethod
    def description(cls, context, properties):
        return f"Adjust {properties.attribute} of the Edges"
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def draw_callback_px(self,context):
        average=format(round(sum(a[0][self.bevelWeightLayer] for a in self.edges)/len(self.edges),2),'.2f')
        change=("+" if self.edges[0][0][self.bevelWeightLayer]-self.edges[0][1]>0 else "")+f"{format(round(self.edges[0][0][self.bevelWeightLayer]-self.edges[0][1],2),f'.{len(self.increment)-1}f')}"
        draw_Text(context,0,preferences().font_size,text=[f"ALT : Select all edges with {self.attribute}",f"CTRL : Clear {self.attribute}",f"{self.attribute} : {average}"],alignH="CENTER")
    def modal(self, context,event):
        self.mouse_x,self.mouse_y=event.mouse_region_x,event.mouse_region_y
        if event.mouse_x>context.region.x+context.region.width-5:
            context.window.cursor_warp(context.region.x,event.mouse_y)
            self.edges_backup=[]
            for (e,w) in self.edges:
                #print("Shift",e[self.bevelWeightLayer])
                weight=float(e[self.bevelWeightLayer])
                self.edges_backup.append((e,weight))
            self.init_x=context.region.x
        if event.mouse_x<context.region.x+2:
            context.window.cursor_warp(context.region.x+context.region.width,event.mouse_y)
            self.init_x=context.region.width
            self.edges_backup=[]
            for (e,w) in self.edges:
                #print("Shift",e[self.bevelWeightLayer])
                weight=float(e[self.bevelWeightLayer])
                self.edges_backup.append((e,weight))
        if event.type == 'LEFT_SHIFT':
            self.init_x=event.mouse_x
            self.edges_backup=[]
            for (e,w) in self.edges:
                #print("Shift",e[self.bevelWeightLayer])
                weight=float(e[self.bevelWeightLayer])
                self.edges_backup.append((e,weight))
                #print(weight)
            #print("Shift",self.activePropCopy)
            if event.value == 'PRESS':
                self.speed=50
            elif event.value == 'RELEASE':
                self.speed=5 
        if event.type=='MOUSEMOVE' :
            for i,(e,w) in enumerate(self.edges):
                #print(self.edges_backup)
                e[ self.bevelWeightLayer ] = myround2(self.edges_backup[i][1]-(self.init_x-event.mouse_x)/((200 *self.speed)),base=eval(self.increment) ) 
            bmesh.update_edit_mesh( self.mesh )
            return {'RUNNING_MODAL'}
        if event.type=='LEFTMOUSE':
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=='RIGHTMOUSE' or event.type=='ESC':
            for i,(e,w) in enumerate(self.edges):
                e[ self.bevelWeightLayer ] = w
            bmesh.update_edit_mesh( self.mesh )
            self.remove_drawHandler(context)
            return {'FINISHED'}
        if event.type=="LEFT_CTRL":
            if event.value =='PRESS':
                self.remove_drawHandler(context)
                bpy.ops.rtools.clearedges('INVOKE_DEFAULT',all=False,trait=self.attribute)
                return {'FINISHED'}
        if event.type=="LEFT_ALT":
            if event.value =='PRESS':
                self.remove_drawHandler(context)
                bpy.ops.rtools.selectedgesbytrait('INVOKE_DEFAULT',trait=self.attribute)
                return {'FINISHED'}
        if event.type=='MIDDLEMOUSE':
            return {'PASS_THROUGH'}
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}
    def invoke(self,context,event):
        
        active=context.active_object
        mesh=active.data
        self.bm= bmesh.from_edit_mesh(mesh)
        if self.attribute=="Bevel Weight":
            self.bevelWeightLayer = self.bm.edges.layers.bevel_weight.verify()
            self.increment=".1"
        else:
            self.bevelWeightLayer = self.bm.edges.layers.crease.verify()
            self.increment=".001"
        try:
            mesh.use_customdata_edge_bevel = True
        except:
            pass
        self.mesh=mesh
        self.edges=[]
        self.edges_backup=[]
        self.speed=5
        self.init_x=event.mouse_x
        selected = [ v for v in self.bm.edges if v.select ]
        for e in selected:
            self.edges.append((e,e[self.bevelWeightLayer]))
        for e,w in self.edges:
                self.edges_backup.append((e,e[self.bevelWeightLayer]))
        
        #for e in mesh.edges:
        #    if e.select:
        #        self.edges.append((e,e.bevel_weight))
        self.add_drawHandler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
class RTOOLS_OT_Edge_Bevel_Weight(bpy.types.Operator):
    bl_idname = "rtools.edge_bevelweight"
    bl_label = "Bevel Weight"
    bl_description = "Adjust Bevel Weight\nCTRL+LMB: Adjust Only the Selected Edges"
    bl_options = {"REGISTER","UNDO"}
    attribute:bpy.props.StringProperty(default='Bevel Weight',options={'HIDDEN'})
    @classmethod
    def description(cls, context, properties):
        return translate_text(f"Adjust {properties.attribute} of edges with similar values\nSHIFT+LMB: Adjust Only the Selected Edges\nCTRL+LMB:Clear {properties.attribute}\nALT+LMB:Select All Edges with {properties.attribute}")
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        mesh=context.active_object.data
        if len([e for e in mesh.edges if e.select])==1 and not self.shift and not self.ctrl and not self.alt:
            for e in [e for e in mesh.edges if e.select]:
                if self.attribute=="Bevel Weight":
                    if e.bevel_weight:
                        bpy.ops.mesh.select_similar(type='BEVEL', compare='EQUAL', threshold=0.0010)
                        break
                else:
                    if e.crease:
                        bpy.ops.mesh.select_similar(type='CREASE', compare='EQUAL', threshold=0.0010)
                        break
        if self.ctrl:
            bpy.ops.rtools.clearedges('INVOKE_DEFAULT',all=False,trait=self.attribute)
        elif self.alt:
            bpy.ops.rtools.selectedgesbytrait('INVOKE_DEFAULT',trait=self.attribute)
        else:
            bpy.ops.rtools.bevelweight('INVOKE_DEFAULT',attribute=self.attribute)
        #bpy.ops.transform.edge_bevelweight('INVOKE_DEFAULT')
        return {'FINISHED'}
    def invoke(self, context, event):
        self.ctrl=event.ctrl
        self.alt=event.alt
        self.shift=event.shift
        return self.execute(context)
class RTOOLS_OT_Clear_Edges(bpy.types.Operator):
    bl_idname = "rtools.clearedges"
    bl_label = "Clear All Edges"
    bl_description = "Clear All Edge Weights\nCTRL+LMB: Clear All Seamed Edges\nSHIFT+LMB: Clear All Sharp Edges\nALT+LMB: Clear all creased edges"
    bl_options = {"REGISTER","UNDO"}
    all:bpy.props.BoolProperty(default=True,options={'HIDDEN','SKIP_SAVE'})
    trait:bpy.props.StringProperty(default="",options={'HIDDEN','SKIP_SAVE'})
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        if self.all:
            select_all()
        if self.ctrl:
            bpy.ops.mesh.mark_seam(clear=True)
        elif self.shift:
            bpy.ops.mesh.mark_sharp(clear=True)
            
        elif self.crease:
            bpy.ops.transform.edge_crease(value=-2)
        else:
            bpy.ops.transform.edge_bevelweight(value=-2)
        return {'FINISHED'}
    def invoke(self, context, event):
        if self.trait:
            self.ctrl=self.trait=="Seam"
            self.shift=self.trait=="Sharp"
            self.weight=self.trait=="Bevel Weight"
            self.crease=self.trait=="Crease"
        else:
            self.ctrl=event.ctrl
            self.shift=event.shift
            self.crease=event.alt
            self.weight=not self.ctrl and not self.crease and not self.shift
        return self.execute(context)
class RTOOLS_OT_Select_Edges(bpy.types.Operator):
    bl_idname = "rtools.selectedgesbytrait"
    bl_label = "Select Edges"
    bl_description = "Select all Edges marked as sharp\nCTRL+LMB: Select all Edges marked as seams"
    bl_options = {"REGISTER","UNDO"}
    trait:bpy.props.StringProperty(default="",options={'SKIP_SAVE','HIDDEN'},name="Trait")
    @classmethod
    def description(cls, context, properties):
        return "Select all Edges marked as "+properties.trait

    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        deselect_all()
        bm=bmesh.from_edit_mesh(context.active_object.data)
        bm.edges.ensure_lookup_table()
        if self.trait=="Sharp":
            for e in bm.edges:
                if not e.smooth:
                    e.select=True
        elif self.trait=="Seam":
            for e in bm.edges:
                if e.seam:
                    e.select=True
        elif self.trait=="Crease":
            layer = bm.edges.layers.crease.verify()
            for e in bm.edges:
                if e[layer]:
                    e.select=True
        elif self.trait=="Bevel Weight":
            layer = bm.edges.layers.bevel_weight.verify()
            for e in bm.edges:
                if e[layer]:
                    e.select=True
        return {'FINISHED'}
    def invoke(self, context, event):
        self.ctrl=event.ctrl
        self.shift=event.shift
        return self.execute(context)
class RTOOLS_OT_Set_Weights(bpy.types.Operator):
    bl_idname = "rtools.setweight"
    bl_label = "Set/Clear Bevel Weight"
    bl_description = "Set/Clear Bevel Weight"
    bl_options = {"REGISTER","UNDO"}
    value:bpy.props.IntProperty(default=1,options={'HIDDEN'})
    @classmethod
    def poll(cls, context):
        return context.mode=='EDIT_MESH'
    def execute(self,context):
        bpy.ops.transform.edge_bevelweight(value=self.value)
        return {'FINISHED'}
class RTOOLS_OT_Generate_All_Thumbnails(bpy.types.Operator):
    bl_idname = "rtools.genthumbs"
    bl_label = "Create Thumbnails for all Materials"
    bl_description = "Create Thumbnails for all Materials marked as an asset"
    bl_options = {"REGISTER","UNDO"}
    def modal(self, context, event):
        if self.current>=self.count:

            self.report({'INFO'},"Finished!")
            return {'FINISHED'}
        elif event.type == 'TIMER':
            self.mats[self.current].asset_generate_preview()
            self.current+=1
            return {'RUNNING_MODAL'}
        elif event.type=='ESC' and event.value=='PRESS':
            self.cancel(context)
            self.report({'WARNING'},"Cancelled!")
            return {'CANCELLED'}
        return {'PASS_THROUGH'}
    def execute(self,context):
        self.current=0
        self.count=len(bpy.data.materials)
        self.mats=[m for m in bpy.data.materials if m.asset_data]
        wm = context.window_manager
        self.timer = wm.event_timer_add(1,window= context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    def cancel(self,context):
        wm = context.window_manager
        wm.event_timer_remove(self.timer)