import bpy
from . utils import * 
import bmesh
class RTOOLS_OT_Prepare_Cloth(bpy.types.Operator):
    bl_idname = "rtools.preparecloth"
    bl_label = "Remesh for Cloth"
    bl_description = "Remesh for cloth (or any other purpose)"
    bl_options = {"REGISTER","UNDO"}
    
    size:bpy.props.IntProperty(name="Remesh Scale",default=50,min=0,max=500,soft_max=100)
    subdiv_level: bpy.props.IntProperty(default=3,name="Subdivision Level",max=6,min=0,options={'SKIP_SAVE'})
    flip_normals: bpy.props.BoolProperty(default=False,name="Flip Normals",options={'SKIP_SAVE'})
    subdiv_method: bpy.props.EnumProperty(items=(('DICE','Dice Remesh','Dice Remesh'),('SUBDIV','Subsurf Modifier','Subsurf Modifier')),default=0,name="Subdivision Method")
    create_new:bpy.props.BoolProperty(default=True,name="Create Separate Object",description="Enable This To Use Only Selected Faces")
    individual_faces: bpy.props.BoolProperty(default=False,name="Use Individual Faces",description='Enabling This Will Automatically Enable SubDivision!')
    remesh_individual_faces: bpy.props.BoolProperty(default=True,name="Remesh Faces Individually")
    precise: bpy.props.BoolProperty(default=False,name="Precise")
    @classmethod
    def poll(cls, context):
            return context.active_object is not None and context.active_object.type=="MESH" 
    def draw(self, context):
        layout=self.layout
        if self.subdiv_method=='SUBDIV':
            layout.prop(self,'subdiv_level')
        else:
            layout.prop(self,'size')
            layout.prop(self,'remesh_individual_faces')
            layout.prop(self,'precise')
        #layout.prop(self,'flip_normals')
        #layout.prop(self,'remesh')
        layout.prop(self,'subdiv_method')
        #layout.prop(self,'subdivide')
        layout.prop(self,'create_new')
        #if self.subdiv_method=='SUBDIV':
        if  self.subdiv_method=='SUBDIV' or self.remesh_individual_faces:
            layout.prop(self,'individual_faces')   
        
    def execute(self, context):
        inObjectMode=context.active_object.mode == 'OBJECT'
        edit_mode=context.mode=='EDIT_MESH'
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.context.space_data.overlay.show_wireframes = True

        
        obj=context.active_object
        if self.create_new:
            if inObjectMode:
                bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.duplicate_move()
            
            bpy.ops.mesh.separate(type='SELECTED')

            bpy.ops.object.editmode_toggle()
            obj=Diff(context.selected_objects,[context.active_object])[0]
            for m in obj.modifiers:
                bpy.ops.object.modifier_remove(
                    {'object': obj}, modifier=m.name)
            bpy.ops.object.select_all(action='DESELECT')
            select(obj,active=True)
            if not self.individual_faces and self.subdiv_method=='SUBDIV':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.dissolve_limited()
                bpy.ops.object.mode_set(mode='OBJECT')
        
        #if self.remesh:
        if self.subdiv_method=='DICE':

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
                if self.individual_faces:
                    edgeMod=obj.modifiers.new(name="RT_EdgeSplit",type="EDGE_SPLIT")
                    edgeMod.use_edge_angle=True
                    edgeMod.split_angle=0
                    bpy.ops.object.modifier_apply(modifier=edgeMod.name)
                bpy.ops.rtools.remeshdice('INVOKE_DEFAULT',size=self.size,dissolve=True,individually=self.remesh_individual_faces,threshold=0.2,precise=self.precise)
        if self.subdiv_method=='SUBDIV':

            bpy.ops.object.mode_set(mode='OBJECT')
            if self.individual_faces:
                edgeMod=obj.modifiers.new(name="RT_EdgeSplit",type="EDGE_SPLIT")
                edgeMod.use_edge_angle=True
                edgeMod.split_angle=0
                bpy.ops.object.modifier_apply(modifier=edgeMod.name)
            
            subMod=obj.modifiers.new(name="RT_SUBDIVISION",type="SUBSURF")
            subMod.subdivision_type='SIMPLE'
            subMod.levels=round(self.subdiv_level)
            bpy.ops.object.modifier_apply(modifier=subMod.name)
        bpy.ops.object.mode_set(mode='EDIT')
        maskGroup=obj.vertex_groups.new(name="RT_ClothPin")
        obj.last_clothpin_group_name=maskGroup.name
        mesh = obj.data  # Get selected object's mesh
        bm = bmesh.from_edit_mesh(mesh)
        bpy.ops.mesh.select_all(action='SELECT')
        if self.flip_normals:
            bpy.ops.mesh.flip_normals() 
        bpy.ops.mesh.region_to_loop()
        selected=[]
        for v in bm.verts:
            if v.select:
                #print(v.index)
                selected.append(v.index)
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.shade_smooth()
        obj.data.use_auto_smooth=True
        obj.data.auto_smooth_angle=1.047
        maskGroup.add(selected,1,'REPLACE')
        #bpy.ops.screen.animation_play()
        if edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self)
class RTOOLS_OT_Create_Cloth(bpy.types.Operator):
    bl_idname = "rtools.createcloth"
    bl_label = "Create Cloth"
    bl_description = "Create cloth Panels"
    bl_options = {"REGISTER","UNDO"}
    pressure: bpy.props.FloatProperty(name="Pressure",default=20)
    shrink:bpy.props.FloatProperty(name="Shrink",default=-0.1,min=-1,max=1)
    stiffness:bpy.props.FloatProperty(name="Stiffness",default=1,min=0,max=10)
    
    subdivide_afterwards: bpy.props.BoolProperty(default=True,name="Add Subsurf modifier after cloth")
    @classmethod
    def poll(cls, context):
            return context.active_object and context.active_object.type=="MESH" 
    def draw(self, context):
        layout=self.layout
        layout.prop(self,'pressure')
        layout.prop(self,'shrink')
        layout.prop(self,'stiffness')
            
        layout.prop(self,'subdivide_afterwards')
    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.space_data.overlay.show_wireframes = False
        bpy.context.scene.frame_set(0)
        bpy.ops.screen.animation_cancel()
        #print(context.active_object)
        obj=context.active_object
        self.obj=obj
        for m in obj.modifiers:
            if m.type=='CLOTH':
                obj.modifiers.remove(m)
                break
        clothMod=obj.modifiers.new(name='RT_Cloth',type='CLOTH')
        #print(clothMod)
        clothMod.settings.use_pressure=True
        clothMod.settings.uniform_pressure_force=self.pressure
        clothMod.settings.vertex_group_mass=obj.last_clothpin_group_name
        clothMod.settings.shrink_min=self.shrink
        clothMod.settings.pin_stiffness=self.stiffness
        
        clothMod.settings.effector_weights.gravity=0
        clothMod.settings.quality=5
        clothMod.settings.time_scale=10
        clothMod.settings.compression_stiffness=50
        clothMod.settings.mass=1
        self.clothMod=clothMod
        if self.subdivide_afterwards:
            self.subsurfMod=obj.modifiers.new(type='SUBSURF',name="RT_Cloth_Subsurf")
            self.subsurfMod.boundary_smooth='PRESERVE_CORNERS'
        #print(obj.modifiers[:])
        bpy.ops.screen.animation_play()
        return {'FINISHED'}
class RTOOLS_OT_Planer_Remesh(bpy.types.Operator):
    bl_idname = "rtools.planerremesh"
    bl_label = "Planar Remesh"
    bl_description = "Remesh Planar Meshes"
    bl_options = {"REGISTER","UNDO"}
    size: bpy.props.FloatProperty(name="Scale",default=0.75,min=0.001,max=0.990)
    threshold:bpy.props.FloatProperty(name="Threshold",default=0.1,min=0.001,max=0.990)
    octals:bpy.props.IntProperty(name="Levels",default=7,max=9,min=1)
    flip_normals: bpy.props.BoolProperty(default=False,name="Flip Normals")
    use_planer: bpy.props.BoolProperty(default=True,options={'HIDDEN'})
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and context.active_object is not None and context.active_object.type in {'MESH','FONT','SURFACE','CURVE'}
        
    def execute(self, context):
        
        thickness=0.0001
        obj=context.active_object
        convert_to_mesh(obj)
        mod=obj.modifiers.new(name='RT_Solidify',type='SOLIDIFY')
        mod.thickness=thickness
        remeshMod=obj.modifiers.new(name='RT_Remesh',type='REMESH')
        remeshMod.mode="SHARP"
        remeshMod.scale=self.size
        remeshMod.octree_depth=self.octals
        remeshMod.threshold=self.threshold
        convert_to_mesh(obj)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all()
        bpy.ops.mesh.remove_doubles(threshold=thickness*1.1)
        if self.use_planer:
            bpy.ops.transform.resize(value=(1, 1, 0), orient_type='NORMAL', orient_matrix_type='NORMAL', constraint_axis=(False, False, True), mirror=True)
        if not self.flip_normals:
            bpy.ops.mesh.flip_normals() 
        bpy.ops.object.mode_set(mode='OBJECT')
        self.use_planer=True
        return {"FINISHED"}
def get_coplanar_face_sets(bm,faces,threshold):
    face_sets=[]
    used_faces=[]
    for f in [a for a in faces if a.select]:
        #print(f.index)
        if f not in used_faces:
            _,cp_faces=coplanar_faces(bm,f,threshold,1)
            #print(cp_faces)
            #print([a.index for a in cp_faces if a.select  and a not in used_faces])
            face_sets.append([a.index for a in cp_faces if a.select  and a not in used_faces])
            used_faces.extend([a for a in cp_faces if a.select and a not in used_faces])
            
            
    return face_sets
def find_face(bm,centers):
    faces=[]
    for f in bm.faces:
        print(f.calc_center_bounds())
        if f.calc_center_bounds() in centers:
            faces.append(f)
    return faces
class RTOOLS_OT_Remesh_With_Dice(bpy.types.Operator):
    bl_idname = "rtools.remeshdice"
    bl_label = "Remesh Using Dice"
    bl_description = "Remesh Using Dice"
    bl_options = {"REGISTER","UNDO"}
    size: bpy.props.IntProperty(name="Scale",default=50,max=200,min=1,soft_max=100)
    cut_through:bpy.props.BoolProperty(default=False,name="Cut Through")
    dissolve: bpy.props.BoolProperty(default=True,name="Dissolve")
    only_selected: bpy.props.BoolProperty(default=False,name="Only Selected Faces")
    align_to_faces: bpy.props.BoolProperty(default=True,name="Align To Faces")
    individually: bpy.props.BoolProperty(default=True,name="Individual Faces")
    threshold: bpy.props.FloatProperty(name="Coplanar Threshold",default=0.2,min=0.0001,max=1,step=20)
    precise: bpy.props.BoolProperty(default=False,name="Precise")
    def draw(self,context):
        layout=self.layout
        layout.prop(self,'size')
        layout.prop(self,'only_selected')
        if not self.only_selected:
            layout.prop(self,'cut_through')
        layout.prop(self,'dissolve')

        layout.prop(self,'align_to_faces')
        layout.prop(self,'individually')
        layout.prop(self,'precise')
        if not self.precise:
            layout.prop(self,'threshold')
        
    def execute(self, context):
        initMat=context.space_data.region_3d.view_matrix.copy()
        edit_mode=context.mode=='EDIT_MESH'
        bpy.ops.object.mode_set(mode='EDIT')
        if self.individually:
            st=time.time()
            bm= bmesh.from_edit_mesh(context.active_object.data)
            bm.faces.ensure_lookup_table()
            selected=[a.index for a in bm.faces if a.select]
            coplanar_sets=get_coplanar_face_sets(bm,bm.faces,self.threshold)
            #print(selected)
            if self.precise:
                coplanar_sets=[]
                for s in selected:
                    coplanar_sets.append([s,])
            for s in coplanar_sets:
                deselect_all()
                for f in s: 
                    
                    bm.faces[f].select=True
                    bm.select_history.add(bm.faces[f])

                for t in bm.faces:
                    if not t.select:
                        t.hide=True
                    else:
                        t.hide=False
                #print("Remeshing:" , [t.index for t in bm.faces if not t.hide])
                bpy.ops.rtools.aligntoface('INVOKE_DEFAULT')
                context.space_data.region_3d.update()
                obj=context.active_object
                maxDim=max(obj.dimensions[:])
                self.scaleX=maxDim/1.5
                self.scaleY=maxDim/1.5
                bpy.ops.object.mode_set(mode='OBJECT')
                #print(self.size)
                context.space_data.region_3d.view_perspective='ORTHO'
                context.space_data.region_3d.update()
                bpy.ops.rtools.dice('EXEC_DEFAULT',origin_to_geometry=True,scaleX=self.scaleX,scaleY=self.scaleY,axis='Vertical',segments=self.size,dissolve=self.dissolve,cut_through=self.cut_through,remove_doubles=False)
                bpy.ops.rtools.dice('EXEC_DEFAULT',origin_to_geometry=True,scaleX=self.scaleX,scaleY=self.scaleY,axis='Horizontal',segments=self.size,dissolve=False,cut_through=self.cut_through,remove_doubles=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bm= bmesh.from_edit_mesh(context.active_object.data)
                bm.faces.ensure_lookup_table()
                #bpy.ops.mesh.reveal(select=False)
                for a in bm.faces:
                    a.hide=False
                bpy.ops.mesh.select_mode(type="FACE")
                context.space_data.region_3d.view_matrix=initMat
                #bpy.ops.view3d.view_persportho()
                context.space_data.region_3d.view_perspective='PERSP'
                context.space_data.region_3d.update()
            #print(time.time()-st)
            if not edit_mode:
                
                bpy.ops.object.mode_set(mode='OBJECT')
        else:
            if self.only_selected:
                bpy.ops.mesh.hide(unselected=True)
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.rtools.aligntoface('INVOKE_DEFAULT')
            #bpy.ops.view3d.view_axis(type='TOP', align_active=self.align_to_faces, relative=False)
            context.space_data.region_3d.update()
            obj=context.active_object
            maxDim=max(obj.dimensions[:])
            self.scaleX=maxDim/1.5
            self.scaleY=maxDim/1.5
            bpy.ops.object.mode_set(mode='OBJECT')
            #print(self.size)
            context.space_data.region_3d.view_perspective='ORTHO'
            context.space_data.region_3d.update()
            bpy.ops.rtools.dice('EXEC_DEFAULT',origin_to_geometry=True,scaleX=self.scaleX,scaleY=self.scaleY,axis='Vertical',segments=self.size,dissolve=self.dissolve,cut_through=self.cut_through,remove_doubles=False)
            bpy.ops.rtools.dice('EXEC_DEFAULT',origin_to_geometry=True,scaleX=self.scaleX,scaleY=self.scaleY,axis='Horizontal',segments=self.size,dissolve=False,cut_through=self.cut_through,remove_doubles=False)
            bpy.ops.object.mode_set(mode='EDIT')
            if self.only_selected:
                bpy.ops.mesh.reveal(select=False)
                
            bpy.ops.mesh.select_mode(type="FACE")
            if not edit_mode:
                
                bpy.ops.object.mode_set(mode='OBJECT')
            context.space_data.region_3d.view_matrix=initMat
            #bpy.ops.view3d.view_persportho()
            context.space_data.region_3d.view_perspective='PERSP'
            context.space_data.region_3d.update()
        
        return {'FINISHED'}