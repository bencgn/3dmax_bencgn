import re as regex
import bpy
import math
import blf
import os
import bgl
import difflib
import csv
from statistics import mean
import bmesh
from mathutils import geometry
import json
import gpu
from mathutils import Vector, Matrix, Euler
import time
import random
from itertools import combinations
from gpu_extras.batch import batch_for_shader
import socket
import requests
from .translations import japanese_translations,chinese_translation
import time
import functools
from ast import literal_eval
pi = 22.0/7.0
random_id_source = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"


def myceil(num, base):
    return base*math.ceil(num/base)


def Diff(li1, li2):
    return (list(list(set(li1)-set(li2)) + list(set(li2)-set(li1))))


def myround2(x, prec=2, base=.05):
    return round(base * round((float(x)/base)), prec)


def myround(x, base=5):
    return base * round(x/base)


def eulerToDegreeS(euler):
    return round(((euler) / (2 * pi)) * 360, 4)


def eulerToDegree(euler, roundTo=0.1):
    return [myround2(round(((euler[0]) / (2 * pi)) * 360, 4), 2, roundTo), myround2(round(((euler[1]) / (2 * pi)) * 360, 4), 2, roundTo), myround2(round(((euler[2]) / (2 * pi)) * 360, 4), 2, roundTo)]


def enable_abs(context):
    context.scene.eevee.use_bloom = True
    context.scene.eevee.use_gtao = True
    context.scene.eevee.use_ssr = True


def clamp(num, min_value, max_value):
    return max(min(num, max_value), min_value)


"""def update_lights(self, context):
    scene = context.scene
    rt_tools = scene.rt_tools
    select_all_lights()
    light_power_add(100*rt_tools.light_multiplier_global, use_percentage=True)"""


def moveToNewCollection(lastCol, lastL, newCol):
    lastCol = get_collection(lastCol)
    lastCol = bpy.data.collections[lastCol]
    if lastCol:
        for c in lastL.children:
            lastCol.objects.unlink(c)
        lastCol.objects.unlink(lastL)
        delete_collection(lastCol, delete_objects=False)
        link_to_collection(lastL, newCol)
        newCol = get_collection(newCol)
        move_to_collection(lastL, newCol)
        newCol = bpy.data.collections[newCol]

        if newCol:
            for o in lastL.children:
                newCol.objects.link(o)


def is_inside_box(box, cursor_x, cursor_y):
    return cursor_x > box[0][0] and cursor_x < box[0][1] and cursor_y > box[1][0] and cursor_y < box[1][1]


def current_selection(cursor_x, cursor_y, coords):
    for i, c in enumerate(coords):
        if is_inside_box(c, cursor_x, cursor_y):
            return i
    return None


def draw_buttons(context, font_id, font_size, text, alignH='CENTER', alignV='BOTTOM', padding=10, activeKey=None, start_x=None, start_y=None, box_start_x=None, box_start_y=None, draw_up_triangle=True, draw_down_triangle=True):
    # st=time.time()
    lcolor=preferences().text_color1
    rcolor=preferences().text_color2
    scolor=preferences().text_color3
    bg_color=preferences().bg_color
    blf.size(font_id, font_size, 72)
#    center=(context.region.width-blf.dimensions(font_id,text)[0])/2
    initY = 50
    n_panel = 0
    text = [a for a in text if a]
    n_panel_alignment = None
    for region in bpy.context.area.regions:
        if region.type == "UI":
            n_panel_alignment = region.alignment
            n_panel = min(region.width, 300)
            break
    #n_panel=150 if bpy.context.space_data.show_region_ui else 0

    if alignV != 'BOTTOM':
        initY = context.region.height - \
            (blf.dimensions(font_id, text[0])[1]*(len(text)))-50

    center = 0
    max_dim_x = 0
    startX = 200000
    dim_y = 0
    init_y = initY
    ycopy = initY
    if isinstance(text, str):
        text = {text}
    keys = []
    YWidths = []
    for t in text:
        YWidths.append(blf.dimensions(font_id, t)[1]+5)
        keys.append(t)
    max_y_dim = max(YWidths)-5
    max_y_dim = font_size
    maxYWidth = sum(YWidths)
    maxWidthKey = max(keys, key=width)
    if alignH == 'LEFT':
        center = 50+(n_panel if n_panel_alignment == 'LEFT' else 0)
    elif alignH == 'RIGHT':
        center = min([context.region.width-blf.dimensions(font_id, f"{maxWidthKey}")[
                     0]-30-(n_panel if n_panel_alignment == 'RIGHT' else 0) for t in text])
    else:
        # pass
        # center=center/2
        center = min([(context.region.width-blf.dimensions(font_id,
                                                           f"{maxWidthKey}")[0])/2 for t in text])
    if box_start_y:
        initY = box_start_y-maxYWidth-50
        init_y = box_start_y-maxYWidth-50
    for t in text:

        if blf.dimensions(font_id, t)[0] > max_dim_x:
            max_dim_x = blf.dimensions(font_id, f"{maxWidthKey}")[0]
        if center < startX:
            startX = center
        if box_start_x:
            center = box_start_x
            startX = box_start_x
        initY += max_y_dim+10
    gpu.state.blend_set("ALPHA")
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)

    # print(init_y,start_x)

    dim_y = initY-5
    # print(init_y,initY)
    vertices = (
        (startX-padding, init_y-padding), (startX +
                                           max_dim_x+padding+40, init_y-padding),
        (startX-padding, dim_y), (startX+max_dim_x+padding+40, dim_y))
    x_coords = [startX-padding, startX+max_dim_x+padding+40]
    indices = (
        (0, 1, 2), (2, 1, 3))
    edge_indices = [(0, 1), (1, 3), (3, 2), (2, 0)]
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(
        shader, 'TRIS', {"pos": vertices}, indices=indices)
    edge_batch = batch_for_shader(
        shader, 'LINES', {"pos": vertices}, indices=edge_indices)

    shader.bind()
    shader.uniform_float("color", bg_color)

    batch.draw(shader)
    shader.uniform_float("color", (1, 1, 1, 0.8))
    if not start_x:
        pass
        # edge_batch.draw(shader)

    initY = ycopy
    coords = []
    if box_start_y:
        initY = box_start_y-maxYWidth-50
    for t in text:
        if center < startX:
            startX = center
        if box_start_x:
            center = box_start_x
            startX = box_start_x
        blf.position(font_id, center, initY, 0)
        blf.color(font_id, lcolor[0],lcolor[1],lcolor[2],lcolor[3])
        if t != 'line':
            blf.draw(font_id, t)
        y_coords = [initY-2]
        initY += max_y_dim+10
        y_coords.append(initY-5)
        coords.append((x_coords, y_coords))
    current = current_selection(start_x, start_y, coords)

    gpu.state.blend_set("ALPHA")
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)
    if current is not None:
        vertices = (
            (coords[current][0][0], coords[current][1][0] -
             5), (coords[current][0][1], coords[current][1][0]-5),
            (coords[current][0][0], coords[current][1][1]-5), (coords[current][0][1], coords[current][1][1]-5))
        x_coords = [startX-padding, startX+max_dim_x+padding]
        indices = (
            (0, 1, 2), (2, 1, 3))
        edge_indices = [(0, 1), (1, 3), (3, 2), (2, 0)]
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(
            shader, 'TRIS', {"pos": vertices}, indices=indices)
        edge_batch = batch_for_shader(
            shader, 'LINES', {"pos": vertices}, indices=edge_indices)

        shader.bind()
        shader.uniform_float("color", (bg_color[0]+0.3,bg_color[1]+0.3,bg_color[2]+0.3, 0.5))

        batch.draw(shader)
    if draw_up_triangle:
        vertices = (
            ((startX-padding + startX+max_dim_x+padding+40)/2, dim_y +
             15), (((startX-padding + startX+max_dim_x+padding+40)/2)-10, dim_y+5),
            (((startX-padding + startX+max_dim_x+padding+40)/2)+10, dim_y+5))
        x_coords = [startX-padding, startX+max_dim_x+padding+40]
        indices = (
            (0, 1, 2),)
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(
            shader, 'TRIS', {"pos": vertices}, indices=indices)

        shader.bind()
        shader.uniform_float("color", scolor)
        batch.draw(shader)
    if draw_down_triangle:
        vertices = (
            ((startX-padding + startX+max_dim_x+padding+40)/2, init_y -
             25), (((startX-padding + startX+max_dim_x+padding+40)/2)-10, init_y-15),
            (((startX-padding + startX+max_dim_x+padding+40)/2)+10, init_y-15))
        x_coords = [startX-padding, startX+max_dim_x+padding+40]
        indices = (
            (0, 1, 2),)
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(
            shader, 'TRIS', {"pos": vertices}, indices=indices)

        shader.bind()
        shader.uniform_float("color", scolor)
        batch.draw(shader)
    gpu.state.blend_set("NONE")
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    # print(time.time()-st)
    return coords


def translate_text(text):
    if bpy.context.preferences.view.language == "ja_JP":
        if text.strip().lower() in japanese_translations.keys():
            key = japanese_translations[text.strip().lower()]
            return key
    elif bpy.context.preferences.view.language == "zh_CN":
        if text.strip().lower() in chinese_translation.keys():
            key = chinese_translation[text.strip().lower()]
            return key
    return text


def width(text):
    return blf.dimensions(0, text)[0]


def translate_list(text):
    translated = []
    for t in text:
        if ':' in t:
            key, action = t.split(':')
            key = translate_text(key)
            action_final = ""
            if "(" in action:
                # print(action)
                action1 = action[:action.index("(")]
                action1 = translate_text(action1)

                if action1 and action1[0] != " ":
                    action1 = " "+action1
                # print(action1)
                action2 = action[action.index("("):action.index(")")+1]

                action2 = translate_text(action2)
                if action2 and action2[0] != " ":
                    action2 = " "+action2
                # print(action2)
                action3 = action[action.index(")")+1:]
                action_final = action1+action2+action3
            else:
                action1 = translate_text(action)
                if action1 and action1[0] != " ":
                    action1 = " "+action1
                action_final = action1
            if action_final and action_final[0] != " ":
                action_final = " "+action_final
            #key=key.replace(" ","")
            key = f"{key} :"
        else:
            action_final = ""
            key = t
            key = translate_text(key)
        # print(action_final)
        translated.append(key+action_final)
    return translated

def draw_Text(context, font_id, font_size, text, alignH='CENTER', alignV='BOTTOM',padding=10,activeKey=None,start_x=None,start_y=None, translate=True):
    if preferences().flip_sides:
        if alignH == 'LEFT':
            alignH='RIGHT'
        elif alignH == 'RIGHT':
            alignH='LEFT'
    font_size=preferences().font_size
    lcolor=preferences().text_color1
    rcolor=preferences().text_color2
    scolor=preferences().text_color3
    hcolor=preferences().text_color4
    bg_color=preferences().bg_color
    blf.size(font_id, font_size, 72)
    #    center=(context.region.width-blf.dimensions(font_id,text)[0])/2
    if translate:
        text = translate_list(text)
    initY = preferences().loc_y
    n_panel=0
    if not preferences().use_floating_text:
        start_x = None
        start_y = None
    
    text=[a for a in text if a]
    n_panel_alignment=None
    for region in bpy.context.area.regions: 
        if region.type == "UI":
            n_panel_alignment=region.alignment
            n_panel = region.width+preferences().loc_x_from_right#min(region.width,300)
            break
    #n_panel=150 if bpy.context.space_data.show_region_ui else 0

    if alignV != 'BOTTOM':
        initY = context.region.height - (blf.dimensions(font_id, text[0])[1]*(len(text)))-preferences().loc_y_from_top

    center = 0
    max_dim_x=0
    startX=200000
    dim_y=0
    init_y=initY
    ycopy=initY
    if isinstance(text, str):
        text = {text,}
    actions=[]
    keys=[]
    YWidths=[]
    for t in text:
        YWidths.append(blf.dimensions(font_id, t)[1]+5)
        if ':' in t:
            key,action=t.split(':')
            
            key=key.replace(" ","")
            key=f"[{key}] :"
            
        else:
            action=""
            key=t
        keys.append(key)
        actions.append(action)
    maxYWidth=sum(YWidths)
    maxWidthKey=max(keys, key=len)
    maxWidthAction=max(actions, key=len)
    maxKeyWidth=blf.dimensions(font_id, maxWidthKey)[0]
    if start_y and preferences().floating_text_location=='ABOVE':
        start_y=start_y+maxYWidth+100
        start_x=start_x-maxKeyWidth/2
    if alignH == 'LEFT':
            center = preferences().loc_x+(n_panel if n_panel_alignment=='LEFT' else 0)
    elif alignH == 'RIGHT':
        center = min([context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[0]-30-(n_panel if n_panel_alignment=='RIGHT' else 0) for t in text])
    else :
            #pass
            #center=center/2
            center = min([(context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[0])/2  for t in text])
    if start_y:
            initY=start_y-maxYWidth-50
            init_y=start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key,action=t.split(':')
            key=key.rstrip()
            if key and (len(key)<3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'UP' in key or 'DOWN' in key):
                key=f"[{key}]"
            
        else:
            action=""
            key=t
        if blf.dimensions(font_id, t)[0]>max_dim_x:
                max_dim_x=blf.dimensions(font_id, f"{maxWidthKey} {maxWidthAction}")[0]
        if center< startX:
            startX=center
        if start_x:
            center=start_x
            startX=start_x  
        
        initY += max(YWidths)
    if bpy.context.preferences.view.language in {'zh_CN','ja_JP'}:
        max_dim_x*=1.3
    gpu.state.blend_set("ALPHA") 
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)
    
    dim_y=initY-5
    vertices = (
            (startX-padding, init_y-padding), (startX+max_dim_x+padding, init_y-padding),
            (startX-padding, dim_y+(padding*0.9)), (startX+max_dim_x+padding, dim_y+(0.9*padding)))
    roundedRectangle(startX-padding,init_y-padding,max_dim_x+2*padding,dim_y-init_y+2*padding,preferences().border_radius)
    gpu.state.blend_set("NONE") 
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    initY=ycopy
    if start_y:
            initY=start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key,action=t.split(':')
            key=key.rstrip()
            if key and (len(key)<3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'A/S/D' in key  or 'UP' in key or 'DOWN' in key):
                key=f"[{key}]"
            
        else:
            action=""
            key=t
        if center< startX:
            startX=center
        if start_x:
            center=start_x
            startX=start_x  
        blf.position(font_id, center, initY, 0)
        blf.color(font_id,  lcolor[0], lcolor[1],lcolor[2], lcolor[3])
        if activeKey and (("[" in key and f"[{activeKey.replace(' ','')}]" in key.replace(" ",""))):
            blf.color(font_id, hcolor[0],hcolor[1], hcolor[2],hcolor[3])
        if key!='line':
            blf.draw(font_id, key)
        if key and action :
            blf.position(font_id, center +maxKeyWidth, initY, 0)
            blf.color(font_id,  lcolor[0], lcolor[1],lcolor[2], lcolor[3])
            blf.draw(font_id,":")
        blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0], initY, 0)
        if "(" in action:
            action1=action[:action.index("(")]
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action1)
            action2=action[action.index("("):action.index(")")+1]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, scolor[0], scolor[1],scolor[2], scolor[3])
            blf.draw(font_id,action2)
            action3=action[action.index(")")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id,rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id,action3)
        elif "[" in action:
            action1=action[:action.index("[")]
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action1)
            action2=action[action.index("[")+1:action.index("]")]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, scolor[0], scolor[1],scolor[2], scolor[3])
            blf.draw(font_id,action2)
            action3=action[action.index("]")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id,action3)

        else:
            blf.color(font_id, rcolor[0], rcolor[1],rcolor[2], rcolor[3])
            blf.draw(font_id, action)
        initY += max(YWidths)
def roundedRectangle(x, y, width, height,radius,smooth=5):
    gpu.state.blend_set("ALPHA") 
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)
    gpu.state.line_width_set(preferences().border_thickness)
    radius=min([radius,width/2, height/2])
    corners=[(x,y),(x+width,y),(x+width,y+height),(x,y+height)]
    tl_Corner=[]
    for i in range(90,180,smooth):
        
        tl_Corner.append((x+radius + radius*math.cos(math.radians(i)),y+height-radius + radius*math.sin(math.radians(i))))
    tr_Corner=[]
    for i in range(0,90,smooth):
        tr_Corner.append((x+width-radius + radius*math.cos(math.radians(i)),y+height-radius + radius*math.sin(math.radians(i))))
    bl_Corner=[]
    for i in range(180,270,smooth):
        bl_Corner.append((x+radius + radius*math.cos(math.radians(i)),y+radius + radius*math.sin(math.radians(i))))
    br_Corner=[]
    for i in range(270,360,smooth):
        br_Corner.append((x+width-radius + radius*math.cos(math.radians(i)),y+radius + radius*math.sin(math.radians(i))))
    #points=[(x+radius,y+radius),]+bl_Corner+[(x+width-radius,y+radius),]+br_Corner+[(x+width-radius,y+height-radius),]+tr_Corner+[(x+radius,y+height-radius)]+tl_Corner
    points=bl_Corner+br_Corner+tr_Corner+tl_Corner
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": points}, indices=[(0,x+1,x+2) for x in range(len(points)-2)])
    edge_batch=batch_for_shader(shader, 'LINES', {"pos": points}, indices=[(x,(x+1)%len(points)) for x in range(len(points))])
    #print(len(points))
    #print([(x,(x+1)%len(points)) for x in range(len(points))])
    shader.bind()
    shader.uniform_float("color", preferences().bg_color)
    batch.draw(shader)
    shader.uniform_float("color", preferences().bg_border_color)
    edge_batch.draw(shader)
    gpu.state.blend_set("NONE") 
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
def draw_Text3(context, font_id, font_size, text, alignH='CENTER', alignV='BOTTOM', padding=10, activeKey=None, start_x=None, start_y=None, translate=True):
    blf.size(font_id, font_size, 72)
#    center=(context.region.width-blf.dimensions(font_id,text)[0])/2
    initY = 50
    n_panel = 0
    # print(translate_list(text))
    if translate:
        text = translate_list(text)
    if not preferences().use_floating_text:
        start_x = None
        start_y = None
    text = [a for a in text if a]
    n_panel_alignment = None
    for region in bpy.context.area.regions:
        if region.type == "UI":
            n_panel_alignment = region.alignment
            n_panel = region.width  # min(region.width,300)
            break
    #n_panel=150 if bpy.context.space_data.show_region_ui else 0

    if alignV != 'BOTTOM':
        initY = context.region.height - \
            (blf.dimensions(font_id, text[0])[1]*(len(text)))-50

    center = 0
    max_dim_x = 0
    startX = 200000
    dim_y = 0
    init_y = initY
    ycopy = initY
    if isinstance(text, str):
        text = {text}
    actions = []
    keys = []
    YWidths = []
    for t in text:
        YWidths.append(blf.dimensions(font_id, t)[1]+5)
        if ':' in t:
            key, action = t.split(':')
            key = key.replace(" ", "")
            key = f"[{key}] :"

        else:
            action = ""
            key = t
        keys.append(key)
        actions.append(action)
    maxYWidth = sum(YWidths)
    maxWidthKey = max(keys, key=width)
    maxWidthAction = max(actions, key=width)
    maxKeyWidth = blf.dimensions(font_id, maxWidthKey)[0]
    if alignH == 'LEFT':
        center = 50+(n_panel if n_panel_alignment == 'LEFT' else 0)
    elif alignH == 'RIGHT':
        center = min([context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[
                     0]-30-(n_panel if n_panel_alignment == 'RIGHT' else 0) for t in text])
    else:
        center = min([(context.region.width-blf.dimensions(font_id,
                                                           f"{maxWidthAction}{maxWidthKey}")[0])/2 for t in text])
    if start_y:
        initY = start_y-maxYWidth-50
        init_y = start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key, action = t.split(':')
            key = key.rstrip()
            if key and (len(key) < 3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'UP' in key or 'DOWN' in key):
                key = f"[{key}]"

        else:
            action = ""
            key = t
        if blf.dimensions(font_id, t)[0] > max_dim_x:
            # print(maxWidthKey,maxWidthAction)
            max_dim_x = blf.dimensions(
                font_id, f"{maxWidthKey} {maxWidthAction}")[0]
        if center < startX:
            startX = center
        if start_x:
            center = start_x
            startX = start_x

        initY += max(YWidths)
    # print(start_x,max_dim_x,init_y,dim_y)
    gpu.state.blend_set("ALPHA")
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)

    # print(init_y,start_x)

    dim_y = initY-5
    # print(init_y,initY)
    vertices = (
        (startX-padding, init_y-padding), (startX+max_dim_x+padding, init_y-padding),
        (startX-padding, dim_y+(padding*0.9)), (startX+max_dim_x+padding, dim_y+(0.9*padding)))
    indices = (
        (0, 1, 2), (2, 1, 3))
    edge_indices = [(0, 1), (1, 3), (3, 2), (2, 0)]
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(
        shader, 'TRIS', {"pos": vertices}, indices=indices)
    edge_batch = batch_for_shader(
        shader, 'LINES', {"pos": vertices}, indices=edge_indices)

    shader.bind()
    shader.uniform_float("color", (0, 0, 0, 0.6 if not start_x else 0.4))

    batch.draw(shader)
    shader.uniform_float("color", (1, 1, 1, 0.8))
    if not start_x:
        pass
        # edge_batch.draw(shader)
    gpu.state.blend_set("NONE")
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    initY = ycopy
    if start_y:
        initY = start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key, action = t.split(':')
            key = key.rstrip()
            if key and (len(key) < 3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'A/S/D' in key or 'UP' in key or 'DOWN' in key):
                key = f"[{key}]"

        else:
            action = ""
            key = t
        if center < startX:
            startX = center
        if start_x:
            center = start_x
            startX = start_x
        blf.position(font_id, center, initY, 0)
        blf.color(font_id, 0.24, 0.8, 1, 1)
        if activeKey and (("[" in key and f"[{activeKey.replace(' ','')}]" in key.replace(" ", ""))):
            blf.color(font_id, 1, 0.3, 0, 1)
        if key != 'line':
            blf.draw(font_id, key)
        if key and action:
            blf.position(font_id, center + maxKeyWidth, initY, 0)
            blf.color(font_id, 0, 0.7, 1, 1)
            blf.draw(font_id, ":")
        blf.position(font_id, center+maxKeyWidth +
                     blf.dimensions(font_id, ":")[0], initY, 0)

        if "(" in action:
            action1 = action[:action.index("(")]
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action1)
            action2 = action[action.index("("):action.index(")")+1]

            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id,
                                                                    ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, 152/255, 250/255, 140/255, 1)
            blf.draw(font_id, action2)
            action3 = action[action.index(")")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[
                         0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action3)
        elif "[" in action:
            action1 = action[:action.index("[")]
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action1)
            action2 = action[action.index("[")+1:action.index("]")]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id,
                                                                    ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, 152/255, 250/255, 140/255, 1)
            blf.draw(font_id, action2)
            action3 = action[action.index("]")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[
                         0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action3)

        else:
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action)
        initY += max(YWidths)  # blf.dimensions(font_id, t)[1]+5


def draw_Text2(context, font_id, font_size, text, alignH='CENTER', alignV='BOTTOM', padding=10, activeKey=None, start_x=None, start_y=None, translate=True):
    blf.size(font_id, font_size, 72)
#    center=(context.region.width-blf.dimensions(font_id,text)[0])/2
    initY = 50
    n_panel = 0
    # print(translate_list(text))
    text = translate_list(text)
    if not preferences().use_floating_text:
        start_x = None
        start_y = None
    text = [a for a in text if a]
    n_panel_alignment = None
    for region in bpy.context.area.regions:
        if region.type == "UI":
            n_panel_alignment = region.alignment
            n_panel = min(region.width, 300)
            break
    #n_panel=150 if bpy.context.space_data.show_region_ui else 0

    if alignV != 'BOTTOM':
        initY = context.region.height - \
            (blf.dimensions(font_id, text[0])[1]*(len(text)))-50

    center = 0
    max_dim_x = 0
    startX = 200000
    dim_y = 0
    init_y = initY
    ycopy = initY
    if isinstance(text, str):
        text = {text}
    actions = []
    keys = []
    YWidths = []
    for t in text:
        YWidths.append(blf.dimensions(font_id, t)[1]+5)
        if ':' in t:
            key, action = t.split(':')
            if translate:
                key = translate_text(key)
                action = translate_text(action)
                if action and action and action[0] != " ":
                    action = " "+action
            key = key.replace(" ", "")
            key = f"[{key}] :"

        else:
            action = ""
            key = t
            if translate:
                key = translate_text(key)
        keys.append(key)
        actions.append(action)
    maxYWidth = sum(YWidths)
    maxWidthKey = max(keys, key=width)
    maxWidthAction = max(actions, key=width)
    maxKeyWidth = blf.dimensions(font_id, maxWidthKey)[0]
    if alignH == 'LEFT':
        center = 50+(n_panel if n_panel_alignment == 'LEFT' else 0)
    elif alignH == 'RIGHT':
        center = min([context.region.width-blf.dimensions(font_id, f"{maxWidthAction}{maxWidthKey}")[
                     0]-30-(n_panel if n_panel_alignment == 'RIGHT' else 0) for t in text])
    else:
        # pass
        # center=center/2
        center = min([(context.region.width-blf.dimensions(font_id,
                                                           f"{maxWidthAction}{maxWidthKey}")[0])/2 for t in text])
    if start_y:
        initY = start_y-maxYWidth-50
        init_y = start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key, action = t.split(':')
            if translate:
                key = translate_text(key)
                action = translate_text(action)
                if action and action and action[0] != " ":
                    action = " "+action
            key = key.rstrip()
            if key and (len(key) < 3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'UP' in key or 'DOWN' in key):
                key = f"[{key}]"

        else:
            action = ""
            key = t
            if translate:
                key = translate_text(key)
        if blf.dimensions(font_id, t)[0] > max_dim_x:
            # print(maxWidthKey,maxWidthAction)
            max_dim_x = blf.dimensions(
                font_id, f"{maxWidthKey} {maxWidthAction}")[0]
        # if alignH == 'LEFT':
        #    center = 50
        # elif alignH == 'RIGHT':
        #    pass
            #center = context.region.width-blf.dimensions(font_id, t)[0]-30-n_panel

        # else:
        #    pass
            # center=center/2
            #center = (context.region.width-blf.dimensions(font_id, f"{key}:{action}")[0])/2
        if center < startX:
            startX = center
        if start_x:
            center = start_x
            startX = start_x

        initY += max(YWidths)
    # print(start_x,max_dim_x,init_y,dim_y)
    gpu.state.blend_set("ALPHA")
    #bgl.glEnable(bgl.GL_LINE_SMOOTH)

    # print(init_y,start_x)

    dim_y = initY-5
    # print(init_y,initY)
    vertices = (
        (startX-padding, init_y-padding), (startX+max_dim_x+padding, init_y-padding),
        (startX-padding, dim_y+(padding*0.9)), (startX+max_dim_x+padding, dim_y+(0.9*padding)))
    indices = (
        (0, 1, 2), (2, 1, 3))
    edge_indices = [(0, 1), (1, 3), (3, 2), (2, 0)]
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(
        shader, 'TRIS', {"pos": vertices}, indices=indices)
    edge_batch = batch_for_shader(
        shader, 'LINES', {"pos": vertices}, indices=edge_indices)

    shader.bind()
    shader.uniform_float("color", (0, 0, 0, 0.6 if not start_x else 0.4))

    batch.draw(shader)
    shader.uniform_float("color", (1, 1, 1, 0.8))
    if not start_x:
        pass
        # edge_batch.draw(shader)
    gpu.state.blend_set("NONE")
    #bgl.glDisable(bgl.GL_LINE_SMOOTH)
    initY = ycopy
    if start_y:
        initY = start_y-maxYWidth-50
    for t in text:
        if ':' in t:
            key, action = t.split(':')
            # print(key)
            if translate:
                key = translate_text(key)
                action = translate_text(action)
                if action and action and action[0] != " ":
                    action = " "+action
            key = key.rstrip()
            if key and (len(key) < 3 or 'SHIFT' in key or 'CTRL' in key or 'ALT' in key or 'TAB' in key or 'X/Y/Z' in key or 'SPACE' in key or 'A/S/D' in key or 'UP' in key or 'DOWN' in key):
                key = f"[{key}]"

        else:
            action = ""
            key = t
            if translate:
                key = translate_text(key)
        if center < startX:
            startX = center
        if start_x:
            center = start_x
            startX = start_x
        blf.position(font_id, center, initY, 0)
        blf.color(font_id, 0.24, 0.8, 1, 1)
        if activeKey and (("[" in key and f"[{activeKey.replace(' ','')}]" in key.replace(" ", ""))):
            blf.color(font_id, 1, 0.3, 0, 1)
        if key != 'line':
            blf.draw(font_id, key)
        if key and action:
            blf.position(font_id, center + maxKeyWidth, initY, 0)
            blf.color(font_id, 0, 0.7, 1, 1)
            blf.draw(font_id, ":")
        blf.position(font_id, center+maxKeyWidth +
                     blf.dimensions(font_id, ":")[0], initY, 0)
        if "(" in action:
            action1 = action[:action.index("(")]
            # print(action1)
            if translate:
                action1 = translate_text(action1)
                if action1 and action1[0] != " ":
                    action1 = " "+action1

            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action1)
            action2 = action[action.index("("):action.index(")")+1]
            # print(action2)
            if translate:
                action2 = translate_text(action2)
            if action2 and action2[0] != " ":
                action2 = " "+action2

            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id,
                                                                    ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, 152/255, 250/255, 140/255, 1)
            blf.draw(font_id, action2)
            action3 = action[action.index(")")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[
                         0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action3)
        elif "[" in action:
            action1 = action[:action.index("[")]
            if translate:
                action1 = translate_text(action1)
            if action1 and action1[0] != " ":
                action1 = " "+action1
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action1)
            action2 = action[action.index("[")+1:action.index("]")]
            if translate:
                action2 = translate_text(action2)
            if action2 and action2[0] != " ":
                action2 = " "+action2
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id,
                                                                    ":")[0]+blf.dimensions(font_id, action1)[0], initY, 0)
            blf.color(font_id, 152/255, 250/255, 140/255, 1)
            blf.draw(font_id, action2)
            action3 = action[action.index("]")+1:]
            blf.position(font_id, center+maxKeyWidth+blf.dimensions(font_id, ":")[
                         0]+blf.dimensions(font_id, action1)[0]+blf.dimensions(font_id, action2)[0], initY, 0)
            blf.color(font_id, 1, 1, 1, 1)
            blf.draw(font_id, action3)

        else:
            blf.color(font_id, 1, 1, 1, 1)
            # print(action)
            if translate:
                action = translate_text(action)
            if action and action[0] != " ":
                action = " "+action

            blf.draw(font_id, action)
        initY += max(YWidths)  # blf.dimensions(font_id, t)[1]+5


def findNode(nodesField, nodesrch):
    #print(f"Searching: {nodesrch}")
    for node in nodesField.nodes:
        #print(f"FOUND: {node.type}")
        if node.type == nodesrch:
            #print(f"FOUND: {node.type}")
            return node
    return None


def findConstraintAxis(mod):
    if mod is not None:
        if mod.use_axis[0]:
            return "X"
        elif mod.use_axis[1]:
            return "Y"
        elif mod.use_axis[0]:
            return "Z"
        else:
            return "X"


def findMirrorAxis(obj, obj2):
    x = abs(obj.location[0]-obj2.location[0])
    y = abs(obj.location[1]-obj2.location[1])
    z = abs(obj.location[2]-obj2.location[2])
    if (x >= y) and (x >= z):
        axis = (True, False, False)
    elif (y >= x) and (y >= z):
        axis = (False, True, False)
    else:
        axis = (False, False, True)
    return axis


# Append:

abbrivations = {'obj': 'Object', 'col': 'Collection',
                'ng': 'NodeTree', 'mat': 'Material', 'world': 'World'}


def searchObjects(object, unique=False):
    results = []
    with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "uindexes.txt" if unique else "indexes.txt"), encoding='utf-8') as csvFile:
        csv_reader = csv.reader(csvFile, delimiter=',')
        for row in csv_reader:
            # print(row[2].lower())
            if object.lower() in row[1].lower() or object.lower() in row[2].lower():
                type = row[0]
                results.append((type, row[1], row[2]))
        if len(results) > 0:
            return results
    return None


def storeObjectToCsv(path, csvFile):
    with bpy.data.libraries.load(str(path)) as (data_from, _):

        for obj in data_from.objects:
            csvFile.writerow(["obj", obj, path])
        for col in data_from.collections:
            csvFile.writerow(["col", col, path])
        for mat in data_from.materials:
            csvFile.writerow(["mat", mat, path])
        for mat in data_from.node_groups:
            csvFile.writerow(["ng", mat, path])
        for world in data_from.worlds:
            csvFile.writerow(["world", world, path])


def uniqueIndex(csvFile):

    entries = set()
    with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "indexes.txt"), mode='r', newline='', encoding='utf-8') as csvFileRead:
        csvReader = csv.reader(csvFileRead, delimiter=',')
        for row in csvReader:
            key = (row[0], row[1])
            if key not in entries or "collection" in row[1].lower():
                entries.add(key)
                csvFile.writerow(row)


"""def searchAllObjects(paths,object):
    for path in paths:
        searchResults=searchObject(path,object)
        if searchResults is not None:
            for obj in searchResults:
                objs.append(obj)
        return [searchObject(path,object) for path in paths] """


def indexAllObjects(folders):
    blendFiles = []
    # start=time.time()
    for folder in folders:
        if os.path.isdir(folder):
            for root, dirs, files in os.walk(folder):

                for file in files:
                    if file.endswith(".blend"):
                        blendFiles.append(os.path.join(root, file))
    blendFiles.sort(key=lambda x: os.path.getmtime(x))
    blendFiles.reverse()
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "indexes.txt"), mode='w', newline='', encoding='utf-8') as csvFile:
        csvFileWriter = csv.writer(
            csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
        for path in blendFiles:
            storeObjectToCsv(path, csvFileWriter)
    with open(os.path.join(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "RanTools-Indexes/"), "uindexes.txt"), mode='w', newline='', encoding='utf-8') as csvFile:
        csvFileWriter = csv.writer(
            csvFile, delimiter=",", quotechar='"', quoting=csv.QUOTE_MINIMAL)
        uniqueIndex(csvFileWriter)

    # end=time.time()
    #print(f"Time Taken To Index All Blend Files: {end-start}")
"""def searchAllObjects(paths,object,objs):
    for path in paths:
        searchResults=searchObject(path,object)
        if searchResults is not None:
            for obj in searchResults:
                objs.append(obj)    """
# def search(paths,object):
# return asyncio.get_event_loop().run_until_complete(searchAllObjects(paths,object))
"""threadingLevel=2
print("Creating Executor")
executor=ThreadPoolExecutor(max_workers=threadingLevel)    """


def appendAsset(context, object):

    objs = []

    objs = searchObjects(
        object, unique=context.preferences.addons[__package__].preferences.use_unique)
    # end=time.time()
    #print(f"Time Taken To Search: {end-start}")
    if objs is not None:
        if len(objs) == 1 and objs[0][0] != "mat" and objs[0][0] != "world":
            obj = objs[0]
            bpy.ops.wm.append(
                directory=os.path.join(
                    obj[2], abbrivations[obj[0]])+"\\",
                filename=obj[1], autoselect=True
            )
        else:
            objs.reverse()
            for obj in objs:
                if obj is not None:
                    temp = context.scene.rt_props.add()
                    finalPath = os.path.join(
                        obj[2], abbrivations[obj[0]]+'\\')
                    temp.path = finalPath
                    temp.type = os.path.basename(obj[2]).replace(
                        '.blend', '')+" ["+abbrivations[obj[0]]+"] =>"+obj[1]
                    temp.name = obj[1]


def AppendNameUpdated(self, context):
    context.scene.rt_props.clear()
    if getattr(self, 'name') != "":
        bpy.ops.rtools.append_by_name(
            'INVOKE_DEFAULT', name=getattr(self, 'name'))


def updateAssets(self, context):
    if bpy.context.preferences.addons[__package__].preferences.autoIndex:
        bpy.ops.rtools.refresh_indexes('INVOKE_DEFAULT')


def duplicateAndParentToEmpty(selected, name):
    if bpy.context.preferences.addons[__package__].preferences.useBoxEmpty:
        dups = []
        hasParents = []
        parents = []
        transform_pivot_point = bpy.context.scene.tool_settings.transform_pivot_point
        # bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        selectedOg = [s for s in bpy.context.selected_objects]
        selected = [s for s in bpy.context.selected_objects]
        # activeRot=bpy.context.active_object.rotation_euler.copy()
        # print(activeRot)
        activeRot = bpy.context.active_object.rotation_euler.copy() if bpy.context.active_object.type in {
            'MESH', 'CURVE', 'SURFACE'} else bpy.context.selected_objects[len(bpy.context.selected_objects)-1].rotation_euler.copy()
        for obj in selected:
            if obj.parent is not None:
                hasParents.append(obj)
                parents.append(obj.parent)
            if obj.type in {'MESH', 'CURVE', 'SURFACE'} and obj != bpy.context.active_object:
                dups.append(duplicate_object(obj))
        if bpy.context.active_object.type in {'MESH', 'CURVE', 'SURFACE'}:
            dups.append(duplicate_object(
                bpy.context.active_object))

        for p in set(parents):
            selectedOg.append(p)
        selected = Diff(selectedOg, hasParents)
        bpy.ops.object.select_all(action='DESELECT')
        cursorLocBackUp = bpy.context.scene.cursor.location.copy()
        bpy.context.scene.cursor.location = (
            bpy.context.active_object.location)
        toRotate = (activeRot[0]-0, activeRot[1]-0, activeRot[2]-0)
        for ob in dups:
            convert_to_mesh(ob)
        for ob in dups:
            # print(ob)
            # ob.rotation_euler=(ob.rotation_euler[0]-toRotate[0],ob.rotation_euler[1]-toRotate[1],ob.rotation_euler[2]-toRotate[2])
            apply_all_modifiers(ob)
            select(ob, active=True)
        bpy.ops.object.join()
        # bpy.ops.object.transform_apply()
        active = bpy.context.active_object
        active.rotation_euler = (
            active.rotation_euler[0]-toRotate[0], active.rotation_euler[1]-toRotate[1], active.rotation_euler[2]-toRotate[2])
        bpy.ops.object.transforms_to_deltas(mode='LOC')
        bpy.ops.object.transform_apply(
            location=True, rotation=True, scale=False)
        bpy.ops.view3d.snap_cursor_to_active()
        # bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
        # print(active.bound_box)
        #bbverts = [Vector(bbvert)@active.matrix_world for bbvert in active.bound_box]
        bbverts = [active.matrix_world @
                   Vector(corner) for corner in active.bound_box]
        # print(bbox_corners)
        meanX = mean([v[0] for v in bbverts])
        meanY = mean([v[1] for v in bbverts])
        meanZ = mean([v[2] for v in bbverts])
        col = get_collection(name)
        move_objects_to_collection(selectedOg, col)
        bpy.ops.object.empty_add(type='CUBE', align='WORLD', location=(
            meanX, meanY, meanZ))
        empty = bpy.context.active_object
        empty.scale = (
            active.dimensions[0]/2, active.dimensions[1]/2, active.dimensions[2]/2)
        empty.name = name
        move_to_collection(empty, name)
        # empty.rotation_euler=activeRot
        bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
        override = get_override('VIEW_3D', 'WINDOW')
        bpy.ops.transform.rotate(override, value=-toRotate[0], orient_axis='X')
        bpy.ops.transform.rotate(override, value=-toRotate[1], orient_axis='Y')
        bpy.ops.transform.rotate(override, value=-toRotate[2], orient_axis='Z')

        delete_object(active)
        for s in selected:
            select(s, active=True)
        select(empty, active=True)
        bpy.ops.object.parent_set()
        bpy.ops.object.light_add(type='SUN', align='WORLD', location=(
            meanX, meanY, meanZ))

        empty2 = bpy.context.active_object
        for ob in selectedOg:
            select(ob)
        select(empty, active=True)
        bpy.context.scene.cursor.location = cursorLocBackUp
        bpy.context.scene.tool_settings.transform_pivot_point = transform_pivot_point
    else:
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        active = bpy.context.active_object
        meanX = mean([x.location[0] for x in selected])
        meanY = mean([x.location[1] for x in selected])
        meanZ = mean([x.location[2] for x in selected])
        meanX2 = mean([(active.matrix_world @ v.co).x for v in active.data.vertices]
                      ) if active.type == "MESH" else active.location[0]
        meanY2 = mean([(active.matrix_world @ v.co).y for v in active.data.vertices]
                      ) if active.type == "MESH" else active.location[1]
        #meanZ=mean([(active.matrix_world @ v.co).z for v in active.data.vertices]) if active.type=="MESH" else active.location[2]
        lowpoints = []

        maxScale = 0
        for obj in selected:

            if max(obj.dimensions.x, obj.dimensions.y) > maxScale:
                maxScale = max(obj.dimensions.x, obj.dimensions.y)
            if obj.type in {'MESH'}:
                # lowpoints.append(
                #    min([(obj.matrix_world @ v.co).z for v in obj.data.vertices]))
                lowpoints.append(
                    min([(obj.matrix_world @ Vector(corner))[2] for corner in obj.bound_box]))

        lowest_pt = min(lowpoints) if len(lowpoints) > 0 else 0
        col = get_collection(name)
        move_objects_to_collection(bpy.context.selected_objects, col)
        # if len(selected) == 1:
        emptyScale = min(maxScale/4, 2)
        bpy.ops.object.empty_add(
            type='PLAIN_AXES', align='WORLD', location=(meanX2, meanY2, lowest_pt))
        # else:
        #    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD',location=(active.location[0],active.location[1],lowest_pt) ,scale=(10, 10, 10))
        empty = bpy.context.active_object
        empty.empty_display_size = emptyScale
        empty.name = name
        move_to_collection(empty, name)
        for ob in selected:
            select(ob)
        # select_all_objects(name)
        select(empty, active=True)
        bpy.ops.object.parent_set()
        #bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD',location=(meanX,meanY,meanZ) ,scale=(10, 10, 10))
        bpy.ops.object.light_add(type='SUN', align='WORLD', location=(
            meanX, meanY, meanZ), scale=(0.1, 0.1, 0.1))

        empty2 = bpy.context.active_object
        empty2.rotation_euler = (0.1, 0.1, 0.1)
        for ob in selected:
            select(ob)
        select(empty, active=True)
        # if len(selected) != 1:
    #    select(active,active=True)
        # set_active_collection(name)

    return (empty, empty2)


def AssetNameUpdated(self, context):

    nameAsset = getattr(self, "name")
    bpy.ops.rtools.createassets('INVOKE_DEFAULT', name=nameAsset)


def captureThumbnail(context, trackTo=None, useEevee=False):
    hidden = []
    Lights = []
    if trackTo is None:
        trackTo = bpy.context.active_object
    if not useEevee:
        # bpy.ops.view3d.localview(frame_selected=True)
        focalLength = bpy.context.space_data.lens
        if len(bpy.context.selected_objects) > 3:
            bpy.context.space_data.lens = 50
        else:
            bpy.context.space_data.lens = 50
        for obj in bpy.context.selected_objects:
            if obj.type == 'LIGHT':
                Lights.append((obj, obj.scale.copy()))
                obj.scale = (0.01, 0.01, 0.01)
        bpy.ops.view3d.view_selected(use_all_regions=False)
        # bpy.ops.view3d.zoom(delta=5000)
        for obj in Lights:
            obj[0].scale = obj[1]
        bpy.context.space_data.lens = 100

        shading = bpy.context.space_data.shading.type
        bpy.context.space_data.shading.type = 'MATERIAL'
        overlays = bpy.context.space_data.overlay.show_overlays

        bpy.context.space_data.overlay.show_overlays = False

        rendexXbackUp = bpy.context.scene.render.resolution_x
        rendexYbackUp = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_x = 256
        bpy.context.scene.render.resolution_y = 256

        unselected = Diff(bpy.data.objects,
                          bpy.context.selected_objects.copy())
        for obj in unselected:
            if obj.type != "LIGHT" and obj.hide_get() == False:
                obj.hide_set(True)
                hidden.append(obj)

        #print(max(x for x in bpy.context.active_object.dimensions))
        #camera_object.location=[max(x for x in bpy.context.active_object.dimensions)*2,max(x for x in bpy.context.active_object.dimensions)*2,max(x for x in bpy.context.active_object.dimensions)]

        bpy.ops.render.opengl(write_still=True)
        for obj in hidden:
            obj.hide_set(False)
        bpy.context.space_data.overlay.show_overlays = overlays
        bpy.context.space_data.lens = focalLength
        bpy.context.scene.render.resolution_x = rendexXbackUp
        bpy.context.scene.render.resolution_y = rendexYbackUp
        bpy.context.space_data.shading.type = shading
    else:
        engine = bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        enable_abs(context)
        # bpy.ops.view3d.view_selected(use_all_regions=False)

        rendexXbackUp = bpy.context.scene.render.resolution_x
        rendexYbackUp = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_x = 256
        bpy.context.scene.render.resolution_y = 256

        unselected = Diff(bpy.data.objects,
                          bpy.context.selected_objects.copy())
        for obj in unselected:
            if obj.type != "LIGHT" and obj.hide_render == False:
                obj.hide_render = True
                hidden.append(obj)
        cameraBackUp = context.scene.camera
        camera_data = bpy.data.cameras.new(name='Camera')
        camera_object = bpy.data.objects.new('Camera', camera_data)
        bpy.context.scene.collection.objects.link(camera_object)

        context.scene.camera = camera_object
        camera_data.lens = 80
        #constraint = camera_object.constraints.new('TRACK_TO')
        # constraint.target=trackTo
        # camera_data.type='ORTHO'
        # camera_data.ortho_scale=3
        context.scene.camera.matrix_world = context.space_data.region_3d.view_matrix
        context.scene.camera.matrix_world.invert()
        for obj in bpy.context.selected_objects:
            if obj.type == 'LIGHT':
                Lights.append((obj, obj.scale))
                obj.scale = (0.01, 0.01, 0.01)
        bpy.ops.view3d.camera_to_view_selected()
        for obj in Lights:
            obj[0].scale = obj[1]

        camera_data.lens = 70
        #print(max(x for x in bpy.context.active_object.dimensions))
        #camera_object.location=[max(x for x in bpy.context.active_object.dimensions)*2,max(x for x in bpy.context.active_object.dimensions)*2,max(x for x in bpy.context.active_object.dimensions)]

        bpy.ops.render.render(write_still=True)
        bpy.context.scene.render.engine = engine
        for obj in hidden:
            obj.hide_render = False

        delete_object(camera_object)
        context.scene.camera = cameraBackUp
        bpy.context.scene.render.resolution_x = rendexXbackUp
        bpy.context.scene.render.resolution_y = rendexYbackUp


def makeEmissive(context):
    colorInput = None
    a = None
    me = bpy.context.active_object.data
    mat = bpy.context.active_object.active_material.copy()
    mat.name = f"Emissive_{bpy.context.active_object.active_material.name}"
    nodes = mat.node_tree.nodes
    node_output = nodes.get("Material Output")
    node_emission = nodes.new(type='ShaderNodeEmission')
    links = mat.node_tree.links

    for link in links:
        #print(f"{link.from_node} => {link.to_node}")
        if link.to_node.bl_idname == "ShaderNodeOutputMaterial":
            if int(link.to_socket.path_from_id()[-2:-1]) == 0:
                lastNode = link.from_node
                # print(lastNode)
                break
    # print(lastNode)
    # print(lastNode.inputs[0].default_value)
    # print("Hi")
    if lastNode.bl_idname in {'ShaderNodeEmission', 'ShaderNodeBsdfPrincipled', 'ShaderNodeBsdfDiffuse', 'ShaderNodeBsdfGlass', 'ShaderNodeBsdfGlossy', 'ShaderNodeBsdfRefraction', 'ShaderNodeBsdfTranslucent', 'ShaderNodeBsdfTransparent', 'ShaderNodeSubsurfaceScattering', 'ShaderNodeEeveeSpecular'}:
        node_emission.inputs[0].default_value = lastNode.inputs[0].default_value
        node_emission.inputs[1].default_value = 2
        for link in links:

            if link.to_node == lastNode:
                t = int(link.to_socket.path_from_id()[link.to_socket.path_from_id().index(
                    "inputs[")+7:][:link.to_socket.path_from_id()[link.to_socket.path_from_id().index("inputs[")+7:].index("]")])
                if t == 0:
                    colorInput = link.from_node
                    # print(colorInput)
                    a = int(link.from_socket.path_from_id()[-2:-1])
                    break
        link = links.new(colorInput.outputs[a], node_emission.inputs[0]
                         ) if colorInput is not None and a is not None else None
        link = links.new(node_emission.outputs[0], node_output.inputs[0])
        return (mat, node_emission)
def ensure_library(name,path):
    if not os.path.isdir(path):
        try:
            os.mkdir(path)
        except:
            pass
    if os.path.isdir(path):
        lib_path=[a for a in bpy.context.preferences.filepaths.asset_libraries if a.name==name]
        if not lib_path:
            init_libs=bpy.context.preferences.filepaths.asset_libraries[:]
            bpy.ops.preferences.asset_library_add(directory='')
            new_lib=[a for a in bpy.context.preferences.filepaths.asset_libraries[:] if a not in init_libs]
            if new_lib:
                new_lib=new_lib[0]
                new_lib.name=name
                new_lib.path=path
                return new_lib.path
            else:
                None
        else:
            lib_path[0].path=path
            return lib_path[0].path
    else:
        return None
def modifierPanelExtension(self, context):
    if preferences().draw_into_modifier_panel:
        layout = self.layout
        row = layout.row()
        column = row.column()
        column.separator()
        column.menu("RTOOLS_MT_Mods_Stacks_Menu", text="Stack Presets")
        column.separator()
        row = column.row()
        row = row.split(factor=0.6)
        rt_tools = context.scene.rt_tools
        if len(context.active_object.modifiers) > 0:
            row.prop(rt_tools, "presetName", text="", text_ctxt="")
            button = row.operator(
                "rtools.create_modifier_preset", text="Create Preset"
            )
            button.name = "FullStack"
            button.newName = rt_tools.presetName
# @persistent


def unique(sequence):
    seen = set()
    return [x for x in sequence if not (x in seen or seen.add(x))]


def updateModPresets(scene):
    bpy.context.scene.modMenuInfo.clear()

    try:
        with open(
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))
                                ), "RanTools-Indexes/ModPresets.txt"
            ),
            mode="r",
        ) as json_file:

            data = json.load(json_file)
            for p in data:
                item = bpy.context.scene.modMenuInfo.add()
                item.name = p[0]
                item.isStack = "isStack" in p[1]
                item.type = p[1]["ModType"] if not item.isStack else ""

    except:
        print("Error")
    if scene != False:
        bpy.app.handlers.depsgraph_update_post.remove(updateModPresets)


def apply_all_modifiers(obj, exctype=None, exc=None, onlyVisible=False):

    # select(objref)
    exc = exc.name if exc is not None else ""
    exctype = exctype if exctype is not None else ""
    for mod in obj.modifiers:

        #print(f"Mod=>{mod.name} EXC=>{exc}")
        if mod.type != exctype and mod.name != exc and (not onlyVisible or mod.show_viewport):
            #print(f"Applying=> {mod.name}")
            try:
                bpy.ops.object.modifier_apply(
                    {'object': obj}, modifier=mod.name)
            except RuntimeError as ex:
                bpy.ops.object.modifier_remove(
                    {'object': obj}, modifier=mod.name)


def get_override(area_type, region_type):
    for area in bpy.context.screen.areas:
        if area.type == area_type:
            for region in area.regions:
                if region.type == region_type:
                    override = {'area': area, 'region': region}
                    return override
    # error message if the area or region wasn't found
    raise RuntimeError("Wasn't able to find", region_type, " in area ", area_type,
                       "\n Make sure it's open while executing script.")


def GroupIt(context, active_name=None):
    if not active_name:
        active_name = context.active_object.name
    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
    dups = []
    hasParents = []
    parents = []
    transform_pivot_point = bpy.context.scene.tool_settings.transform_pivot_point
    cursorLocBackUp = context.scene.cursor.location.copy()

    selected = [s for s in bpy.context.selected_objects]
    activeRot = bpy.context.active_object.rotation_euler.copy() if bpy.context.active_object.type in {
        'MESH', 'CURVE', 'SURFACE'} else bpy.context.selected_objects[len(bpy.context.selected_objects)-1].rotation_euler.copy()
    for obj in selected:
        if obj.parent is not None:
            hasParents.append(obj)
            parents.append(obj.parent)
        if obj.type in {'MESH', 'CURVE', 'SURFACE'} and obj != bpy.context.active_object:
            dups.append(duplicate_object(obj))
    if bpy.context.active_object.type in {'MESH', 'CURVE', 'SURFACE'}:
        dups.append(duplicate_object(
            bpy.context.active_object))
    for p in set(parents):
        selected.append(p)
    selected = Diff(selected, hasParents)
    bpy.ops.object.select_all(action='DESELECT')
    toRotate = (activeRot[0]-0, activeRot[1]-0, activeRot[2]-0)
    for ob in dups:
        convert_to_mesh(ob)
    for ob in dups:
        apply_all_modifiers(ob)
        select(ob, active=True)
    bpy.ops.object.join()

    active = bpy.context.active_object
    active.rotation_euler = (
        active.rotation_euler[0]-toRotate[0], active.rotation_euler[1]-toRotate[1], active.rotation_euler[2]-toRotate[2])
    bpy.ops.object.transforms_to_deltas(mode='LOC')
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=False)
    bpy.ops.view3d.snap_cursor_to_active()

    #context.scene.cursor.location = (bpy.context.active_object.location)
    # bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
    bbverts = [active.matrix_world @
               Vector(corner) for corner in active.bound_box]
    meanX = mean([v[0] for v in bbverts])
    meanY = mean([v[1] for v in bbverts])
    meanZ = mean([v[2] for v in bbverts])
    bpy.ops.object.empty_add(type='CUBE', align='WORLD', location=(
        meanX, meanY, meanZ))
    empty = bpy.context.active_object
    empty.name = active_name
    empty.scale = (
        active.dimensions[0]/2+0.005, active.dimensions[1]/2+0.005, active.dimensions[2]/2+0.005)
    # empty.rotation_euler=activeRot
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
    override = get_override('VIEW_3D', 'WINDOW')
    bpy.ops.transform.rotate(override, value=-toRotate[0], orient_axis='X')
    bpy.ops.transform.rotate(override, value=-toRotate[1], orient_axis='Y')
    bpy.ops.transform.rotate(override, value=-toRotate[2], orient_axis='Z')
    delete_object_with_data(active)
    for s in selected:
        select(s, active=True)
    select(empty, active=True)
    context.scene.cursor.location = cursorLocBackUp
    bpy.context.scene.tool_settings.transform_pivot_point = transform_pivot_point
    bpy.ops.object.parent_set()


def CreateNodeGroup(name, nodesList, linksList, defaultList, locationList, outputsList, inputsList, attrList, isBevel=False):
    group = bpy.data.node_groups.new(name, 'ShaderNodeTree')
    output = group.nodes.new(type='NodeGroupOutput')
    output.location = 600, 600
    if isBevel:
        for inp in inputsList:
            group.inputs.new(inp[0][0], inp[0][1])
    input = group.nodes.new(type='NodeGroupInput')
    input.location = -800, 600
    group.outputs.new('NodeSocketShader', 'out_result')

    nodes = group.nodes
    links = group.links
    a = {}
    b = None
    for name, node in nodesList.items():
        t = nodes.new(type=node)
        t.name = name
        """for l in linksList:
            if l[0][0]==name:
                l[0][0]=t.name
            if l[1][0]==name:
                l[1][0]=t.name
        for l in locationList:
            if l[0]==name:
                l[0]=t.name
        for l in outputsList:
            if l[0]==name:
                l[0]=t.name
        for l in defaultList:
            if l[0]==name:
                l[0]=t.name
        for l in attrList:
            if l[0]==name:
                l[0]=t.name"""
    for attr in attrList:
        for a in attr[1]:
            setattr(nodes.get(attr[0]), a[0], a[1])
    for default in defaultList:
        for i in default[1]:
            if not "RGB" in default[0]:
                nodes.get(default[0]).inputs[i[0]].default_value = i[1]
            else:
                nodes.get(default[0]).outputs[i[0]].default_value = i[1]
    for link in linksList:

        l = links.new(nodes.get(link[0][0]).outputs[link[0][1]], nodes.get(
            link[1][0]).inputs[link[1][1]])
        # print(l.from_node,l.from_socket,l.to_node,l.to_socket)
    for loc in locationList:
        nodes.get(loc[0]).location.x = loc[1][0]
        nodes.get(loc[0]).location.y = loc[1][1]

    if isBevel:
        group.links.new(input.outputs['Normal'], output.inputs[0])
        for i, out in enumerate(outputsList):
            group.links.new(
                nodes.get(out[0]).outputs[out[1]], output.inputs[i+1])
    else:
        for i, out in enumerate(outputsList):
            group.links.new(
                nodes.get(out[0]).outputs[out[1]], output.inputs[i])
    for j, inp in enumerate(inputsList):
        for i in inp[1]:
            # print(i)
            if isBevel:
                group.links.new(
                    input.outputs[inp[0][1]], nodes.get(i[0]).inputs[i[1]])
            else:
                group.links.new(input.outputs[j], nodes.get(i[0]).inputs[i[1]])


def getSocketIndex(socket):
    if "inputs" in socket.path_from_id():
        return int(socket.path_from_id()[socket.path_from_id().index("inputs[")+7:][:socket.path_from_id()[socket.path_from_id().index("inputs[")+7:].index("]")])
    else:
        return int(socket.path_from_id()[socket.path_from_id().index("outputs[")+8:][:socket.path_from_id()[socket.path_from_id().index("outputs[")+8:].index("]")])


def sort_modifiers(object,mirror=True):
    length = len(object.modifiers)
    if mirror:
        mod = None
        for m in object.modifiers:
            if m.type == 'MIRROR':
                mod = m
        if mod is not None:
            override = bpy.context.copy()
            override['active_object'] = object
            override['object'] = object
            bpy.ops.object.modifier_move_to_index(
                override, modifier=mod.name, index=length-1)
    mod = None
    for m in object.modifiers:
        if m.type == 'BEVEL' and m.width < preferences().bevel_threshold and m.profile < 0.95:
            mod = m
    if mod is not None:
        override = bpy.context.copy()
        override['active_object'] = object
        override['object'] = object
        bpy.ops.object.modifier_move_to_index(
            override, modifier=mod.name, index=length-1)

    mod = None
    for m in object.modifiers:
        if m.type == 'WEIGHTED_NORMAL':
            mod = m
    if mod is not None:
        override = bpy.context.copy()
        override['active_object'] = object
        override['object'] = object
        bpy.ops.object.modifier_move_to_index(
            override, modifier=mod.name, index=length-1)


def preferences():
    return bpy.context.preferences.addons[__package__].preferences


def find_intersections(vertices, indices):

    a = combinations(indices, 2)
    intersections = set([])
    for i in a:
        intersect = geometry.intersect_line_line(
            vertices[i[0][0]], vertices[i[0][1]], vertices[i[1][0]], vertices[i[1][1]])
        if intersect:
            intersections.add(intersect[0].freeze())
    return list(intersections)


def find_current_line_intersections(vertices, indices, v1, v2, polycoords=[], threshold=0.1):
    threshold = preferences().crossSnapThreshold
    v = None
    # intersections=set([])
    for e in indices:
        intersect = geometry.intersect_line_line(
            vertices[e[0]], vertices[e[1]], v1, v2)

        if intersect:
            if (intersect[0]-v2).length < threshold:
                v = intersect[0]
                threshold = (intersect[0]-v2).length
            # intersections.add(intersect[0].freeze())
    if len(polycoords) > 1:
        for i, p in enumerate(polycoords):
            intersect = geometry.intersect_line_line(
                polycoords[i], polycoords[(i+1) % (len(polycoords)-1)], v1, v2)

            if intersect:
                if (intersect[0]-v2).length < threshold:
                    v = intersect[0]
                    threshold = (intersect[0]-v2).length
    return v


def equation_plane(v1, v2, v3):
    a1 = v2.x - v1.x
    b1 = v2.y - v1.y
    c1 = v2.z - v1.z
    a2 = v3.x - v1.x
    b2 = v3.y - v1.y
    c2 = v3.z - v1.z
    a = b1 * c2 - b2 * c1
    b = a2 * c1 - a1 * c2
    c = a1 * b2 - b1 * a2
    d = (- a * v1.x - b * v1.y - c * v1.z)
    return a, b, c, d


def coplanar_faces2(bm, face):
    normal_difference_threshold = 0.1
    linked_faces = set([])
    used_edges = []
    edges = set([e for e in face.edges])
    while len(Diff(used_edges, edges)) > 0:
        for edge in Diff(used_edges, edges):
            used_edges.append(edge)
            linked = edge.link_faces
            for f in linked:
                if f.normal.length > 0 and f.normal.angle(face.normal) < normal_difference_threshold:
                    edges.update([e for e in f.edges])
                    linked_faces.add(f)
    bm.faces.ensure_lookup_table()
    if len(linked_faces) > 0:
        faces = [f for f in linked_faces if f.normal.length >
                 0 and f.normal.angle(face.normal) < normal_difference_threshold]
    else:
        faces = [f for f in bm.faces if f.normal.length > 0 and f.normal.angle(
            face.normal) < normal_difference_threshold]
    # print(faces)
    cp_verts = []
    verts = []
    a, b, c, d = equation_plane(
        face.verts[0].co, face.verts[1].co, face.verts[2].co)
    for f in faces:
        # if all([a * v.co.x + b * v.co.y + c * v.co.z + d == 0 for v in f.verts]):

        #    cp_faces.append(f)

        # if f.index != face.index:
        verts.extend(v for v in f.verts)

    cp_verts.extend([v for v in set(verts) if abs(
        a * v.co.x + b * v.co.y + c * v.co.z + d) <= 0.001])

    # print(cp_verts)
    # print(time.time()-start_time)
    #print([v.co for v in cp_verts])
    return cp_verts, []


def coplanar_faces(bm, face, normal_difference_threshold=0.001,planar_threshold=0.003):
    start_time=time.time()

    linked_faces = set([])
    used_edges = []
    edges = set([e for e in face.edges])
    while len(Diff(used_edges, edges)) > 0:
        for edge in Diff(used_edges, edges):
            used_edges.append(edge)
            linked = edge.link_faces
            for f in linked:
                if f.normal.length > 0 and f.normal.angle(face.normal) < normal_difference_threshold:
                    edges.update([e for e in f.edges])
                    linked_faces.add(f)
    bm.faces.ensure_lookup_table()
    if len(linked_faces) > 0:
        faces = [f for f in linked_faces if f.normal.length >
                 0 and f.normal.angle(face.normal) < normal_difference_threshold]
    else:
        faces = [f for f in bm.faces if f.normal.length > 0 and f.normal.angle(
            face.normal) < normal_difference_threshold]
    # print(faces)
    cp_verts = set([])
    cp_faces = set([])
    verts = []
    a, b, c, d = equation_plane(
        face.verts[0].co, face.verts[1].co, face.verts[2].co)
    for f in faces:
        if any([math.isclose(a * v.co.x + b * v.co.y + c * v.co.z + d, 0, abs_tol=planar_threshold) for v in f.verts]):
            # v=f.verts[0]
            # if a * v.co.x + b * v.co.y + c * v.co.z + d == 0 :
            cp_faces.add(f)
            cp_verts.update([v for v in f.verts])

        # if f.index != face.index:
            #verts.extend(v for v in f.verts)

    #cp_verts.extend([v for v in set(verts) if abs(a * v.co.x + b * v.co.y + c * v.co.z + d) <= 0.001])
    # print(list(cp_faces))
    # print(cp_verts)
    print(time.time()-start_time)
    #print([v.co for v in cp_verts])
    return list(cp_verts), list(cp_faces)


def duplicate_linked(obj):
    new_obj = bpy.data.objects.new(obj.name, obj.data)
    bpy.context.collection.objects.link(new_obj)
    return new_obj


def createvert(context):
    mesh_data = bpy.data.meshes.new("Vertex")
    mesh_data.from_pydata([(0, 0, 0)], [], [])
    mesh_data.validate()
    mesh_obj = bpy.data.objects.new("Vertex", mesh_data)
    bpy.context.collection.objects.link(mesh_obj)
    mesh_obj.location = context.scene.cursor.location
    return mesh_obj


def deselect_all():
    if bpy.context.mode == 'OBJECT':
        bpy.ops.object.select_all(action='DESELECT')
    elif 'EDIT' in bpy.context.mode:
        bpy.ops.mesh.select_all(action='DESELECT')


def select_all(context=None):
    if not context:
        if bpy.context.mode == 'OBJECT':
            bpy.ops.object.select_all(action='SELECT')
        elif 'EDIT' in bpy.context.mode:
            bpy.ops.mesh.select_all(action='SELECT')
    else:
        bpy.ops.object.select_all(context, action='SELECT')


def smart_apply_modifiers(obj, mod_list=[], mirror=False):
    index = None
    count = len(obj.modifiers[:])
    if len(mod_list) < 1:
        if not mirror:
            for i, m in enumerate(obj.modifiers[:]):
                if m.type == 'BEVEL' and m.affect == 'EDGES':  # and m.segments>1
                    index = i
        else:
            for i, m in enumerate(obj.modifiers[:]):
                if m.type == 'MIRROR' and any(m.use_axis):
                    index = i
        modifiers = [m.name for m in obj.modifiers if m.name !=
                     'RT_Slice_Bool_Solidify']
    else:
        if not mirror:
            for i, m in enumerate([m for m in obj.modifiers if m.name in mod_list]):
                if m.type == 'BEVEL' and m.affect == 'EDGES':  # and m.segments>1
                    index = i
        else:
            for i, m in enumerate([m for m in obj.modifiers if m.name in mod_list]):
                if m.type == 'MIRROR' and any(m.use_axis):
                    index = i
        #print([f"{a}" for a in mod_list])
        modifiers = [m for m in mod_list if m in [
            a.name for a in obj.modifiers]]
    # print(index)

    if index is not None:
        for m in range(0, index):
            try:
                if obj.modifiers[modifiers[m]].show_viewport:
                    bpy.ops.object.modifier_apply(
                        {'object': obj}, modifier=modifiers[m])
                else:
                    obj.modifiers.remove(obj.modifiers[modifiers[m]])
            except:
                obj.modifiers.remove(obj.modifiers[modifiers[m]])
                pass
    else:
        for m in range(0, len(modifiers)):
            try:
                if obj.modifiers[modifiers[m]].show_viewport:
                    bpy.ops.object.modifier_apply(
                        {'object': obj}, modifier=modifiers[m])
                else:
                    obj.modifiers.remove(obj.modifiers[modifiers[m]])
                # print(modifiers[m])
            except:
                obj.modifiers.remove(obj.modifiers[modifiers[m]])
                pass


def raycast(origin, direction, plane_point, normal):
    return geometry.intersect_line_plane(origin, origin+direction, plane_point, normal)


def create_object(name, polycoords, rotation, only_edges=False, cyclic=True, dissolve=True, limited_dissolve=False):
    # print(math.degrees(rotation[0]),math.degrees(rotation[1]),math.degrees(rotation[2]))
    mesh_name = name
    polycoords = polycoords

    mesh_data = bpy.data.meshes.new(mesh_name)
    # polyIndices.append((len(polycoords)-1,0))
    if only_edges:
        if not cyclic:
            polyIndices = [(i, (i+1)) for i in range(0, len(polycoords)-1)]
        else:
            polyIndices = [(i, (i+1) % (len(polycoords)))
                           for i in range(0, len(polycoords))]
        mesh_data.from_pydata(polycoords, polyIndices, [])
    else:
        polyIndices = [(i, (i+1) % (len(polycoords)))
                       for i in range(0, len(polycoords))]
        mesh_data.from_pydata(polycoords, polyIndices, [
                              [i for i in range(0, len(polycoords))]])
    mesh_data.validate()
    bm = bmesh.new()
    bm.from_mesh(mesh_data)
    if limited_dissolve:
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.01)
        bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(
            1), verts=bm.verts, edges=bm.edges)
    if not only_edges:
        try:
            bm.faces.ensure_lookup_table()
            bm.faces[0].normal_update()
            bm.faces[0].smooth = True
        except:
            pass

    bm.to_mesh(mesh_data)
    # bmesh.utils.face_flip(bm.faces[0])
    bm.free()

    mesh_obj = bpy.data.objects.new(mesh_name, mesh_data)
    bpy.context.collection.objects.link(mesh_obj)
    bpy.ops.object.select_all(action='DESELECT')
    select(mesh_obj)
    mesh_obj.data.use_auto_smooth = True
    mesh_obj.rotation_mode = 'ZYX'
    mesh_obj.rotation_euler[0], mesh_obj.rotation_euler[1], mesh_obj.rotation_euler[2] = - \
        rotation[0], -rotation[1], -rotation[2]
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

    mesh_obj.rotation_mode = 'XYZ'
    mesh_obj.rotation_euler = rotation
    bpy.ops.object.shade_smooth()

    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    return mesh_obj


def find_circle_coords(center, radius, segments, normal, z_rotation=0):
    #startTime = time.time()
    # radius=1
    bm = bmesh.new()
    bmesh.ops.create_circle(
        bm, cap_ends=False, radius=radius, segments=segments)

    mesh_data = bpy.data.meshes.new("Circle")
    bm.to_mesh(mesh_data)
    mesh_obj = bpy.data.objects.new("Circle", mesh_data)
    z = Vector((0, 0, 1))
    if normal != Vector((0, 0, 0)):
        rot = z.rotation_difference(normal).to_euler()
        mesh_obj.rotation_euler = rot
    bm.free()
    bpy.context.collection.objects.link(mesh_obj)
    mesh_obj.location = center
    mesh_obj.rotation_euler = (mesh_obj.rotation_euler.to_matrix(
    ) @ Matrix.Rotation(z_rotation+0.785398, 3, 'Z')).to_euler()
    mesh_obj_evaluated = mesh_obj.evaluated_get(
        bpy.context.evaluated_depsgraph_get())
    coords = [mesh_obj_evaluated.matrix_world @
              v.co for v in mesh_obj_evaluated.data.vertices]
    delete_object(mesh_obj)
    bpy.data.meshes.remove(mesh_data)
    #print("Circle Found In : ",time.time() -startTime)
    #print([(c.x,c.y) for c in coords])
    return coords


def find_polygon_triangles(coords):
    #startTime = time.time()
    mesh_name = "TempPolygon"
    polycoords = coords

    mesh_data = bpy.data.meshes.new(mesh_name)
    # polyIndices.append((len(polycoords)-1,0))
    polyIndices = [(i, (i+1) % (len(polycoords)))
                   for i in range(0, len(polycoords))]
    mesh_data.from_pydata(polycoords, polyIndices, [
                          [i for i in range(0, len(polycoords))]])
    mesh_data.validate()
    mesh_data.calc_loop_triangles()

    triangles = mesh_data.loop_triangles
    triangles = [a.vertices for a in triangles]
    tris = []
    for a in triangles:
        tris.append([b for b in a])
    bpy.data.meshes.remove(mesh_data)
    return tris


def findrectanglecoords(startPoint, endPoint, grid, center=False):
    # startTime=time.time()

    grid_corners = [grid.matrix_world@v.co for v in grid.data.vertices]
    v1, v2, v3, v4 = grid_corners
    B1 = v2-v1
    B1 = B1.normalized()
    B2 = v4-v2
    B2 = B2.normalized()
    A1 = startPoint
    A2 = endPoint
    diagonal_length = (A2-A1).length
   # print(v2,v1,B1)
    if center:
        A1 = A2+diagonal_length*2*(A1-A2).normalized()
        # print(A1)
    # if (B1.z*B2.y-B2.z*B1.y)!=0:

    #    t=(B1.y*A2.z - B1.y*A1.z -B1.z*A2.y+B1.z*A1.y)/(B1.z*B2.y-B2.z*B1.y)
    # else:
     #   if (B1.z*B2.x-B2.z*B1.x)!=0:
    #        t=(B1.x*A2.z - B1.x*A1.z -B1.z*A2.x+B1.z*A1.x)/(B1.z*B2.x-B2.z*B1.x)
    #    else:
    #        t=(B1.y*A2.x - B1.y*A1.x -B1.x*A2.y+B1.x*A1.y)/(B1.x*B2.y-B2.x*B1.y)
    # A3=A2+t*B2
    # A4=A1-t*B2
    A3 = geometry.intersect_line_line(A1, A1+B1, A2, A2+B2)[0]
    A4 = geometry.intersect_line_line(A1, A1+B2, A2, A2+B1)[0]
    # print(time.time()-startTime)
    return [A1, A3, A2, A4]


def add_driver(target_properties, target_modifier, source_modifier, source_object):
    # print(target_modifier.name)
    for target_property in target_properties:
        # print(target_property)
        if "[" in target_property:
            index = regex.search(r"\[(.*)\]", target_property)
            if index:
                index = index[1]
                tp = target_property[:target_property.rindex("[")]
                driver = target_modifier.driver_add(tp, eval(index))
        else:
            tp = target_property
            driver = target_modifier.driver_add(target_property)
        var = driver.driver.variables.new()
        var.name = tp
        var.targets[0].data_path = f'modifiers["{source_modifier.name}"].{target_property}'
        var.targets[0].id_type = 'OBJECT'
        var.targets[0].id = source_object
        driver.driver.expression = f"{tp}"
        driver.driver.expression += " "
        driver.driver.expression = driver.driver.expression[:-1]


def select(obj, active=True):

    if obj:
        obj.select_set(True)
        if active:
            bpy.context.view_layer.objects.active = obj


def deselect(obj):
    if obj:
        obj.select_set(False)


def link_to_collection(obj, col):

    if isinstance(col, str):
        if col in bpy.data.collections:
            bpy.data.collections[col].objects.link(obj)
    else:
        if col.name in bpy.data.collections:
            col.objects.link(obj)


def move_to_collection(obj, col):
    if isinstance(col, str):
        if col not in bpy.data.collections:
            bpy.data.collections.new(col)
            col = bpy.data.collections[col]
            bpy.context.scene.collection.children.link(col)
        else:
            col = bpy.data.collections[col]
    cols = obj.users_collection
    for c in cols:
        c.objects.unlink(obj)
    link_to_collection(obj, col)


def recurLayerCollection(layerColl, collName):
    found = None
    if (layerColl.name == collName):
        return layerColl
    for layer in layerColl.children:
        found = recurLayerCollection(layer, collName)
        if found:
            return found


def get_collection(name):
    if not [c.name for c in bpy.data.collections if bpy.context.scene.user_of_id(c) and name in c.name]:
        col = bpy.data.collections.new(name)
        #col = bpy.data.collections[name]
        bpy.context.scene.collection.children.link(col)
        return col.name
    return [c.name for c in bpy.data.collections if bpy.context.scene.user_of_id(c) and name in c.name][0]


def delete_object(obj):
    if obj:
        bpy.data.objects.remove(obj, do_unlink=True)


def delete_object_with_data(obj):
    if obj and obj.name in bpy.data.objects:
        data = obj.data
        isMesh = obj.type == 'MESH'
        bpy.data.objects.remove(obj, do_unlink=True)
        if isMesh:
            bpy.data.meshes.remove(data)


def duplicate_object(obj, col=None):
    new_obj = None
    to_copy = bpy.data.objects[obj.name]
    if not col:
        col = bpy.context.view_layer.active_layer_collection.collection
    else:
        col = get_collection(col)
        col = bpy.data.collections[col]
    new_obj = to_copy.copy()
    if new_obj.data is not None:
        new_obj.data = to_copy.data.copy()
    new_obj.animation_data_clear()
    if col:
        col.objects.link(new_obj)
    return new_obj


def delete_collection(col, delete_objects=False):
    colref = None
    if isinstance(col, str):
        colref = get_collection(col)
        colref = bpy.data.collections[colref]
    else:
        colref = col

    if delete_objects:
        deselect_all()
        if len(colref.objects) > 0:
            for co in colref.objects:
                delete_object(co)
                # co.select_set(True)
            # delete_selected_objects()
    else:
        deselect_all()
        if len(colref.objects) > 0:
            for co in colref.objects:
                bpy.context.scene.collection.objects.link(co)

    bpy.data.collections.remove(colref)


def convert_to_mesh(obj):
    deselect_all()
    select(obj)
    bpy.ops.object.convert(target='MESH')


def move_objects_to_collection(objs, col):
    if col not in bpy.data.collections:
        col = bpy.data.collections.new(col)
        bpy.context.scene.collection.children.link(col)
    col = bpy.data.collections[col]
    for o in objs:
        for c in o.users_collection:
            c.objects.unlink(o)
        link_to_collection(o, col)


def light_power_multiply(val=0, ref=None):
    objlist = []
    if ref is None:
        objlist = bpy.context.selected_objects
    else:
        objlist = [ref]
    for o in objlist:
        o.data.energy *= val


def largest_substr(str1, str2):
    matcher = difflib.SequenceMatcher(None, str1, str2)
    match = matcher.find_longest_match(0, len(str1), 0, len(str2))
    return str1[0: match.size] if match.a == 0 and match.b == 0 else ""


def longest_substr(str1, str2):
    for i in range(min(len(str1), len(str2))):
        if str1[i] != str2[i]: return str1[0:i]
    return str1[0:i+1]
def distribute(original_strings):
    strings = original_strings.copy()
    groups = []
    while len(strings) > 0:
        group = [strings[0]]
        rem_strings = []
        substr = strings[0]
        strings.pop(0)
        for string in strings:
            new_substr = longest_substr(string, substr)
            #print(new_substr)
            if "_" in string:
                max_length=string.index("_")
            else:
                max_length=1
            if new_substr and len(new_substr) > max_length:
                group.append(string)
                substr = new_substr
            else:
                rem_strings.append(string)
        groups.append({"contents": group, "common": substr})
        strings = rem_strings
        #print(groups)
    return groups


def copy_modifiers(obj, target):
    for mSrc in obj.modifiers:
        mDst = target.modifiers.get(mSrc.name, None)
        if not mDst:
            mDst = target.modifiers.new(mSrc.name, mSrc.type)
        properties = [p.identifier for p in mSrc.bl_rna.properties
                      if not p.is_readonly]
        for prop in properties:
            setattr(mDst, prop, getattr(mSrc, prop))


def get_dimensions(obj):

    return max([Vector((v.co.x*obj.scale.x, v.co.y*obj.scale.y, v.co.z*obj.scale.z)).length for v in obj.data.vertices])


def get_id():
    return "".join(random.sample(random_id_source, 6))


def sortTextures(textures):
    BaseColor = None
    Roughness = None
    Normal = None
    Height = None
    Metal = None
    Specular = None
    opacity = None
    Gloss=None
    ao= None
    Bump=None
    Emit=None
    len = 0
    BaseColorTags = ['diffuse', 'diff', 'albedo', 'col', 'color']
    RoughnessTags = ['roughness', 'rough', 'rgh']
    GlossTags = ['gloss', 'glossiness']
    NormalTags = ['normal', 'nor', 'nrm', 'nrml', 'norm']
    HeightTags = ['displacement', 'displace', 'disp',
                  'dsp', 'height', 'heightmap','depth']
    BumpTags = [ 'bmp', 'bump']
    MetallicTags = ['metallic', 'metalness', 'mtl']
    SpecularTags = ['specularity', 'specular', 'spec', 'spc']
    opacityTags = ['opacity', 'alpha', ' transparent']
    aoTags=['ao','occlusion']
    EmissionTags=["emit","emission","emissive"]
    for tex in textures:
        if any(x in tex.lower() for x in BaseColorTags) and BaseColor is None:
            BaseColor = tex
            len = len+1
        elif any(x in tex.lower() for x in RoughnessTags) and Roughness is None:
            Roughness = tex
            len = len+1
        elif any(x in tex.lower() for x in NormalTags) and Normal is None:
            Normal = tex
            len = len+1
        elif any(x in tex.lower() for x in HeightTags) and Height is None:
            Height = tex
            len = len+1
        elif any(x in tex.lower() for x in MetallicTags) and Metal is None:
            Metal = tex
            len = len+1
        elif any(x in tex.lower() for x in SpecularTags) and Specular is None:
            Specular = tex
            len = len+1
        elif any(x in tex.lower() for x in opacityTags) and opacity is None:
            opacity = tex
            len = len+1
        elif any(x in tex.lower() for x in GlossTags) and Gloss is None:
            Gloss = tex
            len = len+1
        elif any(x in tex.lower() for x in aoTags) and ao is None:
            ao = tex
            len = len+1
        elif any(x in tex.lower() for x in BumpTags) and Bump is None:
            Bump = tex
            len = len+1
        elif any(x in tex.lower() for x in EmissionTags) and Emit is None:
            Emit = tex
            len = len+1
    return[BaseColor, Roughness, Normal, Height, Metal, Specular, opacity,Gloss,ao,Bump,Emit, len]


def get_quality(content):
    if content:
        if "1K" in content[0] or "1024" in content[0]:
            return "1K", 1
        elif "2K" in content[0] or "2048" in content[0]:
            return "2K", 2
        elif "4K" in content[0] or "4096" in content[0]:
            return "4K", 4
        elif "8K" in content[0] or "8192" in content[0]:
            return "8K", 8
        elif "6K" in content[0] or "6144" in content[0]:
            return "6K", 6
        elif "12K" in content[0]:
            return "12K", 12
        elif "16K" in content[0]:
            return "16K", 16
    return "", 4

def create_preview_and_save(materials,path):
    mats=materials[:]
    #print(mats)
    while mats:
        mat=mats[0]
        if any(mat.preview.image_pixels[:]):
            mats.pop(0)
        else:
            return 0.1
    bpy.data.libraries.write(path
                , set(materials), fake_user=True)
    #print("Saved!")
    return None
def clear_mat_name(name):
    #print(name.replace("1K","").replace("2K","").replace("4K","").replace("6K","").replace("8K","").replace("12K","").replace("12K","").strip())
    return name.replace("1K","").replace("2K","").replace("4K","").replace("6K","").replace("8K","").replace("12K","").replace("12K","").strip()
def assign_mats_by_name(objects,mats):
    for obj in objects:
        if obj.name in [clear_mat_name(a.name) for a in mats] or " ".join([a.name for a in objects]).replace("_"," ")  in [clear_mat_name(a.name) for a in mats]:
            #print(obj)
            for i in range(len(obj.material_slots)):
                bpy.ops.object.material_slot_remove({'object': obj})
            obj.data.materials.append([a for a in mats if clear_mat_name(a.name) == obj.name or clear_mat_name(a.name)==" ".join([a.name for a in objects]).replace("_"," ")][0])
def setup_materials_from_images(images):
    mats_created = []
    filename = "RT_StartMat" if preferences().material_preset=='Displacement' else "RT_StartMat_Bump"
    if preferences().material_preset=='FBX':
            filename="RT_StartMat_FBX"
    file_path = os.path.join(os.path.dirname(
        os.path.abspath(__file__)), "Assets", "RTMatSetUp.blend", "Material")
    mat = append_mat(filename, file_path)
    dab_mat=append_mat("RT_StartMatDAB", file_path)
    if len(images) > 0:
        groups = distribute([a.name for a in images])

        for group in groups:
            # if len(groups)>1 and len(groups[0]['contents'])<len(groups[1]['contents']):
            #    print(f"{i} => Material Name => {groups[1]['common'].replace('_',' ')}")
            #    print(f"Textures : {groups[1]['contents']}")
            # else:
            #    print(f"{i} => Material Name => {groups[0]['common'].replace('_',' ')}")
            #    print(f"Textures : {groups[0]['contents']}")
            tex = sortTextures(group['contents'])
            if tex[11] > 0 or (tex[0] is not None and preferences().onlyDiffuse):
                #print(f"{i} => Material Name => {group['common'].replace('_',' ')}")
                #print(f"Textures : {group['contents']}")
                if tex[3] and tex[9]:
                    newMat=dab_mat.copy()
                else:
                    newMat = mat.copy()
                mats_created.append(newMat)
                newMat.use_fake_user = True
                nodes_to_arrange=[]
                newMat.name = group['common'].replace(
                    '_', ' ')+get_quality(group['contents'])[0]
                # context.active_object.active_material=newMat
                # if tex[6]==0:
                #    bpy.data.materials.remove(newMat)
                # else:
                # print(tex)
                if newMat.node_tree.nodes.get("AO") and newMat.node_tree.nodes.get("AO Mix"):
                    if tex[8] is not None :
                        newMat.node_tree.nodes["AO"].image = bpy.data.images[tex[8]]
                        newMat.node_tree.nodes["AO"].image.colorspace_settings.is_data = True
                        nodes_to_arrange.append(newMat.node_tree.nodes["AO"])
                    else:
                        # print(newMat,newMat.node_tree.nodes["BaseColor"].outputs[0].links[0].to_socket,dir(newMat.node_tree.nodes["AO Mix"].outputs[0]),newMat.node_tree.nodes["AO Mix"].outputs[2].links)
                        newMat.node_tree.links.new(newMat.node_tree.nodes["BaseColor"].outputs[0],newMat.node_tree.nodes["Principled BSDF"].inputs[0])
                        newMat.node_tree.nodes.remove(
                            newMat.node_tree.nodes["AO"])
                        newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["AO Mix"])
                if tex[0] is not None:
                    newMat.node_tree.nodes["BaseColor"].image = bpy.data.images[tex[0]]
                    nodes_to_arrange.append(newMat.node_tree.nodes["BaseColor"])
                    # print(newMat.node_tree.nodes["BaseColor"].image.filepath)
                if tex[4] is not None:
                    newMat.node_tree.nodes["Metallic"].image = bpy.data.images[tex[4]]
                    newMat.node_tree.nodes["Metallic"].image.colorspace_settings.is_data = True
                    nodes_to_arrange.append(newMat.node_tree.nodes["Metallic"])
                else:
                    newMat.node_tree.nodes.remove(
                        newMat.node_tree.nodes["Metallic"])
                if tex[5] is not None:
                    newMat.node_tree.nodes["Specular"].image = bpy.data.images[tex[5]]
                    newMat.node_tree.nodes["Specular"].image.colorspace_settings.is_data = True
                    nodes_to_arrange.append(newMat.node_tree.nodes["Specular"])
                else:
                    newMat.node_tree.nodes.remove(
                        newMat.node_tree.nodes["Specular"])
                if tex[1] is not None:
                    newMat.node_tree.nodes["Roughness"].image = bpy.data.images[tex[1]]
                    newMat.node_tree.nodes["Roughness"].image.colorspace_settings.is_data = True
                    nodes_to_arrange.append(newMat.node_tree.nodes["Roughness"])
                else:
                    if tex[7] is not None:
                        newMat.node_tree.nodes["Roughness"].image = bpy.data.images[tex[7]]
                        newMat.node_tree.nodes["Roughness"].image.colorspace_settings.is_data = True
                        soc=newMat.node_tree.nodes["Roughness"].outputs[0].links[0].to_socket
                        invertnode=newMat.node_tree.nodes.new('ShaderNodeInvert')
                        invertnode.location=newMat.node_tree.nodes["Roughness"].location.x+300,newMat.node_tree.nodes["Roughness"].location.y
                        newMat.node_tree.links.new(newMat.node_tree.nodes["Roughness"].outputs[0],invertnode.inputs[1])
                        newMat.node_tree.links.new(invertnode.outputs[0],soc)
                        nodes_to_arrange.append(newMat.node_tree.nodes["Roughness"])
                        newMat.node_tree.nodes["Roughness"].label="Glossiness"
                        newMat.node_tree.nodes["Roughness"].name="Glossiness"
                        
                        
                    else:
                        newMat.node_tree.nodes.remove(
                            newMat.node_tree.nodes["Roughness"])
                if newMat.node_tree.nodes.get("Emission"):
                    if tex[10] is not None:
                        newMat.node_tree.nodes["Emission"].image = bpy.data.images[tex[10]]
                        newMat.node_tree.nodes["Emission"].image.colorspace_settings.is_data = True
                        nodes_to_arrange.append(newMat.node_tree.nodes["Emission"])
                    else:
                        newMat.node_tree.nodes.remove(
                            newMat.node_tree.nodes["Emission"])
                
                if tex[6] is not None:
                    newMat.blend_method = 'CLIP' if newMat.blend_method == 'OPAQUE' else newMat.blend_method
                    newMat.node_tree.nodes["Opacity"].image = bpy.data.images[tex[6]]
                    newMat.node_tree.nodes["Opacity"].image.colorspace_settings.is_data = True
                    nodes_to_arrange.append(newMat.node_tree.nodes["Opacity"])
                else:
                    newMat.node_tree.nodes.remove(
                        newMat.node_tree.nodes["Opacity"])
                if tex[2] is not None :
                    newMat.node_tree.nodes["Normal"].image = bpy.data.images[tex[2]]
                    #newMat.node_tree.nodes["Normal"].image.colorspace_settings.name='Filmic Log'
                    newMat.node_tree.nodes["Normal"].image.colorspace_settings.is_data = True
                    nodes_to_arrange.append(newMat.node_tree.nodes["Normal"])
                else:
                    newMat.node_tree.nodes.remove(
                        newMat.node_tree.nodes["Normal"])
                    if not preferences().material_preset=='Bump':
                        newMat.node_tree.nodes.remove(
                            newMat.node_tree.nodes["Normal Map"])
                if newMat.node_tree.nodes.get("Height"):
                    if tex[3] is not None:
                        if tex[9] is not None:
                            newMat.node_tree.nodes["Bump"].image = bpy.data.images[tex[9]]
                            newMat.node_tree.nodes["Bump"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Bump"])
                        newMat.node_tree.nodes["Height"].image = bpy.data.images[tex[3]]
                        newMat.node_tree.nodes["Height"].image.colorspace_settings.is_data = True
                        nodes_to_arrange.append(newMat.node_tree.nodes["Height"])
                        
                    else:
                        if tex[9] is not None:
                            newMat.node_tree.nodes["Height"].image = bpy.data.images[tex[9]]
                            newMat.node_tree.nodes["Height"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Height"])
                        else:
                            newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["Height"])
                            if not preferences().material_preset=='Bump':
                                newMat.node_tree.nodes.remove(
                                    newMat.node_tree.nodes["Displacement"])
                            # if tex[2]:
                            #     newMat.node_tree.links(newMat.node_tree.nodes["Normal"].outputs[0],newMat.node_tree.nodes["Bump"].outputs[0].links[0].to_socket)
                            if preferences().material_preset=='Bump':
                                if newMat.node_tree.nodes.get('Normal Map'):
                                    newMat.node_tree.links.new(newMat.node_tree.nodes["Normal Map"].outputs[0],newMat.node_tree.nodes["Bump"].outputs[0].links[0].to_socket)
                                if newMat.node_tree.nodes.get("Bump"):
                                            newMat.node_tree.nodes.remove(
                                                newMat.node_tree.nodes["Bump"])
                
                if len(nodes_to_arrange)>1:
                        for index,n in enumerate(nodes_to_arrange[1:]):
                            n.location.y=nodes_to_arrange[index].location.y-(nodes_to_arrange[index].height*(3 if not nodes_to_arrange[index].hide else 1))
                newMat.node_tree.nodes['Reroute'].location.y=sum([(a.location.y-a.height)/2 for a in nodes_to_arrange])/len(nodes_to_arrange)
        for m in mats_created:
            m.use_fake_user=True
        bpy.data.materials.remove(mat)
        bpy.data.materials.remove(dab_mat)
    return mats_created
def setup_materials(self, context, folder_path, lib_path=None, mark_asset=False, tags=None, fromsetupmats=False):
    mats_created = []
    filename = "RT_StartMat" if preferences().material_preset=='Displacement' else "RT_StartMat_Bump"
    if preferences().material_preset=='FBX':
            filename="RT_StartMat_FBX"
    file_path = os.path.join(os.path.dirname(
        os.path.abspath(__file__)), "Assets", "RTMatSetUp.blend", "Material")
    if os.path.isdir(folder_path):
        mat = append_mat(filename, file_path)
        dab_mat=append_mat("RT_StartMatDAB", file_path)
        
        for i, j, y in os.walk(folder_path):
            # print(i)
            # print(os.listdir(i))
            files = []
            for name in os.listdir(i):
                if name.endswith('jpg') or name.endswith('png') or name.endswith('exr'):
                    files.append(name)

            if len(files) > 1:
                groups = distribute(files)

                for group in groups:
                    # if len(groups)>1 and len(groups[0]['contents'])<len(groups[1]['contents']):
                    #    print(f"{i} => Material Name => {groups[1]['common'].replace('_',' ')}")
                    #    print(f"Textures : {groups[1]['contents']}")
                    # else:
                    #    print(f"{i} => Material Name => {groups[0]['common'].replace('_',' ')}")
                    #    print(f"Textures : {groups[0]['contents']}")
                    tex = sortTextures(group['contents'])
                    if tex[11] > 1 or (tex[0] is not None and preferences().onlyDiffuse):
                        #print(f"{i} => Material Name => {group['common'].replace('_',' ')}")
                        #print(f"Textures : {group['contents']}")
                        if tex[3] and tex[9]:
                            newMat=dab_mat.copy()
                        else:
                            newMat = mat.copy()
                        newMat.use_fake_user = True
                        nodes_to_arrange=[]
                        newMat.name = group['common'].replace(
                            '_', ' ')+get_quality(group['contents'])[0]
                        # context.active_object.active_material=newMat
                        # if tex[6]==0:
                        #    bpy.data.materials.remove(newMat)
                        # else:
                        # print(tex)
                        if newMat.node_tree.nodes.get("AO") and newMat.node_tree.nodes.get("AO Mix"):
                            if tex[8] is not None and newMat.node_tree.nodes.get("AO") and newMat.node_tree.nodes.get("AO Mix"):
                                newMat.node_tree.nodes["AO"].image = bpy.data.images.load(
                                    os.path.join(i, tex[8]))
                                newMat.node_tree.nodes["AO"].image.colorspace_settings.is_data = True
                                nodes_to_arrange.append(newMat.node_tree.nodes["AO"])
                            else:
                                
                                    newMat.node_tree.links.new(newMat.node_tree.nodes["BaseColor"].outputs[0],newMat.node_tree.nodes["Principled BSDF"].inputs[0])
                                    newMat.node_tree.nodes.remove(
                                        newMat.node_tree.nodes["AO"])
                                    newMat.node_tree.nodes.remove(
                                            newMat.node_tree.nodes["AO Mix"])
                        if tex[0] is not None:
                            newMat.node_tree.nodes["BaseColor"].image = bpy.data.images.load(
                                os.path.join(i, tex[0]))
                            nodes_to_arrange.append(newMat.node_tree.nodes["BaseColor"])
                            # print(newMat.node_tree.nodes["BaseColor"].image.filepath)
                        if tex[4] is not None:
                            newMat.node_tree.nodes["Metallic"].image = bpy.data.images.load(
                                os.path.join(i, tex[4]))
                            newMat.node_tree.nodes["Metallic"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Metallic"])
                        else:
                            newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["Metallic"])
                        if tex[5] is not None:
                            newMat.node_tree.nodes["Specular"].image = bpy.data.images.load(
                                os.path.join(i, tex[5]))
                            newMat.node_tree.nodes["Specular"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Specular"])
                        else:
                            newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["Specular"])
                        if tex[1] is not None:
                            newMat.node_tree.nodes["Roughness"].image = bpy.data.images.load(
                                os.path.join(i, tex[1]))
                            newMat.node_tree.nodes["Roughness"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Roughness"])
                        else:
                            if tex[7] is not None:
                                newMat.node_tree.nodes["Roughness"].image = bpy.data.images.load(
                                os.path.join(i, tex[7]))
                                newMat.node_tree.nodes["Roughness"].image.colorspace_settings.is_data = True
                                soc=newMat.node_tree.nodes["Roughness"].outputs[0].links[0].to_socket
                                invertnode=newMat.node_tree.nodes.new('ShaderNodeInvert')
                                invertnode.location=newMat.node_tree.nodes["Roughness"].location.x+300,newMat.node_tree.nodes["Roughness"].location.y
                                newMat.node_tree.links.new(newMat.node_tree.nodes["Roughness"].outputs[0],invertnode.inputs[1])
                                newMat.node_tree.links.new(invertnode.outputs[0],soc)
                                nodes_to_arrange.append(newMat.node_tree.nodes["Roughness"])
                                newMat.node_tree.nodes["Roughness"].label="Glossiness"
                                newMat.node_tree.nodes["Roughness"].name="Glossiness"
                                
                                
                            else:
                                newMat.node_tree.nodes.remove(
                                    newMat.node_tree.nodes["Roughness"])
                        if newMat.node_tree.nodes.get("Emission"):
                            if tex[10] is not None :
                                newMat.node_tree.nodes["Emission"].image = bpy.data.images.load(
                                    os.path.join(i, tex[10]))
                                newMat.node_tree.nodes["Emission"].image.colorspace_settings.is_data = True
                                nodes_to_arrange.append(newMat.node_tree.nodes["Emission"])
                            else:
                                newMat.node_tree.nodes.remove(
                                    newMat.node_tree.nodes["Emission"])
                        if tex[6] is not None:
                            newMat.blend_method = 'CLIP' if newMat.blend_method == 'OPAQUE' else newMat.blend_method
                            newMat.node_tree.nodes["Opacity"].image = bpy.data.images.load(
                                os.path.join(i, tex[6]))
                            newMat.node_tree.nodes["Opacity"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Opacity"])
                        else:
                            newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["Opacity"])
                        if tex[2] is not None:
                            newMat.node_tree.nodes["Normal"].image = bpy.data.images.load(
                                os.path.join(i, tex[2]))
                            
                            newMat.node_tree.nodes["Normal"].image.colorspace_settings.is_data = True
                            nodes_to_arrange.append(newMat.node_tree.nodes["Normal"])
                        else:
                            newMat.node_tree.nodes.remove(
                                newMat.node_tree.nodes["Normal"])
                            if not preferences().material_preset=='Bump':
                                newMat.node_tree.nodes.remove(
                                    newMat.node_tree.nodes["Normal Map"])
                        if newMat.node_tree.nodes.get("Height"):
                            if tex[3] is not None :
                                if tex[9] is not None:
                                    newMat.node_tree.nodes["Bump"].image = bpy.data.images.load(
                                    os.path.join(i, tex[9]))
                                    newMat.node_tree.nodes["Bump"].image.colorspace_settings.is_data = True
                                    nodes_to_arrange.append(newMat.node_tree.nodes["Bump"])
                                newMat.node_tree.nodes["Height"].image = bpy.data.images.load(
                                    os.path.join(i, tex[3]))
                                newMat.node_tree.nodes["Height"].image.colorspace_settings.is_data = True
                                nodes_to_arrange.append(newMat.node_tree.nodes["Height"])
                                
                            else:
                                if tex[9] is not None:
                                    newMat.node_tree.nodes["Height"].image = bpy.data.images.load(
                                    os.path.join(i, tex[9]))
                                    newMat.node_tree.nodes["Height"].image.colorspace_settings.is_data = True
                                    nodes_to_arrange.append(newMat.node_tree.nodes["Height"])
                                else:
                                    newMat.node_tree.nodes.remove(
                                        newMat.node_tree.nodes["Height"])
                                    if not preferences().material_preset=='Bump':
                                        newMat.node_tree.nodes.remove(
                                            newMat.node_tree.nodes["Displacement"])
                                    if preferences().material_preset=='Bump':
                                        if newMat.node_tree.nodes.get('Normal Map'):
                                            newMat.node_tree.links.new(newMat.node_tree.nodes["Normal Map"].outputs[0],newMat.node_tree.nodes["Bump"].outputs[0].links[0].to_socket)
                                        if newMat.node_tree.nodes.get("Bump"):
                                            newMat.node_tree.nodes.remove(
                                                newMat.node_tree.nodes["Bump"])
                        
                        
                        
                        if len(nodes_to_arrange)>1:
                                for index,n in enumerate(nodes_to_arrange[1:]):
                                    n.location.y=nodes_to_arrange[index].location.y-(nodes_to_arrange[index].height*(3 if not nodes_to_arrange[index].hide else 1))
                        newMat.node_tree.nodes['Reroute'].location.y=sum([(a.location.y-a.height)/2 for a in nodes_to_arrange])/len(nodes_to_arrange)
                        if mark_asset:

                            newMat.asset_mark()

                            if tags:
                                for t in tags:
                                    newMat.asset_data.tags.new(t)
                            
                            newMat.asset_generate_preview()
                        mats_created.append(newMat)
                if mark_asset and mats_created:
                    bpy.app.timers.register(functools.partial(create_preview_and_save,mats_created,lib_path))
                    #bpy.data.libraries.write(
                    #    lib_path, set(mats_created), fake_user=True)
        bpy.data.materials.remove(mat)
        bpy.data.materials.remove(dab_mat)
    return mats_created

def append_mat(filename, file_path):
    matInit = []

    for m in bpy.data.materials:
        matInit.append(m.name)
    bpy.ops.wm.append(
            directory=file_path,
            filename=filename, autoselect=False
        )
    matAfter = []

    for m in bpy.data.materials:
        matAfter.append(m.name)
    mat = Diff(matInit, matAfter)
    mat = bpy.data.materials.get(mat[0])
    return mat
import http.client as httplib

def isConnected2():
    conn = httplib.HTTPSConnection("8.8.8.8", timeout=5)
    try:
        conn.request("HEAD", "/")
        return True
    except Exception as e:
        return False
    finally:
        conn.close()
def isConnected():
    try:
        sock = socket.create_connection((preferences().site_to_check_connection, 80))
        if sock is not None:
            sock.close
        return True
    except Exception as e:
        #return have_internet()
        print(e)
    return False


def getCurrentVersion():
    try:
        response = requests.get(
            "https://github.com/rantools/rantools/blob/main/README.md", timeout=2)
        response = str(response.content)
        brokenResponse = response[response.index("Current Version")+17:]
        version = brokenResponse[:5]
        brokenResponse = response[response.index("Custom Message")+16:]
        message = brokenResponse[:brokenResponse.index("]")]

        return version, message
    except:
        return "Disconnected", "Disconnected"


def getVertexNormal(vert, bm):
    vSum = Vector((0, 0, 0))
    for a in vert.link_faces:
        vSum = vSum+a.normal
    return vSum/len(vert.link_faces)
def process_json(data):
    result={}
    for a,b in data.items():
        result[a]={literal_eval(k): v for k, v in b.items()}
    return result