
import bpy
from . utils import * 
import mathutils
n={"BAC":'ShaderNodeBrightContrast',"HS":"ShaderNodeHueSaturation","Invert":"ShaderNodeInvert","Mix":"ShaderNodeMixRGB"}
l=[[['BAC',0],['HS',4]],[['HS',0],['Invert',1]],[['Invert',0],['Mix',1]]]
d=[['Invert',[(0,0)]],['Mix',[(0,0)]]]
outs=[['Mix',0]]
inps=[[['NodeSocketColor','Color'],[['BAC',0]]],[['NodeSocketValue','Brightness'],[['BAC',1]]],[['NodeSocketValue','Contrast'],[['BAC',2]]]]
def BakeEdgeMask(context,worn=False):
        bpy.context.scene.render.bake.use_selected_to_active=False
        obj = bpy.context.active_object
        image_name = obj.name + '_EdgeMask_'+f"{context.scene.rt_tools.texture_resolution}"
        if image_name not in bpy.data.images.keys():
            img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
        else:
            #img=bpy.data.images[image_name]
            bpy.data.images.remove(bpy.data.images[image_name])
            img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
        img.source='GENERATED'
        if not worn:
            if bpy.data.node_groups.get('RT_Edge_Mask') is None:
                #n={"Coordinates":"ShaderNodeTexCoord","Bevel":"ShaderNodeBevel","VectorMath":"ShaderNodeVectorMath","Math":"ShaderNodeMath",'Invert':"ShaderNodeInvert"}
                #l=[[['VectorMath',1],['Math',0]],[['Coordinates',1],['Bevel',1]],[['Bevel',0],['VectorMath',0]],[['Coordinates',1],['VectorMath',1]],[['Math',0],['Invert',1]]]
                #d=[['Math',[(1,1000)]]]
                #outs=[['Invert',0]]
                #attrs=[['Math',[('operation','POWER')]],['VectorMath',[('operation','DOT_PRODUCT')]],['Bevel',[('samples',16)]]]
                #CreateNodeGroup("RT_EdgeMaskGroup",n,l,d,[],outs,[],attrs)
                path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
            
        #RT_Edge_From_NormalMap
                bpy.ops.wm.append(
                        directory=path,
                        filename='RT_Edge_Mask', autoselect=False
                    )
        else:
            if bpy.data.node_groups.get('RT_Worn_Edge_Mask') is None:
                path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
            
                bpy.ops.wm.append(
                        directory=path,
                        filename='RT_Worn_Edge_Mask', autoselect=False
                    )

        for mat in obj.data.materials:
            if mat:
                mat.use_nodes = True 
                nodes = mat.node_tree.nodes
                output = nodes.new(type='ShaderNodeOutputMaterial')
                output.name="RT_EdgeMask_Output"
                output.location=200,900
                EdgeDetectGroup=nodes.new('ShaderNodeGroup')
                EdgeDetectGroup.location=-550,200
                EdgeDetectGroup.name="RT_EdgeDetection"
                if not worn:
                    EdgeDetectGroup.node_tree = bpy.data.node_groups.get('RT_Edge_Mask')
                else:
                    EdgeDetectGroup.node_tree = bpy.data.node_groups.get('RT_Worn_Edge_Mask')
                #BevelNode=None
                #for n in EdgeDetectGroup.node_tree.nodes:
                #    if n.name=='Bevel':
                #        BevelNode=n
                if worn:
                    EdgeDetectGroup.inputs[1].default_value=context.scene.rt_tools.bevel_width*20
                    EdgeDetectGroup.inputs[2].default_value=context.scene.rt_tools.bevel_width*10
                else:
                    EdgeDetectGroup.inputs[0].default_value=context.scene.rt_tools.bevel_width
                links=mat.node_tree.links
                links.new(EdgeDetectGroup.outputs[0],output.inputs[0])
                for node in nodes :
                    if node.type == 'OUTPUT_MATERIAL' :
                        node.is_active_output = False
                output.is_active_output = True
                if 'RT_EdgeMask' in [n.name for n in nodes]:
                    texture_node=nodes.get('RT_EdgeMask')
                else:
                    texture_node =nodes.new('ShaderNodeTexImage')
                    texture_node.name = 'RT_EdgeMask'
                    texture_node.location=-900,-200
                
                texture_node.select = True
                nodes.active = texture_node
                texture_node.image = img #Assign the image to the node
        engine=bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'CYCLES'
        samples=bpy.context.scene.cycles.samples
        bpy.context.scene.cycles.samples=context.scene.rt_tools.bevel_render_samples
        bpy.context.scene.cycles.device='GPU'
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.bake(type='COMBINED', save_mode='EXTERNAL')
        bpy.context.scene.render.engine=engine
        bpy.context.scene.cycles.samples=samples
        
        if bpy.data.is_saved:            
            filename = bpy.path.basename(bpy.data.filepath)
            filename = os.path.splitext(filename)[0]
            blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
            filepath = os.path.splitext(bpy.data.filepath)[0]  if not os.path.isdir(context.scene.projectInfo.textures_folder_path) else context.scene.projectInfo.textures_folder_path
            fname=obj.name + "_EdgeMask"
            if not os.path.exists(filepath):
                os.mkdir(filepath)

            files = [file for file in os.listdir(filepath)
                    if file.startswith(blendname)]
            i=0
            name=obj.name + "_EdgeMask"
            while(fname+".png" in files):
                fname = f"{name}_{i}"
                #print(fname)
                i+=1
            final_name = os.path.join(filepath, fname+".png")

            if not img:
                return "ERROR"

            img.save_render(final_name, scene=None)
        #img.save_render(filepath="D:\\Test\\"+obj.name + "_BevelMap.png")
            
        #In the last step, we are going to delete the nodes we created earlier
        for mat in obj.data.materials:
            if mat:
                for n in mat.node_tree.nodes:
                    if n.name == 'RT_EdgeMask_Output' or n.name=="RT_EdgeDetection":
                        mat.node_tree.nodes.remove(n)
                for node in mat.node_tree.nodes :
                        if node.type == 'OUTPUT_MATERIAL':
                            node.is_active_output = True
class RTOOLS_OT_Bake_Bevels(bpy.types.Operator):
    bl_idname = "rtools.bakebevels"
    bl_label = "Bake Bevels"
    bl_description = "Bake Bevels For Eevee\nSHIFT+LMB:Bake Edge Mask\nALT+LMB:Bake Worn Edge Mask\nCTRL+SHIFT+LMB:Bake Bevels And Edge Mask\nCTRL+ALT+LMB:Bake Bevels And Worn Edge Mask"
    bl_options = {"REGISTER","UNDO"}
    NormalTags = ['normal', 'nor', 'nrm', 'nrml', 'norm']
    @classmethod
    def poll(cls,context):
        return len(context.selected_objects)>0 and context.active_object is not None and context.active_object.type in {'MESH','CURVE','SURFACE','FONT'} and len(context.active_object.data.materials)>0
        
    def execute(self, context):
        bpy.context.scene.render.bake.use_selected_to_active=False
        obj = bpy.context.active_object
        # You can choose your texture size (This will be the de bake image)
        image_name = obj.name + '_BevelMap_'+f"{context.scene.rt_tools.texture_resolution}"
        if image_name not in bpy.data.images.keys():
            img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
        else:
            #img=bpy.data.images[image_name]
            bpy.data.images.remove(bpy.data.images[image_name])
            img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
        img.source='GENERATED'
        if bpy.data.node_groups.get('RT_Edge_From_NormalMap') is None:
            #n={'RGB': 'ShaderNodeRGB', 'Invert.001': 'ShaderNodeInvert', 'Invert': 'ShaderNodeInvert', 'Mix': 'ShaderNodeMixRGB', 'Map Range': 'ShaderNodeMapRange', 'Math.001': 'ShaderNodeMath', 'Math': 'ShaderNodeMath'}
            #l=[[['Math', 0], ['Invert', 1]], [['RGB', 0], ['Math', 0]], [['RGB', 0], ['Math.001', 0]], [['Math.001', 0], ['Invert.001', 1]], [['Invert.001', 0], ['Mix', 2]], [['Invert', 0], ['Mix', 1]], [['Map Range', 0], ['Math', 2]]]
            #d=[['Map Range',[(1,0),(2,10)]],['Math.001',[(2,0.2)]],['RGB',[(0,[0.216,0.216,1,1])]]]
            #attributes=[['Math',[('operation','COMPARE')]],['Math.001',[('operation','COMPARE')]],['Mix',[('blend_type','ADD')]]]
            #outs=[["Mix",0]]
            #inps=[[['NodeSocketVector',"Normal"],[['Math',1],['Math.001',1]]],[['NodeSocketFloat','Threshold'],[["Map Range",0]]]]
            #locs=[['RGB', [-576, 742]], ['Invert.001', [53, 442]], ['Invert', [163, 756]], ['Mix', [396, 641]], ['Map Range', [-325, 527]], ['Math.001', [-136, 496]], ['Math', [-79, 768]]]
            #CreateNodeGroup("RT_EdgeDetect",n,l,d,locs,outs,inps,attributes,isBevel=True)
            path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","ExtraAssets.blend","NodeTree")
        
       
            bpy.ops.wm.append(
                    directory=path,
                    filename='RT_Edge_From_NormalMap', autoselect=False
                )
        for mat in obj.data.materials:
            if mat:
                mat.use_nodes = True 
                nodes = mat.node_tree.nodes
                output = nodes.new(type='ShaderNodeOutputMaterial')
                output.name="RT_Bevel_Output"
                output.location=200,900
                PrincipledNode=nodes.new('ShaderNodeBsdfPrincipled')
                PrincipledNode.location=0,900
                PrincipledNode.name="RT_PRINCIPLED"
                bevelNode=nodes.new('ShaderNodeBevel')
                bevelNode.samples=16
                bevelNode.inputs[0].default_value=context.scene.rt_tools.bevel_width
                bevelNode.name="RT_BEVEL"
                links=mat.node_tree.links
                links.new(PrincipledNode.outputs[0],output.inputs[0])
                links.new(bevelNode.outputs[0],PrincipledNode.inputs[(22 if (3, 0, 0) <= bpy.app.version else 20)])
                for node in nodes :
                    if node.type == 'OUTPUT_MATERIAL' :
                        node.is_active_output = False
                output.is_active_output = True
                if {n.name for n in nodes}.issuperset({'RT_Bevel_Map'}):
                    texture_node=nodes.get('RT_Bevel_Map')
                else:
                    texture_node =nodes.new('ShaderNodeTexImage')
                    texture_node.name = 'RT_Bevel_Map'
                    texture_node.location=-900,200
                    
                    EdgeDetectGroup=nodes.new('ShaderNodeGroup')
                    EdgeDetectGroup.location=-550,200
                    EdgeDetectGroup.name="RT_EdgeDetectGroup"
                    EdgeDetectGroup.node_tree = bpy.data.node_groups.get('RT_Edge_From_NormalMap')
                    EdgeDetectGroup.inputs[1].default_value=0.35
                    overlay=nodes.new('ShaderNodeMixRGB')
                    overlay.name="RT_Overlay"
                    overlay.blend_type="MIX"
                    overlay.inputs[0].default_value=0.5
                    overlay.location=-50,200
                    links=mat.node_tree.links
                    nm_node=nodes.new("ShaderNodeNormalMap")
                    nm_node.name = "RT_NormalMap"
                    nm_node.location=-250,200
                    links.new(texture_node.outputs[0],EdgeDetectGroup.inputs[0])
                    links.new(EdgeDetectGroup.outputs[0],nm_node.inputs[1])
                    existingNormal=None
                    toConnect=None
                    for n in nodes:
                        if n.type=='BSDF_PRINCIPLED' and 'RT_PRINCIPLED' not in n.name:
                            for inp in n.inputs:
                                if inp.name=='Normal' and inp.is_linked:
                                    
                                    existingNormal=inp.links[0].from_socket
                                    links.new(existingNormal,overlay.inputs[2])
                                    toConnect=inp
                        # if n.bl_idname=="ShaderNodeTexImage":
                            
                        #     if hasattr(n,'image') and n.image is not None and any(x in n.image.name.lower() for x in self.NormalTags):
                        #         links.new(n.outputs[0],overlay.inputs[2])
                        #         overlay.location.x=n.location.x+200
                        #         overlay.location.y=n.location.y
                        #         existingNormal=n
                            #texture_node.location.x=n.location.x-200
                            #EdgeDetectGroup.location.x=n.location.x+100
                    # if existingNormal is not None:
                    #     if len(existingNormal.outputs[0].links)>0:
                    #         toConnect=existingNormal.outputs[0].links[0].to_socket
                    #         for link in existingNormal.outputs[0].links:
                    #             if link.to_node.bl_idname=="ShaderNodeNormalMap":
                    #                 nm_node=link.to_node
                                    
                    #                 toConnect=existingNormal.outputs[0].links[0].to_node.outputs[0].links[0].to_socket
                    # else:
                    #     overlay.inputs[0].default_value=0
                    links.new(nm_node.outputs[0],overlay.inputs[1])
                    if toConnect is not None:
                        links.new(overlay.outputs[0],toConnect)
                    else:
                        NormalSockets=[]
                        for n in nodes:
                            for s in n.inputs:
                                if s.name=="Normal" and not s.is_linked and 'RT_' not in n.name:
                                    
                                    NormalSockets.append(s)
                        for s in NormalSockets:
                            links.new(overlay.outputs[0],s)
            texture_node.select = True
            nodes.active = texture_node
            texture_node.image = img #Assign the image to the node
        engine=bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'CYCLES'
        samples=bpy.context.scene.cycles.samples
        bpy.context.scene.cycles.samples=context.scene.rt_tools.bevel_render_samples
        bpy.context.scene.cycles.device='GPU'
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.bake(type='NORMAL', save_mode='EXTERNAL')
        bpy.context.scene.render.engine=engine
        bpy.context.scene.cycles.samples=samples
        for mat in obj.data.materials:
            if mat:
                bevelOutputs=[]
                
                nodes = mat.node_tree.nodes
                links=mat.node_tree.links
                nmap=nodes.get("NMap")
                for link in links:
                    if link.from_node.type=="BEVEL":
                        bevelOutputs.append(link.from_socket.links)
                #for socket in set(bevelOutputs):
                    #for i in socket:
                        #links.new(nmap.outputs[0],i.to_socket)
                for n in nodes:
                    #print(n.bl_idname)
                    if n.type=="BEVEL":
                        #pass
                        nodes.remove(n)
        if bpy.data.is_saved:            
            filename = bpy.path.basename(bpy.data.filepath)
            filename = os.path.splitext(filename)[0]
            blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
            filepath = os.path.splitext(bpy.data.filepath)[0]  if not os.path.isdir(context.scene.projectInfo.textures_folder_path) else context.scene.projectInfo.textures_folder_path
            fname=obj.name + "_BevelMap"
            if not os.path.exists(filepath):
                os.mkdir(filepath)

            files = [file for file in os.listdir(filepath)
                    if file.startswith(blendname)]
            i=0
            name=obj.name + "_BevelMap"
            while(fname+".png" in files):
                fname = f"{name}_{i}"
                #print(fname)
                i+=1
            final_name = os.path.join(filepath, fname+".png")

            if not img:
                return "ERROR"

            img.save_render(final_name, scene=None)
        #img.save_render(filepath="D:\\Test\\"+obj.name + "_BevelMap.png")
            
        #In the last step, we are going to delete the nodes we created earlier
        for mat in obj.data.materials:
            if mat:
                for n in mat.node_tree.nodes:
                    if n.name == 'RT_Bevel_Output' or n.name=="RT_PRINCIPLED" or n.name=="RT_BEVEL":
                        mat.node_tree.nodes.remove(n)
                for node in mat.node_tree.nodes :
                        if node.type == 'OUTPUT_MATERIAL':
                            node.is_active_output = True
        #f self.ctrl:
        #    BakeEdgeMask(context)
        return {"FINISHED"}
    def invoke(self, context,event):
        #self.ctrl=event.ctrl
        if event.ctrl and event.shift:
            self.execute(context)
            BakeEdgeMask(context,worn=False)
            return {'FINISHED'}
        elif event.ctrl and event.alt:
            self.execute(context)
            BakeEdgeMask(context,worn=True)
            return {'FINISHED'}
            
        elif event.shift:
            BakeEdgeMask(context,worn=False)
            return {'FINISHED'}
        elif event.alt:
            BakeEdgeMask(context,worn=True)
            return {'FINISHED'}
        else:
            return self.execute(context)

class RTOOLS_OT_Multiply_Resolution(bpy.types.Operator):
    bl_idname = "rtools.multiplybakeresolution"
    bl_label = "Multiply"
    bl_description = "Multiply Resolution by 2\nCTRL+LMB:Divide Resolution by 2" 
    bl_options = {"REGISTER","UNDO"}
    def invoke(self,context, event):
        if event.ctrl:
            context.scene.rt_tools.texture_resolution=int(context.scene.rt_tools.texture_resolution/2)
        else:
            context.scene.rt_tools.texture_resolution*=2
        return {"FINISHED"}

def bakeEnum(context):
    bake_types=[]
    rt_tools=context.scene.rt_tools
    if rt_tools.bake_diffuse:
        bake_types.append("DIFFUSE")
    if rt_tools.bake_rough:
        bake_types.append("ROUGHNESS")
    if rt_tools.bake_metal:
        bake_types.append("METALLIC")
    if rt_tools.bake_glossy:
        bake_types.append("GLOSSY")
    if rt_tools.bake_normal:
        bake_types.append("NORMAL")
    
    if rt_tools.bake_emit:
        bake_types.append("EMIT")
    if rt_tools.bake_opacity:
        bake_types.append("TRANSMISSION")
    if rt_tools.bake_uv:
        bake_types.append("UV")
    if rt_tools.bake_environment:
        bake_types.append("ENVIRONMENT")
    
    if rt_tools.bake_height:
        bake_types.append("HEIGHT")
    if rt_tools.bake_id:
        bake_types.append("ID_Map")
    if rt_tools.bake_combined:
        bake_types.append("COMBINED")
    if rt_tools.bake_ao:
        bake_types.append("AO")
    return bake_types
def get_all_nodes_from_material(node_tree):
    groups=[]
    groups.extend(node_tree.nodes[:])
    for node in node_tree.nodes:
        if node.type=='GROUP':
            groups.extend(get_all_nodes_from_material(node.node_tree))
    return groups
def bake_texture(context,objs,bake_type,image):
        image_name = "_".join([a.name for a in objs]) + f"_{bake_type}_{context.scene.rt_tools.texture_resolution}"
        if image is None:            
            if image_name not in bpy.data.images.keys():
                
                img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
            else:
                #img=bpy.data.images[image_name]
                bpy.data.images.remove(bpy.data.images[image_name])
                img = bpy.data.images.new(image_name,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True,float_buffer=True)
        else:
            img=image
            img.name=image_name
        img.source='GENERATED'
        if bake_type=="NORMAL" or bake_type=='ROUGHNESS' or bake_type=="METALLIC" or bake_type=="SPECULAR" or bake_type=='AO':
            try:
                img.colorspace_settings.name='Non-Color'
            except Exception:
                
                try:
                    img.colorspace_settings.name='Generic Data'
                except Exception:
                    pass
                
            
            img.colorspace_settings.is_data=True
        node_trees=[]
        ogLinks=[]
        newLinks=[]
        default_metallic_values=[]
        default_roughness_values=[]
        #objs_to_operate=[a for a in context.selected_objects if a not in objs] if context.scene.render.bake.use_selected_to_active else objs
        if context.scene.render.bake.use_selected_to_active:
            for obj in [a for a in context.selected_objects if a not in objs]:
                for mat in obj.data.materials:
                    if mat:
                        mat.use_nodes = True 
                        nodes = mat.node_tree.nodes
                        
                        if bake_type=="DIFFUSE":
                            for n in get_all_nodes_from_material(mat.node_tree):
                                for inp in n.inputs:
                                    if "metal" in inp.name.lower():
                                        default_metallic_values.append((inp,inp.default_value))
                                        try:
                                            inp.default_value=0
                                        except:
                                            pass
                                        if inp.is_linked:
                                            for l in inp.links:
                                                ogLinks.append((inp.node.id_data,(l.from_socket,l.to_socket)))
                                                inp.node.id_data.links.remove(l)
                                            #newLinks.append((mat,mat.node_tree.links.new(n.inputs[metallic_input].links[0].from_socket,n.inputs[roughness_input])))
                        if bake_type=="METALLIC":
                            for n in get_all_nodes_from_material(mat.node_tree):
                                if n.type=='BSDF_PRINCIPLED':
                                    roughness_input=(9 if (3, 0, 0) <= bpy.app.version else 7)
                                    metallic_input=(6 if (3, 0, 0) <= bpy.app.version else 4)
                                    default_roughness_values.append((n.inputs[roughness_input],n.inputs[roughness_input].default_value))
                                    n.inputs[roughness_input].default_value=n.inputs[metallic_input].default_value
                                    if n.inputs[roughness_input].is_linked:
                                        ogLinks.append((n.id_data,(n.inputs[roughness_input].links[0].from_socket,n.inputs[roughness_input].links[0].to_socket)))
                                    if n.inputs[metallic_input].is_linked:
                                        new_link=n.id_data.links.new(n.inputs[metallic_input].links[0].from_socket,n.inputs[roughness_input])
                                        newLinks.append((n.id_data,new_link))
        for obj in objs:
            for mat in obj.data.materials:
                if mat:
                    mat.use_nodes = True 
                    nodes = mat.node_tree.nodes
                    links=mat.node_tree.links
                    node_trees.append(mat.node_tree)
                    if 'RT_Texture_Bake_Node' in [n.name for n in nodes]:
                        texture_node=nodes.get('RT_Texture_Bake_Node')
                    else:
                        texture_node =nodes.new('ShaderNodeTexImage')
                        texture_node.name = 'RT_Texture_Bake_Node'
                        texture_node.location=-900,-200
                    
                    if bake_type=="DIFFUSE":
                        for n in get_all_nodes_from_material(mat.node_tree):
                            for inp in n.inputs:
                                if "metal" in inp.name.lower():
                                    default_metallic_values.append((inp,inp.default_value))
                                    try:
                                        inp.default_value=0
                                    except:
                                        pass
                                    if inp.is_linked:
                                        for l in inp.links:
                                            ogLinks.append((inp.node.id_data,(l.from_socket,l.to_socket)))
                                            inp.node.id_data.links.remove(l)
                                        #newLinks.append((mat,mat.node_tree.links.new(n.inputs[metallic_input].links[0].from_socket,n.inputs[roughness_input])))
                    if bake_type=="METALLIC":
                        for n in get_all_nodes_from_material(mat.node_tree):
                            if n.type=='BSDF_PRINCIPLED':
                                roughness_input=(9 if (3, 0, 0) <= bpy.app.version else 7)
                                metallic_input=(6 if (3, 0, 0) <= bpy.app.version else 4)
                                default_roughness_values.append((n.inputs[roughness_input],n.inputs[roughness_input].default_value))
                                n.inputs[roughness_input].default_value=n.inputs[metallic_input].default_value
                                if n.inputs[roughness_input].is_linked:
                                    ogLinks.append((n.id_data,(n.inputs[roughness_input].links[0].from_socket,n.inputs[roughness_input].links[0].to_socket)))
                                if n.inputs[metallic_input].is_linked:
                                    new_link=n.id_data.links.new(n.inputs[metallic_input].links[0].from_socket,n.inputs[roughness_input])
                                    newLinks.append((n.id_data,new_link))
                    texture_node.select = True
                    nodes.active = texture_node
                    texture_node.image = img
        
        bake_type="EMIT" if bake_type=='HEIGHT' else bake_type
        bake_type="ROUGHNESS" if bake_type=='METALLIC' else bake_type
        bake_type="EMIT" if bake_type=='ID_Map' else bake_type
        bake_type="EMIT" if bake_type=='AO' else bake_type
         #Assign the image to the node
        engine=bpy.context.scene.render.engine
        use_direct=bpy.context.scene.render.bake.use_pass_direct
        use_indirect=bpy.context.scene.render.bake.use_pass_indirect
        use_clear=bpy.context.scene.render.bake.use_clear
        transform=context.scene.view_settings.view_transform
        look=context.scene.view_settings.look
        tile_size=context.scene.cycles.tile_size
        use_tile=context.scene.cycles.use_auto_tile
        denoise=context.scene.cycles.use_denoising
        
        # try:
        #     margin_type=bpy.context.scene.render.bake.margin_type
        #     bpy.context.scene.render.bake.margin_type='EXTEND'
        # except:
        #     pass
        if bake_type in {"DIFFUSE","GLOSSY",'TRANSMISSION'}:
            bpy.context.scene.render.bake.use_pass_direct=False
            bpy.context.scene.render.bake.use_pass_indirect=False
        else:
            bpy.context.scene.render.bake.use_pass_direct=True
            bpy.context.scene.render.bake.use_pass_indirect=True
        context.scene.cycles.use_auto_tile=True
        context.scene.cycles.tile_size=min(4096,context.scene.rt_tools.texture_resolution)
        bpy.context.scene.render.engine = 'CYCLES'
        samples=bpy.context.scene.cycles.samples
        # bpy.context.scene.cycles.samples=context.scene.rt_tools.bevel_render_samples if bake_type=='AO' else preferences().bake_samples
        bpy.context.scene.cycles.samples=preferences().bake_samples if bake_type!='COMBINED' else context.scene.rt_tools.bevel_render_samples
        bpy.context.scene.cycles.device='GPU'
        bpy.context.view_layer.objects.active = obj
        try:
            context.scene.view_settings.view_transform='Standard'
        except Exception:
            pass
        
        context.scene.view_settings.look='None'
        context.scene.cycles.use_denoising=False
        if len(objs)==1 and not context.scene.render.bake.use_selected_to_active:
            context.scene.render.bake.use_clear=True
        #if image:
            #bpy.context.scene.render.bake.use_clear=False
        if not context.scene.render.bake.use_selected_to_active:
            bpy.ops.object.bake({'selected_objects':objs,'acitve_object':objs[0],'editable_objects':objs,'selected_editable_objects':objs,'object':objs[0]},type=bake_type)
        else:
            bpy.ops.object.bake(type=bake_type)
        # try:
        #     bpy.context.scene.render.bake.margin_type=margin_type
        # except:
        #     pass
        context.scene.cycles.use_denoising=denoise
        context.scene.cycles.use_auto_tile=use_tile
        context.scene.cycles.tile_size=tile_size
        for tree,link in newLinks:
            try:
                link.id_data.links.remove(link)
            except:
                pass
        for tree,link in ogLinks:
            tree.links.new(link[0],link[1])
        for soc,value in default_metallic_values:
            soc.default_value=value
        for soc,value in default_roughness_values:
            soc.default_value=value
        if bpy.data.is_saved:            
            filename = bpy.path.basename(bpy.data.filepath)
            filename = os.path.splitext(filename)[0]
            blendname = bpy.path.basename(bpy.data.filepath).rpartition('.')[0]
            filepath = os.path.splitext(bpy.data.filepath)[0] if not os.path.isdir(context.scene.projectInfo.textures_folder_path) else context.scene.projectInfo.textures_folder_path
            fname=image_name
            if not os.path.exists(filepath):
                os.mkdir(filepath)

            files = [file for file in os.listdir(filepath)
                    if file.startswith(blendname)]
            i=0
            name=image_name
            while(fname+".png" in files):
                fname = f"{name}_{i}"
                #print(fname)
                i+=1
            final_name = os.path.join(filepath,"_".join([a.name for a in objs]), fname+".png")

            if not img:
                return "ERROR"

            img.save_render(final_name, scene=context.scene)
            bpy.data.images.remove(img)
            bpy.data.images.load(final_name)
        bpy.context.scene.render.engine=engine
        bpy.context.scene.cycles.samples=samples
        bpy.context.scene.render.bake.use_pass_direct=use_direct
        bpy.context.scene.render.bake.use_pass_indirect=use_indirect
        context.scene.view_settings.view_transform=transform
        context.scene.view_settings.look=look
        bpy.context.scene.render.bake.use_clear=use_clear
        return node_trees
def random_color():
    color=[random.random() for i in range(3)]
    r, g, b = color
    col = mathutils.Color((r, g, b))
    col.v=1
    col.s=1
    color=col
    return [color.r,color.g,color.b,1]
def hsv_to_rgb(color):
    col = mathutils.Color((0.0, 0.0, 0.0))
    col.hsv=color
    return [col.r,col.g,col.b,1]
class RTOOLS_OT_Bake_Texture_Maps(bpy.types.Operator):
    bl_idname = "rtools.baketextures"
    bl_label = "Bake Textures"
    bl_description = "Bake Textures"
    bl_options = {"REGISTER","UNDO"}
    
    @classmethod
    def poll(cls,context):
        return len(context.selected_objects)>0 and context.active_object is not None and context.active_object.type in {'MESH','CURVE','SURFACE','FONT'} and len(context.active_object.data.materials)>0
    def execute(self,context):
        init_images=bpy.data.images[:]
        bake_types=bakeEnum(context)
        st=time.time()
        bpy.context.scene.render.bake.margin=preferences().bake_margin
        if self.unwrap:
            bpy.ops.mesh.uv_texture_add()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            context.active_object.data.uv_layers[len(context.active_object.data.uv_layers)-1].active_render=True
            bpy.ops.uv.smart_project()
            bpy.ops.object.mode_set(mode='OBJECT')
        if len(bake_types)<=0:
            self.report({'WARNING'},'No Textures Selected To Bake!')
            if self.new_scene:
                bpy.data.scenes.remove(self.new_scene)
                context.window.scene=self.og_scene
            context.space_data.shading.type=self.shading_type
            return {'CANCELLED'}
        # for obj in context.selected_objects:
        #     if obj.type!='MESH':
        #         deselect(obj)
        mat_colors={}
        if context.scene.rt_tools.bake_id:
            for o in self.selected_objects:
                for m in o.data.materials:
                    if m:
                        mat_colors[m.name]=random_color()   
            mat_count=len(mat_colors)
            c=0
            step=0.1
            if len(mat_colors):
                step=1/mat_count
            for m in mat_colors.keys():
                mat_colors[m]=hsv_to_rgb([c,1,1])
                c=c+step
        #selected_objects=[obj for obj in context.selected_objects if obj.type=='MESH']
        selected_objects=self.selected_objects
        #print(selected_objects)
        if bpy.context.scene.render.bake.use_selected_to_active:
            context.scene.rt_tools.bake_all_to_one=False
            obj=self.active_object
            selected=self.selected
            for c in self.new_scene.collection.objects:
                self.new_scene.collection.objects.unlink(c)
            self.new_scene.collection.objects.link(obj)
            for se in selected:
                self.new_scene.collection.objects.link(se)
            node_trees=[]
            selected=selected[0]
            if len(obj.data.materials)>0 and len(bake_types)>0:

                for bake_type in bake_types:
                    if (bake_type=='AO' and not context.scene.rt_tools.ao_object_influence) or bake_type=='COMBINED':
                        context.window.scene=self.og_scene
                    else:
                        if self.new_scene:
                            context.window.scene=self.new_scene
                    
                    if bake_type=="HEIGHT":
                        for mat in selected.data.materials:
                            if mat:
                                nodes=mat.node_tree.nodes
                                links=mat.node_tree.links
                                output = nodes.new(type='ShaderNodeOutputMaterial')
                                output.name="RT_HeightMap_Output"
                                output.location=200,900
                                textCoord=nodes.new(type='ShaderNodeTexCoord')
                                textCoord.name="RT_TextCoord"
                                separateXYZ=nodes.new(type='ShaderNodeSeparateXYZ')
                                separateXYZ.name="RT_SepXYZ"
                                links.new(textCoord.outputs[0],separateXYZ.inputs[0])
                                links.new(separateXYZ.outputs[2],output.inputs[0])
                                for node in nodes :
                                    if node.type == 'OUTPUT_MATERIAL' :
                                        node.is_active_output = False
                                output.is_active_output = True
                    if bake_type=="AO":
                        for mat in selected.data.materials:
                            if mat:
                                nodes=mat.node_tree.nodes
                                links=mat.node_tree.links
                                output = nodes.new(type='ShaderNodeOutputMaterial')
                                output.name="RT_AO_Output"
                                output.location=200,900
                                textCoord=nodes.new(type='ShaderNodeAmbientOcclusion')
                                textCoord.name="RT_AO"
                                textCoord.samples=context.scene.rt_tools.bevel_render_samples
                                links.new(textCoord.outputs[0],output.inputs[0])
                                for node in nodes:
                                    if node.type == 'OUTPUT_MATERIAL' :
                                        node.is_active_output = False
                                output.is_active_output = True
                    if bake_type=='ID_Map':
                        for mat in selected.data.materials:
                            if mat:
                                nodes=mat.node_tree.nodes
                                links=mat.node_tree.links
                                output = nodes.new(type='ShaderNodeOutputMaterial')
                                output.name="RT_IDMap_Output"
                                output.location=200,900
                                color=nodes.new(type='ShaderNodeRGB')
                                color.name="RT_ID_Color"
                                color.outputs[0].default_value=mat_colors[mat.name] if not context.scene.rt_tools.use_mat_colors else mat.diffuse_color
                                links.new(color.outputs[0],output.inputs[0])
                                for node in nodes :
                                    if node.type == 'OUTPUT_MATERIAL' :
                                        node.is_active_output = False
                                output.is_active_output = True
                    node_trees=bake_texture(context,[obj,],bake_type,image=None)
                    if bake_type=="HEIGHT":
                        for mat in selected.data.materials:
                            if mat:
                                matNodes=mat.node_tree.nodes
                                for node in matNodes:
                                    if node.name in {"RT_HeightMap_Output","RT_TextCoord","RT_SepXYZ"}:
                                        matNodes.remove(node)
                                for node in matNodes :
                                    if node.type == 'OUTPUT_MATERIAL':
                                        node.is_active_output = True
                    if bake_type=="AO":
                        for mat in selected.data.materials:
                            if mat:
                                matNodes=mat.node_tree.nodes
                                for node in matNodes:
                                    if node.name in {"RT_AO_Output","RT_AO"}:
                                        matNodes.remove(node)
                                for node in matNodes :
                                    if node.type == 'OUTPUT_MATERIAL':
                                        node.is_active_output = True
                    if bake_type=="ID_Map":
                            for mat in selected.data.materials:
                                if mat:
                                    matNodes=mat.node_tree.nodes
                                    for node in matNodes:
                                        if node.name in {"RT_IDMap_Output","RT_ID_Color"}:
                                            matNodes.remove(node)
                                    for node in matNodes :
                                        if node.type == 'OUTPUT_MATERIAL':
                                            node.is_active_output = True
                for node_tree in node_trees:
                    if 'RT_Texture_Bake_Node' in node_tree.nodes.keys():
                        node_tree.nodes.remove(node_tree.nodes['RT_Texture_Bake_Node'])
        else:
            bpy.context.scene.render.bake.use_selected_to_active=False
            
            #print(selected_objects)
            for bake_type in bake_types:
                if (bake_type=='AO' and not context.scene.rt_tools.ao_object_influence) or bake_type=='COMBINED':
                    context.window.scene=self.og_scene
                else:
                    if self.new_scene:
                        context.window.scene=self.new_scene
                img=None
                if context.scene.rt_tools.bake_all_to_one:
                    img = bpy.data.images.new("_".join([a.name for a in context.selected_objects if a.type=='MESH'])+"_"+bake_type,context.scene.rt_tools.texture_resolution,context.scene.rt_tools.texture_resolution,alpha=True)
                    img.source='GENERATED'
                    objs=selected_objects
                    for c in self.new_scene.collection.objects:
                            self.new_scene.collection.objects.unlink(c)
                    for o in objs:  
                        self.new_scene.collection.objects.link(o)
                    for i,obj in enumerate(selected_objects):
                        if len(obj.data.materials)>0:
                        
                            if bake_type=="HEIGHT":
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_HeightMap_Output"
                                        output.location=200,900
                                        textCoord=nodes.new(type='ShaderNodeTexCoord')
                                        textCoord.name="RT_TextCoord"
                                        separateXYZ=nodes.new(type='ShaderNodeSeparateXYZ')
                                        separateXYZ.name="RT_SepXYZ"
                                        links.new(textCoord.outputs[0],separateXYZ.inputs[0])
                                        links.new(separateXYZ.outputs[2],output.inputs[0])
                                        for node in nodes :
                                            if node.type == 'OUTPUT_MATERIAL' :
                                                node.is_active_output = False
                                        output.is_active_output = True
                            if bake_type=="AO":
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_AO_Output"
                                        output.location=200,900
                                        textCoord=nodes.new(type='ShaderNodeAmbientOcclusion')
                                        textCoord.name="RT_AO"
                                        textCoord.samples=context.scene.rt_tools.bevel_render_samples
                                        links.new(textCoord.outputs[0],output.inputs[0])
                                        for node in nodes:
                                            if node.type == 'OUTPUT_MATERIAL' :
                                                node.is_active_output = False
                                        output.is_active_output = True
                            if bake_type=='ID_Map':
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_IDMap_Output"
                                        output.location=200,900
                                        color=nodes.new(type='ShaderNodeRGB')
                                        color.name="RT_ID_Color"
                                        color.outputs[0].default_value=mat_colors[mat.name] if not context.scene.rt_tools.use_mat_colors else mat.diffuse_color
                                        links.new(color.outputs[0],output.inputs[0])
                                        for node in nodes :
                                            if node.type == 'OUTPUT_MATERIAL' and node!=output:
                                                node.is_active_output = False
                                        output.is_active_output = True
                            #only_setup=i!=(len(selected_objects)-1) and context.scene.rt_tools.bake_all_to_one
                    node_trees=bake_texture(context,objs,bake_type,image=img)
                    for i,obj in enumerate(selected_objects):
                        if bake_type=="HEIGHT":
                                for mat in obj.data.materials:
                                    if mat:
                                        matNodes=mat.node_tree.nodes
                                        for node in matNodes:
                                            if node.name in {"RT_HeightMap_Output","RT_TextCoord","RT_SepXYZ"}:
                                                matNodes.remove(node)
                                        for node in matNodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = True
                        if bake_type=="AO":
                                for mat in obj.data.materials:
                                    if mat:
                                        matNodes=mat.node_tree.nodes
                                        for node in matNodes:
                                            if node.name in {"RT_AO_Output","RT_AO"}:
                                                matNodes.remove(node)
                                        for node in matNodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = True
                        if bake_type=="ID_Map":
                            for mat in obj.data.materials:
                                if mat:
                                    matNodes=mat.node_tree.nodes
                                    for node in matNodes:
                                        if node.name in {"RT_IDMap_Output","RT_ID_Color"}:
                                            matNodes.remove(node)
                                    for node in matNodes :
                                        if node.type == 'OUTPUT_MATERIAL':
                                            node.is_active_output = True

                    for node_tree in node_trees:
                        if 'RT_Texture_Bake_Node' in node_tree.nodes.keys():
                            node_tree.nodes.remove(node_tree.nodes['RT_Texture_Bake_Node'])
                else:

                    for i,obj in enumerate(selected_objects):
                        for c in self.new_scene.collection.objects:
                            self.new_scene.collection.objects.unlink(c)
                        
                        self.new_scene.collection.objects.link(obj)
                        if len(obj.data.materials)>0:
                            
                            if bake_type=="HEIGHT":
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_HeightMap_Output"
                                        output.location=200,900
                                        textCoord=nodes.new(type='ShaderNodeTexCoord')
                                        textCoord.name="RT_TextCoord"
                                        separateXYZ=nodes.new(type='ShaderNodeSeparateXYZ')
                                        separateXYZ.name="RT_SepXYZ"
                                        links.new(textCoord.outputs[0],separateXYZ.inputs[0])
                                        links.new(separateXYZ.outputs[2],output.inputs[0])
                                        for node in nodes :
                                            if node.type == 'OUTPUT_MATERIAL' :
                                                node.is_active_output = False
                                        output.is_active_output = True
                            if bake_type=="AO":
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_AO_Output"
                                        output.location=200,900
                                        textCoord=nodes.new(type='ShaderNodeAmbientOcclusion')
                                        textCoord.name="RT_AO"
                                        textCoord.samples=context.scene.rt_tools.bevel_render_samples
                                        links.new(textCoord.outputs[0],output.inputs[0])
                                        for node in nodes:
                                            if node.type == 'OUTPUT_MATERIAL' :
                                                node.is_active_output = False
                                        output.is_active_output = True
                            if bake_type=='ID_Map':
                                for mat in obj.data.materials:
                                    if mat:
                                        nodes=mat.node_tree.nodes
                                        links=mat.node_tree.links
                                        output = nodes.new(type='ShaderNodeOutputMaterial')
                                        output.name="RT_IDMap_Output"
                                        output.location=200,900
                                        color=nodes.new(type='ShaderNodeRGB')
                                        color.name="RT_ID_Color"
                                        color.outputs[0].default_value=mat_colors[mat.name] if not context.scene.rt_tools.use_mat_colors else mat.diffuse_color
                                        links.new(color.outputs[0],output.inputs[0])
                                        for node in nodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = False
                                        output.is_active_output = True
                                        
                                    
                            #only_setup=i!=(len(selected_objects)-1) and context.scene.rt_tools.bake_all_to_one
                            #deselect_all()
                            #select(obj)
                            node_trees=bake_texture(context,[obj,],bake_type,image=img)
                            if bake_type=="HEIGHT":
                                for mat in obj.data.materials:
                                    if mat:
                                        matNodes=mat.node_tree.nodes
                                        for node in matNodes:
                                            if node.name in {"RT_HeightMap_Output","RT_TextCoord","RT_SepXYZ"}:
                                                matNodes.remove(node)
                                        for node in matNodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = True
                            if bake_type=="AO":
                                for mat in obj.data.materials:
                                    if mat:
                                        matNodes=mat.node_tree.nodes
                                        for node in matNodes:
                                            if node.name in {"RT_AO_Output","RT_AO"}:
                                                matNodes.remove(node)
                                        for node in matNodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = True
                            if bake_type=="ID_Map":
                                for mat in obj.data.materials:
                                    if mat:
                                        matNodes=mat.node_tree.nodes
                                        for node in matNodes:
                                            if node.name in {"RT_IDMap_Output","RT_ID_Color"}:
                                                matNodes.remove(node)
                                        for node in matNodes :
                                            if node.type == 'OUTPUT_MATERIAL':
                                                node.is_active_output = True
                        for node_tree in node_trees:
                            if 'RT_Texture_Bake_Node' in node_tree.nodes.keys():
                                node_tree.nodes.remove(node_tree.nodes['RT_Texture_Bake_Node'])
        self.report({'INFO'},f"Bake Finished in {round(time.time()-st,2)} seconds")
        print("Bake Finished in",time.time()-st,"seconds")
        if context.scene.rt_tools.create_mats_for_bake:
            mats=setup_materials_from_images([image for image in bpy.data.images if image not in init_images])
            if context.scene.rt_tools.assign_materials:
                assign_mats_by_name(selected_objects,mats)
        if self.new_scene:
            bpy.data.scenes.remove(self.new_scene)
            context.window.scene=self.og_scene
        context.space_data.shading.type=self.shading_type
        return {"FINISHED"}
    def invoke(self, context, event):
        self.unwrap=event.ctrl
        self.active_object=context.active_object
        self.selected=None
        #if len(context.selected_objects)==2:
        self.selected=Diff(context.selected_objects,[self.active_object])
        self.new_scene=None
        self.og_scene=context.scene
        self.selected_objects=[obj for obj in context.selected_objects if obj.type=='MESH']
        scenes=bpy.data.scenes[:]
        bpy.ops.scene.new(type='EMPTY')
        self.new_scene=[a for a in bpy.data.scenes if a not in scenes]
        if self.new_scene:
            self.new_scene=self.new_scene[0]
        self.shading_type=context.space_data.shading.type
        context.space_data.shading.type='SOLID'
        return self.execute(context)
