
import bpy
from bpy.types import Panel
from fractions import Fraction
import random
from . utils import *


class RTOOLS_UL_BackUps_UIList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        ob = data

        obj = item.obj
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            if obj:
                row = layout.row()
                row.prop(obj, "name", text="", emboss=False)
                # if obj.hide_view:
                row.prop(obj, "hide_viewport", text="",
                            emboss=False, icon="RESTRICT_VIEW_OFF")
                # else:
                #     row.prop(obj, "hide_viewport", text="",
                #              emboss=False,icon="RESTRICT_VIEW_ON" if obj.hide_viewport else 'RESTRICT_VIEW_OFF')

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)


class RTOOLS_UL_SavedViews_UIList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):

        view = item

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            if view:
                row = layout.row()
                row.prop(view, "name", text="", emboss=False, icon_value=icon)

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)


class RTOOLS_UL_SavedRenderSettings_UIList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):

        rs = item
        if rs:
            row = layout.row()

            row.prop(rs, "name", text="", emboss=False,
                     icon='EVENT_E' if rs.engine_string == 'BLENDER_EEVEE' else 'EVENT_C')
            if rs.hide_view:
                row.prop(rs, "hide_view", text="", emboss=False,
                         icon="RESTRICT_RENDER_ON")
            else:
                row.prop(rs, "hide_view", text="", emboss=False,
                         icon="RESTRICT_RENDER_OFF")
# And now we can use this list everywhere in Blender. Here is a small example panel.


class BakePanel(bpy.types.Operator):
    bl_idname = "rtools.bake_panel"
    bl_label = "Call Bake Tools Popup"
    bl_description = "Call Bake Tools Popup"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        rt_tools = scene.rt_tools
        column = layout.column()

        column = column.column()
        column.label(text="Textures To Bake:")
        row = column.row()
        row = row.split(factor=0.5)
        col = row.column()
        col.prop(rt_tools, 'bake_diffuse', text="Diffuse")
        col.prop(rt_tools, 'bake_rough', text="Roughness")
        col.prop(rt_tools, 'bake_metal', text="Metallic")
        col.prop(rt_tools, 'bake_glossy', text="Glossy")
        col.prop(rt_tools, 'bake_normal', text="Normal")
        col.prop(rt_tools, 'bake_height', text="Height")
        col.prop(rt_tools, 'bake_id', text="ID Maps")
        col = row.column()
        row=col.row()
        row.prop(rt_tools, 'bake_ao', text="AO")
        if rt_tools.bake_ao:
            row.prop(rt_tools,'ao_object_influence')
        col.prop(rt_tools, 'bake_emit', text="Emission")
        col.prop(rt_tools, 'bake_opacity', text="Opacity")
        col.prop(rt_tools, 'bake_uv', text="UV")
        col.prop(rt_tools, 'bake_environment', text="Environment")

        # col=column
        col.prop(rt_tools, 'bake_combined', text="Combined")
        if rt_tools.bake_id:
            col.prop(rt_tools, 'use_mat_colors')
        col = column
        # if len([obj for obj in context.selected_objects if obj.type == 'MESH']) == 2:
        col.prop(bpy.context.scene.render.bake, 'use_selected_to_active')
        if bpy.context.scene.render.bake.use_selected_to_active:
            col.prop(bpy.context.scene.render.bake, 'cage_extrusion')
            col.prop(bpy.context.scene.render.bake, 'max_ray_distance')
        if len([obj for obj in context.selected_objects if obj.type == 'MESH']) > 1 and not bpy.context.scene.render.bake.use_selected_to_active:
            col.prop(context.scene.rt_tools, 'bake_all_to_one')
            if context.scene.rt_tools.bake_all_to_one:
                col.label(
                    text="Make sure all selected objects are properly UV", icon="ERROR")
                col.label(text="unwrapped on a single UV Layout")
        row=col.row(align=True)
        row.prop(rt_tools,'create_mats_for_bake')
        if rt_tools.create_mats_for_bake:
            row.prop(rt_tools,'assign_materials')
        col.prop(rt_tools, "bevel_render_samples", text="Samples (For AO/Bevel/Combined Bakes)")
        row = col.row()
        row = row.split(factor=0.85, align=True)

        row.prop(rt_tools, "texture_resolution", text="Resolution")
        row.operator('rtools.multiplybakeresolution', text="2X")
        col.operator("rtools.baketextures")
        row = col.row()
        row.label(text="Bevel Width")
        row.prop(rt_tools, "bevel_width", text="")
        col.operator("rtools.bakebevels", text="Bake Bevels")

    def invoke(self, context, event):
        # bpy.ops.wm.call_panel(name='OBJECT_PT_Bake_Tools')
        # return {'FINISHED'}
        return context.window_manager.invoke_popup(self)

    def execute(self, context):

        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}


class RTOOLS_OT_BackUps(bpy.types.Operator):
    bl_idname = "rtools.backup_panel"
    bl_label = "Call Backup Popup"
    bl_description = "Call Backup Popup"
    bl_options = {'REGISTER', 'UNDO'}
    # bl_property="name"
    name: bpy.props.StringProperty(default="")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        for i, ob in enumerate(obj.BackUps):
            if ob.name not in [o.name for o in bpy.data.objects]:
                obj.BackUps.remove(i)
        return bpy.ops.wm.call_panel(name='OBJECT_PT_BackUps_List')
        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}


class RTOOLS_OT_PT_Cutter(bpy.types.Panel):
    bl_label = "P-Cutter"
    bl_idname = "OBJECT_PT_P_CUTTER"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        rt_tools = context.scene.rt_tools
        layout.prop(rt_tools, 'default_shape')
        layout.prop(rt_tools, 'default_curve_type')
        layout.prop(rt_tools, 'keep_drawing')
        layout.prop(rt_tools, 'coplanar_faces')
        layout.prop(rt_tools, 'limited_dissolve')
        layout.prop(rt_tools, 'wiresimul_version_1')
        layout.prop(preferences(), 'use_only_active_object')
        layout.prop(preferences(), 'auto_hide_bools_after_drawing')
        layout.prop(preferences(),'apply_bools_slice_mod')
        layout.prop(preferences(), 'circle_resolution')
        layout.prop(preferences(), 'boolean_solidify_offset')
        layout.prop(preferences(), 'draw_solidify_offset')
        layout.operator('rtools.createbooleanvgroups')
        layout.operator('rtools.slidevertices')
        layout.operator('rtools.cleanbooleans')


class RTOOLS_PT_BackUps(bpy.types.Panel):
    bl_label = "Backups"
    bl_idname = "OBJECT_PT_BackUps_List"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        column = layout.column()
        scene = context.scene
        rt_tools = scene.rt_tools
        obj = context.active_object

        if obj is not None:
            column = column.split(factor=0.9)
            column.template_list("RTOOLS_UL_BackUps_UIList", "", obj, "BackUps",
                                 obj, "BackUpsIndex", item_dyntip_propname='time', sort_reverse=True)
            column = column.column(align=True)
            column.operator("rtools.refreshbackup",
                            text="", icon="FILE_REFRESH")
            column.separator()

            column.operator("rtools.addbackup", text="", icon="ADD")
            column.operator("rtools.deletebackup", text="", icon="REMOVE")
            column.separator()
            column.operator("rtools.replacebackup",
                            text="", icon="ARROW_LEFTRIGHT")
            column.separator()
            column.operator('rtools.normaltransfer', text="",
                            icon='MOD_DATA_TRANSFER')
            row = layout.row()
            row.prop(rt_tools, 'backup_name', text="")
            row = layout.row()
            row.operator("rtools.createbackup").name = rt_tools.backup_name


class RTOOLS_PT_Camera(Panel):
    bl_idname = "OBJECT_PT_RT_camera"
    bl_label = "Camera Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    
    bl_options = {'DEFAULT_CLOSED'}
    def draw(self, context):
        Ratios = ["21:9", "16:9", "2:1", "1:1"]
        ResButtons = ["1/2", "3/2", "2", "4"]
        Resolutions = ["720p", "1080p", "1440p", "2160p"]
        Annotations = {'720p': 'HD', '1080p': 'FHD', '1440p': '2K', '2160p': '4K'}
        Lenses = [18, 24, 35, 50, 85, 105]
        shutterspeeds = [1/500, 1/250, 1/125, 1 /
                        60, 1/30, 1/15, 1/8, 1, 2, 4, 8, 16, 32]
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools

        b = layout.box()
        r=b.row()
        r.label(text="Render Aspect Ratio")
        r.prop(context.space_data,'lock_camera')
        RatioColumns = b.grid_flow(row_major=True, columns=2)
        for ratio in Ratios:
            #row = column.row()
            RatioColumns.operator("rtools.ratio", text=ratio).Ratio = ratio
        column = b.column()
        row = column.row()
        row.operator("rtools.ratioswitch", text="Interactive Camera Adjust")
        row = column.row()
        row.label(text="Render Resolution")
        row = column.row(align=True)
        for res in ResButtons:
            row.operator("rtools.res", text=f"{res}x").Factor = res
        row = column.row(align=True)
        for res in Resolutions:
            row.operator("rtools.ratio",
                         text=f"{Annotations[res]}").Resolution = res
        row = column.row()
        row.label(text="Focal Length(mm)")
        row = column.row(align=True)
        for lens in Lenses:
            row.operator("rtools.cameralens", text=f"{lens}").lens = lens
        row = column.row()
        row.label(text="Shutter Speed")
        row = column.row(align=True)
        for i, shutter in enumerate(shutterspeeds):
            if i == round(len(shutterspeeds)/2):
                row = column.row(align=True)
            row.operator(
                "rtools.shutter", text=f"{str(Fraction(shutter).limit_denominator())}").shutter = shutter
        col = column.column()
        col.operator("rtools.addbackdrop", text="Add BackDrop")
        col.operator("rtools.addlights", text="Add Lights")
        col.operator("rtools.render_path", text="Set Render Path")
        col.operator("rtools.denoise", text="SetUp Denoiser")
        box = col.box()
        box.label(text="Create Camera Markers")
        box.prop(context.scene, 'frame_current')
        box.prop(context.scene, "camera", text="Active Camera")
        #box.label(text="Active Camera: "+context.scene.camera.name)
        for cam in [a for a in context.scene.objects if a.type == 'CAMERA']:
            row = box.row()
            row = row.split(factor=0.6, align=True)
            row.operator("rtools.changeactivecamera", text=cam.name,
                         icon='OUTLINER_DATA_CAMERA').camera = cam.name
            row.prop(cam.data, 'lens')
        column2 = col.split(factor=0.88)

        column2.template_list("RTOOLS_UL_SavedRenderSettings_UIList", "", scene, "RenderSettingsSaves",
                              scene, "activeRenderSettingsIndex", item_dyntip_propname='name', sort_reverse=False)

        column2 = column2.column(align=True)
        column2.label(text="")
        column2.operator("rtools.updaterenderset", text="", icon='SORT_DESC')
        column2.separator()
        column2.operator("rtools.saverendersettings", text="", icon="ADD")
        column2.operator("rtools.removerenderset", text="", icon="REMOVE")
        # column2.operator("rtools.renderall")
        col.prop(rt_tools, 'render_settings_name')
        # col.operator("rtools.loadrenderset")
        # col.operator("rtools.renderall")

        # col.operator("rtools.renderset")
        # col.operator("rtools.removerenderset")
        if len(context.scene.RenderSettingsSaves) > 0 and context.scene.activeRenderSettingsIndex < len(context.scene.RenderSettingsSaves) and context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex]:
            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "engine")
            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "camera")
            row = col.row()
            row = row.split(factor=0.3)
            row.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "clay_type")
            if context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex].clay_type:
                row.prop(
                    context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "clay_color", text="")
            row = col.row()
            row = row.split(factor=0.5)
            row.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "wire_type")
            if context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex].wire_type:
                row.prop(
                    context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "mix_render")

            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "res_x")
            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "res_y")
            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "world")
            col.prop(
                context.scene.RenderSettingsSaves[context.scene.activeRenderSettingsIndex], "film_transparent")
        if bpy.data.is_saved:
            col.prop(rt_tools, "auto_save", text="Auto Save Rendered Images")
        else:
            col.label(text="Save The Project To Use Auto Save")


class RTOOLS_OT_Bake(Panel):
    bl_idname = "OBJECT_PT_Bake_Tools"
    bl_label = "Bake Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        rt_tools = scene.rt_tools
        layout = layout.box()
        column = layout.column()

        column = column.column()
        column.label(text="Textures To Bake:")
        row = column.row()
        row = row.split(factor=0.5)
        col = row.column()
        col.prop(rt_tools, 'bake_diffuse', text="Diffuse")
        col.prop(rt_tools, 'bake_rough', text="Roughness")
        col.prop(rt_tools, 'bake_metal', text="Metallic")
        col.prop(rt_tools, 'bake_glossy', text="Glossy")
        col.prop(rt_tools, 'bake_normal', text="Normal")
        col.prop(rt_tools, 'bake_height', text="Height")
        col.prop(rt_tools, 'bake_id', text="ID Maps")
        col = row.column()
        row=col.row()
        row= row.split(factor=0.4)
        row.prop(rt_tools, 'bake_ao', text="AO")
        if rt_tools.bake_ao:
            row.prop(rt_tools,'ao_object_influence')
        col.prop(rt_tools, 'bake_emit', text="Emission")
        col.prop(rt_tools, 'bake_opacity', text="Opacity")
        col.prop(rt_tools, 'bake_uv', text="UV")
        col.prop(rt_tools, 'bake_environment', text="Environment")

        # col=column
        col.prop(rt_tools, 'bake_combined', text="Combined")
        if rt_tools.bake_id:
            col.prop(rt_tools, 'use_mat_colors')
        col = column
        #if len([obj for obj in context.selected_objects if obj.type == 'MESH']) == 2:
        col.prop(bpy.context.scene.render.bake, 'use_selected_to_active')
        if bpy.context.scene.render.bake.use_selected_to_active:
            col.prop(bpy.context.scene.render.bake, 'cage_extrusion')
            col.prop(bpy.context.scene.render.bake, 'max_ray_distance')
        if len([obj for obj in context.selected_objects if obj.type == 'MESH']) > 1 and not bpy.context.scene.render.bake.use_selected_to_active:
            col.prop(context.scene.rt_tools, 'bake_all_to_one')
            if context.scene.rt_tools.bake_all_to_one:
                col.label(
                    text="Make sure all selected objects are properly UV", icon="ERROR")
                col.label(text="unwrapped on a single UV Layout")
        row=col.row(align=True)
        row.prop(rt_tools,'create_mats_for_bake')
        if rt_tools.create_mats_for_bake:
            row.prop(rt_tools,'assign_materials')
        col.prop(rt_tools, "bevel_render_samples", text="Samples (For AO/Bevel/Combined Bakes)")
        row = col.row()
        row = row.split(factor=0.85, align=True)

        row.prop(rt_tools, "texture_resolution", text="Resolution")
        row.operator('rtools.multiplybakeresolution', text="2X")
        col.operator("rtools.baketextures")
        row = col.row()
        row.label(text="Bevel Width")
        row.prop(rt_tools, "bevel_width", text="")
        col.operator("rtools.bakebevels", text="Bake Bevels")


class RTOOLS_Material(Panel):
    bl_idname = "OBJECT_PT_Material_Tools"
    bl_label = "Material Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools

        b = layout.box()
        b.label(text="SetUp PBR Materials")
        column = b.column()
        col = column.column()
        col.prop(rt_tools, "MaterialFolderPath", text='')
        col.operator("rtools.setup_materials")
        col.operator("rtools.import_material")
        col.operator("rtools.makeemissive")
        #col.operator("rtools.call_material_menu",text="Change Material")
        col.operator("rtools.adduvgrid")
        col.operator("rtools.removeuvgrid")
        # col.prop(rt_tools,"hexwidget")
        if bpy.data.node_groups.get('RT_ClayGroup') is not None:
            row = col.row()
            row.prop(bpy.data.node_groups.get(
                'RT_ClayGroup').nodes['RT_Diffuse'].inputs[0], 'default_value', text='Clay Color')
        col.operator("rtools.addclaymaterial", text="Add Clay Material")
        col.operator("rtools.removeclaymaterial", text="Remove Clay Material")


class RTOOLS_Curve_Tools(Panel):
    bl_idname = "OBJECT_PT_Curve_Tools"
    bl_label = "Curve Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools

        b = layout.box()
        column = b.column()
        col = column.column()

        if context.active_object is not None and len(context.selected_objects) > 0:
            if context.active_object.modifiers.get("RT_ST_Displace") is not None:
                col.prop(
                    context.active_object.modifiers['RT_ST_Displace'], "strength", text="Radius")
            if context.active_object.modifiers.get("RT_ST_Screw") is not None:
                col.prop(
                    context.active_object.modifiers['RT_ST_Screw'], "steps", text="Vertices")
            if context.active_object.modifiers.get("RT_Spiral_Screw") is not None:
                col.prop(
                    context.active_object.modifiers['RT_Spiral_Screw'], "screw_offset", text="Width")
            if context.active_object.modifiers.get("RT_Spiral_Screw_2") is not None:
                col.prop(
                    context.active_object.modifiers['RT_Spiral_Screw_2'], "angle", text="Twist")
                col.prop(
                    context.active_object.modifiers['RT_Spiral_Screw_2'], "steps", text="Resolution")
                col.prop(
                    context.active_object.modifiers['RT_Spiral_Screw_2'], "screw_offset", text="Length")
            if context.active_object.modifiers.get("RT_ST_Screw_2") is not None:
                col.prop(
                    context.active_object.modifiers['RT_ST_Screw_2'], "steps", text="Resolution")
            if context.active_object.modifiers.get("RT_WIRE_LENGTH") is not None:
                col.prop(
                    context.active_object.modifiers['RT_WIRE_LENGTH'], "screw_offset", text="Length")
                col.prop(
                    context.active_object.modifiers['RT_WIRE_LENGTH'], "steps", text="Resolution")

            if context.active_object.modifiers.get("RT_WIRE_COUNT") is not None:
                col.prop(context.active_object, 'wire_type', text='Type')

                if context.active_object.wire_type == 'Parallel':
                    # col.prop(context.active_object.modifiers['RT_WIRE_COUNT'],"relative_offset_displace",text="Offset")
                    col.prop(context.active_object, 'wire_axis')
                    col.prop(context.active_object,
                             "wire_parallel_offset", text="Offset")
                else:
                    if context.active_object.modifiers.get("RT_WIRE_RADIUS") is not None:
                        col.prop(
                            context.active_object.modifiers['RT_WIRE_RADIUS'], "strength", text="Radius")
                col.prop(
                    context.active_object.modifiers['RT_WIRE_COUNT'], "count", text="Count")
            if context.active_object.modifiers.get("RT_STRAND_RADIUS") is not None:
                col.prop(
                    context.active_object.modifiers['RT_STRAND_RADIUS'], "strength", text="Strand Radius")

            if context.active_object.modifiers.get("RT_WIRE_TWIST") is not None:
                col.prop(
                    context.active_object.modifiers['RT_WIRE_TWIST'], "angle", text="Twist")
            if context.active_object.modifiers.get("RT_ST_Screw_2") is not None:
                col.prop(
                    context.active_object.modifiers['RT_ST_Screw_2'], "screw_offset", text="Length")
            if context.active_object.modifiers.get("RT_ST_Solidify") is not None:
                col.prop(
                    context.active_object.modifiers['RT_ST_Solidify'], "thickness", text="Thickness")
            if context.active_object.modifiers.get("RT_CurveDisplace") is not None:
                col.prop(
                    context.active_object.modifiers['RT_CurveDisplace'], "strength", text="Position")
                col.prop(
                    context.active_object.modifiers['RT_CurveDisplace'], "direction", text="Axis")

            if context.active_object.modifiers.get("RT_POC_ARRAY") is not None:
                col.prop(
                    context.active_object.modifiers['RT_POC_ARRAY'], "fit_type", text="Fit Type")
                if context.active_object.modifiers.get("RT_POC_ARRAY").fit_type == 'FIXED_COUNT':
                    col.prop(
                        context.active_object.modifiers['RT_POC_ARRAY'], "count", text="Count")
                elif context.active_object.modifiers.get("RT_POC_ARRAY").fit_type == 'FIT_LENGTH':
                    col.prop(
                        context.active_object.modifiers['RT_POC_ARRAY'], "fit_length", text="Length")
                else:
                    col.prop(
                        context.active_object.modifiers['RT_POC_ARRAY'], "curve", text="Curve")
                col.prop(
                    context.active_object.modifiers['RT_POC_ARRAY'], 'constant_offset_displace', text='Offset')
            if context.active_object.modifiers.get("RT_POC_Curve") is not None:
                col.prop(
                    context.active_object.modifiers['RT_POC_Curve'], "deform_axis", text="Deform Axis")
                if context.active_object.modifiers.get("RT_POC_Curve").object is not None and "RT_CableHook_1" in context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.keys():
                    col.prop(rt_tools, 'hook1_scale',
                             text="Endpoint 1 Tension")
                if context.active_object.modifiers.get("RT_POC_Curve").object is not None and "RT_CableHook_2" in context.active_object.modifiers.get("RT_POC_Curve").object.modifiers.keys():
                    col.prop(rt_tools, 'hook2_scale',
                             text="Endpoint 2 Tension")

            if context.active_object is not None and context.active_object.type == 'CURVE':
                col.prop(context.active_object.data, 'bevel_depth')
            for c in context.active_object.children:
                if c.type == 'CURVE':
                    col.operator(
                        "rtools.editchildcurve", text=f"Edit {c.name} Curve", icon='OUTLINER_OB_CURVE').name = c.name
        col.operator("rtools.putoncurve")
        col.operator("rtools.createcable")
        col.operator("rtools.createmultiplewires")
        col.operator("rtools.drawcurve")
        col.operator("rtools.edgetocurve")
        col.operator("rtools.capsoncurve")
        col.operator("rtools.refitcaps")
        # col.operator("rtools.curveadjust")
        if context.scene.rt_tools.wiresimul_version_1:
            col.operator("rtools.simulatewire")
        else:
            col.operator("rtools.simulatewire2")

        if context.active_object is not None and "RT_CableHook_1" in context.active_object.modifiers.keys():
            col.prop(rt_tools, 'hook1_scale', text="Endpoint 1 Tension")
        if context.active_object is not None and "RT_CableHook_2" in context.active_object.modifiers.keys():
            col.prop(rt_tools, 'hook2_scale', text="Endpoint 2 Tension")
        if context.active_object is not None and context.active_object.type == 'CURVE':
            col.prop(context.active_object.data, 'bevel_depth')


class RT_Particle_Tools(Panel):
    bl_idname = "OBJECT_PT_Particletools"
    bl_label = "Particle Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools
        b = layout.box()
        column = b.column()
        col = column.column()
        if context.active_object is not None:
            col.operator("rtools.instanceatverts")
            col.operator("rtools.instanceatfaces")
            col.operator("rtools.convertandapply")
        if context.active_object is not None and len([p for p in context.active_object.particle_systems if 'RT_PS_Face_Instanced' in p.name]) > 0:
            row = col.row(align=True)
            row.operator("rtools.iafsubdivide").unsubdivide = False
            row.operator("rtools.iafsubdivide",
                         text='Un-Subdivide').unsubdivide = True
            col.operator("rtools.updateiaf")
            settings = context.active_object.particle_systems[
                context.active_object.particle_systems.active_index].settings
            col.prop(settings, 'particle_size')
            col.prop(settings, 'size_random')
            col.prop(settings, 'rotation_mode')
            col.prop(settings, 'rotation_factor_random')
            col.prop(settings, 'phase_factor')
            col.prop(settings, 'phase_factor_random')
        # for i,a in enumerate(context.scene.saved_views):
         #   col.operator("rtools.setview").index=i
        #col.prop(rt_tools,'boid_count',text='Boid Count')
        col.template_list("RTOOLS_UL_SavedViews_UIList", "", scene, "boidSystems",
                          scene, "active_boid_system", item_dyntip_propname='name', sort_reverse=False)
        col.operator("rtools.createboids", text="Boids!")
        if len(context.scene.boidSystems) > 0:
            #settings = context.active_object.particle_systems[context.active_object.particle_systems.active_index].settings
            # print(context.scene.boidSystems[context.scene.active_boid_system].particle_system)
            settings = context.scene.boidSystems[context.scene.active_boid_system].particle_system
            col.operator('rtools.addinstanceobject')
            col.operator('rtools.addcollisionobject')
            row = col.row(align=True)
            row.prop(settings.boids, 'use_flight', text='Fly', toggle=True)
            row.prop(settings.boids, 'use_land', text='Land', toggle=True)
            col.prop(settings, 'particle_size', text='Scale')
            col.prop(settings, 'count', text='Boid Count')
            col.prop(
                context.scene.boidSystems[context.scene.active_boid_system], 'emission_rate', text='Emission Rate')
            if settings.boids.use_flight:
                col.prop(settings.boids, 'air_personal_space',
                         text='Separation')
            if settings.boids.use_land:
                col.prop(settings.boids, 'land_personal_space',
                         text='Land Separation')
            col.prop(
                settings.boids.active_boid_state.rules["Goal"], 'object', text="Target")
            col.prop(rt_tools, 'show_advanced_boid_options',
                     text='Advanced Options', icon='TRIA_DOWN')
            if rt_tools.show_advanced_boid_options:
                col.prop(settings.boids, 'use_climb',
                         text='Climb', toggle=True)
                col.prop(settings, 'size_random', text='Scale Randomness')

                if settings.boids.use_flight:
                    col.prop(settings.boids, 'air_speed_max')
                    col.prop(settings.boids, 'air_speed_min')
                    col.prop(settings.boids, 'air_acc_max')

                if settings.boids.use_land:
                    col.prop(settings.boids, 'land_speed_max')
                    col.prop(settings.boids, 'land_jump_speed')
                    col.prop(settings.boids, 'land_acc_max')

                col.prop(settings.boids, 'bank')
                col.prop(settings.boids, 'pitch')
                col.prop(settings.boids, 'height')


class RTOOLS_OT_Asset_Tools(Panel):
    bl_idname = "OBJECT_PT_Asset_Tools"
    bl_label = "Asset Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.operator("rtools.genthumbs")


class RTOOLS_OT_RTools(Panel):
    bl_idname = "OBJECT_PT_Rtools"
    bl_label = "Random Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools

        b = layout.box()
        column = b.column()
        col = column.column()
        # column2=col.split(factor=0.88)

        #column2.template_list("RTOOLS_UL_SavedViews_UIList", "", scene, "saved_views",scene, "SavedViewsIndex",item_dyntip_propname='name',sort_reverse=False)

        # column2=column2.column(align=True)
        # column2.label(text="")
        # column2.operator("rtools.saveview",text="",icon="ADD")
        # column2.operator("rtools.removesavedview",text="",icon="REMOVE")

        # column2.separator()
        # col.prop(rt_tools,'view_name',text="Name")

        # row=col.row(align=True)
        # col.operator("rtools.projectfromsavedview")
        # row.operator("rtools.saveview")
        # row=col.row(align=True)
        # row.operator("rtools.setview",icon='PLAY_REVERSE',text="").next=-1
        # row.operator("rtools.setview").next=0
        # row.operator("rtools.setview",icon='PLAY',text="").next=1

        col.operator("rtools.quick_mirror", text="Mirror")
        #col.operator("rtools.cleanbooleans", text="Boolean Cleanup")
        col.operator("rtools.create_asset")
        col.operator("rtools.import_asset")
        col.operator("rtools.create_modifier_preset_menu")
        # col.operator("rtools.invoke_modifier_menu")
        col.operator("rtools.matchvisiblity")
        col.operator("rtools.origintogeometrywithmodifiers")
        col.operator("rtools.groupit")
        row = column.row()
        if context.active_object is not None:
            row.prop(context.active_object, 'isGround',
                     text="Mark As Ground", icon="MOD_OCEAN")

            row = column.row()
        row = row.split(factor=0.35, align=True)
        op = row.operator("rtools.snapit", text="Snap!")
        op.location = 0
        op.onlyGround = False
        op = row.operator("rtools.snapit", text="Snap To Ground!")
        op.location = 0
        op.onlyGround = True
        row = column.row()
        # row.prop(rt_tools,'remesh_scale',text="Scale")
        row.operator("rtools.remeshdice")
        row.operator("rtools.planerremesh").size = 0.75
        op = col.operator("rtools.preparecloth")
        col.operator("rtools.createcloth")
        col = column.column()
        col.operator("rtools.slice")
        # col.prop(rt_tools,'hittingObject')
        # col.operator("rtools.break",text="Break!")

        col.operator("rtools.dice")
        col.operator("rtools.addtube")
        col.operator("rtools.addlattice")
        # col.operator("rtools.test")
        # col.operator("rtools.grid")
        # col.operator("rtools.meshdeform")
        # col.operator("rtools.spinninty")
        col.operator("rtools.objectbrush")
        # col.operator("rtools.booltest")
        col.operator("rtools.addplanetoboolean")
        col.operator("rtools.converttoplane")
        col.operator("rtools.taper")
        col.operator("rtools.extractfaces")
        col.operator("rtools.circlearray")
        col.operator("rtools.circulararray")
        col.operator("rtools.convertandapply")
        # col.operator("rtools.wireframerender")
        col.operator("rtools.aligntoface")
        col.operator("rtools.insetshrink")
        col.operator("rtools.alignnormaltoaxis")
        col.operator("rtools.origintobottom")
        # col.operator("rtools.recalllastcutter")
        col.operator("rtools.selectchildren")
        # col.operator("rtools.syncmodifiers")
        # col.operator("rtools.import_presets")
        """box=col.box()
        box.label(text='Create Custom Macros')
        box.prop(rt_tools,'custom_operator_name')
        box.prop(rt_tools,'custom_operator_operations')
        for l in context.scene.OperatorLines:
            box.prop(l,'line',text="")
            for arg in l.arguments:
                box.prop(arg,'value',text=arg.name)
        row=box.row(align=True)
        row.operator("rtools.deleteinfopanel")
        row.operator("rtools.copyinfopanel")
        box.operator("rtools.createop")
        box=col.box()
        box.operator_context = "INVOKE_DEFAULT"
        box.label(text='Custom Macros')
        for o in custom_operators:
            box.operator(o.bl_idname)"""


class RTOOLS_OT_NodeEditor(Panel):
    bl_idname = "OBJECT_PT_RT_NodeEditor"
    bl_label = "Node Tools"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "RanTools"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools
        layout.prop(rt_tools, 'nodeToAppend', text="")
        layout.operator("rtools.addnode")
        layout.operator("rtools.addnodetoqam")
        layout.prop(rt_tools, 'socketsToAdd')
        layout.operator("rtools.addsocketstoqam")
        layout.operator("rtools.makeitflow")
        # box=layout.box()
        #box.operator_context = "INVOKE_DEFAULT"
        #box.label(text='Custom Macros')
        # for o in custom_operators:
        #    box.operator(o.bl_idname)
def panel_opened(self, context):
    if context.scene.opened_panels.find(self.name)>=0:
        t=context.scene.opened_panels[context.scene.opened_panels.find(self.name)]
    else:
        t=context.scene.opened_panels.add()
        t.name=self.name
    t.opened_panels=""
    for i in range(1,39):
        if getattr(self,f"show_panel_{i}",False):
            t.opened_panels=t.opened_panels+","+str(i) if t.opened_panels else str(i)
def get_current_context(context):
    if context.mode=='OBJECT':
        return "objectmode"
    elif context.mode =='EDIT_MESH':
        return "mesh_edit"
    elif context.mode =='EDIT_CURVE':
        return "curve_edit"
    elif context.mode =='EDIT_SURFACE':
        return "surface_edit"
    elif context.mode =='EDIT_TEXT':
        return "text_edit"
    elif context.mode =='SCULPT':
        return "sculpt_mode"
    elif context.mode =='EDIT_ARMATURE':
        return "armature_edit"
    elif context.mode =='EDIT_METABALL':
        return "mball_edit"
    elif context.mode =='EDIT_LATTICE':
        return "lattice_edit"
    elif context.mode =='POSE':
        return "posemode"
    elif context.mode =='PAINT_WEIGHT':
        return "weightpaint"
    elif context.mode =='PAINT_VERTEX':
        return "vertexpaint"
    elif context.mode =='PAINT_TEXTURE':
        return "imagepaint"
    elif context.mode =='PARTICLE':
        return "particlemode"
    else:
        return "None1"


class RTOOLS_OT_Light(Panel):
    bl_idname = "OBJECT_PT_RT_Lights"
    bl_label = "Light Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RanTools"
    factors = ["0.5", "1.5", "2", "4"]
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rt_tools = scene.rt_tools

        b = layout.box()
        column = b.column()
        row = column.row()
        row = row.split(factor=0.85)
        row.prop(rt_tools, "light_group_name", text="", expand=True)

        row.operator("rtools.createlightgroup", text="", icon="ADD")
        row = column.row()
        row.label(text="Lights", icon="LIGHT")

        if len(context.scene.lightGroups) > 0:
            box2 = column
        for i, lightGroup in enumerate(context.scene.lightGroups):

            box = box2.box()
            row = box.row()
            # row=row.split(factor=0.5)

            if context.active_object is not None and context.active_object.type == "LIGHT" and context.active_object.name in [light.name for light in lightGroup.lights]:

                row.label(text=lightGroup.name, icon="KEYTYPE_EXTREME_VEC")
            else:
                row.label(text=lightGroup.name, icon="LIGHT")
            row = row.row(align=True)
            if not context.scene.lightGroups[i].solo:
                row.operator("rtools.sololightgroup",
                             icon="SOLO_OFF", text="").index = i
            else:
                row.operator("rtools.unsololightgroup",
                             icon="SOLO_ON", text="").index = i

            row.operator("rtools.selectlightgroup",
                         icon="RESTRICT_SELECT_OFF", text="").index = i

            row.operator("rtools.removelightgroup",
                         icon="X", text="").index = i
            row.operator("rtools.deletelightgroup",
                         icon="TRASH", text="").index = i
            row = box.row()
            row.prop(lightGroup, "name", text="Name")
            for j, light in enumerate(lightGroup.lights):
                row = box.row()
                if context.active_object is not None and context.active_object.type == "LIGHT" and context.active_object.name == light.name:
                    if light.light is not None:
                        row.label(text=light.name,
                                  icon='KEYTYPE_MOVING_HOLD_VEC')
                elif light.name in [o.name for o in context.selected_objects]:
                    if light.light is not None:
                        row.label(text=light.name,
                                  icon='KEYTYPE_BREAKDOWN_VEC')
                else:
                    if light.light is not None:
                        row.label(text=light.name, icon='LIGHT_' +
                                  light.light.data.type.upper())
                if light.light is not None:
                    lightName = light.name
                    light = light.light.data
                    row = row.split(factor=0.2)
                    row.prop(light, "color", text="")
                    row = row.split(factor=0.7)
                    row.prop(light, 'energy', text="")
                    remove = row.operator(
                        "rtools.removelightfromgroup", icon="REMOVE", text="", emboss=False)
                    remove.indexLight = j
                    remove.index = i
                    row.operator("rtools.selectlight", icon="RESTRICT_SELECT_OFF",
                                 text="", emboss=False).light = lightName

            row = box.row()
            row = row.split(factor=1)
            row.operator("rtools.addlighttogroup",
                         icon="ADD", text="").index = i
            row = box.row(align=True)
            for f in self.factors:
                power = row.operator(
                    "rtools.multiplylightenergy", text=f"{f}X")
                power.factor = eval(f)
                power.index = i
            row = box.row()
            op = row.operator("rtools.randomiselightcolor", icon="COLOR")
            op.seed = random.randint(1, 1000)
            op.index = i
            row.operator("rtools.copyfromclipboard",
                         text="", icon='PASTEDOWN').index = i
            row = box.row()

        lightsInGroups = []
        for lightGroup in context.scene.lightGroups:

            for light in lightGroup.lights:
                lightsInGroups.append(light.light)
        lightsNotInGroups = [
            l for l in bpy.context.scene.objects if l.type == 'LIGHT' and l not in lightsInGroups]
        if len(lightsNotInGroups) > 0:
            box = column.box()
        for light in lightsNotInGroups:
            row = box.row()
            lightname = light.name
            if context.active_object is not None and context.active_object.type == "LIGHT" and context.active_object.name == light.name:
                row.label(text=light.name, icon='KEYTYPE_MOVING_HOLD_VEC')
            elif light.name in [o.name for o in context.selected_objects]:
                row.label(text=light.name, icon='KEYTYPE_BREAKDOWN_VEC')
            else:
                row.label(text=light.name, icon='LIGHT_' +
                          light.data.type.upper())
            light = light.data
            row = row.split(factor=0.3)
            row.prop(light, "color", text="")
            row = row.split(factor=0.8)
            row.prop(light, 'energy', text="")

            row.operator("rtools.selectlight", icon="RESTRICT_SELECT_OFF",
                         text="", emboss=False).light = lightname
        if scene.world and 'Background' in scene.world.node_tree.nodes.keys():
            row = b.row()
            row.label(text='World', icon='WORLD')
            row.prop(
                scene.world.node_tree.nodes['Background'].inputs[1], 'default_value', text="")
