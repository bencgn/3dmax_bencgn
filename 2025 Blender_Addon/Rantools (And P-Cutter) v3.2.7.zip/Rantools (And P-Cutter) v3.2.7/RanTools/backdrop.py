import bpy
from . utils import * 
import colorsys
import os
#import mathutils
class RTOOLS_OT_addBackDrop(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.addbackdrop"
    bl_label = "Add BackDrop"
    bl_description = "Add a BackDrop"
    bl_options = {'REGISTER', 'UNDO'}
    backdrops=[]
    currentBD=None
    lastBD=None
    active=None
    AlignToggle=True
    alignedTo=None
    i=0
    
    #for a in range(1,7):
    #    backdrops.append(f"BackDrop_{a}")
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
    def draw_callback_px(self,context):
        draw_Text(context,0,preferences().font_size,text=[f"A: Change Alignment({self.alignedTo})",f"BackDrop: {self.lastBD.name}"])    
    @classmethod
    def poll(cls, context):
        if context.active_object is not None:
            return context.active_object.mode == 'OBJECT'
    def execute(self, context):
        context.area.tag_redraw()
        if self.lastBD is not None:
            for slot in self.lastBD.material_slots:
                bpy.data.materials.remove(slot.material)

            delete_collection(self.lastBD.users_collection[0],delete_objects=True)
        file_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","BackDrops.blend","Collection")
        
        bpy.ops.wm.append(
            directory=file_path,
            filename=self.currentBD,autoselect=True
        )
        obj=bpy.data.objects[self.currentBD]
        obj.name="BD_"+obj.name
        obj.users_collection[0].name="BackDrops_temp"
        active_object=self.active
        if active_object.type!='MESH' and active_object.type!='CURVE' :
            obj.scale=active_object.scale*3
        else:
            obj.scale=(active_object.dimensions.x*3,active_object.dimensions.x*3,active_object.dimensions.x*3)
        obj.location=(active_object.location.x,active_object.location.y,self.lowest_pt)
        if bpy.context.scene.camera is not None:
            if not self.AlignToggle:
                self.alignedTo="Camera"
                obj.rotation_euler[2] = bpy.context.scene.camera.rotation_euler[2]
            else:
                self.alignedTo="Object"
                obj.rotation_euler[2] = active_object.rotation_euler[2]
        else:
            self.alignedTo="Object"
            obj.rotation_euler[2] = active_object.rotation_euler[2]
        self.lastBD=obj
        return {'FINISHED'}  
    def modal(self, context,event):
        rt_tools=context.scene.rt_tools
        if (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i=(self.i+1)%len(self.backdrops)
            self.currentBD=self.backdrops[self.i]
            self.execute(context)
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.i=(self.i-1)%len(self.backdrops)
            self.currentBD=self.backdrops[self.i]
            self.execute(context)
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            lastCol=self.lastBD.users_collection[0]
            
            self.lastBD.users_collection[0].objects.unlink(self.lastBD)
            delete_collection(lastCol,delete_objects=True)
            bd_col=get_collection("BackDrops")
            link_to_collection(self.lastBD,bd_col)
            select(self.lastBD,active=True)
            self.remove_drawHandler(context)
            bpy.ops.rtools.changebevel('INVOKE_DEFAULT')
            #rt_tools.backDropId+=1
            #print(f"Saving State: {rt_tools.choice}")
            return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC':
            self.remove_drawHandler(context)
            delete_collection(self.lastBD.users_collection[0],delete_objects=True)
            return {'CANCELLED'}
        elif event.type == 'A' and event.value=="PRESS":
            self.AlignToggle=not self.AlignToggle
            if self.AlignToggle:
                self.alignedTo="Object"
                self.lastBD.rotation_euler[2]=self.active.rotation_euler[2]
            if not self.AlignToggle:
                if bpy.context.scene.camera is not None:
                    self.alignedTo="Camera"
                    self.lastBD.rotation_euler[2] = bpy.context.scene.camera.rotation_euler[2]
                else:
                    self.report({'ERROR'},"No Active Camera Found")
        else:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}    
    def invoke(self, context,event):
        if "backdrop" in context.active_object.name.lower() and "backdrop" in context.active_object.users_collection[0].name.lower():
            bpy.ops.rtools.changebevel('INVOKE_DEFAULT')
            return {'FINISHED'}
        self.backdrops=[]
        with bpy.data.libraries.load(os.path.join(os.path.dirname(os.path.abspath(__file__)),"Assets","BackDrops.blend")) as (data_from, _):
            for col in data_from.collections:
                self.backdrops.append(col)
        self.backdrops.reverse()
        enable_abs(context)
        active_object=bpy.context.active_object
        self.active=active_object
        if active_object is None:
            self.report({'ERROR'},"No Active Object Found!")
            return{'CANCELLED'}
        
        self.lastBD=None
        self.AlignToggle=False
        self.alignedTo="Camera"
        rt_tools=context.scene.rt_tools
        #self.backdrops=[f'BackDrop_1',f'BackDrop_2','BackDrop_3']
        self.currentBD=self.backdrops[0]
        
        dup=active_object.evaluated_get(context.evaluated_depsgraph_get())
        if active_object.type!='MESH' and active_object.type!='CURVE' :
            self.lowest_pt=active_object.location.z
        else:
            if active_object.type=='CURVE':
                dup=duplicate_object(active_object,col=None)
                convert_to_mesh(dup)
                self.lowest_pt = min([(dup.matrix_world @ v.co).z for v in dup.data.vertices])
                delete_object(dup)
            else:
                self.lowest_pt = min([(dup.matrix_world @ v.co).z for v in dup.data.vertices])
        
        select(active_object,active=True)
        self.execute(context)
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        return{'RUNNING_MODAL'}  
    
class RTOOLS_OT_updateBevel(bpy.types.Operator):
    # Add Light Intensity Global
    bl_idname = "rtools.changebevel"
    bl_label = "Change Bevel Properties"
    bl_description = "Bevel Properties"
    bl_options = {'REGISTER', 'UNDO'}
    obj=None
    first=True
    initX=0
    initWidth=0
    prevSegment=5
    drawHandler=None
    speed=100
    colorToggle=False
    RoughnessToggle=False
    MetalToggle=False
    width=None
    material=None
    def add_drawHandler(self,context):
        self.drawHandler=bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px,(context,),"WINDOW","POST_PIXEL")
    def remove_drawHandler(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler,"WINDOW")
        context.area.tag_redraw()
    def execute(self, context):

        return {'FINISHED'}  
    def modal(self, context,event):
        
        if event.type == 'LEFT_SHIFT':
            
            if event.value == 'PRESS':
                self.speed=1000
            elif event.value == 'RELEASE':
                self.speed=100    
            self.width=self.obj.modifiers['Bevel'].width
            self.initX=event.mouse_x
        elif event.type == 'LEFT_CTRL':
            if event.value == 'PRESS':
                self.speed=30
            elif event.value == 'RELEASE':
                self.speed=100    
            self.width=self.obj.modifiers['Bevel'].width
            self.initX=event.mouse_x
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        elif event.type == 'C':
            if event.value=='PRESS':
                self.width=self.obj.modifiers['Bevel'].width
                self.initX=event.mouse_x
                self.MetalToggle=False
                self.RoughnessToggle=False
                self.colorToggle=not self.colorToggle
        elif event.type == 'R':
            if event.value=='PRESS':
                self.width=self.obj.modifiers['Bevel'].width
                self.initX=event.mouse_x
                self.MetalToggle=False
                self.colorToggle=False
                self.RoughnessToggle=not self.RoughnessToggle
        elif event.type == 'M':
            if event.value=='PRESS':
                self.width=self.obj.modifiers['Bevel'].width
                self.initX=event.mouse_x
                self.colorToggle=False
                self.RoughnessToggle=False
                self.MetalToggle=not self.MetalToggle
        elif (event.type=="WHEELUPMOUSE" or ((event.type=='UP_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            
            self.obj.modifiers['Bevel'].segments+=1
            context.area.tag_redraw()
            
        elif (event.type=="WHEELDOWNMOUSE" or ((event.type=='DOWN_ARROW' and event.value=='PRESS') if preferences().use_up_down_keys else False)):
            self.obj.modifiers['Bevel'].segments-=1
            context.area.tag_redraw()
        elif event.type == 'MOUSEMOVE':

            if self.colorToggle and self.material and self.bsdf:
                    hsvval=[0,0.2,1]
                    hsvval[0]=clamp(abs(event.mouse_x)/context.region.width,0,1)
                    hsvval[1]=clamp(abs(event.mouse_y)/context.region.height,0,1)                        
                    rgb=colorsys.hsv_to_rgb(hsvval[0],hsvval[1],hsvval[2])
                    self.bsdf.inputs[0].default_value=rgb[0],rgb[1],rgb[2],1
            elif self.MetalToggle and self.material and self.bsdf:
                    self.bsdf.inputs[4].default_value=clamp(abs(event.mouse_x)/context.region.width,0,1)           
            elif self.RoughnessToggle and self.material and self.bsdf:
                    self.bsdf.inputs[7].default_value=clamp(abs(event.mouse_x)/context.region.width,0,1)
                        
            else:            
                self.obj.modifiers['Bevel'].width=max(0.01,self.width - (self.initX-event.mouse_x)/self.speed)
            context.area.tag_redraw()
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                
                self.remove_drawHandler(context)
                return {'FINISHED'}
        elif event.type == 'RIGHTMOUSE' or event.type=='ESC':
            self.remove_drawHandler(context)
            self.obj.modifiers['Bevel'].segments=self.prevSegment
            self.obj.modifiers['Bevel'].width=self.initWidth
            return {'CANCELLED'}
        else:
            return {'PASS_THROUGH'}
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}    
    def invoke(self, context,event):
        
        self.obj=bpy.context.active_object
        if self.obj.modifiers.get('Bevel') is None:
            mod=self.obj.modifiers.new(name='Bevel',type='BEVEL')
            mod.width=0.5
            mod.segments=5
        self.prevSegment=self.obj.modifiers['Bevel'].segments
        self.initX=event.mouse_x 
        self.initWidth=self.obj.modifiers['Bevel'].width
        self.width=self.initWidth
        self.material=None
        self.bsdf=None
        for slot in self.obj.material_slots:
            if slot.name.startswith("BackDrop"):
                self.material=slot.material
                self.bsdf=self.material.node_tree.nodes.get('Principled BSDF')
        context.window_manager.modal_handler_add(self)
        self.add_drawHandler(context)
        context.area.tag_redraw()
        return{'RUNNING_MODAL'} 
    def draw_callback_px(self,context):
        if self.material:
            if self.colorToggle and self.material.node_tree:
                #col=mathutils.Color(self.material.node_tree.nodes.get('Principled BSDF').inputs[0].default_value[:-1])
                
                hsv=colorsys.rgb_to_hsv(self.material.node_tree.nodes.get('Principled BSDF').inputs[0].default_value[0],self.material.node_tree.nodes.get('Principled BSDF').inputs[0].default_value[1],self.material.node_tree.nodes.get('Principled BSDF').inputs[0].default_value[2])
                draw_Text(context,0,preferences().font_size,text=["X-axis : Hue","Y-axis : Saturation",f"Hue: {round(hsv[0],2)}",f"Saturation: {round(hsv[1],2)}","PRESS C to Go Back To Bevel Adjust","PRESS R and M to adjust Roughness and Metallic"],alignH="LEFT")
                #draw_Text(context,0,30,text=["X-axis : Hue","Y-axis : Saturation",f"Hue: {round(col.h,2)}",f"Saturation: {round(col.s,2)}","PRESS C to Go Back To Bevel Adjust","PRESS R and M to adjust Roughness and Metallic"],alignH="LEFT")
            elif self.MetalToggle:
                draw_Text(context,0,preferences().font_size,text=["X-axis : Metallic",f"Metallic: {round(self.material.node_tree.nodes.get('Principled BSDF').inputs[4].default_value,2)}","PRESS M to Go Back To Bevel Adjust","PRESS C and R to adjust Color and Roughness"],alignH="LEFT")
            elif self.RoughnessToggle:
                draw_Text(context,0,preferences().font_size,text=["X-axis : Roughness",f"Roughness: {round(self.material.node_tree.nodes.get('Principled BSDF').inputs[7].default_value,2)}","PRESS R to Go Back To Bevel Adjust","PRESS C and M to adjust Color and Mettalic"],alignH="LEFT")
            else:
                draw_Text(context,0,preferences().font_size,text=[f"C: Color",f"R: Roughness",f"M: Metallic",f"Bevel Segments: {self.obj.modifiers['Bevel'].segments}",f"Bevel Width: {round((self.obj.modifiers['Bevel'].width),2)}"],alignH="LEFT")
