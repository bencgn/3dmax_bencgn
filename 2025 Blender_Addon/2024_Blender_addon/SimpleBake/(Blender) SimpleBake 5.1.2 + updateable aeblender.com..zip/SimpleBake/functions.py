import urllib.request
from pathlib import Path
import shutil
import bpy
import os
import base64
import sys
import tempfile
from . import material_setup
#Global variables
psocketname = {
    "diffuse": "Base Color",
    "metalness": "Metallic",
    "roughness": "Roughness",
    "normal": "Normal",
    "transparency": "Transmission",
    "transparencyroughness": "Transmission Roughness",
    "clearcoat": "Clearcoat",
    "clearcoatroughness": "Clearcoat Roughness",
    "specular": "Specular",
    "alpha": "Alpha",
    "sss": "Subsurface",
    "ssscol": "Subsurface Color"
    }

def printmsg(msg):
    print(f"SIMPLEBAKE: {msg}")


def does_object_have_bakes(obj):
    
    for img in bpy.data.images:
        try:
            if f"SB_{obj.name}_{bpy.context.scene.batchName}_" in img["SB"]:
                return True
                     
        except KeyError:
            pass
                    
    return False
                    

def gen_image_name(obj_name, bakemode, baketype):
    
    #First, let's get the format string we are working with
    
    prefs = bpy.context.preferences.addons[__package__].preferences
    image_name = prefs.img_name_format
    
    #"%OBJ%_%BATCH%_%BAKETYPE%"
    
    #The easy ones
    image_name = image_name.replace("%OBJ%", obj_name)
    image_name = image_name.replace("%BATCH%", bpy.context.scene.batchName)
    
    #Bake mode
    image_name = image_name.replace("%BAKEMODE%", bakemode)
    
    #The hard ones
    if baketype == "diffuse":
        image_name = image_name.replace("%BAKETYPE%", prefs.diffuse_alias)
    
    elif baketype == "metalness":
        image_name = image_name.replace("%BAKETYPE%", prefs.metal_alias)      

    elif baketype == "roughness":
        image_name = image_name.replace("%BAKETYPE%", prefs.roughness_alias)      

    elif baketype == "normal":
        image_name = image_name.replace("%BAKETYPE%", prefs.normal_alias)      

    elif baketype == "transparency":
        image_name = image_name.replace("%BAKETYPE%", prefs.transmission_alias)      

    elif baketype == "transparencyroughness":
        image_name = image_name.replace("%BAKETYPE%", prefs.transmissionrough_alias)      

    elif baketype == "clearcoat":
        image_name = image_name.replace("%BAKETYPE%", prefs.clearcoat_alias)      

    elif baketype == "clearcoatroughness":
        image_name = image_name.replace("%BAKETYPE%", prefs.clearcoatrough_alias)      

    elif baketype == "emission":
        image_name = image_name.replace("%BAKETYPE%", prefs.emission_alias)   

    elif baketype == "specular":
        image_name = image_name.replace("%BAKETYPE%", prefs.specular_alias)      

    elif baketype == "alpha":
        image_name = image_name.replace("%BAKETYPE%", prefs.alpha_alias)      
    
    elif baketype == "ambientocclusion":
        image_name = image_name.replace("%BAKETYPE%", prefs.ao_alias)      
    elif baketype == "ColID":
        image_name = image_name.replace("%BAKETYPE%", prefs.colid_alias)      
    elif baketype == "curvature":
        image_name = image_name.replace("%BAKETYPE%", prefs.curvature_alias)      
    elif baketype == "thickness":
        image_name = image_name.replace("%BAKETYPE%", prefs.thickness_alias)      
    elif baketype == "VertexCols":
        image_name = image_name.replace("%BAKETYPE%", prefs.vertexcol_alias)      
        
    elif baketype == "sss":
        image_name = image_name.replace("%BAKETYPE%", prefs.sss_alias)      
    elif baketype == "ssscol":
        image_name = image_name.replace("%BAKETYPE%", prefs.ssscol_alias)      
    
    else:
        image_name = image_name.replace("%BAKETYPE%", baketype)
    
    return image_name

def removeDisconnectedNodes(nodetree):
    nodes = nodetree.nodes
    
    #Loop through nodes
    repeat = False
    for node in nodes: 
        if node.type == "BSDF_PRINCIPLED" and len(node.outputs[0].links) == 0:
            #Not a player, delete node
            nodes.remove(node)
            repeat = True
        elif node.type == "EMISSION" and len(node.outputs[0].links) == 0:
            #Not a player, delete node
            nodes.remove(node)
            repeat = True
        elif node.type == "MIX_SHADER" and len(node.outputs[0].links) == 0:
            #Not a player, delete node
            nodes.remove(node)
            repeat = True   
    
    #If we removed any nodes, we need to do this again
    if repeat:
        removeDisconnectedNodes(nodetree)
            
def backupMaterial(mat):
    dup = mat.copy()
    dup.name = mat.name + "_SimpleBake"

def restoreAllMaterials():
    #Not efficient but, if we are going to do things this way, we need to loop over every object in the scene 
    dellist = []
    for obj in bpy.data.objects:
        for slot in obj.material_slots:
            origname = slot.name
            
            #Try to set to the corresponding material that was the backup
            try:
                slot.material = bpy.data.materials[origname + "_SimpleBake"]
                
                #If not already on our list, log the original material (that we messed with) for mass deletion
                if origname not in dellist:
                    dellist.append(origname)
                
            except KeyError:
                #Not been backed up yet. Must not have processed an object with that material yet
                pass
                
    #Delete the unused materials
    for matname in dellist:
        bpy.data.materials.remove(bpy.data.materials[matname])
            
    #Rename all materials to the original name, leaving us where we started
    for mat in bpy.data.materials:
        mat.name = mat.name.replace("_SimpleBake", "")

def install_addon_update():
    
    try:
        #Current ver URL
        current_ver_url = base64.b64decode("aHR0cDovL3d3dy50b29oZXkuY28udWsvU2ltcGxlQmFrZS9TaW1wbGVCYWtlX0N1cnJlbnQuemlw").decode("utf-8")
        current_ver_zip_name = "SimpleBake_Curent.zip"
        addon_dir_name =  "SimpleBake"
    
        import zipfile #only needed here
    
        #Get the path where the addons are kept
        addons_path = Path(bpy.utils.script_path_user())
        addons_path = addons_path / "addons"
    
        #Make our current directory the addons directory
        os.chdir(str(addons_path))
    
        #Download new SimbleBake_Current.zip to addons folder
        printmsg("Starting download")
        urllib.request.urlretrieve(current_ver_url, current_ver_zip_name)
        current_ver_zip_name = "SimpleBake_Curent.zip"
        printmsg("Download complete")
        
        #Delete current SimpleBake folder
        addon_dir = addons_path / addon_dir_name
        shutil.rmtree(str(addon_dir)) 
    
        #Unzip
        current_ver_zip = zipfile.ZipFile(current_ver_zip_name, "r")
        current_ver_zip.extractall()
        current_ver_zip.close()
    
        #Delete the zip file we downlaoded
        downloaded_zip = addons_path / current_ver_zip_name
        downloaded_zip.unlink()
        
        return [True]
        
    except Exception as e:
        return [False, e]

def isBlendSaved():
    path = bpy.data.filepath
    if(path=="/" or path==""):
        #Not saved
        return False
    else:
        return True

def create_Images(imgname, bakemode, tag="SB_"):
    printmsg(f"Creating image {imgname}")
    
    #Get the image height and width from the interface
    IMGHEIGHT = bpy.context.scene.imgheight
    IMGWIDTH = bpy.context.scene.imgwidth
    
    #If it already exists, remove it.
    if(imgname in bpy.data.images):
        bpy.data.images.remove(bpy.data.images[imgname])
        
    #Either way, create the new image
    alpha = bpy.context.scene.useAlpha
    
    if bakemode == "normal":
        image = bpy.data.images.new(imgname, IMGWIDTH, IMGHEIGHT, alpha=alpha, is_data=True)
    else:
        #if bpy.context.scene.everything32bitfloat:
            #floatval = True
        #else:
            #floatval = False
        #image = bpy.data.images.new(imgname, IMGWIDTH, IMGHEIGHT, alpha=alpha, float_buffer=floatval)
        image = bpy.data.images.new(imgname, IMGWIDTH, IMGHEIGHT, alpha=alpha)
        
    
    if bakemode == "cyclesbake":
        image.colorspace_settings.name = bpy.context.scene.cyclescolspace
    elif bakemode != "diffuse":
        image.colorspace_settings.name = "Non-Color"
    
    #Tag it with the custom property
    image["SB"] = tag
    
    

def deselectAllNodes(nodes):
    for node in nodes:
        node.select = False
    

def findSocketConnectedtoP(pnode, thisbake):
    #Get socket name for this bake mode
    socketname = psocketname[thisbake]
    
    #Get socket of the pnode
    socket = pnode.inputs[socketname]
    fromsocket = socket.links[0].from_socket
    
    #Return the socket connected to the pnode
    return fromsocket

def createdummynodes(nodetree, thisbake):
    #Loop through pnodes
    nodes = nodetree.nodes
    
    for node in nodes:
        if node.type == "BSDF_PRINCIPLED":
            pnode = node
            #Get socket name for this bake mode
            socketname = psocketname[thisbake]
    
            #Get socket of the pnode
            psocket = pnode.inputs[socketname]
    
            #If it has something plugged in, we can leave it here
            if(len(psocket.links) > 0):
                continue

            #Get value of the unconnected socket
            val = psocket.default_value
    
            #If this is base col or ssscol, add an RGB node and set it's value to that of the socket
            if(socketname == "Base Color" or socketname == "Subsurface Color"):
                rgb = nodetree.nodes.new("ShaderNodeRGB")
                rgb.outputs[0].default_value = val
                rgb.label = "SimpleBake"
                nodetree.links.new(rgb.outputs[0], psocket)

            #If this is anything else, use a value node
            else:
                vnode = nodetree.nodes.new("ShaderNodeValue")
                vnode.outputs[0].default_value = val
                vnode.label = "SimpleBake"
                nodetree.links.new(vnode.outputs[0], psocket)

def bakeoperation(thisbake):

    if(thisbake == "cyclesbake"):
        #If we are doing an old fashioned cycles bake, do that and then exit
        printmsg(f"Beginning bake based on Cycles settings: {bpy.context.scene.cycles.bake_type}")
        bpy.ops.object.bake(type=bpy.context.scene.cycles.bake_type)
        return True

    printmsg(f"Beginning bake for {thisbake}")
    
    #For some reason, we must use clear to bake with alpha. Makes it incompatible with merged bakes, where we cannot clear
    if bpy.context.scene.mergedBake:
        use_clear = False
    else:
        use_clear = True
    
    if(thisbake != "normal"):
        bpy.ops.object.bake(type="EMIT", save_mode="INTERNAL", use_clear=use_clear)
    else:
        bpy.ops.object.bake(type="NORMAL", save_mode="INTERNAL", use_clear=use_clear)
    
def applyobjectscale(obj):
    #Take a record of selection
    objects = bpy.context.selected_objects
    activeobj = bpy.context.active_object
    
    selectOnlyThis(obj)
    bpy.ops.object.transform_apply(scale=True)
    
    #Restore selection
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = activeobj
    return True


def startingChecks(objects, bakemode):
    
    messages = []
    
    #Universal - no condition
    if(bpy.context.scene.render.engine  != "CYCLES"):
        messages.append("ERROR: Not in Cycles")
        
    if(bpy.context.mode != "OBJECT"):
        messages.append("ERROR: Not in object mode")
        
        
    for obj in objects:
        if obj.name != cleanFileName(obj.name) and bpy.context.scene.saveExternal:
            messages.append(f"ERROR: You are trying to save external images, but object with name \"{obj.name}\" contains invalid characters for saving externally.")
            
    
    #PBR Bake Checks - No S2A
    if bakemode == "pbrbake" and not bpy.context.scene.selected_s2a:
        
        for obj in objects:
            #Is it mesh?
            if obj.type != "MESH":
                messages.append(f"ERROR: Object {obj.name} is not mesh")
                #Must continue here - other checks will throw exceptions
                continue
            
            #Are UVs OK?
            if bpy.context.scene.newUVoption == False and len(obj.data.uv_layers) == 0:
                messages.append(f"ERROR: Object {obj.name} has no UVs, and you aren't generating new ones")
                continue
        
            #Are materials OK?
            if not checkObjectValidMaterialConfig(obj):
                messages.append(f"ERROR: Object {obj.name} has no materials or empty slots")
                continue
    
    
    #PBR Bake - S2A
    if bakemode == "pbrbake" and bpy.context.scene.selected_s2a:
        
        #Is everything that is selected mesh?
        for obj in objects:
            if obj.type != "MESH":
                messages.append(f"ERROR: Object {obj.name} is not mesh")
        
        #We only care about the target object
        obj = bpy.context.scene.targetobj
        
        if len(messages) >0:
            #If the above generate an error, don't do any of the other checks
            pass

        #Do we have a target object?
        elif bpy.context.scene.targetobj == None:
            messages.append("ERROR: You are trying to bake to a target object with PBR Bake, but you have not selected one in the SimpleBake panel")

        #Have we got more selected than just the target object?
        elif len(bpy.context.selected_objects) == 1 and bpy.context.selected_objects[0] == obj:
            messages.append("ERROR: You are trying to bake to a target object with PBR Bake, but the only object you have selected is your target")
        
        #Is the target mesh?
        elif obj.type != "MESH":
            messages.append(f"ERROR: Object {obj.name} (the target object you specified in the SimpleBake panel) is not mesh")
        
        #Are UVs OK?
        elif bpy.context.scene.newUVoption == False and len(obj.data.uv_layers) == 0:
            messages.append(f"ERROR: Object {obj.name} has no UVs, and you aren't generating new ones")
        
        #Are materials OK?
        elif not checkObjectValidMaterialConfig(obj):
            messages.append(f"ERROR: Object {obj.name} has no materials or empty slots")
                
    
    #Cycles Bake - No S2A
    if bakemode == "cyclesbake" and not bpy.context.scene.cycles_s2a:
        
        for obj in objects:
            #Is it mesh?
            if obj.type != "MESH":
                messages.append(f"ERROR: Object {obj.name} is not mesh")
                #Must continue here - other checks will throw exceptions
                continue
            
            #Are UVs OK?
            if not bpy.context.scene.tex_per_mat:
                if bpy.context.scene.newUVoption == False and len(obj.data.uv_layers) == 0:
                    messages.append(f"ERROR: Object {obj.name} has no UVs, and you aren't generating new ones")
                    continue
            else:
                if bpy.context.scene.expand_mat_uvs == False and len(obj.data.uv_layers) == 0:
                    messages.append(f"ERROR: Object {obj.name} has no UVs, and you aren't generating new ones")
                    continue
                
        
            #Are materials OK?
            if not checkObjectValidMaterialConfig(obj):
                messages.append(f"ERROR: Object {obj.name} has no materials or empty slots")
                continue    
    
    
    #Cycles Bake - S2A
    if bakemode == "cyclesbake" and bpy.context.scene.cycles_s2a:
        
        #Is everything that is selected mesh?
        for obj in objects:
            if obj.type != "MESH":
                messages.append(f"ERROR: Object {obj.name} is not mesh")
                
        #We only care about the target object
        obj = bpy.context.active_object
        
        if len(messages) >0:
            #If the above generate an error, don't do any of the other checks
            pass
        
        #Do we actually have an active object?
        elif bpy.context.active_object == None:
            messages.append(f"ERROR: You are trying to bake selected to active with CyclesBake, but there is no active object in the viewport")
    
        #Have we got more selected than just the target object?
        elif len(bpy.context.selected_objects) == 1 and bpy.context.selected_objects[0] == obj:
            messages.append("ERROR: You are trying to bake selected to active with CyclesBake, but the only object you have selected is your active (target) object")
    
        #Are UVs OK?
        elif bpy.context.scene.newUVoption == False and len(obj.data.uv_layers) == 0:
            messages.append(f"ERROR: Object {obj.name} has no UVs, and you aren't generating new ones")
    
        #Are materials OK?
        elif not checkObjectValidMaterialConfig(obj):
            messages.append(f"ERROR: Object {obj.name} has no materials or empty slots")
    
    
    #Specials Bake
    if bakemode == "specials":
        if bpy.context.scene.selected_col_vertex:
            for obj in objects:
                if len(obj.data.vertex_colors) == 0:
                    messages.append("You are trying to bake the active vertex colours, but one or more of your objects don't have vertex colours")
    
    #Sketchfab upload
    if bakemode == "sfupload":
        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__package__].preferences
        apikey = addon_prefs.apikey
        if apikey == "":
            messages.append("ERROR: Sketchfab API key needed. Set your API key in Blender user preferences under addons, SimpleBake. Get your API key from Sketchfab.com")
        
   
    
    
    #Let's report back
    if len(messages) != 0:
        ShowMessageBox(messages, "Errors occured", "ERROR")
        return [False, ""]
    else:
        #If we get here then everything looks good
        return [True, "OK"]
    
     #CAGE OBJECT BROKEN? CHECK IF NOT NONE AND, IF NOT, FLIP THE SWITCH TO USE CAGE
    
    
    
    
    #------------------------------------------
    
    """                
        
        #Check at least one object is selected
        if len(bpy.context.selected_objects) < 1:
            messages.append("ERROR: You must have at least one object selected")
            #return [False, "You must have at least one object selected"]
            
        return [True, "OK"]
            
    
    #---------Do the pbr s2a checks first as one will add a material if needed    
    if bakemode == "pbrbake" and bpy.context.scene.selected_s2a == True:
        if bpy.context.scene.targetobj == "":
            messages.append("ERROR: You are trying to bake to a target object with PBR Bake, but you have not selected one in the SimpleBake panel")
            #return [False, "You are trying to bake to a target object with PBR Bake, but you have not selected one in the SimpleBake panel"]
        
        obj = bpy.context.scene.targetobj
        
        #Just in case
        obj.hide_viewport = False
        obj.hide_render = False
        
        if obj.type != "MESH":
            messages.append("ERROR: Your target object is not mesh")
            #return [False, "Your target object is not mesh"]
        if not checkObjectValidMaterialConfig(obj):
            mat = bpy.data.materials.new(name="SimpleBakeTargetPlaceHolder")
            mat.use_nodes = True
            if obj.data.materials:
                # assign to 1st material slot
                obj.data.materials[0] = mat
            else:
                # no slots
                obj.data.materials.append(mat)
                
        if len(obj.data.uv_layers) == 0 and bpy.context.scene.newUVoption == False:
            messages.append(f"ERROR: Your target object ({obj.name}) has no UVs (and you aren't generating new ones)")
            #return [False, "Your target object has no UVs (and you aren't generating new ones)"]
        if len(bpy.context.selected_objects) == 1 and bpy.context.selected_objects[0] == obj:
            messages.append("ERROR: You are trying to bake to a target object with PBR Bake, but the only object you have selected is the target")
            #return [False, "You are trying to bake to a target object with PBR Bake, but the only object you have selected is the target"]
        if obj.scale.x != 1.0 or obj.scale.y != 1.0 or obj.scale.z != 1.0:
            #Silently fix
            applyobjectscale(obj)

    #-------------------------------------------
    
    
    if(bpy.context.scene.render.engine  != "CYCLES"):
        messages.append("ERROR: Not in Cycles")
        #return [False, "Not in Cycles"]
    
    for obj in objects:
        if obj.type != "MESH":
            messages.append(f"ERROR: Selected object {obj.name} is not a mesh object")
            continue
         
        if bpy.context.tex_per_mat:
            if len(obj.data.uv_layers) == 0 and bpy.context.expand_mat_uvs == False:
                messages.append(f"ERROR: Selected object {obj.name} has no UV maps, and you are not generating new UVs")
                continue
        #Most cases
        if len(obj.data.uv_layers) == 0 and bpy.context.scene.newUVoption == False and bpy.context.scene.selected_s2a == False:
            messages.append(f"ERROR: Selected object {obj.name} has no UV maps, and you are not generating new UVs")
   
    
    if(bpy.context.mode != "OBJECT"):
        messages.append("ERROR: Not in object mode")
        #return [False, "Not in object mode"]
    if(len(objects) == 0):
        messages.append("ERROR: No objects are selected")
        #return [False, "No objects selected"]    
    
    
    #If we are doing a selected to active bake with cycles, just check the active object
    if bakemode == "cyclesbake" and bpy.context.scene.render.bake.use_selected_to_active:
        if not checkObjectValidMaterialConfig(bpy.context.active_object):
                messages.append(f"ERROR: You are baking selected to active with CyclesBake, and your active object ({bpy.context.active_object.name}) has no materials or empty slots")
                #return [False, "You are baking selected to active with Cycles Bake, and your active object has no materials or empty slots"]
    #Otherwise, check all objects
    else:
        for obj in objects:
            if not checkObjectValidMaterialConfig(obj):
                messages.append(f"ERROR: Selected object {obj.name} has no materials or empty slots")
                #return [False, "One or more selected objects have no materials or empty slots"]
            
    if bakemode == "cyclesbake" and bpy.context.scene.render.bake.use_selected_to_active:
        if len(bpy.context.selected_objects) < 2:
            messages.append("ERROR: You are baking selected to active with Cycles Bake, but you have only one object selected")
            #return [False, "You are baking selected to active with Cycles Bake, but you have only one object selected"]
    
  

    
"""


def processUVS(objects, newUVoption, orig_objects, orig_active_object):
    
    original_uvs = {}
    
    #Loops over UVs. If it has one, record the active UV map for later restoration
    for obj in objects:
        try:
            original_uvs[obj.name] = obj.data.uv_layers.active.name
        except AttributeError:
            original_uvs[obj.name] = False
     
    #Generating new UVs
    
 
    #------------------NEW UVS ------------------------------------------------------------
    
    if bpy.context.scene.expand_mat_uvs:
        printmsg("We are expanding the UVs for each material into a new UV map")
        bpy.ops.object.select_all(action="DESELECT")
        
        for obj in objects:
        
            if("SimpleBake" in obj.data.uv_layers):
                obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
        
            obj.data.uv_layers.new(name="SimpleBake")
            obj.data.uv_layers["SimpleBake"].active = True
            obj.select_set(state=True)
        
            selectOnlyThis(obj)
            
            bpy.ops.object.mode_set(mode='EDIT', toggle=False)
            
            i=0
            for slot in obj.material_slots:
                obj.active_material_index = i
                bpy.ops.mesh.select_all(action="DESELECT")
                bpy.ops.object.material_slot_select()
                bpy.ops.uv.smart_project(island_margin=bpy.context.scene.unwrapmargin)
                i += 1
            
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    
    elif bpy.context.scene.newUVoption:
        printmsg("We are generating new UVs")
        #Slight hack. Single object must always be Smart UV Project (nothing else makes sense)
        if len(objects) < 2 or bpy.context.scene.selected_s2a:
            bpy.context.scene.newUVmethod = "SmartUVProject_Individual"
        
        #If we are using the combine method, the process is the same for merged and non-merged
        if bpy.context.scene.newUVmethod == "CombineExisting":
            printmsg("We are combining all existing UVs into one big atlas map")
            for obj in objects:
                #If there is already an old map, remove it
                if "SimpleBake_Old" in obj.data.uv_layers:
                    obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake_Old"])
                #If we already have a map called SimpleBake, rename it.
                if("SimpleBake" in obj.data.uv_layers):
                    obj.data.uv_layers["SimpleBake"].name = "SimpleBake_Old"
                #Create a new UVMap called SimpleBake based on whatever was active
                obj.data.uv_layers.new(name="SimpleBake")
                obj.data.uv_layers["SimpleBake"].active = True
                
            bpy.ops.object.select_all(action="DESELECT")
            for obj in objects:
                obj.select_set(state=True)
            #With everything selected, pack into one big map
            bpy.ops.object.mode_set(mode="EDIT", toggle=False)
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.uv.select_all(action="SELECT")
            if bpy.context.scene.averageUVsize:
                bpy.ops.uv.average_islands_scale()
            bpy.ops.uv.pack_islands(rotate=True, margin=bpy.context.scene.uvpackmargin)
            bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
        
        elif bpy.context.scene.newUVmethod == "SmartUVProject_Individual":
            printmsg("We are unwrapping each object individually with Smart UV Project")
            for obj in objects:
                if("SimpleBake" in obj.data.uv_layers):
                    obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
                obj.data.uv_layers.new(name="SimpleBake")
                obj.data.uv_layers["SimpleBake"].active = True
                #Will set active object
                selectOnlyThis(obj)
                
                #Blender 2.91 kindly breaks Smart UV Project in object mode so... yeah... thanks
                bpy.ops.object.mode_set(mode="EDIT", toggle=False)
                bpy.ops.mesh.select_all(action="SELECT")
                bpy.ops.mesh.reveal()

                bpy.ops.uv.smart_project(island_margin=bpy.context.scene.unwrapmargin)
                
                bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
        
        elif bpy.context.scene.newUVmethod == "SmartUVProject_Atlas":
            printmsg("We are unwrapping all objects into an atlas map with Smart UV Project")
            bpy.ops.object.select_all(action="DESELECT")
            for obj in objects:
                if("SimpleBake" in obj.data.uv_layers):
                    obj.data.uv_layers.remove(obj.data.uv_layers["SimpleBake"])
                obj.data.uv_layers.new(name="SimpleBake")
                obj.data.uv_layers["SimpleBake"].active = True
                obj.select_set(state=True)
            #With everything now selected, UV project into one big map
            
            #Blender 2.91 kindly breaks Smart UV Project in object mode so... yeah... thanks
            #Check we have an active object:
            try:
                bpy.context.active_object.type
            except AttributeError:
                #We do need an active object, or we can't enter edit mode
                bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
            
            bpy.ops.object.mode_set(mode="EDIT", toggle=False) # Back to object mode, as it's expected later on
                
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.mesh.reveal()
            
            bpy.ops.uv.smart_project(island_margin=bpy.context.scene.unwrapmargin)
            
            bpy.ops.object.mode_set(mode="OBJECT", toggle=False)# Back to object mode, as it's expected later on
                
                    
     #------------------END NEW UVS ------------------------------------------------------------
    
    else: #i.e. New UV Option was not selected
        printmsg("We are working with the existing UVs")
        
        if bpy.context.scene.prefer_existing_sbmap:
            printmsg("We are preferring existing UV maps called SimpleBake. Setting them to active")
            for obj in objects:
                if("SimpleBake" in obj.data.uv_layers):
                    obj.data.uv_layers["SimpleBake"].active = True
        
         
    #Before we finish, restore the original selected and active objects
    bpy.ops.object.select_all(action="DESELECT")
    for obj in orig_objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = orig_active_object
    
    #Once we are all done, return the original uvs dict
    return original_uvs

def restore_Original_UVs(objects, original_uvs):
    for obj in objects:
        original_uv = original_uvs[obj.name]
        if original_uv:
            obj.data.uv_layers.active = obj.data.uv_layers[original_uv]
    
    
def setupEmissionRunThrough(nodetree, m_output_node, thisbake, ismix=False):
    
    nodes = nodetree.nodes
    pnode = find_pnode(nodetree)
    
    #Create emission shader
    emissnode = nodes.new("ShaderNodeEmission")
    emissnode.label = "SimpleBake"
    
    #Connect to output
    if(ismix):
        #Find the existing mix node before we create a new one
        existing_m_node = find_mnode(nodetree)
        
        #Add a mix shader node and label it
        mnode = nodes.new("ShaderNodeMixShader")
        mnode.label = "SimpleBake"
        
        #Connect new mix node to the output
        fromsocket = mnode.outputs[0]
        tosocket = m_output_node.inputs[0]
        nodetree.links.new(fromsocket, tosocket)

        #Connect new emission node to the first mix slot (leaving second empty)
        fromsocket = emissnode.outputs[0]
        tosocket = mnode.inputs[1]
        nodetree.links.new(fromsocket, tosocket)
        
        #If there is one, plug the factor from the original mix node into our new mix node
        if(len(existing_m_node.inputs[0].links) > 0):
            fromsocket = existing_m_node.inputs[0].links[0].from_socket
            tosocket = mnode.inputs[0]
            nodetree.links.new(fromsocket, tosocket)
        #If no input, add a value node set to same as the mnode factor
        else:
            val = existing_m_node.inputs[0].default_value
            vnode = nodes.new("ShaderNodeValue")
            vnode.label = "SimpleBake"
            vnode.outputs[0].default_value = val
            
            fromsocket = vnode.outputs[0]
            tosocket = mnode.inputs[0]
            nodetree.links.new(fromsocket, tosocket)

    else:
        #Just connect our new emission to the output
        fromsocket = emissnode.outputs[0]
        tosocket = m_output_node.inputs[0]
        nodetree.links.new(fromsocket, tosocket)
            
    #Create dummy nodes for the socket for this bake if needed
    createdummynodes(nodetree, pnode, thisbake)
            
    #Connect whatever is in Principled Shader for this bakemode to the emission
    fromsocket = findSocketConnectedtoP(pnode, thisbake)
    tosocket = emissnode.inputs[0]
    nodetree.links.new(fromsocket, tosocket)        
    
def find_pnode(nodetree):
    nodes = nodetree.nodes
    for node in nodes:
        if(node.type == "BSDF_PRINCIPLED"):
            return node
    #We never found it
    return False

def find_enode(nodetree):
    nodes = nodetree.nodes
    for node in nodes:
        if(node.type == "EMISSION"):
            return node
    #We never found it
    return False

def find_mnode(nodetree):
    nodes = nodetree.nodes
    for node in nodes:
        if(node.type == "MIX_SHADER"):
            return node
    #We never found it
    return False

def find_onode(nodetree):
    nodes = nodetree.nodes
    for node in nodes:
        if(node.type == "OUTPUT_MATERIAL"):
            return node
    #We never found it
    return False

def checkObjectValidMaterialConfig(obj):
    #Firstly, check it actually has material slots
    if len(obj.material_slots) == 0:
        return False
    
    #Check the material slots all have a material assigned
    for slot in obj.material_slots:
        if slot.material == None:
            return False
    
    #If we get here, everything looks good
    return True

# def getMergedSaveName():
    # import datetime
    # now = datetime.datetime.now()
    # timestring = now.strftime("%Y-%m-%d %H:%M")
    
    # if isBlendSaved():
        # fullpath = bpy.data.filepath
        # import os
        # pathelements = os.path.split(fullpath)
        # return pathelements[1].replace(".blend", "") + "-" + timestring
    # else:
        # return timestring

g_save_folder = ""
g_rel_save_folder = ""
def getSaveFolder(initialise = False, relative = False):
    
    global g_save_folder
    global g_rel_save_folder
    
    if initialise:
        fullpath = bpy.data.filepath
        pathelements = os.path.split(fullpath)
        workingdir = Path(pathelements[0])
        
        if bpy.context.scene.folderdatetime:
            from datetime import datetime
            now = datetime.now()
            d1 = now.strftime("%d%m%Y-%H%M")
            
            g_rel_save_folder = cleanFileName(bpy.context.scene.saveFolder) + f"_{d1}"
            savedir = workingdir / g_rel_save_folder
        
        else:
            g_rel_save_folder = cleanFileName(bpy.context.scene.saveFolder)
            savedir = workingdir / g_rel_save_folder
        
        g_save_folder = savedir
        return g_save_folder
    
    elif relative:
        #Called for just the relative reference
        return "//" + g_rel_save_folder
    
    else:
        #Called for full path, time to create folder
        try:
            os.mkdir(g_save_folder)
        except FileExistsError:
            pass    
        
        return g_save_folder
            

def getFileName():
    fullpath = bpy.data.filepath
    pathelements = os.path.split(fullpath)
    return pathelements[1]

def checkAtCurrentVersion(v):
    v = v.replace(".","")
    v = int(v)
    
    #Grab the most recent version from my website
    from urllib.request import urlopen
    link = "http://www.toohey.co.uk/SimpleBake/currentversion"
    
    try:
        f = urlopen(link, timeout=2)
        cver = f.read()
        cver = cver.decode("utf-8")
        cver = cver.replace(".","")
        cver = int(cver)
    
    except:
        printmsg("Unable to check for latest version of SimpleBake - are you online?")
        cver = v
    
    if cver > v:
        return False
    else:
        return True
    
    

def getMatType(nodetree):
    if (find_pnode(nodetree) and find_mnode(nodetree)):
        return "MIX"
    elif(find_pnode(nodetree)):
        return "PURE_P"
    elif(find_enode(nodetree)):
        return "PURE_E"
    else:
        return "INVALID"

def cleanFileName(filename):
    keepcharacters = (' ','.','_','~',"-")
    return "".join(c for c in filename if c.isalnum() or c in keepcharacters).rstrip()


def saveExternal(image, baketype, sfupload=False):
    
    #baketype can be "normal", "cyclesbake", "colidbake", "regular" or any of the bake types
    
    #We want to control the bit depth, so we need a new scene
    scene = bpy.data.scenes.new('SimpleBakeTempScene')
    settings = scene.render.image_settings
    
    #if baketype == "normal" or bpy.context.scene.everything16bit:
        #settings.color_depth = '16'
    #else:
        #settings.color_depth = '8'
    
    #Set the file format and extension
    settings.file_format = bpy.context.scene.exportfileformat
    if settings.file_format.lower() == "jpeg":
        file_extension = "jpg"
    else:
        file_extension = settings.file_format.lower()
        
    if sfupload:
        savepath = Path(str(getSaveFolder()) / "sfupload" / (cleanFileName(image.name) + "." + file_extension))
    else:
        savepath = Path(str(getSaveFolder()) + "/" + (cleanFileName(image.name) + "." + file_extension))
    
    try:
        os.remove(str(savepath))
    except FileNotFoundError:
        pass
    
    
    if(baketype == "cyclesbake" and bpy.context.scene.exportcyclescolspace):
        printmsg("Applying colour management settings from current scene")
        scene.display_settings.display_device = bpy.context.scene.display_settings.display_device
        scene.view_settings.view_transform = bpy.context.scene.view_settings.view_transform
        scene.view_settings.look = bpy.context.scene.view_settings.look
        scene.view_settings.exposure = bpy.context.scene.view_settings.exposure
        scene.view_settings.gamma = bpy.context.scene.view_settings.gamma
        scene.sequencer_colorspace_settings.name = bpy.context.scene.sequencer_colorspace_settings.name
        
    else:
        scene.view_settings.view_transform = "Standard"
    
    
    #Save the image
    #Normal maps are a special case. They are byte images inside Blender and should be saved directly

    #if baketype == "normal":
        #image.pack()
        #image.source = "FILE"
        #image.filepath = str(savepath)
        #image.save()

    
    #Cycles bake and we want to denoise
    if bpy.context.scene.global_mode == "cycles_bake" and bpy.context.scene.rundenoise:
        scene.use_nodes = True

        try:
            scene.node_tree.nodes.remove(scene.node_tree.nodes["Render Layers"])
        except:
            pass
        try:
            scene.node_tree.nodes.remove(scene.node_tree.nodes["Composite"])
        except:
            pass
            
        img_n = scene.node_tree.nodes.new("CompositorNodeImage")
        denoise_n = scene.node_tree.nodes.new("CompositorNodeDenoise")
        output_n = scene.node_tree.nodes.new("CompositorNodeOutputFile")
            
        links = scene.node_tree.links
        links.new(denoise_n.outputs[0], output_n.inputs[0])
        links.new(img_n.outputs[0], denoise_n.inputs[0])
    
    
        img_n.image = image
        
        output_n.base_path = str(savepath.parent)
        
        
        output_n.format.file_format = bpy.context.scene.exportfileformat
        output_n.file_slots[0].path = str(Path(savepath.parts[-1]).with_suffix(""))
        
        
        bpy.ops.render.render(use_viewport=False, scene=scene.name)
        
        #This just seems REALLY hacky. Surely there is a better way to do this....?
        #All because the file output compositor node seemingly HAS to include the frame number for images
        fn_str = str(bpy.context.scene.frame_current)
        l = len(fn_str)
        req_zeros_num = 4 - l

        zeros = "".join(["0"]*req_zeros_num)
        fn_str = zeros+fn_str
        
        os.rename(str(savepath).replace(".png", f"{fn_str}.png"), str(savepath).replace(f"{fn_str}", ""))
        
    
    #Not CyclesBake, or Cycles bake but no denoise
    else:
        image.save_render(str(savepath), scene=scene)
    
    #In all cases, remove that temp scene we were using
    bpy.data.scenes.remove(bpy.data.scenes["SimpleBakeTempScene"])
    
    
    
    #Now we have saved the image externally, update the internal reference to refer to the external file
    if not sfupload:
        try:
            image.unpack()
        except:
            pass
        image.source = "FILE"
        #Let's use a relative path. Shouldn't matter in the end.
        image.filepath = str(getSaveFolder(relative=True)) +"/" + image.name + "." + file_extension
    
            
    
    #Set normal maps back to sRGB for consistency with internally created images
    if baketype == "normal":
         image.colorspace_settings.name = "Non-Color"
   
   
    #UDIMS
    if bpy.context.scene.uv_mode == "udims":
        
        #Is this the last one?
        if int(image.name[-3:]) == bpy.context.scene.udim_tiles:
            #This is the last one
            
            #We will need the tag later
            tag = image["SB"]
            
            #We also need to spot new images laster
            spot_new_items(initialise=True, item_type="images")
            
            #Delete all images indiviudally baked UDIM tiles
            counter = int(image.name[-3:])
            imgrootname = image.name[0:-4]
            while counter > 0:
                bpy.data.images.remove(bpy.data.images[f"{imgrootname}100{counter}"])
                counter = counter - 1
            
            #Reopen all UDIM tiles into one image
            spot_new_items(initialise=True, item_type="images")
            bpy.ops.image.open(filepath=f"{ str(savepath).replace('1003', '1001') }", directory= str(getSaveFolder()) + "/", use_udim_detecting=True, relative_path=True)
            new_images = spot_new_items(initialise=False, item_type="images")
            
            
            #Restore the SB tag to all new images
            new_img_names = spot_new_items(initialise=False, item_type="images")
            for img_name in new_img_names:
                bpy.data.images[img_name]["SB"] = tag + "_udim"
    
            
            #Check for duplicates - .00X
            for imgname in new_images:
                try:
                    int(imgname[-3:])
                
                
                    #Delete the existing version
                    bpy.data.images.remove(bpy.data.images[imgname[0:-4]])
                
                    #Rename our version
                    bpy.data.images[imgname].name = imgname[0:-4]
                
                except ValueError:
                    pass
                    
    return file_extension

def prepObjects(objs, baketype, lastbake_newuvs=False, forcewrite=False):
    printmsg("Creating prepared object")
    #First we prepare objectes
    export_objects = []
    for obj in objs:
        
        
        #-------------Create the prepared mesh----------------------------------------
        
        #Object might have a truncated name. Should use this if it's there
        objname = trunc_if_needed(obj.name)
        
        new_obj = obj.copy()
        new_obj.data = obj.data.copy()
        new_obj["SB_createdfrom"] = obj.name
        
        #Unless we are baking tex per mat, then clear all materials
        if not bpy.context.scene.tex_per_mat:
            new_obj.data.materials.clear()
        new_obj.name = objname + "_SimpleBake"
        
        #Create a collection for our baked objects if it doesn't exist
        if "SimpleBake_Bakes" not in bpy.data.collections:
            c = bpy.data.collections.new("SimpleBake_Bakes")
            bpy.context.scene.collection.children.link(c)
        else:
            #Make sure it's visible for current view laywer or it screws things up
            bpy.context.view_layer.layer_collection.children["SimpleBake_Bakes"].hide_viewport = False
            c = bpy.data.collections["SimpleBake_Bakes"]
        
        #Link object to our new collection
        c.objects.link(new_obj)
        
        #Finally append this object to the export list
        export_objects.append(new_obj)  
        
        
        #---------------------------------UVS--------------------------------------
        
        uvlayers = new_obj.data.uv_layers
        #If we generated new UVs, it will be called "SimpleBake" and we are using that. End of.
        #Same if we are being called for Sketchfab upload, and last bake used new UVs
        if bpy.context.scene.newUVoption or (forcewrite and lastbake_newuvs):
            pass
        
        #If there is an existing map called SimpleBake, and we are preferring it, use that
        elif ("SimpleBake" in uvlayers) and bpy.context.scene.prefer_existing_sbmap:
            pass
            
        #Even if we are not preferring it, if there is just one map called SimpleBake, we are using that
        elif ("SimpleBake" in uvlayers) and len(uvlayers) <2:
            pass
            
        #If there is an existing map called SimpleBake, and we are not preferring it, it has to go
        #Active map becommes SimpleBake
        elif ("SimpleBake" in uvlayers) and not bpy.context.scene.prefer_existing_sbmap:
            uvlayers.remove(uvlayers["SimpleBake"])
            active_layer = uvlayers.active
            active_layer.name = "SimpleBake"
            
        #Finally, if none of the above apply, we are just using the active map
        #Active map becommes SimpleBake
        else:
            active_layer = uvlayers.active
            active_layer.name = "SimpleBake"
            
        #In all cases, we can now delete everything other than SimpleBake
        deletelist = []
        for uvlayer in uvlayers:
            if (uvlayer.name != "SimpleBake"):
                deletelist.append(uvlayer.name)
        for uvname in deletelist:
            uvlayers.remove(uvlayers[uvname])
        
    #---------------------------------END UVS--------------------------------------
    
        #Tex per mat will preserve existing materials
        if not bpy.context.scene.tex_per_mat:
        
            #Create a new material
            #If not mergedbake, call it same as object + batchname + baked
            if not bpy.context.scene.mergedBake:
                mat = bpy.data.materials.get(objname + "_" + bpy.context.scene.batchName + "_baked")
                if mat is None:
                    mat = bpy.data.materials.new(name=objname + "_" + bpy.context.scene.batchName +"_baked")
            #For merged bake, it's just called marged bake + batchname.
            else:
                mat = bpy.data.materials.get("MergedBake_" + bpy.context.scene.batchName)
                if mat is None:
                    mat = bpy.data.materials.new("MergedBake_" + bpy.context.scene.batchName)
            
            # Assign it to object
            mat.use_nodes = True
            new_obj.data.materials.append(mat)
        
        
    #Tex per material should have no material setup (as prepare objects is not an option
    if not bpy.context.scene.tex_per_mat:
                
        #Set up the materials for each object
        for obj in export_objects:
                
            #Should only have one material
            mat = obj.material_slots[0].material
            nodetree = mat.node_tree
            
            if(baketype == "pbrbake"):
                material_setup.create_principled_setup(nodetree, obj)
            # if(baketype == "colidbake"):
                # material_setup.create_colmap_setup(nodetree, obj)
            if(baketype == "cyclesbake"):
                material_setup.create_cyclesbake_setup(nodetree, obj)
            
            #Unless we are going to discard it anyway, change object name to avoid collisions
            if not forcewrite:
                obj.name = obj.name.replace("_SimpleBake", "_Baked")    
             
    bpy.ops.object.select_all(action="DESELECT")
    for obj in export_objects:
        obj.select_set(state=True)
    
    #If we are exporting to FBX, do that now
    if(bpy.context.scene.saveObj or forcewrite):    
        #Export all selected to save folder
        filename = getFileName().replace(".blend", "")
        
        if forcewrite:
            filepath = getSaveFolder() / "sfupload" / (filename + "_SimpleBakeExport.fbx")
        else:
            #Use the file name that the user defined
            #filepath = getSaveFolder() / (filename + "_SimpleBakeExport.fbx")
            filepath = getSaveFolder() / (cleanFileName(bpy.context.scene.fbxName) + ".fbx")
        
        bpy.ops.export_scene.fbx(filepath=str(filepath), check_existing=False, use_selection=True, use_mesh_modifiers=True, use_mesh_modifiers_render=True, path_mode="STRIP")
    
    
    if (not bpy.context.scene.prepmesh or forcewrite) and (not "--background" in sys.argv):
        #Deleted duplicated objects
        for obj in export_objects:
            bpy.data.objects.remove(obj)


def selectOnlyThis(obj):
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(state=True)
    bpy.context.view_layer.objects.active = obj
    
    
def setup_pure_p_material(nodetree, thisbake):
    #Create dummy nodes as needed
    createdummynodes(nodetree, thisbake)
    
    #Create emission shader
    nodes = nodetree.nodes
    m_output_node = find_onode(nodetree)
    loc = m_output_node.location
    
    #Create an emission shader
    emissnode = nodes.new("ShaderNodeEmission")
    emissnode.label = "SimpleBake"
    emissnode.location = loc
    emissnode.location.y = emissnode.location.y + 200
    
    #Connect our new emission to the output
    fromsocket = emissnode.outputs[0]
    tosocket = m_output_node.inputs[0]
    nodetree.links.new(fromsocket, tosocket)
            
    #Connect whatever is in Principled Shader for this bakemode to the emission
    fromsocket = findSocketConnectedtoP(find_pnode(nodetree), thisbake)
    tosocket = emissnode.inputs[0]
    nodetree.links.new(fromsocket, tosocket) 

def setup_pure_e_material(nodetree, thisbake):
    #If baking something other than emission, mute the emission modes so they don't contaiminate our bake
    if thisbake != "Emission":
        nodes = nodetree.nodes
        for node in nodes:
            if node.type == "EMISSION":
                node.mute = True
                node.label = "SimpleBakeMuted"

def setup_mix_material(nodetree, thisbake):
    #No need to mute emission nodes. They are automuted by setting the RGBMix to black
    nodes = nodetree.nodes
    
    #Create dummy nodes as needed
    createdummynodes(nodetree, thisbake)
    
    #For every mix shader, create a mixrgb above it
    #Also connect the factor input to the same thing
    created_mix_nodes = {}
    for node in nodes:
        if node.type == "MIX_SHADER":
            loc = node.location
            rgbmix = nodetree.nodes.new("ShaderNodeMixRGB")
            rgbmix.label = "SimpleBake"
            rgbmix.location = loc
            rgbmix.location.y = rgbmix.location.y + 200
                        
            
            #If there is one, plug the factor from the original mix node into our new mix node
            if(len(node.inputs[0].links) > 0):
                fromsocket = node.inputs[0].links[0].from_socket
                tosocket = rgbmix.inputs["Fac"]
                nodetree.links.new(fromsocket, tosocket)
            #If no input, add a value node set to same as the mnode factor
            else:
                val = node.inputs[0].default_value
                vnode = nodes.new("ShaderNodeValue")
                vnode.label = "SimpleBake"
                vnode.outputs[0].default_value = val
            
                fromsocket = vnode.outputs[0]
                tosocket = rgbmix.inputs[0]
                nodetree.links.new(fromsocket, tosocket)
                
            #Keep a dictionary with paired shader mix node
            created_mix_nodes[node.name] = rgbmix.name
                
    #Loop over the RGBMix nodes that we created
    for node in created_mix_nodes:
        mshader = nodes[node]
        rgb = nodes[created_mix_nodes[node]]
               
        #Mshader - Socket 1
        #First, check if there is anything plugged in at all
        if len(mshader.inputs[1].links) > 0:
            fromnode = mshader.inputs[1].links[0].from_node
            
            if fromnode.type == "BSDF_PRINCIPLED":
                #Get the socket we are looking for, and plug it into RGB socket 1
                fromsocket = findSocketConnectedtoP(fromnode, thisbake)
                nodetree.links.new(fromsocket, rgb.inputs[1])
            elif fromnode.type == "MIX_SHADER":
                #If it's a mix shader on the other end, connect the equivilent RGB node
                #Get the RGB node for that mshader
                fromrgb = nodes[created_mix_nodes[fromnode.name]]
                fromsocket = fromrgb.outputs[0]
                nodetree.links.new(fromsocket, rgb.inputs[1])
            elif fromnode.type == "EMISSION":
                #Set this input to black
                rgb.inputs[1].default_value = (0.0, 0.0, 0.0, 1)
            else:
                printmsg("Error, invalid node config")
        else:
            rgb.inputs[1].default_value = (0.0, 0.0, 0.0, 1)
                    
        #Mshader - Socket 2
        if len(mshader.inputs[2].links) > 0:
            fromnode = mshader.inputs[2].links[0].from_node
            if fromnode.type == "BSDF_PRINCIPLED":
                #Get the socket we are looking for, and plug it into RGB socket 2
                fromsocket = findSocketConnectedtoP(fromnode, thisbake)
                nodetree.links.new(fromsocket, rgb.inputs[2])
            elif fromnode.type == "MIX_SHADER":
                #If it's a mix shader on the other end, connect the equivilent RGB node
                #Get the RGB node for that mshader
                fromrgb = nodes[created_mix_nodes[fromnode.name]]
                fromsocket = fromrgb.outputs[0]
                nodetree.links.new(fromsocket, rgb.inputs[2])
            elif fromnode.type == "EMISSION":
                #Set this input to black
                rgb.inputs[2].default_value = (0.0, 0.0, 0.0, 1)
            else:
                printmsg("Error, invalid node config")
        else:
            rgb.inputs[2].default_value = (0.0, 0.0, 0.0, 1)
                
    #Find the output node with location
    m_output_node = find_onode(nodetree)
    loc = m_output_node.location
    
    #Create an emission shader
    emissnode = nodes.new("ShaderNodeEmission")
    emissnode.label = "SimpleBake"
    emissnode.location = loc
    emissnode.location.y = emissnode.location.y + 200
    
    #Get the original mix node that was connected to the output node
    socket = m_output_node.inputs["Surface"]
    fromnode = socket.links[0].from_node
    
    #Find our created mix node that is paired with it
    rgbmix = nodes[created_mix_nodes[fromnode.name]]
    
    #Plug rgbmix into emission
    nodetree.links.new(rgbmix.outputs[0], emissnode.inputs[0])
    
    #Plug emission into output
    nodetree.links.new(emissnode.outputs[0], m_output_node.inputs[0])

def is_image_single_colour(img):
    pixels = img.pixels[:]
    if not pixels.count(pixels[0]) == len(pixels)/4:
        return False
    if not pixels.count(pixels[1]) == len(pixels)/4:
        return False
    if not pixels.count(pixels[2]) == len(pixels)/4:
        return False
    if not pixels.count(pixels[3]) == len(pixels)/4:
        return False

    return True


#----------------Specials---------------------------------
def import_needed_specials_materials():
    ordered_specials = []
    path = os.path.dirname(__file__) + "/materials/materials.blend\\Material\\"
    if(bpy.context.scene.selected_thickness):
        if "SimpleBake_Thickness" not in bpy.data.materials:
            material_name = "SimpleBake_thickness"
            bpy.ops.wm.append(filename=material_name, directory=path)
            ordered_specials.append("thickness")
        else:
            ordered_specials.append("thickness")
    if(bpy.context.scene.selected_ao):
        if "SimpleBake_AO" not in bpy.data.materials:
            material_name = "SimpleBake_ambientocclusion"
            bpy.ops.wm.append(filename=material_name, directory=path)
            ordered_specials.append("ambientocclusion")
        else:
            ordered_specials.append("ambientocclusion")
            
    if(bpy.context.scene.selected_curvature):
        if "SimpleBake_Curvature" not in bpy.data.materials:
            material_name = "SimpleBake_curvature"
            bpy.ops.wm.append(filename=material_name, directory=path)
            ordered_specials.append("curvature")
        else:
            ordered_specials.append("curvature")
            

    #return the list of specials
    return ordered_specials
        
          
          
#------------Long Name Truncation-----------------------
trunc_num = 0
trunc_dict = {}
def trunc_if_needed(objectname):
    
    global trunc_num
    global trunc_dict
    
    #If we already truncated this, just return that
    if objectname in trunc_dict:
        printmsg(f"Object name {objectname} was previously truncated. Returning that.")
        return trunc_dict[objectname]
    
    #If not, let's see if we have to truncate it
    elif len(objectname) >= 38:
        printmsg(f"Object name {objectname} is too long and will be truncated")
        trunc_num += 1
        truncdobjectname = objectname[0:34] + "~" + str(trunc_num)
        trunc_dict[objectname] = truncdobjectname
        return truncdobjectname
    
    #If nothing else, just return the original name
    else:
        return objectname
        
def untrunc_if_needed(objectname):
    
    global trunc_num
    global trunc_dict
    
    for t in trunc_dict:
        if trunc_dict[t] == objectname:
            printmsg(f"Returning untruncated value {t}")
            return t
    
    return objectname
    
def ShowMessageBox(messageitems_list, title, icon = 'INFO'):

    def draw(self, context):
        for m in messageitems_list:
            self.layout.label(text=m)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
    
    
#---------------Bake Progress--------------------------------------------
def write_bake_progress(current_operation, total_operations):
    progress = int((current_operation / total_operations) * 100)
    
    
    t = Path(tempfile.gettempdir())
    t = t / f"SimpleBake_Bgbake_{os.getpid()}"

    with open(str(t), "w") as progfile:
        progfile.write(str(progress))
        
   
#---------------End Bake Progress--------------------------------------------


def diff(li1, li2):
    li_dif = [i for i in li1 + li2 if i not in li1 or i not in li2]
    return li_dif


#--------------UDIMS-------------------------------------


#Dict obj name to tile
currentUDIMtile = {}

def UDIM_focustile(obj,desiredUDIMtile):
    global currentUDIMtile
    
    
    selectOnlyThis(obj)
    bpy.ops.object.editmode_toggle()
    
    printmsg(f"Shifting UDIM focus tile: Object: {obj.name} Tile: {desiredUDIMtile}")
    
    
    import bmesh
    
    if obj.name not in currentUDIMtile:
        #Must be first time. Set to 0
        currentUDIMtile[obj.name] = 0
    
    #Difference between desired and current
    tilediff =  desiredUDIMtile - currentUDIMtile[obj.name]
    
    me = obj.data
    bm = bmesh.new()
    bm = bmesh.from_edit_mesh(me)

    uv_layer = bm.loops.layers.uv.verify()
    #bm.faces.layers.tex.verify()  # currently blender needs both layers.

    # scale UVs x2
    for f in bm.faces:
        for l in f.loops:
            l[uv_layer].uv[0] -= tilediff

    #bm.to_mesh(me)
    me.update()
    
    currentUDIMtile[obj.name] = desiredUDIMtile
    
    bpy.ops.object.editmode_toggle()
    
#ZERO Indexed
#UDIM_FocusTile(bpy.data.objects[1],0)


past_items_dict = {}
def spot_new_items(initialise=True, item_type="images"):
    
    global past_items_dict
    
    if item_type == "images":
        source = bpy.data.images
    elif item_type == "objects":
        source = bpy.data.objects
    elif item_type == "collections":
        source = bpy.data.collections
    
    
    #First run
    if initialise:
        #Set to empty list for this item type
        past_items_dict[item_type] = []
        
        for source_item in source:
            past_items_dict[item_type].append(source_item.name)
        return True
    
    else:
        #Get the list of items for this item type from the dict
        past_items_list = past_items_dict[item_type]
        new_item_list_names = []
        
        for source_item in source:
            if source_item.name not in past_items_list:
                new_item_list_names.append(source_item.name)
        
        return new_item_list_names
