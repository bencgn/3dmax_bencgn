import bpy
from . import functions
import os
import sys
from. import post_processing
from pathlib import Path

lastbake_newuvs = False

class bake_status():
    total_operations = 0;
    current_operation = 0;

def optimize(imgwidth, imgheight, cyclesbake):
    #Store the current tile sizes and sample count
    orig_settings = {
        "samples": bpy.context.scene.cycles.samples,
        "tile_x": bpy.context.scene.render.tile_x,
        "tile_y": bpy.context.scene.render.tile_y
        }

    #Get the max tile size we are working with
    if(bpy.context.scene.memLimit == "Off"):
        maxtile_x = imgwidth
        maxtile_y = imgheight
    else:
        maxtile_x = int(bpy.context.scene.memLimit)
        maxtile_y = int(bpy.context.scene.memLimit)

    #Set x tile size to greater of imgwidth and maxtile_x
    if(imgwidth <= maxtile_x):
        bpy.context.scene.render.tile_x = imgwidth
    else:
        bpy.context.scene.render.tile_x = maxtile_x

    #Set y tile size to greater of imgheight and maxtile_y
    if(imgheight <= maxtile_y):
        bpy.context.scene.render.tile_y = imgheight
    else:
        bpy.context.scene.render.tile_y = maxtile_y

    if(cyclesbake):
        functions.printmsg(f"Honouring user set sample count of {bpy.context.scene.cycles.samples} for Cycles bake")
    else:
        functions.printmsg("Reducing sample count to 16 for more efficient baking")
        bpy.context.scene.cycles.samples = 16

    #return the original settings
    return orig_settings

def undo_optimize(orig_settings):
    #Restore sample count
    bpy.context.scene.cycles.samples = orig_settings["samples"]

    #Restore tile sizes
    bpy.context.scene.render.tile_x = orig_settings["tile_x"]
    bpy.context.scene.render.tile_y = orig_settings["tile_y"]

orig_settings = None
orig_uvs = None
orig_s2a = None
orig_objects = None
orig_active_object = None

def common_bake_prep(objects, cyclesbake=False):
    functions.printmsg("================================")
    functions.printmsg("--------SIMPLEBAKE Start--------")
    functions.printmsg("================================")

    global udim_counter
    
    
    #Reset the UDIM counters to 0
    udim_counter = 1001
    functions.currentUDIMtile = {}

    #If baking S2A, and the user has selected a cage object, there are extra steps to turn it on
    if bpy.context.scene.selected_s2a or bpy.context.scene.cycles_s2a:
        if bpy.context.scene.render.bake.cage_object == None:
            bpy.context.scene.render.bake.use_cage = False
        else:
            bpy.context.scene.render.bake.use_cage = True

    #Clear status trackers
    bake_status.current_operation = 0
    bake_status.total_operations = 0

    #Initialise the save folder in case we need it
    functions.getSaveFolder(initialise = True)

    #If only one object is selected, can't be merged bake. Force it to off first thing
    if len(bpy.context.selected_objects) == 1:
        bpy.context.scene.mergedBake = False

    #Clear the trunc num for this session
    functions.trunc_num = 0
    functions.trunc_dict = {}

    #Turn off that dam use clear.
    bpy.context.scene.render.bake.use_clear = False

    #Store original selection, in case we mess with it for selected to active bake
    global orig_objects
    orig_objects = bpy.context.selected_objects
    global orig_active_object
    orig_active_object = bpy.context.active_object

    #Record original state of selected to active
    global orig_s2a
    orig_s2a = bpy.context.scene.render.bake.use_selected_to_active
    #If this is a Cycles bake, and we are baking selected to active
    if cyclesbake and bpy.context.scene.render.bake.use_selected_to_active:
        functions.printmsg("Baking selected to active with Cycles Bake")
        #Set objects list to only inlcude active object
        objects = [bpy.context.active_object]
        #Always set the ray distance to the one selected in SimpleBake
        functions.printmsg(f"Setting ray distance to {round(bpy.context.scene.ray_distance, 2)}")
        bpy.context.scene.render.bake.cage_extrusion = bpy.context.scene.ray_distance

    #Do what we are doing with UVs
    global orig_uvs
    #We pass modified objects list for the UV function's actual work (if it has been modified)
    #but also the original list so original selection can be restored at the end
    orig_uvs = functions.processUVS(objects, bpy.context.scene.newUVoption, orig_objects, orig_active_object)

    #Optimize
    global orig_settings
    orig_settings = optimize(bpy.context.scene.imgwidth, bpy.context.scene.imgheight, cyclesbake)

    #Make sure the normal y setting is at defauly
    bpy.context.scene.render.bake.normal_g = "POS_Y"


    #Return modified objects list
    return objects


def do_post_processing(thisbake, IMGNAME):

    functions.printmsg("Doing post processing")

    #DirectX vs OpenGL normal map format

    if thisbake == "normal" and bpy.context.scene.normal_format_switch == "directx":
        post_processing.post_process(internal_img_name="SB_Temp_Img",
        save=False, input_x=bpy.data.images[IMGNAME], x_input_on=True, output_g_invert_on=True)

        #Replace our existing image with the processed one
        tags = bpy.data.images[IMGNAME]["SB"]
        bpy.data.images.remove(bpy.data.images[IMGNAME])
        bpy.data.images["SB_Temp_Img"]["SB"] = tags
        bpy.data.images["SB_Temp_Img"].name = IMGNAME


    #Roughness vs Glossy

    if thisbake == "roughness" and bpy.context.scene.rough_glossy_switch == "glossy":
        post_processing.post_process(internal_img_name="SB_Temp_Img",
        save=False, input_x=bpy.data.images[IMGNAME], x_input_on=True, x_input_total_invert_on=True)


        #Replace our existing image with the processed one
        tags = bpy.data.images[IMGNAME]["SB"]
        bpy.data.images.remove(bpy.data.images[IMGNAME])
        bpy.data.images["SB_Temp_Img"]["SB"] = tags
        bpy.data.images["SB_Temp_Img"].name = IMGNAME


        #Change roughness alias to glossy alias
        prefs = bpy.context.preferences.addons[__package__].preferences
        proposed_name = IMGNAME.replace(prefs.roughness_alias, prefs.glossy_alias)
        if proposed_name in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[proposed_name])

        bpy.data.images[IMGNAME].name = proposed_name
        IMGNAME = proposed_name


    return IMGNAME

def channel_packing(objects):

    functions.printmsg("Channel packing commencing")

    #We need the find images from tag function from the material setup code
    from .material_setup import get_image_from_tag

    if bpy.context.scene.pack_gloss2metal_alpha:
        #-----------Gloss into metal alpha---------------
        for obj in objects:
            if bpy.context.scene.mergedBake:
                objname = "merged"
            else:
                objname = obj.name

            #Find images needed
            metaltex = get_image_from_tag("metalness", objname)
            glosstex = get_image_from_tag("roughness", objname)

            imgname = functions.gen_image_name(objname, "pbr", f"metal + {bpy.context.scene.rough_glossy_switch} in alpha")

            input_r = metaltex
            input_g = metaltex
            input_b = metaltex
            input_a = glosstex
            post_processing.post_process(imgname, input_r=input_r, r_input_isolate_r=True, input_g=input_g,
                g_input_isolate_g=True, input_b=input_b, b_input_isolate_b=True, input_a=input_a, save=True, path_dir=functions.getSaveFolder(), path_filename=Path(imgname))

            #Remove internal image, as it is kind of pointless inside Blender
            bpy.data.images.remove(bpy.data.images[imgname])

            #If this is a mergedbake, break out of the loop
            if bpy.context.scene.mergedBake:
                break


def common_bake_finishing(objects, mergedbake, baketype):
    
    #Reset the UDIM focus tile of all objects
    for obj in objects:
        functions.UDIM_focustile(obj, 0)
    
    #Do channel packing if requested
    channel_packing(objects)

    global orig_s2a
    bpy.context.scene.render.bake.use_selected_to_active = orig_s2a

    global orig_settings
    undo_optimize(orig_settings)

    #If prep mesh, or save object is selected, or running in the background, then do it
    if(bpy.context.scene.saveObj or bpy.context.scene.prepmesh or "--background" in sys.argv):
        functions.prepObjects(objects, baketype)

    #If the user wants it, restore the original active UV map so we don't confuse anyone
    if bpy.context.scene.restoreOrigUVmap:
        global orig_uvs
        functions.restore_Original_UVs(objects, orig_uvs)

    #Restore the original object selection so we don't confuse anyone
    #Use the original object list in case we messed with it for selected to active
    bpy.ops.object.select_all(action="DESELECT")
    global  orig_objects
    for obj in orig_objects:
        obj.select_set(True)
    global orig_active_object
    bpy.context.view_layer.objects.active = orig_active_object

    #Hide all the original objects
    if bpy.context.scene.prepmesh and bpy.context.scene.hidesourceobjects:
        for obj in orig_objects:
            obj.hide_set(True)
        if bpy.context.scene.selected_s2a:
            bpy.context.scene.targetobj.hide_set(True)

    #If not exporting, pack all images that we created
    if not bpy.context.scene.saveExternal:
        for img in bpy.data.images:
            try:
                img["SB"]
                img.pack()
            except:
                pass

    #If we are running in the background, there are some final thigs
    if "--background" in sys.argv:
        #Save file
        bpy.ops.wm.save_mainfile()

def cyclesBake():
    
    udim_counter = 1001

    objects = bpy.context.selected_objects

    #Do the prep we need to do for all bake types - update objects list if selected to active
    objects = common_bake_prep(objects, True)

    #Bake tracking variables have just been cleared, set them now
    #Cycles bake is always one bake per object
    if bpy.context.scene.uv_mode == "udims":
        bake_status.total_operations = len(bpy.context.selected_objects) * bpy.context.scene.udim_tiles
    else:
        bake_status.total_operations = len(bpy.context.selected_objects) 

    functions.printmsg(f"Baking from cycles settings")

    IMGNAME = ""
    mergedbake = bpy.context.scene.mergedBake

    batch_name = bpy.context.scene.batchName
    IMGS_TO_SAVE = []

    def cycles_bake_actual():
            
        #If we are doing a merged bake, just create one image here
        if(mergedbake):
            functions.printmsg("We are doing a merged bake")
            IMGNAME = functions.gen_image_name("Mergedbake", "cyclesbake", bpy.context.scene.cycles.bake_type)
            
            #UDIMs
            if bpy.context.scene.uv_mode == "udims":
                    IMGNAME = IMGNAME+f".{udim_counter}"
            
            functions.create_Images(IMGNAME, "cyclesbake", f"SB_merged_{batch_name}_cyclesbake")
            IMGS_TO_SAVE.append(IMGNAME)
    
        for obj in objects:
            #We will save per object if doing normal or tex per mat bake
            if not mergedbake:
                IMGS_TO_SAVE = []
    
    
            #Reset the already processed list
            mats_done = []
            OBJNAME = functions.trunc_if_needed(obj.name)
            materials = obj.material_slots
    
            #If not merged and not bake per mat, create the image we need for this bake (Delete if exists)
            if(not mergedbake and not bpy.context.scene.tex_per_mat):
                IMGNAME = functions.gen_image_name(OBJNAME, "cyclesbake", bpy.context.scene.cycles.bake_type)
                
                #UDIMS
                if bpy.context.scene.uv_mode == "udims":
                    IMGNAME = IMGNAME+f".{udim_counter}"
                
                functions.create_Images(IMGNAME, "cyclesbake", f"SB_{obj.name}_{batch_name}_cyclesbake")
                IMGS_TO_SAVE.append(IMGNAME)
    
            for matslot in materials:
                mat = bpy.data.materials.get(matslot.name)
    
                #If we are baking tex per mat, then we need an image for each mat
                if bpy.context.scene.tex_per_mat:
                    functions.printmsg(f"Creating image for material; {matslot.name}")
                    IMGNAME = functions.gen_image_name(OBJNAME, "cyclesbake", bpy.context.scene.cycles.bake_type)
                    IMGNAME = IMGNAME + "_" + matslot.name
                    functions.create_Images(IMGNAME, "cyclesbake")
                    IMGS_TO_SAVE.append(IMGNAME)
    
                #Make sure we are using nodes
                if not mat.use_nodes:
                    functions.printmsg(f"Material {mat.name} wasn't using nodes. Have enabled nodes")
                    mat.use_nodes = True
    
                if mat.name in mats_done:
                    #Skip this loop
                    #We don't want to process any materials more than once or bad things happen
                    continue
                else:
                    mats_done.append(mat.name)
                nodetree = mat.node_tree
                nodes = nodetree.nodes
                links = nodetree.links
    
                #Take a copy of material to restore at the end of the process
                functions.backupMaterial(mat)
    
                #Create the image node and set to the bake texutre we are using
                imgnode = nodes.new("ShaderNodeTexImage")
                imgnode.image = bpy.data.images[IMGNAME]
                imgnode.label = "SimpleBake"
                functions.deselectAllNodes(nodes)
                imgnode.select = True
                nodetree.nodes.active = imgnode
    
            #Make sure only the object we want is selected - unless selected to active
            if not bpy.context.scene.render.bake.use_selected_to_active:
                functions.selectOnlyThis(obj)
    
            #Bake
            functions.bakeoperation("cyclesbake")
    
            #Update tracking
            bake_status.current_operation = bake_status.current_operation + 1
            functions.printmsg(f"Bake operation {bake_status.current_operation} of {bake_status.total_operations} complete")
            functions.write_bake_progress(bake_status.current_operation, bake_status.total_operations)
    
            #Restore the original materials
            functions.restoreAllMaterials()
    
            #If we are saving externally, and this isn't a merged bake, save all files after each object complete
            if(bpy.context.scene.saveExternal and not mergedbake):
                functions.printmsg("Saving baked images externally")
                for img in IMGS_TO_SAVE:
                    functions.printmsg(f"Saving {img}")
                    functions.saveExternal(bpy.data.images[img], "cyclesbake")
    
    
        #If we did a merged bake, and we are saving externally, then save here
        if mergedbake and bpy.context.scene.saveExternal:
            functions.printmsg("Saving merged baked image externally")
            functions.saveExternal(bpy.data.images[IMGNAME], "cyclesbake")

    #Bake at least once
    cycles_bake_actual()
    udim_counter = udim_counter + 1
    
    #If we are doing UDIMs, we need to go back in
    if bpy.context.scene.uv_mode == "udims":
        
        while udim_counter < bpy.context.scene.udim_tiles + 1001:
            functions.printmsg(f"Going back in for tile {udim_counter}")
            for obj in objects:
                functions.UDIM_focustile(obj,udim_counter - 1001)
                
            cycles_bake_actual()
        
            udim_counter = udim_counter + 1
    
    
    #Finished baking. Perform wind down actions
    common_bake_finishing(objects, mergedbake, "cyclesbake")

def specialsBake(IMGWIDTH, IMGHEIGHT):
    functions.printmsg("Special Bake")
    
    udim_counter = 1001

    #This can never be selected to active, would not make sense
    bpy.context.scene.render.bake.use_selected_to_active = False

    #Common bake prep
    orig_objects = bpy.context.selected_objects
    objects = common_bake_prep(orig_objects, cyclesbake=False)

    #Firstly, let's bake the coldid maps if they have been asked for
    if bpy.context.scene.selected_col_mats:
        colIDMap(IMGWIDTH, IMGHEIGHT, objects, "Colmap")
    if bpy.context.scene.selected_col_vertex:
        colIDMap(IMGWIDTH, IMGHEIGHT, objects, "Vertexcols")

    #Record whether this is a merged bake or not
    mergedbake = bpy.context.scene.mergedBake

    #Import the materials that we need, and save the returned list of specials
    ordered_specials = functions.import_needed_specials_materials()

    #At this point, time to return if no ordered specials that require imported materials
    if len(ordered_specials) == 0:
        functions.printmsg("No more specials ordered")
        return True

    
    def specialsBake_actual():
        
        #Loop over the selected specials and bake them
        for special in ordered_specials:
            functions.printmsg(f"Baking {special}")
    
            #If we are doing a merged bake, just create one image here
            if(bpy.context.scene.mergedBake):
                functions.printmsg("We are doing a merged bake")
                IMGNAME = functions.gen_image_name("MergedBake", "special", special)
                
                #UDIMs
                if bpy.context.scene.uv_mode == "udims":
                    IMGNAME = IMGNAME+f".{udim_counter}"
                
                #TODO - May want to change the tag when can apply specials bakes
                functions.create_Images(IMGNAME, "special", "")
    
    
            for obj in objects:
                OBJNAME = obj.name
    
                #If we are not doing a merged bake, create the image to bake to
                if not bpy.context.scene.mergedBake:
                    IMGNAME = functions.gen_image_name(OBJNAME, "special", special)
                    
                    #UDIMs
                    if bpy.context.scene.uv_mode == "udims":
                        IMGNAME = IMGNAME+f".{udim_counter}"
    
                    #TODO - May want to change the tag when can apply specials bakes
                    functions.create_Images(IMGNAME, "special", "")
    
                #Apply special material to all slots
                materials = obj.material_slots
                for matslot in materials:
                    name = matslot.name
    
    
                    #If we already copied the imported special material for this material, use that. If not, copy it and use that
                    if name + "_sbspectmp_" + special in bpy.data.materials:
                        matslot.material = bpy.data.materials[name + "_sbspectmp_" + special]
                    else:
                        newmat = bpy.data.materials["SimpleBake_" + special].copy()
                        matslot.material = newmat
                        newmat.name = name + "_sbspectmp_" + special
    
                    #Create the image node and set to the bake texutre we are using
                    thismat = matslot.material
                    nodes = thismat.node_tree.nodes
                    imgnode = nodes.new("ShaderNodeTexImage")
                    imgnode.image = bpy.data.images[IMGNAME]
                    imgnode.label = "SimpleBake"
                    functions.deselectAllNodes(nodes)
                    imgnode.select = True
                    nodes.active = imgnode
    
                #Bake this object
                functions.selectOnlyThis(obj)
                functions.bakeoperation("special")
    
                #Restore all materials
                for matslot in materials:
                    if "_sbspectmp_" + special in matslot.name:
                        matslot.material = bpy.data.materials[matslot.name.replace("_sbspectmp_" + special, "")]
    
    
                #If we are saving per object (not merged bake) - do that here
                if(bpy.context.scene.saveExternal and not mergedbake):
                    functions.printmsg("Saving baked images externally")
                    functions.saveExternal(bpy.data.images[IMGNAME], "special")
    
        #If we did a merged bake, and we are saving externally, then save here
        if mergedbake and bpy.context.scene.saveExternal:
            functions.printmsg("Saving merged baked image externally")
            functions.saveExternal(bpy.data.images[IMGNAME], "special")

    
    #Bake at least once
    specialsBake_actual()
    udim_counter = udim_counter + 1
    
    
    #If we are doing UDIMs, we need to go back in
    if bpy.context.scene.uv_mode == "udims":
        
        while udim_counter < bpy.context.scene.udim_tiles + 1001:
            functions.printmsg(f"Going back in for tile {udim_counter}")
            for obj in objects:
                functions.UDIM_focustile(obj,udim_counter - 1001)
                
            specialsBake_actual()
        
            udim_counter = udim_counter + 1
    
    
    #Delete the special placeholders
    for mat in bpy.data.materials:
        if "_sbspectmp_" in mat.name:
            bpy.data.materials.remove(mat)


    #Call common finishing
    #TODO===----
    common_bake_finishing(objects, mergedbake, "special")


def colIDMap(IMGWIDTH, IMGHEIGHT, objects, mode="random"):

    functions.printmsg(f"Baking ColourID map")

    IMGNAME = ""
    mergedbake = bpy.context.scene.mergedBake
    
    udim_counter = 1001

    def colIDMap_actual():
        #If we are doing a merged bake, just create one image here
        if(mergedbake):
            functions.printmsg("We are doing a merged bake")
            #IMGNAME = f"MergedBake_{bpy.context.scene.batchName}_{mode}"
            IMGNAME = functions.gen_image_name("MergedBake", "special", f"ColID-{mode}")
            #UDIMs
            if bpy.context.scene.uv_mode == "udims":
                IMGNAME = IMGNAME+f".{udim_counter}"
            functions.create_Images(IMGNAME, "special", "")
    
        for obj in objects:
            OBJNAME = functions.trunc_if_needed(obj.name)
            materials = obj.material_slots
    
            if(not mergedbake):
                #Create the image we need for this bake (Delete if exists)
                if mode == "Colmap":
                    IMGNAME = functions.gen_image_name(OBJNAME, "special", "ColID")
                     #UDIMs
                    if bpy.context.scene.uv_mode == "udims":
                        IMGNAME = IMGNAME+f".{udim_counter}"
                else:
                    IMGNAME = functions.gen_image_name(OBJNAME, "special", "VertexCols")
                     #UDIMs
                    if bpy.context.scene.uv_mode == "udims":
                        IMGNAME = IMGNAME+f".{udim_counter}"
                functions.create_Images(IMGNAME, "special", "")
    
            for matslot in materials:
                mat = bpy.data.materials.get(matslot.name)
    
                #Make sure we are using nodes
                if not mat.use_nodes:
                    functions.printmsg(f"Material {mat.name} wasn't using nodes. Have enabled nodes")
                    mat.use_nodes = True
    
                nodetree = mat.node_tree
                nodes = nodetree.nodes
                links = nodetree.links
    
                m_output_node = functions.find_onode(nodetree)
    
                #Take a copy of material to restore at the end of the process
                functions.backupMaterial(mat)
    
                #Create emission shader and connect to material output
                emissnode = nodes.new("ShaderNodeEmission")
                emissnode.label = "SimpleBake"
                fromsocket = emissnode.outputs[0]
                tosocket = m_output_node.inputs[0]
                nodetree.links.new(fromsocket, tosocket)
    
                if mode == "Colmap":
                    #Using random colours
                    #Set emission node to random color
                    import random
                    randr = random.randint(5,10) / 10
                    randg = random.randint(5,10) / 10
                    randb = random.randint(5,10) / 10
                    emissnode.inputs["Color"].default_value = (randr, randg, randb, 1.0)
    
                #We are using vertex colours
                else:
                    #Using vertex colours
                    #Get name of active vertex colors for this object
                    col_name = obj.data.vertex_colors.active.name
                    #Create attribute node
                    attrnode = nodes.new("ShaderNodeAttribute")
                    #Set it to the active vertex cols
                    attrnode.attribute_name = col_name
                    #Connect
                    fromsocket = attrnode.outputs[0]
                    tosocket = emissnode.inputs[0]
                    nodetree.links.new(fromsocket, tosocket)
    
                #Create the image node and set to the bake texutre we are using
                imgnode = nodes.new("ShaderNodeTexImage")
                imgnode.image = bpy.data.images[IMGNAME]
                imgnode.label = "SimpleBake"
                functions.deselectAllNodes(nodes)
                imgnode.select = True
                nodetree.nodes.active = imgnode
    
            #Make sure only the object we want is selected (unless we are doing selected to active
            functions.selectOnlyThis(obj)
    
            #Bake
            functions.bakeoperation("Emission")
    
            #Restore the original materials
            functions.restoreAllMaterials()
    
            #If we are saving externally, and this is not a merged bake, save
            if(bpy.context.scene.saveExternal and not mergedbake):
                functions.printmsg("Saving baked images externally")
                functions.saveExternal(bpy.data.images[IMGNAME], "special")
    
        #If we did a merged bake, and we are saving externally, then save here
        if mergedbake and bpy.context.scene.saveExternal:
            functions.printmsg("Saving merged baked image externally")
            functions.saveExternal(bpy.data.images[IMGNAME], "special")

    
    #Bake at least once
    colIDMap_actual()
    udim_counter = udim_counter + 1
    
    #If we are doing UDIMs, we need to go back in
    if bpy.context.scene.uv_mode == "udims":
        
        while udim_counter < bpy.context.scene.udim_tiles + 1001:
            functions.printmsg(f"Going back in for tile {udim_counter}")
            for obj in objects:
                functions.UDIM_focustile(obj,udim_counter - 1001)
                
            colIDMap_actual()
        
            udim_counter = udim_counter + 1
    
    #Finished baking. Perform wind down actions
    #common_bake_finishing(objects, mergedbake, IMGNAME, "colidbake")




def doBake(selectedbakes):

    global lastbake_newuvs
    #global udim_counter
    udim_counter = 1001

    if bpy.context.scene.newUVoption:
        lastbake_newuvs = True
    else:
        lastbake_newuvs = False

    #This can never be selected to active, would not make sense
    bpy.context.scene.render.bake.use_selected_to_active = False

    objects = bpy.context.selected_objects

    batch_name = bpy.context.scene.batchName

    #Do the prep we need to do for all bake types
    common_bake_prep(objects)

    #Check for mergedback option
    mergedbake = bpy.context.scene.mergedBake

    #Bake tracking variables have just been cleared, set them now
    #Even with merged bake, it's still this calculation
    if bpy.context.scene.uv_mode == "udims":
        bake_status.total_operations = (len(selectedbakes) * bpy.context.scene.udim_tiles) * len(bpy.context.selected_objects)
    else:
        bake_status.total_operations = len(selectedbakes) * len(bpy.context.selected_objects)
        
    

    #Loop over the bake modes we are using
    
    def doBake_actual():
        
        IMGNAME = ""
    
        for thisbake in selectedbakes:
    
            #If we are doing a merged bake, just create one image here
            if(mergedbake):
                functions.printmsg("We are doing a merged bake")
                IMGNAME = functions.gen_image_name("Mergedbake", "pbr", thisbake)
                
                #UDIM testing
                if bpy.context.scene.uv_mode == "udims":
                    IMGNAME = IMGNAME+f".{udim_counter}"
                
                functions.create_Images(IMGNAME, thisbake, f"SB_merged_{batch_name}_{thisbake}")
    
    
            for obj in objects:
                #Reset the already processed list
                mats_done = []
    
                functions.printmsg(f"Baking object: {obj.name}")
    
    
                #Truncate if needed from this point forward
                OBJNAME = functions.trunc_if_needed(obj.name)
    
                #If we are not doing a merged bake
                #Create the image we need for this bake (Delete if exists)
                if(not mergedbake):
                    IMGNAME = functions.gen_image_name(obj.name, "pbr", thisbake)
    
                    #UDIM testing
                    if bpy.context.scene.uv_mode == "udims":
                        IMGNAME = IMGNAME+f".{udim_counter}"
    
                    functions.create_Images(IMGNAME, thisbake, f"SB_{obj.name}_{batch_name}_{thisbake}")
    
    
                #Prep the materials one by one
                materials = obj.material_slots
                for matslot in materials:
                    mat = bpy.data.materials.get(matslot.name)
    
                    if mat.name in mats_done:
                        functions.printmsg(f"Skipping material {mat.name}, already processed")
                        #Skip this loop
                        #We don't want to process any materials more than once or bad things happen
                        continue
                    else:
                        mats_done.append(mat.name)
    
                    #Make sure we are using nodes
                    if not mat.use_nodes:
                        functions.printmsg(f"Material {mat.name} wasn't using nodes. Have enabled nodes")
                        mat.use_nodes = True
    
                    nodetree = mat.node_tree
                    nodes = nodetree.nodes
    
                    #Take a copy of material to restore at the end of the process
                    functions.backupMaterial(mat)
    
                    #Create the image node and set to the bake texutre we are using
                    imgnode = nodes.new("ShaderNodeTexImage")
                    imgnode.image = bpy.data.images[IMGNAME]
                    imgnode.label = "SimpleBake"
    
                    #Remove all disconnected nodes so don't interfere with typing the material
                    functions.removeDisconnectedNodes(nodetree)
    
                    #Normal and emission bakes require no further material prep. Just skip the rest
                    if(thisbake != "normal" and thisbake != "emission"):
                        #Work out what type of material we are dealing with here and take correct action
                        mat_type = functions.getMatType(nodetree)
    
                        if(mat_type == "MIX"):
                            functions.setup_mix_material(nodetree, thisbake)
                        elif(mat_type == "PURE_E"):
                            functions.setup_pure_e_material(nodetree, thisbake)
                        elif(mat_type == "PURE_P"):
                            functions.setup_pure_p_material(nodetree, thisbake)
    
                    #Last action before leaving this material, make the image node selected and active
                    functions.deselectAllNodes(nodes)
                    imgnode.select = True
                    nodetree.nodes.active = imgnode
    
                #Select only this object
                functions.selectOnlyThis(obj)
    
                #Bake the object for this bake mode
                functions.bakeoperation(thisbake)
    
                #Update tracking
                bake_status.current_operation = bake_status.current_operation + 1
                functions.printmsg(f"Bake operation {bake_status.current_operation} of {bake_status.total_operations} complete")
                functions.write_bake_progress(bake_status.current_operation, bake_status.total_operations)
    
                #Restore the original materials
                functions.restoreAllMaterials()
    
                #If we are saving externally, and this isn't a merged bake, save
                if not mergedbake:
                    #Always do post processing
                    IMGNAME = do_post_processing(thisbake=thisbake, IMGNAME=IMGNAME)
                    if bpy.context.scene.saveExternal:
                        functions.printmsg("Saving baked images externally")
                        functions.saveExternal(bpy.data.images[IMGNAME], thisbake)
    
            #If we did a merged bake, and we are saving externally, then save here
            if mergedbake:
                #Always do post processing
                IMGNAME = do_post_processing(thisbake=thisbake, IMGNAME=IMGNAME)
                if bpy.context.scene.saveExternal:
                    functions.printmsg("Saving merged baked image externally")
                    functions.saveExternal(bpy.data.images[IMGNAME], thisbake)

    #Do the bake at least once
    doBake_actual()
    udim_counter = udim_counter + 1
    
    #If we are doing UDIMs, we need to go back in
    if bpy.context.scene.uv_mode == "udims":
        
        while udim_counter < bpy.context.scene.udim_tiles + 1001:
            functions.printmsg(f"Going back in for tile {udim_counter}")
            for obj in objects:
                functions.UDIM_focustile(obj,udim_counter - 1001)
                
            doBake_actual()
        
            udim_counter = udim_counter + 1
        
    
    #Finished baking. Perform wind down actions
    common_bake_finishing(objects, mergedbake, "pbrbake")



def doBakeS2A(selectedbakes):



    global lastbake_newuvs

    lastbake_newuvs = False

    if bpy.context.scene.newUVoption:
        lastbake_newuvs = True
    else:
        lastbake_newuvs = False

    targetobj = bpy.context.scene.targetobj
    batch_name = bpy.context.scene.batchName


    #We still need an objects list
    objects = bpy.context.selected_objects

    #Do the prep, as usual, but only on targetobject
    common_bake_prep([targetobj])

    #Bake tracking variables have just been cleared, set them now
    #For S2A, only one object
    bake_status.total_operations = len(selectedbakes)

    #Always set the ray distance to the one selected in SimpleBake
    functions.printmsg(f"Setting ray distance to {round(bpy.context.scene.ray_distance, 2)}")
    bpy.context.scene.render.bake.cage_extrusion = bpy.context.scene.ray_distance

    #Info
    functions.printmsg("Baking PBR maps to target mesh: " + targetobj.name)

    #Turn on Selected to Active bake
    bpy.context.scene.render.bake.use_selected_to_active = True

    #Loop over the bake modes we are using
    IMGNAME = ""

    for thisbake in selectedbakes:
        #We just need the one image for each bake mode, created at the target object
        functions.printmsg("We are bakikng PBR maps to target mesh")
        #IMGNAME = f"{functions.trunc_if_needed(targetobj.name)}_{bpy.context.scene.batchName}_{thisbake}"
        IMGNAME = functions.gen_image_name(targetobj.name, "pbr", thisbake)

        functions.create_Images(IMGNAME, thisbake, f"SB_{targetobj.name}_{batch_name}_{thisbake}")

        #Prep the target object
        materials = targetobj.material_slots
        for matslot in materials:
            mat = bpy.data.materials.get(matslot.name)

            #First, check if the material is using nodes. If not, enable
            if not mat.use_nodes:
                functions.printmsg(f"Material {mat.name} wasn't using nodes. Have enabled nodes")
                mat.use_nodes = True

            nodetree = mat.node_tree
            nodes = nodetree.nodes

            #Create the image node and set to the bake texutre we are using
            imgnode = nodes.new("ShaderNodeTexImage")
            imgnode.image = bpy.data.images[IMGNAME]
            imgnode.label = "SimpleBake"

            #Make the image node selected and active
            functions.deselectAllNodes(nodes)
            imgnode.select = True
            nodetree.nodes.active = imgnode

        #Now prep all the objects for this bake mode
        for obj in objects:
            #Reset the already processed list
            mats_done = []

            functions.printmsg(f"Preparing object: {obj.name}")
            OBJNAME = functions.trunc_if_needed(obj.name)

            #Prep the materials one by one
            materials = obj.material_slots
            for matslot in materials:
                mat = bpy.data.materials.get(matslot.name)

                if mat.name in mats_done:
                    #Skip this loop
                    #We don't want to process any materials more than once or bad things happen
                    continue
                else:
                    mats_done.append(mat.name)

                nodetree = mat.node_tree
                nodes = nodetree.nodes

                #Take a copy of material to restore at the end of the process
                functions.backupMaterial(mat)

                #Remove all disconnected nodes so don't interfere with typing the material
                functions.removeDisconnectedNodes(nodetree)

                #Normal and emission bakes require no further material prep. Just skip the rest
                if(thisbake != "normal" and thisbake != "emission"):
                    #Work out what type of material we are dealing with here and take correct action
                    mat_type = functions.getMatType(nodetree)

                    if(mat_type == "MIX"):
                        functions.setup_mix_material(nodetree, thisbake)
                    elif(mat_type == "PURE_E"):
                        functions.setup_pure_e_material(nodetree, thisbake)
                    elif(mat_type == "PURE_P"):
                        functions.setup_pure_p_material(nodetree, thisbake)

            #Make sure that correct objects are selected right before bake
            bpy.ops.object.select_all(action="DESELECT")
            for obj in objects:
                obj.select_set(True)
            targetobj.select_set(True)
            bpy.context.view_layer.objects.active = targetobj

            #Bake the object for this bake mode
            functions.bakeoperation(thisbake)

            #Update tracking
            bake_status.current_operation = bake_status.current_operation + 1
            functions.printmsg(f"Bake operation {bake_status.current_operation} of {bake_status.total_operations} complete")
            functions.write_bake_progress(bake_status.current_operation, bake_status.total_operations)

        #Restore the original materials
        functions.restoreAllMaterials()


        #Delete that image node we created at the target object
        materials = targetobj.material_slots
        for matslot in materials:
            mat = bpy.data.materials.get(matslot.name)
            for node in mat.node_tree.nodes:
                if node.label == "SimpleBake":
                    mat.node_tree.nodes.remove(node)

        #Always do post processing
        IMGNAME = do_post_processing(thisbake=thisbake, IMGNAME=IMGNAME)

        #If we are saving externally, save
        if(bpy.context.scene.saveExternal):
            functions.printmsg("Saving baked images externally")
            functions.saveExternal(bpy.data.images[IMGNAME], thisbake)

    #Finished baking all bake modes. Perform wind down actions
    common_bake_finishing([targetobj], False, "pbrbake")

def sketchfabupload(caller):
    functions.printmsg("Sketchfab Upload Beginning")

    ########################
    #Check SB_createdfrom property. Only upload copied and applied.
    #Change tooltips
    #Change poll (check for above property)
    ########################


    #Get the currently selected objects
    target_objs_list = bpy.context.selected_objects
    images_imgs = []
    #batch_name = bpy.context.scene.batchName

    #Get all the textures being used by our objejects. Should only have one material each
    for obj in target_objs_list:
        nodes = obj.material_slots[0].material.node_tree.nodes
        for node in nodes:
            if node.bl_idname == "ShaderNodeTexImage":
                images_imgs.append(node.image)

    #Create a temp folder for SFUpload in the folder where blend saved
    f = Path(bpy.data.filepath)
    f = f.parents[0]
    f = f / "SFUpload"

    try:
        os.mkdir(str(f))
    except:
        pass

    #Save each image into that folder
    writtenfilenames_strlist = []
    for img in images_imgs:
        #Could be internal or externally saved
        op = img.filepath
        try:
            off = img.fileformat
        except:
            off = False

        img.filepath = str(f / functions.cleanFileName(img.name))

        if not ".png" in img.filepath:
            img.filepath = img.filepath + ".png"

        if off:
            img.fileformat = "PNG"

        img.save()
        writtenfilenames_strlist.append(Path(img.filepath).parts[-1])

        img.filepath = op
        if off:
            img.fileformat = off


    #Export the fbx (we might have multiple objects)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in target_objs_list:
        obj.select_set(state=True)

    filename = (functions.getFileName()).replace(".blend", "")
    bpy.ops.export_scene.fbx(filepath=str(f / f"{filename}.fbx"), check_existing=False, use_selection=True, use_mesh_modifiers=True, use_mesh_modifiers_render=True, path_mode="STRIP")


    #Zip it up
    from zipfile import ZipFile

    zip_path = str(f / f"{filename}.zip")
    zip = ZipFile(str(zip_path), mode="w")
    for fn in writtenfilenames_strlist:
        zip.write(str(f / fn), arcname=fn)


    #And now the fbx
    zip.write(str(f / f"{filename}.fbx"), arcname=f"{filename}.fbx")
    zip.close()



    #Get Sketchfab API
    preferences = bpy.context.preferences
    addon_prefs = preferences.addons[__package__].preferences
    apikey = addon_prefs.apikey

    #Call Sketchfab Upload
    from . import sketchfabapi
    upload_url = sketchfabapi.upload(zip_path, functions.getFileName(), apikey)

    if not upload_url:
        functions.printmsg("Upload to Sketchfab failed. See console messages for details")
        return False
    else:
        #Open URL that is returned
        import webbrowser
        webbrowser.open(upload_url, new=0, autoraise=True)
        functions.printmsg("Upload complete. Your web broswer should have opened.")

    #Delete Zip file
    #import os
    #os.remove(zip_path)

    #return True

