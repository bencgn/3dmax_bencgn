import bpy
import sys
import subprocess
import os
from . import functions
from . import bakefunctions
from .bg_bake import bgbake_ops
from pathlib import Path
import tempfile

from .ui import SimpleBakePreferences


def bakestolist():
    #Assemble properties into list
    selectedbakes = []
    selectedbakes.append("diffuse") if bpy.context.scene.selected_col else False
    selectedbakes.append("metalness") if bpy.context.scene.selected_metal else False
    selectedbakes.append("roughness") if bpy.context.scene.selected_rough else False
    selectedbakes.append("normal") if bpy.context.scene.selected_normal else False
    selectedbakes.append("transparency") if bpy.context.scene.selected_trans else False
    selectedbakes.append("transparencyroughness") if bpy.context.scene.selected_transrough else False
    selectedbakes.append("clearcoat") if bpy.context.scene.selected_clearcoat else False
    selectedbakes.append("clearcoatroughness") if bpy.context.scene.selected_clearcoat_rough else False
    selectedbakes.append("emission") if bpy.context.scene.selected_emission else False
    selectedbakes.append("specular") if bpy.context.scene.selected_specular else False
    selectedbakes.append("alpha") if bpy.context.scene.selected_alpha else False
    
    selectedbakes.append("sss") if bpy.context.scene.selected_sss else False
    selectedbakes.append("ssscol") if bpy.context.scene.selected_ssscol else False
    
    return selectedbakes


class OBJECT_OT_simple_bake_mapbake(bpy.types.Operator):
    """Bake the PBR Maps based on your settings"""
    bl_idname = "object.simple_bake_mapbake"
    bl_label = "Bake PBR Maps"

    @classmethod
    def poll(cls, context):
        
        """
        ok = False
        for obj in bpy.context.selected_objects:
            try:
                obj["SB_createdfrom"]
                ok = False
            except:
                ok = True
        
        """
        ok = True
        return ok
    
    def execute(self, context):
        
        selectedbakes = bakestolist()
        
        #If we have been called in background mode, just get on with it. Checks should be done.
        if "--background" in sys.argv:
            try:
                bpy.data.collections.remove(bpy.data.collections["SimpleBake_Bakes"])
            except:
                pass
            
            #Bake
            if bpy.context.scene.selected_s2a:
                bakefunctions.doBakeS2A(selectedbakes)
            else:
                bakefunctions.doBake(selectedbakes)
            
            self.report({"INFO"}, "Bake complete")
            return {'FINISHED'}
            
         
        #If not, do the usual checks
        result = functions.startingChecks(bpy.context.selected_objects, "pbrbake")
        if(not result[0]):
            #self.report({"ERROR"}, "ERROR: " + result[1])
            return {"CANCELLED"}
                          
        
        #If the user requested background mode, fire that up now and exit
        
        #Do common bake prep early so we get to keep the UVs etc.
        #objects = bpy.context.selected_objects
        #bakefunctions.common_bake_prep(objects)
        
        
        if bpy.context.scene.bgbake == "bg":
            bpy.ops.wm.save_mainfile()
            filepath = filepath = bpy.data.filepath
            process = subprocess.Popen(
                [bpy.app.binary_path, "--background",filepath, "--python-expr",\
                "import bpy;\
                import os;\
                from pathlib import Path;\
                savepath=Path(bpy.data.filepath).parent / (str(os.getpid()) + \".blend\");\
                bpy.ops.wm.save_as_mainfile(filepath=str(savepath), check_existing=False);\
                bpy.ops.object.simple_bake_mapbake();"],
                shell=False)
                        
            bgbake_ops.bgops_list.append([process, bpy.context.scene.prepmesh, bpy.context.scene.hidesourceobjects])            
            
            self.report({"INFO"}, "Background bake process started")
            return {'FINISHED'}
        
        #If we are doing this here and now, get on with it
        if bpy.context.scene.selected_s2a:
            bakefunctions.doBakeS2A(selectedbakes)
        else:
            bakefunctions.doBake(selectedbakes)
        
        self.report({"INFO"}, "Bake complete")
        return {'FINISHED'}

class OBJECT_OT_simple_bake_sketchfabupload(bpy.types.Operator):
    """You can only upload (an) object(s) created with the "Copy objects and apply bakes" option. If this button is grayed out, you haven't got the correct objects selected.
Not available if .blend file not saved or if no Sketchfab API key set in user preferences. 
Get your API key from the account section of Sketchfab.com"""
    bl_idname = "object.simple_bake_sketchfabupload"
    bl_label = "Upload to Sketchfab"
    
    @classmethod
    def poll(cls, context):
        for obj in bpy.context.selected_objects:
            try:
                obj["SB_createdfrom"]
            except:
                return False
        
        try:
            bpy.context.active_object["SB_createdfrom"]
        except:
            return False
        
        return True
    
    def execute(self, context):
        selectedbakes = bakestolist()
        
        result = functions.startingChecks(bpy.context.selected_objects, "sfupload")
        
        if(not result[0]):
            #self.report({"ERROR"}, "ERROR: " + result[1])
            return {"CANCELLED"}
        
        result = bakefunctions.sketchfabupload(self)
        
        if result:
            self.report({"INFO"}, "Upload operation complete. Your web browser should have opened. Check console for any errors.")
            return {'FINISHED'}
        else:
            return {'CANCELLED'}
        


class OBJECT_OT_simple_bake_specials(bpy.types.Operator):
    """Bake a colourID map (random colour per material)"""
    bl_idname = "object.simple_bake_specials"
    bl_label = "Bake Selected Special Maps"
    
    
    def execute(self, context):
        
        #If we are running in the background, just get on with it. All checks should be complete
        if "--background" in sys.argv:
            try:
                bpy.data.collections.remove(bpy.data.collections["SimpleBake_Bakes"])
            except:
                pass
            
            bakefunctions.specialsBake(context.scene.imgwidth, context.scene.imgheight)
            self.report({"INFO"}, "Bake complete")
            return {'FINISHED'} 
        
        #Otherwise, do usual checks 
        result = functions.startingChecks(bpy.context.selected_objects, "specials")
        if(not result[0]):
            #self.report({"ERROR"}, "ERROR: " + result[1])
            return {"CANCELLED"}

        #If the user requested baking in the background, fire off a process to do that
        if bpy.context.scene.bgbake == "bg":
            bpy.ops.wm.save_mainfile()
            filepath = filepath = bpy.data.filepath
            
            process = subprocess.Popen(
                [bpy.app.binary_path, "--background",filepath, "--python-expr",\
                "import bpy;\
                import os;\
                from pathlib import Path;\
                savepath=Path(bpy.data.filepath).parent / (str(os.getpid()) + \".blend\");\
                bpy.ops.wm.save_as_mainfile(filepath=str(savepath), check_existing=False);\
                bpy.ops.object.simple_bake_specials();"],
                shell=False)
            
            bgbake_ops.bgops_list.append([process, bpy.context.scene.prepmesh, bpy.context.scene.hidesourceobjects])
            self.report({"INFO"}, "Background bake process started")
            return {'FINISHED'}
        
        #Or, if we are doing it right here and right now, do that
        bakefunctions.specialsBake(context.scene.imgwidth, context.scene.imgheight)
        self.report({"INFO"}, "Bake complete")
        return {'FINISHED'}


class OBJECT_OT_simple_bake_cyclesbake(bpy.types.Operator):
    """'Traditional' bake based on cycles settings (usually the panel above this one)"""
    bl_idname = "object.simple_bake_cyclesbake"
    bl_label = "Bake Using Cycles"
    
    @classmethod

    def poll(cls, context):
        """
        ok = False
        for obj in bpy.context.selected_objects:
            try:
                obj["SB_createdfrom"]
                ok = False
            except:
                ok = True
        """    
        ok = True
        return ok
    
    def execute(self, context): 
        
        #If we are running in the background, just get on with it. All checks should be complete
        if "--background" in sys.argv:
            try:
                bpy.data.collections.remove(bpy.data.collections["SimpleBake_Bakes"])
            except:
                pass
            bakefunctions.cyclesBake()
            self.report({"INFO"}, "Bake complete")
            return {'FINISHED'}            
        
        
        #Make sure certian things are in sync
        if context.scene.cycles_s2a is True:
            context.scene.render.bake.use_selected_to_active = True
        else:
            context.scene.render.bake.use_selected_to_active = False
        
        
        #Flag this is a cycles bake with True as second argument
        result = functions.startingChecks(bpy.context.selected_objects, "cyclesbake")
        if(not result[0]):
            #self.report({"ERROR"}, "ERROR: " + result[1])
            return {"CANCELLED"}
                       
        
        #If the user requested baking in the background, fire off a process to do that
        if bpy.context.scene.bgbake == "bg":
            bpy.ops.wm.save_mainfile()
            filepath = filepath = bpy.data.filepath
            
            process = subprocess.Popen(
                [bpy.app.binary_path, "--background",filepath, "--python-expr",\
                "import bpy;\
                import os;\
                from pathlib import Path;\
                savepath=Path(bpy.data.filepath).parent / (str(os.getpid()) + \".blend\");\
                bpy.ops.wm.save_as_mainfile(filepath=str(savepath), check_existing=False);\
                bpy.ops.object.simple_bake_cyclesbake();"],
                shell=False)
                        
            bgbake_ops.bgops_list.append([process, bpy.context.scene.prepmesh, bpy.context.scene.hidesourceobjects])
            self.report({"INFO"}, "Background bake process started")
            return {'FINISHED'}
        
        
        #If we are doing this right here right now, let's go
        bakefunctions.cyclesBake()
        self.report({"INFO"}, "Bake complete")
        return {'FINISHED'}


class OBJECT_OT_simple_bake_selectall(bpy.types.Operator):
    """Select all PBR bake types"""
    bl_idname = "object.simple_bake_selectall"
    bl_label = "Select All"
    
    def execute(self, context):
        bpy.context.scene.selected_col = True
        bpy.context.scene.selected_metal = True
        bpy.context.scene.selected_rough = True
        bpy.context.scene.selected_normal = True
        bpy.context.scene.selected_trans = True
        bpy.context.scene.selected_transrough = True
        bpy.context.scene.selected_emission = True
        bpy.context.scene.selected_clearcoat = True
        bpy.context.scene.selected_clearcoat_rough = True
        bpy.context.scene.selected_specular = True
        bpy.context.scene.selected_alpha = True
        bpy.context.scene.selected_sss = True
        bpy.context.scene.selected_ssscol = True
        return {'FINISHED'}

class OBJECT_OT_simple_bake_selectnone(bpy.types.Operator):
    """Select none PBR bake types"""
    bl_idname = "object.simple_bake_selectnone"
    bl_label = "Select None"
    
    def execute(self, context):
        bpy.context.scene.selected_col = False
        bpy.context.scene.selected_metal = False
        bpy.context.scene.selected_rough = False
        bpy.context.scene.selected_normal = False
        bpy.context.scene.selected_trans = False
        bpy.context.scene.selected_transrough = False
        bpy.context.scene.selected_emission = False
        bpy.context.scene.selected_clearcoat = False
        bpy.context.scene.selected_clearcoat_rough = False
        bpy.context.scene.selected_specular = False
        bpy.context.scene.selected_alpha = False
        bpy.context.scene.selected_sss = False
        bpy.context.scene.selected_ssscol = False
        return {'FINISHED'}

class OBJECT_OT_simple_bake_installupdate(bpy.types.Operator):
    """Download and install the most recent version of SimpleBake"""
    bl_idname = "object.simple_bake_installupdate"
    bl_label = "Download and Install Update"
    
    def execute(self, context):
        global justupdated
        result = functions.install_addon_update()
        
        if result[0] == True:
            self.report({"INFO"}, "Update complete. Restart Blender")
            SimpleBakePreferences.justupdated = True
        else:
            self.report({"ERROR"}, f"Could not download update. Error: {result[1]}")
            justupdated = False
        return {'FINISHED'} 

class OBJECT_OT_simple_bake_default_imgname_string(bpy.types.Operator):
    """Reset the image name string to default (Sketchfab compatible)"""
    bl_idname = "object.simple_bake_default_imgname_string"
    bl_label = "Restore image string to default"
    
    def execute(self, context):
        from .ui import SimpleBakePreferences
        SimpleBakePreferences.reset_img_string()
        
        return {'FINISHED'} 

class OBJECT_OT_simple_bake_default_aliases(bpy.types.Operator):
    """Reset the image name string to default (Sketchfab compatible)"""
    bl_idname = "object.simple_bake_default_aliases"
    bl_label = "Restore all bake type aliases to default"
    
    def execute(self, context):
        from .ui import SimpleBakePreferences
        SimpleBakePreferences.reset_aliases()
        
        return {'FINISHED'} 
        
class OBJECT_OT_simple_bake_bgbake_status(bpy.types.Operator):
    """Check on the status of bakes running in the background"""
    bl_idname = "object.simple_bake_bgbake_status"
    bl_label = "Check on the status of bakes running in the background"
    
    def execute(self, context):
        msg_items = []
        
        
        #Display remaining
        if len(bgbake_ops.bgops_list) == 0:
            msg_items.append("No background bakes are currently running")
        
        else:
            msg_items.append(f"--------------------------")
            for p in bgbake_ops.bgops_list:
                
                t = Path(tempfile.gettempdir())
                t = t / f"SimpleBake_Bgbake_{str(p[0].pid)}"            
                try:
                    with open(str(t), "r") as progfile:
                        progress = progfile.readline()
                except:
                    #No file yet, as no bake operation has completed yet. Holding message
                    progress = 0
                
                msg_items.append(f"RUNNING: Process ID: {str(p[0].pid)} - Progress {progress}%")
                msg_items.append(f"--------------------------")
            
        functions.ShowMessageBox(msg_items, "Background Bake Status(es)")
        
        return {'FINISHED'} 

class OBJECT_OT_simple_bake_bgbake_import(bpy.types.Operator):
    """Import baked objects previously baked in the background"""
    bl_idname = "object.simple_bake_bgbake_import"
    bl_label = "Import baked objects previously baked in the background"
    
    def execute(self, context):
        
        if bpy.context.mode != "OBJECT":
            self.report({"ERROR"}, "You must be in object mode")
            return {'CANCELLED'} 
            
        
        
        for p in bgbake_ops.bgops_list_finished:
            
            savepath = Path(bpy.data.filepath).parent
            pid_str = str(p[0].pid)
            path = savepath / (pid_str + ".blend")
            path = str(path) + "\\Collection\\"
            
            #Record the objects and collections before append (as append doesn't give us a reference to the new stuff)
            # objects_before_names = []
            # for obj in bpy.data.objects:
                # objects_before_names.append(obj.name)
            # cols_before_names = []
            # for col in bpy.data.collections:
                # cols_before_names.append(col.name)
            # images_before_names = []
            # for img in bpy.data.images:
                # images_before_names.append(img.name)
            
            
            functions.spot_new_items(initialise=True, item_type="objects")
            functions.spot_new_items(initialise=True, item_type="collections")
            functions.spot_new_items(initialise=True, item_type="images")
            
            
            #Append
            bpy.ops.wm.append(filename="SimpleBake_Bakes", directory=path, use_recursive=False, active_collection=False)
            
            #No idea why we have to do this, but apparently we do
            for img in bpy.data.images:
                try:
                    if img["SB"] != "":
                        img.filepath = img.filepath.replace("../../", "")
                except:
                    pass
            
            
            
            #If we didn't actually want the objects, delete them
            if not p[1]:
                #Delete objects we just imported (leaving only textures)
                
                # for obj in bpy.data.objects:
                    # if not obj.name in objects_before_names:
                        # bpy.data.objects.remove(obj)
                # for col in bpy.data.collections:
                    # if not col.name in cols_before_names:
                        # bpy.data.collections.remove(col)
                
                for ob_name in functions.spot_new_items(initialise=False, item_type = "objects"):
                    bpy.data.objects.remove(bpy.data.objects[obj_name])
                for col_name in functions.spot_new_items(initialise=False, item_type = "collections"):
                    bpy.data.collections.remove(bpy.data.collections[col_name])                
            
                        
            #If we have to hide the source objects, do it
            if p[2]:
                objects_before_names = functions.spot_new_items(initialise=False, item_type="objects")
                
                for obj in bpy.data.objects:
                    if not obj.name in objects_before_names:
                        if obj.name.replace("_Baked", "") in bpy.data.objects:
                            bpy.data.objects[obj.name.replace("_Baked", "")].hide_set(True)
            
            #Delete the temp blend file
            try:
                os.remove(str(savepath / pid_str) + ".blend")
                os.remove(str(savepath / pid_str) + ".blend1")
            except:
                pass
        
        #Clear list for next time
        bgbake_ops.bgops_list_finished = []
        
        
        #Confirm back to user
        self.report({"INFO"}, "Import complete")
        
        messagelist = []
        #messagelist.append(f"{len(bpy.data.objects)-len(objects_before_names)} objects imported")
        #messagelist.append(f"{len(bpy.data.images)-len(images_before_names)} textures imported")
        
        messagelist.append(f"{len(functions.spot_new_items(initialise=False, item_type='objects'))} objects imported")
        messagelist.append(f"{len(functions.spot_new_items(initialise=False, item_type='images'))} textures imported")
        
        functions.ShowMessageBox(messagelist, "Import complete", icon = 'INFO')
        

        #If we imported an image, and we already had an image with the same name, get rid of the original in favour of the imported
        new_images_names = functions.spot_new_items(initialise=False, item_type="images")
        
        
        # images_before_names #We have a list of the names before
        # #Get a list of the names after
        # images_after_names = []
        # for img in bpy.data.images:
            # images_after_names.append(img.name)
        
        # #Compaure lists
        # new_images_names = functions.diff(images_after_names, images_before_names)
        
        #Find any .001s
        for imgname in new_images_names:
            try:
                int(imgname[-3:])
                
                #Delete the existing version
                bpy.data.images.remove(bpy.data.images[imgname[0:-4]])
                
                #Rename our version
                bpy.data.images[imgname].name = imgname[0:-4]
                
            except ValueError:
                pass
                
                
        return {'FINISHED'} 

class OBJECT_OT_simple_bake_bgbake_clear(bpy.types.Operator):
    """Delete the background bakes because you don't want to import them into Blender. NOTE: If you chose to save bakes or FBX externally, these are safe and NOT deleted. This is just if you don't want to import into this Blender session"""
    bl_idname = "object.simple_bake_bgbake_clear"
    bl_label = "Delete the background bakes"
    
    def execute(self, context):
        savepath = Path(bpy.data.filepath).parent
        
        for p in bgbake_ops.bgops_list_finished:
            pid_str = str(p[0].pid)
            try:
                os.remove(str(savepath / pid_str) + ".blend")
                os.remove(str(savepath / pid_str) + ".blend1")
            except:
                pass
        
        bgbake_ops.bgops_list_finished = []
        
        return {'FINISHED'} 
