import bpy
import os

#p list
#   process object
#   bool copy object and apply
#   bool hide objects


class bgbake_ops():
    bgops_list = []
    bgops_list_last = []
    bgops_list_finished = []

def remove_dead():
    
    #Remove dead processes from current list
    for p in bgbake_ops.bgops_list:
        if p[0].poll() == 0:
            #if p[1] is True:
                #Only go to finished list if true (i.e. prepmesh was selected)
                #bgbake_ops.bgops_list_finished.append(p)
            
            bgbake_ops.bgops_list_finished.append(p)
            bgbake_ops.bgops_list.remove(p)
    
    return 1 #1 second timer
    
bpy.app.timers.register(remove_dead, persistent=True)


def check_merged_bake_setting():
	
	if len(bpy.context.selected_objects)<2:
		bpy.context.scene.mergedBake = False

	return 1 #1 second timer

bpy.app.timers.register(check_merged_bake_setting, persistent=True)
