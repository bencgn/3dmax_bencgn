bl_info = {
    "name": "SimpleBake",
    "author": "Lewis <simplebake@toohey.co.uk>",
    "version": (5, 1, 2),
    "blender": (2, 80, 0),
    "location": "Properties Panel -> Render Settings Tab",
    "description": "Simple baking of PBR maps",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object",
}


import bpy
import os
from . import bakefunctions
from . import functions
from . import bg_bake

#Import classes
from .operators import (OBJECT_OT_simple_bake_mapbake, OBJECT_OT_simple_bake_sketchfabupload, OBJECT_OT_simple_bake_specials, OBJECT_OT_simple_bake_cyclesbake,
OBJECT_OT_simple_bake_selectall, OBJECT_OT_simple_bake_selectnone, OBJECT_OT_simple_bake_installupdate, OBJECT_OT_simple_bake_default_imgname_string,
OBJECT_OT_simple_bake_default_aliases, OBJECT_OT_simple_bake_bgbake_status, OBJECT_OT_simple_bake_bgbake_import, OBJECT_OT_simple_bake_bgbake_clear)
from .ui import (OBJECT_PT_simple_bake_panel, OBJECT_PT_simple_bake_panel, SimpleBakePreferences, OBJECT_OT_simple_bake_releasenotes)            

#Classes list for register
#List of all classes that will be registered
classes = ([OBJECT_OT_simple_bake_mapbake, OBJECT_OT_simple_bake_sketchfabupload, OBJECT_OT_simple_bake_specials, OBJECT_OT_simple_bake_cyclesbake,
        OBJECT_OT_simple_bake_selectall, OBJECT_OT_simple_bake_selectnone, OBJECT_OT_simple_bake_installupdate,
        OBJECT_PT_simple_bake_panel, OBJECT_OT_simple_bake_releasenotes, SimpleBakePreferences, OBJECT_OT_simple_bake_default_imgname_string, OBJECT_OT_simple_bake_default_aliases, OBJECT_OT_simple_bake_bgbake_status, OBJECT_OT_simple_bake_bgbake_import, OBJECT_OT_simple_bake_bgbake_clear])




def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)


#---------------------UPDATE FUNCTIONS--------------------------------------------

def tex_per_mat_update(self, context):
    if context.scene.tex_per_mat == False:
        context.scene.prepmesh = False
        context.scene.hidesourceobjects = False
        context.scene.mergedBake = False
        context.scene.expand_mat_uvs = False
        
    
def expand_mat_uvs_update(self, context):
    context.scene.newUVoption = False
    context.scene.prefer_existing_sbmap = False

def prepmesh_update(self, context):
    if context.scene.prepmesh == False:
        context.scene.hidesourceobjects = False
    else:
        context.scene.hidesourceobjects = True
    
def exportfileformat_update(self,context):
    if context.scene.exportfileformat == "JPEG":
        context.scene.everything16bit = False

def texture_res_update(self, context):
    if context.scene.texture_res == "Test":
        context.scene.imgheight = 128
        context.scene.imgwidth = 128
        context.scene.render.bake.margin = 2

    elif context.scene.texture_res == "1k":
        context.scene.imgheight = 1024
        context.scene.imgwidth = 1024
        context.scene.render.bake.margin = 10
        
    elif context.scene.texture_res == "2k":
        context.scene.imgheight = 1024*2
        context.scene.imgwidth = 1024*2
        context.scene.render.bake.margin = 14
        
    elif context.scene.texture_res == "3k":
        context.scene.imgheight = 1024*3
        context.scene.imgwidth = 1024*3
        context.scene.render.bake.margin = 18
        
    elif context.scene.texture_res == "4k":
        context.scene.imgheight = 1024*4
        context.scene.imgwidth = 1024*4
        context.scene.render.bake.margin = 20

    elif context.scene.texture_res == "5k":
        context.scene.imgheight = 1024*5
        context.scene.imgwidth = 1024*5
        context.scene.render.bake.margin = 24

    elif context.scene.texture_res == "6k":
        context.scene.imgheight = 1024*6
        context.scene.imgwidth = 1024*6
        context.scene.render.bake.margin = 28
        
        
def alpha_update(self, context):
    bpy.context.scene.mergedBake = False
    
def s2a_update(self, context):
    bpy.context.scene.mergedBake = False
    
def saveExternal_update(self, context):
    if bpy.context.scene.saveExternal == False:
        bpy.context.scene.everything16bit = False
        bpy.context.scene.rundenoise = False
        
        bpy.context.scene.uv_mode = "normal"
        
def repackUVs_update(self, context):
    pass

def newUVoption_update(self, context):
    if bpy.context.scene.newUVoption == True:
        bpy.context.scene.prefer_existing_sbmap = False
        #bpy.context.scene.repackUVs = False
        
def prefer_existing_sbmap_update(self, context):
    pass
        
def ray_distance_update(self, context):
    pass

def mergedBake_update(self, context):
    #if bpy.context.scene.newUVmethod == "SmartUVProject_Individual" and bpy.context.scene.mergedBake:
        #ShowMessageBox("This combination of options probably isn't what you want. You are unwrapping multiple objects individually, and then baking them all to one texture. The bakes will be on top of each other.", "Warning", "MONKEY")
    pass

def newUVmethod_update(self, context):
    pass
    #if bpy.context.scene.newUVmethod == "SmartUVProject_Individual" and bpy.context.scene.mergedBake:
        #ShowMessageBox("This combination of options probably isn't what you want. You are unwrapping multiple objects individually, and then baking them all to one texture. The bakes will be on top of each other.", "Warning", "MONKEY")


def global_mode_update(self, context):
    
    if not bpy.context.scene.global_mode == "cycles_bake":
        bpy.context.scene.tex_per_mat = False
        bpy.context.scene.expand_mat_uvs = False
    
    if not bpy.context.scene.global_mode == "pbr_bake":
        bpy.context.scene.selected_s2a = False
        
    if bpy.context.scene.global_mode == "specials_bake":
        bpy.context.scene.prepmesh = False
        bpy.context.scene.hidesourceobjects = False
        bpy.context.scene.bgbake = "fg"


def cycles_s2a_update(self, context):
    if context.scene.cycles_s2a:
        context.scene.render.bake.use_selected_to_active = True
        context.scene.mergedBake = False
    else:
        context.scene.render.bake.use_selected_to_active = False


def pack_master_switch_update(self,context):
    #Turn off all packing
    if not context.scene.pack_master_switch:
        context.scene.pack_gloss2metal_alpha = False


def selected_rough_update(self,context):
    if context.scene.selected_rough == False:
        context.scene.pack_gloss2metal_alpha = False


def selected_metal_update(self,context):
    if context.scene.selected_metal == False:
        context.scene.pack_gloss2metal_alpha = False
        
def bgbake_update(self,context):
    pass
    
    
def uv_mode_update(self, context):
    if context.scene.uv_mode == "udims":
        context.scene.newUVoption = False
 
#-------------------END UPDATE FUNCTIONS----------------------------------------------

def register():
    
    global bl_info
    version = bl_info["version"]
    version = str(version[0]) + str(version[1]) + str(version[2])
    current = functions.checkAtCurrentVersion(version) 
    
    OBJECT_PT_simple_bake_panel.current = current
    OBJECT_PT_simple_bake_panel.version = f"{str(version[0])}.{str(version[1])}.{str(version[2])}"
    
    
    #Global variables
    des = "Global Baking Mode"
    bpy.types.Scene.global_mode = bpy.props.EnumProperty(name="Bake Mode", default="pbr_bake", description=des, items=[
    ("pbr_bake", "PBR Bake", "Bake PBR maps from materials created around the Principled BSDF and Emission shaders"),
    ("cycles_bake", "Cycles Bake", "Bake the 'traditional' cycles bake modes, configured in the default Blender bake panel (usually above the SimpleBake panel)"),
    ("specials_bake", "Specials Bake", "Bake special maps")
    ], update = global_mode_update)
    
    des = "Texture Resolution"
    bpy.types.Scene.texture_res = bpy.props.EnumProperty(name="Texture Resolution", default="1k", description=des, items=[
    ("Custom", "Custom", "Allows you to set a custom texture resolution"),
    ("Test", "Test", "Texture Resolution of 128 x 128 (for a quick, low resolution test"),
    ("1k", "1k", f"Texture Resolution of 1024 x 1024"),
    ("2k", "2k", f"Texture Resolution of {1024*2} x {1024*2}"),
    ("3k", "3k", f"Texture Resolution of {1024*3} x {1024*3}"),
    ("4k", "4k", f"Texture Resolution of {1024*4} x {1024*4}"),
    ("5k", "5k", f"Texture Resolution of {1024*5} x {1024*5}"),
    ("6k", "6k", f"Texture Resolution of {1024*6} x {1024*6}")
    ], update = texture_res_update)
    
    
    des = "Distance to cast rays from target object to selected object(s)"
    bpy.types.Scene.ray_distance = bpy.props.FloatProperty(name="Ray Distance", default = 0.2, description=des, update=ray_distance_update)
    bpy.types.Scene.ray_warning_given = bpy.props.BoolProperty(default = False)
    
    #des = "Normal map images are always 32bit float internal images. Tick this if you want all internal images to be created as 32bit float. Image quality is theoretically increased, but often it will not be noticable for images not containing normal or bump information"
    #bpy.types.Scene.everything32bitfloat = bpy.props.BoolProperty(name="All internal 32bit float", default = False, description=des)
    des = "Normal map images are always exported as 16bit. Tick this if you want all images to be exported as 16bit (else 8bit). Not available with jpgs. Image quality is theoretically increased, but often it will not be noticable for images not containing normal or bump information"
    bpy.types.Scene.everything16bit = bpy.props.BoolProperty(name="All exports 16bit", default = False, description=des)
    
    des = "Bake a PBR Colour map"
    bpy.types.Scene.selected_col = bpy.props.BoolProperty(name="Diffuse", default = True, description=des)
    des = "Bake a PBR Metalness map"
    bpy.types.Scene.selected_metal = bpy.props.BoolProperty(name="Metal", description=des, update=selected_metal_update)
    des = "Bake a PBR Roughness or Glossy map"
    bpy.types.Scene.selected_rough = bpy.props.BoolProperty(name="Roughness/Glossy", description=des, update=selected_rough_update)
    des = "Bake a Normal map"
    bpy.types.Scene.selected_normal = bpy.props.BoolProperty(name="Normal", description=des)
    des = "Bake a PBR Transmission map"
    bpy.types.Scene.selected_trans = bpy.props.BoolProperty(name="Transmission", description=des)
    des = "Bake a PBR Transmission Roughness map"
    bpy.types.Scene.selected_transrough = bpy.props.BoolProperty(name="Transmission Rough", description=des)
    des = "Bake an Emission map"
    bpy.types.Scene.selected_emission = bpy.props.BoolProperty(name="Emission", description=des)
    des = "Bake a PBR Clearcoat map"
    
    bpy.types.Scene.selected_sss = bpy.props.BoolProperty(name="SSS", description=des)
    des = "Bake a Subsurface map"
    bpy.types.Scene.selected_ssscol = bpy.props.BoolProperty(name="SSS Col", description=des)
    des = "Bake a Subsurface colour map"
    
    bpy.types.Scene.selected_clearcoat = bpy.props.BoolProperty(name="Clearcoat", description=des)
    des = "Bake a PBR Clearcoat Roughness map"
    bpy.types.Scene.selected_clearcoat_rough = bpy.props.BoolProperty(name="Clearcoat Roughness", description=des)
    des = "Bake a Specular/Reflection map"
    bpy.types.Scene.selected_specular = bpy.props.BoolProperty(name="Specular", description=des)
    des = "Bake a PBR Alpha map"
    bpy.types.Scene.selected_alpha = bpy.props.BoolProperty(name="Alpha", description=des)
    
    des = "Bake each material into its own texture (for export to virtual worlds like Second Life"
    bpy.types.Scene.tex_per_mat = bpy.props.BoolProperty(name="Texture per material", description=des, update=tex_per_mat_update)
    
    
    #-----------Specials-------------------------------------------
    des = "ColourID Map based on random colour per material"
    bpy.types.Scene.selected_col_mats = bpy.props.BoolProperty(name="Col ID (Mats)", description=des)
    des = "Bake the active vertex colours to a texture"
    bpy.types.Scene.selected_col_vertex = bpy.props.BoolProperty(name="Vertex Colours", description=des)
    des = "Ambient Occlusion"
    bpy.types.Scene.selected_ao = bpy.props.BoolProperty(name="AO", description=des)
    des = "Thickness map"
    bpy.types.Scene.selected_thickness = bpy.props.BoolProperty(name="Thickness", description=des)
    des = "Curvature map"
    bpy.types.Scene.selected_curvature = bpy.props.BoolProperty(name="Curvature", description=des)
    
    
    des = "Bake maps from one or more  source objects (usually high poly) to a single target object (usually low poly). Source and target objects must be in the same location (overlapping). See Blender documentation on selected to active baking for more details"
    bpy.types.Scene.selected_s2a = bpy.props.BoolProperty(name="Bake selected objects to target object", update = s2a_update, description=des)
    des = "Specify the target object for the baking. Note, this need not be part of your selection in the viewport (though it can be)"
    bpy.types.Scene.targetobj = bpy.props.PointerProperty(name="Target Object", description=des, type=bpy.types.Object)
    
    
    #UVs-----------
    
    des = "Use Smart UV Project to create a new UV map for your objects (or target object if baking to a target). See Blender Market FAQs for more details"
    bpy.types.Scene.newUVoption = bpy.props.BoolProperty(name="New UV Map(s)", description=des, update=newUVoption_update)
    des = "If one exists for the object being baked, use any existing UV maps called 'SimpleBake' for baking (rather than the active UV map)"
    bpy.types.Scene.prefer_existing_sbmap = bpy.props.BoolProperty(name="Prefer existing UV maps called SimpleBake", description=des, update=prefer_existing_sbmap_update)
    
    des = "New UV Method"
    bpy.types.Scene.newUVmethod = bpy.props.EnumProperty(name="New UV Method", default="SmartUVProject_Atlas", description=des, items=[
    ("SmartUVProject_Individual", "Smart UV Project (Individual)", "Each object gets a new UV map using Smart UV Project"),
    ("SmartUVProject_Atlas", "Smart UV Project (Atlas)", "Create a combined UV map (atlas map) using Smart UV Project"),
    ("CombineExisting", "Combine Active UVs (Atlas)", "Create a combined UV map (atlas map) by combining the existing, active UV maps on each object")
    ], update=newUVmethod_update)
    
    des = "If you are creating new UVs, or preferring an existing UV map called SimpleBake, the UV map used for baking may not be the one you had displayed in the viewport before baking. This option restores what you had active before baking"
    bpy.types.Scene.restoreOrigUVmap = bpy.props.BoolProperty(name="Restore originally active UV map at end", description=des, default=True)
    
    des = "Margin to use when packing combined UVs into Atlas map"
    bpy.types.Scene.uvpackmargin = bpy.props.FloatProperty(name="Pack Margin", default=0.05, description=des)
    
    des = "Average the size of the UV islands when combining them into the atlas map"
    bpy.types.Scene.averageUVsize = bpy.props.BoolProperty(name="Average UV Island Size", default=True, description=des)
    
    des = "When using 'Texture per material', Create a new UV map, and expand the UVs from each material to fill that map using Smart UV Project"
    bpy.types.Scene.expand_mat_uvs = bpy.props.BoolProperty(name="New UVs per material, expanded to bounds", description=des, update=expand_mat_uvs_update)


    des = "Bake to UDIMs or normal UVs. You must be exporting your bakes to use UDIMs. You must manually create your UDIM UVs (this cannot be automated)"
    bpy.types.Scene.uv_mode = bpy.props.EnumProperty(name="UV Mode", default="normal", description=des, items=[
    ("normal", "Normal", "Normal UV maps"),
    ("udims", "UDIMs", "UDIM UV maps")
    ], update = uv_mode_update)
    
    des = "Set the number of tiles that your UV map has used"
    bpy.types.Scene.udim_tiles = bpy.props.IntProperty(name="UDIM Tiles", default=2, description=des)

    
    
    #---------------
    
    
    des = "Export your bakes to the folder specified below, under the same folder where your .blend file is saved. Not available if .blend file not saved"
    bpy.types.Scene.saveExternal = bpy.props.BoolProperty(name="Export bakes", default = False, description=des, update = saveExternal_update)
    
    des = "Create a copy of your selected objects in Blender (or target object if baking to a target) and apply the baked textures to it. If you are baking in the background, this happens after you import"
    bpy.types.Scene.prepmesh = bpy.props.BoolProperty(name="Copy objects and apply bakes", default = False, description=des, update=prepmesh_update)
    des = "Hide the source object that you baked from in the viewport after baking. If you are baking in the background, this happens after you import"
    bpy.types.Scene.hidesourceobjects = bpy.props.BoolProperty(name="Hide source objects after bake", default = False, description=des)
    
    des = "Export your mesh as a .fbx file with a single texture and the UV map used for baking (i.e. ready for import somewhere else. File is saved in the folder specified below, under the folder where your blend file is saved. Not available if .blend file not saved"
    bpy.types.Scene.saveObj = bpy.props.BoolProperty(name="Export mesh", default = False, description=des)
    des = "File name of the fbx. NOTE: To maintain compatibility, only MS Windows acceptable characters will be used"
    bpy.types.Scene.fbxName = bpy.props.StringProperty(name="FBX name", description=des, default="Export", maxlen=20)
    
    
    des = "Baked images have a transparent background (else Black)"
    bpy.types.Scene.useAlpha = bpy.props.BoolProperty(name="Use Alpha", default = False, update = alpha_update, description=des)
    des = "Bake multiple objects to one set of textures. Not available with 'Use Alpha' (limitation of Blender) or with 'Bake maps to target object' (would not make sense)"
    bpy.types.Scene.mergedBake = bpy.props.BoolProperty(name="Multiple objects to one texture set", default = False, description=des, update = mergedBake_update)
    
    des = "Apply colour space settings (exposure, gamma etc.) when saving the image externally. Only available if you are exporting baked images"
    bpy.types.Scene.exportcyclescolspace = bpy.props.BoolProperty(name="Export with Col Management Settings", default = True, description=des)
    
    des = "Set the height of the baked image that will be produced"
    bpy.types.Scene.imgheight = bpy.props.IntProperty(name="Height", default=1024, description=des)
    des = "Set the width of the baked image that will be produced"
    bpy.types.Scene.imgwidth = bpy.props.IntProperty(name="Width", default=1024, description=des)
    
    des = "Set the colour space of the images created for cycles bakes"
    bpy.types.Scene.cyclescolspace = bpy.props.EnumProperty(name="CyclesBake Col Space", default="sRGB", description=des, items=[
    ("sRGB", "sRGB", "Use the sRGB colour space for CyclesBakes"),
    ("Filmic Log", "Filmic", "Use the filmic log colour space for CyclesBakes")
    ])
    
    bpy.types.Scene.memLimit = bpy.props.EnumProperty(name="Memory Limit", default="4096", 
        description="Limit memory usage by limiting render tile size. More memory means faster bake times, but it is possible to exceed the capabilities of your computer which will lead to a crash or slow bake times", items=[
            ("512", "Ultra Low", "Ultra Low memory usage (max 512 tile size)"),
            ("1024", "Low", "Low memory usage (max 1024 tile size)"),
            ("2048", "Medium", "Medium memory usage (max 2048 tile size)"),
            ("4096", "Normal", "Normal memory usage, for a reasonably modern computer (max 4096 tile size)"),
            ("Off", "No Limit", "Don't limit memory usage (tile size matches render image size)")
            ])
   
    des = "Margin between islands to use for Smart UV Project"
    bpy.types.Scene.unwrapmargin = bpy.props.FloatProperty(name="UV Unwrap Margin", default=0.0, description=des)
    
    des = "Bake using the Cycles selected to active option"
    bpy.types.Scene.cycles_s2a = bpy.props.BoolProperty(name="Selected to Active", description=des, update = cycles_s2a_update)

    bpy.types.Scene.exportfileformat = bpy.props.EnumProperty(name="Export File Format", update=exportfileformat_update, default="PNG", 
        description="Select the file format for exported bakes. Also applies to Sketchfab upload images", items=[
            ("PNG", "PNG", ""),
            ("JPEG", "JPG", ""),
            ("TIFF", "TIFF", "")
            ])
    
    des="Name of the folder to create and save the bakes/mesh into. Created in the folder where you blend file is saved. NOTE: To maintain compatibility, only MS Windows acceptable characters will be used"
    bpy.types.Scene.saveFolder = bpy.props.StringProperty(name="Save folder name", description=des, default="SimpleBake_Bakes", maxlen=20)
    
    des="Name to apply to these bakes (is incorporated into the bakes file name, provided you have included this in the image format string - see addon preferences). NOTE: To maintain compatibility, only MS Windows acceptable characters will be used"
    bpy.types.Scene.batchName = bpy.props.StringProperty(name="Batch name", description=des, default="Bake1", maxlen=20)
    
    des="Switch between roughness and glossiness (inverts of each other). NOTE: Roughness is the default for Blender so, if you change this, texture probably won't look right when used in Blender"
    bpy.types.Scene.rough_glossy_switch = bpy.props.EnumProperty(name="", default="rough", 
        description=des, items=[
            ("rough", "Rough", ""),
            ("glossy", "Glossy", "")
            ])
    
    des="Switch between OpenGL and DirectX formats for normal map. NOTE: Opengl is the default for Blender so, if you change this, texture probably won't look right when used in Blender"
    bpy.types.Scene.normal_format_switch = bpy.props.EnumProperty(name="", default="opengl", 
        description=des, items=[
            ("opengl", "OpenGL", ""),
            ("directx", "DirectX", "")
            ])
    
    #---------------------Channel packing-------------------------------------------
    
    des="Display channel packing options (for game engines). Only available when Export Bakes option is used. Packed image will be exported only (no internal Blender image). Packed image will be a seperate EXR file. Only EXR file format is supported"
    bpy.types.Scene.pack_master_switch = bpy.props.BoolProperty(name="Channel Packing", description=des, update=pack_master_switch_update)
    
    des="Pack glossy/roughness (whatever you baked) into alpha of metalness texture (for game engines). Only available if you are baking both Metal and Roughness/Glossy maps"
    bpy.types.Scene.pack_gloss2metal_alpha = bpy.props.BoolProperty(name="Pack roughness/glossy into metal", description=des)
    
    des="Pack glossy/roughness (whatever you baked) into alpha and metalness in the blue channel"
    bpy.types.Scene.pack_gloss2metal_alpha = bpy.props.BoolProperty(name="Pack roughness/glossy into metal", description=des)
    
    bpy.types.Scene.bgbake = bpy.props.EnumProperty(name="Background Bake", default="fg", items=[
    ("fg", "Foreground", "Perform baking in the foreground. Blender will lock up until baking is complete"),
    ("bg", "Background", "Perform baking in the background, leaving you free to continue to work in Blender while the baking is being carried out")
    ], update=bgbake_update)
    
    des="Append date and time to folder name. If you turn this off there is a risk that you will accidentally overwrite bakes you did before if you forget to change the folder name"
    bpy.types.Scene.folderdatetime = bpy.props.BoolProperty(name="Append date and time to folder", description=des, default=True)
    
    des="Run baked images through the compositor. Your blend file must be saved, and you must be exporting your bakes"
    bpy.types.Scene.rundenoise = bpy.props.BoolProperty(name="Denoise", description=des, default=False)
    
    
    #Register classes
    global classes
    for cls in classes:
        bpy.utils.register_class(cls)
    
    
    
def unregister():
    
    #User preferences
    global classes
    for cls in classes:
        bpy.utils.unregister_class(cls)
    

    del bpy.types.Scene.saveObj
    del bpy.types.Scene.newUVoption
    del bpy.types.Scene.saveExternal
    del bpy.types.Scene.memLimit
    del bpy.types.Scene.useAlpha
    del bpy.types.Scene.prepmesh
    del bpy.types.Scene.unwrapmargin
    #del bpy.types.Scene.everything32bitfloat
    del bpy.types.Scene.everything16bit
    del bpy.types.Scene.cyclescolspace
    del bpy.types.Scene.exportcyclescolspace
    del bpy.types.Scene.texture_res
    del bpy.types.Scene.hidesourceobjects
    del bpy.types.Scene.saveFolder
    del bpy.types.Scene.batchName
    del bpy.types.Scene.fbxName
    del bpy.types.Scene.bgbake
    del bpy.types.Scene.folderdatetime
    del bpy.types.Scene.rundenoise
    
    
    del bpy.types.Scene.selected_col_mats
    del bpy.types.Scene.selected_col_vertex
    del bpy.types.Scene.selected_ao
    del bpy.types.Scene.selected_thickness
    del bpy.types.Scene.selected_curvature        
    

if __name__ == "__main__":
    register()


