import bpy
from . import functions
from . import bakefunctions
from .bg_bake import bgbake_ops


class OBJECT_PT_simple_bake_panel(bpy.types.Panel):
    #bl_idname = "object.simple_bake_panel"
    bl_label = "Simple Bake"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    
    current = True
    version = "0.0.0"

    """
    @classmethod
    def poll(cls, context):
        return (context.object is not None)
    """

    def draw(self, context):
        
        layout = self.layout
        
        if(bpy.context.scene.render.engine != "CYCLES"):
            row = layout.row()
            row.label(text="Switch to Cycles to use SimpleBake")
            #Version
            row = layout.row()
            row.alignment = 'RIGHT'
            row.label(text=f"Version {self.version}")
            return
        
        if not self.current:
            row = layout.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.6
            row.label(text="", icon="MOD_WAVE")
            
            row = layout.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.6
            row.label(text="Newer version of SimpleBake available")
            row = layout.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.6
            row.label(text="Update automatically in addon preferences")
        
        
        #layout.use_property_split = True
        #layout.use_property_decorate = False
        
        #-----------Global Mode Select------------------------
        box = layout.box()
        row = box.row()
        row.scale_y = 1.5 
        
        if context.scene.global_mode == "pbr_bake":
            modetxt = "Bake mode (PBR)"
        if context.scene.global_mode == "cycles_bake":
            modetxt = "Bake mode (Cycles)"
        if context.scene.global_mode == "specials_bake":
            modetxt = "Bake mode (Specials)"
        
        row.prop_menu_enum(context.scene, "global_mode", icon="SETTINGS", text=modetxt)
        
        #--------Specials Bake Settings-------------------
        
        if(context.scene.global_mode == "specials_bake"):
            box = layout.box()
            box.label(text="Specials Bake Settings")
            row = box.row()
            row.prop(context.scene, "selected_col_mats")
            row.prop(context.scene, "selected_col_vertex")
            row = box.row()
            row.prop(context.scene, "selected_ao")
            row.prop(context.scene, "selected_thickness")
            row = box.row()
            row.prop(context.scene, "selected_curvature")
            
        
        
        #--------PBR Bake Settings-------------------
        
        if(context.scene.global_mode == "pbr_bake"):
            box = layout.box()
            box.label(text="PBR Bake Settings")
            
            row = box.row()
            row.prop(context.scene, "selected_col")
            row.prop(context.scene, "selected_metal")
            
            row = box.row()
            row.prop(context.scene, "selected_sss")
            row.prop(context.scene, "selected_ssscol")
            
            row = box.row()
            row.prop(context.scene, "selected_rough")
            row.prop(context.scene, "selected_normal")
            if context.scene.selected_rough or context.scene.selected_normal:
                row = box.row()
                if context.scene.selected_rough:
                    col = row.column()
                    col.prop(context.scene, "rough_glossy_switch")
                    #col.enabled = True if bpy.context.scene.selected_rough else False
                if context.scene.selected_normal:
                    col = row.column()
                    col.prop(context.scene, "normal_format_switch")
                    #col.enabled = True if bpy.context.scene.selected_normal else False
            
            row = box.row()
            row.prop(context.scene, "selected_trans")
            row.prop(context.scene, "selected_transrough")
            row = box.row()
            row.prop(context.scene, "selected_clearcoat")
            row.prop(context.scene, "selected_clearcoat_rough")
            row = box.row()
            row.prop(context.scene, "selected_emission")
            row.prop(context.scene, "selected_specular")
            row = box.row()
            row.prop(context.scene, "selected_alpha")
            row = box.row()
            row.operator("object.simple_bake_selectall", icon='ADD')
            row.operator("object.simple_bake_selectnone", icon='REMOVE')
            row = box.row()
            row.prop(context.scene, "selected_s2a")
            
            if(bpy.context.scene.selected_s2a): 
                row = box.row()
                row.alignment = "RIGHT"
                #row.use_property_split = True
                #row.prop_search(context.scene, "targetobj", context.scene, "objects")
                row.prop(context.scene, "targetobj")
                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene, "ray_distance")
                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene.render.bake, "cage_object", text="Cage Object (Optional)")
                
            if context.scene.ray_distance < 0.2:
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="", icon="MONKEY")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="Warning: Setting ray distance too low")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="can give strange results")
        
        #--------Cycles Bake Settings-------------------
        
        if(context.scene.global_mode == "cycles_bake"):
            box = layout.box()
            box.label(text="CyclesBake Settings")
            row = box.row()
            row.prop(context.scene, "exportcyclescolspace")
            if not bpy.context.scene.saveExternal:
                row.enabled = False 
            row = box.row()
            row.alignment = "RIGHT"
            row.prop(context.scene, "cyclescolspace")
            row = box.row()
            #row.prop(context.scene.render.bake, "use_selected_to_active")
            #if bpy.context.scene.render.bake.use_selected_to_active:
            
            row.prop(context.scene, "cycles_s2a")
            if bpy.context.scene.cycles_s2a:
                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene, "ray_distance")
                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene.render.bake, "cage_object", text="Cage Object (Optional)")

            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="Remember to also set bake settings")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="in the Blender bake panel")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="*SimpleBake settings always take precedence*")
            
            if context.scene.ray_distance < 0.2:
                row = box.row()
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="", icon="MONKEY")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="Warning: Setting ray distance too low")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="can give strange results")
            
                
                    
        #--------Texture Settings-------------------
        
        box = layout.box()
        box.label(text="Texture Settings")
        
        row = box.row()
        row.prop(context.scene, "texture_res", expand=True)
        row.scale_y = 1.5 
        
        
        if context.scene.texture_res == "Custom":
            row = box.row()
            row.prop(context.scene, "imgheight")
            row.prop(context.scene, "imgwidth") 
        
        row = box.row()
        row.alignment = "RIGHT"
        row.prop(context.scene.render.bake, "margin", text="Bake Margin")
        
        #row = box.row()
        #row.prop(context.scene, "everything32bitfloat")
        
        row = box.row()
        row.prop(context.scene, "useAlpha")
        
        #For now, this is CyclesBake only
        if context.scene.global_mode == "cycles_bake":
            row = box.row()
            row.prop(context.scene, "tex_per_mat")

        #--------Export Settings-------------------

        box = layout.box()
        box.label(text="Export Settings")
   

        row = box.row()
        col = row.column()
        col.prop(context.scene, "saveExternal")
        if(not functions.isBlendSaved()):
            col.enabled = False
        col = row.column()
        col.prop(context.scene, "saveObj")
        if(not functions.isBlendSaved()):
            col.enabled = False  
        
        if context.scene.saveObj:
            row = box.row()
            row.alignment = "RIGHT"
            row.prop(context.scene, "fbxName")
            
        if context.scene.saveExternal or context.scene.saveObj:
            row = box.row()
            #row.alignment = "RIGHT"
            row.prop(context.scene, "saveFolder", text="Folder name")

            row = box.row()
            #row.alignment = "RIGHT"
            row.prop(context.scene, "folderdatetime")        
            
    
            row = box.row()
            #row.alignment = "RIGHT"
            row.prop(context.scene, "exportfileformat", text="Format")
            
            #row = box.row()
            #row.alignment = "RIGHT"
            #row.prop(context.scene, "everything16bit")
            #if not context.scene.saveExternal or context.scene.exportfileformat == "JPEG":
                #row.enabled = False
        
        if not context.scene.folderdatetime and context.scene.saveExternal:
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="Warning: Not appending date and time to folder name means")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="all previous bakes in the folder will be overwritten")
            row = box.row()
            row.scale_y = 0.5
            row.alignment = 'CENTER'
            row.label(text="with the new versions each time you bake. Be careful!")

        
        
        #--------UV Settings-------------------
        box = layout.box()
        box.label(text="UV and Maps Settings")
        
        #UV mode
        row = box.row()
        row.prop(context.scene, "uv_mode", expand=True)
        if context.scene.saveExternal:
            row.enabled = True
        else:
            row.enabled = False
        
        
        if bpy.context.scene.uv_mode == "udims":
            
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="Warning: UDIM functionality is in Alpha")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="Use with caution. You must manually create UV")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="map over UDIM tiles")
            

            row = box.row()
            row.prop(context.scene, "udim_tiles")
            
            
        
        if bpy.context.scene.uv_mode == "udims":
            pass
        
        elif not context.scene.tex_per_mat:
            row = box.row()
            row.prop(context.scene, "newUVoption")
            if context.scene.newUVoption:
                if len(context.selected_objects) >1 and not context.scene.selected_s2a:
                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(context.scene, "newUVmethod")
                    if context.scene.newUVmethod == "SmartUVProject_Atlas" or context.scene.newUVmethod == "SmartUVProject_Individual":
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(context.scene, "unwrapmargin")
                    else:
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(context.scene, "averageUVsize")
                        row.prop(context.scene, "uvpackmargin")
                else:
                    #One object selected
                    row = box.row()
                    row.alignment = "RIGHT"
                    row.label(text="Smart UV Project")
                    row.prop(context.scene, "unwrapmargin")
        else:
            row = box.row()
            row.prop(context.scene, "expand_mat_uvs")
            
        
        row = box.row()  
        row.prop(context.scene, "prefer_existing_sbmap")
        if context.scene.newUVoption == True or context.scene.expand_mat_uvs:
            row.enabled = False
        
                
        row = box.row()
        row.prop(context.scene, "mergedBake")
        if context.scene.useAlpha or context.scene.selected_s2a or len(context.selected_objects) <2 or context.scene.tex_per_mat:
            row.enabled = False
        if context.scene.global_mode == "cycles_bake" and context.scene.render.bake.use_selected_to_active:
            row.enabled = False
            
        row = box.row()
        row.prop(context.scene, "restoreOrigUVmap")
        
        if bpy.context.scene.newUVoption and bpy.context.scene.newUVmethod == "SmartUVProject_Individual" and bpy.context.scene.mergedBake and bpy.context.scene.uv_mode != "udims":
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="WARNING: Current settings will unwrap objects")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="individually but bake to one texture set")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="Bakes will be on top of each other!")

        if not bpy.context.scene.newUVoption  and bpy.context.scene.mergedBake:
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="ALERT: You are baking multiple objects to one texture")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="set with existing UVs. You will need to manually")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="make sure those UVs don't overlap!")        
        
        if bpy.context.scene.newUVoption and not bpy.context.scene.saveObj and not bpy.context.scene.prepmesh and bpy.context.scene.bgbake == "bg":
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="", icon="MONKEY")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="WARNING: You are baking in background with new UVs, but")
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text="not exporting FBX or using 'Copy Objects and Apply Bakes'")
            row = box.row()
            row.scale_y = 0.5
            row.alignment = 'CENTER'
            row.label(text="You will recieve the baked textures on import, but you will")
            row = box.row()
            row.scale_y = 0.5
            row.alignment = 'CENTER'
            row.label(text="have no access to an object with the new UV map!")
        
        
        #--------Other Settings-------------------
        
        
        box = layout.box()
        box.label(text="Other Settings")
        
        row=box.row()
        row.alignment = 'LEFT'
        row.prop(context.scene, "batchName")
        
        if not context.scene.global_mode == "specials_bake":
            row = box.row()
            if bpy.context.scene.bgbake == "fg":
                text = "Copy objects and apply bakes"
            else:
                text = "Copy objects and apply bakes (after import)"
            
            row.prop(context.scene, "prepmesh", text=text)
            if context.scene.tex_per_mat:
                row.enabled = False
                
        
        if (context.scene.prepmesh == True) and (not context.scene.global_mode == "specials_bake"):
            if bpy.context.scene.bgbake == "fg":
                text = "Hide source objects after bake"
            else:
                text = "Hide source objects after bake (after import)"
            row = box.row()
            row.prop(context.scene, "hidesourceobjects", text=text)
        
        if bpy.context.scene.global_mode == "cycles_bake":
            row = box.row()
            row.prop(context.scene, "rundenoise")
            if not bpy.context.scene.saveExternal:
                row.enabled = False
        
        row = box.row()
        row.alignment = "RIGHT"
        row.prop(context.scene, "memLimit")
        
        #-------------Channel packing --------------------------
        if(context.scene.global_mode == "pbr_bake"):
            
            box = layout.box()
            row = box.row()
            row.prop(context.scene, "pack_master_switch")
            if not context.scene.saveExternal:
                row.enabled=False
                            
            if context.scene.pack_master_switch:
                row=box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="", icon="MONKEY")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="WARNING: Channel packing is in BETA")
            
                
                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene, "pack_gloss2metal_alpha")
                if not (context.scene.selected_metal and context.scene.selected_rough):
                    row.enabled=False
                
            
        

        #-------------Buttons-------------------------
        
        if(context.scene.global_mode == "pbr_bake"):
            row = layout.row()
            row.scale_y = 2
            row.operator("object.simple_bake_mapbake", icon='RENDER_RESULT')
            
        
        if(context.scene.global_mode == "cycles_bake"):
            row = layout.row()
            row.operator("object.simple_bake_cyclesbake", icon="RESTRICT_RENDER_ON")
            row.scale_y = 2
                 
        
        if(context.scene.global_mode == "specials_bake"):
            row = layout.row()
            row.operator("object.simple_bake_specials", icon="RESTRICT_RENDER_ON")
            row.scale_y = 2  

        
        #Always display the bg/fg switch (except for specials)
        
        if(context.scene.global_mode != "specials_bake"):
            row = layout.row()
            row.scale_y = 1.5
            row.prop(context.scene, "bgbake", expand=True)         


        if(context.scene.global_mode == "pbr_bake"):
            if(context.scene.selected_alpha):
                box = layout.box()
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="", icon="MONKEY")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="Warning: Uploading to Sketchfab with an Alpha texture")
                row = box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.label(text="will make your object inviisble by detault!")
                row = box.row()
                row.scale_y = 0.5
                row.alignment = 'CENTER'
                row.label(text="")
                row = box.row()
                row.scale_y = 0.5
                row.alignment = 'CENTER'
                row.label(text="You must change the texture settings")
                row = box.row()
                row.scale_y = 0.5
                row.alignment = 'CENTER'
                row.label(text="in Sketchfab after upload from 'Luminance' to 'Alpha'")
            
            
            
        box = layout.box()    
        row=box.row()
        row.label(text="Background bakes")
        
        row = box.row()
        row.scale_y = 1.5
        
        # - BG status button
        col = row.column()
        if len(bgbake_ops.bgops_list) == 0:
            enable = False
            icon = "GHOST_DISABLED"
        else:
            enable = True
            icon = "GHOST_ENABLED"
                
        col.operator("object.simple_bake_bgbake_status", text="Status", icon=icon)
        col.enabled = enable
        
        # - BG import button
        
        col = row.column()
        if len(bgbake_ops.bgops_list_finished) != 0:
            enable = True
            icon = "IMPORT"
        else:
            enable = False
            icon = "IMPORT"
        
        col.operator("object.simple_bake_bgbake_import", text="Import", icon=icon)
        col.enabled = enable

        
        #BG erase button
        
        col = row.column()
        if len(bgbake_ops.bgops_list_finished) != 0:
            enable = True
            icon = "TRASH"
        else:
            enable = False
            icon = "TRASH"
        
        col.operator("object.simple_bake_bgbake_clear", text="Discard", icon=icon)
        col.enabled = enable       
        
        
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text=f"BG bakes running - {len(bgbake_ops.bgops_list)} | Available for import - {len(bgbake_ops.bgops_list_finished)}")

        
        if(context.scene.global_mode == "pbr_bake"):
            row = layout.row()
            row.scale_y = 1.5
            row.operator("object.simple_bake_sketchfabupload", text="Sketchfab Upload", icon="EXPORT") 

        #Version
        row = layout.row()
        row.alignment = 'RIGHT'
        row.label(text=f"Version {self.version}")
        
        

class SimpleBakePreferences(bpy.types.AddonPreferences):
    # this must match the add-on name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = __package__

    apikey: bpy.props.StringProperty(name="Sketchfab API Key: ")
    img_name_format: bpy.props.StringProperty(name="Image format string",
        default="%OBJ%_%BATCH%_%BAKEMODE%_%BAKETYPE%")
    
    justupdated = False
    
    #Aliases
    diffuse_alias: bpy.props.StringProperty(name="Diffuse", default="diffuse")
    metal_alias: bpy.props.StringProperty(name="Metal", default="metalness")
    roughness_alias: bpy.props.StringProperty(name="Roughness", default="roughness")
    glossy_alias: bpy.props.StringProperty(name="Glossy", default="glossy")
    normal_alias: bpy.props.StringProperty(name="Normal", default="normal")
    transmission_alias: bpy.props.StringProperty(name="Transmission", default="transparency")
    transmissionrough_alias: bpy.props.StringProperty(name="Transmission Roughness", default="transparencyroughness")
    clearcoat_alias: bpy.props.StringProperty(name="Clearcost", default="clearcoat")
    clearcoatrough_alias: bpy.props.StringProperty(name="Clearcoat Roughness", default="clearcoatroughness")
    emission_alias: bpy.props.StringProperty(name="Emission", default="emission")
    specular_alias: bpy.props.StringProperty(name="Specular", default="specular")
    alpha_alias: bpy.props.StringProperty(name="Alpha", default="alpha")    
    sss_alias: bpy.props.StringProperty(name="SSS", default="sss")
    ssscol_alias: bpy.props.StringProperty(name="SSS Colour", default="ssscol")
    ao_alias: bpy.props.StringProperty(name="AO", default="ao")
    curvature_alias: bpy.props.StringProperty(name="Curvature", default="curvature")
    thickness_alias: bpy.props.StringProperty(name="Thickness", default="thickness")
    vertexcol_alias: bpy.props.StringProperty(name="vertex Col", default="vertexcol")
    colid_alias: bpy.props.StringProperty(name="Col ID", default="colid")
    
    @classmethod
    def reset_img_string(self):
        prefs = bpy.context.preferences.addons[__package__].preferences
        #prefs.img_name_format = "BOO"
        prefs.property_unset("img_name_format")
        bpy.ops.wm.save_userpref()
        
    @classmethod
    def reset_aliases(self):
        prefs = bpy.context.preferences.addons[__package__].preferences
        
        prefs.property_unset("diffuse_alias")
        prefs.property_unset("metal_alias")  
        prefs.property_unset("roughness_alias")  
        prefs.property_unset("normal_alias")  
        prefs.property_unset("transmission_alias")  
        prefs.property_unset("transmissionrough_alias")  
        prefs.property_unset("clearcoat_alias")  
        prefs.property_unset("clearcoatrough_alias")  
        prefs.property_unset("emission_alias")
        prefs.property_unset("specular_alias")  
        prefs.property_unset("alpha_alias")
        prefs.property_unset("sss_alias")
        prefs.property_unset("ssscol_alias")
        prefs.property_unset("ao_alias") 
        prefs.property_unset("curvature_alias") 
        prefs.property_unset("thickness_alias") 
        prefs.property_unset("vertexcol_alias") 
        prefs.property_unset("colid_alias") 

        bpy.ops.wm.save_userpref()     
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text="Enter your Sketchfab API key below. Don't forget to click \"Save Preferences\" after.")
        row = layout.row()
        row.prop(self, "apikey")
        current = OBJECT_PT_simple_bake_panel.current
        
        row = layout.row()
        if current:
            row.label(text="SimpleBake is up to date (last checked when Blender started)")
        else:
            if self.justupdated:
                row.label(text="Update complete. Please restart Blender to take effect", icon="MONKEY")
                
            else:
                row.label(text="There is a newer version of SimpleBake available. Click below to update", icon="MOD_WAVE")
                row = layout.row()
                row.operator("object.simple_bake_installupdate", icon="MOD_WAVE")
                row.scale_y = 2
       
        row = layout.row()
        row.scale_y = 2
        row.operator("object.simple_bake_releasenotes", icon="MOD_WAVE")
        
        
        box = layout.box()
        row = box.row()
        row.label(text="Format string for image names")
        row = box.row()
        row.label(text="Valid variables are %OBJ% (object name or 'MergedBake'), %BATCH% (batch name),")
        row.scale_y = 0.5
        row = box.row()
        row.label(text="%BAKEMODE% (pbr or cycles bake) and %BAKETYPE% (diffuse, emission etc.)")
        row.scale_y = 0.5
        row = box.row()
        row.label(text="An example based on your current settings is shown below")
        row.scale_y = 0.5

        row = box.row()
        test_obj = "Cube"
        test_bakemode = "pbr"
        test_baketype = "diffuse"
        row.label(text=f"Current: {functions.gen_image_name(test_obj, test_bakemode, test_baketype)}")
        
        row = box.row()
        row.prop(self, "img_name_format")
        row = box.row()
        row.operator("object.simple_bake_default_imgname_string")
        
        #PBR Aliases
        box = layout.box()
        
        
        row = box.row()
        row.label(text="Aliases for PBR bake types")
        
        row = box.row()
        row.label(text="WARNING: Sketchfab looks for certain values. Changing these may breack SF Upload")
        
        row = box.row()
        col = row.column()
        col.prop(self, "diffuse_alias")
        col = row.column()
        col.prop(self, "metal_alias")        

        row = box.row()
        col = row.column()
        col.prop(self, "sss_alias")
        col = row.column()
        col.prop(self, "ssscol_alias")        
        
        row = box.row()
        col = row.column()
        col.prop(self, "roughness_alias")
        col = row.column()
        col.prop(self, "glossy_alias")

        row = box.row()
        col = row.column()
        col.prop(self, "transmission_alias")
        col = row.column()
        col.prop(self, "transmissionrough_alias")  

        row = box.row()
        col = row.column()
        col.prop(self, "clearcoat_alias")
        col = row.column()
        col.prop(self, "clearcoatrough_alias")  

        row = box.row()
        col = row.column()
        col.prop(self, "emission_alias")
        col = row.column()
        col.prop(self, "specular_alias")  
        
        row = box.row()
        col = row.column()
        col.prop(self, "alpha_alias")
        col = row.column()
        col.prop(self, "normal_alias")    
        col.label(text="")  
        
        #Specials Aliases
        box = layout.box()
        
        row = box.row()
        row.label(text="Aliases for special bake types")
        
        row = box.row()
        col = row.column()
        col.prop(self, "ao_alias")
        col = row.column()
        col.prop(self, "curvature_alias")        
        
        row = box.row()
        col = row.column()
        col.prop(self, "thickness_alias")
        col = row.column()
        col.prop(self, "vertexcol_alias")    

        row = box.row()
        col = row.column()
        col.prop(self, "colid_alias")
        
        #Reset button
        box = layout.box()
        row = box.row()
        row.operator("object.simple_bake_default_aliases")
        
 

class OBJECT_OT_simple_bake_releasenotes(bpy.types.Operator):
    """View the SimpleBake release notes (opens browser)"""
    bl_idname = "object.simple_bake_releasenotes"
    bl_label = "View the SimpleBake release notes (opens browser)"
    
    def execute(self, context):
        import webbrowser
        webbrowser.open('http://www.toohey.co.uk/SimpleBake/releasenotes.html', new=2)
        return {'FINISHED'} 

        
