import bpy
from pathlib import Path
import tempfile
import shutil


def setup_nodes(scene):
    
    node_tree = scene.node_tree
    nodes = node_tree.nodes
    
    
    #--------------------------------------------------------------------------
    
    #Create nodes
    my_nodes = {}
    final_output = scene.node_tree.nodes.new('CompositorNodeComposite')
    my_nodes['final_output'] = final_output
    final_output.name = 'Composite'
    a_input_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['a_input_img_invert'] = a_input_img_invert
    a_input_img_invert.mute = True
    a_input_img_invert.name = 'Invert.003'
    b_input_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['b_input_img_invert'] = b_input_img_invert
    b_input_img_invert.mute = True
    b_input_img_invert.name = 'Invert.002'
    #x_img_mix = scene.node_tree.nodes.new('CompositorNodeMixRGB')
    #my_nodes['x_img_mix'] = x_img_mix
    #x_img_mix.name = 'Mix'
    b_input_img = scene.node_tree.nodes.new('CompositorNodeImage')
    my_nodes['b_input_img'] = b_input_img
    b_input_img.name = 'Image.001'
    a_input_img = scene.node_tree.nodes.new('CompositorNodeImage')
    my_nodes['a_input_img'] = a_input_img
    a_input_img.name = 'Image'
    input_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['input_comb'] = input_comb
    input_comb.name = 'Combine RGBA'
    allinput_sepRGBA = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['allinput_sepRGBA'] = allinput_sepRGBA
    allinput_sepRGBA.name = 'Separate RGBA'
    r_input_img = scene.node_tree.nodes.new('CompositorNodeImage')
    my_nodes['r_input_img'] = r_input_img
    r_input_img.name = 'Image.002'
    g_input_img_sep = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['g_input_img_sep'] = g_input_img_sep
    g_input_img_sep.name = 'Separate RGBA.002'
    b_input_img_sep = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['b_input_img_sep'] = b_input_img_sep
    b_input_img_sep.name = 'Separate RGBA.003'
    a_input_img_sep = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['a_input_img_sep'] = a_input_img_sep
    a_input_img_sep.name = 'Separate RGBA.004'
    g_input_img = scene.node_tree.nodes.new('CompositorNodeImage')
    my_nodes['g_input_img'] = g_input_img
    g_input_img.name = 'Image.003'
    a_input_img_r_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['a_input_img_r_invert'] = a_input_img_r_invert
    a_input_img_r_invert.mute = True
    a_input_img_r_invert.name = 'Invert.021'
    a_input_img_g_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['a_input_img_g_invert'] = a_input_img_g_invert
    a_input_img_g_invert.mute = True
    a_input_img_g_invert.name = 'Invert.024'
    a_input_img_b_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['a_input_img_b_invert'] = a_input_img_b_invert
    a_input_img_b_invert.mute = True
    a_input_img_b_invert.name = 'Invert.023'
    a_input_img_a_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['a_input_img_a_invert'] = a_input_img_a_invert
    a_input_img_a_invert.mute = True
    a_input_img_a_invert.name = 'Invert.022'
    b_input_img_r_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['b_input_img_r_invert'] = b_input_img_r_invert
    b_input_img_r_invert.mute = True
    b_input_img_r_invert.name = 'Invert.017'
    b_input_img_g_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['b_input_img_g_invert'] = b_input_img_g_invert
    b_input_img_g_invert.mute = True
    b_input_img_g_invert.name = 'Invert.020'
    b_input_img_b_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['b_input_img_b_invert'] = b_input_img_b_invert
    b_input_img_b_invert.mute = True
    b_input_img_b_invert.name = 'Invert.019'
    b_input_img_a_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['b_input_img_a_invert'] = b_input_img_a_invert
    b_input_img_a_invert.mute = True
    b_input_img_a_invert.name = 'Invert.018'
    g_input_img_r_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['g_input_img_r_invert'] = g_input_img_r_invert
    g_input_img_r_invert.mute = True
    g_input_img_r_invert.name = 'Invert.013'
    g_input_img_g_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['g_input_img_g_invert'] = g_input_img_g_invert
    g_input_img_g_invert.mute = True
    g_input_img_g_invert.name = 'Invert.014'
    g_input_img_b_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['g_input_img_b_invert'] = g_input_img_b_invert
    g_input_img_b_invert.mute = True
    g_input_img_b_invert.name = 'Invert.016'
    g_input_img_a_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['g_input_img_a_invert'] = g_input_img_a_invert
    g_input_img_a_invert.mute = True
    g_input_img_a_invert.name = 'Invert.015'
    r_input_img_g_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['r_input_img_g_invert'] = r_input_img_g_invert
    r_input_img_g_invert.mute = True
    r_input_img_g_invert.name = 'Invert.010'
    r_input_img_b_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['r_input_img_b_invert'] = r_input_img_b_invert
    r_input_img_b_invert.mute = True
    r_input_img_b_invert.name = 'Invert.012'
    r_input_img_a_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['r_input_img_a_invert'] = r_input_img_a_invert
    r_input_img_a_invert.mute = True
    r_input_img_a_invert.name = 'Invert.011'
    g_input_img_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['g_input_img_comb'] = g_input_img_comb
    g_input_img_comb.name = 'Combine RGBA.003'
    b_input_img_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['b_input_img_comb'] = b_input_img_comb
    b_input_img_comb.name = 'Combine RGBA.004'
    a_input_img_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['a_input_img_comb'] = a_input_img_comb
    a_input_img_comb.name = 'Combine RGBA.005'
    r_input_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['r_input_img_invert'] = r_input_img_invert
    r_input_img_invert.mute = True
    r_input_img_invert.name = 'Invert'
    g_input_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['g_input_img_invert'] = g_input_img_invert
    g_input_img_invert.mute = True
    g_input_img_invert.name = 'Invert.001'
    x_input_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['x_input_img_invert'] = x_input_img_invert
    x_input_img_invert.mute = True
    x_input_img_invert.name = 'Invert.004'
    r_input_img_sep = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['r_input_img_sep'] = r_input_img_sep
    r_input_img_sep.name = 'Separate RGBA.001'
    r_input_img_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['r_input_img_comb'] = r_input_img_comb
    r_input_img_comb.name = 'Combine RGBA.002'
    r_input_img_r_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['r_input_img_r_invert'] = r_input_img_r_invert
    r_input_img_r_invert.mute = True
    r_input_img_r_invert.name = 'Invert.009'
    x_input_img = scene.node_tree.nodes.new('CompositorNodeImage')
    my_nodes['x_input_img'] = x_input_img
    x_input_img.name = 'Image.004'
    x_input_img_sep = scene.node_tree.nodes.new('CompositorNodeSepRGBA')
    my_nodes['x_input_img_sep'] = x_input_img_sep
    x_input_img_sep.name = 'Separate RGBA.005'
    x_input_img_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['x_input_img_comb'] = x_input_img_comb
    x_input_img_comb.name = 'Combine RGBA.006'
    x_input_img_r_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['x_input_img_r_invert'] = x_input_img_r_invert
    x_input_img_r_invert.mute = True
    x_input_img_r_invert.name = 'Invert.025'
    x_input_img_g_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['x_input_img_g_invert'] = x_input_img_g_invert
    x_input_img_g_invert.mute = True
    x_input_img_g_invert.name = 'Invert.028'
    x_input_img_b_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['x_input_img_b_invert'] = x_input_img_b_invert
    x_input_img_b_invert.mute = True
    x_input_img_b_invert.name = 'Invert.027'
    x_input_img_a_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['x_input_img_a_invert'] = x_input_img_a_invert
    x_input_img_a_invert.mute = True
    x_input_img_a_invert.name = 'Invert.026'
    output_comb = scene.node_tree.nodes.new('CompositorNodeCombRGBA')
    my_nodes['output_comb'] = output_comb
    output_comb.name = 'Combine RGBA.001'
    output_r_img_invert = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['output_r_img_invert'] = output_r_img_invert
    output_r_img_invert.mute = True
    output_r_img_invert.name = 'Invert.005'
    output_g_img_invert  = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['output_g_img_invert'] = output_g_img_invert 
    output_g_img_invert .mute = True
    output_g_img_invert .name = 'Invert.008'
    output_b_img_invert  = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['output_b_img_invert'] = output_b_img_invert 
    output_b_img_invert .mute = True
    output_b_img_invert .name = 'Invert.007'
    output_a_img_invert  = scene.node_tree.nodes.new('CompositorNodeInvert')
    my_nodes['output_a_img_invert'] = output_a_img_invert 
    output_a_img_invert .mute = True
    output_a_img_invert .name = 'Invert.006'
    #Set Node locations
    final_output.location = (867.5746459960938, 250.2066192626953)
    a_input_img_invert.location = (-488.2374267578125, 19.486282348632812)
    b_input_img_invert.location = (-684.8906860351562, 114.55467224121094)
    #x_img_mix.location = (-37.95930480957031, 297.3863220214844)
    b_input_img.location = (-2443.40576171875, -428.3995056152344)
    a_input_img.location = (-1786.6885986328125, -1071.821533203125)
    input_comb.location = (-268.2374267578125, 213.77874755859375)
    allinput_sepRGBA.location = (171.7625732421875, 239.2522735595703)
    r_input_img.location = (-2143.86865234375, 993.3101196289062)
    g_input_img_sep.location = (-2266.7607421875, 275.1116027832031)
    b_input_img_sep.location = (-2073.1962890625, -337.3150939941406)
    a_input_img_sep.location = (-1360.1995849609375, -890.2435302734375)
    g_input_img.location = (-2534.910400390625, 290.72613525390625)
    a_input_img_r_invert.location = (-1226.4525146484375, -402.4371643066406)
    a_input_img_g_invert.location = (-1020.6691284179688, -400.96832275390625)
    a_input_img_b_invert.location = (-986.9119873046875, -578.6928100585938)
    a_input_img_a_invert.location = (-884.1727905273438, -671.22705078125)
    b_input_img_r_invert.location = (-1781.925537109375, -126.22734069824219)
    b_input_img_g_invert.location = (-1568.6649169921875, -168.9112548828125)
    b_input_img_b_invert.location = (-1557.538330078125, -270.98150634765625)
    b_input_img_a_invert.location = (-1546.4117431640625, -408.3123474121094)
    g_input_img_r_invert.location = (-1949.1336669921875, 446.7655334472656)
    g_input_img_g_invert.location = (-1780.56787109375, 360.5783996582031)
    g_input_img_b_invert.location = (-1614.9378662109375, 269.5498046875)
    g_input_img_a_invert.location = (-1781.925537109375, 118.74124145507812)
    r_input_img_g_invert.location = (-1412.6282958984375, 825.2625122070312)
    r_input_img_b_invert.location = (-1430.08203125, 679.1769409179688)
    r_input_img_a_invert.location = (-1553.8448486328125, 552.1460571289062)
    g_input_img_comb.location = (-1065.694091796875, 329.8668212890625)
    b_input_img_comb.location = (-1043.39453125, -1.442535400390625)
    a_input_img_comb.location = (-766.9119873046875, -196.06260681152344)
    r_input_img_invert.location = (-718.126708984375, 473.43756103515625)
    g_input_img_invert.location = (-734.7447509765625, 280.9242248535156)
    x_input_img_invert.location = (-342.3436279296875, 613.2159423828125)
    r_input_img_sep.location = (-1942.433837890625, 896.9397583007812)
    r_input_img_comb.location = (-1089.708984375, 625.126953125)
    r_input_img_r_invert.location = (-1428.495361328125, 993.5784301757812)
    x_input_img.location = (-1309.2576904296875, 1783.64990234375)
    x_input_img_sep.location = (-1131.9102783203125, 1622.4853515625)
    x_input_img_comb.location = (-580.3524169921875, 890.957275390625)
    x_input_img_r_invert.location = (-796.5108032226562, 1632.1455078125)
    x_input_img_g_invert.location = (-818.2330932617188, 1435.140869140625)
    x_input_img_b_invert.location = (-983.865234375, 1333.2418212890625)
    x_input_img_a_invert.location = (-1186.1536865234375, 1228.62548828125)
    output_comb.location = (622.1620483398438, 257.45257568359375)
    output_r_img_invert.location = (409.870361328125, 489.51995849609375)
    output_g_img_invert.location = (402.16204833984375, 312.22979736328125)
    output_b_img_invert.location = (399.59259033203125, 137.50901794433594)
    output_a_img_invert.location = (399.592529296875, -68.04483032226562)
    #Create links
    node_tree.links.new(nodes['Image.003'].outputs[0],  nodes['Separate RGBA.002'].inputs[0])
    node_tree.links.new(nodes['Image.001'].outputs[0],  nodes['Separate RGBA.003'].inputs[0])
    node_tree.links.new(nodes['Image'].outputs[0],  nodes['Separate RGBA.004'].inputs[0])
    node_tree.links.new(nodes['Image.002'].outputs[0],  nodes['Separate RGBA.001'].inputs[0])
    node_tree.links.new(nodes['Invert'].outputs[0],  nodes['Combine RGBA'].inputs[0])
    node_tree.links.new(nodes['Invert.001'].outputs[0],  nodes['Combine RGBA'].inputs[1])
    node_tree.links.new(nodes['Invert.002'].outputs[0],  nodes['Combine RGBA'].inputs[2])
    node_tree.links.new(nodes['Invert.003'].outputs[0],  nodes['Combine RGBA'].inputs[3])
    node_tree.links.new(nodes['Separate RGBA'].outputs[0],  nodes['Invert.005'].inputs[1])
    node_tree.links.new(nodes['Combine RGBA.001'].outputs[0],  nodes['Composite'].inputs[0])
    node_tree.links.new(nodes['Separate RGBA'].outputs[1],  nodes['Invert.008'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA'].outputs[2],  nodes['Invert.007'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA'].outputs[3],  nodes['Invert.006'].inputs[1])
    node_tree.links.new(nodes['Invert.005'].outputs[0],  nodes['Combine RGBA.001'].inputs[0])
    node_tree.links.new(nodes['Invert.006'].outputs[0],  nodes['Combine RGBA.001'].inputs[3])
    node_tree.links.new(nodes['Invert.007'].outputs[0],  nodes['Combine RGBA.001'].inputs[2])
    node_tree.links.new(nodes['Invert.008'].outputs[0],  nodes['Combine RGBA.001'].inputs[1])
    node_tree.links.new(nodes['Image.004'].outputs[0],  nodes['Separate RGBA.005'].inputs[0])
    
    #node_tree.links.new(nodes['Combine RGBA'].outputs[0],  nodes['Mix'].inputs[1])
    #node_tree.links.new(nodes['Invert.004'].outputs[0],  nodes['Mix'].inputs[2])
    #node_tree.links.new(nodes['Mix'].outputs[0],  nodes['Separate RGBA'].inputs[0])
    
    
    node_tree.links.new(nodes['Combine RGBA.002'].outputs[0],  nodes['Invert'].inputs[1])
    node_tree.links.new(nodes['Combine RGBA.003'].outputs[0],  nodes['Invert.001'].inputs[1])
    node_tree.links.new(nodes['Combine RGBA.004'].outputs[0],  nodes['Invert.002'].inputs[1])
    node_tree.links.new(nodes['Combine RGBA.005'].outputs[0],  nodes['Invert.003'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.001'].outputs[0],  nodes['Invert.009'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.002'].outputs[0],  nodes['Invert.013'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.003'].outputs[0],  nodes['Invert.017'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.004'].outputs[0],  nodes['Invert.021'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.001'].outputs[1],  nodes['Invert.010'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.001'].outputs[2],  nodes['Invert.012'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.001'].outputs[3],  nodes['Invert.011'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.002'].outputs[1],  nodes['Invert.014'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.002'].outputs[2],  nodes['Invert.016'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.002'].outputs[3],  nodes['Invert.015'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.003'].outputs[1],  nodes['Invert.020'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.003'].outputs[2],  nodes['Invert.019'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.003'].outputs[3],  nodes['Invert.018'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.004'].outputs[1],  nodes['Invert.024'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.004'].outputs[2],  nodes['Invert.023'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.004'].outputs[3],  nodes['Invert.022'].inputs[1])
    node_tree.links.new(nodes['Invert.009'].outputs[0],  nodes['Combine RGBA.002'].inputs[0])
    node_tree.links.new(nodes['Invert.010'].outputs[0],  nodes['Combine RGBA.002'].inputs[1])
    node_tree.links.new(nodes['Invert.011'].outputs[0],  nodes['Combine RGBA.002'].inputs[3])
    node_tree.links.new(nodes['Invert.012'].outputs[0],  nodes['Combine RGBA.002'].inputs[2])
    node_tree.links.new(nodes['Invert.013'].outputs[0],  nodes['Combine RGBA.003'].inputs[0])
    node_tree.links.new(nodes['Invert.014'].outputs[0],  nodes['Combine RGBA.003'].inputs[1])
    node_tree.links.new(nodes['Invert.015'].outputs[0],  nodes['Combine RGBA.003'].inputs[3])
    node_tree.links.new(nodes['Invert.016'].outputs[0],  nodes['Combine RGBA.003'].inputs[2])
    node_tree.links.new(nodes['Invert.017'].outputs[0],  nodes['Combine RGBA.004'].inputs[0])
    node_tree.links.new(nodes['Invert.018'].outputs[0],  nodes['Combine RGBA.004'].inputs[3])
    node_tree.links.new(nodes['Invert.019'].outputs[0],  nodes['Combine RGBA.004'].inputs[2])
    node_tree.links.new(nodes['Invert.020'].outputs[0],  nodes['Combine RGBA.004'].inputs[1])
    node_tree.links.new(nodes['Invert.021'].outputs[0],  nodes['Combine RGBA.005'].inputs[0])
    node_tree.links.new(nodes['Invert.022'].outputs[0],  nodes['Combine RGBA.005'].inputs[3])
    node_tree.links.new(nodes['Invert.023'].outputs[0],  nodes['Combine RGBA.005'].inputs[2])
    node_tree.links.new(nodes['Invert.024'].outputs[0],  nodes['Combine RGBA.005'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.005'].outputs[0],  nodes['Invert.025'].inputs[1])
    node_tree.links.new(nodes['Combine RGBA.006'].outputs[0],  nodes['Invert.004'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.005'].outputs[1],  nodes['Invert.028'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.005'].outputs[2],  nodes['Invert.027'].inputs[1])
    node_tree.links.new(nodes['Separate RGBA.005'].outputs[3],  nodes['Invert.026'].inputs[1])
    node_tree.links.new(nodes['Invert.025'].outputs[0],  nodes['Combine RGBA.006'].inputs[0])
    node_tree.links.new(nodes['Invert.026'].outputs[0],  nodes['Combine RGBA.006'].inputs[3])
    node_tree.links.new(nodes['Invert.027'].outputs[0],  nodes['Combine RGBA.006'].inputs[2])
    node_tree.links.new(nodes['Invert.028'].outputs[0],  nodes['Combine RGBA.006'].inputs[1])
    return my_nodes


    
    #-------------------------------------------------------------------------------------


def process_args(args, my_nodes, scene):
    
    #args is a dictionary
    
    #Total input inverts
    
    my_nodes["r_input_img_invert"].mute = False if (("r_input_total_invert_on" in args) and args["r_input_total_invert_on"]) else True
    my_nodes["g_input_img_invert"].mute = False if (("g_input_total_invert_on" in args) and args["g_input_total_invert_on"]) else True
    my_nodes["b_input_img_invert"].mute = False if (("b_input_total_invert_on" in args) and args["b_input_total_invert_on"]) else True
    my_nodes["a_input_img_invert"].mute = False if (("a_input_total_invert_on" in args) and args["a_input_total_invert_on"]) else True
    my_nodes["x_input_img_invert"].mute = False if (("x_input_total_invert_on" in args) and args["x_input_total_invert_on"]) else True

    #Input channel inverts

    my_nodes["r_input_img_r_invert"].mute = False if (("r_input_r_invert_on" in args) and args["r_input_r_invert_on"]) else True
    my_nodes["r_input_img_g_invert"].mute = False if (("r_input_g_invert_on" in args) and args["r_input_g_invert_on"]) else True
    my_nodes["r_input_img_b_invert"].mute = False if (("r_input_b_invert_on" in args) and args["r_input_b_invert_on"]) else True
    my_nodes["r_input_img_a_invert"].mute = False if (("r_input_a_invert_on" in args) and args["r_input_a_invert_on"]) else True


    my_nodes["g_input_img_r_invert"].mute = False if (("g_input_r_invert_on" in args) and args["g_input_r_invert_on"]) else True
    my_nodes["g_input_img_g_invert"].mute = False if (("g_input_g_invert_on" in args) and args["g_input_g_invert_on"]) else True
    my_nodes["g_input_img_b_invert"].mute = False if (("g_input_b_invert_on" in args) and args["g_input_b_invert_on"]) else True
    my_nodes["g_input_img_a_invert"].mute = False if (("g_input_a_invert_on" in args) and args["g_input_a_invert_on"]) else True


    my_nodes["b_input_img_r_invert"].mute = False if (("b_input_r_invert_on" in args) and args["b_input_r_invert_on"]) else True
    my_nodes["b_input_img_g_invert"].mute = False if (("b_input_g_invert_on" in args) and args["b_input_g_invert_on"]) else True
    my_nodes["b_input_img_b_invert"].mute = False if (("b_input_b_invert_on" in args) and args["b_input_b_invert_on"]) else True
    my_nodes["b_input_img_a_invert"].mute = False if (("b_input_a_invert_on" in args) and args["b_input_a_invert_on"]) else True


    my_nodes["a_input_img_r_invert"].mute = False if (("a_input_r_invert_on" in args) and args["a_input_r_invert_on"]) else True
    my_nodes["a_input_img_g_invert"].mute = False if (("a_input_g_invert_on" in args) and args["a_input_g_invert_on"]) else True
    my_nodes["a_input_img_b_invert"].mute = False if (("a_input_b_invert_on" in args) and args["a_input_b_invert_on"]) else True
    my_nodes["a_input_img_a_invert"].mute = False if (("a_input_a_invert_on" in args) and args["a_input_a_invert_on"]) else True

    my_nodes["x_input_img_r_invert"].mute = False if (("x_input_r_invert_on" in args) and args["x_input_r_invert_on"]) else True
    my_nodes["x_input_img_g_invert"].mute = False if (("x_input_g_invert_on" in args) and args["x_input_g_invert_on"]) else True
    my_nodes["x_input_img_b_invert"].mute = False if (("x_input_b_invert_on" in args) and args["x_input_b_invert_on"]) else True
    my_nodes["x_input_img_a_invert"].mute = False if (("x_input_a_invert_on" in args) and args["x_input_a_invert_on"]) else True    
    
    #Output inverts
    
    my_nodes["output_r_img_invert"].mute = False if (("output_r_invert_on" in args) and args["output_r_invert_on"]) else True    
    my_nodes["output_g_img_invert"].mute = False if (("output_g_invert_on" in args) and args["output_g_invert_on"]) else True    
    my_nodes["output_b_img_invert"].mute = False if (("output_b_invert_on" in args) and args["output_b_invert_on"]) else True    
    my_nodes["output_a_img_invert"].mute = False if (("output_a_invert_on" in args) and args["output_a_invert_on"]) else True    
    
    
    #my_nodes["x_img_mix"].inputs[0].default_value = 1 if (("x_input_on" in args) and args["x_input_on"]) else 0
    
    im_list = []
    #Input images
    #Set the RGBA images
    if "input_r" in args:
        my_nodes["r_input_img"].image = args["input_r"]
        im_list.append(args["input_r"])
    else:
        my_nodes["r_input_img"].image = None
        scene.node_tree.links.remove(my_nodes["r_input_img_invert"].outputs[0].links[0])
        
    if "input_g" in args:
        my_nodes["g_input_img"].image = args["input_g"]
        im_list.append(args["input_g"])
    else:
        my_nodes["g_input_img"].image = None        
        scene.node_tree.links.remove(my_nodes["g_input_img_invert"].outputs[0].links[0])
        
    if "input_b" in args:
        my_nodes["b_input_img"].image = args["input_b"]
        im_list.append(args["input_b"])
    else:
        my_nodes["b_input_img"].image = None
        scene.node_tree.links.remove(my_nodes["b_input_img_invert"].outputs[0].links[0])
        
    if "input_a" in args:
        my_nodes["a_input_img"].image = args["input_a"]
        im_list.append(args["input_a"])
    else:
        my_nodes["a_input_img"].image = None
        scene.node_tree.links.remove(my_nodes["a_input_img_invert"].outputs[0].links[0])

    #X img mix
    node_tree = scene.node_tree
    if ("x_input_on" in args) and args["x_input_on"]:
        my_nodes["x_input_img"].image = args["input_x"]
        node_tree.links.new(my_nodes['x_input_img_invert'].outputs[0],  my_nodes['allinput_sepRGBA'].inputs[0])
    else:
        node_tree.links.new(my_nodes['input_comb'].outputs[0],  my_nodes['allinput_sepRGBA'].inputs[0])
    
    #Bit silly that we have to do this, but apparently we do
    #if ("x_input_on" in args) and args["x_input_on"]:
        #my_nodes["x_img_mix"].inputs[0].default_value = 1
        #Set all inputs to the same image
        #my_nodes["r_input_img"].image = args["input_x"]
        #my_nodes["g_input_img"].image = args["input_x"]
        #my_nodes["b_input_img"].image = args["input_x"]
        #my_nodes["a_input_img"].image = args["input_x"]
        #my_nodes["x_input_img"].image = args["input_x"]
        #Mute the non-x alpha
        #my_nodes["a_input_img"].mute=True
    #else:
        #my_nodes["x_img_mix"].inputs[0].default_value = 0
        
    #Set the render size to that of our biggest image:
    if ("x_input_on" in args) and args["x_input_on"]:
        scene.render.resolution_x = args["input_x"].size[0]
        scene.render.resolution_y = args["input_x"].size[1]
    else:
        biggest_x = 0
        biggest_y = 0
        for img in im_list:
            if img.size[0] > biggest_x:
                biggest_x = img.size[0]
            if img.size[1] > biggest_y:
                biggest_y = img.size[1]
        scene.render.resolution_x = biggest_x
        scene.render.resolution_y = biggest_y

    #Perform the isolations
    
    #--------------- R INPUT ----------------------------------------------------------------
    
    if ("r_input_isolate_r" in args) and (args["r_input_isolate_r"]):
        #scene.node_tree.links.remove(my_nodes["r_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_a_invert"].outputs[0].links[0])
    

    if ("r_input_isolate_g" in args) and (args["r_input_isolate_g"]):
        scene.node_tree.links.remove(my_nodes["r_input_img_r_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["r_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_a_invert"].outputs[0].links[0])


    if ("r_input_isolate_b" in args) and (args["r_input_isolate_b"]):
        scene.node_tree.links.remove(my_nodes["r_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_g_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["r_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_a_invert"].outputs[0].links[0])

    if ("r_input_isolate_a" in args) and (args["r_input_isolate_a"]):
        scene.node_tree.links.remove(my_nodes["r_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["r_input_img_b_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["r_input_img_a_invert"].outputs[0].links[0])
        
    #--------------- G INPUT ----------------------------------------------------------------
    
    if ("g_input_isolate_r" in args) and (args["g_input_isolate_r"]):
        #scene.node_tree.links.remove(my_nodes["g_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_a_invert"].outputs[0].links[0])

    if ("g_input_isolate_g" in args) and (args["g_input_isolate_g"]):
        scene.node_tree.links.remove(my_nodes["g_input_img_r_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["r_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_a_invert"].outputs[0].links[0])

    if ("g_input_isolate_b" in args) and (args["g_input_isolate_b"]):
        scene.node_tree.links.remove(my_nodes["g_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_g_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["g_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_a_invert"].outputs[0].links[0])

    if ("g_input_isolate_a" in args) and (args["g_input_isolate_a"]):
        scene.node_tree.links.remove(my_nodes["g_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["g_input_img_b_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["g_input_img_a_invert"].outputs[0].links[0])
    
    #--------------- B INPUT ----------------------------------------------------------------
    
    if ("b_input_isolate_r" in args) and (args["b_input_isolate_r"]):
        #scene.node_tree.links.remove(my_nodes["b_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_a_invert"].outputs[0].links[0])

    if ("b_input_isolate_g" in args) and (args["b_input_isolate_g"]):
        scene.node_tree.links.remove(my_nodes["b_input_img_r_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["b_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_a_invert"].outputs[0].links[0])

    if ("b_input_isolate_b" in args) and (args["b_input_isolate_b"]):
        scene.node_tree.links.remove(my_nodes["b_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_g_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["b_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_a_invert"].outputs[0].links[0])

    if ("b_input_isolate_a" in args) and (args["b_input_isolate_a"]):
        scene.node_tree.links.remove(my_nodes["b_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["b_input_img_b_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["b_input_img_a_invert"].outputs[0].links[0])

    #--------------- A INPUT ----------------------------------------------------------------
    
    if ("a_input_isolate_r" in args) and (args["a_input_isolate_r"]):
        #scene.node_tree.links.remove(my_nodes["a_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_a_invert"].outputs[0].links[0])

    if ("a_input_isolate_g" in args) and (args["a_input_isolate_g"]):
        scene.node_tree.links.remove(my_nodes["a_input_img_r_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["a_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_a_invert"].outputs[0].links[0])

    if ("a_input_isolate_b" in args) and (args["a_input_isolate_b"]):
        scene.node_tree.links.remove(my_nodes["a_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_g_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["a_input_img_b_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_a_invert"].outputs[0].links[0])

    if ("a_input_isolate_a" in args) and (args["a_input_isolate_a"]):
        scene.node_tree.links.remove(my_nodes["a_input_img_r_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_g_invert"].outputs[0].links[0])
        scene.node_tree.links.remove(my_nodes["a_input_img_b_invert"].outputs[0].links[0])
        #scene.node_tree.links.remove(my_nodes["a_input_img_a_invert"].outputs[0].links[0])
        
        
    #Adapt for missing images
    
    

def post_process(internal_img_name, path_dir="", path_filename="", file_format="OPEN_EXR", save=False, **args):
    #Path is a pathlib object
    #save is a bool
    #internal_img_name is a string
        
    
    #Create new scene
    scene = bpy.data.scenes.new("SBCompositing")
    

    #Scene.use_nodes
    scene.use_nodes = True

    #Get node handlers
    node_tree = scene.node_tree
    nodes = node_tree.nodes

    #Delete all default nodes from new scene
    for node in nodes:
        nodes.remove(node)
    
    #Create the node structure that we need
    #Returns a dictionary of nodes
    my_nodes = setup_nodes(scene)
    
    
    #Process the arguments that were passed, mostly mute options
    process_args(args, my_nodes, scene)
    
        
    #Render to temp file for the internal image
    tmpdir = Path(tempfile.mkdtemp())
    scene.render.filepath = str(tmpdir / path_filename)
    #Let's always do this an EXR
    scene.render.image_settings.file_format = "OPEN_EXR"
    bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=scene.name)
    
    
    #Reload the temp file into an internal image again
    img = bpy.data.images.load(str(tmpdir / path_filename)+"."+"exr")
    
    
    #Make sure that image is non-color for now
    img.colorspace_settings.name = "Non-Color"
    
    #Pack image, so we don't lose it when we delete the temp file
    img.pack()
    
    
    #Rename internal image
    img.name = internal_img_name
    
    #Delete the external tmp file
    shutil.rmtree(str(tmpdir))    

    
    
    if save:
        #Render to output file, if we are saving extnerally
        scene.render.filepath = str(path_dir / path_filename)
        
        #Set file format to requested
        scene.render.image_settings.file_format = file_format
        
        #Save
        bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=scene.name)
    
    
    #Delete the new scene
    #bpy.data.scenes.remove(scene)
    
    
    return True
    
    
    
    
    
#r = bpy.data.images["rgb_squares.png"]
#g = bpy.data.images["rgb_squares.png"]
#b = bpy.data.images["B.png"]
#a = bpy.data.images["A.png"]

#path_dir = Path("/home/lewis/OneDrive/Blender/Current Projects/SimpleBake/Output/")
#path_filename = Path("testoutput")
#internal_img_name = "Testing"

##Inputs
#input_r=bpy img
#path_dir=""
#path_filename=""
#internal_img_name=""

##Options
#r_input_total_invert_on=True
#r_input_r_invert_on=True
#output_r_invert_on=True
#x_input_on=True

#Normal map example
#post_process(path_dir=path_dir, path_filename=path_filename, internal_img_name=internal_img_name, 
#        save=True, input_x=bpy.data.images["Cube_Bake2_normal.png"], x_input_on=True, output_g_invert_on=True)

#post_process(path_dir=path_dir, path_filename=path_filename, internal_img_name=internal_img_name, 
        #save=True, input_r=r,input_g=g,input_b=b,input_a=a, output_r_invert_on=True)
        
#post_process(internal_img_name=internal_img_name, input_g=g, input_r=r, g_input_isolate_g=True, r_input_isolate_r=True)
