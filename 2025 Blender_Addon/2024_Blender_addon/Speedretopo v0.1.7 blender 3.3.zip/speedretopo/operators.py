# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>
import bpy
import bmesh
from mathutils import *
import math
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       FloatVectorProperty,
                       BoolVectorProperty,
                       PointerProperty)
from .ui import get_addon_preferences

# -----------------------------------------------------------------------------
#    Activate addons
# -----------------------------------------------------------------------------

# class SPEEDRETOPO_OT_activate_bsurfaces(bpy.types.Operator):
#     bl_idname = "speedretopo.activate_bsurfaces"
#     bl_label = "Activate Bsurfaces"
#     bl_description = "Activate Bsurfaces"
#     bl_options = {"REGISTER"}
#
#     def execute(self, context):
#         bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")
#         bpy.ops.wm.save_userpref()
#         return {"FINISHED"}
#
#
# class SPEEDRETOPO_OT_activate_looptools(bpy.types.Operator):
#     bl_idname = "speedretopo.activate_looptools"
#     bl_label = "Activate Lopptools"
#     bl_description = "Activate Looptools"
#     bl_options = {"REGISTER"}
#
#     def execute(self, context):
#         bpy.ops.preferences.addon_enable(module="mesh_looptools")
#         bpy.ops.wm.save_userpref()
#         return {"FINISHED"}



# -----------------------------------------------------------------------------
#    Setup Retopo
# -----------------------------------------------------------------------------

class SPEEDRETOPO_OT_set_face_sets(bpy.types.Operator):
    bl_idname = 'object.speedretopo_set_face_sets'
    bl_label = "Set Face Sets"
    bl_description = "Set Face Sets"
    bl_options = {'REGISTER'}

    face_sets_from: EnumProperty(
        items=(('face_sets_from_selection', "Face Sets From Selection", ""),
               ('face_sets_by_loose_parts', "Face Sets By Loose Parts", ""),
               ('clear_face_sets', "Clear Face Sets", ""),
               ('face_sets_from_visible', "Face Sets From Visible", ""),
               ('face_sets_from_masked', "Face Sets From Masked", ""),),
        default='face_sets_from_selection',
        description = "Set Face Sets")

    def execute(self, context):
        self.obj_mode = context.object.mode

        self.mode_edit = False
        self.mode_object = False

        if context.object.mode == 'EDIT':
            self.mode_edit = True
        else:
            self.mode_object = True

        bpy.ops.object.mode_set(mode='SCULPT')

        if self.face_sets_from == 'face_sets_from_selection':
            bpy.ops.sculpt.face_sets_create(mode='SELECTION')

        elif self.face_sets_from == 'face_sets_by_loose_parts':
            bpy.ops.sculpt.face_sets_init(mode='LOOSE_PARTS')

        elif self.face_sets_from == 'face_sets_from_visible':
            bpy.ops.sculpt.face_sets_create(mode='VISIBLE')

        # elif self.face_sets_from == 'face_sets_from_masked':
        #     bpy.ops.sculpt.face_sets_create(mode='MASKED')

        # else:
        #     bpy.ops.sculpt.face_sets_create(mode='ALL')

        # if self.mode_edit :
        #     bpy.ops.object.mode_set(mode='EDIT')
        # elif self.mode_object:
        #     bpy.ops.object.mode_set(mode='OBJECT')
        # else:
        #     bpy.ops.object.mode_set(mode='SCULPT')
        #
        # if self.face_sets_from in {'face_sets_from_selection','face_sets_by_loose_parts','face_sets_from_visible'}:
        bpy.ops.object.mode_set(mode='SCULPT')

        return {'FINISHED'}


# Setup Retopo
class SPEEDRETOPO_OT_create_speedretopo(bpy.types.Operator):
    bl_idname = "object.speedretopo_create_retopo"
    bl_label = "Create Speed Retopo"
    bl_description = "Start Retopology"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        # addonPref = context.preferences.addons[__name__].preferences
        addonPref = get_addon_preferences()
        self.hidden_wire = addonPref.hidden_wire
        self.obj_color = addonPref.obj_color
        self.use_color_shader = addonPref.use_color_shader
        start_from = addonPref.start_from
        auto_add_mirror = addonPref.auto_add_mirror
        auto_add_shrinkwrap = addonPref.auto_add_shrinkwrap
        use_in_front = addonPref.use_in_front
        use_wireframe = addonPref.use_wireframe
        # speedretopo_PropertyGroup = context.window_manager.speedretopo_PropertyGroup

        new_ref_object = context.active_object

        bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")
        bpy.ops.preferences.addon_enable(module="mesh_looptools")

        # if hasattr(bpy.types, "VIEW3D_PT_tools_SURFSK_mesh"):
        # Prepare Grease Pencil
        context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'

        # Add snap
        context.scene.tool_settings.use_snap = True
        context.scene.tool_settings.snap_elements = {'FACE'}
        context.scene.tool_settings.use_snap_translate = True

        # Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(size=0.2, enter_editmode=False, location=(0, 0, 0))
        context.active_object.name = new_ref_object.name + "_Retopo"
        context.object.data.name = new_ref_object.name + "_Retopo"

        self.retopo = context.active_object

        # SET CUSTOM PROP
        context.active_object.speedretopo_ref_object = new_ref_object
        context.scene.bsurfaces.SURFSK_mesh = self.retopo
        bpy.ops.object.mode_set(mode='EDIT')

        # SHADING
        if use_wireframe:
            context.object.show_wire = True
            context.object.show_all_edges = True

        if use_in_front:
            context.object.show_in_front = True
            if (2, 81, 0) < bpy.app.version:
                context.scene.bsurfaces.SURFSK_in_front = True

        if self.hidden_wire and not self.use_color_shader:
            context.space_data.overlay.show_occlude_wire = True

        elif self.use_color_shader and not self.hidden_wire:
            context.space_data.shading.light = 'MATCAP'
            context.space_data.shading.color_type = 'OBJECT'
            context.object.color = self.obj_color
            context.space_data.overlay.show_occlude_wire = False

        elif self.use_color_shader and self.hidden_wire:
            self.hidden_wire = False
            context.space_data.shading.light = 'MATCAP'
            context.space_data.shading.color_type = 'OBJECT'
            context.object.color = self.obj_color
            context.space_data.overlay.show_occlude_wire = False

        elif not self.use_color_shader and not self.hidden_wire:
            context.space_data.overlay.show_occlude_wire = False

        context.scene.tool_settings.use_mesh_automerge = True

        if start_from == 'BSURFACE':
            bpy.ops.mesh.delete(type='VERT')
        elif start_from == 'POLYBUILD':
            bpy.ops.mesh.delete(type='VERT')
            bpy.ops.wm.tool_set_by_id(name="builtin.poly_build")
        elif start_from == 'VERTEX':
            bpy.ops.mesh.merge(type='CENTER')
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')

        if start_from in {'BSURFACE', 'VERTEX'}:
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
        elif start_from == 'POLYBUILD':
            bpy.ops.wm.tool_set_by_id(name="mesh_tool.poly_build", cycle=False, space_type='VIEW_3D')

        bpy.ops.object.mode_set(mode='OBJECT')

        if (2, 81, 0) < bpy.app.version:
            context.scene.bsurfaces.SURFSK_mesh = self.retopo
            context.scene.bsurfaces.SURFSK_guide = 'Annotation'

        elif (2, 80, 0) < bpy.app.version:
            context.scene.bsurfaces.SURFSK_object_with_retopology = self.retopo

        # Add Mirror
        if auto_add_mirror:
            mod_mirror = self.retopo.modifiers.new("Mirror", 'MIRROR')
            mod_mirror.use_axis[0] = True
            mod_mirror.mirror_object = new_ref_object
            # mod_mirror.mirror_object = bpy.data.objects[speedretopo_PropertyGroup.speedretopo_ref_obj.name]
            mod_mirror.show_on_cage = True
            mod_mirror.use_clip = False
            mod_mirror.merge_threshold = 0.001
            mod_mirror.use_mirror_merge = True
            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror")


        #create the vgroup
        has_vgroup = False
        for vgroup in self.retopo.vertex_groups:
            if vgroup.name == "Speedretopo_freeze_unfreeze":
                has_vgroup = True
                continue

        if not has_vgroup:
            self.retopo.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        # Add Shrinkwrap
        if auto_add_shrinkwrap:
            mod_shrinkwrap = self.retopo.modifiers.new("Shrinkwrap", 'SHRINKWRAP')
            mod_shrinkwrap.target = new_ref_object
            mod_shrinkwrap.wrap_method = 'PROJECT'
            mod_shrinkwrap.use_negative_direction = True
            mod_shrinkwrap.use_positive_direction = True
            mod_shrinkwrap.cull_face = 'OFF'
            mod_shrinkwrap.wrap_mode = 'ABOVE_SURFACE'
            mod_shrinkwrap.show_on_cage = True
            mod_shrinkwrap.vertex_group = "Speedretopo_freeze_unfreeze"
            mod_shrinkwrap.invert_vertex_group = True

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')

        if start_from == 'VERTEX':
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.transform.translate('INVOKE_DEFAULT')

            # CLEAR CURSOR
            context.scene.cursor.location[:] = context.scene.cursor.rotation_euler[:] = (0, 0, 0)
        # else:
        #     self.report({'WARNING'}, "Activate Bsurfaces")
        return {"FINISHED"}


# -----------------------------------------------------------------------------
#    Align to X
# -----------------------------------------------------------------------------

# Align to X
class SPEEDRETOPO_OT_align_center_edges(bpy.types.Operator):
    bl_idname = "object.speedretopo_align_center_edges"
    bl_label = "Align Center Edges"
    bl_description = "Align Vertices to the center of the grid"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        '''
        # suppression des edges internes
        boundary_edges = get_edges_boundary_loop(bm, 1)
        for e in bm.edges:
            if e.select and not e in boundary_edges:
        '''

        ob = context.object
        current_mode = ob.mode
        bpy.ops.object.mode_set(mode = 'EDIT')


        me = ob.data
        bm = bmesh.from_edit_mesh(me)

        for v in bm.verts:
            if len([v for v in bm.verts if v.select]) >= 1:
                if v.select:
                    v.co[0] = 0

            else:
                v.select_set(abs(v.co[0]) < 0.01)

                bm.edges.ensure_lookup_table()
                e = bm.edges[0]
                for loop in e.link_loops: # select loop
                    if len(loop.vert.link_edges) == 4:
                        e.select = True

                        while len(loop.vert.link_edges) == 4:
                            loop = loop.link_loop_prev.link_loop_radial_prev.link_loop_prev
                            e_next = loop.edge
                            e_next.select = True

                if v.select:
                    v.co[0] = 0


        bm.select_mode |= {'VERT'}
        bmesh.update_edit_mesh(me)
        bm.select_flush_mode()

        bpy.ops.object.mode_set(mode = current_mode)

        return {'FINISHED'}


# -----------------------------------------------------------------------------
#    SUBSURF
# -----------------------------------------------------------------------------

# Apply Subsurf
class SPEEDRETOPO_OT_add_subsurf(bpy.types.Operator):
    bl_idname = "object.speedretopo_add_subsurf"
    bl_label = "Add Subsurf Modifier"
    bl_description = "Add Subsurf Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        act_obj = context.active_object

        mod_subsurf = act_obj.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3
        mod_subsurf.show_only_control_edges = True
        mod_subsurf.show_in_editmode = False
        shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
        if shrinkwrap:
            bpy.ops.object.modifier_move_up(modifier="Subsurf")
        return {'FINISHED'}


# Remove Subsurf
class SPEEDRETOPO_OT_remove_subsurf(bpy.types.Operator):
    bl_idname = "object.speedretopo_remove_subsurf"
    bl_label = "Remove Subsurf Modifier"
    bl_description = "Remove Subsurf Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Subsurf")
        return {"FINISHED"}


# Apply Subsurf
class SPEEDRETOPO_OT_apply_subsurf(bpy.types.Operator):
    bl_idname = "object.speedretopo_apply_subsurf"
    bl_label = "Apply Subsurf Modifier"
    bl_description = "Apply Subsurf Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="Subsurf")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Subsurf")
        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="Subsurf")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Subsurf")
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


# -----------------------------------------------------------------------------
#    Mirror
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_add_mirror(bpy.types.Operator):
    """ Automatically cut an object along an axis """
    bl_idname = "object.speedretopo_add_mirror"
    bl_label = "Add Mirror Modifier"
    bl_description = "Add Mirror Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        act_obj = context.active_object

        mod_mirror = act_obj.modifiers.new("Mirror", 'MIRROR')
        mod_mirror.use_axis[0] = True
        mod_mirror.mirror_object = context.active_object.speedretopo_ref_object
        mod_mirror.show_on_cage = True
        mod_mirror.use_clip = True
        mod_mirror.merge_threshold = 0.001
        mod_mirror.use_mirror_merge = True
        shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
        subsurf = context.active_object.modifiers.get("Subsurf")
        if shrinkwrap:
            bpy.ops.object.modifier_move_up(modifier=mod_mirror.name)
        if subsurf:
            bpy.ops.object.modifier_move_up(modifier=mod_mirror.name)
        return {'FINISHED'}


# Apply Mirror
class SPEEDRETOPO_OT_apply_mirror(bpy.types.Operator):
    bl_idname = "object.speedretopo_apply_mirror"
    bl_label = "Apply Mirror Modifier"
    bl_description = "Apply Mirror Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="Mirror")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")

        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="Mirror")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Mirror")
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

    # Remove


class SPEEDRETOPO_OT_remove_mirror(bpy.types.Operator):
    bl_idname = "object.speedretopo_remove_mirror"
    bl_label = "Remove Mirror Modifier"
    bl_description = "Remove Mirror Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Mirror")
        return {"FINISHED"}


# -----------------------------------------------------------------------------
#    Shrinkwrap
# -----------------------------------------------------------------------------
# Remove
class SPEEDRETOPO_OT_remove_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.speedretopo_remove_shrinkwrap"
    bl_label = "Remove Shrinkwrap Modifier"
    bl_description = "Remove Shrinkwrap Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Shrinkwrap")
        return {"FINISHED"}


# Apply Shrinkwrap
class SPEEDRETOPO_OT_add_and_apply_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.speedretopo_add_apply_shrinkwrap"
    bl_label = "Add and Apply Shrinkwrap Modifier"
    bl_description = "Add and Apply Shrinkwrap Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.speedretopo_add_shrinkwrap()
        bpy.ops.object.speedretopo_apply_shrinkwrap()
        return {'FINISHED'}


# Apply Shrinkwrap
class SPEEDRETOPO_OT_apply_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.speedretopo_apply_shrinkwrap"
    bl_label = "Apply Shrinkwrap Modifier"
    bl_description = "Apply Shrinkwrap Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        for mod in context.object.modifiers:
            if mod.type == 'SHRINKWRAP':
                ref = mod.target
                context.active_object.speedretopo_ref_object = ref

        if context.object.mode in {"OBJECT", 'SCULPT'}:
            bpy.ops.object.modifier_apply(modifier="Shrinkwrap")
        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Shrinkwrap")
            bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}


# Add Shrinkwrap
class SPEEDRETOPO_OT_add_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.speedretopo_add_shrinkwrap"
    bl_label = "Add Shrinkwrap Modifier"
    bl_description = "Add Shrinkwrap Modifier"
    bl_options = {"REGISTER", 'UNDO'}

    def execute(self, context):
        act_obj = context.active_object

        has_vgroup = False
        for vgroup in act_obj.vertex_groups:
            if vgroup.name == "Speedretopo_freeze_unfreeze":
                has_vgroup = True
                continue

        if not has_vgroup:
            act_obj.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        if context.active_object.speedretopo_ref_object:
            # Add Shrinkwrap
            mod_shrinkwrap = act_obj.modifiers.new("Shrinkwrap", 'SHRINKWRAP')
            mod_shrinkwrap.wrap_method = 'PROJECT'
            mod_shrinkwrap.use_negative_direction = True
            mod_shrinkwrap.use_positive_direction = True
            mod_shrinkwrap.cull_face = 'OFF'
            mod_shrinkwrap.wrap_mode = 'ABOVE_SURFACE'
            mod_shrinkwrap.show_on_cage = True
            mod_shrinkwrap.target = context.active_object.speedretopo_ref_object
            if has_vgroup:
                mod_shrinkwrap.vertex_group = "Speedretopo_freeze_unfreeze"
                mod_shrinkwrap.invert_vertex_group = True

            #set center vertices
            act_obj_mode = context.active_object.mode

            bpy.ops.object.mode_set(mode='EDIT')
            me = act_obj.data
            bm = bmesh.from_edit_mesh(me)
            v_selection = [v for v in act_obj.data.vertices if v.select]
            print(v_selection)
            bpy.ops.mesh.select_all(action='DESELECT')

            has_center_vgroup = False
            for vgroup in act_obj.vertex_groups:
                if vgroup.name == "Speedretopo_set_unset_center":
                    bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
                    bpy.ops.object.vertex_group_select()
                    has_center_vgroup = True

                    for v in bm.verts :
                        if v.select :
                            bpy.ops.object.speedretopo_align_center_edges()

            bpy.ops.mesh.select_all(action='DESELECT')
            for v in v_selection:
                v.select = True

            bpy.ops.object.mode_set(mode=act_obj_mode)

        else:
            self.report({'WARNING'}, "No active object, could not finish")

        return {'FINISHED'}


# Update Shrinkwrap
class SPEEDRETOPO_OT_update_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.speedretopo_update_shrinkwrap"
    bl_label = "Update shrinkwrap Modifier"
    bl_description = "Update shrinkwrap Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):

        # bpy.ops.object.speedretopo_align_center_edges()
        bpy.ops.object.speedretopo_apply_shrinkwrap()
        bpy.ops.object.speedretopo_add_shrinkwrap()
        bpy.ops.object.speedretopo_clean_normals()

        # edit_mode = False
        # if context.object.mode == 'EDIT':
        #     edit_mode = True
        #     bpy.ops.object.mode_set(mode='OBJECT')
        # ob = bpy.context.active_object
        # obtarget = bpy.data.objects[ob.name]
        #
        # mod_props = []
        #
        # for mod in ob.modifiers:
        #     properties = []
        #     for prop in mod.bl_rna.properties:
        #         if not prop.is_readonly:
        #             properties.append(prop.identifier)
        #     mod_props.append([mod, properties])
        #
        #     bpy.ops.object.modifier_apply(modifier="Shrinkwrap")
        #
        # bpy.ops.object.modifier_add(type='SHRINKWRAP')
        #
        #
        #
        # for stuff in mod_props:
        #     for prop in stuff[1]:
        #         setattr(obtarget.modifiers[stuff[0].name], prop, getattr(stuff[0], prop))



        # if edit_mode:
        #     bpy.ops.object.mode_set(mode='EDIT')
        return {"FINISHED"}


# Update Shrinkwrap
class SPEEDRETOPO_OT_clean_normals(bpy.types.Operator):
    bl_idname = "object.speedretopo_clean_normals"
    bl_label = "Recalculate Normals"
    bl_description = "Recalculate Normals"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        act_obj = context.active_object
        mode = act_obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        me = act_obj.data
        bm = bmesh.from_edit_mesh(me)

        vert_selected = ([v for v in bm.verts if v.select])

        # RECALCULATE NORMAL OUTSIDE
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action='DESELECT')

        for v in vert_selected:
            v.select = True

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.shade_smooth(use_auto_smooth=True)
        # bpy.ops.object.shade_smooth()
        bpy.ops.object.mode_set(mode=mode)
        return {"FINISHED"}


# -----------------------------------------------------------------------------
#   Relax
# -----------------------------------------------------------------------------
# LapRelax
class SPEEDRETOPO_OT_srrelax(bpy.types.Operator):
    bl_idname = "mesh.speedretopo_relax"
    bl_label = "Relax"
    bl_description = "Smoothing mesh keeping volume"
    bl_options = {'REGISTER', 'UNDO'}

    Repeat: bpy.props.IntProperty(
        name="Repeat",
        description="Repeat how many times",
        default=5,
        min=1,
        max=100)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH')

    def invoke(self, context, event):

        # smooth #Repeat times
        for i in range(self.Repeat):
            self.do_laprelax()

        # bpy.ops.mesh.select_all(action='DESELECT')
        return {'FINISHED'}

    def do_laprelax(self):

        context = bpy.context
        region = context.region
        area = context.area
        selobj = bpy.context.active_object
        mesh = selobj.data
        bm = bmesh.from_edit_mesh(mesh)
        bmprev = bm.copy()
        vertices = [v for v in bmprev.verts if v.select]

        if not vertices:
            bpy.ops.mesh.select_all(action='SELECT')

        for v in bmprev.verts:

            if v.select:

                tot = Vector((0, 0, 0))
                cnt = 0
                for e in v.link_edges:
                    for f in e.link_faces:
                        if not (f.select):
                            cnt = 1
                    if len(e.link_faces) == 1:
                        cnt = 1
                        break
                if cnt:
                    # dont affect border edges: they cause shrinkage
                    continue

                # find Laplacian mean
                for e in v.link_edges:
                    tot += e.other_vert(v).co
                tot /= len(v.link_edges)

                # cancel movement in direction of vertex normal
                delta = (tot - v.co)
                if delta.length != 0:
                    ang = delta.angle(v.normal)
                    deltanor = math.cos(ang) * delta.length
                    nor = v.normal
                    nor.length = abs(deltanor)
                    bm.verts.ensure_lookup_table()
                    bm.verts[v.index].co = tot + nor

        mesh.update()
        bm.free()
        bmprev.free()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

        # for v in vertices:
        #     v.select = True


# Space Relax
class SPEEDRETOPO_OT_space_relax(bpy.types.Operator):
    bl_idname = "object.speedretopo_space_relax"
    bl_label = "Space Relax"
    bl_description = "Relax Vertices"
    bl_options = {"REGISTER"}

    def execute(self, context):
        bpy.ops.mesh.looptools_space()
        bpy.ops.mesh.looptools_relax()

        return {"FINISHED"}

class SPEEDRETOPO_OT_symmetrize(bpy.types.Operator):
    bl_idname = 'object.speedretopo_symmetrize'
    bl_label = "Symmetrize MEsh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        actobj_mode = context.object.mode

        # bpy.ops.object.speedretopo_mesh_automirror()
        # bpy.ops.object.speedretopo_align_center_edges()

        bpy.ops.object.mode_set(mode='OBJECT')
        for mod in context.object.modifiers:
            if mod.type == 'MIRROR':
                bpy.ops.object.modifier_apply(modifier="Mirror")

        if context.object.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        bpy.ops.mesh.select_all(action='DESELECT')


        bpy.ops.object.mode_set(mode=actobj_mode)

        return {'FINISHED'}

class SPEEDRETOPO_OT_update_mirror(bpy.types.Operator):
    bl_idname = 'object.speedretopo_update_mirror'
    bl_label = "Update Mirror"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        # bpy.ops.object.speedretopo_mesh_automirror()

        # bpy.ops.mesh.select_all(action='SELECT')
        # bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        # bpy.ops.mesh.remove_doubles(threshold=0.3)
        # bpy.ops.mesh.select_all(action='DESELECT')

        bpy.ops.object.speedretopo_align_center_edges()
        bpy.ops.object.speedretopo_apply_mirror()
        bpy.ops.object.speedretopo_add_mirror()


        return {'FINISHED'}

class SPEEDRETOPO_OR_quadremesh(bpy.types.Operator):
    bl_idname = 'object.speedretopo_quadremesh'
    bl_label = "Quad Remesh"
    bl_options = {'REGISTER'}

    def execute(self, context):
        addonPref = get_addon_preferences()
        quad_use_mesh_symmetry = addonPref.quad_use_mesh_symmetry
        quad_use_preserve_sharp = addonPref.quad_use_preserve_sharp
        quad_use_preserve_boundary = addonPref.quad_use_preserve_boundary
        quad_preserve_paint_mask = addonPref.quad_preserve_paint_mask
        quad_smooth_normals = addonPref.quad_smooth_normals
        quad_mode = addonPref.quad_mode
        quad_target_ratio = addonPref.quad_target_ratio
        quad_target_edge_length = addonPref.quad_target_edge_length
        quad_target_faces = addonPref.quad_target_faces
        quad_mesh_area = addonPref.quad_mesh_area
        quad_seed = addonPref.quad_seed

        if addonPref.quad_mode == 'RATIO':
            faces_count = len(context.object.data.polygons)
            quad_target_faces = int(faces_count * quad_target_ratio)

        bpy.ops.object.quadriflow_remesh(use_mesh_symmetry=quad_use_mesh_symmetry,
                                         use_preserve_sharp=quad_use_preserve_sharp,
                                         use_preserve_boundary=quad_use_preserve_boundary,
                                         preserve_paint_mask=quad_preserve_paint_mask,
                                         smooth_normals=quad_smooth_normals,
                                         mode=quad_mode,
                                         target_ratio=quad_target_ratio,
                                         target_edge_length=quad_target_edge_length,
                                         target_faces=quad_target_faces,
                                         mesh_area=quad_mesh_area,
                                         seed=quad_seed)

        # Redraw Area to update the mesh
        for area in context.screen.areas:
            area.tag_redraw()


        return {'FINISHED'}


# -----------------------------------------------------------------------------
#    Auto Mirror
# -----------------------------------------------------------------------------
bpy.types.Scene.AutoMirror_cut: bpy.props.BoolProperty(default=True,
                                                       description="If enabled, cut the mesh in two parts and mirror it. If not, just make a loopcut")


# # Auto Mirror
class SPEEDRETOPO_OT_mesh_align_vertices(bpy.types.Operator):
    bl_idname = "object.speedretopo_align_vertices"
    bl_label = "Align Vertices on 1 Axis"
    bl_description = "Align Vertices to the Center of the Grid"
    bl_options = {'REGISTER'}

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')

        x1, y1, z1 = context.scene.cursor.location
        bpy.ops.view3d.snap_cursor_to_selected()

        x2, y2, z2 = context.scene.cursor.location

        context.scene.cursor.location[0], context.scene.cursor.location[1], context.scene.cursor.location[2] = 0, 0, 0

        # Vertices coordinate to 0 (local coordinate, so on the origin)
        for vert in context.object.data.vertices:
            if vert.select:
                axis = 0
                vert.co[axis] = 0

        context.scene.cursor.location = x2, y2, z2

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        context.scene.cursor.location = x1, y1, z1

        bpy.ops.object.mode_set(mode='EDIT')


        return {'FINISHED'}


class SPEEDRETOPO_OT_mesh_automirror(bpy.types.Operator):
    """ Automatically cut an object along an axis """
    bl_idname = "object.speedretopo_mesh_automirror"
    bl_label = "AutoMirror"
    bl_options = {'REGISTER'} # 'UNDO' ?

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH"

    def get_local_axis_vector(self, context, X, Y, Z, orientation):
        loc = context.object.location
        bpy.ops.object.mode_set(mode = "OBJECT") # Needed to avoid to translate vertices

        v1 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value = (X*orientation, Y*orientation, Z*orientation),
                                    constraint_axis = ((X==1), (Y==1), (Z==1)),
                                    orient_type = 'LOCAL')
        v2 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value = (-X*orientation, -Y*orientation, -Z*orientation),
                                    constraint_axis = ((X==1), (Y==1), (Z==1)),
                                    orient_type = 'LOCAL')

        bpy.ops.object.mode_set(mode="EDIT")
        return v2-v1

    def execute(self, context):
        context.active_object.select_set(True)

        # automirror = context.scene.automirror

        X,Y,Z = 1,0,0

        # if automirror.axis == 'x':
        #     X = 1
        # elif automirror.axis == 'y':
        #     Y = 1
        # elif automirror.axis == 'z':
        #     Z = 1

        bpy.ops.object.speedretopo_align_center_edges()
        current_mode = context.object.mode # Save the current mode

        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode = "EDIT") # Go to edit mode

        bpy.ops.mesh.select_all(action = 'SELECT') # Select all the vertices

        orientation = 1

        cut_normal = self.get_local_axis_vector(context, X, Y, Z, orientation)

        # Cut the mesh
        bpy.ops.mesh.bisect(
            plane_co = (
                context.object.location[0],
                context.object.location[1],
                context.object.location[2]
            ),
            plane_no = cut_normal,
            use_fill = False,
            clear_inner = True,
            clear_outer = 0,
            # threshold = automirror.threshold
            threshold = 0.001
        )

        bpy.ops.object.speedretopo_align_vertices() # Use to align the vertices on the origin, needed by the "threshold"

        # if not automirror.toggle_edit:
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode = current_mode) # Reload previous mode


        return {'FINISHED'}

# -----------------------------------------------------------------------------
#    Threshold
# -----------------------------------------------------------------------------
# Double Threshold 0.1
class SPEEDRETOPO_OT_double_threshold_plus(bpy.types.Operator):
    bl_idname = "object.speedretopo_double_threshold_plus"
    bl_label = "Double Threshold 01"
    bl_description = "Set the Double Threshold at 01"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # tool_settings = context.tool_settings
        context.scene.tool_settings.double_threshold = 0.1
        return {'FINISHED'}


# Double Threshold 0.001
class SPEEDRETOPO_OT_double_threshold_minus(bpy.types.Operator):
    bl_idname = "object.speedretopo_double_threshold_minus"
    bl_label = "Double Threshold 0001"
    bl_description = "Set the Double Threshold at 0001"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.tool_settings.double_threshold = 0.001
        return {'FINISHED'}


class SPEEDRETOPO_OT_continue_retopo(bpy.types.Operator):
    bl_idname = 'object.speedretopo_continue_retopo'
    bl_label = "Continue Retopo"
    bl_description = "Continue the Retopology"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH' if
                context.object.mode in {"OBJECT","SCULPT"}]) == 1:
            return True

    def execute(self, context):
        addonPref = get_addon_preferences()
        use_menu_or_pie_menu = addonPref.use_menu_or_pie_menu
        context.scene.bsurfaces.SURFSK_mesh = context.active_object
        bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}

class SPEEDRETOPO_OT_set_bsurface(bpy.types.Operator):
    bl_idname = 'object.speedretopo_set_bsurface'
    bl_label = "Set Bsurface"
    bl_description = "Set the Retopo Mesh for Bsurface"
    bl_options = {'REGISTER','UNDO'}

    # def invoke(self, context, event):
        # bpy.ops.ed.undo_push()

    def execute(self, context):

        context.scene.bsurfaces.SURFSK_mesh = context.active_object
        bpy.ops.object.mode_set(mode='EDIT')
        # bpy.ops.mesh.surfsk_add_surface('INVOKE_DEFAULT')

        return {'FINISHED'}


# Exit Retopo
class SPEEDRETOPO_OT_add_color(bpy.types.Operator):
    bl_idname = 'object.speedretopo_add_color'
    bl_label = "Add Color"
    bl_description = "Add Color Shading to the Retopo Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1:
            return True

    def execute(self, context):
        addonPref = get_addon_preferences()
        self.obj_color = addonPref.obj_color

        context.space_data.shading.color_type = 'OBJECT'
        context.object.color = self.obj_color
        context.space_data.overlay.show_occlude_wire = False


        return {'FINISHED'}


class SPEEDRETOPO_OT_remove_color(bpy.types.Operator):
    bl_idname = 'object.speedretopo_remove_color'
    bl_label = "Remove Color"
    bl_description = "Remove Color Shading from the Retopo Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if [obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']:
            return True

    def execute(self, context):
        addonPref = get_addon_preferences()
        self.obj_color = addonPref.obj_color

        context.object.color = (1, 1, 1, 1)
        context.space_data.overlay.show_occlude_wire = True

        return {'FINISHED'}


class SPEEDRETOPO_OT_exit_retopo(bpy.types.Operator):
    bl_idname = 'object.speedretopo_exit_retopo'
    bl_label = "Exit Retopo"
    bl_description = "Exit Retopo"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if [obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']:
            return True

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}


class SPEEDRETOPO_OT_finalize_retopo(bpy.types.Operator):
    bl_idname = 'object.speedretopo_finalize_retopo'
    bl_label = "Finalize Retopo"
    bl_description = "Finalize the Retopology"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if [obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']:
            return True

    def execute(self, context):

        bpy.ops.object.mode_set(mode='OBJECT')

        context.object.color = (1, 1, 1, 1)
        context.space_data.overlay.show_occlude_wire = False

        for mod in context.object.modifiers:
            if mod.type == 'SHRINKWRAP':
                bpy.ops.object.modifier_apply(modifier="Shrinkwrap")

        # REMOVE CUSTOM PROP
        context.object.speedretopo_ref_object = None

        return {'FINISHED'}

# from bpy.types import Object
# class SPEEDRETOPO_OT_clear_reference(bpy.types.Operator):
#     bl_idname = 'object.speedretopo_clear_reference'
#     bl_label = "Clear Reference"
#     bl_description = "Clear Reference"
#     bl_options = {'REGISTER'}
#
#     @classmethod
#     def poll(cls, context):
#         if [obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']:
#             return True
#
#     def execute(self, context):
#         for obj in context.selected_objects:
#
#             Object.speedretopo_ref_object = ""
#             del obj["speedretopo_ref_object"]
#
#         return {'FINISHED'}

class SPEEDRETOPO_OT_gstretch(bpy.types.Operator):
    bl_idname = 'object.speedretopo_gstretch'
    bl_label = "Gstretch"
    bl_options = {'REGISTER'}

    @classmethod

    def poll(cls, context):
        return True

    def execute(self, context):

        lt = bpy.context.window_manager.looptools
        lt.gstretch_use_guide = 'Annotation'

        gp = context.active_object
        gp.active_material_index = 0

        bpy.ops.mesh.looptools_gstretch(conversion='limit_vertices', conversion_distance=0.1, conversion_max=32, conversion_min=8, conversion_vertices=32, delete_strokes=False, influence=100, lock_x=False, lock_y=False, lock_z=False, method='regular')

        bpy.ops.remove.annotation()
        return {'FINISHED'}

# Decimate
class SPEEDRETOPO_OT_decimate(bpy.types.Operator):
    bl_idname = "object.speedretopo_decimate"
    bl_label = "Decimate Object"
    bl_description = "Decimate for lighter object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            decimate = context.object.modifiers.get("Decimate")
            if not decimate :
                mod_decim = obj.modifiers.new("Decimate", 'DECIMATE')
                mod_decim.ratio = 0.2
                context.object.show_wire = True

        return {"FINISHED"}

# Apply Decimate
class SPEEDRETOPO_OT_apply_decimate(bpy.types.Operator):
    bl_idname = "object.speedretopo_apply_decimate"
    bl_label = "Apply Decimate Modifier"
    bl_description = "Apply Decimate Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(modifier="Decimate")

        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Decimate")
            bpy.ops.object.mode_set(mode='EDIT')

        context.object.show_wire = False
        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_decimate(bpy.types.Operator):
    bl_idname = "object.speedretopo_remove_decimate"
    bl_label = "Remove Decimate Modifier"
    bl_description = "Remove Decimate Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Decimate")
        context.object.show_wire = False
        return {"FINISHED"}


class SPEEDRETOPO_OT_freeze_unfreeze(bpy.types.Operator):
    bl_idname = "object.speedretopo_freeze_unfreeze"
    bl_label = "Freeze/Unfreeze Selection"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    freeze_unfreeze : EnumProperty(
        items=(('freeze', "freeze", ""),
               ('unfreeze', "unfreeze", ""),
               ('clear', "clear", ""),
               ('select', "select", ""),),
        default='freeze'
    )

    def execute(self, context):
        obj = context.active_object

        has_vgroup = False
        for vgroup in obj.vertex_groups:
            if vgroup.name == "Speedretopo_freeze_unfreeze":
                bpy.ops.object.vertex_group_set_active(group='Speedretopo_freeze_unfreeze')
                has_vgroup = True
                continue

        if not has_vgroup:
            obj.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        if [v for v in bm.verts if v.select] :
            if self.freeze_unfreeze == 'freeze':
                bpy.ops.object.vertex_group_assign()
            elif self.freeze_unfreeze == 'unfreeze':
                bpy.ops.object.vertex_group_remove_from()
            elif self.freeze_unfreeze == 'select':
                bpy.ops.mesh.select_all(action='DESELECT')


        if self.freeze_unfreeze == 'clear':
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)

        if self.freeze_unfreeze == 'select':
            bpy.ops.object.vertex_group_select()

        return {"FINISHED"}

class SPEEDRETOPO_OT_set_unset_center(bpy.types.Operator):
    bl_idname = "object.speedretopo_set_unset_center"
    bl_label = "Set/UnSet Center"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    set_unset_center : EnumProperty(
        items=(('set', "set", ""),
               ('unset', "unset", ""),
               ('clear', "clear", ""),
               ('select', "select", ""),),
        default='set'
    )

    def execute(self, context):
        obj = context.active_object

        has_vgroup = False
        for vgroup in obj.vertex_groups:
            if vgroup.name == "Speedretopo_set_unset_center":
                bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
                has_vgroup = True
                continue

        if not has_vgroup:
            obj.vertex_groups.new(name="Speedretopo_set_unset_center")

        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        if [v for v in bm.verts if v.select] :
            if self.set_unset_center == 'set':
                bpy.ops.object.vertex_group_assign()
            elif self.set_unset_center == 'unset':
                bpy.ops.object.vertex_group_remove_from()
            elif self.set_unset_center == 'select':
                bpy.ops.mesh.select_all(action='DESELECT')

        if self.set_unset_center == 'set':
            for v in bm.verts :
                if v.select :
                    bpy.ops.object.speedretopo_align_center_edges()

        if self.set_unset_center == 'clear':
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)

        if self.set_unset_center == 'select':
            bpy.ops.object.vertex_group_select()

        return {"FINISHED"}
# -----------------------------------------------------
# REGISTER/UNREGISTER
# -----------------------------------------------------
CLASSES =  [SPEEDRETOPO_OT_create_speedretopo,
            SPEEDRETOPO_OT_align_center_edges,
            SPEEDRETOPO_OT_add_subsurf,
            SPEEDRETOPO_OT_remove_subsurf,
            SPEEDRETOPO_OT_apply_subsurf,
            SPEEDRETOPO_OT_add_mirror,
            SPEEDRETOPO_OT_apply_mirror,
            SPEEDRETOPO_OT_remove_mirror,
            SPEEDRETOPO_OT_remove_shrinkwrap,
            SPEEDRETOPO_OT_add_and_apply_shrinkwrap,
            SPEEDRETOPO_OT_apply_shrinkwrap,
            SPEEDRETOPO_OT_add_shrinkwrap,
            SPEEDRETOPO_OT_update_shrinkwrap,
            SPEEDRETOPO_OT_clean_normals,
            SPEEDRETOPO_OT_srrelax,
            SPEEDRETOPO_OT_space_relax,
            SPEEDRETOPO_OT_mesh_align_vertices,
            SPEEDRETOPO_OT_double_threshold_plus,
            SPEEDRETOPO_OT_double_threshold_minus,
            SPEEDRETOPO_OT_continue_retopo,
            SPEEDRETOPO_OT_add_color,
            SPEEDRETOPO_OT_remove_color,
            SPEEDRETOPO_OT_exit_retopo,
            SPEEDRETOPO_OT_finalize_retopo,
            SPEEDRETOPO_OT_symmetrize,
            SPEEDRETOPO_OT_mesh_automirror,
            SPEEDRETOPO_OT_update_mirror,
            SPEEDRETOPO_OR_quadremesh,
            SPEEDRETOPO_OT_gstretch,
            SPEEDRETOPO_OT_decimate,
            SPEEDRETOPO_OT_apply_decimate,
            SPEEDRETOPO_OT_remove_decimate,
            SPEEDRETOPO_OT_freeze_unfreeze,
            SPEEDRETOPO_OT_set_unset_center,
            SPEEDRETOPO_OT_set_bsurface

    # SPEEDRETOPO_OT_clear_reference,
            # SPEEDRETOPO_OT_activate_bsurfaces,
            # SPEEDRETOPO_OT_activate_looptools,
            # SPEEDRETOPO_OT_set_face_sets
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in CLASSES:
        if hasattr(bpy.types, cls.__name__):
            bpy.utils.unregister_class(cls)