# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

bl_info = {
    "name": "SpeedRetopo",
    "description": "Addon for retopology",
    "author": "Cedric Lepiller, EWOC for Laprelax",
    "version": (0, 1, 7),
    "blender": (3, 3, 0),
    "location": "Property Panel, Press N in the 3DView",
    "wiki_url": "",
    "category": "Object"}

import bpy
from mathutils import *
from bpy.types import Object
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       FloatVectorProperty,
                       BoolVectorProperty,
                       PointerProperty)
import rna_keymap_ui
from .ui import SPEEDRETOPO_PT_ui
from .icon.icons import *

# Import des modules
if "bpy" in locals():
    import importlib
    reloadable_modules = [
        "operators",
        "ui",
        "documentation"
    ]
    for module in reloadable_modules:
        if module in locals():
            importlib.reload(locals()[module])

from . import  (operators,
                ui,
                documentation
                )



# -----------------------------------------------------------------------------
#    Preferences
# -----------------------------------------------------------------------------

keymaps_items_dict = {"Speedretopo": ['object.speedretopo_ot_start_or_edit', None, '3D View '
                                                                                   'Generic', 'VIEW_3D', 'WINDOW',
                                      'RIGHTMOUSE', 'PRESS', True, True, True
                                      ],
                      }


def update_speedretopo_category(self, context):
    is_panel = hasattr(bpy.types, 'SPEEDRETOPO_PT_ui')

    if is_panel:
        try:
            bpy.utils.unregister_class(SPEEDRETOPO_PT_ui)
        except:
            pass
    SPEEDRETOPO_PT_ui.bl_category = self.category
    bpy.utils.register_class(SPEEDRETOPO_PT_ui)


# Preferences
class SPEEDFLOW_MT_addon_preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    prefs_tabs: EnumProperty(
        items=(('info', "Info", "ADDON INFO"),
               ('options', "Options", "ADDON OPTIONS"),
               ('keymaps', "Keymaps", "CHANGE KEYMAPS"),
               ('tutorials', 'Tutorials', 'Tutorials'),
               ('addons', "Addons", "Addons"),
               ('links', "Links", "LINKS")),
        default='options')

    hidden_wire: BoolProperty(name="Hidden Wire", default=True,
                              description="Hide Faces to see through the mesh")
    icons = load_icons()

    icon1 = icons.get("icon_bsurface")
    icon2 = icons.get("icon_vertex")
    icon3 = icons.get("icon_polybuild")

    start_from: EnumProperty(
        items=(('BSURFACE', "BSurface", "Use Bsurface Addon, Press D, old and draw the lines", icon1.icon_id, 1),
               ('VERTEX', "Vertex", "Use a single Vertex to start the retopology", icon2.icon_id, 2),
               ('POLYBUILD', "Polybuild", "Use Polybuild Tool", icon3.icon_id, 3)),
        default='VERTEX',
        description="")

    use_menu_or_pie_menu: EnumProperty(
        items=(('menu', "Menu", "Use Menu instead of Pie Menus"),
               ('pie_menus', "Pie Menus", "Use Pie Menus instead of Menu" )),
        default='menu',
        description="Choose Menu Type")

    auto_add_mirror: BoolProperty(name="Auto Add Mirror", default=True, description="Add a Mirror Modifier to your retopology.")
    auto_add_shrinkwrap: BoolProperty(name="Auto Add Shrinkwrap", default=True, description="Add a Shrinkwrap Modifier to your retopology.")
    use_in_front: BoolProperty(name="Use In Front Setting", default=True,
                                   description="See the Retopo Mesh in front of the Reference Mesh")
    use_wireframe: BoolProperty(name="Use Wireframe", default=True,
                                   description="Show Object Wireframe")
    use_color_shader: BoolProperty(name="Use Color Shader", default=False,
                                   description="Add a Color to you mesh")
    obj_color: FloatVectorProperty(name="", default=(0, 0.65, 1, 0.5), min=0, max=1, size=4, subtype='COLOR_GAMMA',
                                   description="Choose a Color to you mesh")
    mirror_axis: BoolVectorProperty(default=[True, False, False], size=3, name="")

    buttons_size: FloatProperty(name="", default=1, min=1, max=2, precision=3)

    category: StringProperty(description="Choose a name for the category of the panel", default="SpeedRetopo",
                             update=update_speedretopo_category)


    # QUAD REMESH
    quad_use_mesh_symmetry : BoolProperty(name="Use Mesh Symmetry", default=True,
                                         description="Generate a symmetrical mesh using the mesh symmetry configuration.")
    quad_use_preserve_sharp : BoolProperty(name="Use Preserve Sharp", default=True, description="Try to preserve Sharph features on the mesh.")
    quad_use_preserve_boundary : BoolProperty(name="Use Preserve Boundary", default=True,description="Try to preserve Boundary on the mesh.")
    quad_preserve_paint_mask : BoolProperty(name="Use Preserve Paint Mask", default=False, description="Reproject the paint mask onto the new mesh.")
    quad_smooth_normals : BoolProperty(name="Smooth Normals", default=True,description="Smooth the Normals of the mesh")
    quad_mode : EnumProperty(
        items=(('FACES', "FACES", ""),
               ('RATIO', "RATIO", "" ),
               ('EDGE', "EDGE", "" )),
        default='FACES',
        description="Specify the amount of detail for the new mesh.")
    quad_target_ratio : FloatProperty(name="Ratio", default=0.5, min=0.01, max=1, precision=3, description="Relative Number of Faces compared to the current Mesh.")
    quad_target_edge_length : FloatProperty(name="Length", default=0.1, min=0.01, max=1, precision=3, description="Edges Length")
    quad_target_faces : IntProperty(name="Number of Faces", default=1000, min=1, max=100000, description="Number of Faces")
    quad_mesh_area : FloatProperty(name="Quad Mesh Area", default=-1, min=-1, max=1, precision=3, description="Old Object Face Area, This property is only used to cache the object area for later calculations.")
    quad_seed : IntProperty(name="Seed", default=0, min=0, max=255, description="Random Seed to use with the Solver")

    show_start_menu: BoolProperty(default=True, description="Show/Hide Start Menu")
    show_retopo_settings_menu: BoolProperty(default=True, description="Show/Hide Retopo Settings")
    show_modifiers_menu: BoolProperty(default=True, description="Show/Hide Modifiers")
    show_tools_menu: BoolProperty(default=True, description="Show/Hide Tools")
    show_shading_menu: BoolProperty(default=True, description="Show/Hide Shadind")
    show_quadriflow_menu: BoolProperty(default=False, description="Show/Hide Quadriflow")
    show_freeze_unfreeze: BoolProperty(default=False, description="Show/Hide Freezing tools")
    show_center_tools: BoolProperty(default=True, description="Show/Hide Center tools")

    show_hide_menu_settings: BoolProperty(default=True, description="Show/Hide Menus Settings")
    show_hide_retopo_settings: BoolProperty(default=True, description="Show/Hide Retopology Settings")
    show_hide_quadremesh_settings: BoolProperty(default=False, description="Show/Hide Quad Remesh Settings")


    reference_nbf : IntProperty(name="Number of Faces for the Reference Object", default=100000, min=10, max=500000, description="Number of Faces for the Reference Object.")

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        row = layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)
        row.scale_y = 1.5
        if self.prefs_tabs == 'info':
            box = layout.box()
            icon = icons.get("icon_discord")
            row = box.row()
            row.scale_y = 2
            row.operator("wm.url_open", text="SUPPORT ON DISCORD FOR CUSTOMERS",
                         icon_value=icon.icon_id).url = "https://discord.gg/ctQAdbY"

            box = layout.box()
            box.label(text="Welcome to SpeedRetopo, this addon allows you to make easy and Fast Retopology.")
            box.label(text="The addon was made from profesionnal for you and is really simple to use.")
            box.label(text="It gives you all the necessary tools to work on your retopology.")

            box = layout.box()
            box.label(text="The Documentation is located in the Active tool and Workspace Settings of the Property Editor.", icon='HELP')


        if self.prefs_tabs == 'options':
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="",icon='MENU_PANEL')
            row.prop(self, "show_hide_menu_settings", text="MENUS SETTINGS",
                     icon='TRIA_UP' if self.show_hide_menu_settings else 'TRIA_RIGHT')
            if self.show_hide_menu_settings:

                row = box.row(align=True)
                row.label(text="Panel Category:")
                row.prop(self, "category", text="")

                row = box.row(align=True)
                row.label(text="Choose Menu Type")
                row.prop(self, "use_menu_or_pie_menu", text="")

                row = box.row(align=True)
                row.label(text="Buttons Size")
                row.prop(self, "buttons_size")

                row = box.row(align=True)
                row.label(text="Always show Modifiers menu")
                row.prop(self, "show_modifiers_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Always show Tools menu")
                row.prop(self, "show_tools_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Always show Shading menu")
                row.prop(self, "show_shading_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Number of Faces for the Reference Object")
                row.prop(self, "reference_nbf", text="      ")

            # RETOPO
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_polybuild")
            row.label(text="", icon_value=icon.icon_id)
            row.prop(self, "show_hide_retopo_settings", text="RETOPOLOGY SETTINGS",
                     icon='TRIA_UP' if self.show_hide_retopo_settings else 'TRIA_RIGHT')
            if self.show_hide_retopo_settings:
                row = box.row(align=True)
                row.label(text="Start Retopo From")
                row.prop(self, "start_from", text="")

                row = box.row(align=True)
                row.label(text="Auto Add Mirror")
                row.prop(self, "auto_add_mirror", text="      ")

                row = box.row(align=True)
                row.label(text="Auto Add Shrinkwrap")
                row.prop(self, "auto_add_shrinkwrap", text="      ")

                row = box.row(align=True)
                row.label(text="Use Hidden Wire")
                row.prop(self, "hidden_wire", text="      ")

                row = box.row(align=True)
                row.label(text="Use Wireframe")
                row.prop(self, "use_wireframe", text="      ")

                row = box.row(align=True)
                row.label(text="Use In Front")
                row.prop(self, "use_in_front", text="      ")

                row = box.row(align=True)
                row.label(text="Use Color")
                row.prop(self, "use_color_shader", text="      ")


                if self.use_color_shader:
                    row = box.row(align=True)
                    row.label(text="Color")
                    row.prop(self, "obj_color")

                row = box.row(align=True)
                row.label(text="", icon='MOD_REMESH')
                row.prop(self, "show_hide_quadremesh_settings", text="QUADREMESH SETTINGS",
                         icon='TRIA_UP' if self.show_hide_quadremesh_settings else 'TRIA_RIGHT')
                if self.show_hide_quadremesh_settings:
                    row = box.row(align=True)
                    row.label(text="Use Symmetry")
                    row.prop(self, "quad_use_mesh_symmetry", text="      ")

                    row = box.row(align=True)
                    row.label(text="Use Preserve Sharp")
                    row.prop(self, "quad_use_preserve_sharp", text="      ")

                    row = box.row(align=True)
                    row.label(text="Use Preserve Boundary")
                    row.prop(self, "quad_use_preserve_boundary", text="      ")

                    row = box.row(align=True)
                    row.label(text="Use Preserve Paint Mask")
                    row.prop(self, "quad_preserve_paint_mask", text="      ")

                    row = box.row(align=True)
                    row.label(text="Smooth Normals")
                    row.prop(self, "quad_smooth_normals", text="      ")

                    row = box.row(align=True)
                    row.label(text="Mode")
                    row.prop(self, "quad_mode", text="")

                    if self.quad_mode == 'RATIO':
                        row = box.row(align=True)
                        row.label(text="Ratio")
                        row.prop(self, "quad_target_ratio", text="      ")

                    elif self.quad_mode == 'LENGTH':
                        row = box.row(align=True)
                        row.label(text="Length")
                        row.prop(self, "quad_target_edge_length", text="      ")

                    else:
                        row = box.row(align=True)
                        row.label(text="Number of Faces")
                        row.prop(self, "quad_target_faces", text="      ")

                    row = box.row(align=True)
                    row.label(text="Seed")
                    row.prop(self, "quad_seed", text="      ")





        # KEYMAPS
        if self.prefs_tabs == 'keymaps':
            wm = bpy.context.window_manager
            draw_keymap_items(wm, layout)

        # TUTORIALS
        if self.prefs_tabs == 'tutorials':
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="Youtube Channel",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"

            # SPEEDFLOW BASICS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SPEEDFLOW BASICS")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/speedflow_basics"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedflow-basics---parametric-modeling"


            # Sony BSP10
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SONY BSP10")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/sony_bsp10_non_destructive_tutorial"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/sony-bsp10-non-destructive-worflow-tutorial"

            # HYDRANT MODELING
            box = layout.box()
            row = box.row(align=True)
            row.label(text="HYDRANT MODELING TUTORIAL")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/hydrant_modeling_tutorial"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/hydrant---hard-surface-modeling-tutorial"

            # HYDRANT UNWRAPPING
            row = box.row(align=True)
            row.label(text="HYDRANT MODELING TUTORIAL")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/hydrant_unwrapping_tutorial"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/hydrant---uwrapping-tutorial"

            # FURRY WARFARE
            box = layout.box()
            row = box.row(align=True)
            row.label(text="FURRY WARFARE")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open",
                         text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/furry_warfare_plane_modeling_tutorial"

        # Addons
        if self.prefs_tabs == 'addons':


            # SPEEDFLOW
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SPEEDFLOW")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/speedflow"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedflow"
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651436"

            # SPEEDSCULPT
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SPEEDSCULPT")
            row = box.row(align=True)
            icon = icons.get("icon_gumroad")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/SpeedSculpt"
            icon = icons.get("icon_market")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedsculpt"
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://pitiwazou.artstation.com/store/JmKn/speedsculpt"

            # PROFLOW
            box = layout.box()
            row = box.row(align=True)
            row.label(text="PROFLOW")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/proflow"
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/proflow"
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651445"

            # ASSET MANAGEMENT

            box = layout.box()
            row = box.row(align=True)
            row.label(text="ASSET MANAGEMENT")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/asset_management"
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/asset-management"

            # SPEEDRETOPO https://pitiwazou-1.gumroad.com/l/dynamic_lines
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SPEEDRETOPO")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/speedretopo"
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedretopo"

            # EASYREF
            box = layout.box()
            row = box.row(align=True)
            row.label(text="EASYREF")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/easyref"
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedretopo"

            # DYNAMIQUE LINES
            box = layout.box()
            row = box.row(align=True)
            row.label(text="DYNAMIQUE LINES")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/l/dynamic_lines"
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651438"

            # RMB PIE MENUS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="RMB PIE MENUS")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/wazou_rmb_pie_menu_v2"

            # WAZOU's PIE MENUS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="WAZOU's PIE MENUS")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/wazou_pie_menus"

            # SMART CURSOR
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SMART CURSOR")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://gumroad.com/l/smart_cursor"

            # ARCHIPACK
            box = layout.box()
            row = box.row(align=True)
            row.label(text="ARCHIPACK")
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://blender-archipack.org"


        # URls
        if self.prefs_tabs == 'links':
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SUPPORT ME", icon='HAND')
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_patreon")
            row.operator("wm.url_open", text="Patreon",
                         icon_value=icon.icon_id).url = "https://www.patreon.com/pitiwazou"
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_tipeee")
            row.operator("wm.url_open", text="Tipeee",
                         icon_value=icon.icon_id).url = "https://www.tipeee.com/blenderlounge"

            box = layout.box()
            row = box.row(align=True)
            row.label(text="WEB", icon='WORLD')
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="Pitiwazou.com",
                         icon_value=icon.icon_id).url = "http://www.pitiwazou.com/"

            box = layout.box()
            row = box.row(align=True)
            row.label(text="YOUTUBE", icon='SEQUENCE')

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="Youtube - Pitiwazou",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"
            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("wm.url_open", text="Youtube - Blenderlounge",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/channel/UCaA3_WSE5A0H6YrS1SDfAQw/videos"

            box = layout.box()
            row = box.row(align=True)
            row.label(text="SOCIAL", icon='USER')

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="Artstation",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/artist/pitiwazou"
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_twitter")
            row.operator("wm.url_open", text="Twitter",
                         icon_value=icon.icon_id).url = "https://twitter.com/#!/pitiwazou"
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_facebook")
            row.operator("wm.url_open", text="Facebook",
                         icon_value=icon.icon_id).url = "https://www.facebook.com/Pitiwazou-C%C3%A9dric-Lepiller-120591657966584/"
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_discord")
            row.operator("wm.url_open", text="Blenderlounge's Discord",
                         icon_value=icon.icon_id).url = "https://discord.gg/MBDphac"


# -----------------------------------------------------------------------------
#    Keymap
# -----------------------------------------------------------------------------
addon_keymaps = []


def draw_keymap_items(wm, layout):
    kc = wm.keyconfigs.user

    for name, items in keymaps_items_dict.items():
        kmi_name, kmi_value, km_name = items[:3]
        box = layout.box()
        split = box.split()
        col = split.column()
        col.label(text=name)
        col.separator()
        km = kc.keymaps[km_name]
        get_hotkey_entry_item(kc, km, kmi_name, kmi_value, col)


def get_hotkey_entry_item(kc, km, kmi_name, kmi_value, col):
    # for menus and pie_menu
    if kmi_value:
        for km_item in km.keymap_items:
            if km_item.idname == kmi_name and km_item.properties.name == kmi_value:
                col.context_pointer_set('keymap', km)
                rna_keymap_ui.draw_kmi([], kc, km, km_item, col, 0)
                return

        col.label(text=f"No hotkey entry found for {kmi_value}")
        col.operator(SPEEDRETOPO_OT_Add_Hotkey.bl_idname, icon='ADD')

    # for operators
    else:
        if km.keymap_items.get(kmi_name):
            col.context_pointer_set('keymap', km)
            rna_keymap_ui.draw_kmi(
                [], kc, km, km.keymap_items[kmi_name], col, 0)
        else:
            col.label(text=f"No hotkey entry found for {kmi_name}")
            col.operator(SPEEDRETOPO_OT_Add_Hotkey.bl_idname, icon='ADD')


class SPEEDRETOPO_OT_Add_Hotkey(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "template_rmb.add_hotkey"
    bl_label = "Add Hotkeys"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        add_hotkey()

        self.report({'INFO'},
                    "Hotkey added in User Preferences -> Input -> Screen -> Screen (Global)")
        return {'FINISHED'}


def add_hotkey():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if not kc:
        return

    for items in keymaps_items_dict.values():
        kmi_name, kmi_value, km_name, space_type, region_type = items[:5]
        eventType, eventValue, ctrl, shift, alt = items[5:]
        km = kc.keymaps.new(name=km_name, space_type=space_type,
                            region_type=region_type)

        kmi = km.keymap_items.new(kmi_name, eventType,
                                  eventValue, ctrl=ctrl, shift=shift,
                                  alt=alt

                                  )
        if kmi_value:
            kmi.properties.name = kmi_value

        kmi.active = True

    addon_keymaps.append((km, kmi))


def remove_hotkey():
    ''' clears all addon level keymap hotkeys stored in addon_keymaps '''

    kmi_values = [item[1] for item in keymaps_items_dict.values() if item]
    kmi_names = [item[0] for item in keymaps_items_dict.values() if item not in ['wm.call_menu', 'wm.call_menu_pie']]

    for km, kmi in addon_keymaps:
        # remove addon keymap for menu and pie menu
        if hasattr(kmi.properties, 'name'):
            if kmi_values:
                if kmi.properties.name in kmi_values:
                    km.keymap_items.remove(kmi)

        # remove addon_keymap for operators
        else:
            if kmi_names:
                if kmi.name in kmi_names:
                    km.keymap_items.remove(kmi)

    addon_keymaps.clear()

class SPEEDRETOPO_PropertyGroup(bpy.types.PropertyGroup):
    show_doc_intro: BoolProperty(default=True, description="Show/Hide Introduction")
    show_doc_start: BoolProperty(default=True, description="Show/Hide Starting Your Retopology")
    show_doc_ref: BoolProperty(default=True, description="Show/Hide Reference Object")
    show_doc_modifiers: BoolProperty(default=False, description="Show/Hide Modifiers")
    show_doc_tools: BoolProperty(default=False, description="Show/Hide Tools")
    show_doc_shading: BoolProperty(default=False, description="Show/Hide Shading")
    show_doc_start_cont_fin: BoolProperty(default=False, description="Show/Hide Start Continue Finalize")
    show_doc_prefs: BoolProperty(default=False, description="Show/Hide Preferences")
    # show_freeze_unfreeze: BoolProperty(default=False, description="Show/Hide Freezing tools")
    # show_center_tools: BoolProperty(default=True, description="Show/Hide Center tools")

    # axis : EnumProperty(
    #     items = [("x", "X", "", 1),
    #              ("y", "Y", "", 2),
    #              ("z", "Z", "", 3)],
    #     description="Axis used by the mirror modifier",
    # )

CLASSES = [
           SPEEDRETOPO_OT_Add_Hotkey,
           SPEEDFLOW_MT_addon_preferences,
           SPEEDRETOPO_PropertyGroup]


def register():
    operators.register()
    ui.register()
    documentation.register()

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

    # Update Category
    context = bpy.context
    prefs = context.preferences.addons[__name__].preferences
    update_speedretopo_category(prefs, context)

    # PropertyGroup
    Object.speedretopo_ref_object = PointerProperty(name="", type=Object)
    bpy.types.WindowManager.speedretopo_PropertyGroup = PointerProperty(type=SPEEDRETOPO_PropertyGroup)
    # bpy.types.Scene.automirror = PointerProperty(type = SPEEDRETOPO_PropertyGroup)

    add_hotkey()


def unregister():
    operators.unregister()
    ui.unregister()
    documentation.unregister()

    for cls in CLASSES:
        if hasattr(bpy.types, cls.__name__):
            bpy.utils.unregister_class(cls)

    remove_hotkey()

    del Object['speedretopo_ref_object']