# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.types import Menu, Header
from .icon.icons import load_icons
from bpy.types import Object
import bmesh




def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    return bpy.context.preferences.addons[addon_key].preferences


# UI
class SPEEDRETOPO_PT_ui(bpy.types.Panel):
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tools"

    # @classmethod
    # def poll(cls, context):
    #     if context.object is not None and context.selected_objects:
    #         return True

    def draw_header(self, context):
        layout = self.layout
        icons = load_icons()
        icon = icons.get("icon_speedretopo")
        layout.label(text="", icon_value=icon.icon_id)

    def draw(self, context):
        layout = self.layout
        if context.object is not None and len(context.selected_objects) == 1:
            SpeedRetopo(self, context)
        elif len(context.selected_objects) == 0:
            layout.label(text="Select An Object", icon='ERROR')
        else:
            layout.label(text="Selection Only One Object", icon='ERROR')

# Panel
def SpeedRetopo(self, context):
    layout = self.layout
    tool_settings = context.tool_settings
    overlay = context.space_data.overlay
    shading = context.space_data.shading
    addonPref = get_addon_preferences()
    use_color_shader = addonPref.use_color_shader
    buttons_size = addonPref.buttons_size
    icons = load_icons()
    reference_nbf = addonPref.reference_nbf

    # if context.object is not None and context.selected_objects and context.object.type == 'MESH' :
    # if context.object.type == 'MESH':
    self.has_mirror = False
    for mod in context.object.modifiers:
        if mod.type == 'MIRROR':
            self.has_mirror = True

    self.huge_faces = False
    # if len(context.selected_objects)==1:
    if not context.active_object.speedretopo_ref_object :
        if context.object.mode == "OBJECT":
            for obj in context.selected_objects:
                if len(obj.data.polygons)> reference_nbf:
                    self.huge_faces = True

        # if context.scene.bsurfaces.SURFSK_mesh != bpy.data.objects[context.object.name]:
    # context.scene.bsurfaces.SURFSK_mesh = bpy.data.objects[context.object.name]


    if self.huge_faces :
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        col.label(text="Decrease the number of")
        col.label(text="vertices of")
        col.label(text="the Reference Object")

        decimate = False
        for mod in context.active_object.modifiers:
            if mod.type == "DECIMATE":
                decimate = True

        if not decimate:
            row=box.row()
            row.scale_y = 1.3
            icon = icons.get("icon_decimate")
            row.operator("object.speedretopo_decimate", text="Decimate", icon_value=icon.icon_id)
        else:
            row = col.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_valid")
            row.operator("object.speedretopo_apply_decimate", text="Apply Decimate", icon_value=icon.icon_id)
            row.prop(context.active_object.modifiers["Decimate"], "show_viewport", text="",icon='RESTRICT_VIEW_ON')
            row.operator("object.speedretopo_remove_decimate", text="", icon='X')
            row = col.row(align=True)
            row.prop(context.active_object.modifiers["Decimate"], "ratio", text="Ratio")
            row = col.row(align=True)
            row.prop(context.active_object.modifiers["Decimate"], "face_count", text="Face Count:")




    # REF object
    box = layout.box()
    row = box.row(align=True)
    row.label(text="SET REFERENCE")
    row = box.row(align=True)
    obj = context.active_object
    row.scale_y = 1.3
    row.prop(obj, "speedretopo_ref_object", text="", icon='MESH_MONKEY')

    if context.object.mode == "OBJECT":
        if context.object.mode in {'OBJECT', 'SCULPT'}:
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row()
            row.scale_y = 1
            row.prop(addonPref, "show_start_menu", text="START RETOPO",
                     icon='DISCLOSURE_TRI_DOWN' if addonPref.show_start_menu else 'SNAP_GRID')

            if addonPref.show_start_menu:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.speedretopo_create_retopo", text="START RETOPO", icon='GREASEPENCIL')

                # SETTINGS
                box = layout.box()
                split = box.split()
                col = split.column(align=True)

                row = col.row(align=True)
                row.label(text="START RETOPO WITH", icon='TOOL_SETTINGS')
                row = col.row(align=True)
                row.scale_y = 1.5
                row.prop(addonPref, "start_from", text="")

                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.label(text="RETOPO SETTINGS", icon='PRESET')
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(addonPref, "auto_add_mirror", text="Add Mirror Modifier")

                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(addonPref, "auto_add_shrinkwrap", text="Add Shrinkwrap Modifier")

                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(addonPref, "hidden_wire", text="Use Hidden Wire")

                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(addonPref, "use_in_front", text="Use In front")

                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(addonPref, "use_wireframe", text="Show Wireframe")

                row = col.row(align=True)
                row.prop(addonPref, "use_color_shader", text="Use Color Shader")
                if use_color_shader:
                    row.scale_y = buttons_size
                    row.prop(addonPref, "obj_color", text="")

    # MODIFIERS
    if context.object.mode in {'OBJECT','EDIT', 'SCULPT'}:
        mirror = context.active_object.modifiers.get("Mirror")
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row()
        row.scale_y = 1
        row.prop(addonPref, "show_modifiers_menu", text="MODIFIERS",
                 icon='DISCLOSURE_TRI_DOWN' if addonPref.show_modifiers_menu else 'MODIFIER')
        if addonPref.show_modifiers_menu:
            if mirror:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.scale_x = 1.2
                if context.object.modifiers["Mirror"].show_viewport == False:
                    row.prop(context.active_object.modifiers["Mirror"], "show_viewport", text="Mirror")
                elif context.object.modifiers["Mirror"].show_viewport == True:
                    row.prop(context.active_object.modifiers["Mirror"], "show_viewport", text="Mirror")
                icon = icons.get("icon_clipping")
                row.prop(context.active_object.modifiers["Mirror"], "use_clip", text="", icon_value=icon.icon_id)
                icon = icons.get("icon_valid")
                row.operator("object.speedretopo_apply_mirror", text="", icon_value=icon.icon_id)
                icon = icons.get("icon_delete")
                row.operator("object.speedretopo_remove_mirror", text="", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Mirror"], "merge_threshold", text="Merge Limit")
            else:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.operator("object.speedretopo_add_mirror", text="Add Mirror", icon='MOD_MIRROR')

            #shrinkwrap
            shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
            if shrinkwrap :
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.scale_x = 1.2
                if context.object.modifiers["Shrinkwrap"].show_viewport == False:
                    row.prop(context.active_object.modifiers["Shrinkwrap"], "show_viewport", text="Shrinkwrap")
                elif context.object.modifiers["Shrinkwrap"].show_viewport == True:
                    row.prop(context.active_object.modifiers["Shrinkwrap"], "show_viewport", text="Shrinkwrap")
                icon = icons.get("icon_valid")
                row.operator("object.speedretopo_apply_shrinkwrap", text="", icon_value=icon.icon_id)
                icon = icons.get("icon_delete")
                row.operator("object.speedretopo_remove_shrinkwrap", text="", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Shrinkwrap"], "offset", text = "Shrinkwrap Offset")
                row = col.row(align=True)
                icon = icons.get("icon_update")
                row.operator("object.speedretopo_update_shrinkwrap", text="Update Shrinkwrap", icon_value=icon.icon_id)
            else:
                if context.object.speedretopo_ref_object is not None:
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.scale_y = buttons_size
                    row.operator("object.speedretopo_add_shrinkwrap", text="Add shrinkwrap", icon = 'MOD_SHRINKWRAP')
                    for mod in context.object.modifiers:
                        if mod.type =='SHRINKWRAP':
                            row = col.row(align=True)
                            icon = icons.get("icon_valid")
                            row.operator("object.speedretopo_add_apply_shrinkwrap", text="Update Shrinkwrap", icon_value=icon.icon_id)

            # Subsurf
            subsurf = context.active_object.modifiers.get("Subsurf")

            if subsurf:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.scale_x = 1.2
                if context.object.modifiers["Subsurf"].show_viewport == False:
                    row.prop(context.active_object.modifiers["Subsurf"], "show_viewport", text="Subsurf")
                elif context.object.modifiers["Subsurf"].show_viewport == True:
                    row.prop(context.active_object.modifiers["Subsurf"], "show_viewport", text="Subsurf")
                icon = icons.get("icon_optimal_display")
                row.prop(context.active_object.modifiers["Subsurf"], "show_only_control_edges", text="",
                         icon_value=icon.icon_id)
                row.prop(context.active_object.modifiers["Subsurf"], "show_in_editmode", text="", icon='EDITMODE_HLT')
                icon = icons.get("icon_valid")
                row.operator("object.speedretopo_apply_subsurf", text="", icon_value=icon.icon_id)
                icon = icons.get("icon_delete")
                row.operator("object.speedretopo_remove_subsurf", text="", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Subsurf"], "levels", text="Levels")

            else:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.operator("object.speedretopo_add_subsurf", text="Add Subsurf", icon='MOD_SUBSURF')

    # TOOLS
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1
    row.prop(addonPref, "show_tools_menu", text="TOOLS",
             icon='DISCLOSURE_TRI_DOWN' if addonPref.show_tools_menu else 'TOOL_SETTINGS')

    if addonPref.show_tools_menu:
        if context.object.mode in {'OBJECT', 'SCULPT'}:
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals")
            row.operator("object.speedretopo_clean_normals", text="Recalculate Normals", icon_value=icon.icon_id)

            if not self.has_mirror:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size + 0.3
                row.operator("object.speedretopo_symmetrize", text="Symmetrize", icon='MOD_MIRROR')

        elif context.object.mode == "EDIT":
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size  + 0.3
            if context.scene.bsurfaces.SURFSK_mesh == bpy.data.objects[context.object.name]:
                icon = icons.get("icon_bsurface")
                row.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)
            else:
                icon = icons.get("icon_error")
                row.operator("object.speedretopo_set_bsurface", text="Click To Set Bsurface Mesh", icon_value=icon.icon_id)

            # row.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size + 0.3
            icon = icons.get("icon_align_to_x")
            row.operator("object.speedretopo_align_center_edges", text="Align Vertices to Center", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size + 0.3
            row.operator("object.speedretopo_symmetrize", text="Symmetrize", icon='MOD_MIRROR')

            if hasattr(bpy.types, "MESH_OT_retopomt"):
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                icon = icons.get("icon_retopomt")
                row.operator("mesh.retopomt", icon_value=icon.icon_id)

            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_space")
            row.operator("object.speedretopo_space_relax", text="Space", icon_value=icon.icon_id)
            row.scale_y = buttons_size
            icon = icons.get("icon_relax")
            row.operator("mesh.speedretopo_relax", text="Relax", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_gstretch")
            row.operator("object.speedretopo_gstretch", text="GStretch", icon_value=icon.icon_id)
            row.scale_y = buttons_size
            icon = icons.get("icon_curve")
            row.operator("mesh.looptools_curve", text="Curve", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_bridge")
            row.operator("mesh.looptools_bridge", text="Bridge", icon_value=icon.icon_id)
            row.scale_y = buttons_size
            icon = icons.get("icon_gridfill")
            row.operator("mesh.fill_grid", text="Grid Fill", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals")
            row.operator("object.speedretopo_clean_normals", text="Recalculate Normals", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_flip_normals")
            row.operator("mesh.flip_normals", text="Flip Normals", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()

            # AUTO MERGE
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.prop(context.tool_settings, "use_mesh_automerge", text="Auto Merge")
            if context.scene.tool_settings.use_mesh_automerge == True:
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(tool_settings, "double_threshold", text="Threshold")
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.operator("object.speedretopo_double_threshold_minus", text="0.001")
                row.operator("object.speedretopo_double_threshold_plus", text="0.1")

            # CENTER TOOLS
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            col.prop(addonPref, "show_center_tools", text="CENTER TOOLS",
                     icon='DISCLOSURE_TRI_DOWN' if addonPref.show_center_tools else 'THREE_DOTS')
            if addonPref.show_center_tools:
                row = col.row(align=True)

                me = context.object.data
                bm = bmesh.from_edit_mesh(me)
                if [v for v in bm.verts if v.select] :
                    row.operator("object.speedretopo_set_unset_center", text='Set', icon='LAYER_ACTIVE').set_unset_center = "set"
                    row.operator("object.speedretopo_set_unset_center", text='UnSet', icon='IPO_LINEAR').set_unset_center = "unset"
                row = col.row(align=True)
                row.operator("object.speedretopo_set_unset_center", text='Select', icon='GROUP_VERTEX').set_unset_center = "select"
                row.operator("object.speedretopo_set_unset_center", text='Clear', icon='SELECT_SET').set_unset_center = "clear"

            # FREEZING
            if context.active_object.speedretopo_ref_object:
                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                col.prop(addonPref, "show_freeze_unfreeze", text="FREEZING TOOLS",
                         icon='DISCLOSURE_TRI_DOWN' if addonPref.show_freeze_unfreeze else 'FREEZE')
                if addonPref.show_freeze_unfreeze:

                    row = col.row(align=True)

                    me = context.object.data
                    bm = bmesh.from_edit_mesh(me)
                    if [v for v in bm.verts if v.select] :
                        row.operator("object.speedretopo_freeze_unfreeze", text='Freeze', icon='FREEZE').freeze_unfreeze = "freeze"
                        row.operator("object.speedretopo_freeze_unfreeze", text='UnFreeze', icon='IPO_LINEAR').freeze_unfreeze = "unfreeze"
                    row = col.row(align=True)
                    row.operator("object.speedretopo_freeze_unfreeze", text='Select', icon='GROUP_VERTEX').freeze_unfreeze = "select"
                    row.operator("object.speedretopo_freeze_unfreeze", text='Clear', icon='SELECT_SET').freeze_unfreeze = "clear"

    # SHADING
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1
    row.prop(addonPref, "show_shading_menu", text="SHADING",
             icon='DISCLOSURE_TRI_DOWN' if addonPref.show_shading_menu else 'SHADING_TEXTURE')

    if addonPref.show_shading_menu:
        row = col.row(align=True)
        row.separator()
        if context.object.mode == "EDIT":

            row = col.row(align=True)
            row.scale_y = buttons_size
            if overlay.show_occlude_wire == False:
                row.prop(overlay, "show_occlude_wire", text="Hidden Wire", icon='RADIOBUT_OFF')
            elif overlay.show_occlude_wire == True:
                row.prop(overlay, "show_occlude_wire", text="Hidden Wire", icon='RADIOBUT_ON')

        row = col.row(align=True)
        row.scale_y = buttons_size
        if context.object.show_in_front == False:
            row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_OFF')
        elif context.object.show_in_front == True:
            row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_ON')

        row = col.row(align=True)
        row.scale_y = buttons_size
        if context.object.show_wire == False:
            row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_OFF')
        elif context.object.show_wire == True:
            row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_ON')

        row = col.row(align=True)
        row.scale_y = buttons_size
        if shading.show_backface_culling == False:
            row.prop(shading, "show_backface_culling", text="Back Face Culling", icon='RADIOBUT_OFF')
        elif shading.show_backface_culling == True:
            row.prop(shading, "show_backface_culling", text="Back Face Culling", icon='RADIOBUT_ON')

        row = col.row(align=True)
        row.scale_y = buttons_size
        if context.active_object.color[3] != 1:
            row.scale_y = buttons_size
            row.prop(context.object, "color", text="")
            icon = icons.get("icon_delete")
            row.operator("object.speedretopo_remove_color", text="", icon_value=icon.icon_id)
        else:
            if context.active_object.speedretopo_ref_object:
                icon = icons.get("icon_color")
                row.operator("object.speedretopo_add_color", text="Add Color", icon_value=icon.icon_id)

        if context.object.mode == 'SCULPT':
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals")
            row.operator("object.speedretopo_clean_normals", text="Recalculate Normals", icon_value=icon.icon_id)

    # QUADRIFLOW
    if context.object.speedretopo_ref_object == None:
        if context.object is not None and context.selected_objects :
            if context.object.mode == "OBJECT":
                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1
                row.prop(addonPref, "show_quadriflow_menu", text="QUADRIFLOW",
                         icon='DISCLOSURE_TRI_DOWN' if addonPref.show_quadriflow_menu else 'MOD_REMESH')

                if addonPref.show_quadriflow_menu:
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(addonPref, "quad_use_mesh_symmetry", text="Use Mesh Symmetry")
                    row = col.row(align=True)
                    row.prop(addonPref, "quad_use_preserve_sharp", text="Preserve Sharp")
                    row = col.row(align=True)
                    row.prop(addonPref, "quad_use_preserve_boundary", text="Preserve Mesh Boundary")
                    row = col.row(align=True)
                    row.prop(addonPref, "quad_preserve_paint_mask", text="Preserve Paint Mask")
                    row = col.row(align=True)
                    row.prop(addonPref, "quad_smooth_normals", text="Smooth Normals")
                    row = col.row()
                    row.prop(addonPref, "quad_mode", text="Mode")
                    if addonPref.quad_mode == 'EDGE':
                        row = col.row(align=True)
                        row.separator()
                        row = col.row(align=True)
                        row.label(text="Edge Length:")
                        row.prop(addonPref, "quad_target_edge_length", text="")

                    elif addonPref.quad_mode == 'RATIO':
                        row = col.row(align=True)
                        row.separator()
                        row = col.row(align=True)
                        row.label(text="Ratio:")
                        row.prop(addonPref, "quad_target_ratio", text="")

                    else:
                        row = col.row(align=True)
                        row.separator()
                        row = col.row(align=True)
                        row.label(text="Faces:")
                        row.prop(addonPref, "quad_target_faces", text="")

                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Seed:")
                    row.prop(addonPref, "quad_seed", text="")

                    row = col.row(align=True)
                    row.separator()
                    row.scale_y = 2
                    row = col.row(align=True)
                    row.operator("object.speedretopo_quadremesh", text="QuadriFlow Remesh")


        # FACE SETS
        # box = layout.box()
        # split = box.split()
        # col = split.column(align=True)
        # row = col.row(align=True)
        # row.scale_y = 1
        # row.prop(speedretopo_PropertyGroup, "show_face_sets", text="FACE SETS",
        #          icon='SELECT_EXTEND' if speedretopo_PropertyGroup.show_face_sets else 'SELECT_EXTEND')

        # if speedretopo_PropertyGroup.show_face_sets:
        #     row = col.row(align=True)
        #     row.separator()
        #     row = col.row(align=True)
        #     row.scale_y = buttons_size
        #     op = row.operator("object.speedretopo_set_face_sets", text="Face Sets From Selection", icon='MOD_TRIANGULATE')
        #     op.face_sets_from = "face_sets_from_selection"
        #     row = col.row(align=True)
        #     row.scale_y = buttons_size
        #     op = row.operator("object.speedretopo_set_face_sets", text="Face Sets By Loose Parts", icon='UV_ISLANDSEL')
        #     op.face_sets_from = "face_sets_by_loose_parts"
            # row = col.row(align=True)
            # row.scale_y = buttons_size
            # op = row.operator("object.speedretopo_set_face_sets", text="Face Sets From Visible", icon='SNAP_FACE')
            # op.face_sets_from = "face_sets_from_visible"
    # if context.active_object.speedretopo_ref_object:
    #     # FINALIZE
    #     box = layout.box()
    #     split = box.split()
    #     col = split.column(align=True)
    #     row = col.row(align=True)
    #     row.scale_y = 1.3
    #     icon = icons.get("icon_valid")
    #     row.operator("object.speedretopo_finalize_retopo", text="FINALIZE RETOPO", icon_value=icon.icon_id)

class SPEEDRETOPO_PT_start_retopo_settings(bpy.types.Operator):
    bl_idname = "view3d.start_retopo_settings"
    bl_label = "Start Retopo Settings"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.object.mode == "OBJECT"

    def invoke(self, context, event):
        self.dpi_value = context.preferences.system.dpi
        context.window_manager.windows[0].cursor_warp(x=int(event.mouse_x - (self.dpi_value*2/2)), y=int(event.mouse_y +200))
        popup = context.window_manager.invoke_popup(self, width=int(self.dpi_value*2))
        context.window_manager.windows[0].cursor_warp(x=event.mouse_x, y=event.mouse_y)
        return popup

    def draw(self, context):
        layout = self.layout
        addonPref = get_addon_preferences()
        use_color_shader = addonPref.use_color_shader
        obj = context.active_object

        if context.object is not None and context.object.mode == "OBJECT":

            box = layout.box()
            row = box.row(align=True)
            row.label(text="SET REFERENCE")
            row = box.row(align=True)
            # row = layout.row(align=True)
            row.scale_y = 1.3
            row.prop(obj, "speedretopo_ref_object", text="", icon='MESH_MONKEY')
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("object.speedretopo_create_retopo", text="START RETOPO", icon='GREASEPENCIL')
            box = layout.box()
            row = box.row(align=True)
            row.label(text="START RETOPO WITH", icon='TOOL_SETTINGS')
            row = box.row(align=True)
            row.scale_y = 1.5
            row.prop(addonPref, "start_from", text="")

            row = box.row(align=True)
            row.label(text="RETOPO SETTINGS", icon='MOD_HUE_SATURATION')
            row = box.row(align=True)
            row.scale_y = 1.2
            row.prop(addonPref, "auto_add_mirror", text="Add Mirror Modifier")

            row = box.row(align=True)
            row.scale_y = 1.2
            row.prop(addonPref, "auto_add_shrinkwrap", text="Add Shrinkwrap Modifier")

            row = box.row(align=True)
            row.scale_y = 1.2
            row.prop(addonPref, "hidden_wire", text="Use Hidden Wire")

            row = box.row(align=True)
            row.scale_y = 1.2
            row.prop(addonPref, "use_in_front", text="Use In front")

            row = box.row(align=True)
            row.scale_y = 1.2
            row.prop(addonPref, "use_wireframe", text="Show Wireframe")

            row = box.row(align=True)
            row.prop(addonPref, "use_color_shader", text="Use Color Shader")
            if use_color_shader:
                row.scale_y = 1.2
                row.prop(addonPref, "obj_color", text="")

class SPEEDRETOPO_PT_popup_menu(bpy.types.Operator):
    bl_idname = "view3d.speedretopo_popup_menu"
    bl_label = "Edit Menu"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1

    def invoke(self, context, event):
        self.dpi_value = context.preferences.system.dpi
        context.window_manager.windows[0].cursor_warp(x=int(event.mouse_x - (self.dpi_value*1.5/2)), y=int(event.mouse_y))
        popup = context.window_manager.invoke_popup(self, width=int(self.dpi_value*1.5))
        context.window_manager.windows[0].cursor_warp(x=event.mouse_x, y=event.mouse_y)
        return popup

    def draw(self, context):
        layout = self.layout

        SpeedRetopo(self, context)

class SPEEDRETOPO_OT_start_or_edit(bpy.types.Operator):
    bl_idname = 'object.speedretopo_ot_start_or_edit'
    bl_label = "Speedretopo"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1


    def execute(self, context):
        addonPref = get_addon_preferences()
        use_menu_or_pie_menu = addonPref.use_menu_or_pie_menu

        if context.object.mode == 'EDIT':
            if use_menu_or_pie_menu == 'menu':
                bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
            else:
                bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")

        elif context.object.mode != 'EDIT':
            if context.active_object.speedretopo_ref_object:
                bpy.ops.object.mode_set(mode='EDIT')
                if use_menu_or_pie_menu == 'menu':
                    bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
                else:
                    bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")
            else:
                bpy.ops.view3d.start_retopo_settings('INVOKE_DEFAULT')

        elif context.object.mode == 'SCULPT':
            if context.active_object.speedretopo_ref_object:
                if use_menu_or_pie_menu == 'menu':
                    bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
                else:
                    bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")
            else:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.view3d.start_retopo_settings('INVOKE_DEFAULT')
        return {'FINISHED'}


# Pie Menu

def speedretopo_pie_menus_modifiers(self, context):
    pie = self.layout.menu_pie()
    icons = load_icons()

    # ------Mirror
    col = pie.column(align=True)
    mirror = context.active_object.modifiers.get("Mirror")
    if mirror:
        row = col.row(align=True)
        row.label(text="", icon='MOD_MIRROR')
        row.scale_x = 1.3
        row.scale_y = 1.2
        if context.object.modifiers["Mirror"].show_viewport == False:
            row.prop(context.active_object.modifiers["Mirror"], "show_viewport", text="")
        elif context.object.modifiers["Mirror"].show_viewport == True:
            row.prop(context.active_object.modifiers["Mirror"], "show_viewport", text="")
        icon = icons.get("icon_clipping")
        row.prop(context.active_object.modifiers["Mirror"], "use_clip", text="", icon_value=icon.icon_id)
        icon = icons.get("icon_valid")
        row.operator("speedretopo.apply_mirror", text="", icon_value=icon.icon_id)
        icon = icons.get("icon_delete")
        row.operator("object.speedretopo_remove_mirror", text="", icon_value=icon.icon_id)

    # ------shrinkwrap
    shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
    if shrinkwrap:
        row = col.row(align=True)
        row.label(text="", icon='MOD_SHRINKWRAP')
        row.scale_x = 1.3
        row.scale_y = 1.2
        if context.object.modifiers["Shrinkwrap"].show_viewport == False:
            row.prop(context.active_object.modifiers["Shrinkwrap"], "show_viewport", text="")
        elif context.object.modifiers["Shrinkwrap"].show_viewport == True:
            row.prop(context.active_object.modifiers["Shrinkwrap"], "show_viewport", text="")
        icon = icons.get("icon_update")
        row.operator("object.speedretopo_update_shrinkwrap", text="", icon_value=icon.icon_id)
        icon = icons.get("icon_valid")
        row.operator("object.speedretopo_apply_shrinkwrap", text="", icon_value=icon.icon_id)
        icon = icons.get("icon_delete")
        row.operator("object.speedretopo_remove_shrinkwrap", text="", icon_value=icon.icon_id)

    # Subsurf
    subsurf = context.active_object.modifiers.get("Subsurf")
    if subsurf:
        row = col.row(align=True)
        row.label(text="", icon='MOD_SUBSURF')
        row.scale_x = 1.3
        row.scale_y = 1.2
        if context.object.modifiers["Subsurf"].show_viewport == False:
            row.prop(context.active_object.modifiers["Subsurf"], "show_viewport", text="")
        elif context.object.modifiers["Subsurf"].show_viewport == True:
            row.prop(context.active_object.modifiers["Subsurf"], "show_viewport", text="")
        icon = icons.get("icon_optimal_display")
        row.prop(context.active_object.modifiers["Subsurf"], "show_only_control_edges", text="",
                 icon_value=icon.icon_id)
        icon = icons.get("icon_valid")
        row.operator("object.speedretopo_apply_subsurf", text="", icon_value=icon.icon_id)
        icon = icons.get("icon_delete")
        row.operator("object.speedretopo_remove_subsurf", text="", icon_value=icon.icon_id)

    if not mirror:
        row = col.row(align=True)
        row.scale_y = 1.2
        row.operator("object.speedretopo_add_mirror", text="Add Mirror", icon='MOD_MIRROR')

    if not shrinkwrap:
        row = col.row(align=True)
        row.scale_y = 1.2
        row.operator("object.speedretopo_add_shrinkwrap", text="Add shrinkwrap", icon='MOD_SHRINKWRAP')
        icon = icons.get("icon_valid")
        row.operator("object.speedretopo_add_apply_shrinkwrap", text="", icon_value=icon.icon_id)

    if not subsurf:
        row = col.row(align=True)
        row.scale_y = 1.2
        row.operator("object.speedretopo_add_subsurf", text="Add Subsurf", icon='MOD_SUBSURF')

class SPEEDRETOPO_MT_pie_menu(Menu):
    bl_label = "SPEEDRETOPO"

    @classmethod
    def poll(cls, context):
        return len(context.object is not None and context.selected_objects) == 1

    def draw(self, context):
        pie = self.layout.menu_pie()
        icons = load_icons()

        if len(context.object is not None and context.selected_objects) == 1:
            # OBJECT_MODE
            if context.object.mode in {"OBJECT","SCULPT"}:

                #4 - LEFT
                speedretopo_pie_menus_modifiers(self, context)

                #6 - RIGHT
                pie.separator()

                #2 - BOTTOM
                split = pie.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1.2
                icon = icons.get("icon_recalculate_normals")
                row.operator("object.speedretopo_clean_normals", text="Recalculate Normals", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1.2
                shading = context.space_data.shading

                row = col.row(align=True)
                row.scale_y = 1.2
                if context.object.show_in_front == False:
                    row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_OFF')
                elif context.object.show_in_front == True:
                    row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_ON')

                row = col.row(align=True)
                row.scale_y = 1.3
                if context.object.show_wire == False:
                    row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_OFF')
                elif context.object.show_wire == True:
                    row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_ON')

                row = col.row(align=True)
                row.scale_y = 1.2
                if shading.show_backface_culling == False:
                    row.prop(shading, "show_backface_culling", text="Back Face Culling", icon='RADIOBUT_OFF')
                elif shading.show_backface_culling == True:
                    row.prop(shading, "show_backface_culling", text="Back Face Culling", icon='RADIOBUT_ON')

                #8 - TOP
                col = pie.column(align=True)
                # row = col.row(align=True)
                # row.label(text="SET REFERENCE")
                # obj = context.active_object
                # row = col.row(align=True)
                # row.scale_y = 1.2
                # row.prop(obj, "speedretopo_ref_object", text="", icon='MESH_MONKEY')

                row = col.row(align=True)
                row.scale_y = 1.2
                icon = icons.get("icon_continue")
                row.operator("object.speedretopo_continue_retopo", text="CONTINUE RETOPO", icon_value=icon.icon_id)

                #7 - TOP - LEFT
                col = pie.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1.2
                # icon = icons.get("icon_valid")
                # row.operator("object.speedretopo_finalize_retopo", text="FINALIZE", icon_value=icon.icon_id)
                # row.operator("object.speedretopo_exit_retopo", text="EXIT RETOPO", icon='PAUSE')

                row = col.row(align=True)
                row.prop(context.active_object, "speedretopo_ref_object")

                #9 - TOP - RIGHT
                pie.separator()

                #1 - BOTTOM - LEFT
                pie.separator()

                #3 - BOTTOM - RIGHT
                pie.separator()


            # EDIT_MODE
            if context.object.mode == "EDIT":
                speedretopo_pie_menus_modifiers(self, context)

                #6 - RIGHT
                icon = icons.get("icon_align_to_x")
                pie.operator("object.speedretopo_align_center_edges", text="Align Vertices to Center", icon_value=icon.icon_id)

                #2 - BOTTOM
                split = pie.split()
                col = split.column(align=True)
                if hasattr(bpy.types, "MESH_OT_retopomt"):
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    icon = icons.get("icon_retopomt")
                    row.operator("mesh.retopomt", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1.2
                icon = icons.get("icon_recalculate_normals")
                row.operator("object.speedretopo_clean_normals", text="Recalculate Normals", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1.2
                icon = icons.get("icon_flip_normals")
                row.operator("mesh.flip_normals", text="Flip Normals", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1.2
                overlay = context.space_data.overlay
                shading = context.space_data.shading

                if overlay.show_occlude_wire == False :
                    row.prop(overlay, "show_occlude_wire", text = "Hidden Wire", icon='RADIOBUT_OFF')
                elif overlay.show_occlude_wire == True :
                    row.prop(overlay, "show_occlude_wire", text = "Hidden Wire", icon='RADIOBUT_ON')

                row = col.row(align=True)
                row.scale_y = 1.2
                if context.object.show_in_front == False:
                    row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_OFF')
                elif context.object.show_in_front == True:
                    row.prop(context.object, "show_in_front", text="In Front", icon='RADIOBUT_ON')

                row = col.row(align=True)
                row.scale_y = 1.2
                if context.object.show_wire == False:
                    row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_OFF')
                elif context.object.show_wire == True:
                    row.prop(context.object, "show_wire", text="Wireframe", icon='RADIOBUT_ON')

                row = col.row(align=True)
                row.scale_y = 1.2
                if shading.show_backface_culling == False :
                    row.prop(shading, "show_backface_culling", text = "Back Face Culling", icon='RADIOBUT_OFF')
                elif shading.show_backface_culling == True :
                    row.prop(shading, "show_backface_culling", text = "Back Face Culling", icon='RADIOBUT_ON')

                # Center
                row = col.row(align=True)
                row.label(text='Center Tools', icon='THREE_DOTS')
                row = col.row(align=True)
                me = context.object.data
                bm = bmesh.from_edit_mesh(me)
                if [v for v in bm.verts if v.select] :
                    row.operator("object.speedretopo_set_unset_center", text='Set', icon='LAYER_ACTIVE').set_unset_center = "set"
                    row.operator("object.speedretopo_set_unset_center", text='UnSet', icon='IPO_LINEAR').set_unset_center = "unset"
                row = col.row(align=True)
                row.operator("object.speedretopo_set_unset_center", text='Select', icon='GROUP_VERTEX').set_unset_center = "select"
                row.operator("object.speedretopo_set_unset_center", text='Clear', icon='SELECT_SET').set_unset_center = "clear"

                # freeze
                row = col.row(align=True)
                row.label(text='Freezing Tools', icon='FREEZE')
                row = col.row(align=True)
                me = context.object.data
                bm = bmesh.from_edit_mesh(me)
                if [v for v in bm.verts if v.select] :
                    row.operator("object.speedretopo_freeze_unfreeze", text='Freeze', icon='FREEZE').freeze_unfreeze = "freeze"
                    row.operator("object.speedretopo_freeze_unfreeze", text='UnFreeze', icon='IPO_LINEAR').freeze_unfreeze = "unfreeze"
                row = col.row(align=True)
                row.operator("object.speedretopo_freeze_unfreeze", text='Select', icon='GROUP_VERTEX').freeze_unfreeze = "select"
                row.operator("object.speedretopo_freeze_unfreeze", text='Clear', icon='SELECT_SET').freeze_unfreeze = "clear"

                # row = col.row(align=True)
                # row.scale_y = 1.2
                # op = row.operator("object.speedretopo_set_face_sets", text="Face Sets From Selection",
                #                   icon='MOD_TRIANGULATE')
                # op.face_sets_from = "face_sets_from_selection"
                # row = col.row(align=True)
                # row.scale_y = 1.2
                # op = row.operator("object.speedretopo_set_face_sets", text="Face Sets By Loose Parts",
                #                   icon='UV_ISLANDSEL')
                # op.face_sets_from = "face_sets_by_loose_parts"
                # row = col.row(align=True)
                # row.scale_y = 1.2
                # op = row.operator("object.speedretopo_set_face_sets", text="Face Sets From Visible", icon='SNAP_FACE')
                # op.face_sets_from = "face_sets_from_visible"

                #8 - TOP
                col = pie.column(align=True)
                row = col.row(align=True)

                if context.scene.bsurfaces.SURFSK_mesh == bpy.data.objects[context.object.name]:
                    icon = icons.get("icon_bsurface")
                    row.scale_y = 1.3
                    row.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)
                else:
                    icon = icons.get("icon_error")
                    row.scale_y = 1.3
                    row.operator("object.speedretopo_set_bsurface", text="Click to Set Bsurface Mesh", icon_value=icon.icon_id)
                # icon = icons.get("icon_bsurface")
                # row.operator("object.speedretopo_add_bsurface", text="Add BSurface", icon_value=icon.icon_id)
                # row.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)

                #7 - TOP - LEFT
                col = pie.column(align=True)
                row=col.row(align=True)
                row.scale_y = 1.2
                # icon = icons.get("icon_valid")
                # row.operator("object.speedretopo_finalize_retopo", text="FINALIZE", icon_value=icon.icon_id)
                # row.operator("object.speedretopo_exit_retopo", text="EXIT RETOPO", icon='PAUSE')

                row = col.row(align=True)
                row.prop(context.active_object, "speedretopo_ref_object")

                #------Threshold
                row=col.row(align=True)
                row.scale_y = 1.2
                row.scale_x = 1
                row.prop(context.tool_settings, "use_mesh_automerge", text="Auto Merge")
                row.operator("object.speedretopo_double_threshold_plus", text="0.1")
                row.operator("object.speedretopo_double_threshold_minus", text="0.001")

                #9 - TOP - RIGHT
                icon = icons.get("icon_space")
                pie.operator("object.speedretopo_space_relax", text="Space", icon_value=icon.icon_id)

                #1 - BOTTOM - LEFT
                split = pie.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1
                row.scale_x = 1.3
                icon = icons.get("icon_gstretch")
                # row.operator("mesh.looptools_gstretch", text="GStretch", icon_value=icon.icon_id)
                row.operator("object.speedretopo_gstretch", text="GStretch", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1
                row.scale_x = 1.3
                icon = icons.get("icon_bridge")
                row.operator("mesh.looptools_bridge", text="Bridge", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1
                row.scale_x = 1.3
                icon = icons.get("icon_gridfill")
                row.operator("mesh.fill_grid", text="Grid Fill", icon_value=icon.icon_id)
                row = col.row(align=True)
                row.scale_y = 1
                row.scale_x = 1.3
                icon = icons.get("icon_curve")
                row.operator("mesh.looptools_curve", text="Curve", icon_value=icon.icon_id)

                #3 - BOTTOM - RIGHT
                icon = icons.get("icon_relax")
                pie.operator("mesh.speedretopo_relax", text="Relax", icon_value=icon.icon_id)

        elif len(context.selected_objects) == 0:
            pie.separator()
            pie.separator()
            pie.separator()
            pie.operator("object.select_all", text="Select An Object", icon='ERROR').action = 'DESELECT'
            pie.separator()
            pie.separator()
            pie.separator()
            pie.separator()

        else:
            pie.separator()
            pie.separator()
            pie.separator()
            pie.operator("object.select_all", text="Select Only One Object", icon='ERROR').action = 'DESELECT'
            pie.separator()
            pie.separator()
            pie.separator()
            pie.separator()



# -----------------------------------------------------
# REGISTER/UNREGISTER
# -----------------------------------------------------
CLASSES =  [SPEEDRETOPO_PT_ui,
            SPEEDRETOPO_MT_pie_menu,
            SPEEDRETOPO_OT_start_or_edit,
            SPEEDRETOPO_PT_start_retopo_settings,
            SPEEDRETOPO_PT_popup_menu

            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in CLASSES:
        if hasattr(bpy.types, cls.__name__):
            bpy.utils.unregister_class(cls)