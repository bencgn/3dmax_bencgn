import bpy
from bpy.props import (
    FloatProperty,
    IntProperty,
    BoolProperty,
    StringProperty,
    FloatVectorProperty,
    PointerProperty,
    CollectionProperty,
    EnumProperty,
)
import math
import os
from os.path import abspath, join, exists
import bmesh
from bpy_extras import view3d_utils
from bpy_extras.object_utils import AddObjectHelper, object_data_add
import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from gpu.types import GPUVertBuf, GPUBatch, GPUVertFormat
from gpu.types import GPUShader
from mathutils import Vector
from mathutils import *
from math import *
from bpy.types import Panel, Menu, Operator, PropertyGroup, Macro
from bmesh.types import BMVert, BMFace
import mathutils
import bpy_extras
from bpy_extras.view3d_utils import region_2d_to_location_3d
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils.geometry import intersect_line_plane
from mathutils.geometry import intersect_line_line
from mathutils.geometry import intersect_line_line_2d
import traceback

from bgl import *
import numpy
import random

import addon_utils

from bpy_extras.io_utils import ImportHelper
from bpy_extras.io_utils import ExportHelper


class QA_PT_panel(bpy.types.Panel):
    bl_label = "QUICKASSEMBLY"
    bl_category = "QuickTools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):

        layout = self.layout

        box = layout.box()
        row = box.row()
        row.operator(QA_Apply.bl_idname)
        row = box.row()
        row.label(text="Array")
        row = box.row()
        row.operator(QA_LinearArray.bl_idname)
        # row = box.row()
        # row.operator(QA_LinearArrayCollection.bl_idname)
        row = box.row()
        row.operator(QA_RadialArray.bl_idname)
        # row = box.row()
        # row.operator(QA_RadialArrayCollection.bl_idname)
        row = box.row()
        row.operator(QA_BrickArray.bl_idname)
        row = box.row()
        row.operator(QA_CurveArray.bl_idname)
        row = box.row()
        row.operator(QA_CurveArrayCollection.bl_idname)
        row = box.row()
        row.label(text="Scatter")
        row = box.row()
        row.operator(QA_ObjectScatter.bl_idname)
        row = box.row()
        row.operator(QA_ObjectScatterCollection.bl_idname)
        row = box.row()
        row.operator(QA_TextureScatter.bl_idname)
        row = box.row()
        row.operator(QA_TextureScatterCollection.bl_idname)
        row = box.row()
        row.operator(QA_VolumeScatter.bl_idname)
        row = box.row()
        row.operator(QA_VolumeScatterCollection.bl_idname)
        row = box.row()
        row.operator(QA_Randomizer.bl_idname)
        row = box.row()
        row.operator(QA_RandomizerCollection.bl_idname)
        row = box.row()
        row.label(text="Effects")
        row = box.row()
        row.operator(QA_Shrinkwrap.bl_idname)
        row = box.row()
        row.operator(QA_Cloner.bl_idname)
        row = box.row()
        row.operator(QA_Growth.bl_idname)
        row = box.row()
        row.operator(QA_GrowthCollection.bl_idname)
        row = box.row()
        row.operator(QA_Snow.bl_idname)
        row = box.row()
        row.operator(QA_SnowCollection.bl_idname)
        row = box.row()
        row.operator(QA_Damage.bl_idname)
        row = box.row()
        row.operator(QA_Exploder.bl_idname)
        row = box.row()
        row.operator(QA_Spikes.bl_idname)
        row = box.row()
        row.operator(QA_Proxy.bl_idname)
        row = box.row()
        row.label(text="Displace")
        row = box.row()
        row.operator(QA_TextureDisplacement.bl_idname)
        row = box.row()
        row.operator(QA_NoiseDisplacement.bl_idname)


# apply


class QA_Apply(Operator):
    bl_idname = "object.qaapply"
    bl_label = "Apply Assembly"
    bl_description = "Apply modifiers on selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        node_out1 = None
        node_out2 = None

        if len(sel) > 0:

            for ob in sel:

                bpy.ops.object.select_all(action="DESELECT")
                bpy.data.objects[ob.name].select_set(True)
                bpy.context.view_layer.objects.active = ob

                for mod in ob.modifiers:
                    if mod.type == "NODES":
                        for input in mod.node_group.inputs:
                            if input.name == "Realize Instances":
                                mod[input.identifier] = 1

                bpy.ops.object.convert(target="MESH")

        return {"FINISHED"}


# array


class QA_LinearArray(Operator):
    bl_idname = "object.qalineararray"
    bl_label = "Linear Array"
    bl_description = "Create a Linear Array modifier on the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_LinearArray")
                    ]

                geomod = ob.modifiers.new(name="QT_LinearArray", type="NODES")

                original_group = bpy.data.node_groups["QT_LinearArray"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_LinearArrayCollection(Operator):
    bl_idname = "object.qalineararraycollection"
    bl_label = "Linear Array Collection"
    bl_description = "Create a Linear Array modifier on the active object using the selected Collection"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_LinearArray_Collection")
                ]

            geomod = act.modifiers.new(name="QT_LinearArray_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_LinearArray_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_37"] = col

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_RadialArray(Operator):
    bl_idname = "object.qaradialarray"
    bl_label = "Radial Array"
    bl_description = "Create a Radial Array modifier on the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_RadialArray")
                    ]

                geomod = ob.modifiers.new(name="QT_RadialArray", type="NODES")

                original_group = bpy.data.node_groups["QT_RadialArray"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_RadialArrayCollection(Operator):
    bl_idname = "object.qaradialarraycollection"
    bl_label = "Radial Array Collection"
    bl_description = "Create a Radial Array modifier on the active object using the selected Collection"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_RadialArray_Collection")
                ]

            geomod = act.modifiers.new(name="QT_RadialArray_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_RadialArray_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_26"] = col

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_BrickArray(Operator):
    bl_idname = "object.qabrickarray"
    bl_label = "Brick Array"
    bl_description = "Create a Brick Array modifier on the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_BrickArray")
                    ]

                geomod = ob.modifiers.new(name="QT_BrickArray", type="NODES")

                original_group = bpy.data.node_groups["QT_BrickArray"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_CurveArray(Operator):
    bl_idname = "object.qacurvearray"
    bl_label = "Curve Array"
    bl_description = "Array selected object along the selected Curve"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 1:

            if act.type == "CURVE":
                if act.data.bevel_object:
                    act.data.bevel_object = None

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_CurveArray")
                ]

            geomod = act.modifiers.new(name="QT_CurveArray", type="NODES")

            original_group = bpy.data.node_groups["QT_CurveArray"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Join"):
                    node_join = n

            # move geo node to top
            for modifier in act.modifiers:
                while act.modifiers.find(geomod.name) != 0:
                    bpy.ops.object.modifier_move_up(modifier=geomod.name)

            for ob in sel:
                if ob != act:

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    bpy.ops.object.origin_set(
                        type="ORIGIN_CENTER_OF_MASS", center="MEDIAN"
                    )
                    matrix = Matrix()
                    me = ob.data
                    mw = ob.matrix_world
                    local_verts = [matrix @ Vector(v[:]) for v in ob.bound_box]
                    o = sum(local_verts, Vector()) / 8
                    o.z = min(v.z for v in local_verts)
                    o = matrix.inverted() @ o
                    me.transform(Matrix.Translation(-o))
                    mw.translation = mw @ o
                    ob.location = Vector((0, 0, 0))

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

                    node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                    node_object.transform_space = "ORIGINAL"
                    node_object.inputs[0].default_value = ob
                    node_object.inputs[1].default_value = True
                    node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

                    # ob.hide_set(True)

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            context.area.tag_redraw()

        return {"FINISHED"}


class QA_CurveArrayCollection(Operator):
    bl_idname = "object.qacurvearraycollection"
    bl_label = "Curve Array Collection"
    bl_description = "Array objects in selected Collection along the selected Curve"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            if act.data.bevel_object:
                act.data.bevel_object = None

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_CurveArray_Collection")
                ]

            geomod = act.modifiers.new(name="QT_CurveArray_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_CurveArray_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Join"):
                    node_join = n

            # move geo node to top
            for modifier in act.modifiers:
                while act.modifiers.find(geomod.name) != 0:
                    bpy.ops.object.modifier_move_up(modifier=geomod.name)

            # move collection objects to ground
            for ob in col.all_objects:
                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    bpy.ops.object.origin_set(
                        type="ORIGIN_CENTER_OF_MASS", center="MEDIAN"
                    )
                    matrix = Matrix()
                    me = ob.data
                    mw = ob.matrix_world
                    local_verts = [matrix @ Vector(v[:]) for v in ob.bound_box]
                    o = sum(local_verts, Vector()) / 8
                    o.z = min(v.z for v in local_verts)
                    o = matrix.inverted() @ o
                    me.transform(Matrix.Translation(-o))
                    mw.translation = mw @ o
                    ob.location = Vector((0, 0, 0))
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

            # bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_47"] = col

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            context.area.tag_redraw()

        return {"FINISHED"}


# scatter


class QA_ObjectScatter(Operator):
    bl_idname = "object.qaobjectscatter"
    bl_label = "Object Scatter"
    bl_description = "Scatter the selected objects onto the active object"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 1:

            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=act.location
            )
            obj = context.object
            context.view_layer.objects.active = obj

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_ObjectScatter")
                ]

            geomod = obj.modifiers.new(name="QT_ObjectScatter", type="NODES")

            original_group = bpy.data.node_groups["QT_ObjectScatter"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Join"):
                    node_join = n

                if n.name.startswith("TARGET"):
                    node_target = n
                    node_target.inputs[0].default_value = act

            for ob in sel:

                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

                    ob.hide_set(True)

                    node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                    node_object.transform_space = "ORIGINAL"
                    node_object.inputs[0].default_value = ob
                    node_object.inputs[1].default_value = True
                    node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            context.area.tag_redraw()

        return {"FINISHED"}


class QA_ObjectScatterCollection(Operator):
    bl_idname = "object.qaobjectscattercollection"
    bl_label = "Object Scatter Collection"
    bl_description = "Scatter the selected Collection onto the active object"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.ops.object.duplicate()
            obj = context.object
            context.view_layer.objects.active = obj
            bpy.ops.object.select_all(action="DESELECT")

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_ObjectScatter_Collection")
                ]

            geomod = obj.modifiers.new(name="QT_ObjectScatter_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_ObjectScatter_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Join"):
                    node_join = n

                if n.name.startswith("TARGET"):
                    node_target = n
                    node_target.inputs[0].default_value = act

            # move collection objects to ground
            for ob in col.all_objects:
                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_17"] = col

            context.area.tag_redraw()

        return {"FINISHED"}


class QA_TextureScatter(Operator, ImportHelper):
    bl_idname = "object.qatexturescatter"
    bl_label = "Texture Scatter"
    bl_description = (
        "Scatter the selected objects onto the active object using a texture"
    )
    bl_options = {"PRESET", "UNDO"}

    files: CollectionProperty(type=bpy.types.PropertyGroup)  # Stores properties

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        dirname = os.path.dirname(self.filepath)

        node_img = None

        for f in self.files:
            if len(self.files) == 1:
                f = self.files[0]
                img_path = os.path.join(dirname, f.name)
                bpy.ops.image.open(filepath=img_path)
                bpy.data.images[f.name].filepath = img_path
                img_spec = bpy.data.images[f.name]
            else:
                return {"FINISHED"}

        if len(sel) == 1:

            geomod = act.modifiers.get("QT_TextureScatter")
            if geomod:
                node_tree = bpy.data.node_groups[geomod.node_group.name]
                for n in node_tree.nodes:
                    if n.name.startswith("Image"):
                        node_img = n
                if node_img:
                    node_img.inputs[0].default_value = img_spec

        if len(sel) > 1:

            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=act.location
            )
            obj = context.object
            context.view_layer.objects.active = obj

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_TextureScatter")
                ]

            geomod = obj.modifiers.new(name="QT_TextureScatter", type="NODES")

            original_group = bpy.data.node_groups["QT_TextureScatter"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Image"):
                    node_img = n
                    node_img.inputs[0].default_value = img_spec

                if n.name.startswith("Join"):
                    node_join = n

                if n.name.startswith("TARGET"):
                    node_target = n
                    node_target.inputs[0].default_value = act

            for ob in sel:
                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

                    ob.hide_set(True)

                    node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                    node_object.transform_space = "ORIGINAL"
                    node_object.inputs[0].default_value = ob
                    node_object.inputs[1].default_value = True
                    node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

        bpy.ops.object.select_all(action="DESELECT")
        bpy.data.objects[act.name].select_set(True)
        bpy.context.view_layer.objects.active = act

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_TextureScatterCollection(Operator, ImportHelper):
    bl_idname = "object.qatexturescattercollection"
    bl_label = "Texture Scatter Collection"
    bl_description = (
        "Scatter the selected Collection onto the active object using a texture"
    )
    bl_options = {"PRESET", "UNDO"}

    files: CollectionProperty(type=bpy.types.PropertyGroup)  # Stores properties

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        dirname = os.path.dirname(self.filepath)

        node_img = None

        for f in self.files:
            if len(self.files) == 1:
                f = self.files[0]
                img_path = os.path.join(dirname, f.name)
                bpy.ops.image.open(filepath=img_path)
                bpy.data.images[f.name].filepath = img_path
                img_spec = bpy.data.images[f.name]
            else:
                return {"FINISHED"}

        if col and act:

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.ops.object.duplicate()
            obj = context.object
            context.view_layer.objects.active = obj
            bpy.ops.object.select_all(action="DESELECT")

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_TextureScatter_Collection")
                ]

            geomod = obj.modifiers.new(
                name="QT_TextureScatter_Collection", type="NODES"
            )

            original_group = bpy.data.node_groups["QT_TextureScatter_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Image"):
                    node_img = n
                    node_img.inputs[0].default_value = img_spec

                if n.name.startswith("TARGET"):
                    node_target = n
                    node_target.inputs[0].default_value = act

            # move collection objects to ground
            for ob in col.all_objects:
                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_21"] = col

            context.area.tag_redraw()

        return {"FINISHED"}


class QA_VolumeScatter(Operator):
    bl_idname = "object.qavolumescatter"
    bl_label = "Volume Scatter"
    bl_description = "Scatter the selected objects into the volume of the active object"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 1:

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_VolumeScatter")
                ]

            geomod = act.modifiers.new(name="QT_VolumeScatter", type="NODES")

            original_group = bpy.data.node_groups["QT_VolumeScatter"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            node_tree = bpy.data.node_groups[geomod.node_group.name]
            for n in node_tree.nodes:
                if n.name.startswith("Join"):
                    node_join = n

            for ob in sel:

                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

                    ob.hide_set(True)

                    node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                    node_object.transform_space = "ORIGINAL"
                    node_object.inputs[0].default_value = ob
                    node_object.inputs[1].default_value = True
                    node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act
            bpy.ops.object.origin_set(type="ORIGIN_CENTER_OF_MASS", center="MEDIAN")

            context.area.tag_redraw()

        return {"FINISHED"}


class QA_VolumeScatterCollection(Operator):
    bl_idname = "object.qavolumescattercollection"
    bl_label = "Volume Scatter Collection"
    bl_description = (
        "Scatter the selected Collection into the volume of the active object"
    )
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_VolumeScatter_Collection")
                ]

            geomod = act.modifiers.new(name="QT_VolumeScatter_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_VolumeScatter_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            # move collection objects to ground
            for ob in col.all_objects:
                if ob != act:

                    bpy.ops.object.select_all(action="DESELECT")
                    bpy.data.objects[ob.name].select_set(True)
                    bpy.context.view_layer.objects.active = ob

                    # proper orientation for custom object
                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )
                    local_bbox_center = 0.125 * sum(
                        (Vector(b) for b in ob.bound_box), Vector()
                    )
                    global_bbox_center = ob.matrix_world @ local_bbox_center
                    ob.data.transform(mathutils.Matrix.Translation(-global_bbox_center))

                    bbox_coords = [Vector(b) for b in ob.bound_box]
                    bbox_y = bbox_coords[0] - global_bbox_center
                    bbox_z = bbox_coords[1] - global_bbox_center

                    ob.matrix_world.translation.z = bbox_z[2]

                    bpy.ops.object.transform_apply(
                        location=True, rotation=True, scale=True
                    )

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act
            bpy.ops.object.origin_set(type="ORIGIN_CENTER_OF_MASS", center="MEDIAN")

            geomod["Input_18"] = col

        context.area.tag_redraw()

        return {"FINISHED"}


# fx


class QA_Shrinkwrap(Operator):
    bl_idname = "object.qashrinkwrap"
    bl_label = "Shrinkwrap"
    bl_description = "Shrinkwrap selected object onto the active object"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 1:

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_Shrinkwrap")
                ]

            for ob in sel:
                if ob != act:

                    geomod = ob.modifiers.new(name="QT_Shrinkwrap", type="NODES")
                    original_group = bpy.data.node_groups["QT_Shrinkwrap"]
                    single_user_group = original_group.copy()
                    geomod.node_group = single_user_group

                    node_tree = bpy.data.node_groups[geomod.node_group.name]
                    for n in node_tree.nodes:
                        if n.name.startswith("TARGET"):
                            node_target = n
                            node_target.inputs[0].default_value = act

        return {"FINISHED"}


class QA_Cloner(Operator):
    bl_idname = "object.qacloner"
    bl_label = "Cloner"
    bl_description = "Create copies of the selected objects and apply randomization"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Cloner")
                    ]

                geomod = ob.modifiers.new(name="QT_Cloner", type="NODES")

                original_group = bpy.data.node_groups["QT_Cloner"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        return {"FINISHED"}


class QA_Randomizer(Operator):
    bl_idname = "object.qarandomizer"
    bl_label = "Randomizer"
    bl_description = "Apply randomization to the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if act:
            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=act.location
            )
            obj = context.object
            context.view_layer.objects.active = obj

            if len(sel) > 0:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Randomizer")
                    ]

                geomod = obj.modifiers.new(name="QT_Randomizer", type="NODES")
                original_group = bpy.data.node_groups["QT_Randomizer"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

                for ob in sel:

                    node_tree = bpy.data.node_groups[geomod.node_group.name]
                    for n in node_tree.nodes:
                        if n.name.startswith("Join"):
                            node_join = n

                    node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                    node_object.transform_space = "RELATIVE"
                    node_object.inputs[0].default_value = ob
                    node_object.inputs[1].default_value = True
                    node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

                    ob.hide_set(True)

        return {"FINISHED"}


class QA_RandomizerCollection(Operator):
    bl_idname = "object.qarandomizercollection"
    bl_label = "Randomizer Collection"
    bl_description = "Apply randomization to the selected collection"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection

        if col:

            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=Vector((0, 0, 0))
            )
            obj = context.object
            context.view_layer.objects.active = obj
            col.objects.unlink(obj)
            bpy.context.scene.collection.objects.link(obj)

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_Randomizer_Collection")
                ]

            geomod = obj.modifiers.new(name="QT_Randomizer_Collection", type="NODES")
            original_group = bpy.data.node_groups["QT_Randomizer_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            bpy.context.view_layer.active_layer_collection.hide_viewport = True
            geomod["Input_7"] = col

        context.area.tag_redraw()

        return {"FINISHED"}


class QA_Growth(Operator):
    bl_idname = "object.qagrowth"
    bl_label = "Growth"
    bl_description = "Grow selected object on the active object"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if sel and act:
            if len(sel) > 1:

                bpy.ops.object.select_all(action="DESELECT")
                bpy.data.objects[act.name].select_set(True)
                context.view_layer.objects.active = act

                bpy.ops.object.duplicate()
                obj = context.object
                bpy.ops.object.select_all(action="DESELECT")
                bpy.data.objects[obj.name].select_set(True)
                context.view_layer.objects.active = obj

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Growth")
                    ]

                geomod = obj.modifiers.new(name="QT_Growth", type="NODES")

                original_group = bpy.data.node_groups["QT_Growth"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

                node_tree = bpy.data.node_groups[geomod.node_group.name]
                for n in node_tree.nodes:
                    if n.name.startswith("Join"):
                        node_join = n

                for ob in sel:
                    if ob != act:

                        bpy.ops.object.transform_apply(
                            location=True, rotation=True, scale=True
                        )
                        bpy.ops.object.origin_set(
                            type="ORIGIN_CENTER_OF_MASS", center="MEDIAN"
                        )
                        matrix = Matrix()
                        me = ob.data
                        mw = ob.matrix_world
                        local_verts = [matrix @ Vector(v[:]) for v in ob.bound_box]
                        o = sum(local_verts, Vector()) / 8
                        o.z = min(v.z for v in local_verts)
                        o = matrix.inverted() @ o
                        me.transform(Matrix.Translation(-o))
                        mw.translation = mw @ o
                        ob.location = Vector((0, 0, 0))

                        bpy.ops.object.transform_apply(
                            location=True, rotation=True, scale=True
                        )

                        node_object = node_tree.nodes.new("GeometryNodeObjectInfo")
                        node_object.transform_space = "ORIGINAL"
                        node_object.inputs[0].default_value = ob
                        node_object.inputs[1].default_value = True
                        node_tree.links.new(node_object.outputs[3], node_join.inputs[0])

                bpy.ops.object.select_all(action="DESELECT")
                bpy.data.objects[obj.name].select_set(True)
                bpy.context.view_layer.objects.active = obj

        return {"FINISHED"}


class QA_GrowthCollection(Operator):
    bl_idname = "object.qagrowthcollection"
    bl_label = "Growth Collection"
    bl_description = "Grow active object on the selected Collection"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection
        act = bpy.context.view_layer.objects.active

        if col and act:

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.ops.object.duplicate()
            obj = context.object
            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            context.view_layer.objects.active = obj

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_Growth_Collection")
                ]

            geomod = obj.modifiers.new(name="QT_Growth_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_Growth_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            # move active obj to ground
            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[act.name].select_set(True)
            bpy.context.view_layer.objects.active = act

            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            bpy.ops.object.origin_set(type="ORIGIN_CENTER_OF_MASS", center="MEDIAN")
            matrix = Matrix()
            me = obj.data
            mw = obj.matrix_world
            local_verts = [matrix @ Vector(v[:]) for v in obj.bound_box]
            o = sum(local_verts, Vector()) / 8
            o.z = min(v.z for v in local_verts)
            o = matrix.inverted() @ o
            me.transform(Matrix.Translation(-o))
            mw.translation = mw @ o
            obj.location = Vector((0, 0, 0))
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            geomod["Input_23"] = col

        return {"FINISHED"}


class QA_Snow(Operator):
    bl_idname = "object.qasnow"
    bl_label = "Snow"
    bl_description = "Create Snow on the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 0:

            for ob in sel:

                bpy.ops.object.select_all(action="DESELECT")
                obj = bpy.ops.mesh.primitive_plane_add(
                    enter_editmode=False, location=ob.location
                )
                obj = context.object
                context.view_layer.objects.active = obj

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Snow")
                    ]

                geomod = obj.modifiers.new(name="QT_Snow", type="NODES")

                original_group = bpy.data.node_groups["QT_Snow"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

                node_tree = bpy.data.node_groups[geomod.node_group.name]
                for n in node_tree.nodes:
                    if n.name.startswith("Object"):
                        node_object = n

                node_object.inputs[0].default_value = ob

        return {"FINISHED"}


class QA_SnowCollection(Operator):
    bl_idname = "object.qasnowcollection"
    bl_label = "Snow Collection"
    bl_description = "Create Snow on the selected Collection"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        col = bpy.context.view_layer.active_layer_collection.collection

        if col:

            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=Vector((0, 0, 0))
            )
            obj = context.object
            context.view_layer.objects.active = obj
            col.objects.unlink(obj)
            bpy.context.scene.collection.objects.link(obj)

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_Snow_Collection")
                ]

            geomod = obj.modifiers.new(name="QT_Snow_Collection", type="NODES")

            original_group = bpy.data.node_groups["QT_Snow_Collection"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

            bpy.ops.object.select_all(action="DESELECT")
            bpy.data.objects[obj.name].select_set(True)
            bpy.context.view_layer.objects.active = obj

            geomod["Input_12"] = col

        return {"FINISHED"}


class QA_Damage(Operator):
    bl_idname = "object.qadamage"
    bl_label = "Damage"
    bl_description = "Simple Damage on selected objects"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):

        sel = context.selected_objects

        for ob in sel:
            bpy.ops.object.convert(target="MESH")

            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.mesh.quads_convert_to_tris(
                quad_method="BEAUTY", ngon_method="BEAUTY"
            )
            bpy.ops.object.editmode_toggle()

            filepath = None
            for mod in addon_utils.modules():
                if mod.bl_info["name"] == "QuickAssembly 2022":
                    filepath = mod.__file__

            dirpath = os.path.dirname(filepath)
            fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

            with bpy.data.libraries.load(fullpath, link=False) as (data_from, data_to):
                data_to.node_groups = [
                    name
                    for name in data_from.node_groups
                    if name.startswith("QT_Damage")
                ]

            geomod = ob.modifiers.new(name="QT_Damage", type="NODES")

            original_group = bpy.data.node_groups["QT_Damage"]
            single_user_group = original_group.copy()
            geomod.node_group = single_user_group

        return {"FINISHED"}


class QA_Exploder(Operator):
    bl_idname = "object.qaexploder"
    bl_label = "Exploder"
    bl_description = "Explode selected object with voronoi chunks"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Exploder")
                    ]

                geomod = ob.modifiers.new(name="QT_Exploder", type="NODES")

                original_group = bpy.data.node_groups["QT_Exploder"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        return {"FINISHED"}


class QA_Spikes(Operator):
    bl_idname = "object.qaspikes"
    bl_label = "Spikes"
    bl_description = "Create Spikes on the selected objects"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 0:

            for ob in sel:

                bpy.ops.object.select_all(action="DESELECT")
                obj = bpy.ops.mesh.primitive_plane_add(
                    enter_editmode=False, location=ob.location
                )
                obj = context.object
                context.view_layer.objects.active = obj

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Spikes")
                    ]

                geomod = obj.modifiers.new(name="QT_Spikes", type="NODES")

                original_group = bpy.data.node_groups["QT_Spikes"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

                node_tree = bpy.data.node_groups[geomod.node_group.name]
                for n in node_tree.nodes:
                    if n.name.startswith("TARGET"):
                        node_object = n

                node_object.inputs[0].default_value = ob

        return {"FINISHED"}


class QA_Proxy(Operator):
    bl_idname = "object.qaproxy"
    bl_label = "Proxy"
    bl_description = "Convert selected objects to instanced proxy meshes"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_Proxy")
                    ]

                geomod = ob.modifiers.new(name="QT_Proxy", type="NODES")

                original_group = bpy.data.node_groups["QT_Proxy"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        return {"FINISHED"}


# displace


class QA_TextureDisplacement(Operator, ImportHelper):
    bl_idname = "object.qatexturedisplacement"
    bl_label = "Texture Displacement"
    bl_description = "Triplanar texture based Mesh Displacement"
    bl_options = {"PRESET", "UNDO"}

    files: CollectionProperty(type=bpy.types.PropertyGroup)  # Stores properties

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        dirname = os.path.dirname(self.filepath)

        node_img = None

        for f in self.files:
            if len(self.files) == 1:
                f = self.files[0]
                img_path = os.path.join(dirname, f.name)
                bpy.ops.image.open(filepath=img_path)
                bpy.data.images[f.name].filepath = img_path
                img_spec = bpy.data.images[f.name]
            else:
                return {"FINISHED"}

        if len(sel) == 0:

            bpy.ops.object.select_all(action="DESELECT")
            obj = bpy.ops.mesh.primitive_plane_add(
                enter_editmode=False, location=Vector((0, 0, 0))
            )
            obj = context.object
            context.view_layer.objects.active = obj
            sel.append(obj)

        if len(sel) > 0:

            for ob in sel:

                for mod in ob.modifiers:
                    if mod.name.startswith("QT_TextureDisplacement"):
                        node_tree = bpy.data.node_groups[mod.node_group.name]
                        for n in node_tree.nodes:
                            if n.name.startswith("Image"):
                                node_img = n

                if not node_img:
                    filepath = None
                    for mod in addon_utils.modules():
                        if mod.bl_info["name"] == "QuickAssembly 2022":
                            filepath = mod.__file__

                    dirpath = os.path.dirname(filepath)
                    fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                    with bpy.data.libraries.load(fullpath, link=False) as (
                        data_from,
                        data_to,
                    ):
                        data_to.node_groups = [
                            name
                            for name in data_from.node_groups
                            if name.startswith("QT_TextureDisplacement")
                        ]

                    geomod = ob.modifiers.new(
                        name="QT_TextureDisplacement", type="NODES"
                    )

                    original_group = bpy.data.node_groups["QT_TextureDisplacement"]
                    single_user_group = original_group.copy()
                    geomod.node_group = single_user_group

                    node_tree = bpy.data.node_groups[geomod.node_group.name]
                    for n in node_tree.nodes:
                        if n.name.startswith("Image"):
                            node_img = n

            if node_img:
                node_img.inputs[0].default_value = img_spec

        return {"FINISHED"}


class QA_NoiseDisplacement(Operator):
    bl_idname = "object.qanoisedisplacement"
    bl_label = "Noise Displacement"
    bl_description = "Noise based Mesh Displacement"
    bl_options = {"PRESET", "UNDO"}

    def execute(self, context):

        sel = bpy.context.selected_objects
        act = bpy.context.view_layer.objects.active

        if len(sel) > 0:

            for ob in sel:

                filepath = None
                for mod in addon_utils.modules():
                    if mod.bl_info["name"] == "QuickAssembly 2022":
                        filepath = mod.__file__

                dirpath = os.path.dirname(filepath)
                fullpath = os.path.join(dirpath, "QA_GeoNodes.blend")

                with bpy.data.libraries.load(fullpath, link=False) as (
                    data_from,
                    data_to,
                ):
                    data_to.node_groups = [
                        name
                        for name in data_from.node_groups
                        if name.startswith("QT_NoiseDisplacement")
                    ]

                geomod = ob.modifiers.new(name="QT_NoiseDisplacement", type="NODES")

                original_group = bpy.data.node_groups["QT_NoiseDisplacement"]
                single_user_group = original_group.copy()
                geomod.node_group = single_user_group

        return {"FINISHED"}
