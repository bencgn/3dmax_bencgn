bl_info = {
    "name": "QuickAssembly 2022",
    "author": "Jama Jurabaev and ALKSNDR",
    "version": (1, 0),
    "blender": (3, 3, 1),
    "location": "See Sidebar ('N' Panel) for Hotkeys",
    "description": "Assemble your scenes and designs with Geometry Nodes",
    "wiki_url": "http://www.alksndr.com/quicktools",
    "tracker_url": "http://www.alksndr.com/quicktools",
    "category": "Mesh",
}

import bpy
from bpy.utils import register_class, unregister_class
from .operators import (
    QA_PT_panel,
    QA_Apply,
    QA_LinearArray,
    QA_LinearArrayCollection,
    QA_RadialArray,
    QA_RadialArrayCollection,
    QA_CurveArray,
    QA_CurveArrayCollection,
    QA_BrickArray,
    QA_Randomizer,
    QA_RandomizerCollection,
    QA_Cloner,
    QA_Proxy,
    QA_Snow,
    QA_SnowCollection,
    QA_Growth,
    QA_GrowthCollection,
    QA_Damage,
    QA_Exploder,
    QA_Spikes,
    QA_ObjectScatter,
    QA_ObjectScatterCollection,
    QA_TextureScatter,
    QA_TextureScatterCollection,
    QA_VolumeScatter,
    QA_VolumeScatterCollection,
    QA_TextureDisplacement,
    QA_NoiseDisplacement,
    QA_Shrinkwrap,
)

from bpy.props import (
    FloatProperty,
    IntProperty,
    BoolProperty,
    StringProperty,
    FloatVectorProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup
import rna_keymap_ui
import addon_utils

classes = (
    QA_PT_panel,
    QA_Apply,
    QA_LinearArray,
    QA_LinearArrayCollection,
    QA_RadialArray,
    QA_RadialArrayCollection,
    QA_CurveArray,
    QA_CurveArrayCollection,
    QA_BrickArray,
    QA_Randomizer,
    QA_RandomizerCollection,
    QA_Cloner,
    QA_Proxy,
    QA_Snow,
    QA_SnowCollection,
    QA_Growth,
    QA_GrowthCollection,
    QA_Damage,
    QA_Exploder,
    QA_Spikes,
    QA_ObjectScatter,
    QA_ObjectScatterCollection,
    QA_TextureScatter,
    QA_TextureScatterCollection,
    QA_VolumeScatter,
    QA_VolumeScatterCollection,
    QA_TextureDisplacement,
    QA_NoiseDisplacement,
    QA_Shrinkwrap,
)


def register():

    for cls in classes:
        register_class(cls)


def unregister():

    for cls in reversed(classes):
        unregister_class(cls)
