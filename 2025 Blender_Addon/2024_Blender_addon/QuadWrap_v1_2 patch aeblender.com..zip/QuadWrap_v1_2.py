#
#####################################################################################
# Copyright (C) 2020-2020 Quadwrap v1
# 
# animationsvfx@gmail.com Twitter: @AFX_LAB
# Based on code by AFX-LAB copyright (C) 2020-2020 Quadwrap v1
# Please do not modify or re-distribute in respect of the author.
# License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
#####################################################################################
#


bl_info = {    "name": "Quadwrap",
    "author": "Alberto Gonzalez",
    "version": (1, 2),
    "blender": (2,80,0),
    "location": "View3D > ToolShelf > Retopology > QuadWrap v1",
    "description": "Retopology tool for cylindrical/organic retopology.",
    "warning": "",
    "wiki_url": "",
    "category": "AFX"}



import bpy
from bpy_extras.view3d_utils import (region_2d_to_origin_3d, 
                                     region_2d_to_vector_3d)


from bpy.props import IntProperty, FloatProperty
import time
                                 
import bmesh
from bpy_extras import view3d_utils
from mathutils import Vector, Matrix

from math import radians

from bpy.types import Operator

import bgl
import gpu
from gpu_extras.batch import batch_for_shader
import numpy as np
import blf

from struct import pack

from mathutils import Vector
from mathutils.bvhtree import BVHTree
import fnmatch
import mathutils
from bpy_extras.view3d_utils import region_2d_to_location_3d

import math
import random
from mathutils import Vector


def cursor_create(context):
    
    brush = bpy.data.objects['qcBrush']#(CORE BRUSH(CIRCLE))
    brush.show_in_front = True
    
    return brush

def mouse_ray_get(context, event):
    co = event.mouse_region_x, event.mouse_region_y
    region = context.region
    r_data = context.space_data.region_3d
    
    origin = region_2d_to_origin_3d(region, r_data, co)
    direction = region_2d_to_vector_3d(region, r_data, co)
    return origin, direction
    
def update_prox(self,context):
    
    pass

bpy.types.Scene.prox_select = bpy.props.IntProperty(min = 0, max = 10, default = 1, description="Select more by proximity", update = update_prox)
 
 
 
#Subd levels DRAW
def draw_callback_px_text(self, context):
    
    font_id = 0  # XXX, need to find out how best to get this.

    # draw some text
  
 
    blf.position(font_id, self._x - 10, self._y, 0)
    blf.size(font_id, 20, 72)
    
    blf.color(font_id,1, 1, 1, 1)
        
   
    blf.draw(font_id, str(bpy.context.scene.ring_count))#self.cloak_ob.modifiers["Subdivision"].levels) )
    
    # 50% alpha, 2 pixel width line
   
    bgl.glBegin(bgl.GL_LINE_STRIP)
    for x, y in self.mouse_path:
        
        bgl.glVertex2i(x, y)

    bgl.glEnd()

    # restore opengl defaults
    bgl.glLineWidth(10)
    bgl.glDisable(bgl.GL_BLEND)
    bgl.glColor4f(0.5, 0.5, 1.0, 1.0) 
    
    
#Subd levels DRAW
def draw_callback_px_text2(self, context):
    
    font_id = 0  # XXX, need to find out how best to get this.

    # draw some text
  
 
    blf.position(font_id, self._x - 10, self._y, 0)
    blf.size(font_id, 20, 72)
    
    blf.color(font_id,1, 1, 1, 1)
        
   
    blf.draw(font_id, str(self.cloak_ob.modifiers["Subdivision"].levels) )
    
    # 50% alpha, 2 pixel width line
   
    bgl.glBegin(bgl.GL_LINE_STRIP)
    for x, y in self.mouse_path:
        
        bgl.glVertex2i(x, y)

    bgl.glEnd()

    # restore opengl defaults
    bgl.glLineWidth(10)
    bgl.glDisable(bgl.GL_BLEND)
    bgl.glColor4f(0.5, 0.5, 1.0, 1.0)

#Brush Draw
def draw_callback_px(self,context):
           
    obj = bpy.data.objects['qcBrush']

    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    color_pos = shader.uniform_from_name("color")
    color = 1.0, 1.0, 1.0, 0.4
    
  
    def get_ob_coords():
        return [obj.matrix_world @ v.co for v in obj.data.vertices]

    bgl.glLineWidth(4)
    bgl.glEnable(bgl.GL_BLEND)
    #bgl.glEnable(bgl.GL_DEPTH_TEST)
    
    shader.bind()
    shader.uniform_vector_float(color_pos, pack("4f", *color), 4)
    batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": get_ob_coords()})
    batch.draw(shader)
  
  
  
#Loop draw
def draw_callback_px2(self,context):
    
    
    shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
    #ob = 
    
    obj = bpy.data.objects["Cloak"]#bpy.context.active_object
    obj.update_from_editmode() #FINALLY LOOP PREHIGHLIGHT!!
    
    deg = bpy.context.view_layer.depsgraph
    me = obj.evaluated_get(deg).to_mesh()
    
    me_data = obj.data
    
    
    bm = bmesh.new()
    bm.from_mesh(me)
    
   
    #kd = mathutils.kdtree.KDTree(len(bm.verts))

    
    verts = [ obj.matrix_world @ v.co for v in bm.verts]
    
   
    gi = obj.vertex_groups["Ring"].index # get group index
   

    
    
    
      # Retrieve vertex group layer
    
    vgl = bm.verts.layers.deform.verify()
    
    selected_verts = len([(v for v in bm.verts) for v in bm.verts if( v.select )])
    
    #vgl = selected_verts.layers.deform.verify()
    
    
    
    
     # Access the layer on the vertex

        #if v_vert_groups:
            
#vgroup = [v for v in bm.verts if v.select]
    
    if bpy.context.scene.cloak_symmetry == True:
        
        value1 = bpy.context.scene.ring_count *2
        value2 = bpy.context.scene.ring_count *4
        
        
    else:
        value1 = bpy.context.scene.ring_count
        
        value2 = bpy.context.scene.ring_count *2
        
        
    edge_indices = [(v.index for v in e.verts) for e in bm.edges if (e.select and selected_verts ==  value1 ) ]

    edge_indices2 = [(v.index for v in e.verts) for e in bm.edges if (e.select and selected_verts == value2  )]
    
    face_colors = ((0.9, 0.25, 0.25, 1.0),) * len(verts)
    edges_colors = ((1.0, 1.0, 1.0, 0.9),) * len(verts)
    bridge_colors = ((0.9, 0.25, 0.25, 1),) * len(verts) 
    
    faces = set(f.index for f in bm.faces) #if f.select)
    face_tri_indices = [[loop.vert.index for loop in looptris]
                        for looptris in bm.calc_loop_triangles()
                        if looptris[1].face]
    
    
    #bgl.glColor4f(1.0, 1.0, 1.0, 0.2)
    bgl.glLineWidth(4)
    
    bgl.glEnable(bgl.GL_DEPTH_TEST)
    bgl.glEnable(bgl.GL_BLEND)
    
    
    bgl.glEnable(bgl.GL_CULL_FACE)

    bgl.glCullFace(bgl.GL_BACK)
    
    
    shader.bind()
   
    
    batch1 = batch_for_shader(
        shader, 'TRIS',
        {"pos": verts, "color": face_colors},
        indices=face_tri_indices)
    

    batch2 = batch_for_shader(
    shader, 'LINES',
    {"pos": verts, "color": edges_colors},
    indices=edge_indices)
    
    batch3 = batch_for_shader(
    shader, 'LINES',
    {"pos": verts, "color": bridge_colors},
    indices=edge_indices2)
    
    batch2.draw(shader)
 
    batch3.draw(shader)

    #batch1.draw(shader)
    
#Outline faces and edges draw
def draw_callback_px3(self,context):
   
    
    shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')
    
    ob = bpy.context.object
    
    obj = bpy.data.objects["Cloak"]#bpy.context.active_object
    
    deg = bpy.context.view_layer.depsgraph
    me = obj.evaluated_get(deg).to_mesh()
    
    bm = bmesh.new()
    bm.from_mesh(me)
                 
    verts = [ obj.matrix_world @ v.co for v in bm.verts]



    face_colors = ((0.1, 0.3, 0.9, 0.3),) * len(verts)
    edges_colors = ((0.4, 0.8, 0.9, 0.5),) * len(verts)

    faces = set(f.index for f in bm.faces) #if f.select)
    
    
    face_tri_indices = [[loop.vert.index for loop in looptris]
                        for looptris in bm.calc_loop_triangles()
                        if looptris[1].face]
                            
   
    #bgl.glEnable(bgl.GL_BLEND)
    #bgl.glColor4f(1.0, 1.0, 1.0, 0.6)
    bgl.glLineWidth(2)
    
    bgl.glEnable(bgl.GL_DEPTH_TEST)
    
    bgl.glEnable(bgl.GL_CULL_FACE)

    #bgl.glCullFace(bgl.GL_BACK)
    
    if 'Cloak' in bpy.data.objects:
        shader.bind()
    else:
        pass

    batch1 = batch_for_shader(
        shader, 'TRIS',
        {"pos": verts,"color": face_colors},
        indices=face_tri_indices)

    edge_indices = [(v.index for v in e.verts) for e in bm.edges ]#if e.select]
    
    batch2 = batch_for_shader(
        shader, 'LINES',
        {"pos": verts, "color": edges_colors},
        indices=edge_indices)
    
    batch1.draw(shader)
    batch2.draw(shader)

#RAYCAST


    



def brush_setup(self,context):
    
    
    ob = bpy.context.active_object
    
    bpy.ops.mesh.primitive_circle_add(vertices=15, radius=1.1, enter_editmode=False)
    
    
    
    bpy.ops.object.modifier_add(type='MASK')

    bpy.context.object.name = "qcBrush"
    brush = bpy.data.objects['qcBrush']
    
    self.brush = brush
    bpy.context.object.show_wire = True
    bpy.context.object.show_all_edges = True
    #bpy.context.object.show_in_front = True

    #bpy.ops.view3d.toggle_xray()
    #self.brush = brush
    
#    bpy.ops.object.modifier_add(type='SUBSURF')
#    bpy.context.object.modifiers["Subdivision"].show_on_cage = True
#    
#    bpy.context.object.modifiers["Subdivision"].levels = 0

#    #bpy.context.object.modifiers["Subdivision"].show_only_control_edges = True
#    
# 

    bpy.ops.object.modifier_add(type='SHRINKWRAP')
    bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[self.og_obj.name]
    bpy.context.object.modifiers["Shrinkwrap"].wrap_method = 'PROJECT'
    bpy.context.object.modifiers["Shrinkwrap"].use_negative_direction = True
    bpy.context.object.modifiers["Shrinkwrap"].show_viewport = True
    

    

    bpy.context.scene.tool_settings.use_snap = True
    bpy.context.scene.tool_settings.snap_elements = {'VOLUME'}
    bpy.context.scene.tool_settings.snap_target = 'CENTER'
    bpy.context.scene.tool_settings.use_mesh_automerge = False

    bpy.context.scene.tool_settings.use_snap_align_rotation = False
    bpy.context.scene.tool_settings.use_snap_self = False


    bpy.ops.object.empty_add(type='SPHERE', radius=0.1)
    bpy.context.object.name = "DIRECTION"

    track_to = bpy.data.objects['DIRECTION']
    
    
    
    bpy.ops.transform.translate(value=(0, 0, 0.5), orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=0.6441, use_proportional_connected=False, use_proportional_projected=False)

  
    bpy.context.view_layer.objects.active = brush



    bpy.ops.object.constraint_add(type='TRACK_TO')
    
    brush.constraints["Track To"].target =bpy.data.objects["DIRECTION"]

    brush.constraints["Track To"].track_axis = 'TRACK_Z'
    brush.constraints["Track To"].up_axis = 'UP_Y'
    

    track_to.select_set(True)

    bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)


    bpy.ops.object.select_all(action='DESELECT')
    
    
    
    bpy.context.view_layer.objects.active = track_to

    track_to.select_set(True)
    

    
    #bpy.ops.object.constraint_add(type='COPY_LOCATION')
    #track_to.constraints["Copy Location"].target = bpy.data.objects["qcBrush"]
    
    
    #track_to.constraints["Copy Location"].influence = 0.5

    bpy.ops.object.constraint_add(type='SHRINKWRAP')
    
    
    track_to.constraints["Shrinkwrap"].wrap_mode = 'INSIDE'
    
    bpy.ops.object.constraint_add(type='LIMIT_DISTANCE')
    track_to.constraints["Limit Distance"].distance = 4

    track_to.constraints["Shrinkwrap"].target = bpy.data.objects[self.og_obj.name]
    track_to.constraints["Limit Distance"].target = bpy.data.objects["qcBrush"]
    
    track_to.hide_viewport = True
    
    
    bpy.context.view_layer.objects.active = ob

    ob.select_set(True)
    

#    ###########################################################################}}


def raycast(context, event):
    
    #obj = bpy.data.objects['DINO']
    
    mxy = event.mouse_region_x, event.mouse_region_y
    region = context.region
    rv3d = context.region_data
    if rv3d:
        vl = context.view_layer
        origin = region_2d_to_origin_3d(region, rv3d, mxy)
        direction = region_2d_to_vector_3d(region, rv3d, mxy)
        
        
        
        
        hit, loc, *_ = context.scene.ray_cast(vl, origin, direction)
        if hit:
            return loc
    
    
    
def raycastbvh(self,context, event):
    
    
##
    origin, direction = self.get_origin_and_direction(event, context)
    
    obj = self.og_obj
    bm = bmesh.new()
    depsgraph = context.evaluated_depsgraph_get()
    ob_eval = obj.evaluated_get(depsgraph)
    
    mesh = ob_eval.to_mesh()
    bm.from_mesh(mesh)
    bm.transform(obj.matrix_world)

    bvhtree = BVHTree.FromBMesh(bm)
    ob_eval.to_mesh_clear()
    
    hit, loc, norm, index = bvhtree.ray_cast(origin, direction)
    ##
    
    
    return hit



     
#QuadCLOAK OPERATOR
class QC_OT_quadcloak(bpy.types.Operator):
    bl_idname = "object.quad_cloak"
    bl_label = "QuadWrap Brush"
    bl_options = {"REGISTER", "UNDO"}
    
    cursor = None
    
    
    # GPU Shader outline for brush
    
    
    # Implement bvh tree method
    
    
#    origin, direction = self.get_origin_and_direction(event, context)

#    self.hit, self.normal, *_ = self.bvhtree.ray_cast(origin, direction)
    
     #Implement##
    

    def invoke(self, context, event):
        
    
          
        self.og_obj = bpy.context.active_object
        
        self.og_name = self.og_obj.name
        
        bpy.context.scene.mirror_obj = self.og_obj.name


        self.mouse_pos = [0,0]
        self.loc = [0,0,0]
        self.object = None
        self.view_point = None
        self.view_vector = None
        self.world_loc = None
        self.loc_on_plane = None
        self.normal = None
        
        bpy.ops.object.editmode_toggle()
        bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
        #bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
        bpy.ops.object.editmode_toggle()

        if bpy.data.objects.get("qcBrush") is not None:
            brush = bpy.data.objects['qcBrush']
            self.brush = brush
            
            
            bpy.context.scene.tool_settings.use_snap = True
            bpy.context.scene.tool_settings.snap_elements = {'VOLUME'}
            bpy.context.scene.tool_settings.snap_target = 'CENTER'
            bpy.context.scene.tool_settings.use_mesh_automerge = False
            
            bpy.context.scene.tool_settings.use_snap_align_rotation = False
            bpy.context.scene.tool_settings.use_snap_self = False

             
            pass
        else:
            
            brush_setup(self,context)
            
            


        self.cursor = cursor_create(context)
       
        #{{Empty constraint track to hack, uncomment this for it to work
        
        #self.track_to_point = bpy.data.objects['DIRECTION']
        
        #####################################################}}
       
        self._timer = context.window_manager.modal_handler_add(self)
        
        self.first_mouse_x = 0#event.mouse_x
            
            
            
        self.lmb = False
        self.mouse_path = []
        
       
        #self.bvhtree = self.bvhtree_from_object(context, self.og_obj)
        
        
        self.start_loc = None
     
        self.active = False
   
        
        self.length = 15
        
        #context.window_manager.modal_handler_add(self)
        args = (self, context)
        
        self.draw_text = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px_text, args, 'WINDOW', 'POST_PIXEL')
        
        #self.draw_text2 = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px_text2, args, 'WINDOW', 'POST_PIXEL')
        
        
        self.mouse_path = []
        self._x = []
        
        self._y = []
        
        if 'Cloak' in bpy.data.objects:
            
            #obj = bpy.data.objects['mfxbrush']
            
            self.cloak_ob = bpy.data.objects['Cloak']

        
        
        self.brush_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args,'WINDOW','POST_VIEW')
        
        
        self.faces_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px3, args, 'WINDOW', 'POST_VIEW')
        self.cloak_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px2, args, 'WINDOW', 'POST_VIEW')
        
        
        
        
        
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_relationship_lines = False

        
        self.world_loc = None
            
        self.radius = None
        
        self._ringcount = 6
       
           
        context.area.tag_redraw()
        
        
        bpy.context.scene.help_panel = '1'
        
        bpy.context.scene.cloak_symmetry = False

        bpy.context.scene.bisect_symmetry = False


        return {'RUNNING_MODAL'}
    

    
    def end(self,context):
        #bpy.types.SpaceView3D
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_text, 'WINDOW')
        #bpy.types.SpaceView3D.draw_handler_remove(self.draw_text2, 'WINDOW')
        
        
        context.space_data.draw_handler_remove(self.cloak_handler, "WINDOW")
        context.space_data.draw_handler_remove(self.faces_handler, "WINDOW")
        context.space_data.draw_handler_remove(self.brush_handler, "WINDOW")
       
        context.area.tag_redraw()
        return {'FINISHED'}

  
    
    
    def get_origin_and_direction(self, event, context):
        region    = context.region
        region_3d = context.space_data.region_3d
        
        mouse_coord = (event.mouse_region_x, event.mouse_region_y)

        origin    = region_2d_to_origin_3d(region, region_3d, mouse_coord)
        
       
        direction = region_2d_to_vector_3d(region, region_3d, mouse_coord)
        
        #origin = origin + direction * 0.1
         
        return origin, direction
    
    
       

    def execute(self, context):
        if context.area.type != 'VIEW_3D':
            print("Must use in a 3d region")
            return {'CANCELLED'}

        self.set_wheel_zoom_state(False)

        #wm = context.window_manager
        #wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self.set_wheel_zoom_state(True)
      
    

    def modal(self, context, event):
        
        ## EDIT MODE PRESELECT HIGHLIGHTING SYSTEM###############
        for region in context.area.regions:
            if(region.x <= event.mouse_x < region.x + region.width  and
               region.y <= event.mouse_y < region.y + region.height and
               region.type in ("TOOLS", "UI", "TOOL_PROPS")):
                
               return {'PASS_THROUGH'}

        
         
        if event.ctrl:
        
            if event.type in {'WHEELUPMOUSE'}:
                    
                    
           
                    
                    
                    self._ringcount = min(8 ,self._ringcount+1)
                    #bpy.context.scene.brush_prox = self._radius
                    
                    
                    
                    
                    x_ = self._ringcount
                    
                    bpy.context.scene.ring_count = x_
                
                    
                    #bpy.context.scene.eevee.volumetric_start = self._radius

                    
                    print("radius: {}".format(self._ringcount))
                    
                    return {'RUNNING_MODAL'}
                
                
            if event.type in {'WHEELDOWNMOUSE'}:
                
                
                
                self._ringcount = max(4,self._ringcount- 1) 
                #bpy.context.scene.brush_prox = self._radius
                x_ = self._ringcount
                
                
                bpy.context.scene.ring_count = x_
                
                print("radius: {}".format(self._ringcount))
                
                
                return {'RUNNING_MODAL'}
        

            
      
        context.area.tag_redraw()
        
        #Text HUD mouse coords
        self._x = event.mouse_region_x
        self._y = event.mouse_region_y
        
        
        
        x = event.mouse_region_x
        y = event.mouse_region_y
        #if self.count == 1:
        loc = event.mouse_region_x, event.mouse_region_y

       ###################################################
        
       # BRUSH SYSTEM (SNAPPING)############3
        
        self.mouse_pos = event.mouse_region_x, event.mouse_region_y
        
    
        # SCENE RAYCAST   
        
        origin, direction = mouse_ray_get(context, event)
    
        
        hit1, location1, normal, index, object, mat =\
        context.scene.ray_cast( context.view_layer, origin = origin, direction= direction)
        
        
        
        if hit1:
            
            hit2, location2, normal, index, object, mat =\
                context.scene.ray_cast(context.view_layer, location1 - 0.001 * normal, -normal)
            
            
            
            if hit2:
                
                self.cursor.location += (location1 + location2) / 2
                
                self.cursor.location /= 2
                
                
                radius = (location1 - location2).length / 2 * 1.2
                
                self.cursor.scale.x = radius
                self.cursor.scale.y = radius
                self.cursor.scale.z = radius
                
                #obj = bpy.data.objects['Cloak']
                
                
                #brush rotation, using constraint hack for now(smoother)
#                o = self.cursor
#                
#                Vect = ( self.snap_point - o.location)
#                o.rotation_euler = Vect.to_track_quat('Z','Y').to_euler()
#                
               
                
                #Snap cursor to volume for stepping
                
                
                
               
                #bpy.context.scene.cursor.location = snap_point
                
      
                                
                if self.lmb:
                    
                    radius = (location1 - location2).length /1.5
                    
                    self.length = radius
                    
                    
                    
                    #bpy.context.scene.cursor.location = self.cursor.location
                   
                    
                
                    pass
                
        
        
        # left mouse is being pressed while moving the mouse

 
        
        ##
        
        if self.active and event.type =='MOUSEMOVE':
            
            
            
            origin, direction = self.get_origin_and_direction(event, context)
        
            obj = self.og_obj
            quads = bpy.data.objects['Cloak']
            
            
            bm = bmesh.new()
            depsgraph = context.evaluated_depsgraph_get()
            ob_eval = quads.evaluated_get(depsgraph)
            
            mesh = ob_eval.to_mesh()
            bm.from_mesh(mesh)
            bm.transform(quads.matrix_world)

            bvhtree = BVHTree.FromBMesh(bm)
            ob_eval.to_mesh_clear()
            
            hit, loc, norm, index = bvhtree.ray_cast(origin, direction)
          
            
            #IGNORE QUAD(Cloak) RAYCAST(avoids extruding explosion)
            
            
            #loop = bpy.data.objects['Cloak'] #using 'quads' for now
                                    
            #ob = bpy.context.object
            
            quads.update_from_editmode()
            me = quads.data
            verts_sel = [v.co for v in me.vertices if v.select]
            pivot = sum(verts_sel, Vector()) / len(verts_sel)
            
            c_location = self.cursor.location#bpy.context.scene.cursor.location
            
            m_location = quads.matrix_world @ pivot

            #get get the offset
            l = c_location - m_location

            #split the tuple
            
            
            x = l[0]
            y = l[1]
            z = l[2]
               
               
               
            if hit:
                pass
            
            else:
                
                if hit1:
                
                    end_loc =  raycast(context, event)
                        
                    end_cursor = self.cursor.location #raycastbvh(self,context,event)

            
                    
                          

                    if self.start_loc and end_cursor:
                        
                        
                    
                    
                        distance = (end_cursor - self.start_loc).length
                        
                        #cursor = bpy.context.scene.cursor.location
                        
                       
                        
                        
                        if distance >= self.length:
                            
                            
                            
                            obj = bpy.data.objects['Cloak']
                                
                                
                                
                            deg = bpy.context.view_layer.depsgraph
                            
                            #With modifiers
                            me = obj.evaluated_get(deg).to_mesh()
                            
                            #Without modifiers
                            me_data = obj.data
                            
                            bm = bmesh.new()
                            bm.from_mesh(me_data)
                            
                            selected_verts = len([v for v in bm.verts if v.select])
                            
                            if selected_verts == bpy.context.scene.ring_count:
                            
                                factor = self.length / distance
                                location = self.start_loc.lerp(end_cursor, factor)
                                
                                self.start_loc = location
                                distance -= self.length
                        
                                
                                # getting a list of select verts (you should have this already)
                                
          
                                
                                bpy.ops.object.mode_set(mode='OBJECT')

                                # getting a list of select verts (you should have this already)
                                obj = bpy.data.objects['Cloak']
                                
                                
                                mesh = obj.data
                                
                                
                                #########################################################
                                #Aligning the loop is now possible. 
                                #Credits to Jon Denning for sharing this snippet!
                                
                                xform = obj.matrix_world.inverted()
                                verts = [v for v in mesh.vertices if v.select]
                                assert len(verts) >= 3, 'must have at least 3 vertices to make this work'

                                # find center of selected verts, although it could be any point!
                                # this will serve as the pivot point
                                center = sum((v.co for v in verts), Vector()) / len(verts)

                                # get cursor location in local space, although it could be any point!
                                # this is what we will orient the normal toward
                                cursor = xform @ self.cursor.location #bpy.context.scene.cursor.location

                                # get direction from pivot point to cursor
                                # ultimately, we want diff and norm to be aligned
                                diff = (cursor - center).normalized()

                                # compute normal
                                # we do this by sampling 3 verts 10x, keeping the estimated
                                # norm that was computed from the verts with greatest cross
                                norm = None
                                for attempt in range(100):
                                    # shuffle verts to get random sampling
                                    random.shuffle(verts)
                                    v0,v1,v2 = verts[:3]
                                    norm_test = (v1.co - v0.co).cross(v2.co - v0.co)
                                    if not norm or norm_test.length > norm.length:
                                        norm = norm_test
                                    
                                norm.normalize()

                                # determine which side cursor is on; might need to flip normal
                                if diff.dot(norm) < 0:
                                    # norm was computed pointing away from diff
                                    # negate norm!
                                    norm = -norm

                                # compute the quaternion representing the rotational difference between norm and diff
                                # we'll use this quat to rotate the points
                                rot_quat = norm.rotation_difference(diff)

                                # apply transformation!
                                #bpy.ops.object.mode_set(mode='OBJECT')
                                
                                
                                for v in verts:
                                    v.co = center + rot_quat @ (v.co - center)
                                
                                bpy.ops.object.mode_set(mode='EDIT')
                            
                            ##########################################################
                                
                                
                                bpy.ops.ed.undo_push() # AVOID UNDO CRASH
                                
                                bpy.ops.mesh.extrude_region('INVOKE_DEFAULT')
                                
                                
                        
                                        

                                bpy.ops.mesh.vertices_smooth(factor=0.1)
                        
                                 
                                
                    
                    
                     # getting a list of select verts (you should have this already)
                    
                            bpy.ops.transform.translate(value=(x, y, z), 
                                                        orient_type='GLOBAL', 
                                                        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
                                                        orient_matrix_type='GLOBAL', 
                                                        mirror=True, 
                                                        use_proportional_edit=False, 
                                                        proportional_edit_falloff='SMOOTH', 
                                                        proportional_size=133.951, 
                                                        use_proportional_connected=True, 
                                                        use_proportional_projected=False)
                            
                            
                            
                                
                            
                            #assign vertex group "Ring"
                            

                            bpy.ops.object.vertex_group_remove_from()
                
                
                ## AUTO ENDCAP FILL
#                if hit1:
#                    pass      

#                else:
#    #                
#    #                
#    #                
#                    if 'Cloak' in bpy.data.objects:
#                        
#                        obj = bpy.data.objects['Cloak']
#                        
#                        
#                        
#                        deg = bpy.context.view_layer.depsgraph
#                        
#                        #With modifiers
#                        me = obj.evaluated_get(deg).to_mesh()
#                        
#                        #Without modifiers
#                        me_data = obj.data
#                        
#                        bm = bmesh.new()
#                        bm.from_mesh(me_data)
#                        
#                        selected_verts = len([v for v in bm.verts if v.select])
#                        
#                        if selected_verts == bpy.context.scene.ring_count:
#                            
#                            # uncomment for auto end cap filling
#                            
#                            bpy.ops.mesh.fill_grid('INVOKE_DEFAULT')
#                           
#                                
#                                #bpy.ops.transform.translate('INVOKE_DEFAULT', release_confirm =True)
#                                
#                                
#                            bpy.ops.transform.translate(value=(x*2, y*2, z*2), 
#                                                        orient_type='GLOBAL', 
#                                                        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
#                                                        orient_matrix_type='GLOBAL', 
#                                                        mirror=True, 
#                                                        use_proportional_edit=False, 
#                                                        proportional_edit_falloff='SMOOTH', 
#                                                        proportional_size=133.951, 
#                                                        use_proportional_connected=True, 
#                                                        use_proportional_projected=False)
#        
#                   ##
            return {'RUNNING_MODAL'}
            
        
        if event.type == 'MOUSEMOVE':
            
            
            if bpy.context.object.mode == 'EDIT':
                pass
            else:
                
                
                
                delta = self.first_mouse_x - event.mouse_x
          
                index =  delta * 0.01 %  4
                
                if event.ctrl:
                    mesh = bpy.context.object
                    
                    for mod in mesh.modifiers:
                        if mod.type == 'SUBSURF':
                            bpy.context.object.modifiers["Subdivision"].levels = -index %3
                            
                    if 'Cloak' in bpy.data.objects:
            
                        #obj = bpy.data.objects['mfxbrush']
                        self.cloak_ob = bpy.data.objects['Cloak']
                else:
                    pass
                
            if bpy.context.object.mode == 'EDIT':
                

                if event.shift:
                    
                    bpy.ops.view3d.select(extend=True, center=True, deselect=False,location= loc)
                        
                    bpy.ops.mesh.loop_multi_select(ring=False)
                
                else:
                    
                    if self.lmb:
                       
                      
                        if 'Cloak' in bpy.data.objects:
                    
                            obj = bpy.data.objects['Cloak']
                            deg = bpy.context.view_layer.depsgraph
                            me = obj.evaluated_get(deg).to_mesh()
                            
                            bm = bmesh.new()
                            bm.from_mesh(me)
                            
                            selected_verts = len([v for v in bm.verts if v.select])
                            
                            if selected_verts == 8:
                                #bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
                                pass
                            else:
                                #bpy.ops.mesh.select_all(action='DESELECT')
                                pass
                    
                                #bpy.ops.wm.tool_set_by_id(name="builtin.select_box")

            
                            #bpy.ops.view3d.select(extend=False, center=True, deselect=True,location= loc)
                
                                
                    else:
                        
                        bpy.ops.mesh.select_mode(type="EDGE")
                        #bpy.ops.mesh.select_mode(type="VERT")
                       
                        bpy.ops.view3d.select(extend=False, center=True, deselect=False,location= loc)
                            
                            
                        bpy.ops.mesh.loop_multi_select(ring=False)

    
                      
        if event.type == 'LEFTMOUSE':
            

            
            #bpy.ops.wm.tool_set_by_id(name="builtin.select_box")

            
            
            
            self.lmb = event.value =='PRESS'
            
            if event.value == 'PRESS':
                
                brush = bpy.data.objects['qcBrush']
                
                brush.select_set == True
                
                if bpy.context.object.mode == 'OBJECT':
                    
                    brush = bpy.data.objects['qcBrush']
                    
                    #obname = bpy.context.active_object.name
                    ##COMMENT THESE FOR LOOP MODE TO WORK########################
                    brush = self.brush
                    bpy.ops.object.select_all(action='DESELECT')
                    context.view_layer.objects.active = brush
                    brush.select_set(True)      
                    ###########################################################
                    
                    
                    ##LEAVE THESE UNCOMMENTED FOR LOOP MODE######
                    ob = bpy.context.active_object
                    
                    
                    #DUPLICATE OR...
                    
#                    bpy.ops.object.duplicate('INVOKE_DEFAULT')
#                    bpy.context.object.name = "Cloak"
#                    bpy.ops.object.modifier_remove(modifier="Mask")


#                    bpy.ops.object.editmode_toggle()
#                    
#                    bpy.ops.mesh.unsubdivide(iterations=1)
#                    
#                    bpy.ops.object.editmode_toggle()


#                    
#                    bpy.context.object.modifiers["Subdivision"].levels = 1
#                    bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True
#                    
#                    bpy.ops.object.visual_transform_apply()
#                    
#              
#                    bpy.context.object.modifiers["Shrinkwrap"].show_viewport = True

                    #bpy.context.object.constraints["Track To"].mute = True
                    
                    
                    
                    
                    #...ADD CIRCLE INSTEAD
                    
                    
                     
                    bpy.ops.mesh.primitive_circle_add(vertices=bpy.context.scene.ring_count, radius=0.9, location = self.cursor.location, enter_editmode=False)
                    
                    
                    bpy.context.object.name = "Cloak"
                    
                    bpy.data.objects['Cloak'].matrix_world = bpy.data.objects['qcBrush'].matrix_world
                    
                    bpy.context.object.show_wire = True
                    bpy.context.object.show_all_edges = True
                    bpy.context.object.show_in_front = True

                    #bpy.ops.view3d.toggle_xray()
                    self.cloak_ob = bpy.data.objects['Cloak']
                    
                    
                    
                    



                    bpy.ops.object.modifier_add(type='SMOOTH')
                    bpy.context.object.modifiers["Smooth"].show_in_editmode = True
                    bpy.context.object.modifiers["Smooth"].show_on_cage = True
                    bpy.context.object.modifiers["Smooth"].factor = 0
                    bpy.context.object.modifiers["Smooth"].iterations = 1


                    bpy.ops.object.modifier_add(type='SUBSURF')
                    bpy.context.object.modifiers["Subdivision"].show_on_cage = True
                    bpy.context.object.modifiers["Subdivision"].levels = 0

                    bpy.context.object.modifiers["Subdivision"].show_only_control_edges = False
                    
                 

                    bpy.ops.object.modifier_add(type='SHRINKWRAP')
                    bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects[self.og_obj.name]
                    bpy.context.object.modifiers["Shrinkwrap"].wrap_method = 'PROJECT'
                    bpy.context.object.modifiers["Shrinkwrap"].use_negative_direction = True
                    bpy.context.object.modifiers["Shrinkwrap"].show_viewport = True
                    bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True

        
                    #bpy.ops.mesh.unsubdivide(iterations=1)
                   

                    
#                    
               
                    ##COMMENT THESE FOR LOOP MODE TO WORK######################
                    bpy.ops.object.editmode_toggle()
                    
                    
                    group = bpy.context.object.vertex_groups.new()
                    group.name = "Ring"
                    #group.add(bpy.data.objects.data.verts, 1.0, 'ADD')
                    bpy.ops.object.vertex_group_assign()


                    #bpy.ops.mesh.extrude_context_move('INVOKE_DEFAULT')
                    
                    #bpy.ops.transform.translate('INVOKE_DEFAULT')
                    
                    
                    #bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
                    
                
                else:
                    
                    origin, direction = self.get_origin_and_direction(event, context)
            
                    obj = self.og_obj
                    quads = bpy.data.objects['Cloak']
                    
                    
                    bm = bmesh.new()
                    depsgraph = context.evaluated_depsgraph_get()
                    ob_eval = quads.evaluated_get(depsgraph)
                    
                    mesh = ob_eval.to_mesh()
                    bm.from_mesh(mesh)
                    bm.transform(quads.matrix_world)

                    bvhtree = BVHTree.FromBMesh(bm)
                    ob_eval.to_mesh_clear()
                    
                    hit, loc, norm, index = bvhtree.ray_cast(origin, direction)
                    
                    
                    if hit:
                        pass
                    
                    else:
                        if hit1:
                            obj = bpy.data.objects['Cloak']
                                
                                
                                
                            deg = bpy.context.view_layer.depsgraph
                            
                            #With modifiers
                            me = obj.evaluated_get(deg).to_mesh()
                            
                            #Without modifiers
                            me_data = obj.data
                            
                            bm = bmesh.new()
                            bm.from_mesh(me_data)
                            
                            selected_verts = len([v for v in bm.verts if v.select])
                            
                            if selected_verts == bpy.context.scene.ring_count:
                        
          
                                bpy.ops.object.mode_set(mode='OBJECT')

                                # getting a list of select verts (you should have this already)
                                obj = bpy.data.objects['Cloak']
                                
                                
                                mesh = obj.data
                                
                                
                                #########################################################
                                #Aligning the loop is now possible. 
                                #Credits to Jon Denning for sharing this snippet!
                                
                                xform = obj.matrix_world.inverted()
                                verts = [v for v in mesh.vertices if v.select]
                                assert len(verts) >= 3, 'must have at least 3 vertices to make this work'

                                # find center of selected verts, although it could be any point!
                                # this will serve as the pivot point
                                center = sum((v.co for v in verts), Vector()) / len(verts)

                                # get cursor location in local space, although it could be any point!
                                # this is what we will orient the normal toward
                                cursor = xform @ self.cursor.location #bpy.context.scene.cursor.location

                                # get direction from pivot point to cursor
                                # ultimately, we want diff and norm to be aligned
                                diff = (cursor - center).normalized()

                                # compute normal
                                # we do this by sampling 3 verts 10x, keeping the estimated
                                # norm that was computed from the verts with greatest cross
                                norm = None
                                for attempt in range(100):
                                    # shuffle verts to get random sampling
                                    random.shuffle(verts)
                                    v0,v1,v2 = verts[:3]
                                    norm_test = (v1.co - v0.co).cross(v2.co - v0.co)
                                    if not norm or norm_test.length > norm.length:
                                        norm = norm_test
                                    
                                norm.normalize()

                                # determine which side cursor is on; might need to flip normal
                                if diff.dot(norm) < 0:
                                    # norm was computed pointing away from diff
                                    # negate norm!
                                    norm = -norm

                                # compute the quaternion representing the rotational difference between norm and diff
                                # we'll use this quat to rotate the points
                                rot_quat = norm.rotation_difference(diff)

                                # apply transformation!
                                #bpy.ops.object.mode_set(mode='OBJECT')
                                
                                
                                for v in verts:
                                    v.co = center + rot_quat @ (v.co - center)
                                    
                                
                                ##########################################################
                                
                                
                                bpy.ops.object.mode_set(mode='EDIT')
                                
                            
                            bpy.ops.ed.undo_push()
                            
                            bpy.ops.mesh.dupli_extrude_cursor('INVOKE_DEFAULT',rotate_source=True)
                            
                            loop = bpy.data.objects['Cloak']
                                        
                            #ob = bpy.context.object
                            
                            loop.update_from_editmode()
                            me = loop.data
                            verts_sel = [v.co for v in me.vertices if v.select]
                            pivot = sum(verts_sel, Vector()) / len(verts_sel)
                            
                            c_location = self.cursor.location#bpy.context.scene.cursor.location
                            
                            m_location = loop.matrix_world @ pivot

                            #get get the offset
                            l = c_location - m_location

                            #split the tuple
                            
                            
                            x = l[0]
                            y = l[1]
                            z = l[2]
                   
                           
                           
                            bpy.ops.transform.translate(value=(x, y, z), 
                                                        orient_type='GLOBAL', 
                                                        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
                                                        orient_matrix_type='GLOBAL', 
                                                        mirror=True, 
                                                        use_proportional_edit=False, 
                                                        proportional_edit_falloff='SMOOTH', 
                                                        proportional_size=133.951, 
                                                        use_proportional_connected=True, 
                                                        use_proportional_projected=False)
                                        
             
                        
                    #bpy.ops.view3d.snap_selected_to_cursor()
                                   
                    #bpy.ops.mesh.vertices_smooth(factor=-0.05)


                    #bpy.ops.mesh.extrude_context_move('INVOKE_DEFAULT')
                    #bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "mirror":False}, TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'GLOBAL', "orient_matrix":((1, 0, 0), (0, 1, 0), (0, 0, 1)), "orient_matrix_type":'GLOBAL', "constraint_axis":(False, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":0.300477, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":True, "use_accurate":False})

                    #bpy.ops.transform.translate('INVOKE_DEFAULT')
                    
                    rc_status = False #Release Confirm Status
                    
                    
                    #bpy.ops.transform.translate(orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', mirror=True, use_proportional_edit=True, proportional_edit_falloff='SMOOTH', proportional_size=0.300477, use_proportional_connected=False, use_proportional_projected=False, release_confirm= rc_status)

            
#                    if 'Cloak' in bpy.data.objects:
#                
#                        obj = bpy.data.objects['Cloak']
#                        deg = bpy.context.view_layer.depsgraph
#                        me = obj.evaluated_get(deg).to_mesh()
#                        
#                        bm = bmesh.new()
#                        bm.from_mesh(me)
#                        
#                        selected_verts = len([v for v in bm.verts if v.select])
#                        
#                        if selected_verts == 8:
#                            bpy.ops.mesh.extrude_context_move('INVOKE_DEFAULT')
                            
                      
            
            elif event.value == 'RELEASE':
                
                
                # Auto Merge closed 
                #bpy.ops.object.vertex_group_select()


                #bpy.ops.mesh.bridge_edge_loops(use_merge=True)


                #bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
                
                #bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
                
                #bpy.ops.object.editmode_toggle()
                
                pass
                    
                    ## TWO MODES: LOOP MODE & WRAP MODE FOR QUADCLOAK (STILL NEED TO CREATE ENUM LIST FOR MODES###########
                    
                    ###########################################################
                    
                    
                    #return self.end(context)
                    
                    ##UNCOMMENT THESE FOR LOOP MODE#############
                    #ob.select_set(True)
                    
                    
                    #context.view_layer.objects.active = ob
                    
                    #dupli.select_set(True)
                    
                    ################################################
                    
                    #bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                    
                    #ob.select_set(False)
                    
                    #bpy.context.selected_objects[0].select_set(True)
               
           
#                    if bpy.context.scene.tool_mode == '0':
#                    
#                        bpy.ops.mesh.select_all(action='SELECT')

#                        bpy.ops.mesh.remove_doubles(threshold=2)
#                    pass
                
                

        if event.type == 'LEFTMOUSE':
            
            if not self.active:
            
                
            
                self.start_loc = raycastbvh(self,context, event)#raycast(context, event)
                
                if self.start_loc:  
                    #self.add_empty(context, self.start_loc)
                    pass
            self.active = event.value == 'PRESS'
            
            
            return {'PASS_THROUGH'}
                                
            #return {"RUNNING_MODAL"}
        if event.type == 'LEFT_SHIFT':
            bpy.ops.ed.undo_push()
            
            if event.value == 'PRESS':
                #
                
                
                pass
            
            elif event.value == 'RELEASE':
                
                #Loop Bridger
                
               
                if 'Cloak' in bpy.data.objects:
                        
                    obj = bpy.data.objects['Cloak']
                    deg = bpy.context.view_layer.depsgraph
                    me = obj.evaluated_get(deg).to_mesh()
                    
                    me_data = obj.data
                    
                    bm = bmesh.new()
                    bm.from_mesh(me_data)
                    
                    selected_verts = len([v for v in bm.verts if v.select])
                    
                    if selected_verts == bpy.context.scene.ring_count *2:
                        
                        if bpy.context.object.mode == 'EDIT':
                            
                            bcuts = bpy.context.scene.cloak_bridge_cut
                            
                            if bpy.context.scene.cloak_bridge_merge == True:
                                merge_status = True
                            else:
                                merge_status = False
                                
                                
                            try:
                                
                                
                                bpy.ops.mesh.bridge_edge_loops(merge_factor=0.5, use_merge = merge_status, twist_offset=0, number_cuts= bcuts)
                            
                            
                            except RuntimeError as ex:
                                error_report = "\n".join(ex.args)
                                print("Caught error:", error_report)
    
                
                            
                            
                        else:
                            pass
                        
                        
                        
                                
                else:
                    pass
                
                
       
         
        
        if event.type == 'G':
            
            bpy.ops.ed.undo_push()
            
            if event.value == 'PRESS':
                  #bpy.ops.object.editmode_toggle()
                
                if bpy.context.object.mode == 'EDIT':
                    #if 'Cloak' in bpy.data.objects:
                    
                    obj = bpy.context.object#bpy.data.objects['Cloak']
                    
                    deg = bpy.context.view_layer.depsgraph
                    me = obj.evaluated_get(deg).to_mesh()
                    
                    me_data = obj.data
                    
                    bm = bmesh.new()
                    bm.from_mesh(me_data)
                    
                    selected_verts = len([v for v in bm.verts if v.select])
                    
                    if selected_verts == bpy.context.scene.ring_count:
                         bpy.ops.transform.translate('INVOKE_DEFAULT')
                    #else:
                   #     pass
                   
                else:
                        
                    
                    pass
                #bpy.ops.ed.undo('INVOKE_DEFAULT')
                
            elif event.value == 'RELEASE':
                pass
            
            
            return {"RUNNING_MODAL"}

                    
                    
        ##WRAP MODE
        if event.type == 'RIGHTMOUSE':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
               
                    
                try:
                    #bpy.ops.mesh.delete(type='VERT')
                    bpy.ops.object.editmode_toggle()
                    ob = bpy.context.object
                    ob.name = "Quads"

                except RuntimeError as ex:
                    error_report = "\n".join(ex.args)
                    print("Caught error:", error_report)

            
                #bpy.ops.mesh.delete(type='VERT')

                
                context.area.tag_redraw()
                if bpy.data.objects['qcBrush']:
                    bpy.ops.object.modifier_remove(modifier="Mask")


            return {"RUNNING_MODAL"}
        
       
             
        if event.type == 'A':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                
                

                
                #return self.end(context)
                
                ob = bpy.context.object
                #bpy.ops.object.editmode_toggle()
                
                if bpy.context.object.mode == 'EDIT':
                    
                    bpy.ops.object.mode_set(mode='OBJECT')
                else:
                    pass
                
                bpy.context.object.show_in_front = True
                
                bpy.ops.object.convert(target='MESH')
                

#                for mod in ob.modifiers:
#                    if mod.type == 'SUBSURF':
#                        
#                        
#                        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Subdivision")
#                
#                    else:
#                        pass
#                    
#                for mod in ob.modifiers:
#                    if mod.type == 'SHRINKWRAP':
#                        
#                        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Shrinkwrap")

#                    else:
#                        pass
#                
                
                

                ob.name = "Quads"
                
                
                
                bpy.ops.object.select_all(action='DESELECT')
                
                
                objects = bpy.data.objects
                
                myListX = fnmatch.filter( [objects [i].name for i in range(len(objects ))] , 'Quads*')

                for item in myListX:
                    bpy.data.objects[item].select_set(True)

                selected = bpy.context.selected_objects
                
                bpy.ops.object.join()
                bpy.context.object.show_in_front = True
                bpy.context.object.show_all_edges = True
                bpy.context.object.show_wire = True

                
                
                bpy.ops.object.editmode_toggle()

                bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
                
                bpy.ops.object.editmode_toggle()
                
                ob = bpy.context.object
                ob.name = "Quads"
                
                ob.select_set(True)
                bpy.ops.object.select_all(action='DESELECT')

                #bpy.context.view_layer.objects.active = self.og_obj

                #self.og_obj.select_set(True)
    
    
#                bpy.ops.object.modifier_add(type='CLOTH')
#                bpy.context.object.modifiers["Cloth"].settings.quality = 4
#                bpy.context.object.modifiers["Cloth"].settings.mass = 5


#                bpy.ops.screen.animation_play()
                #bpy.context.view_layer.objects.active = current_obj
                
                bpy.context.scene.cloak_symmetry = False

                bpy.context.scene.bisect_symmetry = False


                
                
            return {"RUNNING_MODAL"}
        
       
        
        if event.type == 'X':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                #bpy.ops.object.editmode_toggle()
                
                if bpy.context.object.mode == 'EDIT':
                    #if 'Cloak' in bpy.data.objects:
                    
                    obj = bpy.context.object#bpy.data.objects['Cloak']
                    deg = bpy.context.view_layer.depsgraph
                    me = obj.evaluated_get(deg).to_mesh()
                    
                    me_data = obj.data
                    
                    bm = bmesh.new()
                    
                    
                    bm.from_mesh(me_data)
                    
                    selected_verts = len([v for v in bm.verts if v.select])
                    
                    if selected_verts == bpy.context.scene.ring_count:
                         bpy.ops.mesh.delete(type='VERT')
#                    else:
#                        pass
                   
                else:
                        
                    
                    
                    ob = bpy.context.active_object
                    objs = bpy.data.objects
                    objs.remove(objs[ob.name], do_unlink=True)
                    
                    context.view_layer.objects.active = bpy.data.objects['qcBrush']
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')

                    bpy.context.view_layer.objects.active = self.og_obj

                    self.og_obj.select_set(True)
        
    
                #bpy.ops.ed.undo('INVOKE_DEFAULT')
                
            
            
            return {"RUNNING_MODAL"}
        
        if event.type == 'F':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                if bpy.context.object.mode == 'EDIT':
                    if 'Cloak' in bpy.data.objects:
                    
                        obj = bpy.data.objects['Cloak']
                        deg = bpy.context.view_layer.depsgraph
                        me = obj.evaluated_get(deg).to_mesh()
                        
                        me_data = obj.data
                        
                        bm = bmesh.new()
                        bm.from_mesh(me_data)
                        
                        selected_verts = len([v for v in bm.verts if v.select])
                        
                        if selected_verts == bpy.context.scene.ring_count:
                            
                            bpy.ops.ed.undo_push()
                            
                            bpy.ops.mesh.fill_grid(span=2)
                            bpy.ops.transform.translate('INVOKE_DEFAULT')
                        else:
                            pass
                        
                        
            return {"RUNNING_MODAL"}
        
        if event.type == 'Z':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                
                bpy.ops.ed.undo()
                
            
            
            return {"RUNNING_MODAL"}
        
        if event.type == 'W':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                
                bpy.ops.mesh.subdivide(number_cuts=1, smoothness=1)

            
            
            return {"RUNNING_MODAL"}
        
        if event.type == 'B':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                
                #bpy.ops.object.editmode_toggle()
                #bpy.ops.mesh.bridge_edge_loops('INVOKE_DEFAULT')
                #bpy.ops.object.editmode_toggle()
            
                pass
            
            return {"RUNNING_MODAL"}
        

            
                    #context.view_layer.objects.active = bpy.context.selected_objects[0]
                    
                    
                    #APPLY VISUAL TRANSFORM FOR CONSTRAINTS
                    
                    
#                    bpy.ops.object.modifier_add(type='SHRINKWRAP')
#                    bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects["Demon"]
#                    bpy.context.object.modifiers["Shrinkwrap"].show_on_cage = True


                    


#                    bpy.ops.object.editmode_toggle()
#                    bpy.ops.mesh.select_all(action='SELECT')

#                    bpy.ops.wm.tool_set_by_id(name="builtin.extrude_to_cursor")
                
            return {"PASS_THROUGH"}
        
        
         ## SPACE EVENT FOR LOOP MODE ONLY ( LOOP MODE IS WHERE YOU ADD CIRCLES AT A TIME AND PRESS SPACE TO BRIDGE LOOPS)
        if event.type == 'SPACE':
            if event.value == 'PRESS':
                pass
            elif event.value == 'RELEASE':
                
                ob = bpy.context.active_object
                ob.select_set(False)
                context.view_layer.objects.active = bpy.context.selected_objects[1]
                
                bpy.ops.object.join()

                bpy.ops.object.editmode_toggle()
                bpy.ops.mesh.bridge_edge_loops()
                bpy.ops.object.editmode_toggle()
                
                bpy.ops.object.modifier_remove(modifier="Subdivision")

                bpy.ops.object.modifier_add(type='SUBSURF')
                bpy.ops.object.modifier_add(type='SHRINKWRAP')
                bpy.context.object.modifiers["Shrinkwrap"].target = bpy.data.objects["Hand"]
                bpy.context.object.modifiers["Shrinkwrap"].wrap_method = 'PROJECT'
                bpy.context.object.modifiers["Shrinkwrap"].use_negative_direction = True
                
                 
                bpy.ops.object.modifier_add(type='SUBSURF')
                
                
                bpy.context.object.show_wire = True
                bpy.context.object.show_all_edges = True

                
                bpy.ops.object.visual_transform_apply()
                context.view_layer.objects.active = bpy.data.objects['Circle']
                
                bpy.ops.object.select_all(action='DESELECT')
                ob.select_set(True)


            return {"RUNNING_MODAL"}
        
        if event.type == "ESC":
            
            #uncomment once gpu shader works without it being run on Invoke
            
            bpy.context.scene.help_panel = '0'

            bpy.context.scene.tool_settings.use_snap = False
            bpy.context.space_data.overlay.show_cursor = True
            bpy.context.space_data.overlay.show_relationship_lines = True



            if 'qcBrush' in bpy.data.objects:
            
                #obj = bpy.data.objects['mfxbrush']
                objs = bpy.data.objects
                objs.remove(objs["qcBrush"], do_unlink=True)
            else:
                pass
            
            
            if 'DIRECTION' in bpy.data.objects:
            
                #obj = bpy.data.objects['mfxbrush']
                objs = bpy.data.objects
                
                track_to = bpy.data.objects['DIRECTION']
                track_to.hide_viewport = False
            
            
                objs.remove(objs['DIRECTION'], do_unlink=True)
                
                
            else:
                pass
            
            return self.end(context)
            context.view_layer.objects.active = self.og_obj
            self.og_obj.select_set(True)
            
            #return {"CANCELLED"}
            #end(self,context)
            
         
        
        
        return {"PASS_THROUGH"}
    



    
class RM_OT_relaxmethod(bpy.types.Operator):
    """Relax remesh object."""
    
    bl_idname = "object.remesh_relax"
    bl_label = "Remesh Relax"
    bl_options = {'REGISTER', 'UNDO'}
    
    
    
    def execute(self, context):
        
        
        
        
        bm = bmesh.new()
        bm.from_mesh(bpy.data.objects['Quads'].data)
        
        strength = bpy.context.scene.relax_strength
        tot = 50
        
        
        
        wm = bpy.context.window_manager
        for i in range(strength):
            wm.progress_begin(0, tot)
            for i in range(tot):
                wm.progress_update(i)
            
            for vert in bm.verts:
                avg = Vector()
                for edge in vert.link_edges:
                    other = edge.other_vert(vert)
                    avg += other.co
                avg /= len(vert.link_edges)
                avg -= vert.co
                avg -= avg.dot(vert.normal) * vert.normal
                vert.co += avg 
        
        bm.normal_update()
        wm.progress_end()
        
     
        bm.to_mesh(bpy.data.objects['Quads'].data)
        
        
        
        bpy.data.objects['Quads'].data.update()
        
        bpy.context.view_layer.update()
        


        return {'FINISHED'}

bpy.types.Scene.relax_strength = bpy.props.IntProperty(min = 1, max = 50, default = 20, description="Relax strength value", update=None)




def symmetry_update(self,context):
    
    cloak = bpy.data.objects['Cloak']
#    
#    #Add Mirror modifier
#    symmetry = cloak.modifiers.new(name="Symmetry", type='MIRROR')
#    
#    

    if bpy.context.scene.cloak_symmetry:
        
        target = bpy.context.scene.mirror_obj
        bpy.ops.object.modifier_add(type='MIRROR')
        cloak.modifiers["Mirror"].mirror_object = bpy.data.objects[target]
        
        
        bpy.ops.object.modifier_move_up(modifier="Mirror")
        bpy.ops.object.modifier_move_up(modifier="Mirror")
        bpy.ops.object.modifier_move_up(modifier="Mirror")
        bpy.ops.object.modifier_move_up(modifier="Mirror")

    else:
        
        bpy.ops.object.modifier_remove(modifier="Mirror")
    
    
    
    
    
    
    
    
    
def bisect_update(self,context):
    
    if bpy.context.scene.bisect_symmetry:
        
        bpy.context.object.modifiers["Mirror"].use_bisect_axis[0] = True
        
    else:
        
        bpy.context.object.modifiers["Mirror"].use_bisect_axis[0] = False

    
bpy.types.Scene.cloak_symmetry = bpy.props.BoolProperty(name="cloak_symmetry", default=False, description = "Enable Symmetry for this Cloak.", update = symmetry_update)
bpy.types.Scene.bisect_symmetry = bpy.props.BoolProperty(name="bisect_symmetry", default=False, description = "Enable Bisect for Symmetry.", update = bisect_update)
    

class QX_PT_panel(bpy.types.Panel):

    bl_category = "Retopology"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    #bl_context = "editmode"
    bl_label = "QuadWrap Retopology v1"
    
    
    def draw(self,context):
        
        layout = self.layout
        scene = bpy.context.scene
        
        
        #row.prop(context.scene, "help_panel",text="Subdivisions:")
        
        #row.operator("object.quad_wrap",text="QuadWrap",icon = 'MESH_GRID')
        #row.operator("object.quad_belt",text="QuadBelt",icon = 'TRACKING')
        
        
            
        if bpy.context.scene.help_panel == '1':
            
            ob = bpy.context.object
            layout = self.layout
            row = layout.row(align= True)
            #row.prop(context.scene, "mirror_obj",text="MirrorOBJ")
            
            if ob.name == 'Cloak':
                pass
            else:
                
                row.prop(context.scene, "ring_count",text="Vertices:")
                
                #row.prop(context.scene, "cloak_subd",text="Subdivisions:")
            
            
            quads = bpy.context.object#bpy.data.objects['Cloak']
            
            row = layout.row(align= True)
            
            for mod in quads.modifiers:
                    
                #row = row.row(align=True)
                
               
                if mod.type == 'SUBSURF':
                    
                    row.prop(mod, "levels", text= "Subdivisions:")
                    
            row = layout.row(align= True)
            
            
            if bpy.context.object.name == "Cloak":
                
                
                row.prop(context.scene, "cloak_symmetry",text="Symmetry")
                
                row.prop(context.scene, "bisect_symmetry",text="Bisect")
                
                
            row = layout.row(align= True)
            
            
            row.label(text= "Bridge Options:")
            row = layout.row(align= True)
            
            row.prop(context.scene, "cloak_bridge_merge",text="Merge")
            
            if bpy.context.scene.cloak_bridge_merge == False:
                  
                row.prop(context.scene, "cloak_bridge_cut",text="Bridge cuts:")
            
            
            
            row = layout.row(align= True)
            #row.prop(context.scene, "relax_strength",text="Relax Strength", slider=True)
            #row.operator("object.remesh_relax",text="Relax",icon = 'MESH_GRID')
            #row.scale_y = 1.1
            
            
            #HOTKEY HELP#########
            layout.label(text= "Quad Cloak:", icon = 'ONIONSKIN_ON')
            layout.label(text= "Hotkeys:")
            
            layout.label(text= "Cick & Drag = Draw Extrude Rings")
            if 'Cloak' in bpy.data.objects:
                layout.label(text= "LMB = Extrude to cursor")
            else:
                
                
                layout.label(text= "LMB = Add Ring")
            
            layout.label(text= "RMB = New Cloak.")
            if bpy.context.object.mode == 'EDIT':
                text = "X = Delete active ring."
            else:
                text = "X = Reset."
                
            layout.label(text= "SHIFT(Hold) = Bridge active rings.")
            layout.label(text= "G = Move Active Ring")
            layout.label(text= "RR = Twist Ring.")
            
            layout.label(text= "F = Fill End Caps.")
            layout.label(text= "A = Apply Quads.")
            
            
            layout.label(text= "Z = Undo.")
                
            layout.label(text= text)
            
            layout.label(text= "ESC = Exit.")
            layout.scale_y = 1.5
            
        else:
            
            row = layout.column(align= True)
            row.operator("object.quad_cloak",text="Start QuadWrap",icon = 'ONIONSKIN_ON')
            row.scale_y = 1.5
        
    
classes = ( QC_OT_quadcloak,QX_PT_panel)

def register():
    #bpy.utils.register_module(__name__)
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
        
        
    bpy.types.Scene.ring_count = bpy.props.IntProperty(min = 4, max = 10,name="ring_count", default=4)
    bpy.types.Scene.cloak_symmetry = bpy.props.BoolProperty(name="cloak_symmetry", default=False, description = "Enable Symmetry for this Cloak.", update = symmetry_update)
    
    bpy.types.Scene.mirror_obj = bpy.props.StringProperty(name="")
    
    bpy.types.Scene.bisect_symmetry = bpy.props.BoolProperty(name="bisect_symmetry", default=False, description = "Enable Bisect for Symmetry.", update = bisect_update)
    
    
    bpy.types.Scene.cloak_subd = bpy.props.IntProperty(min = 0, max = 4,name="cloak_subd", default=1)
    bpy.types.Scene.cloak_bridge_cut = bpy.props.IntProperty(min = 2, max = 10,name="cloak_bridge_cut", default=2)
    
    bpy.types.Scene.cloak_bridge_merge = bpy.props.BoolProperty(name="cb_merge", default=False, description = "Merge")
    
    bpy.types.Scene.relax_strength = bpy.props.IntProperty(min = 1, max = 50, default = 20, description="Relax strength value", update=None)
    
    bpy.types.Scene.help_panel = bpy.props.EnumProperty(
    name="Modes",
    description="Help Panel. Hotkey shortcuts.",
    
    items=[("0","0","0",'',0),
           
           ("1","1","1",'',1)
      
          
           
          ],
          default= '0',
          update= None
            
          #options= {'ENUM_FLAG'},
          )
    
def unregister():
    #bpy.utils.unregister_module(__name__)
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()

