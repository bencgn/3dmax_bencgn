"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
"""

import bpy
import time
import json
from bpy import context
from bpy.props import StringProperty
from mathutils import Vector

def identify_moved_vertices(base_positions, adjusted_positions):
    moved_vertices = [i for i, pos in enumerate(base_positions) if not (pos - adjusted_positions[i]).length < 1e-5]
    return moved_vertices



def determine_starting_position_for_adjustment(obj, idx, target_position, base_positions, additional_groups=None):
    base_position = base_positions[idx]

    combined_position, combined_weights = measure_combined_influences(obj, idx, additional_groups)

    distance_from_base = (target_position - base_position).length
    distance_from_combined = (target_position - combined_position).length

    if distance_from_combined < distance_from_base:
        starting_position = combined_position
        starting_weights = combined_weights
    else:
        starting_position = base_position
        starting_weights = {obj.vertex_groups[group.group].name: group.weight for group in obj.data.vertices[idx].groups}

    return starting_position, starting_weights

def calculate_weight_adjustment(obj, idx, target_position, diff_vec, max_movements, learning_rate, additional_groups=None):
    vertex = obj.data.vertices[idx]
    vertex_groups = {obj.vertex_groups[group.group].name: group.weight for group in vertex.groups if obj.vertex_groups[group.group].name in max_movements}

    if additional_groups:
        for add_group_name in additional_groups:
            if add_group_name not in vertex_groups and add_group_name in max_movements:
                vertex_groups[add_group_name] = 0.0

    for vg_name, vg_weight in vertex_groups.items():

        vg = obj.vertex_groups[vg_name]
        max_movement = max_movements[vg.name]

        epsilon = 1e-8
        if max_movement.length_squared > epsilon:
            dot_product = diff_vec.dot(max_movement)
            length_squared = max_movement.length_squared
            gradient = dot_product / length_squared
            unclamped_weight_change = learning_rate * gradient
        else:
            continue

        weight_change = max(min(unclamped_weight_change, 1), -1)
        new_weight = vg_weight + weight_change
        new_weight = max(0, min(new_weight, 1))

        vg.add([idx], new_weight, 'REPLACE')

    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(dg)
    mesh = eval_obj.to_mesh()
    new_pos = mesh.vertices[idx].co.copy()
    eval_obj.to_mesh_clear()



def get_vertex_position_in_pose(obj, vertex_index, moved_vertices):
    bpy.ops.object.mode_set(mode='OBJECT')
    
    if vertex_index not in moved_vertices:
        return obj.data.vertices[vertex_index].co.copy()
    
    armature_modifiers = [mod for mod in obj.modifiers if mod.type == 'ARMATURE' and mod.show_viewport]
    if not armature_modifiers:
        return None
    
    dg = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(dg)
    
    mesh = eval_obj.data
    
    vertex_position = mesh.vertices[vertex_index].co.copy()
    
    return vertex_position


def calculate_maximum_possible_movement(obj, idx, isolated_positions, moved_vertices):
    max_movements = {}

    vertex_position_in_pose = get_vertex_position_in_pose(obj, idx, moved_vertices)

    for group_name, positions_dict in isolated_positions.items():
        if idx in positions_dict:
            isolated_position = positions_dict[idx]
            max_movement = isolated_position - vertex_position_in_pose
            max_movements[group_name] = max_movement

    return max_movements





def calculate_combined_influence_movement(obj, idx, all_influencing_groups, additional_groups=None):
    original_weights = {}
    combined_weights = {}

    vertex_groups = obj.data.vertices[idx].groups
    for vg in vertex_groups:
        group_name = obj.vertex_groups[vg.group].name
        original_weights[group_name] = vg.weight

    if additional_groups:
        equal_weight = 1.0 / len(additional_groups) if additional_groups else 0
        for group_name in additional_groups:
            if group_name in original_weights:
                combined_weights[group_name] = equal_weight
                obj.vertex_groups[group_name].add([idx], equal_weight, 'REPLACE')
    else:
        combined_weights = original_weights.copy()

    bpy.context.view_layer.update()
    eval_obj = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = eval_obj.data

    new_pos = mesh.vertices[idx].co.copy()

    for group_name, weight in original_weights.items():
        group = obj.vertex_groups.get(group_name)
        if group:
            group.add([idx], weight, 'REPLACE')

    return new_pos, combined_weights






def isolate_vertex_group_influence(obj, moved_vertices, all_influencing_groups):
    isolated_positions = {}
    original_weights = {}
   
    if not isinstance(moved_vertices, list):
        moved_vertices = [moved_vertices]

    for idx in moved_vertices:
        vertex_groups = obj.data.vertices[idx].groups
        for group in all_influencing_groups:
            for vg in vertex_groups:
                if obj.vertex_groups[vg.group].name == group.name:
                    original_weights[(group.name, idx)] = vg.weight
                    break
            else:
                original_weights[(group.name, idx)] = 0.0

    for group in all_influencing_groups:
        group.add(moved_vertices, 1.0, 'REPLACE')

        for other_group in all_influencing_groups:
            if other_group != group:
                other_group.add(moved_vertices, 0.0, 'REPLACE')

        bpy.context.view_layer.update()
        eval_obj = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        mesh = eval_obj.data

        for idx in moved_vertices:
            new_pos = mesh.vertices[idx].co.copy()
            isolated_positions.setdefault(group.name, {})[idx] = new_pos

        for idx in moved_vertices:
            if (group.name, idx) in original_weights:
                group.add([idx], original_weights[(group.name, idx)], 'REPLACE')

    for group_name, weight_data in original_weights.items():
        group = obj.vertex_groups[group_name[0]]
        for idx in moved_vertices:
            if (group_name[0], idx) in original_weights:
                group.add([idx], original_weights[(group_name[0], idx)], 'REPLACE')

    return isolated_positions







def measure_combined_influences(obj, idx, additional_groups=None):
    influencing_groups = []

    if additional_groups:
        for add_group_name in additional_groups:
            group_index = obj.vertex_groups.find(add_group_name)
            if group_index != -1:
                influencing_groups.append(obj.vertex_groups[group_index])

    if not influencing_groups:
        vertex_group_weights = {group.group: group.weight for group in obj.data.vertices[idx].groups}
        influencing_groups = [group for group in obj.vertex_groups if group.index in vertex_group_weights]

    combined_influence_position, combined_weights = calculate_combined_influence_movement(obj, idx, influencing_groups, additional_groups)
    return combined_influence_position, combined_weights



def measure_isolated_influences(obj, moved_vertices, additional_groups=None):
    if not isinstance(moved_vertices, list):
        moved_vertices = [moved_vertices]

    all_influencing_groups = set()

    for idx in moved_vertices:
        vertex_group_weights = {group.group: group.weight for group in obj.data.vertices[idx].groups}
        if additional_groups is not None:
            for group_name in additional_groups:
                if group_name in obj.vertex_groups and obj.vertex_groups[group_name].index in vertex_group_weights:
                    all_influencing_groups.add(obj.vertex_groups[group_name])
        else:
            all_influencing_groups.update([group for group in obj.vertex_groups if group.index in vertex_group_weights])

    isolated_positions = isolate_vertex_group_influence(obj, moved_vertices, list(all_influencing_groups))

    return isolated_positions




def get_single_influenced_vertices(obj, moved_vertices):
    single_influence_vertices = []
    for idx in moved_vertices:
        groups = obj.vertex_groups

        influences = []
        for group in groups:
            try:
                weight = group.weight(idx)
                if weight > 0:
                    influences.append(group)
            except RuntimeError:
                continue

        if len(influences) == 1:
            single_influence_vertices.append(idx)
    
    return single_influence_vertices



def pre_process_vertex_groups(obj, moved_vertices, additional_groups):
    for idx in moved_vertices:
        vertex_group_weights = {obj.vertex_groups[group.group].name: group.weight for group in obj.data.vertices[idx].groups}

        for group_name in additional_groups:
            group = obj.vertex_groups.get(group_name)
            if group:
                if group_name in vertex_group_weights:
                    group.add([idx], vertex_group_weights[group_name], 'REPLACE')
                else:
                    group.add([idx], 0.0, 'REPLACE')



def normalize_weights(obj, vertices):
    for idx in vertices:
        total_weight = sum([group.weight for group in obj.data.vertices[idx].groups])
        if total_weight == 0:
            continue

        for group in obj.data.vertices[idx].groups:
            group_name = obj.vertex_groups[group.group].name
            normalized_weight = group.weight / total_weight
            obj.vertex_groups[group_name].add([idx], normalized_weight, 'REPLACE')



def apply_weights(obj, base_positions, adjusted_positions):   
    moved_vertices = identify_moved_vertices(base_positions, adjusted_positions)
    
    convergence_threshold = obj.weight_shaper_convergence_threshold
    max_iterations = obj.weight_shaper_iterations
    learning_rate = obj.weight_shaper_learning_rate
    additional_groups = [bone.name for bone in obj.additional_bones]
    
    pre_process_vertex_groups(obj, moved_vertices, additional_groups)

    adjusted_positions = [Vector(pos) for pos in json.loads(obj.data.adjusted_positions)]
    
    for idx in moved_vertices:
        starting_position, starting_weights = determine_starting_position_for_adjustment(obj, idx, adjusted_positions[idx], base_positions, additional_groups)

        converged = False
        iteration = 0

        while iteration < max_iterations and not converged:
            for group_name, weight in starting_weights.items():
                group = obj.vertex_groups[group_name]
                group.add([idx], weight, 'REPLACE')

            isolated_positions = measure_isolated_influences(obj, idx, additional_groups)
            max_movements = calculate_maximum_possible_movement(obj, idx, isolated_positions, moved_vertices)

            diff_vec = adjusted_positions[idx] - starting_position
            calculate_weight_adjustment(obj, idx, adjusted_positions[idx], diff_vec, max_movements, learning_rate)

            new_pos = get_vertex_position_in_pose(obj, idx, moved_vertices)
            starting_position = new_pos
            starting_weights = {group.group: group.weight for group in obj.data.vertices[idx].groups}

            new_diff_vec = adjusted_positions[idx] - new_pos
            converged = new_diff_vec.length <= convergence_threshold
            iteration += 1

        
        normalize_weights(obj, [idx])
    

class ApplyWeights(bpy.types.Operator):
    """Optimize weight painting based on mesh adjustments"""
    bl_idname = "vertexmover.apply_weights"
    bl_label = "Optimize Weights"

    def execute(self, context):
        start_time = time.time()
        obj = context.object

        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh. Please select a mesh object.")
            return {'CANCELLED'}
        previous_mode = obj.mode       
        
        try:
            base_positions = json.loads(obj.data.base_positions)
            if base_positions == []:
                self.report({'WARNING'}, "Please begin mesh adjustments first.")
                return {'CANCELLED'}
        except json.JSONDecodeError:
            self.report({'WARNING'}, "Please begin mesh adjustments first.")
            return {'CANCELLED'}

        try:
            adjusted_positions = json.loads(obj.data.adjusted_positions)
            if adjusted_positions == []:
                self.report({'WARNING'}, "Please complete mesh adjustments first.")
                return {'CANCELLED'}
        except json.JSONDecodeError:
            self.report({'WARNING'}, "Please complete mesh adjustments first.")
            return {'CANCELLED'}
        
        if not obj.additional_bones:
            self.report({'WARNING'}, "Please select at least one influencing bone.")
            return {'CANCELLED'}
        
        if not getattr(obj, 'shape_key_removed_by_addon', False):
            self.report({'WARNING'}, "Shape key was not removed correctly. Cannot optimize weights.")
            return {'CANCELLED'}
        
        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            
            base_positions = [Vector(pos) for pos in json.loads(obj.data.base_positions)]
            adjusted_positions = [Vector(pos) for pos in json.loads(obj.data.adjusted_positions)]

            apply_weights(obj, base_positions, adjusted_positions)
            

            bpy.ops.object.mode_set(mode=previous_mode)

        if previous_mode == 'POSE':
            armature = obj.find_armature()
            if armature:
                bpy.context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='POSE')
                
        end_time = time.time()
        execution_time = end_time - start_time
        execution_message = f"Optimization completed in {execution_time:.2f} seconds."
        self.report({'INFO'}, execution_message)

        return {'FINISHED'}



class CreateShapeKey(bpy.types.Operator):
    """Initiate mesh adjustments based on the current pose"""
    bl_idname = "vertexmover.create_shape_key"
    bl_label = "Begin Mesh Adjustments"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'MESH' and obj.parent and obj.parent.type == 'ARMATURE' and not obj.is_mesh_adjustment_active

    def execute(self, context):
        obj = context.object

        obj.data.base_positions = ""
        obj.data.adjusted_positions = ""
        
        bpy.ops.object.mode_set(mode='OBJECT')

        if obj.data.shape_keys and "VertexMoveFromPose" in obj.data.shape_keys.key_blocks:
            index = obj.data.shape_keys.key_blocks.find("VertexMoveFromPose")
            obj.active_shape_key_index = index
            bpy.ops.object.shape_key_remove(all=False)
        
        armature_modifier = None
        for modifier in obj.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object == obj.parent:
                armature_modifier = modifier
                break

        if armature_modifier is None:
            self.report({'ERROR'}, "No armature modifier found for the parent armature")
            return {'CANCELLED'}

        override = context.copy()
        override['object'] = obj
        override['active_object'] = obj

        with context.temp_override(**override):
            bpy.ops.object.modifier_apply_as_shapekey(modifier=armature_modifier.name, keep_modifier=True)


        armature_modifier.show_viewport = False
        
        if obj.data.shape_keys:
            if "Basis" in obj.data.shape_keys.key_blocks:
                shape_key = obj.data.shape_keys.key_blocks["Basis"]
            else:
                shape_key = obj.data.shape_keys.key_blocks[0]
                self.report({'WARNING'}, "The original 'Basis' shape key appears to be renamed. Proceeding with the first shape key.")
        else:
            bpy.ops.object.shape_key_add(from_mix=False)
            obj.data.shape_keys.key_blocks[-1].name = "Basis"
            shape_key = obj.data.shape_keys.key_blocks["Basis"]

        new_shape_key = obj.data.shape_keys.key_blocks[-1]
        new_shape_key.name = "VertexMoveFromPose"

        new_shape_key.value = 1

        obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

        self.save_base_positions(context.object)

        obj.is_mesh_adjustment_active = True

        self.report({'INFO'}, "Ready to adjust mesh. Switched to Edit mode.")
        return {'FINISHED'}
    
    
    def save_base_positions(self, obj):
        bpy.ops.object.mode_set(mode='OBJECT')
        positions = [get_vertex_position_with_shape_keys(obj, v.index).to_tuple() for v in obj.data.vertices if v.select]
        obj.data.base_positions = json.dumps(positions)
        bpy.ops.object.mode_set(mode='EDIT')



class CUSTOM_UL_items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.name, translate=False, icon_value=icon)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)

    def draw_filter(self, context, layout):
        pass


class SIMPLEVERTEXMOVER_PT_Panel(bpy.types.Panel):
    """Creates a Panel in the 3D view"""
    bl_label = "Weight Shaper"
    bl_idname = "SIMPLEVERTEXMOVER_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Weight Shaper'

    def draw(self, context):
        layout = self.layout
        obj = context.object

        
        
        if obj:
            layout.operator("vertexmover.create_shape_key", text="Begin Mesh Adjustments")
            layout.operator("vertexmover.finish_editing", text="Complete Mesh Adjustments")
            
            layout.label(text="Algorithm Settings:")
            layout.prop(obj, "weight_shaper_iterations", text="Iterations")
            layout.prop(obj, "weight_shaper_learning_rate", text="Learning Rate")
            layout.prop(obj, "weight_shaper_convergence_threshold", text="Convergence Threshold")
             
            layout.label(text="Influencing Bones:")
            row = layout.row()
            col = row.column()
            col.template_list("CUSTOM_UL_items", "additional_bones", obj, "additional_bones", obj, "additional_bones_index", rows=2)
            
            col = row.column(align=True)
            col.operator("object.add_selected_bones", text="", icon='ADD')
            col.operator("object.remove_selected_bone", text="", icon='REMOVE')
            
            layout.operator("vertexmover.apply_weights", text="Optimize Weights")
        else:
            layout.label(text="Select an object to see Weight Shaper settings.")

        
        

def get_vertex_position_with_shape_keys(obj, vertex_index):
    if obj.data.shape_keys is None:
        return obj.data.vertices[vertex_index].co.copy()

    base_position = obj.data.vertices[vertex_index].co.copy()
    adjusted_position = base_position

    for shape_key in obj.data.shape_keys.key_blocks:
        if shape_key.name != "Basis":
            influence = shape_key.data[vertex_index].co
            adjusted_position = base_position + (shape_key.value * (influence - base_position))

    return adjusted_position



class VERTEXMOVER_OT_FinishEditing(bpy.types.Operator):
    """Conclude mesh adjustments and set up for weight optimization"""
    bl_idname = "vertexmover.finish_editing"
    bl_label = "Complete Mesh Adjustments"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.is_mesh_adjustment_active
    
    def execute(self, context):
        obj = context.object

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

        self.save_adjusted_positions(obj)

        bpy.ops.object.mode_set(mode='OBJECT')

        armature_modifier = next((mod for mod in obj.modifiers if mod.type == 'ARMATURE'), None)
        if armature_modifier:
            armature_modifier.show_viewport = True

        obj.shape_key_removed_by_addon = False

        if obj.data.shape_keys and "VertexMoveFromPose" in obj.data.shape_keys.key_blocks:
            index = obj.data.shape_keys.key_blocks.find("VertexMoveFromPose")
            obj.shape_key_remove(obj.data.shape_keys.key_blocks[index])

            obj.shape_key_removed_by_addon = True
            self.report({'INFO'}, "Mesh adjustments completed. Switched to Weight Paint mode.")
        else:
            self.report({'WARNING'}, "No specific shape key found for removal.")

        bpy.ops.object.mode_set(mode='OBJECT')

        if obj.type == 'MESH' and obj.parent and obj.parent.type == 'ARMATURE':
            bpy.ops.object.select_all(action='DESELECT')
            armature = obj.parent
            armature.select_set(True)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')

        obj.is_mesh_adjustment_active = False
        
        return {'FINISHED'}
    
    def save_adjusted_positions(self, obj):
        bpy.ops.object.mode_set(mode='OBJECT')
        positions = [get_vertex_position_with_shape_keys(obj, v.index).to_tuple() for v in obj.data.vertices if v.select]
        obj.data.adjusted_positions = json.dumps(positions)
    

class AdditionalBoneItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Bone Name")

class OBJECT_OT_AddSelectedBones(bpy.types.Operator):
    """Add selected bones to the influencing bones list"""
    bl_idname = "object.add_selected_bones"
    bl_label = "Add Influencing Bones"

    def execute(self, context):
        obj = context.active_object
        selected_bones = []

        if obj.type == 'ARMATURE' and obj.mode == 'POSE':
            selected_bones = [bone.name for bone in obj.data.bones if bone.select]
        elif obj.mode == 'EDIT' and obj.type == 'ARMATURE':
            selected_bones = [bone.name for bone in obj.data.edit_bones if bone.select]
        elif obj.mode == 'WEIGHT_PAINT' and obj.type == 'MESH':
            armature = obj.find_armature()
            if armature:
                selected_bones = [bone.name for bone in armature.pose.bones if bone.bone.select]
                if not selected_bones:
                    self.report({'WARNING'}, "No bones selected in the Armature.")
                    return {'CANCELLED'}

        for bone_name in selected_bones:
            if any(bone.name == bone_name for bone in obj.additional_bones):
                self.report({'WARNING'}, f"Bone {bone_name} is already in the list.")
                continue

            mesh_obj = context.view_layer.objects.active
            if mesh_obj.type == 'MESH' and bone_name not in [vg.name for vg in mesh_obj.vertex_groups]:
                self.report({'WARNING'}, f"No vertex group found for bone: {bone_name}")
                continue

            item = obj.additional_bones.add()
            item.name = bone_name
            self.report({'INFO'}, f"Added bone: {bone_name}")

        return {'FINISHED'}


class OBJECT_OT_RemoveSelectedBone(bpy.types.Operator):
    """Remove a selected bone from the influencing bones list"""
    bl_idname = "object.remove_selected_bone"
    bl_label = "Remove Influencing Bone"

    def execute(self, context):
        obj = context.active_object
        index = obj.additional_bones_index

        if obj.additional_bones and 0 <= index < len(obj.additional_bones):
            removed_bone_name = obj.additional_bones[index].name
            obj.additional_bones.remove(index)
            obj.additional_bones_index = max(0, index - 1)
            self.report({'INFO'}, f"Removed bone: {removed_bone_name}")
        else:
            self.report({'WARNING'}, "No bone selected for removal.")

        return {'FINISHED'}




classes = [
    CUSTOM_UL_items,
    OBJECT_OT_RemoveSelectedBone,
    OBJECT_OT_AddSelectedBones,
    AdditionalBoneItem,
    SIMPLEVERTEXMOVER_PT_Panel,
    CreateShapeKey,
    ApplyWeights,
    VERTEXMOVER_OT_FinishEditing
]


registration_status = {
    'classes_registered': False,
    'properties_registered': False
}

def register():
    
    try:
        for cls in classes:
            bpy.utils.register_class(cls)
        registration_status['classes_registered'] = True
    except Exception as e:
        print(f"Error registering classes: {e}")

    
    try:
        bpy.types.Object.shape_key_removed_by_addon = bpy.props.BoolProperty(name="Shape Key Removed By Addon", default=False)
        
        bpy.types.Object.is_mesh_adjustment_active = bpy.props.BoolProperty(default=False)

    
        bpy.types.Object.weight_shaper_convergence_threshold = bpy.props.FloatProperty(
            name="Convergence Threshold",
            description="Convergence threshold for the weight optimization algorithm",
            default=0.001,  
            min=0.0001,  
            max=0.1,  
            step=0.1,  
            precision=4  
        )

        
        bpy.types.Object.weight_shaper_learning_rate = bpy.props.FloatProperty(
            name="Learning Rate",
            description="Learning rate for the weight optimization algorithm",
            default=0.3,  
            min=0.01,  
            max=1.0,   
            step=10,    
            precision=2 
        )
        
        bpy.types.Object.weight_shaper_iterations = bpy.props.IntProperty(
            name="Weight Shaper Iterations",
            description="Number of iterations for the weight optimization algorithm",
            default=5,
            min=1,
            max=100 
        )

        
        bpy.types.Object.additional_bones = bpy.props.CollectionProperty(type=AdditionalBoneItem)
        bpy.types.Object.additional_bones_index = bpy.props.IntProperty(
            name="Active Bone Index",
            default=0,
            min=0,
            description="Active index for UIList"
        )

         
        bpy.types.Mesh.base_positions = StringProperty(
            name="Base Positions",
            description="Stored base positions of vertices as a JSON string",
            default="[]"
        )

        bpy.types.Mesh.adjusted_positions = StringProperty(
            name="Adjusted Positions",
            description="Stored adjusted positions of vertices as a JSON string",
            default="[]"
        )
            
        registration_status['properties_registered'] = True
    except Exception as e:
        print(f"Error registering properties: {e}")


def unregister():
    
    if registration_status['properties_registered']:
        try:
            del bpy.types.Mesh.adjusted_positions
            del bpy.types.Mesh.base_positions
            del bpy.types.Object.additional_bones_index
            del bpy.types.Object.additional_bones
            del bpy.types.Object.weight_shaper_iterations
            del bpy.types.Object.weight_shaper_learning_rate
            del bpy.types.Object.weight_shaper_convergence_threshold
            del bpy.types.Object.is_mesh_adjustment_active
            del bpy.types.Object.shape_key_removed_by_addon
            
            registration_status['properties_registered'] = False
        except Exception as e:
            print(f"Error unregistering properties: {e}")

    if registration_status['classes_registered']:
        try:
            for cls in reversed(classes):
                bpy.utils.unregister_class(cls)
            registration_status['classes_registered'] = False
        except Exception as e:
            print(f"Error unregistering classes: {e}")

if __name__ == "__main__":
    register()
