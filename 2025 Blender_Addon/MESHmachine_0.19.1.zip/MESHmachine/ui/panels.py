import bpy
import os

from .. utils.ui import get_icon, get_panel_fold
from .. utils.registration import get_path, get_prefs, get_pretty_version

from .. import bl_info

class PanelMESHmachine(bpy.types.Panel):
    bl_idname = "MACHIN3_PT_mesh_machine"
    bl_label = ''
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MACHIN3"
    bl_order = 10

    @classmethod
    def poll(cls, context):
        return get_prefs().show_sidebar_panel

    def draw_header(self, context):
        layout = self.layout
        mm = context.scene.MM

        if get_prefs().update_available:
            layout.label(text="", icon_value=get_icon("refresh_green"))

        row = layout.row(align=True)

        row.label(text=f"MESHmachine {get_pretty_version(bl_info['version'])}")

        row.prop(mm, 'sidebar_show_resources', text='', icon='BLENDER')
        row.prop(mm, 'sidebar_show_help', text='', icon='QUESTION')

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        mm = context.scene.MM

        active = context.active_object
        can_sweep = [obj for obj in context.scene.objects if obj.MM.isstashobj]

        if get_prefs().update_available:
            column.separator()

            row = column.row()
            row.scale_y = 1.2
            row.label(text="An Update is Available", icon_value=get_icon("refresh_green"))
            row.operator("wm.url_open", text="What's new?").url = 'https://machin3.io/MESHmachine/docs/whatsnew'

            column.separator()

        if active and active.MM.stashes or can_sweep:

            if can_sweep:
                row = column.row(align=True)
                row.alignment = 'CENTER'
                row.label(text="Stashes have been linked to the Scene.")

                row = column.row()
                row.scale_y = 1.2
                row.alert = True
                row.operator('machin3.sweep_stashes', text='Sweep Stashes', icon='BRUSH_DATA')

            if active and active.MM.stashes:
                if can_sweep:
                    column.separator()

                if panel := get_panel_fold(column, "stashes", f"{active.name}'s Stashes", icon='OBJECT_HIDDEN', default_closed=True):
                    box = panel.box()
                    column = box.column()
                    column.label(text=f"{active.name} {'(' + active.MM.stashname + ')' if active.MM.stashname else ''}")

                    column.template_list("MACHIN3_UL_stashes", "", active.MM, "stashes", active.MM, "active_stash_idx", rows=max(len(active.MM.stashes), 1))

        if panel := get_panel_fold(column, "plugs", "Plug Placement", icon="PIVOT_CURSOR", default_closed=True):
            row = panel.split(factor=0.33)
            row.label(text="Plug Align")
            r = row.row()
            r.prop(mm, "align_mode", expand=True)

        if mm.sidebar_show_resources:
            if panel := get_panel_fold(column, "resources", "Resources", icon="BLENDER", default_closed=False):
                self.draw_resources(panel)

        if mm.sidebar_show_help:
            col = column.column(align=True)
            col.alert = True

            if panel := get_panel_fold(col, 'get_support', "Get Support", icon='GREASEPENCIL', default_closed=True):
                self.draw_support(panel)

            if panel := get_panel_fold(column, 'documentation', "Documentation", icon='INFO', default_closed=False):
                self.draw_documentation(panel)

        if bpy.ops.machin3.meshmachine_debug.poll():
            column.separator()

            column.scale_y = 2
            column.operator('machin3.meshmachine_debug', text='Button')

    def draw_resources(self, layout):
        current_path = os.path.dirname(bpy.data.filepath)
        resources_path = os.path.join(get_path(), "resources")

        example_tutorial_path = os.path.join(resources_path, "Example_Tutorial.blend")
        example_plugged_path = os.path.join(resources_path, "Example_Plugged.blend")

        if sub_panel := get_panel_fold(layout, "examples", "Examples", icon="FILE_BLEND", default_closed=False):
            if bpy.data.is_dirty and resources_path != current_path:
                col = sub_panel.column(align=True)
                col.alert = True
                row = col.row(align=True)
                row.alignment = 'CENTER'
                row.label(text="Your current file is not saved!", icon="ERROR")
                row = col.row(align=True)
                row.alignment = 'CENTER'
                row.label(text="Unsaved changes will be lost,")
                row = col.row(align=True)
                row.alignment = 'CENTER'
                row.label(text="if you load the following examples.")

            row = sub_panel.row(align=True)
            row.operator_context = 'EXEC_DEFAULT'
            row.scale_y = 1.5

            op = row.operator("wm.open_mainfile", text="Tutorial", icon="FILE_BLEND")
            op.filepath=example_tutorial_path
            op.load_ui = True

            op = row.operator("wm.open_mainfile", text="Plugged", icon="FILE_BLEND")
            op.filepath=example_plugged_path
            op.load_ui = True

        if sub_panel := get_panel_fold(layout, "plug_packs", "3rd Party Plug Packs", icon="PLUGIN", default_closed=True):
            row = sub_panel.row()
            row.scale_y = 1.2
            row.operator("wm.url_open", text="Plug Packs", icon='PLUGIN').url = "https://machin3.io/MESHmachine/docs/plug_resources"

    def draw_support(self, layout):
        layout.scale_y = 1.5
        layout.operator('machin3.get_meshmachine_support', text='Get Support', icon='GREASEPENCIL')

    def draw_documentation(self, layout):
        row = layout.row(align=True)
        row.scale_y = 1.25
        row.operator("wm.url_open", text='Local', icon='INTERNET_OFFLINE').url = "file://" + os.path.join(get_path(), "docs", "index.html")
        row.operator("wm.url_open", text='Online', icon='INTERNET').url = 'https://machin3.io/MESHmachine/docs'

        row = layout.row(align=True)
        row.scale_y = 1.25
        row.operator("wm.url_open", text='FAQ', icon='QUESTION').url = 'https://machin3.io/MESHmachine/docs/faq'
        row.operator("wm.url_open", text='Youtube', icon='FILE_MOVIE').url = 'https://www.youtube.com/playlist?list=PLcEiZ9GDvSdXR9kd4O6cdQN_6i0LOe5lw'

        layout.separator()

        row = layout.row(align=True)
        row.operator("wm.url_open", text="Blender Artists", icon="COMMUNITY").url = "https://blenderartists.org/t/meshmachine/1102529"
