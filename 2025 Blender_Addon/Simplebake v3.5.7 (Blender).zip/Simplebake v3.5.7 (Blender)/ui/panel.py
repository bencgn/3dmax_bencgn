import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import Panel, Operator

from ..utils import SBConstants, pbr_selections_to_list, specials_selection_to_list
from .objects_list import SIMPLEBAKE_UL_Objects_List
from .channel_packing_list import SIMPLEBAKE_UL_CPTexList
from .panel_operators import is_blend_saved
from ..background_and_progress import BackgroundBakeTasks, BakeInProgress
from ..auto_update import VersionControl
from ..bake_operators.pbr_bake_support_operators import has_node_groups
from ..messages import print_message


def monkey_tip(message_lines, box):
    sbp = bpy.context.scene.SimpleBake_Props
    row = box.row()
    row.alert=True
    row.prop(sbp, "showtips", icon="TRIA_DOWN" if sbp.showtips else "TRIA_RIGHT", icon_only=True, emboss=False)
    row.label(text=f'{"Tip" if sbp.showtips else "Tip available"}', icon="MONKEY")
    row.alignment = 'CENTER'
    
    if sbp.showtips:
        for line in message_lines:
            row = box.row()
            row.alignment = 'CENTER'
            row.scale_y = 0.5
            row.label(text=line)

def decals_tips(box):
    sbp = bpy.context.scene.SimpleBake_Props

    message_lines = [
        "PBR DECALS MODE",
        "Add the decal objects to the",
        "list, and specify your target",
        "object in the Target Object box.",
        "If using the 'Copy objects and",
        "apply bakes' option, a suitable",
        "decals material will be created"
        ]
    monkey_tip(message_lines, box)


    row=box.row()
    row.label(text="")


def auto_match_high_low_tips(box):
    sbp = bpy.context.scene.SimpleBake_Props
    if sbp.auto_match_mode == "name":

        message_lines = [
            "AUTO MATCH HIGH/LOW - NAME MODE",
            "Only objects with \"_high\" as a suffix",
            "to their name can be added to the list",
            "Each object's icon indicates if a",
            "corresponding \"_low\" object for baking",
            "can be found in the scene",
            "Cage objects are also auto detected",
            "with the suffix \"_cage\""
            ]
        monkey_tip(message_lines, box)

    if sbp.auto_match_mode == "position":

        message_lines = [
            "AUTO MATCH HIGH/LOW - POSITION MODE",
            "Add your high poly objects to the list",
            "Low poly detected by position (<0.5 BU)",
            "Each object's icon indicates if a",
            "corresponding low poly object for baking",
            "can be found in the scene"
            ]
        monkey_tip(message_lines, box)

        row=box.row()
        row.label(text="")


def denoise_options(box):
    C = bpy.context
    sbp = C.scene.SimpleBake_Props
    
    row = box.row()
    col = row.column()
    col.prop(sbp, "rundenoise", text="Denoise (Compositor)")
    #if not sbp.save_bakes_external:
        #col.enabled = False
    col = row.column()
    col.prop(C.scene.cycles, "use_denoising", text="Denoise (Cycles)")
    
    if C.scene.cycles.use_denoising:
        row=box.row()
        row.alignment = "RIGHT"
        row.prop(C.scene.cycles, "denoiser")
        row=box.row()
        row.alignment = "RIGHT"
        row.prop(C.scene.cycles, "denoising_input_passes")
        row=box.row()
        row.alignment = "RIGHT"
        row.prop(C.scene.cycles, "denoising_prefilter")

def check_for_render_inactive_modifiers():
    
    sbp = bpy.context.scene.SimpleBake_Props
    objects = [i.obj_point for i in sbp.objects_list if i.obj_point != None]
    
    for obj in objects:
        for mod in obj.modifiers:
            if mod.show_render and not mod.show_viewport:
                return True
    if sbp.selected_s2a and sbp.targetobj != None:
        for mod in sbp.targetobj.modifiers:
            if mod.show_render and not mod.show_viewport:
                return True
            
    if sbp.cycles_s2a and sbp.targetobj_cycles != None:
        for mod in sbp.targetobj_cycles.modifiers:
            if mod.show_render and not mod.show_viewport:
                return True
    
    return False
    
def check_for_viewport_inactive_modifiers():
    
    sbp = bpy.context.scene.SimpleBake_Props
    objects = [i.obj_point for i in sbp.objects_list if i.obj_point != None]
    
    for obj in objects:
        for mod in obj.modifiers:
            if mod.show_viewport and not mod.show_render:
                return True
    if sbp.selected_s2a and sbp.targetobj != None:
        for mod in sbp.targetobj.modifiers:
            if mod.show_viewport and not mod.show_render:
                return True
            
    if sbp.cycles_s2a and sbp.targetobj_cycles != None:
        for mod in sbp.targetobj_cycles.modifiers:
            if mod.show_viewport and not mod.show_render:
                return True
    
    return False   

def disable_row_if_node_groups(row, box):
    sbp = bpy.context.scene.SimpleBake_Props
    
    ngs = False
    objs = [i.obj_point for i in sbp.objects_list]
    for o in objs:
        for slot in o.material_slots:
            if slot.material != None:
                ngs = has_node_groups(slot.material)
    
    if ngs:
        row.enabled = False
        
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Node groups detected")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Unfortunately these can only be")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="baked in the foreground")
    
def disable_row_if_auto_match(row, box):
    sbp = bpy.context.scene.SimpleBake_Props

    if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode == "automatch":
        row.enabled = False

        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Auto match high low poly enabled")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Unfortunately this can only be")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="baked in the foreground")

def disable_row_if_decals(row, box):
    sbp = bpy.context.scene.SimpleBake_Props

    if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode == "decals":
        row.enabled = False

        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Baking decals to target enabled.")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="Unfortunately this can only be")
        row = box.row()
        row.alert = True
        row.alignment = 'CENTER'
        row.scale_y = 0.5
        row.label(text="baked in the foreground")


class SIMPLEBAKE_PT_main_panel(Panel):
    bl_label = "SimpleBake"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render" 
    
    def draw_version_info(self, context, layout):
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        
        def print_installed_ver():
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                iv = VersionControl.installed_version_str
                row.label(text=f"Installed version: {iv}")
        
        if  bpy.app.version >= (4,0,0):
            box = layout.box()
            row = box.row()
            row.alert=True
            row.alignment = 'CENTER'
            row.label(text=f"Obtain SimpleBake for Blender")
            row.scale_y = 0.6
            row = box.row()
            row.alert=True
            row.alignment = 'CENTER'
            row.label(text=f"4.0+ from Blender Market")
            row.scale_y = 0.6
            return False


        elif prefs.no_update_check:
            print_installed_ver()
            
            row = layout.row()
            row.alert=True
            row.alignment = 'CENTER'
            row.scale_y = 0.6
            iv = VersionControl.installed_version_str
            row.label(text=f"(Update checking disabled)")
            
            
        else:
        
            if VersionControl.was_error:
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text="", icon="ERROR")
                
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text="WARNING: Simplebake wasn't able to check")
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text="for updates. Are you online?")
                
                row = layout.row()
                row.operator("simplebake.protect_clear", icon='URL', text="Yes I *AM* online!!")
                row.scale_y = 1.5
                print_installed_ver()
                return True
            
            elif not VersionControl.at_current:
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.alert=True
                row.label(text="", icon="MOD_WAVE") 
                
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.alert=True
                row.label(text="Newer version of SimpleBake available")
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.alert=True
                row.label(text="Update automatically in addon preferences")
                print_installed_ver()
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text=f"Available Version: {VersionControl.current_version_str}")
                
                return True

            else:
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text="", icon="CHECKMARK")
                
                row = layout.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.6
                row.label(text="SimpleBake is up-to-date")
                print_installed_ver()
                return True
    
    def draw_global_mode_buttons(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.scale_y = 1.5 
        row.prop(sbp, "global_mode", icon="SETTINGS", expand=True)
        
        row = box.row()
        row.operator("simplebake.panel_hide_all", icon='PROP_OFF', text="Hide all")
        row.operator("simplebake.panel_show_all", icon='PROP_ON', text="Show all")
        
    def draw_presets(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.prop(sbp, "presets_show", text="Settings presets", icon="PROP_ON" if sbp.presets_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.presets_show:
                
            row = box.row()
            col = row.column()
            col.template_list("SIMPLEBAKE_UL_Presets_List", "Presets List", sbp,
                              "presets_list", sbp, "presets_list_index")
            
            col = row.column()
            col.operator("simplebake.preset_refresh", text="", icon="FILE_REFRESH")
            col.operator("simplebake.preset_load", text="", icon="CHECKMARK")
            col.operator("simplebake.preset_delete", text="", icon="CANCEL")
            
            
            row = box.row()
            row.prop(sbp, "preset_name")
            row.operator("simplebake.preset_save", text="", icon="FUND")
            
            row = box.row()
            row.prop(sbp, "preset_load_clear_obj")
        
    
    
    def draw_objects_list(self, context, box):
        sbp = context.scene.SimpleBake_Props
        
        row = box.row()
        row.prop(sbp, "bake_objects_show", text="Bake objects", icon="PROP_ON" 
                 if sbp.bake_objects_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.bake_objects_show:
            
            row = box.row()
            row.template_list("SIMPLEBAKE_UL_Objects_List", "Bake Objects List", sbp,
                          "objects_list", sbp, "objects_list_index")
            row = box.row()
            row.operator('simplebake.add_bake_object', text='Add', icon="PRESET_NEW")
            row.operator('simplebake.remove_bake_object', text='Remove', icon="CANCEL")
            row.operator('simplebake.clear_bake_objects_list', text='Clear', icon="MATPLANE")
            row = box.row()
            row.operator('simplebake.move_bake_object_list', text='Up', icon="TRIA_UP").direction="UP"
            row.operator('simplebake.move_bake_object_list', text='Down', icon="TRIA_DOWN").direction="DOWN"
            row.operator('simplebake.refresh_bake_object_list', text='Refresh', icon="FILE_REFRESH")
                
            if sbp.global_mode == SBConstants.PBR:
                row = box.row()
                row.prop(sbp, "selected_s2a")
                    
                if(sbp.selected_s2a):

                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "s2a_opmode")

                    if sbp.s2a_opmode in ["single", "decals"]:
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "targetobj")

                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(context.scene.render.bake, "cage_object", text="Cage Object (Optional)")

                        if sbp.s2a_opmode == "decals":
                            decals_tips(box)

                    if sbp.s2a_opmode == "automatch":
                        row=box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "auto_match_mode")

                        auto_match_high_low_tips(box)

                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "cage_smooth_hard")
                    if bpy.context.scene.render.bake.cage_object != None:
                        row.enabled = False
                    row = box.row()
                    row.use_property_split = True
                    row.prop(sbp, "cage_extrusion")
                    if bpy.context.scene.render.bake.cage_object != None:
                        row.enabled = False
                    row = box.row()
                    row.use_property_split = True
                    row.prop(sbp, "ray_distance")
        
            
            if sbp.global_mode == SBConstants.CYCLESBAKE:
                row = box.row()
                row.prop(sbp, "cycles_s2a", text="Bake to target object (selected to active)")
                if sbp.cycles_s2a:
                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "s2a_opmode")

                    if sbp.s2a_opmode in ["single"]:


                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "targetobj_cycles")
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(context.scene.render.bake, "cage_object", text="Cage Object (Optional)")

                    if sbp.s2a_opmode in ["automatch"]:
                        row=box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "auto_match_mode")

                        auto_match_high_low_tips(box)

                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "cage_smooth_hard")
                    if bpy.context.scene.render.bake.cage_object != None:
                        row.enabled = False
                    row = box.row()
                    row.use_property_split = True
                    row.prop(sbp, "cage_extrusion")
                    if bpy.context.scene.render.bake.cage_object != None:
                        row.enabled = False
                    row = box.row()
                    row.use_property_split = True
                    row.prop(sbp, "ray_distance")
            
            row = box.row()
            row.prop(sbp, "isolate_objects")

            
            if check_for_render_inactive_modifiers():
                
                message_lines = [
                "One or more selected objects",
                "has a modifier enabled for",
                "render (and so baking), but disabled in",
                "viewport. May cause unexpected results"
                ]
                monkey_tip(message_lines, box)
                
            if check_for_viewport_inactive_modifiers():
                
                message_lines = [
                "One or more selected objects",
                "has a modifier enabled in the",
                "viewport, but disabled for",
                "render (and so baking).",
                "May cause unexpected results"
                ]
                monkey_tip(message_lines, box)
    
    def draw_pbr_settings(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.prop(sbp, "pbr_settings_show", text="PBR Bakes", icon="PROP_ON"
                 if sbp.pbr_settings_show else "PROP_OFF", icon_only=True, emboss=False)

        if sbp.pbr_settings_show:
            row = box.row()
            row.prop(sbp, "selected_col")
            row.prop(sbp, "selected_metal")
                
            row = box.row()
            row.prop(sbp, "selected_sss")
            row.prop(sbp, "selected_ssscol")
                
            row = box.row()
            row.prop(sbp, "selected_rough")
            row.prop(sbp, "selected_normal")
            if sbp.selected_rough or sbp.selected_normal:
                row = box.row()
                if sbp.selected_normal and sbp.selected_rough:
                    col = row.column()
                    col.prop(sbp, "rough_glossy_switch")
                    col = row.column()
                    col.prop(sbp, "normal_format_switch")
                elif sbp.selected_rough:
                    col = row.column()
                    col.prop(sbp, "rough_glossy_switch")                    
                    col = row.column()
                    col.label(text="")
                elif sbp.selected_normal:
                    col = row.column()
                    col.label(text="")
                    col = row.column()
                    col.prop(sbp, "normal_format_switch")
                
            row = box.row()
            row.prop(sbp, "selected_trans")
            row.prop(sbp, "selected_transrough")
            row = box.row()
            row.prop(sbp, "selected_clearcoat")
            row.prop(sbp, "selected_clearcoat_rough")
            row = box.row()
            row.prop(sbp, "selected_emission")
            row.prop(sbp, "selected_emission_strength")
            row = box.row()
            col = row.column()
            col.prop(sbp, "selected_specular")
            col = row.column()
            col.prop(sbp, "selected_alpha")
            if sbp.selected_s2a == True and sbp.s2a_opmode == "decals":
                col.enabled = False
            row = box.row()
            row.prop(sbp, "selected_displacement")
            row = box.row()
            row.operator("simplebake.selectall_pbr", icon='ADD')
            row.operator("simplebake.selectnone_pbr", icon='REMOVE')
    
    def draw_cyclesbake_settings(self, context, box):
        
        sbp = context.scene.SimpleBake_Props
        
        row = box.row()
        row.prop(sbp, "cyclesbake_settings_show", text="CyclesBake", icon="PROP_ON" if sbp.cyclesbake_settings_show else "PROP_OFF", icon_only=False, emboss=False)
            
        if sbp.cyclesbake_settings_show:
            cscene = bpy.context.scene.cycles
            cbk = bpy.context.scene.render.bake
            
            row=box.row()
            row.prop(cscene, "bake_type")
            
            col = box.column()
            if cscene.bake_type == 'NORMAL':
                col.prop(cbk, "normal_space", text="Space")
        
                sub = col.column()
                sub.prop(cbk, "normal_r", text="Swizzle R")
                sub.prop(cbk, "normal_g", text="G")
                sub.prop(cbk, "normal_b", text="B")

            elif cscene.bake_type == 'COMBINED':
    
                col.prop(cbk, "use_pass_direct")
                col.prop(cbk, "use_pass_indirect")
    
                col = box.column()
                col.active = cbk.use_pass_direct or cbk.use_pass_indirect
                col.prop(cbk, "use_pass_diffuse")
                col.prop(cbk, "use_pass_glossy")
                col.prop(cbk, "use_pass_transmission")
                col.prop(cbk, "use_pass_emit")
    
            elif cscene.bake_type in {'DIFFUSE', 'GLOSSY', 'TRANSMISSION'}:
                col = box.column()
                col.prop(cbk, "use_pass_direct")
                col.prop(cbk, "use_pass_indirect")
                col.prop(cbk, "use_pass_color")
                
            row = box.row()
            col = row.column()
            col.prop(context.scene.cycles, "samples")
            #row = box.row()
            
            if (sbp.global_mode == SBConstants.CYCLESBAKE and 
                    bpy.context.scene.cycles.bake_type != "NORMAL"):
                row = box.row()
                row.prop(sbp, "cyclesbake_cs")
            
            denoise_options(box)
            
                    
    def draw_specials_settings(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.prop(sbp, "specials_show", text="Special bakes", icon="PROP_ON" if sbp.specials_show else "PROP_OFF", icon_only=False, emboss=False)
        need_denoise_options = False
        
        if sbp.specials_show:
            row = box.row()
            col = row.column()
            col.prop(sbp, "selected_col_mats")
            if sbp.selected_s2a or sbp.cycles_s2a:
                col.enabled = False
            col = row.column()
            col.prop(sbp, "selected_col_vertex")
            row = box.row()
            row.prop(sbp, "selected_curvature")
            row = box.row()
            row = box.row()
            row.prop(sbp, "selected_ao")
            row.prop(sbp, "selected_thickness")
            row = box.row()
            row.prop(sbp, "selected_lightmap")
            if sbp.selected_s2a or sbp.cycles_s2a:
                row.enabled = False
            
            
            if sbp.selected_ao or sbp.selected_thickness:
                row = box.row()
                row.prop(sbp, "ao_sample_count")
                if sbp.global_mode == SBConstants.PBR:
                    need_denoise_options = True
            if sbp.selected_lightmap and sbp.global_mode == SBConstants.PBR:
                row = box.row()
                row.prop(context.scene.cycles, "samples", text="Lightmap Sample Count")
                need_denoise_options = True
            if sbp.selected_lightmap:    
                row=box.row()
                row.prop(sbp, "lightmap_apply_colman", text="Lightmap apply colour management")
                if not sbp.save_bakes_external: row.enabled = False
            
            if need_denoise_options:
                row = box.row()
                denoise_options(box)
                
            
            if (sbp.selected_lightmap or sbp.selected_ao or sbp.selected_thickness) and sbp.global_mode == SBConstants.PBR:
                
                message_lines = [
                "Sample count and denoise are not normally",
                f"relevant for PBR Bake, but they are for {SBConstants.LIGHTMAP},",
                f"{SBConstants.AO} and {SBConstants.THICKNESS}"
                ]
                monkey_tip(message_lines, box)
            
            if sbp.selected_lightmap and sbp.global_mode == SBConstants.CYCLESBAKE:
                message_lines = [
                "Lightmap will have sample count",
                "and denoise settings that",
                "you have set for CyclesBake above"
                ]
                monkey_tip(message_lines, box)
            
            if (sbp.selected_ao or sbp.selected_thickness) and sbp.global_mode == SBConstants.CYCLESBAKE:
                message_lines = [
                "AO and thickness will have",
                "denoise settings that",
                "you have set for CyclesBake above"
                ]
                monkey_tip(message_lines, box)
            
            row = box.row()
            row.operator("simplebake.import_special_mats", icon='ADD')
        
            if sbp.selected_s2a or sbp.cycles_s2a:
                message_lines = [
                "Lightmap is unavailable when",
                "baking to target object for",
                "now. I am working on it!"
                ]
                monkey_tip(message_lines, box)
    
    def draw_texture_settings(self, context, box):
        sbp = context.scene.SimpleBake_Props

        row=box.row()
        row.prop(sbp, "textures_show", text="Texture settings", icon="PROP_ON"
                 if sbp.textures_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.textures_show:
            
            row = box.row()
            #HASNT BEEN ADDED TO PRESETS!
            #row.prop(sbp, "tex_override")
            #if sbp.tex_override:
                #row = box.row()
                #row.prop(sbp, "tex_override_tex")

            if False:
                pass
            else:
                row = box.row()
                row.label(text="Bake at:")
                row.scale_y = 0.5

                row = box.row()
                row.prop(sbp, "imgwidth")
                row.prop(sbp, "imgheight")

                row = box.row()
                row.operator("simplebake.decrease_texture_res", icon = "TRIA_DOWN")
                row.operator("simplebake.increase_texture_res", icon = "TRIA_UP")

                row=box.row()

                row = box.row()
                row.label(text="Output at:")
                row.scale_y = 0.5

                row = box.row()
                row.prop(sbp, "outputwidth")
                row.prop(sbp, "outputheight")

                row = box.row()
                row.operator("simplebake.decrease_output_res", icon = "TRIA_DOWN")
                row.operator("simplebake.increase_output_res", icon = "TRIA_UP")

                row = box.row()
                row.alignment = "RIGHT"
                row.prop(context.scene.render.bake, "margin", text="Bake Margin")

                try: #Margin type was added after Blender 3.0, apparently
                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(context.scene.render.bake, "margin_type", text="Margin Type")
                except:
                    pass

                row = box.row()
                row.prop(sbp, "everything32bitfloat")

                row = box.row()
                row.prop(sbp, "use_alpha")
                if sbp.export_file_format == "JPEG" or not sbp.clear_image:
                    row.enabled = False

                #For now, this is CyclesBake only
                #if sbp.global_mode == SBConstants.CYCLESBAKE:
                    #row = box.row()
                    #row.prop(sbp, "tex_per_mat")

            row = box.row()
            row.prop(sbp, "merged_bake")

            if len(sbp.objects_list) < 2 and sbp.merged_bake and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode!="automatch":

                message_lines = [
                    "You are baking multiple objects to one",
                    "texture set, but have fewer then 2",
                    "in the bake list. This is OK, but",
                    "might not be what you wanted"
                        ]
                monkey_tip(message_lines, box)

            if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch" and len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
                row.enabled = False

            if sbp.merged_bake:
                row = box.row()
                row.prop(sbp, "merged_bake_name")

            row = box.row()
            row.prop(sbp, "clear_image")
            if sbp.uv_mode == "udims":
                row.enabled = False
    
    def draw_export_settings(self, context, box):
        row = box.row()
        sbp = context.scene.SimpleBake_Props
        
        row.prop(sbp, "export_show", text="Export settings", icon="PROP_ON" if sbp.export_show else "PROP_OFF", icon_only=False, emboss=False)
        
   
        if sbp.export_show:
            if not is_blend_saved():
                row=box.row()
                row.label(text="Unavailable - Blend file not saved")
                return True
            
            row = box.row()
            col = row.column()
            col.prop(sbp, "save_bakes_external")
            col = row.column()
            col.prop(sbp, "save_obj_external")
            
            #Relevant for both saving object and saving textures
            if sbp.save_bakes_external or sbp.save_obj_external:
                
                row = box.row()
                col = row.column()
                col.prop(sbp, "export_path", text="Export Path")
                col = row.column()
                col.operator("simplebake.export_path_to_blend_location", text="", icon="UV_SYNC_SELECT")
                
                row = box.row()
                row.prop(sbp, "export_folder_per_object")
                #row = box.row()
                #row.prop(sbp, "folder_date_time")        
            
            #Relevant if exporting textures
            if sbp.save_bakes_external:
                row = box.row()
                if sbp.export_file_format == "OPEN_EXR":
                    row.label(text="EXR exported as (max) 32bit")
                elif sbp.export_file_format == "JPEG" or sbp.export_file_format == "TARGA":
                    pass
                else:
                    row.prop(sbp, "everything_16bit")
                row = box.row()
                if(sbp.global_mode == SBConstants.PBR):
                    row.prop(sbp, "apply_col_man_to_col")
                    if not sbp.selected_col:
                        row.enabled = False
                    
                if(sbp.global_mode == SBConstants.CYCLESBAKE):
                    row.prop(sbp, "export_cycles_col_space")
                    if bpy.context.scene.cycles.bake_type == "NORMAL":
                        row.enabled = False 
                row = box.row()
                row.prop(sbp, "export_file_format", text="Format")
                if sbp.export_file_format == "OPEN_EXR":
                    row.prop(sbp, "exr_codec_export")
                if sbp.export_file_format == "JPEG":
                    row.prop(sbp, "jpeg_quality", slider=True)
                    
                row = box.row()
                row.prop(sbp, "keep_internal_after_export")
                
            #Relevant if saving object
            if sbp.save_obj_external:
                
                row=box.row()
                #row.alignment = "RIGHT"
                row.prop(sbp, "export_format")
                
                #FBX
                if sbp.export_format == "fbx":
                    row=box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "apply_mods_on_mesh_export")
                    row=box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "apply_transformation")
                
                
                    if not sbp.export_folder_per_object:
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "fbx_name")
            
                    row=box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "fbx_preset_name")
                    
                    
                #GLTF
                if sbp.export_format == "gltf":
                    if not sbp.export_folder_per_object:
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "gltf_name")
            
                    row=box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "gltf_preset_name")
            
            #Tips
            #if not sbp.folder_date_time and sbp.save_bakes_external:
                #Tip alert
                #message_lines = [
                    #"Not appending date and time to folder name",
                    #"means all previous bakes will be",
                    #"overwritten. Be careful!"
                    #]
                #monkey_tip(message_lines, box)
            
            if sbp.everything32bitfloat and sbp.save_bakes_external and sbp.export_file_format != "OPEN_EXR":
                #Tip alert
                message_lines = [
                    "You are creating all images as 32bit float.",
                    "You may want to export to EXR",
                    "to preserve your 32bit image(s)"
                    ]
                monkey_tip(message_lines, box)
                    
            if sbp.export_file_format == "OPEN_EXR" and sbp.save_bakes_external:
                #Tip alert
                message_lines = [
                    "Note: EXR files cannot be exported",
                    "with colour management settings.",
                    "EXR doesn't support them. Even",
                    "Blender defaults will be ignored"
                    ]
                monkey_tip(message_lines, box)
        
    
    def draw_uv_settings(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.prop(sbp, "uv_show", text="UV settings", icon="PROP_ON" if sbp.uv_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.uv_show:

            n = int(''.join(c for c in bpy.app.version_string if c.isdigit()))
            if n == 360:
                row=box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.alert=True
                row.label(text="WARNING")
                row=box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.alert=True
                row.label(text="SERIOUS BUG WITH BLENDER 3.6 UVS")
                row=box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.alert=True
                row.label(text="CRASH VERY LIKELY")
                row=box.row()
                row.alignment = 'CENTER'
                row.scale_y = 0.5
                row.alert=True
                row.label(text="SEE BLENDER MARKET FAQS")

            row = box.row()
            row.prop(sbp, "uv_mode", expand=True)
            row.enabled = True if sbp.save_bakes_external else False
            if not sbp.save_bakes_external:
                message_lines = [
                    "Must be saving bakes externally for UDIMS"
                    ]
                monkey_tip(message_lines, box)

            if sbp.uv_mode == "udims":
                #Tip alert
                message_lines = [
                    "You must manually create UV map over",
                    "UDIM tiles prior to bake"
                    ]
                monkey_tip(message_lines, box)
            
                row = box.row()
                row.prop(sbp, "udim_tiles")
            
            if sbp.uv_mode == "udims":
                pass
            
            else:
                row = box.row()
                row.prop(sbp, "new_uv_option")
                
                #-----------------------------------
                def multi_object_options(box):
                    row = box.row()
                    row.alignment = "RIGHT"
                    row.prop(sbp, "new_uv_method")
                    if sbp.new_uv_method == ("SmartUVProject_Atlas" or sbp.new_uv_method == "SmartUVProject_Individual"):
                            row = box.row()
                            row.alignment = "RIGHT"
                            row.prop(sbp, "unwrapmargin")
                    else: #Combine
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.prop(sbp, "average_uv_size")
                        row.prop(sbp, "uvpackmargin")
                def single_object_options(box):
                        #One object selected
                        row = box.row()
                        row.alignment = "RIGHT"
                        row.label(text="Smart UV Project")
                        row.prop(sbp, "unwrapmargin")
                #-----------------------------------

                #Print the options if requesting new UVs
                if sbp.new_uv_option:
                    objects = [obj.name for obj in sbp.objects_list]
                    viable_high_low = SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes
                    if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch" and len(viable_high_low) >1:
                        multi_object_options(box)
                    elif (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch" and len(viable_high_low) ==1:
                        single_object_options(box)
                    elif len(objects) >1 and not (sbp.selected_s2a or sbp.cycles_s2a):
                        multi_object_options(box)
                    elif len(objects) ==1:
                        single_object_options(box)
                    else:
                        row = box.row()
                        row.label(text="No objects selected for bake")

            
            row = box.row()  
            row.prop(sbp, "prefer_existing_sbmap")
            if sbp.new_uv_option == True:
                row.enabled = False
            
                
            row = box.row()
            row.prop(sbp, "restore_orig_uv_map")
            
            if sbp.new_uv_option:
                row = box.row()
                row.prop(sbp, "move_new_uvs_to_top")

            n = int(''.join(c for c in bpy.app.version_string if c.isdigit()))
            if n >= 360:
                row = box.row()
                row.prop(sbp, "uv_advanced_packing_show", text="Advanced UV packing settings", icon="DOWNARROW_HLT" if sbp.uv_advanced_packing_show else "RIGHTARROW_THIN", icon_only=False, emboss=False)
                row.alignment = "LEFT"

                if sbp.uv_advanced_packing_show:
                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_rotate")
                    col=row.column()
                    col.prop(sbp, "uvp_scale")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_lock_pinned")
                    col=row.column()
                    col.prop(sbp, "uvp_merge_overlapping")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvpackmargin")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_shape_method")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_rotation_method")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_margin_method")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_lock_method")

                    row=box.row()
                    col=row.column()
                    col.prop(sbp, "uvp_pack_to")


            if sbp.new_uv_option and sbp.restore_orig_uv_map and not sbp.copy_and_apply:
                #Tip alert
                message_lines = [
                "Generating new UVs, but restoring originals",
                "after bake. Baked textures won't align with the",
                "original UVs. Manually change active UV map ",
                "after bake"
                ]
                
            
            if sbp.new_uv_option and sbp.new_uv_method == "SmartUVProject_Individual" and sbp.merged_bake and sbp.uv_mode != "udims":
                #Tip alert
                message_lines = [
                "Current settings will unwrap objects",
                "individually but bake to one texture set",
                "Bakes will be on top of each other!"
                ]
                monkey_tip(message_lines, box)
            
    
            if not sbp.new_uv_option  and sbp.merged_bake:
                #Tip alert
                message_lines = [
                "ALERT: You are baking multiple objects to one texture",
                "set with existing UVs. You will need to manually",
                "make sure those UVs don't overlap!"
                ]
                monkey_tip(message_lines, box)
                       
            
            if sbp.new_uv_option and not sbp.save_obj_external and not sbp.copy_and_apply and sbp.bgbake == "bg":
                #Tip alert
                message_lines = [
                "You are baking in background with new UVs, but",
                "not exporting FBX or using 'Copy Objects and Apply Bakes'",
                "You will recieve the baked textures on import, but you will",
                "have no access to an object with the new UV map!"
                ]
                monkey_tip(message_lines, box)
    
    def draw_other_settings(self, context, box):
        sbp = context.scene.SimpleBake_Props 
        row = box.row()
        row.prop(sbp, "other_show", text="Other settings", icon="PROP_ON" if sbp.other_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.other_show:
            row=box.row()
            row.alignment = 'LEFT'
            row.prop(sbp, "batch_name")
        
            row = box.row()
            if sbp.bgbake == "fg": text = "Copy objects and apply bakes"
            else: text = "Copy objects and apply bakes (after import)"
            
            row.prop(sbp, "copy_and_apply", text=text)
            if sbp.tex_per_mat: row.enabled = False

            row = box.row()
            row.prop(sbp, "apply_bakes_to_original", text="Apply bakes to original objects")
            if sbp.bgbake == "bg":
                row.enabled = False
            if sbp.apply_bakes_to_original:
                message_lines = [
                "Be careful when applying bakes to",
                "original objects. Original materials won't",
                "be deleted, BUT they will have no users",
                "and may be purged on next save"
                ]
                monkey_tip(message_lines, box)

            if sbp.apply_bakes_to_original and sbp.restore_orig_uv_map:
                message_lines = [
                "You are restoring your original UVs",
                "after bake, but also applying the baked",
                "textures to original objects. The textures",
                "may not look right with original UVs"
                ]
                monkey_tip(message_lines, box)


            row = box.row()
            row.prop(sbp, "no_force_32bit_normals")

            if (sbp.copy_and_apply == True):
                if sbp.bgbake == "fg": text = "Hide source objects after bake"
                else: text = "Hide source objects after bake (after import)"
                row = box.row()
                row.prop(sbp, "hide_source_objects", text=text)
                if sbp.selected_s2a or sbp.cycles_s2a:
                    if sbp.bgbake == "fg": text = "Hide cage object after bake"
                    else: text = "Hide cage object after bake (after import)"
                    row = box.row()
                    row.prop(sbp, "hide_cage_object", text=text)

                row = box.row()
                row.prop(sbp, "create_glTF_node")
                if sbp.create_glTF_node:
                    row.prop(sbp, "glTF_selection", text="")

                if sbp.global_mode == SBConstants.CYCLESBAKE:
                    row=box.row()
                    row.prop(sbp, "cyclesbake_copy_and_apply_mat_format", text = "Material")

            if bpy.context.preferences.addons["cycles"].preferences.has_active_device():
                row=box.row()
                row.prop(context.scene.cycles, "device")
            else:
                row=box.row()
                row.label(text="No valid GPU device in Blender Preferences. Using CPU.")


            if sbp.global_mode == SBConstants.PBR:
                row = box.row()
                row.prop(sbp, "boosted_sample_count")



                
            
            
            if bpy.context.preferences.addons["cycles"].preferences.compute_device_type == "OPTIX" and bpy.context.preferences.addons["cycles"].preferences.has_active_device():
                #Tip alert
                message_lines = [
                "Other users have reported problems baking",
                "with GPU and OptiX. This is a Blender issue",
                "If you encounter problems bake with CPU"
                ]
                monkey_tip(message_lines, box)
                
            
            if (sbp.global_mode == SBConstants.PBR and sbp.copy_and_apply and
                len(pbr_selections_to_list()) == 0 and len(specials_selection_to_list()) > 0):

                message_lines = ([
                    "You are baking only special maps (no primary)",
                    "while using 'Copy objects and apply bakes'",
                    "Special maps will be in the new object(s)",
                    "material(s), but disconnected"
                    ])
                monkey_tip(message_lines, box)
    
    def draw_channel_packing(self, context, box):
        
        sbp = context.scene.SimpleBake_Props
        
        row = box.row()
        row.prop(sbp, "channelpacking_show", text="Channel packing", icon="PROP_ON" if sbp.channelpacking_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.channelpacking_show:
        
            if not is_blend_saved():
        
                row=box.row()
                row.label(text="Unavailable - Blend file not saved")
        
            elif not sbp.save_bakes_external:
    
                row=box.row()
                row.label(text="Unavailable - You must be exporting your bakes")
    
            else:
            
                row=box.row()
                col = row.column()
        
                col.template_list("SIMPLEBAKE_UL_CPTexList", "CP Textures List", sbp,
                                        "cp_list", sbp, "cp_list_index")
                col = row.column()
                col.operator("simplebake.cptex_delete", text="", icon="CANCEL")
                col.operator("simplebake.cptex_set_defaults", text="", icon="MONKEY")
                
                row=box.row()
                row.prop(sbp, "cp_name")
                row=box.row()
                row.prop(sbp, "channelpackfileformat", text="Format")
                if sbp.channelpackfileformat == "OPEN_EXR":
                    row.prop(sbp, "exr_codec_cpts") 
                row=box.row()
                row.scale_y=0.7
                row.prop(sbp, "cptex_R", text="R")
                row=box.row()
                row.scale_y=0.7
                row.prop(sbp, "cptex_G", text="G")
                row=box.row()
                row.scale_y=0.7
                row.prop(sbp, "cptex_B", text="B")
                row=box.row()
                row.scale_y=0.7
                row.prop(sbp, "cptex_A", text="A")
                
                
                cp_list = sbp.cp_list
                current_name = sbp.cp_name 
                if current_name in cp_list: #Editing a cpt that is already there
                    index = cp_list.find(current_name)
                    cpt = cp_list[index]
                    
                    if cpt.R != sbp.cptex_R or\
                        cpt.G != sbp.cptex_G or\
                        cpt.B != sbp.cptex_B or\
                        cpt.A != sbp.cptex_A or\
                        cpt.file_format != sbp.channelpackfileformat or\
                        cpt.exr_codec != sbp.exr_codec_cpts:
                            
                            row = box.row()
                            row.alert=True
                            text = f"Update {current_name} (!!not saved!!)"
                            row.operator("simplebake.cptex_add", text=text, icon="ADD")
                    else: #No changes, no button
                        text = f"Editing {current_name}"
                        row = box.row()
                        row.label(text=text)
                        row.alignment = 'CENTER'
                        
                else: #New item
                    row = box.row()
                    text = "Add new (!!not saved!!)"
                    row.alert = True
                    row.operator("simplebake.cptex_add", text=text, icon="ADD")
                    
                if sbp.cptex_R == "" or\
                    sbp.cptex_G == "" or\
                    sbp.cptex_B == "" or\
                    sbp.cptex_A == "":
                        row.enabled = False
            
                row=box.row()
                row.prop(sbp, "del_cptex_components")
                if sbp.copy_and_apply or sbp.apply_bakes_to_original:
                    row.enabled = False


            if sbp.channelpackfileformat != "OPEN_EXR":
                lines = [\
                    "Other formats MIGHT work, but the",\
                    "only way to get consistent, reliable",\
                    "channel packing in Blender is to use",\
                    "OpenEXR. Use OpenEXR if you can"]
                monkey_tip(lines, box)

    
    def draw_bake_buttons(self, context, box):
        
        sbp = context.scene.SimpleBake_Props
        row = box.row()
        row.scale_y = 1.5
        row.prop(sbp, "bgbake", expand=True)
        
        row = box.row()

        #Requesting Decals FG
        if sbp.bgbake == "fg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="decals":
            row.operator("simplebake.decals_operation", icon='RENDER_RESULT', text="Bake! (Decals)")

        #Requesting Decals BG
        elif sbp.bgbake == "bg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="decals":
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.decals_operation_background", icon='RENDER_RESULT', text="Bake! (Decals) (Background)")
            
        #Requesting Auto Match FG
        elif sbp.bgbake == "fg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
            row.operator("simplebake.automatch_operation", icon='RENDER_RESULT', text="Bake! (Auto Match)")

        #Requesting Auto Match BG
        elif sbp.bgbake == "bg" and (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.automatch_operation_background", icon='RENDER_RESULT', text="Bake! (Auto Match) (Background)")

        #Requesting PBR foreground
        elif sbp.bgbake == "fg" and sbp.global_mode == SBConstants.PBR and not sbp.selected_s2a:
            row.operator("simplebake.bake_operation_pbr", icon='RENDER_RESULT', text="Bake!")

        #Requesting PBR background
        elif sbp.bgbake == "bg" and sbp.global_mode == SBConstants.PBR and not sbp.selected_s2a:
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.bake_operation_pbr_background", icon='RENDER_RESULT', text="Bake! (in background)")
            disable_row_if_node_groups(row, box)

        #Requesting PBRS2A foreground
        elif sbp.bgbake == "fg" and sbp.global_mode == SBConstants.PBR and sbp.selected_s2a:
            row.operator("simplebake.bake_operation_pbrs2a", icon='RENDER_RESULT', text="Bake! (to target)")
        
        #Requesting  PBRS2A background
        elif sbp.bgbake == "bg" and sbp.global_mode == SBConstants.PBR and sbp.selected_s2a:
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.bake_operation_pbrs2a_background", icon='RENDER_RESULT', text="Bake! (in background)")
            disable_row_if_node_groups(row, box)
            #disable_row_if_auto_match(row, box)
            #disable_row_if_decals(row, box)
       
        #------------------------
        #Requesting CyclesBake foreground
        elif sbp.bgbake == "fg" and sbp.global_mode == SBConstants.CYCLESBAKE and not sbp.cycles_s2a:
            row.operator("simplebake.bake_operation_cyclesbake", icon='RENDER_RESULT', text="Bake!")
        #Requesting CyclesBake background
        elif sbp.bgbake == "bg" and sbp.global_mode == SBConstants.CYCLESBAKE and not sbp.cycles_s2a:
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.bake_operation_cyclesbake_background", icon='RENDER_RESULT', text="Bake! (in background)")
        #Requesting CyclesBake S2A foreground
        elif sbp.bgbake == "fg" and sbp.global_mode == SBConstants.CYCLESBAKE and sbp.cycles_s2a:
            row.operator("simplebake.bake_operation_cyclesbake_s2a", icon='RENDER_RESULT', text="Bake! (to target)")
        
        #Requesting CyclesBake S2A background
        elif sbp.bgbake == "bg" and sbp.global_mode == SBConstants.CYCLESBAKE and sbp.cycles_s2a:
            row.prop(sbp, "bgbake_name", text="Name: ")
            row = box.row()
            row.operator("simplebake.bake_operation_cyclesbake_s2a_background", icon='RENDER_RESULT', text="Bake! (in background)")
            disable_row_if_auto_match(row, box)
        
        row.scale_y = 2

        # p = False
        # for o in sbp.objects_list:
        #     if o != None and o.name not in bpy.context.view_layer.objects:
        #         p = True
        # 
        # if p:
        #     message_lines = [
        #         "One or more objects on the bake",
        #         "list don't exist in this view layer.",
        #         "They will be automatically removed",
        #         "from the list before bake"
        #         ]
        #     monkey_tip(message_lines, box)


        
            
    def draw_fg_bake_status(self, context, box):
        sbp = context.scene.SimpleBake_Props
        row=box.row()
        row.scale_y = 0.5
        row.alignment = 'CENTER'
        row.alert=True
        row.label(text="FOREGROUND BAKE")
        row=box.row()
        row.scale_y = 0.5
        row.alignment = 'CENTER'
        row.alert=True
        row.label(text="IN PROGRESS")
        row=box.row()
        row.scale_y = 0.5
        row.alignment = 'CENTER'
        row.label(text="Please wait")
        
        # row=box.row()
        # row.alignment = 'CENTER'
        # row.label(text=sbp.fg_status_message)
        
        row=box.row()
        row.alignment = 'CENTER'
        row.label(text=f"{sbp.percent_complete}% complete")
        
    def draw_background_bakes(self, context, box):
        sbp = context.scene.SimpleBake_Props
        
        active = BackgroundBakeTasks.active_tasks
        queued = BackgroundBakeTasks.queued_tasks
        completed = BackgroundBakeTasks.completed_tasks
        
        row = box.row()
        row.prop(sbp, "bg_status_show", text="Background bakes", icon="PROP_ON" if sbp.bg_status_show else "PROP_OFF", icon_only=False, emboss=False)
        
        if sbp.bg_status_show:
        
            row = box.row()
            row.label(text="Completed:")
            for bgt in completed:
                row = box.row()
                row.scale_y = 0.7
                row.label(text=f"{bgt.name} - finished", icon="GHOST_ENABLED")
                row.operator("simplebake.import_bgbake", icon='IMPORT', text = "").pid = str(bgt.pid)
                row.operator("simplebake.discard_bgbake", icon="CANCEL", text="").pid = str(bgt.pid)
            
            row = box.row()
            row.label(text="Active:")
            for bgt in active:
                row = box.row()
                row.scale_y = 0.7
                row.label(text=f"{bgt.name} - baking in progress {BackgroundBakeTasks.get_bgbake_status(bgt)}%", icon="GHOST_DISABLED")
                row.operator("simplebake.kill_active_bgbake", icon="CANCEL", text="").pid = str(bgt.pid)
                
            row = box.row()
            row.label(text="Queued:")
            for bgt in queued:
                row = box.row()
                row.scale_y = 0.7
                row.label(text=f"{bgt.name} - queued", icon="GHOST_DISABLED")
                row.operator("simplebake.delete_queued_bgbake", icon='CANCEL', text="").id = bgt.id
            
    def draw_sketchfab_upload(self, context, box):
        sbp = context.scene.SimpleBake_Props
        
        row = box.row()
        row.operator("simplebake.sketchfab_upload", icon='IMPORT', text = "Sketchfab Upload")
        
        return True
    
    def draw(self, context):
        sbp = context.scene.SimpleBake_Props
        
        layout = self.layout
        
        r = self.draw_version_info(context, layout)
        if not r:
            return False
        
        if not BakeInProgress.is_baking:
            box = layout.box()
            self.draw_global_mode_buttons(context, box)
            
            box = layout.box()
            self.draw_presets(context, box)
            
            box = layout.box()
            self.draw_objects_list(context, box)
            
            if sbp.global_mode == SBConstants.PBR:
                box = layout.box()
                self.draw_pbr_settings(context, box)
                
            if sbp.global_mode == SBConstants.CYCLESBAKE:
                box = layout.box()
                self.draw_cyclesbake_settings(context, box)
                
            box = layout.box()
            self.draw_specials_settings(context, box)
            
            box = layout.box()
            self.draw_texture_settings(context, box)
            
            box = layout.box()
            self.draw_export_settings(context, box)
            
            box = layout.box()
            self.draw_uv_settings(context, box)
            
            box = layout.box()
            self.draw_other_settings(context,box)
            
            if sbp.global_mode == SBConstants.PBR:
                box = layout.box()
                self.draw_channel_packing(context,box)
            
            box = layout.box()
            self.draw_bake_buttons(context, box)
        else:
            box = layout.box()
            self.draw_fg_bake_status(context, box)
        
        box = layout.box()
        self.draw_background_bakes(context, box)
        
        
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        if prefs.apikey != "":
            box = layout.box()
            self.draw_sketchfab_upload(context, box)


classes = ([
        SIMPLEBAKE_PT_main_panel
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
