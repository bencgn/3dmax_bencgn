import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, IntProperty
import bmesh
from pathlib import Path

from .utils import select_only_this, get_udim_set
from .messages import print_message

class SimpleBake_OT_Set_UDIM_Focus_Tile(Operator):
    bl_idname = "simplebake.set_udim_focus_tile"
    bl_label = "Set UDIM tile"
    
    target_object_name: StringProperty()
    desired_udim_tile: IntProperty()
    
    current_udim_tile_by_object = {}
    
    def shift_uvs(self, context):
        orig_active_object = bpy.context.active_object
        orig_selected_objects = bpy.context.selected_objects
        
        obj = bpy.data.objects[self.target_object_name]
        desired_udim_tile = (self.desired_udim_tile - 1) #As this is zero indexed
        
        select_only_this(obj)
        bpy.ops.object.mode_set(mode="EDIT", toggle=False)
    
        print_message(f"Shifting UDIM focus tile: Object: {obj.name} Tile: {desired_udim_tile}")
    
        if obj.name not in self.current_udim_tile_by_object:
            #Must be first time. Set to 0
            self.current_udim_tile_by_object[obj.name] = 0
        else:
            #Difference between desired and current
            tile_diff =  desired_udim_tile - self.current_udim_tile_by_object[obj.name]
    
            me = obj.data
            bm = bmesh.new()
            bm = bmesh.from_edit_mesh(me)

            uv_layer = bm.loops.layers.uv.verify()
            #bm.faces.layers.tex.verify()  # currently blender needs both layers.

            # scale UVs x2
            for f in bm.faces:
                for l in f.loops:
                    l[uv_layer].uv[0] -= tile_diff

            #bm.to_mesh(me)
            me.update()
            self.current_udim_tile_by_object[obj.name] = desired_udim_tile
    
        bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
    
        #Restore the original selected and active objects before we leave
        for o in orig_selected_objects:
            o.select_set(state=True)
        bpy.context.view_layer.objects.active = orig_active_object
    
        return True
    
    def shift_bake_image_node(self, context):
        
        obj = bpy.data.objects[self.target_object_name]
        for slot in obj.material_slots:
            mat = slot.material
            node_tree = mat.node_tree
            nodes = node_tree.nodes
            
            #Find our bake image node
            n = [n for n in nodes if "SB_bake_image_node" in n and n["SB_bake_image_node"] == True]
            assert(len(n)==1)
            n = n[0]
            img = n.image
            
            #Get udim set from existing image
            udim_set = get_udim_set(img)
            
            #Get the image node to the correct tile image
            n.image = udim_set[self.desired_udim_tile]
            print_message(f"Shifting to bake image to {n.image.name} for object {obj.name}")
            
    
    def execute(self, context):
        
        self.shift_uvs(context)
        self.shift_bake_image_node(context)
        
        return {'FINISHED'}

class SimpleBake_OT_Reload_UDIMS(Operator):
    bl_idname = "simplebake.reload_udims"
    bl_label = "Reload UDIM images"

    bake_operation_id: StringProperty()
    
    def execute(self, context):
        
        #Find any primary UDIM images that might exis
        primary_udims = ([i for i in bpy.data.images if "SB_udim_id" in i 
                            and i["SB_udim_secondary"] == False and
                            "SB_bake_operation_id" in i and i["SB_bake_operation_id"] ==
                            self.bake_operation_id])
        
        assert(len(primary_udims)>0)
        
        for primary_udim_image in primary_udims:
            print_message(f"Found primary udim image {primary_udim_image.name}")
            
            #Need enough for Copy and Apply operator to find us
            tags = {}
            tags["SB_bake_operation_id"] = primary_udim_image["SB_bake_operation_id"]
            tags["SB_this_bake"] = primary_udim_image["SB_this_bake"]
            tags["SB_bake_object"] = primary_udim_image["SB_bake_object"]
            tags["SB_merged_bake"] = primary_udim_image["SB_merged_bake"]
            tags["SB_merged_bake_name"] = primary_udim_image["SB_merged_bake_name"]
            tags["SB_global_mode"] = primary_udim_image["SB_global_mode"]

            #Get the full save path we stored in external_save (Blender is using a relative path)
            file_path = Path(primary_udim_image["SB_full_save_path"])
            
            udim_set = list(get_udim_set(primary_udim_image).values())
            for udim in udim_set:
                bpy.data.images.remove(udim)
            
            #We need to get the file name and the save folder manually, unfortunately...
            save_folder = file_path.parents[0]
            file_name = file_path.parts[-1]
            
            #Possible Blender bug? (pre-check)
            for i in bpy.data.images:
                if "<UDIM>" in i.name:
                    i.name = i.name.replace("<UDIM>", "1001")
            
            [bpy.data.images.remove(i) for i in bpy.data.images if i.name == file_name]
            
            bpy.ops.image.open(filepath=str(save_folder / file_name), directory=str(save_folder), use_udim_detecting=True, relative_path=True)
            
            #Possible Blender bug? (post_check)
            for i in bpy.data.images:
                if "<UDIM>" in i.name:
                    i.name = i.name.replace("<UDIM>", "1001")
            
            
            img = bpy.data.images[file_name]
            for t in tags:
                img[t] = tags[t]
        
        return {'FINISHED'}
    

classes = ([
    SimpleBake_OT_Set_UDIM_Focus_Tile,
    SimpleBake_OT_Reload_UDIMS
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)


