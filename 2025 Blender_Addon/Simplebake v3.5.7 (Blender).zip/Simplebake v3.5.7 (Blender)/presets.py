import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

import os
import json
from pathlib import Path

from .utils import clean_file_name, SBConstants, show_message_box
from .messages import print_message

class SimpleBake_OT_preset_save(Operator):
    """Save current SimpleBake settings to preset"""
    bl_idname = "simplebake.preset_save"
    bl_label = "Save"

    @classmethod
    def poll(cls,context):
        sbp = context.scene.SimpleBake_Props
        return sbp.preset_name != ""

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props

        if sbp.preset_name != clean_file_name(sbp.preset_name):
            message_items = ["ERROR: Preset name can only contain characters that",
                             "are valid for the external file system"]
            show_message_box(message_items, "ERROR", icon = "ERROR")
            return {'CANCELLED'}

        d = {}

        #SimpleBake internal
        d["global_mode"] = sbp.global_mode
        d["ray_distance"] = sbp.ray_distance
        d["cage_extrusion"] = sbp.cage_extrusion
        d["auto_match_mode"] = sbp.auto_match_mode
        d["selected_s2a"] = sbp.selected_s2a
        d["s2a_opmode"] = sbp.s2a_opmode
        d["merged_bake"] = sbp.merged_bake
        d["merged_bake_name"] = sbp.merged_bake_name
        d["cycles_s2a"] = sbp.cycles_s2a
        d["imgheight"] = sbp.imgheight
        d["imgwidth"] = sbp.imgwidth
        d["outputheight"] = sbp.outputheight
        d["outputwidth"] = sbp.outputwidth
        d["everything32bitfloat"] = sbp.everything32bitfloat
        d["use_alpha"] = sbp.use_alpha
        d["rough_glossy_switch"] = sbp.rough_glossy_switch
        d["normal_format_switch"] = sbp.normal_format_switch
        d["tex_per_mat"] = sbp.tex_per_mat
        d["selected_col"] = sbp.selected_col
        d["selected_metal"] = sbp.selected_metal
        d["selected_rough"] = sbp.selected_rough
        d["selected_normal"] = sbp.selected_normal
        d["selected_trans"] = sbp.selected_trans
        d["selected_transrough"] = sbp.selected_transrough
        d["selected_emission"] = sbp.selected_emission
        d["selected_emission_strength"] = sbp.selected_emission_strength
        d["selected_sss"] = sbp.selected_sss
        d["selected_ssscol"] = sbp.selected_ssscol
        d["selected_clearcoat"] = sbp.selected_clearcoat
        d["selected_clearcoat_rough"] = sbp.selected_clearcoat_rough
        d["selected_specular"] = sbp.selected_specular
        d["selected_alpha"] = sbp.selected_alpha
        d["selected_col_mats"] = sbp.selected_col_mats
        d["selected_col_vertex"] = sbp.selected_col_vertex
        d["selected_ao"] = sbp.selected_ao
        d["selected_thickness"] = sbp.selected_thickness
        d["selected_curvature"] = sbp.selected_curvature
        d["selected_lightmap"] = sbp.selected_lightmap
        d["lightmap_apply_colman"] = sbp.lightmap_apply_colman
        d["new_uv_option"] = sbp.new_uv_option
        d["prefer_existing_sbmap"] = sbp.prefer_existing_sbmap
        d["new_uv_method"] = sbp.new_uv_method
        d["restore_orig_uv_map"] = sbp.restore_orig_uv_map
        d["uvpackmargin"] = sbp.uvpackmargin
        d["average_uv_size"] = sbp.average_uv_size
        d["expand_mat_uvs"] = sbp.expand_mat_uvs
        d["uv_mode"] = sbp.uv_mode
        d["udim_tiles"] = sbp.udim_tiles
        d["unwrapmargin"] = sbp.unwrapmargin
        d["channelpackfileformat"] = sbp.channelpackfileformat
        d["del_cptex_components"] = sbp.del_cptex_components
        d["save_bakes_external"] = sbp.save_bakes_external
        d["export_folder_per_object"] = sbp.export_folder_per_object
        d["export_format"] = sbp.export_format
        d["jpeg_quality"] = sbp.jpeg_quality
        d["save_obj_external"] = sbp.save_obj_external
        d["fbx_name"] = sbp.fbx_name
        d["gltf_name"] = sbp.gltf_name
        d["copy_and_apply"] = sbp.copy_and_apply
        d["apply_bakes_to_original"] = sbp.apply_bakes_to_original
        d["hide_source_objects"] = sbp.hide_source_objects
        d["hide_cage_object"] = sbp.hide_cage_object
        d["preserve_materials"] = sbp.preserve_materials
        d["everything_16bit"] = sbp.everything_16bit
        d["export_file_format"] = sbp.export_file_format
        #d["save_external_folder"] = sbp.save_external_folder
        d["apply_col_man_to_col"] = sbp.apply_col_man_to_col
        d["export_cycles_col_space"] = sbp.export_cycles_col_space
        #d["folder_date_time"] = sbp.folder_date_time
        d["rundenoise"] = sbp.rundenoise
        d["apply_mods_on_mesh_export"] = sbp.apply_mods_on_mesh_export
        d["objects_list_index"] = sbp.objects_list_index
        d["bgbake"] = sbp.bgbake
        d["memLimit"] = sbp.memLimit
        d["batch_name"] = sbp.batch_name
        d["first_texture_show"] = sbp.first_texture_show
        d["bgbake_name"] = sbp.bgbake_name
        d["apply_transformation"] = sbp.apply_transformation
        d["create_glTF_node"] = sbp.create_glTF_node
        d["glTF_selection"] = sbp.glTF_selection
        d["export_path"] = sbp.export_path
        d["move_new_uvs_to_top"] = sbp.move_new_uvs_to_top
        d["selected_displacement"] = sbp.selected_displacement
        d["cyclesbake_cs"] = sbp.cyclesbake_cs
        d["fbx_preset_name"] = sbp.fbx_preset_name
        d["gltf_preset_name"] = sbp.gltf_preset_name
        d["cyclesbake_copy_and_apply_mat_format"] = sbp.cyclesbake_copy_and_apply_mat_format
        #d["preset_load_clear_obj"] = sbp.preset_load_clear_obj
        d["clear_image"] = sbp.clear_image
        d["cage_smooth_hard"] = sbp.cage_smooth_hard
        d["boosted_sample_count"] = sbp.boosted_sample_count
        d["no_force_32bit_normals"] = sbp.no_force_32bit_normals
        d["keep_internal_after_export"] = sbp.keep_internal_after_export
        d["ao_sample_count"] = sbp.ao_sample_count
        d["isolate_objects"] = sbp.isolate_objects

        #UV packing settings
        d["uv_advanced_packing_show"] = sbp.uv_advanced_packing_show
        d["uvp_shape_method"] = sbp.uvp_shape_method
        d["uvp_scale"] = sbp.uvp_scale
        d["uvp_rotate"] = sbp.uvp_rotate
        d["uvp_rotation_method"] = sbp.uvp_rotation_method
        d["uvp_margin_method"] = sbp.uvp_margin_method
        d["uvp_lock_pinned"] = sbp.uvp_lock_pinned
        d["uvp_lock_method"] = sbp.uvp_lock_method
        d["uvp_merge_overlapping"] = sbp.uvp_merge_overlapping
        d["uvp_pack_to"] = sbp.uvp_pack_to

        #Non SimpleBake settings
        d["bake_type"] = bpy.context.scene.cycles.bake_type
        d["use_pass_direct"] = bpy.context.scene.render.bake.use_pass_direct
        d["use_pass_indirect"] = bpy.context.scene.render.bake.use_pass_indirect
        d["use_pass_diffuse"] = bpy.context.scene.render.bake.use_pass_diffuse
        d["use_pass_glossy"] = bpy.context.scene.render.bake.use_pass_glossy
        d["use_pass_transmission"] = bpy.context.scene.render.bake.use_pass_transmission
        d["use_pass_emit"] = bpy.context.scene.render.bake.use_pass_emit
        d["cycles.samples"] = bpy.context.scene.cycles.samples
        d["bake.normal_space"] = bpy.context.scene.render.bake.normal_space
        d["render.bake.normal_r"] = bpy.context.scene.render.bake.normal_r
        d["render.bake.normal_g"] = bpy.context.scene.render.bake.normal_g
        d["render.bake.normal_b"] = bpy.context.scene.render.bake.normal_b
        d["use_pass_color"] = bpy.context.scene.render.bake.use_pass_color
        d["bake.margin"] = bpy.context.scene.render.bake.margin
        d["bake.margin_type"] = bpy.context.scene.render.bake.margin_type
        d["exr_codec"] = bpy.context.scene.render.image_settings.exr_codec
        d["cycles_denoise"] = bpy.context.scene.cycles.use_denoising
        d["cycles_denoiser"] = bpy.context.scene.cycles.denoiser
        d["cycles_denoising_input_passes"] = bpy.context.scene.cycles.denoising_input_passes
        d["cycles_denoising_prefilter"] = bpy.context.scene.cycles.denoising_prefilter

        #Show/Hide
        d["showtips"] = sbp.showtips
        d["presets_show"] = sbp.presets_show
        d["bake_objects_show"] = sbp.bake_objects_show
        d["pbr_settings_show"] = sbp.pbr_settings_show
        d["cyclesbake_settings_show"] = sbp.cyclesbake_settings_show
        d["specials_show"] = sbp.specials_show
        d["textures_show"] = sbp.textures_show
        d["export_show"] = sbp.export_show
        d["uv_show"] = sbp.uv_show
        d["other_show"] = sbp.other_show
        d["channelpacking_show"] = sbp.channelpacking_show
        d["bg_status_show"] = sbp.bg_status_show


        #Grab the objects in the advanced list (if any)
        d["objects_list"] = [o.name for o in sbp.objects_list]
        #Grab the target objects if there is one
        if sbp.targetobj != None:
            d["pbr_target_obj"] =  sbp.targetobj.name
        else:
            d["pbr_target_obj"] = None
        if sbp.targetobj_cycles != None:
            d["cycles_target_obj"] = sbp.targetobj_cycles.name
        else:
            d["cycles_target_obj"] = None
        #Cage object if there is one
        if bpy.context.scene.render.bake.cage_object != None:
            d["cage_object"] = bpy.context.scene.render.bake.cage_object.name
        else:
            d["cage_object"] = None

        #Channel packed images
        cp_images_dict = {}
        for cpt in sbp.cp_list:
            thiscpt_dict = {}
            thiscpt_dict["R"] = cpt.R
            thiscpt_dict["G"] = cpt.G
            thiscpt_dict["B"] = cpt.B
            thiscpt_dict["A"] = cpt.A

            thiscpt_dict["file_format"] = cpt.file_format
            thiscpt_dict["exr_codec"] = cpt.exr_codec

            cp_images_dict[cpt.name] = thiscpt_dict
        if len(cp_images_dict)>0:
            d["channel_packed_images"] = cp_images_dict

        #Find where we want to save
        p = Path(bpy.utils.script_path_user())
        p = p.parents[1]
        p = p / "data" / "SimpleBake"
        savename = clean_file_name(sbp.preset_name)

        if not os.path.isdir(str(p)):
            os.makedirs(str(p))

        print_message(f"Saving preset to {str(p)}")

        jsonString = json.dumps(d)
        jsonFile = open(str(p / savename), "w")
        jsonFile.write(jsonString)
        jsonFile.close()

        #Refreh the list
        bpy.ops.simplebake.preset_refresh()

        self.report({"INFO"}, "Preset saved")
        return {'FINISHED'}

class SimpleBake_OT_preset_load(Operator):
    """Load selected SimpleBake preset"""
    bl_idname = "simplebake.preset_load"
    bl_label = "Load"

    @classmethod
    def poll(cls,context):
        sbp = context.scene.SimpleBake_Props
        try:
            sbp.presets_list[sbp.presets_list_index].name
            return True
        except:
            return False

    def legacy_fixes(self, context, d):
        sbp = context.scene.SimpleBake_Props
        if d["global_mode"] == "pbr_bake": d["global_mode"] = SBConstants.PBR
        if d["global_mode"] == "cycles_bake": d["global_mode"] = SBConstants.CYCLESBAKE

        if d["rough_glossy_switch"] == "rough": d["rough_glossy_switch"] = SBConstants.PBR_ROUGHNESS
        if d["rough_glossy_switch"] == "glossy": d["rough_glossy_switch"] = SBConstants.PBR_GLOSSY
        if d["normal_format_switch"] == "opengl": d["normal_format_switch"] = SBConstants.NORMAL_OPENGL
        if d["normal_format_switch"] == "directx": d["normal_format_switch"] = SBConstants.NORMAL_DIRECTX

        if "mergedBake" in d: d["merged_bake"] = d["mergedBake"]
        if "mergedBakeName" in d: d["merged_bake_name"] = d["mergedBakeName"]
        if "useAlpha" in d: d["use_alpha"] = d["useAlpha"]
        if "newUVoption" in d: d["new_uv_option"] = d["newUVoption"]
        if "newUVmethod" in d: d["new_uv_method"] = d["newUVmethod"]
        if "restoreOrigUVmap" in d: d["restore_orig_uv_map"] = d["restoreOrigUVmap"]
        if "averageUVsize" in d: d["average_uv_size"] = d["averageUVsize"]
        if "saveExternal" in d: d["save_bakes_external"] = d["saveExternal"]
        if "exportFolderPerObject" in d: d["export_folder_per_object"] = d["exportFolderPerObject"]
        if "saveObj" in d: d["save_obj_external"] = d["saveObj"]
        if "fbxName" in d: d["fbx_name"] = d["fbxName"]
        #if "saveFolder" in d: d["save_external_folder"] = d["saveFolder"]
        #if "folderdatetime" in d: d["folder_date_time"] = d["folderdatetime"]
        if "applymodsonmeshexport" in d: d["apply_mods_on_mesh_export"] = d["applymodsonmeshexport"]
        if "bakeobjs_advanced_list_index" in d: d["objects_list_index"] = d["bakeobjs_advanced_list_index"]
        if "batchName" in d: d["batch_name"] = d["batchName"]
        if "object_list" in d: d["objects_list"] = d["object_list"]
        if "hidesourceobjects" in d: d["hide_source_objects"] = d["hidesourceobjects"]
        if "everything16bit" in d: d["everything_16bit"] =  d["everything16bit"]
        if "exportfileformat" in d: d["export_file_format"] = d["exportfileformat"]
        if "selected_applycolmantocol" in d: d["apply_col_man_to_col"] = d["selected_applycolmantocol"]
        if "exportcyclescolspace" in d: d["export_cycles_col_space"] = d["exportcyclescolspace"]
        if "applytransformation" in d: d["apply_transformation"] = d["applytransformation"]

        return d

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        s = bpy.context.scene

        #Load it
        loadname = clean_file_name(sbp.presets_list[sbp.presets_list_index].name)

        p = Path(bpy.utils.script_path_user())
        p = p.parents[1]
        p = p /  "data" / "SimpleBake" / loadname

        print_message(f"Loading preset from {str(p)}")

        try:
            fileObject = open(str(p), "r")
        except:
            bpy.ops.simplebake.preset_refresh()
            self.report({"ERROR"}, f"Preset {loadname} no longer exists")
            return {'CANCELLED'}


        json_content = fileObject.read()
        d = json.loads(json_content)

        #Fix legacy names
        d = self.legacy_fixes(context, d)

        #SimpleBake internal
        try: sbp.global_mode = d["global_mode"]
        except Exception as e: print(e)
        try: sbp.ray_distance = d["ray_distance"]
        except Exception as e: print(e)
        try: sbp.cage_extrusion = d["cage_extrusion"]
        except Exception as e: print(e)
        try: sbp.selected_s2a = d["selected_s2a"]
        except Exception as e: print(e)
        try: sbp.s2a_opmode = d["s2a_opmode"]
        except Exception as e: print(e)
        try: sbp.merged_bake = d["merged_bake"]
        except Exception as e: print(e)
        try: sbp.merged_bake_name = d["merged_bake_name"]
        except Exception as e: print(e)
        try: sbp.cycles_s2a = d["cycles_s2a"]
        except Exception as e: print(e)
        try: sbp.auto_match_mode = d["auto_match_mode"]
        except Exception as e: print(e)
        try: sbp.imgheight = d["imgheight"]
        except Exception as e: print(e)
        try: sbp.imgwidth = d["imgwidth"]
        except Exception as e: print(e)
        try: sbp.outputheight = d["outputheight"]
        except Exception as e: print(e)
        try: sbp.outputwidth = d["outputwidth"]
        except Exception as e: print(e)
        try: sbp.everything32bitfloat = d["everything32bitfloat"]
        except Exception as e: print(e)
        try: sbp.use_alpha = d["use_alpha"]
        except Exception as e: print(e)
        try: sbp.rough_glossy_switch = d["rough_glossy_switch"]
        except Exception as e: print(e)
        try: sbp.normal_format_switch = d["normal_format_switch"]
        except Exception as e: print(e)
        try: sbp.tex_per_mat = d["tex_per_mat"]
        except Exception as e: print(e)
        try: sbp.selected_col = d["selected_col"]
        except Exception as e: print(e)
        try: sbp.selected_metal = d["selected_metal"]
        except Exception as e: print(e)
        try: sbp.selected_rough = d["selected_rough"]
        except Exception as e: print(e)
        try: sbp.selected_normal = d["selected_normal"]
        except Exception as e: print(e)
        try: sbp.selected_trans = d["selected_trans"]
        except Exception as e: print(e)
        try: sbp.selected_transrough = d["selected_transrough"]
        except Exception as e: print(e)
        try: sbp.selected_emission = d["selected_emission"]
        except Exception as e: print(e)
        try: sbp.selected_emission_strength = d["selected_emission_strength"]
        except Exception as e: print(e)
        try: sbp.selected_sss = d["selected_sss"]
        except Exception as e: print(e)
        try: sbp.selected_ssscol = d["selected_ssscol"]
        except Exception as e: print(e)
        try: sbp.selected_clearcoat = d["selected_clearcoat"]
        except Exception as e: print(e)
        try: sbp.selected_clearcoat_rough = d["selected_clearcoat_rough"]
        except Exception as e: print(e)
        try: sbp.selected_specular = d["selected_specular"]
        except Exception as e: print(e)
        try: sbp.selected_alpha = d["selected_alpha"]
        except Exception as e: print(e)
        try: sbp.selected_col_mats = d["selected_col_mats"]
        except Exception as e: print(e)
        try: sbp.selected_col_vertex = d["selected_col_vertex"]
        except Exception as e: print(e)
        try: sbp.selected_ao = d["selected_ao"]
        except Exception as e: print(e)
        try: sbp.selected_thickness = d["selected_thickness"]
        except Exception as e: print(e)
        try: sbp.selected_curvature = d["selected_curvature"]
        except Exception as e: print(e)
        try: sbp.selected_lightmap = d["selected_lightmap"]
        except Exception as e: print(e)
        try: sbp.lightmap_apply_colman = d["lightmap_apply_colman"]
        except Exception as e: print(e)
        try: sbp.new_uv_option = d["new_uv_option"]
        except Exception as e: print(e)
        try: sbp.new_uv_method = d["new_uv_method"]
        except Exception as e: print(e)
        try: sbp.restore_orig_uv_map = d["restore_orig_uv_map"]
        except Exception as e: print(e)
        try: sbp.uvpackmargin = d["uvpackmargin"]
        except Exception as e: print(e)
        try: sbp.average_uv_size = d["average_uv_size"]
        except Exception as e: print(e)
        try: sbp.expand_mat_uvs = d["expand_mat_uvs"]
        except Exception as e: print(e)
        try: sbp.uv_mode = d["uv_mode"]
        except Exception as e: print(e)
        try: sbp.udim_tiles = d["udim_tiles"]
        except Exception as e: print(e)
        try: sbp.unwrapmargin = d["unwrapmargin"]
        except Exception as e: print(e)
        try: sbp.channelpackfileformat = d["channelpackfileformat"]
        except Exception as e: print(e)
        try: sbp.del_cptex_components = d["del_cptex_components"]
        except Exception as e: print(e)
        try: sbp.save_bakes_external = d["save_bakes_external"]
        except Exception as e: print(e)
        try: sbp.export_folder_per_object = d["export_folder_per_object"]
        except Exception as e: print(e)
        try: sbp.export_format = d["export_format"]
        except Exception as e: print(e)
        try: sbp.jpeg_quality = d["jpeg_quality"]
        except Exception as e: print(e)
        try: sbp.save_obj_external = d["save_obj_external"]
        except Exception as e: print(e)
        try: sbp.fbx_name = d["fbx_name"]
        except Exception as e: print(e)
        try: sbp.gltf_name = d["gltf_name"]
        except Exception as e: print(e)
        try: sbp.copy_and_apply = d["copy_and_apply"]
        except Exception as e: print(e)
        try: sbp.apply_bakes_to_original = d["apply_bakes_to_original"]
        except Exception as e: print(e)
        try: sbp.hide_source_objects = d["hide_source_objects"]
        except Exception as e: print(e)
        try: sbp.hide_cage_object = d["hide_cage_object"]
        except Exception as e: print(e)
        try: sbp.preserve_materials = d["preserve_materials"]
        except Exception as e: print(e)
        try: sbp.everything_16bit = d["everything_16bit"]
        except Exception as e: print(e)
        try: sbp.export_file_format = d["export_file_format"]
        except Exception as e: print(e)
        #try: sbp.save_external_folder = d["save_external_folder"]
        #except Exception as e: print(e)
        try: sbp.apply_col_man_to_col = d["apply_col_man_to_col"]
        except Exception as e: print(e)
        try: sbp.export_cycles_col_space = d["export_cycles_col_space"]
        except Exception as e: print(e)
        #try: sbp.folder_date_time = d["folder_date_time"]
        #except Exception as e: print(e)
        try: sbp.rundenoise = d["rundenoise"]
        except Exception as e: print(e)
        try: sbp.apply_mods_on_mesh_export = d["apply_mods_on_mesh_export"]
        except Exception as e: print(e)
        try: sbp.objects_list_index = d["objects_list_index"]
        except Exception as e: print(e)
        try: sbp.bgbake = d["bgbake"]
        except Exception as e: print(e)
        try: sbp.batch_name = d["batch_name"]
        except Exception as e: print(e)
        try: sbp.first_texture_show = d["first_texture_show"]
        except Exception as e: print(e)
        try: sbp.bgbake_name = d["bgbake_name"]
        except Exception as e: print(e)
        try: sbp.prefer_existing_sbmap = d["prefer_existing_sbmap"]
        except Exception as e: print(e)
        try: sbp.apply_transformation = d["apply_transformation"]
        except Exception as e: print(e)
        try: sbp.memLimit = d["memLimit"]
        except Exception as e: print(e)
        try: sbp.create_glTF_node = d["create_glTF_node"]
        except Exception as e: print(e)
        try: sbp.glTF_selection = d["glTF_selection"]
        except Exception as e: print(e)
        try: sbp.export_path = d["export_path"]
        except Exception as e: print(e)
        try: sbp.move_new_uvs_to_top = d["move_new_uvs_to_top"]
        except Exception as e: print(e)
        try: sbp.selected_displacement = d["selected_displacement"]
        except Exception as e: print(e)
        try: sbp.cyclesbake_cs = d["cyclesbake_cs"]
        except Exception as e: print(e)
        try: sbp.fbx_preset_name = d["fbx_preset_name"]
        except Exception as e: print(e)
        try: sbp.gltf_preset_name = d["gltf_preset_name"]
        except Exception as e: print(e)
        try: sbp.cyclesbake_copy_and_apply_mat_format = d["cyclesbake_copy_and_apply_mat_format"]
        except Exception as e: print(e)
        #try: sbp.preset_load_clear_obj = d["preset_load_clear_obj"]
        #except Exception as e: print(e)
        try: sbp.clear_image = d["clear_image"]
        except Exception as e: print(e)
        try: sbp.cage_smooth_hard = d["cage_smooth_hard"]
        except Exception as e: print(e)
        try: sbp.boosted_sample_count = d["boosted_sample_count"]
        except Exception as e: print(e)
        try: sbp.no_force_32bit_normals = d["no_force_32bit_normals"]
        except Exception as e: print(e)
        try: sbp.keep_internal_after_export = d["keep_internal_after_export"]
        except Exception as e: print(e)
        try: sbp.ao_sample_count = d["ao_sample_count"]
        except Exception as e: print(e)
        try: sbp.isolate_objects = d["isolate_objects"]
        except Exception as e: print(e)



        try: sbp.uv_advanced_packing_show = d["uv_advanced_packing_show"]
        except Exception as e: print(e)
        try: sbp.uvp_shape_method = d["uvp_shape_method"]
        except Exception as e: print(e)
        try: sbp.uvp_scale = d["uvp_scale"]
        except Exception as e: print(e)
        try: sbp.uvp_rotate = d["uvp_rotate"]
        except Exception as e: print(e)
        try: sbp.uvp_rotation_method = d["uvp_rotation_method"]
        except Exception as e: print(e)
        try: sbp.uvp_margin_method = d["uvp_margin_method"]
        except Exception as e: print(e)
        try: sbp.uvp_lock_pinned = d["uvp_lock_pinned"]
        except Exception as e: print(e)
        try: sbp.uvp_lock_method = d["uvp_lock_method"]
        except Exception as e: print(e)
        try: sbp.uvp_merge_overlapping = d["uvp_merge_overlapping"]
        except Exception as e: print(e)
        try: sbp.uvp_pack_to = d["uvp_pack_to"]
        except Exception as e: print(e)

        #Non-SimpleBake Settings
        try: s.cycles.bake_type = d["bake_type"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_direct = d["use_pass_direct"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_indirect = d["use_pass_indirect"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_diffuse = d["use_pass_diffuse"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_glossy = d["use_pass_glossy"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_transmission = d["use_pass_transmission"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_emit = d["use_pass_emit"]
        except Exception as e: print(e)
        try: s.cycles.samples = d["cycles.samples"]
        except Exception as e: print(e)
        try: s.render.bake.normal_space = d["bake.normal_space"]
        except Exception as e: print(e)
        try: s.render.bake.normal_r = d["render.bake.normal_r"]
        except Exception as e: print(e)
        try: s.render.bake.normal_g = d["render.bake.normal_g"]
        except Exception as e: print(e)
        try: s.render.bake.normal_b = d["render.bake.normal_b"]
        except Exception as e: print(e)
        try: s.render.bake.use_pass_color = d["use_pass_color"]
        except Exception as e: print(e)
        try: s.render.bake.margin = d["bake.margin"]
        except Exception as e: print(e)
        try: s.render.bake.margin_type = d["bake.margin_type"]
        except Exception as e: print(e)
        try: s.cycles.use_denoising = d["cycles_denoise"]
        except Exception as e: print(e)
        try: s.cycles.denoiser = d["cycles_denoiser"]
        except Exception as e: print(e)
        try: s.cycles.denoising_input_passes = d["cycles_denoising_input_passes"]
        except Exception as e: print(e)
        try: s.cycles.denoising_prefilter = d["cycles_denoising_prefilter"]
        except Exception as e: print(e)
        try: s.render.image_settings.exr_codec = d["exr_codec"]
        except Exception as e: print(e)

        #Show/Hide
        try: sbp.showtips = d["showtips"]
        except Exception as e: print(e)
        try: sbp.presets_show = d["presets_show"]
        except Exception as e: print(e)
        try: sbp.bake_objects_show = d["bake_objects_show"]
        except Exception as e: print(e)
        try: sbp.pbr_settings_show = d["pbr_settings_show"]
        except Exception as e: print(e)
        try: sbp.cyclesbake_settings_show = d["cyclesbake_settings_show"]
        except Exception as e: print(e)
        try: sbp.specials_show = d["specials_show"]
        except Exception as e: print(e)
        try: sbp.textures_show = d["textures_show"]
        except Exception as e: print(e)
        try: sbp.export_show = d["export_show"]
        except Exception as e: print(e)
        try: sbp.uv_show = d["uv_show"]
        except Exception as e: print(e)
        try: sbp.other_show = d["other_show"]
        except Exception as e: print(e)
        try: sbp.channelpacking_show = d["channelpacking_show"]
        except Exception as e: print(e)
        try: sbp.bg_status_show = d["bg_status_show"]
        except Exception as e: print(e)




        #Channel packing images
        sbp.cp_list.clear()


        if "channel_packed_images" in d:
            channel_packed_images = d["channel_packed_images"]

            if len(channel_packed_images) > 0:
                sbp.cp_list.clear()

            for imgname in channel_packed_images:

                thiscpt_dict = channel_packed_images[imgname]

                #Create the list item
                li = sbp.cp_list.add()
                li.name = imgname

                #Set the list item properies
                li.R = thiscpt_dict["R"]
                li.G = thiscpt_dict["G"]
                li.B = thiscpt_dict["B"]
                li.A = thiscpt_dict["A"]

                li.file_format = thiscpt_dict["file_format"]
                li.exr_codec = thiscpt_dict["exr_codec"]


        #Refresh the set values in the packed textures list (so it doesn't look like it hasn't been saved)
        #Go to first item (just in case the preset loads fewer than we already had
        if len(sbp.cp_list) > 0:
            sbp.cp_list_index = 0


        #And now the objects, if they are here

        #Clear list if that was asked for
        if sbp.preset_load_clear_obj:
            sbp.objects_list.clear()

            for obj_name in d["objects_list"]:
                if obj_name in bpy.data.objects:
                    #Find where name attribute of each object in the advanced selection list matches the name
                    l = [o.name for o in sbp.objects_list if o.name == obj_name]
                    if len(l) == 0:
                        #Not already in the list
                        i = sbp.objects_list.add()
                        i.name = obj_name #Advanced object list has a name and pointers arritbute
                        i.obj_point = bpy.data.objects[obj_name]

            if d["pbr_target_obj"] != None and d["pbr_target_obj"] in bpy.data.objects:
                sbp.targetobj = bpy.data.objects[d["pbr_target_obj"]]
            if d["cycles_target_obj"] != None and d["cycles_target_obj"] in bpy.data.objects:
                sbp.targetobj_cycles = bpy.data.objects[d["cycles_target_obj"]]
            #Cage object
            if d["cage_object"] != None and d["cage_object"] in bpy.data.objects:
                bpy.context.scene.render.bake.cage_object = bpy.data.objects[d["cage_object"]]


        self.report({"INFO"}, f"Preset {loadname} loaded")

        return {'FINISHED'}

classes = ([
    SimpleBake_OT_preset_load,
    SimpleBake_OT_preset_save
        ])

def register():

    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
