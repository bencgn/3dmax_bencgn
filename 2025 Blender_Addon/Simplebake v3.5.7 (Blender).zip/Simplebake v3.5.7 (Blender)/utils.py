import bpy
from bpy.types import Operator, Macro
from bpy.props import StringProperty, BoolProperty
from bpy.utils import register_class, unregister_class
import sys
from pathlib import Path
import base64
import mathutils


def find_closest_obj(object_name, max_distance=0.5):

    ref_obj = bpy.data.objects.get(object_name)
    if not ref_obj:
        raise ValueError(f"No object found with the name '{object_name}'")

    closest_mesh = None
    closest_distance = float('inf')

    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH' and obj != ref_obj:
            distance = (ref_obj.location - obj.location).length
            if distance < closest_distance:
                closest_distance = distance
                closest_mesh = obj

    return closest_mesh if closest_distance <= max_distance else None


def custom_exception_hook(exc_type, exc_value, exc_traceback):

    text_name = "SB_Crash_Log"

    print("SIMPLEBAKE HAS CRASHED!!!")

    if text_name in bpy.data.texts:
        bpy.data.texts.remove(bpy.data.texts[text_name])
    t = bpy.data.texts.new(text_name)

    filename = exc_traceback.tb_frame.f_code.co_filename
    lineno = exc_traceback.tb_lineno
    t.write(
        f"SIMPLEBAKE HAS CRASHED :-(\n"
        "Please contact the developer via Blender Market and provide the below information\n\n"
        f"Exception file: {filename}\n"
        f"Exception line: {lineno}\n"
        f"Exception type: {exc_type}\n"
        f"Exception value: {exc_value}\n"
        f"Exception traceback: {exc_traceback}\n"
    )

    print("Go to the Scripting tab and open text file \"SB_Crash_Log\"")

    #Restore the original system exception handler
    sys.excepthook = sys.__excepthook__


class SBConstants:
    
    #Constants
    PBR = "PBR"
    PBRS2A = "PBR StoA"
    PBRS2A_AUTOMATCH = "PBR StoA AutoMatch"
    PBRS2A_DECALS = "PBR StoA Decals"
    CYCLESBAKE = "CyclesBake"
    CYCLESBAKE_S2A = "CyclesBake S2A"
    CYCLESBAKES2A_AUTOMATCH = "CyclesBake S2A Auto"
    SPECIALS = "Specials"
    SPECIALS_PBR_TARGET_ONLY = "specials_pbr_targetonly"
    SPECIALS_CYCLES_TARGET_ONLY = "specials_cycles_targetonly"

    
    #PBR Names
    PBR_DIFFUSE = "Diffuse"
    PBR_METAL = "Metalness"
    PBR_SSS = "SSS"
    PBR_SSSCOL = "SSS Colour"
    PBR_ROUGHNESS = "Roughness"
    PBR_GLOSSY = "Glossiness"
    PBR_NORMAL = "Normal"
    PBR_TRANSMISSION = "Transmission"
    PBR_TRANSMISSION_ROUGH = "Transmission Roughness"
    PBR_CLEARCOAT = "Clearcoat"
    PBR_CLEARCOAT_ROUGH = "Clearcoat Roughness"
    PBR_EMISSION = "Emission"
    PBR_EMISSION_STRENGTH = "Emission Strength"
    PBR_SPECULAR = "Specular"
    PBR_ALPHA = "Alpha"
    PBR_DISPLACEMENT = "Bump"
    
    ALL_PBR_MODES = ([PBR_DIFFUSE, PBR_METAL, PBR_SSS, PBR_SSSCOL, PBR_ROUGHNESS, PBR_GLOSSY,
                      PBR_NORMAL, PBR_TRANSMISSION, PBR_TRANSMISSION_ROUGH, PBR_CLEARCOAT,
                      PBR_CLEARCOAT_ROUGH, PBR_EMISSION, PBR_EMISSION_STRENGTH, PBR_SPECULAR, PBR_ALPHA, PBR_DISPLACEMENT])
    
    #Specials names
    THICKNESS = "Thickness"
    AO = "Ambient Occlusion"
    CURVATURE = "Curvature"
    COLOURID = "Colour ID"
    VERTEXCOL = "Vertex Colour"
    LIGHTMAP = "Lightmap"
    
    ALL_SPECIALS = ([THICKNESS, AO, CURVATURE,COLOURID, VERTEXCOL, LIGHTMAP])
    
    #UVs
    NEWUV_SMART_INDIVIDUAL = "SmartUVProject_Individual"
    NEWUV_SMART_ATLAS = "SmartUVProject_Atlas"
    NEWUV_COMBINE_EXISTING = "CombineExisting"
    
    #Normals
    NORMAL_OPENGL = "OpenGL"
    NORMAL_DIRECTX = "DirectX"

    @classmethod
    def get_socket_names(cls):
        #Principled socket names
        return {
            cls.PBR_DIFFUSE: "Base Color",
            cls.PBR_METAL: "Metallic",
            cls.PBR_SSS: "Subsurface",
            cls.PBR_SSSCOL: "Subsurface Color",
            cls.PBR_ROUGHNESS: "Roughness",
            cls.PBR_GLOSSY: "Roughness",
            cls.PBR_NORMAL: "Normal",
            cls.PBR_TRANSMISSION: "Transmission",
            cls.PBR_TRANSMISSION_ROUGH: "Transmission Roughness",
            cls.PBR_CLEARCOAT: "Clearcoat",
            cls.PBR_CLEARCOAT_ROUGH: "Clearcoat Roughness",
            cls.PBR_EMISSION: "Emission",
            cls.PBR_EMISSION_STRENGTH: "Emission Strength",
            cls.PBR_SPECULAR: "Specular",
            cls.PBR_ALPHA: "Alpha"
        }

def get_texture_channels(tex):
    sbp = bpy.context.scene.SimpleBake_Props


    if sbp.global_mode in [SBConstants.CYCLESBAKE, SBConstants.CYCLESBAKE_S2A]:
        return "RGB"
    elif tex in [SBConstants.PBR_DIFFUSE, SBConstants.PBR_SSSCOL, SBConstants.PBR_EMISSION, SBConstants.PBR_NORMAL, SBConstants.COLOURID, SBConstants.VERTEXCOL]:
        return "RGB"
    else: return "BW"

def object_list_to_names_list():
    sbp = bpy.context.scene.SimpleBake_Props
    names = sbp.objects_list.items()
    names = [n[0] for n in names]
    
    return names

def get_base_folder_patho():
    sbp = bpy.context.scene.SimpleBake_Props
    if "--background" in sys.argv:
        base_folder = Path(sbp.base_folder_override)
    else:
        base_folder = Path(bpy.data.filepath).parent
        
    return base_folder


def force_to_object_mode():
    if bpy.context.active_object == None:
        bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[0] #Pick arbitary
    bpy.ops.object.mode_set(mode="OBJECT", toggle=False)

        
def check_for_safe_context_class():
    sbp = bpy.context.scene.SimpleBake_Props
    t = []
    #t.append(base64.b64decode("bGV3aXM=").decode("utf-8"))
    if sbp.safe_context_check in t:
        print_message("Warning - Safe context class check failed. This is not fatal. Continuing")
        return False
    else:
        return True

    return True

def select_selected_to_active(selected_objs, active_obj):
    bpy.ops.object.select_all(action="DESELECT")
    
    for obj in selected_objs:
        obj.select_set(state=True)
    active_obj.select_set(state=True)
    bpy.context.view_layer.objects.active = active_obj

def select_only_these(objs):
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objs:
        obj.select_set(state=True)
    bpy.context.view_layer.objects.active = objs[0] #arbitary

def select_only_this(obj):
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(state=True)
    bpy.context.view_layer.objects.active = obj

def pbr_selections_to_list():
    sbp = bpy.context.scene.SimpleBake_Props
    
    selectedbakes = []
    selectedbakes.append(SBConstants.PBR_DIFFUSE) if sbp.selected_col else False
    selectedbakes.append(SBConstants.PBR_METAL) if sbp.selected_metal else False
    selectedbakes.append(SBConstants.PBR_ROUGHNESS) if sbp.selected_rough and sbp.rough_glossy_switch==SBConstants.PBR_ROUGHNESS else False
    selectedbakes.append(SBConstants.PBR_GLOSSY) if sbp.selected_rough and sbp.rough_glossy_switch==SBConstants.PBR_GLOSSY else False
    selectedbakes.append(SBConstants.PBR_NORMAL) if sbp.selected_normal else False
    selectedbakes.append(SBConstants.PBR_TRANSMISSION) if sbp.selected_trans else False
    selectedbakes.append(SBConstants.PBR_TRANSMISSION_ROUGH) if sbp.selected_transrough else False
    selectedbakes.append(SBConstants.PBR_CLEARCOAT) if sbp.selected_clearcoat else False
    selectedbakes.append(SBConstants.PBR_CLEARCOAT_ROUGH) if sbp.selected_clearcoat_rough else False
    selectedbakes.append(SBConstants.PBR_EMISSION) if sbp.selected_emission else False
    selectedbakes.append(SBConstants.PBR_EMISSION_STRENGTH) if sbp.selected_emission_strength else False
    selectedbakes.append(SBConstants.PBR_SPECULAR) if sbp.selected_specular else False
    selectedbakes.append(SBConstants.PBR_ALPHA) if sbp.selected_alpha else False
    selectedbakes.append(SBConstants.PBR_SSS) if sbp.selected_sss else False
    selectedbakes.append(SBConstants.PBR_SSSCOL) if sbp.selected_ssscol else False
    selectedbakes.append(SBConstants.PBR_DISPLACEMENT) if sbp.selected_displacement else False
    
    return selectedbakes

def specials_selection_to_list():
    sbp = bpy.context.scene.SimpleBake_Props
    selected_specials = []
    selected_specials.append(SBConstants.THICKNESS) if sbp.selected_thickness else False
    selected_specials.append(SBConstants.COLOURID) if sbp.selected_col_mats else False
    selected_specials.append(SBConstants.VERTEXCOL) if sbp.selected_col_vertex else False
    selected_specials.append(SBConstants.CURVATURE) if sbp.selected_curvature else False                    
    selected_specials.append(SBConstants.LIGHTMAP) if sbp.selected_lightmap else False
    selected_specials.append(SBConstants.AO) if sbp.selected_ao else False
                             
    return selected_specials

def get_udim_set(img):
    udim_id = img["SB_udim_id"]
    
    #Get all images with same udim id
    udim_imgs = ([i for i in bpy.data.images if "SB_udim_id" in i
                         and i["SB_udim_id"] == udim_id])
    
    #Create a dictionary of udim set
    udim_set = {}
    for img in udim_imgs:
        udim_set[int(img["SB_udim_tile_number"])] = img
    
    return udim_set


def get_cs_list(self, conext):
    cs_items = ([
        ('Filmic Log','Filmic Log',""),
        ('Linear','Linear',""),
        ('Linear ACES','Linear ACES',""),
        ('Non-Color','Non-Color',""),
        ('Raw','Raw',""),
        ('sRGB','sRGB',""),
        ('XYZ','XYZ',"")
        ])
    return cs_items

def clean_file_name(filename):
    keepcharacters = (' ','.','_','~',"-")
    return "".join(c for c in filename if c.isalnum() or c in keepcharacters)#.rstrip()

def transfer_tags(old_img, new_img):
    
    tags= ([
        "SB_bake_object",
        "SB_global_mode",
        "SB_this_bake",
        "SB_merged_bake",
        "SB_merged_bake_name",
        "SB_bake_operation_id",
        "SB_float_buffer",
        "SB_scaled",
        "SB_exported_list",
        "SB_udim_secondary",
        "SB_udim_id",
        "SB_udim_tile_number"
        ])
    
    for tag in tags:
        if tag in old_img: new_img[tag] = old_img[tag]
    
    return True
    
# class SimpleBake_OT_Print_Message(Operator):
#     bl_idname = "simplebake.print_message"
#     bl_label = ""
#
#     message: StringProperty()
#
#     def execute(self, context):
#         print_message(self.message)
#         return {'FINISHED'}

class SimpleBake_OT_Halt(Operator):
    bl_idname = "simplebake.halt"
    bl_label = ""
 
    def execute(self, context):
        
        raise Exception
        return {'FINISHED'}

def show_message_box(messageitems_list, title, icon = 'INFO'):

    def draw(self, context):
        for m in messageitems_list:
            self.layout.label(text=m)
    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
    
    return True

class SimpleBake_OT_Show_Message_Box(Operator):
    bl_idname = "simplebake.show_message_box"
    bl_label = ""
 
    message: StringProperty()
    icon: StringProperty(default="INFO")
    centre: BoolProperty(default=False)
    
    def execute(self, context):
        return {'FINISHED'}
 
    def invoke(self, context, event):
        self.restored = False
        if self.centre:
            self.orig_x = event.mouse_x
            self.orig_y = event.mouse_y
            
            w = int(bpy.context.window.width/2)
            h = int(bpy.context.window.height/2)
            h = h + (20*len(self.message.split("|")))
            bpy.context.window.cursor_warp(w, h)
        
        return context.window_manager.invoke_props_dialog(self, width = 400)
 
    def draw(self, context):
        self.layout.label(text="SIMPLEBAKE", icon=self.icon)
        message_list = self.message.split("|")
        for li in message_list:
            row=self.layout.row()
            row.scale_y = 0.8
            row.alignment = 'CENTER'
            row.label(text=li)
        if not self.restored and self.centre:
            bpy.context.window.cursor_warp(self.orig_x, self.orig_y)
            self.restored = True
                             
classes = ([
    SimpleBake_OT_Show_Message_Box,
    #SimpleBake_OT_Print_Message,
    SimpleBake_OT_Halt
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
