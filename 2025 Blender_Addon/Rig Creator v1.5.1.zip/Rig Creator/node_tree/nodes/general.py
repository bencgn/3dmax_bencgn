

from ...generaldata import *

class GeneralNodeData(GeneralArmatureData):
    
    

    def CompileNode(self,) : ...
    