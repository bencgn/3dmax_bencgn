import bpy 
import uuid
from bpy.utils import register_class, unregister_class
from bpy.types import Operator, Macro
from bpy.props import StringProperty, BoolProperty


from datetime import datetime
import sys
from ..background_and_progress import BackgroundBakeTasks, BakeInProgress
from ..utils import (SBConstants, print_message, pbr_selections_to_list, check_for_safe_context_class,
                     get_udim_set, select_only_this, show_message_box, specials_selection_to_list, force_to_object_mode)
from ..material_management import SimpleBake_OT_Material_Backup as MatManager
from .specials_bake_operators import add_specials_to_macro, add_specials_to_macro_s2a
from .pbr_bake_support_operators import sample_nodes_present

class SimpleBake_OT_PBR_Bake_Macro(Macro):
    bl_idname = "simplebake.pbr_bake_macro"
    bl_label = "Go"
    bl_options = {'BLOCKING', 'INTERNAL'}
    
    @classmethod
    def clean(cls):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
        bpy.utils.register_class(cls)

class SimpleBake_OT_Bake_Operation_PBRS2A_Background(Operator):
    """Start the bake operation"""
    bl_idname = "simplebake.bake_operation_pbrs2a_background"
    bl_description = "Commence background bake for PBR S2A"
    bl_label = "Bake (Background)"

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        
        #Starting checks
        if 'CANCELLED' in bpy.ops.simplebake.starting_checks():
            return {'CANCELLED'}
        
        #Start operator call for call back
        start_command = "bpy.ops.simplebake.bake_operation_pbrs2a()"

        #Tag objects in case we want to hide them later
        bg_bake_id = str(uuid.uuid4())
        def append_to_bg_hide_list(obj, bg_bake_id):
            if "SB_BG_HIDE" in obj:
                existing = obj["SB_BG_HIDE"]
                existing.append(bg_bake_id)
                obj["SB_BG_HIDE"] = existing
            else:
                obj["SB_BG_HIDE"] = [bg_bake_id]

        if sbp.hide_source_objects:
            for obj in sbp.objects_list:
                o = obj.obj_point
                append_to_bg_hide_list(o, bg_bake_id)
            #Also hide target object
            if sbp.targetobj != None:
                append_to_bg_hide_list(sbp.targetobj, bg_bake_id)

        if sbp.hide_cage_object and bpy.context.scene.render.bake.cage_object != None:
            append_to_bg_hide_list(bpy.context.scene.render.bake.cage_object, bg_bake_id)

        BackgroundBakeTasks(sbp.bgbake_name, sbp.copy_and_apply, start_command, bg_bake_id)
        return{'FINISHED'}


class SimpleBake_OT_Bake_Operation_PBRS2A(Operator):
    """Start the bake operation"""
    bl_idname = "simplebake.bake_operation_pbrs2a"
    bl_description = "Commence bake for PBR S2A"
    bl_label = "Bake"
    
    _timer = None 
        
    @classmethod
    def poll(cls,context):
        sbp = context.scene.SimpleBake_Props
        if BakeInProgress.is_baking: return False
        else: return True
    
    def modal(self, context, event):
        sbp = context.scene.SimpleBake_Props
        if event.type == 'TIMER':
            if not BakeInProgress.is_baking:
                 context.window_manager.event_timer_remove(self._timer)
                 
        return {'PASS_THROUGH'}
    
    
    def execute(self, context):
        
        force_to_object_mode()
        
        sbp = context.scene.SimpleBake_Props
        
        #Refresh objects list
        bpy.ops.simplebake.refresh_bake_object_list()
        
        #Set variables from panel
        global_mode = SBConstants.PBRS2A
        
        bake_operation_id = str(uuid.uuid4())
        
        #Objects
        bake_objects_names = [o.obj_point.name for o in sbp.objects_list]
        if sbp.targetobj != None: #Starting checks will catch this later if it's None
            target_object_name = sbp.targetobj.name
            if target_object_name in bake_objects_names:
                bake_objects_names.remove(target_object_name)
        
        pbr_bake_modes = pbr_selections_to_list()
        
        if sbp.rough_glossy_switch == SBConstants.PBR_GLOSSY: used_glossy = True
        else: used_glossy = False
        if sbp.normal_format_switch == SBConstants.NORMAL_DIRECTX: used_directx = True
        else: used_directx = False
        #if sbp.everything_16bit: s8or16 = "16"
        #else: s8or16 = "8"
        
        if sbp.uv_mode == "udims": udims = True
        else: udims = False
        
        #Background
        if "--background" in sys.argv: in_background = True
        else: in_background = False
        
        #Progress Tracking
        ps = len(pbr_selections_to_list())
        ss = len(specials_selection_to_list())
        u = sbp.udim_tiles
        o = 1 #S2A bake
        if udims:
            t = (ps + ss) * u * o
            sbp.total_bake_images_number = t
        else:
            t = (ps + ss) * o
            sbp.total_bake_images_number = t
        print_message(f"Total of {sbp.total_bake_images_number} images to bake")
                
        boost_needed = False
        
        #-----------------------------------------------------
        
        
        #Starting checks
        if 'CANCELLED' in bpy.ops.simplebake.starting_checks(): #Should work out it's own mode from panel selections
            return {'CANCELLED'}
            
        MACRO = SimpleBake_OT_PBR_Bake_Macro
        
        #Clean macro
        MACRO.clean()
        
        #Common bake prep
        MACRO.define("SIMPLEBAKE_OT_common_bake_prep")
        
        #Pre-bake (node groups and then reroute nodes)
        MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="Pre bake starting"
        MACRO.define("SIMPLEBAKE_OT_pbr_pre_bake")
        MACRO.define("SIMPLEBAKE_OT_remove_reroutes")
        
        #PBR specific bake prep
        op = MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
        op.properties.mode="prepare"
        
        #Process UVs (target object only)
        op = MACRO.define("SIMPLEBAKE_OT_process_uvs")
        op.properties.island_margin = sbp.unwrapmargin
        op.properties.average_islands = sbp.average_uv_size
        op.properties.prefer_sb_uv_maps = sbp.prefer_existing_sbmap
        op.properties.new_uv_option = sbp.new_uv_option
        op.properties.new_uv_method = sbp.new_uv_method
        op.properties.global_mode = sbp.global_mode
        op.properties.expand_mat_uvs = sbp.expand_mat_uvs
        op.properties.uvpackmargin = sbp.uvpackmargin
        op.properties.pbrtarget_only = True
        
        #For each bake mode
        for bake_mode in pbr_bake_modes:
            #For each bake object
            for obj_name in bake_objects_names:
            
                #Backup all materials on object
                op = MACRO.define("SIMPLEBAKE_OT_material_backup")
                op.properties.target_object_name = obj_name
                op.properties.mode = MatManager.MODE_WORKING_BACKUP
                
                #Prepare all materials for this bake mode (no image)
                op = MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
                op.properties.bake_operation_id = bake_operation_id
                op.properties.target_name = obj_name
                op.properties.this_bake = bake_mode
                op.properties.no_bake_image_node = True
                #Done with this bake object
                
                if sample_nodes_present(obj_name):
                    op = MACRO.define("SIMPLEBAKE_OT_print_message")
                    op.properties.message = f"Boost needed because of {obj_name}"
                    boost_needed = True
            
            #Target object only now
            
            #Backup all materials on object
            op = MACRO.define("SIMPLEBAKE_OT_material_backup")
            op.properties.target_object_name = target_object_name #!!!
            op.properties.mode = MatManager.MODE_WORKING_BACKUP
            
            #Create bake image if needed for TARGET OBJECT and this bake mode
            if ((bake_mode ==SBConstants.PBR_NORMAL and not sbp.no_force_32bit_normals) or sbp.everything32bitfloat): 
                    float_buffer = True
            else: float_buffer = False
            op = MACRO.define("SIMPLEBAKE_OT_bake_image")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.this_bake = bake_mode
            op.properties.target_object_name = target_object_name #!!
            op.properties.global_mode = global_mode
            op.properties.use_alpha = sbp.use_alpha
            op.properties.float_buffer = float_buffer
            op.properties.img_width = sbp.imgwidth
            op.properties.img_height = sbp.imgheight
            op.properties.udims = udims
            op.properties.udim_tiles_number = sbp.udim_tiles
            op.properties.batch_name = sbp.batch_name
            op.properties.clear_image = sbp.clear_image
            
            #Set bake image on TARGET OBJECT
            op = MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.target_name = target_object_name #!!!
            op.properties.this_bake = bake_mode
            op.properties.only_bake_image_node = True
            
            #Select objects
            op = MACRO.define("SIMPLEBAKE_OT_select_selected_to_active")
            op.properties.mode = SBConstants.PBRS2A
            if sbp.isolate_objects:
                #Isolate S2A causes a return which doesn't actually mess with the selection
                op = MACRO.define("SIMPLEBAKE_OT_select_only_this")
                op.properties.target_object_name = target_object_name
                op.properties.isolate_s2a = True
        
            #Bake
            def do_bake():
                if not check_for_safe_context_class():
                    return False
                if boost_needed:
                    op = MACRO.define("SIMPLEBAKE_OT_print_message")
                    op.properties.message = ("Sample node(s) detected. Boosting sample count")
                    op = MACRO.define("SIMPLEBAKE_OT_set_sample_count")
                    op.properties.sample_count = sbp.boosted_sample_count
                else:
                    op = MACRO.define("SIMPLEBAKE_OT_set_sample_count")
                    op.properties.sample_count = 2
                
                op = MACRO.define("OBJECT_OT_bake")
                op.properties.use_clear = False
                op.properties.target = "IMAGE_TEXTURES"
                op.properties.use_selected_to_active=True
                op.properties.margin = bpy.context.scene.render.bake.margin
                try: #Magin type added after Blender 3.0
                    op.properties.margin_type = bpy.context.scene.render.bake.margin_type
                except:
                    pass
                if bake_mode == SBConstants.PBR_NORMAL: op.properties.type = "NORMAL"
                else: op.properties.type = "EMIT"
                op.properties.max_ray_distance = sbp.ray_distance
                #Cage---------
                if bpy.context.scene.render.bake.cage_object != None:
                    op.properties.use_cage = True
                    op.properties.cage_object = bpy.context.scene.render.bake.cage_object.name
                elif sbp.cage_smooth_hard == "smooth":
                    op.properties.use_cage = True
                    op.properties.cage_extrusion = sbp.cage_extrusion
                elif sbp.cage_smooth_hard == "hard":
                    op.properties.use_cage = False
                    op.properties.cage_extrusion = sbp.cage_extrusion
                    
                op = MACRO.define("SIMPLEBAKE_OT_update_progress")
                op.properties.background = in_background
                
            if udims:
                i = 0
                while i<sbp.udim_tiles:
                    i+=1
                    op = MACRO.define("SIMPLEBAKE_OT_set_udim_focus_tile")
                    op.properties.target_object_name=target_object_name
                    op.properties.desired_udim_tile=i
                    do_bake()
            else:
                do_bake()
            if udims:
                op = MACRO.define("SIMPLEBAKE_OT_set_udim_focus_tile")
                op.properties.target_object_name=target_object_name
                op.properties.desired_udim_tile=1
                
                
            #Restore all materials (scene wide) for next bake mode (if any)
            op = MACRO.define("SIMPLEBAKE_OT_material_backup")
            op.properties.mode=MatManager.MODE_WORKING_RESTORE
            
            #Should we invert roughness to glossy or normal map to DirecX?
            if bake_mode == SBConstants.PBR_GLOSSY and used_glossy:
                op = MACRO.define("SIMPLEBAKE_OT_invert_roughness_to_glossy")
                op.properties.obj_name = target_object_name
                op.properties.bake_operation_id = bake_operation_id
                op.properties.udims = udims
                
            if bake_mode == SBConstants.PBR_NORMAL and used_directx:
                op = MACRO.define("SIMPLEBAKE_OT_create_directx_normal")
                op.properties.bake_operation_id = bake_operation_id
                op.properties.obj_name = target_object_name
                op.properties.udims = udims
                
            #Scale all baked images if needed (catching this latest one)
            op = MACRO.define("SIMPLEBAKE_OT_scale_images_if_needed")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.this_bake = bake_mode
            
            #Pack
            op = MACRO.define("SIMPLEBAKE_OT_pack_baked_images")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.bake_mode = bake_mode
                    
            #Save bakes external?
            if sbp.save_bakes_external:
                op = MACRO.define("SIMPLEBAKE_OT_save_images_externally")
                op.properties.bake_operation_id = bake_operation_id
                op.properties.file_format = sbp.export_file_format
                op.properties.folder_per_object = sbp.export_folder_per_object
                op.properties.bake_mode = bake_mode
                #op.properties.s8or16 = s8or16
                op.properties.apply_col_man_to_col = sbp.apply_col_man_to_col
                op.properties.in_background = in_background
                
                #Done with this bake mode
        

        #--Done with all bake modes

        #PBR specific bake finishing
        op = MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
        op.properties.mode="finish"
        
        #Add specials to the macro queue
        add_specials_to_macro_s2a(MACRO, context, bake_operation_id, in_background)#!!
        
        #Reload any UDIMs
        if udims:
            op = MACRO.define("SIMPLEBAKE_OT_reload_udims")

        #All bakes done, copy and apply, save_obj_external or in background??
        if sbp.copy_and_apply or sbp.save_obj_external or in_background:
            op = MACRO.define("SIMPLEBAKE_OT_copy_and_apply")
            op.properties.target_object_name = target_object_name
            op.properties.bake_operation_id = bake_operation_id
            op.properties.used_glossy = used_glossy
            op.properties.used_directx = used_directx
            op.properties.hide_source_objects = sbp.hide_source_objects
            op.properties.glTF = sbp.create_glTF_node
            op.properties.glTF_option = sbp.glTF_selection
            op.properties.in_background = in_background
            op.properties.global_mode = global_mode
    
        if sbp.save_obj_external:
            #Export obj? (Will also remove copy and apply object if not needed)
            op = MACRO.define("SIMPLEBAKE_OT_save_objects_externally")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.fbx_name = sbp.fbx_name
            op.properties.gltf_name = sbp.gltf_name
            op.properties.apply_mods_on_mesh_export = sbp.apply_mods_on_mesh_export
            op.properties.apply_transformation = sbp.apply_transformation
            op.properties.copy_and_apply = sbp.copy_and_apply
            op.properties.export_folder_per_object = sbp.export_folder_per_object
            op.properties.in_background = in_background

        #Channel packing
        op = MACRO.define("SIMPLEBAKE_OT_channel_packing")
        op.properties.bake_operation_id = bake_operation_id
        op.properties.pbrtarget_only = True
        op.properties.export_folder_per_object = sbp.export_folder_per_object
        op.properties.in_background = in_background
        op.properties.global_mode = global_mode
        op.properties.batch_name = sbp.batch_name
        
        #Common bake finishing
        op = MACRO.define("SIMPLEBAKE_OT_common_bake_finishing")
        op.properties.baked_number = sbp.total_bake_images_number
        op.properties.in_background = in_background
        op.properties.bake_operation_id = bake_operation_id
        
        
        #--------------------------------------------------------------------------------
        if not in_background: #Cases a crash in background!
            message_list=([
                "Foreground bake has started",
                "Please wait...."
                ])
            show_message_box(message_list, "SIMPLEBAKE - FOREGROUND BAKE STARTED", icon = 'INFO')
        
        BakeInProgress.is_baking = True
        context.window_manager.modal_handler_add(self)
        self._timer = context.window_manager.event_timer_add(1, window=context.window)
        
        
        try:
            bpy.ops.simplebake.pbr_bake_macro('INVOKE_DEFAULT')
        except Exception as e:
            BakeInProgress.was_error = True
            print("Unfortunately, there was a crash. Check the console or terminal for details")
            print(e)
            if not in_background:
                message=f"Unfortunately, there was a crash. Check the console or terminal for details"
                icon="ERROR"
                centre = True
                bpy.ops.simplebake.show_message_box('INVOKE_DEFAULT', message=message, icon=icon, centre=centre)
        
        
        return {'RUNNING_MODAL'}



class SimpleBake_OT_Bake_Operation_PBR_Background(Operator):
    """Start the bake operation"""
    bl_idname = "simplebake.bake_operation_pbr_background"
    bl_description = "Commence background bake for PBR (non S2A)"
    bl_label = "Bake (Background)"

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        
        #Starting checks
        if 'CANCELLED' in bpy.ops.simplebake.starting_checks():
            return {'CANCELLED'}
        
        #Start operator call for call back
        start_command = "bpy.ops.simplebake.bake_operation_pbr()"

        #Tag objects in case we want to hide them later
        bg_bake_id = str(uuid.uuid4())
        def append_to_bg_hide_list(obj, bg_bake_id):
            if "SB_BG_HIDE" in obj:
                existing = obj["SB_BG_HIDE"]
                existing.append(bg_bake_id)
                obj["SB_BG_HIDE"] = existing
            else:
                obj["SB_BG_HIDE"] = [bg_bake_id]

        if sbp.hide_source_objects:
            for obj in sbp.objects_list:
                o = obj.obj_point
                append_to_bg_hide_list(o, bg_bake_id)
        
        BackgroundBakeTasks(sbp.bgbake_name, sbp.copy_and_apply, start_command, bg_bake_id)
        return{'FINISHED'}
        

class SimpleBake_OT_Bake_Operation_PBR(Operator):
    """Start the bake operation"""
    bl_idname = "simplebake.bake_operation_pbr"
    bl_description = "Commence bake for PBR (non S2A)"
    bl_label = "Bake"
    
    _timer = None 
        
    @classmethod
    def poll(cls,context):
        sbp = context.scene.SimpleBake_Props
        if BakeInProgress.is_baking: return False
        else: return True
    
    def modal(self, context, event):
        sbp = context.scene.SimpleBake_Props
        if event.type == 'TIMER':
            if not BakeInProgress.is_baking:
                 context.window_manager.event_timer_remove(self._timer)
                          
        return {'PASS_THROUGH'}
    
    
    def execute(self, context):
        
        sbp = context.scene.SimpleBake_Props
        
        #Refresh objects list
        bpy.ops.simplebake.refresh_bake_object_list()
        
        #Set variables from panel
        global_mode = SBConstants.PBR
        
        bake_operation_id = str(uuid.uuid4())
        bake_objects_names = [o.obj_point.name for o in sbp.objects_list]
        pbr_bake_modes = pbr_selections_to_list()
        if sbp.rough_glossy_switch == SBConstants.PBR_GLOSSY: used_glossy = True
        else: used_glossy = False
        if sbp.normal_format_switch == SBConstants.NORMAL_DIRECTX: used_directx = True
        else: used_directx = False
        #if sbp.everything_16bit: s8or16 = "16"
        #else: s8or16 = "8"
        
        if sbp.uv_mode == "udims": udims = True
        else: udims = False
        
        #Background
        if "--background" in sys.argv: in_background = True
        else: in_background = False
        
        #Progress Tracking
        ps = len(pbr_selections_to_list())
        ss = len(specials_selection_to_list())
        u = sbp.udim_tiles
        o = len(bake_objects_names)
        if udims:
            t = (ps + ss) * u * o
            sbp.total_bake_images_number = t
        else:
            t = (ps + ss) * o
            sbp.total_bake_images_number = t
        print_message(f"Total of {sbp.total_bake_images_number} images to bake")
                
        #-----------------------------------------------------
        
        
        #Starting checks
        if 'CANCELLED' in bpy.ops.simplebake.starting_checks():
            return {'CANCELLED'}
        
        
        force_to_object_mode()
        
        MACRO = SimpleBake_OT_PBR_Bake_Macro
        
        #Clean macro
        MACRO.clean()
        
        #Common bake prep
        MACRO.define("SIMPLEBAKE_OT_common_bake_prep")
        
        #Pre-bake (node groups)
        MACRO.define("SIMPLEBAKE_OT_print_message").properties.message="Pre bake starting"
        MACRO.define("SIMPLEBAKE_OT_pbr_pre_bake")
        MACRO.define("SIMPLEBAKE_OT_remove_reroutes")
        
        #PBR specific bake prep
        op = MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
        op.properties.mode="prepare"
        
        #Process UVs
        op = MACRO.define("SIMPLEBAKE_OT_process_uvs")
        op.properties.island_margin = sbp.unwrapmargin
        op.properties.average_islands = sbp.average_uv_size
        op.properties.prefer_sb_uv_maps = sbp.prefer_existing_sbmap
        op.properties.new_uv_option = sbp.new_uv_option
        op.properties.new_uv_method = sbp.new_uv_method
        op.properties.global_mode = sbp.global_mode
        op.properties.expand_mat_uvs = sbp.expand_mat_uvs
        op.properties.uvpackmargin = sbp.uvpackmargin
        
        obj_counter = 1
        for obj_name in bake_objects_names:
            if obj_counter == len(bake_objects_names):
                #---Last operation---
                last_obj = True
            else: last_obj = False
            
            for bake_mode in pbr_bake_modes:
                
                #Backup all materials on object
                op = MACRO.define("SIMPLEBAKE_OT_material_backup")
                op.properties.target_object_name = obj_name
                op.properties.mode = MatManager.MODE_WORKING_BACKUP
                
                #Create bake image if needed for this object and this bake mode
                if (
                    (bake_mode == SBConstants.PBR_NORMAL and not sbp.no_force_32bit_normals) or sbp.everything32bitfloat): 
                    float_buffer = True
                else: float_buffer = False
                op = MACRO.define("SIMPLEBAKE_OT_bake_image")
                op.properties.bake_operation_id = bake_operation_id
                op.properties.merged_bake = sbp.merged_bake
                op.properties.merged_bake_name = sbp.merged_bake_name
                op.properties.this_bake = bake_mode
                op.properties.target_object_name = obj_name
                op.properties.global_mode = global_mode
                op.properties.use_alpha = sbp.use_alpha
                op.properties.float_buffer = float_buffer
                op.properties.img_width = sbp.imgwidth
                op.properties.img_height = sbp.imgheight
                op.properties.udims = udims
                op.properties.udim_tiles_number = sbp.udim_tiles
                op.properties.batch_name = sbp.batch_name
                op.properties.clear_image = sbp.clear_image
                
            
                #Configure all object materials for this bake mode
                op = MACRO.define("SIMPLEBAKE_OT_prepare_object_mats_pbr")
                op.properties.bake_operation_id = bake_operation_id
                op.properties.target_name = obj_name
                op.properties.this_bake = bake_mode
                op.properties.merged_bake = sbp.merged_bake
                                
                #Bake
                op = MACRO.define("SIMPLEBAKE_OT_select_only_this")
                op.properties.target_object_name = obj_name
                if sbp.isolate_objects:
                    op.properties.isolate = True
                
                def do_bake():
                    if not check_for_safe_context_class():
                        return False
                    
                    if sample_nodes_present(obj_name):
                        op = MACRO.define("SIMPLEBAKE_OT_print_message")
                        op.properties.message = ("Sample node(s) detected. Boosting sample count")
                        op = MACRO.define("SIMPLEBAKE_OT_set_sample_count")
                        op.properties.sample_count = sbp.boosted_sample_count
                    else:
                        op = MACRO.define("SIMPLEBAKE_OT_set_sample_count")
                        op.properties.sample_count = 2
                    op = MACRO.define("OBJECT_OT_bake")
                    op.properties.use_clear = False
                    op.properties.target = "IMAGE_TEXTURES"
                    op.properties.margin = bpy.context.scene.render.bake.margin
                    try: #Magin type added after Blender 3.0
                        op.properties.margin_type = bpy.context.scene.render.bake.margin_type
                    except:
                        pass
                    if bake_mode == SBConstants.PBR_NORMAL: op.properties.type = "NORMAL"
                    else: op.properties.type = "EMIT"
                    op = MACRO.define("SIMPLEBAKE_OT_update_progress")
                    op.properties.background = in_background
                    
                        
                if udims:
                    i = 0
                    while i<sbp.udim_tiles:
                        i+=1
                        op = MACRO.define("SIMPLEBAKE_OT_set_udim_focus_tile")
                        op.properties.target_object_name=obj_name
                        op.properties.desired_udim_tile=i
                        do_bake()
                else:
                    do_bake()
                if udims:
                    op = MACRO.define("SIMPLEBAKE_OT_set_udim_focus_tile")
                    op.properties.target_object_name=obj_name
                    op.properties.desired_udim_tile=1
                    
                #Restore all materials (scene wide) for next bake mode (if any)
                op = MACRO.define("SIMPLEBAKE_OT_material_backup")
                op.properties.mode=MatManager.MODE_WORKING_RESTORE
                
                #-----------If not a merged bake, done with this image. 
                #-----------If merged bake, only done if this is last object
                if not sbp.merged_bake or (sbp.merged_bake and last_obj):
                    #LAST OPERATION
                    
                    #Should we invert roughness to glossy or normal map to DirecX?
                    if bake_mode == SBConstants.PBR_GLOSSY and used_glossy:
                        op = MACRO.define("SIMPLEBAKE_OT_invert_roughness_to_glossy")
                        op.properties.obj_name = obj_name
                        op.properties.bake_operation_id = bake_operation_id
                        op.properties.merged_bake = sbp.merged_bake
                        op.properties.merged_bake_name = sbp.merged_bake_name
                        op.properties.udims = udims
                        
                    if bake_mode == SBConstants.PBR_NORMAL and used_directx:
                        op = MACRO.define("SIMPLEBAKE_OT_create_directx_normal")
                        op.properties.bake_operation_id = bake_operation_id
                        op.properties.merged_bake = sbp.merged_bake
                        op.properties.merged_bake_name = sbp.merged_bake_name
                        op.properties.obj_name = obj_name
                        op.properties.udims = udims
                    
                    #Scale all baked images if needed (catching this latest one)
                    op = MACRO.define("SIMPLEBAKE_OT_scale_images_if_needed")
                    op.properties.bake_operation_id = bake_operation_id
                    op.properties.this_bake = bake_mode
                    
                    #Pack
                    op = MACRO.define("SIMPLEBAKE_OT_pack_baked_images")
                    op.properties.bake_operation_id = bake_operation_id
                    op.properties.bake_mode = bake_mode
                    
                    #Save bakes external?
                    if sbp.save_bakes_external:
                        op = MACRO.define("SIMPLEBAKE_OT_save_images_externally")
                        op.properties.bake_operation_id = bake_operation_id
                        op.properties.file_format = sbp.export_file_format
                        op.properties.folder_per_object = sbp.export_folder_per_object
                        op.properties.bake_mode = bake_mode
                        op.properties.merged_bake = sbp.merged_bake
                        op.properties.merged_bake_name = sbp.merged_bake_name
                        #op.properties.s8or16 = s8or16
                        op.properties.apply_col_man_to_col = sbp.apply_col_man_to_col
                        op.properties.in_background = in_background
                
            #---Done with this object---
            obj_counter += 1
                
        #---Done with all objects---
        
        #PBR specific bake finishing
        op = MACRO.define("SIMPLEBAKE_OT_pbr_specific_bake_prep_and_finish")
        op.properties.mode="finish"
        
        
        #Add specials to the macro queue
        add_specials_to_macro(MACRO, context, bake_operation_id, in_background, bake_objects_names)
        
        #Reload any UDIMs
        if udims:
            op = MACRO.define("SIMPLEBAKE_OT_reload_udims")

        #All bakes done, copy and apply, save_obj_external or in background??
        if sbp.copy_and_apply or sbp.save_obj_external or in_background:
            for obj_name in bake_objects_names:
                op = MACRO.define("SIMPLEBAKE_OT_copy_and_apply")
                op.properties.target_object_name = obj_name
                op.properties.bake_operation_id = bake_operation_id
                op.properties.used_glossy = used_glossy
                op.properties.used_directx = used_directx
                op.properties.hide_source_objects = sbp.hide_source_objects
                op.properties.merged_bake = sbp.merged_bake
                op.properties.merged_bake_name = sbp.merged_bake_name
                op.properties.glTF = sbp.create_glTF_node
                op.properties.glTF_option = sbp.glTF_selection
                op.properties.in_background = in_background
                op.properties.global_mode = global_mode
        
        if sbp.save_obj_external:
            #Export obj? (Will also remove copy and apply object if not needed)
            op = MACRO.define("SIMPLEBAKE_OT_save_objects_externally")
            op.properties.bake_operation_id = bake_operation_id
            op.properties.fbx_name = sbp.fbx_name
            op.properties.gltf_name = sbp.gltf_name
            op.properties.apply_mods_on_mesh_export = sbp.apply_mods_on_mesh_export
            op.properties.apply_transformation = sbp.apply_transformation
            op.properties.copy_and_apply = sbp.copy_and_apply
            op.properties.export_folder_per_object = sbp.export_folder_per_object
            op.properties.merged_bake = sbp.merged_bake
            op.properties.merged_bake_name = sbp.merged_bake_name
            op.properties.in_background = in_background
        
        #Channel packing
        op = MACRO.define("SIMPLEBAKE_OT_channel_packing")
        op.properties.bake_operation_id = bake_operation_id
        op.properties.pbrtarget_only = False
        op.properties.merged_bake = sbp.merged_bake
        op.properties.merged_bake_name = sbp.merged_bake_name
        op.properties.export_folder_per_object = sbp.export_folder_per_object
        op.properties.in_background = in_background
        op.properties.global_mode = global_mode
        op.properties.batch_name = sbp.batch_name
        
        #Common bake finishing
        op = MACRO.define("SIMPLEBAKE_OT_common_bake_finishing")
        op.properties.baked_number = sbp.total_bake_images_number
        op.properties.in_background = in_background
        op.properties.bake_operation_id = bake_operation_id
        
        
        #--------------------------------------------------------------------------------
        if not in_background: #Cases a crash in background!
            message_list=([
                "Foreground bake has started",
                "Please wait...."
                ])
            show_message_box(message_list, "SIMPLEBAKE - FOREGROUND BAKE STARTED", icon = 'INFO')
        
        BakeInProgress.is_baking = True
        context.window_manager.modal_handler_add(self)
        self._timer = context.window_manager.event_timer_add(1, window=context.window)
        
        
        try:
            bpy.ops.simplebake.pbr_bake_macro('INVOKE_DEFAULT')
        except Exception as e:
            BakeInProgress.was_error = True
            print("Unfortunately, there was a crash. Check the console or terminal for details")
            print(e)
            if not in_background:
                message=f"Unfortunately, there was a crash. Check the console or terminal for details"
                icon="ERROR"
                centre = True
                bpy.ops.simplebake.show_message_box('INVOKE_DEFAULT', message=message, icon=icon, centre=centre)
        
        return {'RUNNING_MODAL'}

classes = ([
    SimpleBake_OT_Bake_Operation_PBR,
    SimpleBake_OT_Bake_Operation_PBRS2A,
    SimpleBake_OT_PBR_Bake_Macro,
    SimpleBake_OT_Bake_Operation_PBR_Background,
    SimpleBake_OT_Bake_Operation_PBRS2A_Background
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:        unregister_class(cls)
