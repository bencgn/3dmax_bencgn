import bpy

from bpy.utils import register_class, unregister_class
from bpy.types import Operator
from bpy.props import StringProperty, IntProperty, BoolProperty

import os
from pathlib import Path
import tempfile
from datetime import datetime
from math import floor

from ..utils import SBConstants, print_message, get_udim_set, transfer_tags, show_message_box, object_list_to_names_list
from ..material_management import SimpleBake_OT_Material_Backup as MatManager
from ..background_and_progress import BakeInProgress

class SimpleBake_OT_Set_Sample_Count(Operator):
    bl_idname = "simplebake.set_sample_count"
    bl_label = "Set the sample count"
    
    sample_count: IntProperty()
    
    def execute(self, context):
        context.scene.cycles.samples = self.sample_count
        print_message(f"Sample count now {self.sample_count}")
        return {'FINISHED'}

class SimpleBake_OT_Compositor_Denoise(Operator):
    """Run the target image through compositor denoise"""
    bl_idname = "simplebake.compositor_denoise"
    bl_label = "Denoise"
    
    bake_operation_id: StringProperty()
    bake_type: StringProperty()
    
    def execute(self, context):
        
        print_message("Running compositor denoiser")
        
        imgs = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                 and i["SB_bake_operation_id"] == self.bake_operation_id
                 and i["SB_this_bake"] == self.bake_type
                 and i["SB_denoised"] == False
                 ])
        
        [bpy.data.scenes.remove(s) for s in bpy.data.scenes if s.name == "compositor_denoise"]
        path = os.path.dirname(__file__) + "/../resources/denoise.blend/Scene/"
        bpy.ops.wm.append(filename="compositor_denoise", directory=path)
        
        s = bpy.data.scenes["compositor_denoise"]
        s.render.image_settings.file_format = "OPEN_EXR"
        s.render.image_settings.color_depth = "32"
        s.render.image_settings.color_mode = "RGBA"
        s.view_settings.view_transform = "Standard"
        #Should all be same size
        s.render.resolution_x = imgs[0].size[0]
        s.render.resolution_y = imgs[0].size[1]
        
        node_tree = s.node_tree
        nodes = node_tree.nodes
        
        i_node = [n for n in nodes if n.label == "image"]
        assert(len(i_node) == 1)
        i_node= i_node[0]
        
        temp_dir = Path(tempfile.TemporaryDirectory().name)
        
        for img in imgs:
        
            i_node.image = img
            bpy.ops.render.render(use_viewport=False, scene=s.name)
        
            render_result_image = bpy.data.images["Render Result"]
        
            render_result_image.save_render(str(temp_dir / f"{img.name}.exr"), scene=s)
            new_img = bpy.data.images.load(str(temp_dir / f"{img.name}.exr"))
            transfer_tags(img, new_img)
            new_img["SB_denoised"] = True
            new_img.name = img.name
    
        
        [bpy.data.images.remove(i) for i in imgs]
        [bpy.data.scenes.remove(s) for s in bpy.data.scenes if s.name == "compositor_denoise"]
        
        return {'FINISHED'}

class SimpleBake_OT_Select_Only_This(Operator):
    """Select only the specified object"""
    bl_idname = "simplebake.select_only_this"
    bl_label = "Select"
    
    hidden = []
    
    target_object_name: StringProperty()
    isolate: BoolProperty(default=False)
    isolate_s2a: BoolProperty(default=False)
    
    def execute(self, context):

        obj = bpy.data.objects[self.target_object_name]

        if self.isolate_s2a:
            bake_objs = object_list_to_names_list()
            bake_objs.append(self.target_object_name)

            #Hide everything
            for o in bpy.data.objects:
                if o.name not in bake_objs and o.type=="MESH":
                    if o.hide_render == False:
                        o.hide_render = True
                        self.__class__.hidden.append(o.name)

            #Unhide object in bake objects list
            for o_name in bake_objs:
                bpy.data.objects[o_name].hide_render = False

            #Return here - we don't actually want to mess with the selection
            return {'FINISHED'}

        if self.isolate:
            #Unhide the object we are baking. It may not have been unhidden yet
            obj.hide_render = False

            #Hide all other objects
            for o in bpy.data.objects:
                if o.name != self.target_object_name and o.type=="MESH":
                    if o.hide_render == False:
                        o.hide_render = True
                        self.__class__.hidden.append(o.name)

        bpy.ops.object.select_all(action="DESELECT")
        obj.select_set(state=True)
        bpy.context.view_layer.objects.active = obj
        
        return {'FINISHED'}


class SimpleBake_OT_Select_Selected_To_Active(Operator):
    """Select the bake objects as selected, and target object as active"""
    bl_idname = "simplebake.select_selected_to_active"
    bl_label = "Select"
    
    mode: StringProperty()
    
    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        objs = [i.obj_point for i in sbp.objects_list]
        
        if self.mode == SBConstants.PBRS2A:
            target_obj = sbp.targetobj 
        
        if self.mode == SBConstants.CYCLESBAKE_S2A:
            target_obj = sbp.targetobj_cycles 
        
        bpy.ops.object.select_all(action="DESELECT")
        
        [obj.select_set(state=True) for obj in objs]
        target_obj.select_set(state=True)
        bpy.context.view_layer.objects.active = target_obj
        
        return {'FINISHED'}

class CommonBakePrepandFinish:
    #Non-Blender class. No register
    orig_object_selection = []
    orig_active_object = None
    
    orig_object_uvs = {}
    orig_object_uvs_render = {}
    
    orig_render_engine = None
    packed_images = []
    start_time = None
    
    

class SimpleBake_OT_Pack_Baked_Images(Operator):
    """Preperation shared by all types of bake"""
    bl_idname = "simplebake.pack_baked_images"
    bl_description = "Pack all baked images into blend file"
    bl_label = "Pack"
    
    bake_operation_id: StringProperty()
    bake_mode: StringProperty()
    
    def execute(self, context):
        #Get all primary images for this operation
        imgs = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
            and i["SB_bake_operation_id"] == self.bake_operation_id
            and i.name not in CommonBakePrepandFinish.packed_images and
            "SB_this_bake" in i and i["SB_this_bake"] == self.bake_mode and
            "SB_udim_secondary" in i and i["SB_udim_secondary"] == False
            ])

        secondary_images =[]
        for img in imgs:
            #Are any of these just the primary in a UDIM set?
            if "SB_udim_id" in img:
                udim_set = get_udim_set(img)
                del udim_set[1] #We don't want the first tile twice
                secondary_images += list(udim_set.values())
        
        imgs+=secondary_images
                
        for img in imgs:
            print_message(f"Packing {img.name}")
            img.pack()
            img.use_fake_user = True
            CommonBakePrepandFinish.packed_images.append(img.name)
        
        return {'FINISHED'}
    
class SimpleBake_OT_Scale_Images_If_Needed(Operator):
    """Preperation shared by all types of bake"""
    bl_idname = "simplebake.scale_images_if_needed"
    bl_description = "Scale images if needed"
    bl_label = "Scale"
    
    bake_operation_id: StringProperty()
    this_bake: StringProperty()
    
    def execute(self, context):
        
        #Scale images if needed
        print_message("Scaling images if needed")
        imgs = ([i for i in bpy.data.images
                 if "SB_bake_operation_id" in i and 
                 i["SB_bake_operation_id"] == self.bake_operation_id and
                 "SB_this_bake" in i and
                 i["SB_this_bake"] == self.this_bake and
                 not i["SB_scaled"]
                 ])
        sbp = bpy.context.scene.SimpleBake_Props
        for img in imgs:
            width = img.size[0]
            height = img.size[1]
            if width != sbp.outputwidth or height != sbp.outputheight:
                print_message(f"Scaling {img.name} to {sbp.outputwidth} by {sbp.outputheight}")
                img.scale(sbp.outputwidth, sbp.outputheight)
            #Either way, we considered it
            img["SB_scaled"] = True
        
        
        return {'FINISHED'} 

class SimpleBake_OT_Common_Bake_Prep(Operator):
    """Preperation shared by all types of bake"""
    bl_idname = "simplebake.common_bake_prep"
    bl_description = "Preperation shared by all types of bake"
    bl_label = "BakePrep"
    
    def execute(self, context):
        
        print_message("================================")
        print_message("--------SIMPLEBAKE START--------")
        print_message("================================")
        
        CommonBakePrepandFinish.start_time = datetime.now()
        
        sbp = context.scene.SimpleBake_Props
        bake_objects_names = [o.obj_point.name for o in sbp.objects_list]
        
        print_message("Common bake prep starting")
        
        #Fresh start for materials
        bpy.ops.simplebake.material_backup(mode=MatManager.MODE_INITIALISE)
        
        #Tracking number reset
        sbp.current_bake_image_number = 0
        sbp.percent_complete = 0
        
        #Render engine
        CommonBakePrepandFinish.orig_render_engine = bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'CYCLES'
        
        #Object selection
        CommonBakePrepandFinish.orig_object_selection = bpy.context.selected_objects
        CommonBakePrepandFinish.orig_active_object = bpy.context.active_object
        
        #Object orig_object_uvs
        uv_objs_names = bake_objects_names
        if sbp.targetobj != None: uv_objs_names.append(sbp.targetobj.name)
        if sbp.targetobj_cycles != None: uv_objs_names.append(sbp.targetobj_cycles.name)
        for o_name in uv_objs_names:
            obj = bpy.data.objects[o_name]
            if obj.data.uv_layers.active != None:
                CommonBakePrepandFinish.orig_object_uvs[o_name] = obj.data.uv_layers.active.name
            #Get UV layer active for render
            uv_active_render = [uv for uv in obj.data.uv_layers if uv.active_render]
            for uv in uv_active_render:
                CommonBakePrepandFinish.orig_object_uvs_render[o_name] = uv.name
            
        #Create a new collection, and add selected objects and target objects to it
        for c in bpy.data.collections:
            if "SimpleBake_Working" in c.name: bpy.data.collections.remove(c)
        c = bpy.data.collections.new("SimpleBake_Working")
        bpy.context.scene.collection.children.link(c)
        for o_name in bake_objects_names:
            obj = bpy.data.objects[o_name]
            if o_name not in c.objects:
                c.objects.link(obj)
            if sbp.targetobj != None and sbp.targetobj.name not in c.objects:
                c.objects.link(sbp.targetobj)
            if sbp.targetobj_cycles != None and sbp.targetobj_cycles.name not in c.objects:
                c.objects.link(sbp.targetobj_cycles)
    
        #Every object must have at least camera ray visibility
        for o_name in bake_objects_names:
            obj = bpy.data.objects[o_name]
            obj.visible_camera = True
        if sbp.targetobj != None:
            sbp.targetobj.visible_camera = True
        if sbp.targetobj_cycles != None:
            sbp.targetobj_cycles.visible_camera = True
        
        #In case of crash
        for m in bpy.data.materials:
            if "SB_working_dup" in m: del m["SB_working_dup"]
        
        return {'FINISHED'}
    
class SimpleBake_OT_Common_Bake_Finishing(Operator):
    """Finishing actions shared by all types of bake"""
    bl_idname = "simplebake.common_bake_finishing"
    bl_description = "Finishing shared by all types of bake"
    bl_label = "BakeFinish"
    
    baked_number: IntProperty()
    in_background: BoolProperty()
    bake_operation_id: StringProperty()
    
    def execute(self, context):
        
        sbp = context.scene.SimpleBake_Props
        
        BakeInProgress.is_baking = False
        
        bake_objects_names = [o.obj_point.name for o in sbp.objects_list]
        
        print_message("Common bake finishing")
        
        #Delete placeholder material
        #for obj in bpy.data.objects:
            #for mat_slot in obj.material_slots:
                #if mat_slot.material != None and mat_slot.name == "SimpleBake_Placeholder":
                    #bpy.data.materials.remove(mat_slot.material)
        if "SimpleBake_Placeholder" in bpy.data.materials:
            m = bpy.data.materials["SimpleBake_Placeholder"]
            bpy.data.materials.remove(m)
            
        #Working collection
        for c in bpy.data.collections:
            if "SimpleBake_Working" in c.name: bpy.data.collections.remove(c)
        
        #Render engine
        bpy.context.scene.render.engine = CommonBakePrepandFinish.orig_render_engine
        
        #Force to object mode
        if bpy.context.active_object == None:
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[0] #Pick arbitary
        bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
        
        #Object selection
        bpy.ops.object.select_all(action="DESELECT")
        for obj in CommonBakePrepandFinish.orig_object_selection:
            try: obj.select_set(True)
            except: pass #E.g. if user had a copy and apply object selected, and now it's gone
        try: bpy.context.view_layer.objects.active = CommonBakePrepandFinish.orig_active_object
        except: pass
        
        #Object orig_object_uvs
        if sbp.restore_orig_uv_map:
            uv_objs_names = bake_objects_names
            if sbp.targetobj != None: uv_objs_names.append(sbp.targetobj.name)
            if sbp.targetobj_cycles != None: uv_objs_names.append(sbp.targetobj_cycles.name)
        
            for o_name in uv_objs_names:
                obj = bpy.data.objects[o_name]
                if o_name in CommonBakePrepandFinish.orig_object_uvs:
                    uv_name = CommonBakePrepandFinish.orig_object_uvs[o_name]
                    if uv_name in obj.data.uv_layers:
                        obj.data.uv_layers.active = obj.data.uv_layers[uv_name] 
                if o_name in CommonBakePrepandFinish.orig_object_uvs_render:
                    uv_name = CommonBakePrepandFinish.orig_object_uvs_render[o_name]
                    if uv_name in obj.data.uv_layers:
                        obj.data.uv_layers[uv_name].active_render = True
                        
                    

        #Clear packed list
        CommonBakePrepandFinish.packed_images.clear()
        
        #Remove SimpleBake_Bakes if it's empty
        if "SimpleBake_Bakes" in bpy.data.collections:
            c = bpy.data.collections["SimpleBake_Bakes"]
            if len(c.objects) == 0: bpy.data.collections.remove(c)
        
        #Restore master copy of all materials
        bpy.ops.simplebake.material_backup(mode=MatManager.MODE_MASTER_RESTORE)
        
        #Report
        if not self.in_background and not BakeInProgress.was_error:
            message=f"Foreground bake is complete|{str(self.baked_number)} images baked"
            icon="INFO"
            centre = True
            bpy.ops.simplebake.show_message_box('INVOKE_DEFAULT', message=message, icon=icon, centre=centre)
        
        #Always reset this - 
        BakeInProgress.was_error = False
        
        
        if self.in_background:
            bpy.ops.wm.save_mainfile()
            print_message("Saving file")
        
        #If this was an S2A bake, also hide the bake objects (only target will be hidden by Copy and Apply)
        if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.copy_and_apply and sbp.hide_source_objects:
            for obj_name in bake_objects_names:
                obj = bpy.data.objects[obj_name]
                obj.hide_set(True)

        ##If this was an S2A bake, also hide the cage object if user requested this
        if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.copy_and_apply and sbp.hide_cage_object:
            obj = bpy.context.scene.render.bake.cage_object
            if obj != None: #May not have a cage object actually set
                obj.hide_set(True)


                
        #Do we want to keep the internal images after export?
        #Will not affect background bakes anyway, as we are being called after the file save
        if sbp.save_bakes_external and not sbp.keep_internal_after_export:# and not self.in_background:
            print_message("Deleting internal baked images")
            for img in bpy.data.images:
                if "SB_bake_operation_id" in img and img["SB_bake_operation_id"] == self.bake_operation_id:
                    print_message(f"Deleting {img.name}")
                    bpy.data.images.remove(img)
        
        #Unhide for rendering any objects we hid for the isolation function and clear
        for o_name in SimpleBake_OT_Select_Only_This.hidden:
            bpy.data.objects[o_name].hide_render = False
        SimpleBake_OT_Select_Only_This.hidden = []
        
        #Reload all baked images
        imgs = [i for i in bpy.data.images if ("SB_bake_operation_id" in i and 
                                               i["SB_bake_operation_id"] == self.bake_operation_id)]
        for i in imgs:
            i.reload()
        
            
        
        start_time = CommonBakePrepandFinish.start_time
        finish_time = datetime.now()
        s = (finish_time-start_time).seconds
        print_message(f"Time taken - {s} seconds ({floor(s/60)} minutes, {s%60} seconds)")
        
        return {'FINISHED'}
    
    
classes = ([
    SimpleBake_OT_Pack_Baked_Images,
    SimpleBake_OT_Scale_Images_If_Needed,
    SimpleBake_OT_Common_Bake_Prep,
    SimpleBake_OT_Common_Bake_Finishing,
    SimpleBake_OT_Select_Only_This,
    SimpleBake_OT_Compositor_Denoise,
    SimpleBake_OT_Select_Selected_To_Active,
    SimpleBake_OT_Set_Sample_Count
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
    
