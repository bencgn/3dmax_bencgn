bl_info = {
    "name": "SimpleBake",
    "author": "Lewis <www.toohey.co.uk/SimpleBake/support/>",
    "version": (3, 3, 1),
    "blender": (3, 0, 0),
    "location": "Properties Panel -> Render Settings Tab",
    "description": "Simple baking of PBR and other textures",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object",
}
import bpy
from bpy.utils import register_class, unregister_class

from . import object_preperation
from . import image_management
from . import material_management
from . import external_save
from . import property_group
from . import uv_management
from . import copy_and_apply
from . import udim_management
from . import starting_checks
from . import utils
from . import background_and_progress
from . import channel_packing
from . import auto_update
from . import presets
from . import sketchfab_upload
    
from . import ui
from . import bake_operators

from .auto_update import VersionControl

classes = ([
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)
        
    object_preperation.register()
    image_management.register()
    material_management.register()
    external_save.register()
    property_group.register()
    ui.register()
    uv_management.register()
    copy_and_apply.register()
    bake_operators.register()
    udim_management.register()
    starting_checks.register()
    utils.register()
    background_and_progress.register()
    channel_packing.register()
    auto_update.register()
    presets.register()
    sketchfab_upload.register()
    
    prefs = bpy.context.preferences.addons["SimpleBake"].preferences
    
    version = bl_info["version"]
    VersionControl.installed_version = version
    no_online_check = False
    if prefs.no_update_check:
        no_online_check = True
    VersionControl.check_at_current_version(no_online_check)
    

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
        
    object_preperation.unregister()
    image_management.unregister()
    material_management.unregister()
    external_save.unregister()
    property_group.unregister()
    ui.unregister()
    uv_management.unregister()
    copy_and_apply.unregister()
    bake_operators.unregister()
    udim_management.unregister()
    starting_checks.unregister()
    utils.unregister()
    background_and_progress.unregister()
    channel_packing.unregister()
    auto_update.unregister()
    presets.unregister()
    sketchfab_upload.unregister()
    
