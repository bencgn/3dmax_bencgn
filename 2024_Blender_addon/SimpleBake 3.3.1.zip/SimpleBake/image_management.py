import bpy
from bpy.types import Operator
from bpy.utils import register_class, unregister_class
from bpy.props import BoolProperty, StringProperty, IntProperty

import uuid
import numpy as np

from .utils import SBConstants, print_message


class SimpleBake_OT_Bake_Image(Operator):
    """Generate image to be baked to if needed"""
    bl_idname = "simplebake.bake_image"
    bl_description = "Generates image to be baked to if needed"
    bl_label = "GenImage"
    
    need_first_time_settings = []

    merged_bake: BoolProperty()
    merged_bake_name: StringProperty()
    bake_operation_id: StringProperty()
    this_bake: StringProperty()
    target_object_name: StringProperty()
    global_mode: StringProperty()
    use_alpha: BoolProperty()
    float_buffer: BoolProperty()
    img_height: IntProperty()
    img_width: IntProperty()
    udims: BoolProperty()
    udim_tiles_number: IntProperty()
    batch_name: StringProperty()
    clear_image: BoolProperty(default=False)
    
    
    udim_id = ""

    
    def create_individual_bake_image(self):
        print_message("Getting individual baked image")
        
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        proposed_name = prefs.img_name_format

        alias_dict = prefs.get_alias_dict()
        if self.this_bake in alias_dict: this_bake = alias_dict[self.this_bake]
        else: this_bake = self.this_bake
        
        proposed_name = proposed_name.replace("%OBJ%", self.target_object_name)
        proposed_name = proposed_name.replace("%BAKEMODE%", self.global_mode)
        proposed_name = proposed_name.replace("%BAKETYPE%", this_bake)
        proposed_name = proposed_name.replace("%BATCH%", self.batch_name)
        
        if self.udims:
            proposed_name = proposed_name + ".1001"
            
        need_new = False
        if proposed_name in bpy.data.images and not self.clear_image:
            #It's there, and we aren't going to clear it

            #No action for now
            i = bpy.data.images[proposed_name]
            self.created_images.append(i)
            self.set_image_tags(i)
            need_new = False

        elif proposed_name in bpy.data.images:
            #It's there, but we want to clear it
            bpy.data.images.remove(bpy.data.images[proposed_name])
            need_new = True

        else:
            #It's not there
            need_new = True
        
        if need_new:
            #Actually Create the image
            i = bpy.data.images.new(proposed_name, self.img_width, self.img_height, alpha=self.use_alpha, float_buffer=self.float_buffer)
            self.created_images.append(i)
            self.set_image_tags(i)
            self.need_first_time_settings.append(i)
        else:
            #self.need_first_time_settings = False
            pass
        
    
    def create_merged_bake_image(self):
        print_message("Getting merged bake image")
        
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        proposed_name = prefs.img_name_format

        alias_dict = prefs.get_alias_dict()
        if self.this_bake in alias_dict: this_bake = alias_dict[self.this_bake]
        else: this_bake = self.this_bake
        
        proposed_name = proposed_name.replace("%OBJ%", self.merged_bake_name)
        proposed_name = proposed_name.replace("%BAKEMODE%", self.global_mode)
        proposed_name = proposed_name.replace("%BAKETYPE%", this_bake)
        proposed_name = proposed_name.replace("%BATCH%", self.batch_name)
        #else:
        if self.udims:
            proposed_name = proposed_name + ".1001"
        
        need_new = False
        
        if proposed_name not in bpy.data.images:
            need_new = True
        else:
            i = bpy.data.images[proposed_name]
            if "SB_bake_operation_id" in i and i["SB_bake_operation_id"] != self.bake_operation_id:
                #It's there, but different bake ID
                if self.clear_image:
                    bpy.data.images.remove(i)
                    need_new = True
                else:
                    #Essentially do nothing
                    pass

            elif "SB_bake_operation_id" not in i:
                 #It's there, but it doesn't even have an ID. This will be a weird coincidence
                if self.clear_image:
                    bpy.data.images.remove(i)
                    need_new = True
                else:
                    #Essentially do nothing
                    pass

            elif "SB_bake_operation_id" in i and i["SB_bake_operation_id"] == self.bake_operation_id:
                #It's there, and it's our bake
                need_new = False
                
        if need_new:
            i = bpy.data.images.new(proposed_name, self.img_width, self.img_height, alpha=self.use_alpha, float_buffer=self.float_buffer)
            self.created_images.append(i)
            self.set_image_tags(i)
            self.need_first_time_settings.append(i)

        else:
            #Just using existing image, pretend we created it
            #i is created up on line 113
            self.created_images.append(i)
            self.set_image_tags(i)


    
    def set_image_tags(self, i):
        i["SB_bake_object"] = self.target_object_name
        i["SB_global_mode"] = self.global_mode
        i["SB_this_bake"] = self.this_bake
        i["SB_merged_bake"] = self.merged_bake
        i["SB_merged_bake_name"] = self.merged_bake_name
        i["SB_bake_operation_id"] = self.bake_operation_id
        i["SB_float_buffer"] = self.float_buffer
        i["SB_scaled"] = False
        i["SB_exported_list"] = []
        i["SB_denoised"] = False
        i["SB_udim_secondary"] = False
        
        if self.udims:
            i["SB_udim_id"] = self.udim_id
            i["SB_udim_tile_number"] = 1
            
    
    def create_udim_images(self):
        print_message("Creating UDIM image set")
        
        sbp = bpy.context.scene.SimpleBake_Props
        counter = 1001
        #Only one in the list at this point
        #For udims, it will already have the 1001 suffix
        img = self.created_images[0]
        udim_base_name = img.name.replace(".1001","")
        #img["SB_udim_base_name"] = udim_base_name
        #img.name = f"{udim_base_name}.{str(counter)}"
        
        #Now the others
        udim_tiles_number = self.udim_tiles_number+1000
        
        while(counter<udim_tiles_number):
            counter+=1
            proposed_name = f"{udim_base_name}.{str(counter)}"
            
            need_new = False
            if proposed_name in bpy.data.images:
                #It's there
                #Just delete it
                bpy.data.images.remove(bpy.data.images[proposed_name])
                need_new = True
            else:
                #It's not there
                need_new = True

            if need_new:
                i = bpy.data.images.new(proposed_name, self.img_width, self.img_height,
                                alpha=self.use_alpha, float_buffer=self.float_buffer)
                self.need_first_time_settings.append(i)
            else:
                #Still need i
                i = bpy.data.images[proposed_name]
            
            #Set UDIM tags not matter what
            i["SB_bake_operation_id"] = self.bake_operation_id
            i["SB_udim_secondary"] = True
            i["SB_udim_id"] = self.udim_id
            i["SB_scaled"] = False
            i["SB_exported_list"] = []
            i["SB_udim_tile_number"] = str(counter - 1000)
            i["SB_this_bake"] = self.this_bake
            i["SB_float_buffer"] = self.float_buffer
            i["SB_bake_object"] = self.target_object_name
            i["SB_denoised"] = False
            
            
    def set_image_settings(self, imgs):
        sbp = bpy.context.scene.SimpleBake_Props
        for i in imgs:
            print_message(f"Adjusting settings on new image {i.name}")
            if self.this_bake == SBConstants.PBR_NORMAL:
                i.generated_color = (0.5,0.5,1.0,1.0) #Normal ignores the use alpha option
            elif self.this_bake == "NORMAL": #CyclesBake normal
                i.generated_color = (0.5,0.5,1.0,1.0) #Normal ignores the use alpha option
            elif self.use_alpha:
                i.generated_color = (0.0,0.0,0.0,0.0)
            else:
                i.generated_color = (0.0,0.0,0.0,1.0)
            
            #if self.this_bake not in [SBConstants.PBR_DIFFUSE, "COMBINED", "DIFFUSE", SBConstants.LIGHTMAP]:
                #i.colorspace_settings.name = "Non-Color"
            
            prefs = bpy.context.preferences.addons["SimpleBake"].preferences
            cs_dict = prefs.get_cs_dict()
            
            if self.this_bake in cs_dict:
                cs = cs_dict[self.this_bake]
            elif self.global_mode in [SBConstants.CYCLESBAKE,SBConstants.CYCLESBAKE_S2A] and bpy.context.scene.cycles.bake_type != "NORMAL": 
                cs = sbp.cyclesbake_cs
            else:
                cs = "Non-Color"
            
            #Will throw an errror for ACES. Not ideal, but force everything to role_data for now
            try:
                i.colorspace_settings.name = cs
            #ACES
            except:
                print_message("WARNING - Was unable to set to Non-Color space. Falling back to role_data for ACES")
                i.colorspace_settings.name = "role_data"
    
    def execute(self, context):

        sbp = bpy.context.scene.SimpleBake_Props
        
        #If we are baking to an existing image, then we don't need to do anything other than set tags
        #if sbp.tex_override:
            #self.set_image_tags(sbp.tex_override_tex)
            #return {'FINISHED'}

        self.need_first_time_settings = []
        self.created_images = []

        #Has to be created here, or it won't be the same for all images
        self.udim_id = str(uuid.uuid4())

        
        if self.merged_bake:
            self.create_merged_bake_image()
        else:
            self.create_individual_bake_image()
            
            
        #We had to create a new image
        if self.created_images != []:
            #Create the counterpart UDIM images if we want them
            if self.udims:
                self.create_udim_images()

            #Set image settings for images that are freshly created
            self.set_image_settings(self.need_first_time_settings)
        
        else:
            print_message("Using existing image")
        
        return {'FINISHED'}
    


classes = ([
        SimpleBake_OT_Bake_Image
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
