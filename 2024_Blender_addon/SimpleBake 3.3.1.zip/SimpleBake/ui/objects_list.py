import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import Operator, PropertyGroup, UIList
from bpy.props import EnumProperty

def refresh_bake_objects_list():
    
    sbp = bpy.context.scene.SimpleBake_Props
    objects_list = sbp.objects_list

    gone = []
    for li in objects_list:
        #Is it empty?
        if li.obj_point == None:
            gone.append(li.name)
            
        #Is it not in use anywhere else?
        elif len(li.obj_point.users_scene) < 1:
            gone.append(li.name)


    for g in gone:
        objects_list.remove(objects_list.find(g))
        #We were the only user (presumably)
        if g in bpy.data.objects:
            bpy.data.objects.remove(bpy.data.objects[g])


class SIMPLEBAKE_UL_Objects_List(UIList):
    """Bake objects list"""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):

        # Icon
        custom_icon = 'OBJECT_DATAMODE'

        # Support all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.obj_point.name, icon = custom_icon)

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon = custom_icon)


class SimpleBake_OT_Add_Bake_Object(Operator):
    """Add selected object(s) to the bake list"""

    bl_idname = "simplebake.add_bake_object"
    bl_label = "Adds a bake object to the list"

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects)
    
    def execute(self, context):
        #Lets get rid of the non-mesh objects from the selections
        [obj.select_set(False) for obj in bpy.data.objects if obj.type != "MESH"]

        #Do we still have an active object?
        if bpy.context.active_object == None:
            #If not, pick one
            bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
    
        #Add to list if not already in the list
        objs = bpy.context.selected_objects.copy()
        sbp = context.scene.SimpleBake_Props
        for obj in objs:
            r = [o.name for o in sbp.objects_list if o.name == obj.name]
            if len(r) == 0:
                n = sbp.objects_list.add()    
                n.obj_point = obj
                n.name = obj.name
        
        #Throw in a refresh
        refresh_bake_objects_list()
        
        return{'FINISHED'}


class SimpleBake_OT_Remove_Bake_Object(Operator):
    """Remove the selected object from the bake list."""

    bl_idname = "simplebake.remove_bake_object"
    bl_label = "Removes a bake object from the list"

    @classmethod
    def poll(cls, context):
        #TODO-------
        return context.scene.SimpleBake_Props.objects_list

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        objects_list = sbp.objects_list
        index = sbp.objects_list_index

        objects_list.remove(index)
        sbp.objects_list_index = min(max(0, index - 1), len(objects_list) - 1)
        
        #Throw in a refresh
        refresh_bake_objects_list()
        
        return{'FINISHED'}


class SimpleBake_OT_Clear_Bake_Objects_List(Operator):
    """Clear the object list"""

    bl_idname = "simplebake.clear_bake_objects_list"
    bl_label = "Clears the bake object list"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        sbp.objects_list.clear()
        
        #Throw in a refresh
        refresh_bake_objects_list()
        
        return{'FINISHED'}

class SimpleBake_OT_Move_Bake_Object_List(Operator):
    """Move an object in the list."""

    bl_idname = "simplebake.move_bake_object_list"
    bl_label = "Moves an item in the bake objects list"

    direction: bpy.props.EnumProperty(items=(('UP', 'Up', ""),
                                              ('DOWN', 'Down', ""),))

    @classmethod
    def poll(cls, context):
        return context.scene.SimpleBake_Props.objects_list

    def move_index(self):
        """ Move index of an item render queue while clamping it. """
        sbp = bpy.context.scene.SimpleBake_Props
        index = sbp.objects_list_index
        list_length = len(sbp.objects_list) - 1  # (index starts at 0)
        new_index = index + (-1 if self.direction == 'UP' else 1)

        sbp.objects_list_index = max(0, min(new_index, list_length))

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        objects_list = sbp.objects_list
        index = sbp.objects_list_index

        neighbor = index + (-1 if self.direction == 'UP' else 1)
        objects_list.move(neighbor, index)
        self.move_index()
        
        #Throw in a refresh
        refresh_bake_objects_list()
        
        return{'FINISHED'}


class SimpleBake_OT_Refresh_Bake_Object_List(Operator):
    """Refresh the list to remove objects"""

    bl_idname = "simplebake.refresh_bake_object_list"
    bl_label = "Refresh the bake objects list"

    @classmethod
    def poll(cls, context):
        return True


    def execute(self, context):
        refresh_bake_objects_list()
        
        return{'FINISHED'}
    
classes = ([
        SIMPLEBAKE_UL_Objects_List,
        SimpleBake_OT_Add_Bake_Object,
        SimpleBake_OT_Remove_Bake_Object,
        SimpleBake_OT_Clear_Bake_Objects_List,
        SimpleBake_OT_Move_Bake_Object_List,
        SimpleBake_OT_Refresh_Bake_Object_List
        
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
