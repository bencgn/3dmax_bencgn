import bpy 
from bpy.utils import register_class, unregister_class
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

import os

from .utils import SBConstants, print_message

                
class SimpleBake_OT_Copy_And_Apply(Operator):
    """Copy the baked objects and apply baked textures"""
    bl_idname = "simplebake.copy_and_apply"
    bl_description = "Copy baked objects and apply bakes"
    bl_label = "Copy and apply"
    
    target_object_name: StringProperty()
    bake_operation_id: StringProperty()
    used_glossy: BoolProperty(default = False)
    used_directx: BoolProperty(default = False)
    hide_source_objects: BoolProperty(default = False)
    global_mode: StringProperty()
    cyclesbake_mat_format: StringProperty(default = "emission")
    
    #preserve_materials: BoolProperty(default = False)
    merged_bake: BoolProperty(default = False) 
    merged_bake_name: StringProperty(default = "")
    
    glTF: BoolProperty()
    glTF_option: StringProperty()
    
    in_background: BoolProperty()

    def import_cyclesbake_mat_setup(self, context, new_obj, merged=False):


        if self.cyclesbake_mat_format == "emission":
            import_mat_name = "SB_cyclesbake_e"
        elif self.cyclesbake_mat_format == "background":
            import_mat_name = "SB_cyclesbake_b"
        else:
            import_mat_name = "SB_cyclesbake_p"
        [bpy.data.materials.remove(mat) for mat in bpy.data.materials if mat.name == import_mat_name]
        path = os.path.dirname(__file__) + "/resources/copy_and_apply_mats.blend/Material/"
        bpy.ops.wm.append(filename=import_mat_name, directory=path)
        mat = bpy.data.materials[import_mat_name]
        
        #Assign to object
        new_obj.data.materials.append(mat)
        
        if merged:
            mat.name = f"{self.merged_bake_name}_Baked"
            mat["SB_bake_operation_id"] = self.bake_operation_id
        else:    
            mat.name = f"{new_obj.name}" #Already includes "_baked"

        return mat

    
    def import_pbr_mat_setup(self, context, new_obj, merged=False):
        sbp = bpy.context.scene.SimpleBake_Props
        
        #Which mat do we need to import?
        if self.used_glossy and self.used_directx: import_mat_name = "SB_pbr_directx_and_glossy"
        elif self.used_glossy and not self.used_directx: import_mat_name = "SB_pbr_glossy"
        elif not self.used_glossy and self.used_directx: import_mat_name = "SB_pbr_directx"
        else: import_mat_name = "SB_standard_pbr"
        
        #Import the PBR node setup that we need and assign to object
        [bpy.data.materials.remove(mat) for mat in bpy.data.materials if mat.name == import_mat_name]
        path = os.path.dirname(__file__) + "/resources/copy_and_apply_mats.blend/Material/"
        bpy.ops.wm.append(filename=import_mat_name, directory=path)
        mat = bpy.data.materials[import_mat_name]
        
        #Assign to object
        new_obj.data.materials.append(mat)
        
        if merged:
            mat.name = f"{self.merged_bake_name}_Baked"
            mat["SB_bake_operation_id"] = self.bake_operation_id
        else:
            mat.name = f"{new_obj.name}" #Already includes "_baked" 

        #If we are baking alpha or transparency, set the blend mode
        if sbp.selected_alpha or sbp.selected_trans:
            mat.blend_method = "BLEND"

        return mat
        
    def create_cyclesbake_setup(self, context, new_obj):
        mat = self.import_cyclesbake_mat_setup(context, new_obj)
        node_tree = mat.node_tree
        nodes = node_tree.nodes
        
        #The non-specials texture
        tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                and i["SB_bake_operation_id"] == self.bake_operation_id
                and "SB_this_bake" in i and i["SB_this_bake"] not in SBConstants.ALL_SPECIALS
                and i["SB_bake_object"] == self.target_object_name
                ])
        assert len(tex) == 1
        tex = tex[0]
        
        node = [n for n in nodes if n.label=="cyclesbake"]
        assert len(node) == 1
        node = node[0]
        node.image = tex
        
        #The specials textures
        for bake_type in SBConstants.ALL_SPECIALS:
            node = [n for n in nodes if n.label==bake_type]
            if len(node) == 0: continue #E.g. Glossy will not be there for standard
            else: node = node[0]
            tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                            and i["SB_bake_operation_id"] == self.bake_operation_id
                            and "SB_this_bake" in i and i["SB_this_bake"] == bake_type
                            and i["SB_bake_object"] == self.target_object_name
                            ])
            if len(tex) == 1:
                tex = tex[0]
                node.image = tex
            else:
                nodes.remove(node)
        return mat
    
    def create_cyclesbake_setup_merged(self, context, new_obj):
        
        #Check if we already have the merged texture
        mat_name = f"{self.merged_bake_name}_Baked"
        if mat_name in bpy.data.materials:
            mat = bpy.data.materials[mat_name]
            if "SB_bake_operation_id" in mat and mat["SB_bake_operation_id"] == self.bake_operation_id:
                mat = bpy.data.materials[mat_name]
                #Assign existing merged mat to object and leave
                new_obj.data.materials.append(mat)
                return mat
        
        mat = self.import_cyclesbake_mat_setup(context, new_obj, merged=True)
        node_tree = mat.node_tree
        nodes = node_tree.nodes
        
        #The non-specials texture
        tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                and i["SB_bake_operation_id"] == self.bake_operation_id
                and "SB_this_bake" in i and i["SB_this_bake"] not in SBConstants.ALL_SPECIALS
                ])
        assert len(tex) == 1
        tex = tex[0]
        
        node = [n for n in nodes if n.label=="cyclesbake"]
        assert len(node) == 1
        node = node[0]
        node.image = tex
        
        #The specials textures
        for bake_type in SBConstants.ALL_SPECIALS:
            node = [n for n in nodes if n.label==bake_type]
            if len(node) == 0: continue #E.g. Glossy will not be there for standard
            else: node = node[0]
            tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                            and i["SB_bake_operation_id"] == self.bake_operation_id
                            and "SB_this_bake" in i and i["SB_this_bake"] == bake_type])
            if len(tex) == 1:
                tex = tex[0]
                node.image = tex
            else:
                nodes.remove(node)
        return mat
        
        
    def create_pbr_setup(self, context, new_obj):
        
        mat = self.import_pbr_mat_setup(context, new_obj)
        node_tree = mat.node_tree
        nodes = node_tree.nodes
        
        bake_types = SBConstants.ALL_PBR_MODES #Every possible bake mode for PBR
        bake_types += SBConstants.ALL_SPECIALS #Every possible bake mode for specials
        #Set the textures
        for bake_type in bake_types:
            node = [n for n in nodes if n.label==bake_type]
            if len(node) == 0: continue #E.g. Glossy will not be there for standard
            else: node = node[0]
            tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                            and i["SB_bake_operation_id"] == self.bake_operation_id
                            and "SB_this_bake" in i and i["SB_this_bake"] == bake_type
                            and "SB_bake_object" in i and i["SB_bake_object"] == self.target_object_name])
            if len(tex) == 1:
                tex = tex[0]
                node.image = tex
            else:
                nodes.remove(node)
        return mat
        
    def create_pbr_setup_merged(self, context, new_obj):
        
        #Check if we already have the merged texture
        mat_name = f"{self.merged_bake_name}_Baked"
        if mat_name in bpy.data.materials:
            mat = bpy.data.materials[mat_name]
            if "SB_bake_operation_id" in mat and mat["SB_bake_operation_id"] == self.bake_operation_id:
                mat = bpy.data.materials[mat_name]
                #Assign existing merged mat to object and leave
                new_obj.data.materials.append(mat)
                return mat
                
        #No existing merged bake material
        mat = self.import_pbr_mat_setup(context, new_obj, merged=True)
        node_tree = mat.node_tree
        nodes = node_tree.nodes
        
        bake_types = SBConstants.ALL_PBR_MODES #Every possible bake mode for PBR
        bake_types += SBConstants.ALL_SPECIALS #Every possible bake mode for specials
        #Set the textures
        for bake_type in bake_types:
            node = [n for n in nodes if n.label==bake_type]
            if len(node) == 0: continue #E.g. Glossy will not be there for standard
            else: node = node[0]
            tex = ([i for i in bpy.data.images if "SB_bake_operation_id" in i 
                            and i["SB_bake_operation_id"] == self.bake_operation_id
                            and "SB_this_bake" in i and i["SB_this_bake"] == bake_type
                            and "SB_merged_bake" in i and i["SB_merged_bake"] == True
                            and "SB_merged_bake_name" in i and i["SB_merged_bake_name"] == self.merged_bake_name
                            ])
            if len(tex) == 1:
                tex = tex[0]
                node.image = tex
            else:
                nodes.remove(node)
        
        return mat
        
    def hook_up_glTF_node(self, context, mat):
        node_tree = mat.node_tree
        nodes = node_tree.nodes
        
        glTF_node = [n for n in nodes if n.label == "gltf"]
        assert(len(glTF_node))
        glTF_node = glTF_node[0]
        
        target_option = self.glTF_option
        
        target_node = [n for n in nodes if n.label == target_option]
        assert(len(target_node))
        target_node = target_node[0]
            
        node_tree.links.new(target_node.outputs[0], glTF_node.inputs[0])
            
    
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props
        
        print_message(f"Creating prepared object {self.target_object_name}")
        
        source_obj = bpy.data.objects[self.target_object_name]
        
        if (source_obj.name + "_Baked") in bpy.data.objects:
            bpy.data.objects.remove(bpy.data.objects[source_obj.name + "_Baked"])
        
        new_obj = source_obj.copy()
        new_obj.data = source_obj.data.copy()
        
        new_obj["SB_copy_and_apply_from"] = source_obj.name
        new_obj["SB_bake_operation_id"] = self.bake_operation_id
        
        new_obj.name = source_obj.name + "_Baked"
        
        new_obj.data.materials.clear()

        if "SB_BG_HIDE" in new_obj:
            del new_obj["SB_BG_HIDE"]
        
        #Create a collection for our baked objects if it doesn't exist
        if self.in_background: col_name = "SimpleBake_Bakes_Background"
        else: col_name = "SimpleBake_Bakes"
        if col_name not in bpy.data.collections:
            col = bpy.data.collections.new(col_name)
            context.scene.collection.children.link(col)
        else:
            col = bpy.data.collections[col_name]
            if col_name not in context.scene.collection.children:
                context.scene.collection.children.link(col)
        
        try: col.color_tag = "COLOR_05"
        except AttributeError: pass

        #Make sure it's visible and enabled for current view laywer
        bpy.context.view_layer.layer_collection.children[col_name].exclude = False
        bpy.context.view_layer.layer_collection.children[col_name].hide_viewport = False
        
        #Link object to our new collection
        col.objects.link(new_obj)
        
        #Set active uv to one we used for bake for this object. Remove others.
        bake_uv_name = source_obj["SB_uv_used_for_bake"]
        new_obj.data.uv_layers.active = new_obj.data.uv_layers[bake_uv_name]
        del_list = [uvl.name for uvl in new_obj.data.uv_layers if uvl.name != bake_uv_name]
        [new_obj.data.uv_layers.remove(new_obj.data.uv_layers[name]) for name in del_list]
        
        if self.global_mode in [SBConstants.PBR, SBConstants.PBRS2A] and self.merged_bake:
            mat = self.create_pbr_setup_merged(context,new_obj)
        elif self.global_mode in [SBConstants.PBR, SBConstants.PBRS2A]:
            mat = self.create_pbr_setup(context, new_obj)
        elif self.global_mode in [SBConstants.CYCLESBAKE, SBConstants.CYCLESBAKE_S2A] and self.merged_bake:
            mat = self.create_cyclesbake_setup_merged(context, new_obj)
        elif self.global_mode in [SBConstants.CYCLESBAKE, SBConstants.CYCLESBAKE_S2A]:
            mat = self.create_cyclesbake_setup(context, new_obj)
        else:
            print_message("Something went wrong with Copy and Apply")
        
        #Hook up glTF node?
        if self.glTF:
            self.hook_up_glTF_node(context, mat)
        
        
        #Hide source objects?
        if self.hide_source_objects:
            source_obj.hide_set(True)
       
        return {'FINISHED'}

classes = ([
    SimpleBake_OT_Copy_And_Apply
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
