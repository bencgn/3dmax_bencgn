import bpy, os, math
from bpy.types import Operator
from bpy.props import StringProperty, StringProperty, EnumProperty

from ..bl_class_registry import BlClassRegistry
from ..core.serializer.asset_serializer import PlxAsset
from ..addon.distribution import AssetCollection, AssetCategory

from ..utils.asset_utilities import get_and_set_inputs
from ..utils.general_utilities import get_context_pointer

def get_category_enum_items(self, context):
    return AssetCategory.get_enum_items(self.asset_type)

@BlClassRegistry()
class PHILOGIX_OT_SelectAsset(Operator):
    bl_idname = "plx.select_asset"
    bl_label = "Choose Assets"
    bl_description = "Choose Assets" 
    bl_options = {'UNDO'}

    asset_type: StringProperty()
    search_keyword: StringProperty()
    categorys: EnumProperty(
        name='Category',
        description='List of available material category',
        items=get_category_enum_items
    )

    value_node = None

    def draw(self, context):
        if not self.value_node:
            self.value_node = get_context_pointer(context, 'active_value_node')
        self.layout.context_pointer_set("active_value_node", self.value_node)
        
        props = context.scene.PlxProps
        
        asset_items = AssetCollection.get_asset_items(self.asset_type, self.categorys, self.search_keyword)
        assets_dict = iter(asset_items.items())

        num_items = len(asset_items)
        max_num_cols = props.category_display_cols
        max_num_items = max(math.ceil(num_items/max_num_cols)*max_num_cols, max_num_cols)

        item_scale = props.category_display_size/10

        self.layout.ui_units_x = max_num_cols * item_scale + 3

        box = self.layout.box()
        row = box.row()
        row.label(text=f"{self.asset_type} Category:", icon='MOUSE_LMB_DRAG')
        row.prop(self, 'categorys', text='')
        row.prop(self, 'search_keyword', text='', icon='VIEWZOOM')

        row = box.row()
        row.label(text=' ')
        row.prop(props, 'category_display_size', text='Size')
        row.prop(props, 'category_display_cols', text='Columns')

        grid = self.layout.grid_flow(columns=max_num_cols, even_columns=True, even_rows=True, row_major=True)

        for _ in range(max_num_items):
            item  = next(assets_dict, None)

            if item:
                asset_id, asset_info = item
                asset_name, asset_preview, _ = asset_info.values()
                
                col = grid.column(align=True)

                row = col.row()
                row.scale_y = item_scale
                row.ui_units_y = 0.001

                update_operator = row.operator("plx.update_asset", text=' ', emboss=True)
                update_operator.asset_id = asset_id
                update_operator.asset_type = self.asset_type

                row = col.row()
                row.template_icon(icon_value=asset_preview, scale=item_scale)

                if props.category_display_size < 35:
                    col.separator(factor=item_scale/2.75)
                else:
                    row = col.row()
                    row.alignment = 'CENTER'
                    row.label(text=asset_name)
            else:
                grid.column()

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self, width=300)
    
    def execute(self, context):
        return {'FINISHED'}

@BlClassRegistry()
class PHILOGIX_OT_UpdateAssets(Operator):
    bl_idname = "plx.update_asset"
    bl_label = "Update Assets"
    bl_description = "Update Assets" 
    bl_options = {'UNDO'}

    asset_id: StringProperty()
    asset_type: StringProperty()

    def execute(self, context):
        if self.asset_type == 'Brushes':
            loaded_asset = None

            for brush in bpy.data.brushes:
                if brush.PlxAssetId == self.asset_id:
                    loaded_asset = brush
                    break
                
            if not loaded_asset:
                loaded_asset = PlxAsset.load_asset(self.asset_id)

            loaded_asset.use_custom_icon = True
            loaded_asset.icon_filepath = AssetCollection.get_preview_path(self.asset_id)
            context.tool_settings.image_paint.brush = loaded_asset

        else:
            active_value_node = get_context_pointer(context, 'active_value_node')
            if active_value_node:
                prev_asset = active_value_node.node_tree
                loaded_asset = PlxAsset.load_asset(self.asset_id)
                active_value_node.node_tree = loaded_asset
                get_and_set_inputs(active_value_node, loaded_asset)

                if prev_asset:
                    bpy.data.node_groups.remove(prev_asset)

            layer_group_props = active_value_node.id_data.PlxProps
            layer_group_props.uv_settings.uv_projection_mode = layer_group_props.uv_settings.uv_projection_mode

        self.report({'INFO'}, f"Applied assets: '{loaded_asset.PlxAssetName}'!")
        return {'FINISHED'}
