import bpy, gpu, blf
import numpy as np
from gpu_extras.batch import batch_for_shader

from ..utils.object_utilities import get_active_material, get_active_mesh_object


# Define indices for triangle rendering
indices = ((0, 1, 2), (2, 1, 3), (0, 1, 1), (1, 2, 2), (2, 2, 3), (3, 0, 0))

# Load shaders
shader_name = 'UNIFORM_COLOR'
fill_shader = gpu.shader.from_builtin(shader_name)
edge_shader = gpu.shader.from_builtin(shader_name)

def draw(operator):
    # Extract relevant variables from the operator
    m_x, m_y = operator.x - 20, operator.y + 40
    curr_color = tuple(list(operator.curr_color) + [1.0])

    # Set uniform color for fill shader
    fill_shader.uniform_float("color", curr_color)

    # Define vertices for fill drawing
    draw_verts = (
        (m_x, m_y),
        (m_x + 20, m_y),
        (m_x, m_y - 20),
        (m_x + 20, m_y - 20)
    )

    # Draw filled rectangle
    batch = batch_for_shader(fill_shader, 'TRIS', {"pos": draw_verts}, indices=indices)
    batch.draw(fill_shader)

    # Set uniform color for edge shader
    edge_shader.uniform_float("color", (0.5, 0.5, 0.5, 0.5))

    # Define edges for edge drawing
    edges = (
        draw_verts[0], draw_verts[1],
        draw_verts[0], draw_verts[2],
        draw_verts[2], draw_verts[3],
        draw_verts[1], draw_verts[3]
    )

    # Draw edges
    edge_batch = batch_for_shader(edge_shader, 'LINES_ADJ', {"pos": edges})
    edge_batch.draw(edge_shader)

    # Convert RGB color to hexadecimal
    hex_color = '#{:02x}{:02x}{:02x}'.format(*(int(c * 255) for c in operator.curr_color[:3]))

    # Draw color value using Blender Font Drawing
    font_id = 0
    blf.position(font_id, m_x + 25, m_y - 15, 0)
    blf.size(font_id, 16)
    blf.color(font_id, 0.5, 0.5, 0.5, 0.75)
    blf.draw(font_id, hex_color)

def srgb_to_linear(c):
    if c <= 0.04045:
        return c / 12.92
    else:
        return ((c + 0.055) / 1.055) ** 2.4


class SceneSettings:
    def __init__(self, context):
        self.context = context
        self.store()

    def store(self):
        space_data = self.context.space_data
        shading = space_data.shading
        overlay = space_data.overlay

        self.prev_image_spaces = []
        for area in self.context.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                space = area.spaces[0]
                self.prev_image_spaces.append([space, space.use_image_pin])

        self.prev_image_paint_mode = self.context.tool_settings.image_paint.mode
        self.prev_canvas = self.context.tool_settings.image_paint.canvas

        self.prev_mode = self.context.active_object.mode
        self.prev_shading_type = shading.type
        self.prev_shading_light = shading.light
        self.prev_shading_color_type = shading.color_type
        self.prev_show_overlays = overlay.show_overlays
        
        self.prev_use_dof = shading.use_dof
        self.prev_show_xray = shading.show_xray
        self.prev_show_cavity = shading.show_cavity
        self.prev_show_shadows = shading.show_shadows
        self.prev_show_object_outline = shading.show_object_outline

    def restore(self):
        # Restore previous settings
        context = self.context

        context.tool_settings.image_paint.mode = self.prev_image_paint_mode
        context.tool_settings.image_paint.canvas = self.prev_canvas

        context.space_data.shading.type = self.prev_shading_type
        context.space_data.shading.light = self.prev_shading_light
        context.space_data.shading.color_type = self.prev_shading_color_type
        context.space_data.overlay.show_overlays = self.prev_show_overlays

        context.space_data.shading.use_dof = self.prev_use_dof
        context.space_data.shading.show_xray = self.prev_show_xray
        context.space_data.shading.show_cavity = self.prev_show_cavity
        context.space_data.shading.show_shadows = self.prev_show_shadows
        context.space_data.shading.show_object_outline = self.prev_show_object_outline

        bpy.ops.object.mode_set(mode=self.prev_mode)

        for area in self.prev_image_spaces:
            space = area[0]
            space.use_image_pin = area[1]


class PHILOGIX_OT_screen_picker(bpy.types.Operator):
    bl_idname = 'plx.screen_picker'
    bl_label = 'Color Picker'
    bl_description = 'Extract color information from a selected group of neighboring pixels'
    bl_options = {'REGISTER'}

    id_node_name: bpy.props.StringProperty()
    color_node_name: bpy.props.StringProperty()

    curr_color: bpy.props.FloatVectorProperty(
        default=(0.0, 0.0, 0.0),
        precision=4,
        description='The mean RGB values of the picked pixels',
        subtype='COLOR_GAMMA'
    )
    
    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            self.x = event.mouse_region_x
            self.y = event.mouse_region_y

            fb = gpu.state.active_framebuffer_get()

            # Read color from framebuffer
            curr_picker_buffer = fb.read_color(event.mouse_x, event.mouse_y, 1, 1, 3, 0, 'FLOAT')
            self.curr_color = np.array(curr_picker_buffer.to_list()).reshape(-1)

        if event.type == 'LEFTMOUSE':
            id_node = bpy.data.node_groups[self.id_node_name]
            color_node = id_node.nodes[self.color_node_name]

            R_sRGB, G_sRGB, B_sRGB = self.curr_color[:3]

            R_linear = srgb_to_linear(R_sRGB)
            G_linear = srgb_to_linear(G_sRGB)
            B_linear = srgb_to_linear(B_sRGB)

            color_node.inputs['Color'].default_value = (R_linear, G_linear, B_linear, 1.0)

            self.scene_settings.restore()
            space = getattr(bpy.types, self.space_type)
            space.draw_handler_remove(self._handler, 'WINDOW')
            context.window.cursor_modal_restore()
            context.workspace.status_text_set(None)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.scene_settings.restore()
            space = getattr(bpy.types, self.space_type)
            space.draw_handler_remove(self._handler, 'WINDOW')
            context.window.cursor_modal_restore()
            context.workspace.status_text_set(None)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.workspace.status_text_set(text="Pick a custom Color from the Screen. Press Esc or Rightclick to Cancel")

        mat = get_active_material()
        obj = get_active_mesh_object()
        bake_images = obj.data.PlxProps.bake_images
        id_bake_image = bake_images.get('ID')

        if not id_bake_image or not id_bake_image.image:
            self.report({'INFO'}, "Map ID not found!")
            return {"CANCELLED"}

        id_bake_image = id_bake_image.image
        uv_layer = obj.data.uv_layers.get(obj.data.PlxProps.bake_uvmap)

        self.x = event.mouse_region_x
        self.y = event.mouse_region_y

        self.scene_settings = SceneSettings(context)

        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

        if uv_layer: uv_layer.active = True

        context.tool_settings.image_paint.mode = 'IMAGE'
        context.tool_settings.image_paint.canvas = id_bake_image

        context.space_data.shading.type = 'SOLID'
        context.space_data.shading.light = 'FLAT'
        context.space_data.shading.color_type = 'TEXTURE'
        context.space_data.overlay.show_overlays = False

        context.space_data.shading.show_xray = False
        context.space_data.shading.show_shadows = False
        context.space_data.shading.show_cavity = False
        context.space_data.shading.use_dof = False
        context.space_data.shading.show_object_outline = False

        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('EYEDROPPER')

        self.space_type = context.space_data.__class__.__name__
        space = getattr(bpy.types, self.space_type)
        self._handler = space.draw_handler_add(draw, (self,), 'WINDOW', 'POST_PIXEL')

        return {'RUNNING_MODAL'}
