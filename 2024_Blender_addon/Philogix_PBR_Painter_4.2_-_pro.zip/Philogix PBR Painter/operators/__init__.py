###############   IMPORTS
import bpy
from . import (
    asset_management, 
    category_management, 
    layers, 
    baking_manager, 
    image_management, 
    material_management, 
    exporting_manager, 
    screen_picker
    )

from ..core.registration_manager import RegistrationManager

if RegistrationManager().is_dev_version:
    from . import version_develop

if RegistrationManager().is_pro_version:
    from . import version_pro
else:
    from . import version_trailer

###############   REGISTER ADDON
classes = (
    # Material
    material_management.PHILOGIX_OT_RemoveShader,
    material_management.PHILOGIX_OT_RemoveMatSlot,
    material_management.PHILOGIX_OT_RemoveMaterialChannel,
    
    # Image
    image_management.PHILOGIX_OT_SaveImage,
    image_management.PHILOGIX_OT_SaveAsImage,
    image_management.PHILOGIX_OT_PackImage,
    image_management.PHILOGIX_OT_UnPackImage,
    
    # Bake
    baking_manager.PHILOGIX_OT_Baker,
    baking_manager.PHILOGIX_OT_ImportBakeImage,
    baking_manager.PHILOGIX_OT_ClearBakeImage,

    # Export
    exporting_manager.PHILOGIX_OT_RemoveExportPreset,
    exporting_manager.PHILOGIX_OT_SaveExportPreset,
    exporting_manager.PHILOGIX_OT_NewExportPreset,
    exporting_manager.PHILOGIX_OT_AddExportSlot,
    exporting_manager.PHILOGIX_OT_RemoveExportSlot,
    exporting_manager.PHILOGIX_OT_ChangeOutputChannel,
    exporting_manager.PHILOGIX_OT_ChangeOutputChannelColorSpace,
    
    screen_picker.PHILOGIX_OT_screen_picker
    )

def register():
    for c in classes:
        bpy.utils.register_class(c)

    layers.register()


def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    layers.unregister()