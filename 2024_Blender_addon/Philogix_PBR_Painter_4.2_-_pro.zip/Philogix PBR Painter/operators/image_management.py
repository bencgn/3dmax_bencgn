import bpy, os

from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

from bpy_extras.io_utils import ExportHelper

from ..core.image_manager import ImageManager

from ..utils.file_utilities import get_image_extension


class PHILOGIX_OT_SaveImage(Operator):
    bl_idname = "plx.save_image"
    bl_label = ""
    bl_options = {'UNDO'}

    image_name: StringProperty()
    
    def execute(self, context):
        image = bpy.data.images[self.image_name]

        if image.packed_file and image.is_dirty:
            image.pack()

        elif not image.packed_file and not os.path.exists(image.filepath):
            image.pack()

        else:
            ImageManager.save(image, image.filepath, True)
            self.report({'INFO'}, "Image has been saved to: " + image.filepath_from_user())

        return {"FINISHED"}

class PHILOGIX_OT_SaveAsImage(Operator):
    bl_idname = "plx.save_as_image"
    bl_label = "Save As Image"
    bl_options = {'UNDO'}

    image_name: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")

    use_filter: BoolProperty()
    filename_ext = ''


    def draw(self, context):
        image_settings = self.scene.render.image_settings
        
        layout = self.layout       
        layout.template_image_settings(image_settings, color_management=False)
        
        
    def invoke(self, context, event):
        self.scene = bpy.data.scenes.new('Plx_Temp Scene')
        #self.scene.display_settings.display_device = 'None'
        self.scene.sequencer_colorspace_settings.name = 'Non-Color'
        
        image_settings = self.scene.render.image_settings
        self.image = bpy.data.images[self.image_name]
        
        image_settings.file_format = self.image.file_format
        
        return ExportHelper.invoke(self, context, event)
    
  
    def execute(self, context):
        tiled = self.image.source == 'TILED'
        image_settings = self.scene.render.image_settings
        image_extension = get_image_extension(image_settings.file_format)
        imagePath = f"{self.filepath}{'.<UDIM>' if tiled else ''}.{image_extension}"

        try:
            if not self.image.packed_file:
                self.image.pack()

            self.image.save_render(filepath=imagePath, scene=self.scene)
            self.image.filepath_raw = imagePath

            if self.image.packed_file:
                self.image.unpack(method='REMOVE')

            self.image.reload()
            self.report({'INFO'}, "Image has been saved to: " + self.image.filepath_from_user())

        except Exception as e:
            self.report({'INFO'}, str(e))
            
        bpy.data.scenes.remove(self.scene)

        self.report({'INFO'}, f"Saved image: {imagePath}!")

        return {"FINISHED"}
    
    def cancel(self, context):
        if hasattr(self, "scene") and self.scene:
            bpy.data.scenes.remove(self.scene)

class PHILOGIX_OT_PackImage(Operator):
    bl_idname = "plx.pack_image"
    bl_label = ""
    bl_options = {'UNDO'}

    image_name: StringProperty()
    
    def execute(self, context):
        image = bpy.data.images[self.image_name]
        image.pack()
        return {"FINISHED"}

class PHILOGIX_OT_UnPackImage(Operator):
    bl_idname = "plx.unpack_image"
    bl_label = ""
    bl_options = {'UNDO'}

    image_name: StringProperty()
    
    def execute(self, context):
        image = bpy.data.images[self.image_name]
        image.unpack(method='REMOVE')
        return {"FINISHED"}
