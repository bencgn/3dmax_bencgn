import bpy, os

from bpy.types import Operator

from ..bl_class_registry import BlClassRegistry
from ..addon.distribution import AssetCategory
from ..utils.general_utilities import get_context_pointer

@BlClassRegistry()
class PHILOGIX_OT_AddCategory(Operator):
    bl_idname = "plx.add_category"
    bl_label = "Add Category"
    bl_description = ''
    bl_options = {'UNDO'}

    asset_type: bpy.props.StringProperty()
    
    def execute(self, context):
        AssetCategory.add_category(self.asset_type, 'New Category')
        context.scene.PlxProps.editing_category = ''
        context.scene.PlxProps.category_name = ''
        return {"FINISHED"}

@BlClassRegistry()
class PHILOGIX_OT_RemoveCategory(Operator):
    bl_idname = "plx.remove_category"
    bl_label = "Remove Category"
    bl_description = ''
    bl_options = {'UNDO'}

    asset_type: bpy.props.StringProperty()
    category_key: bpy.props.StringProperty()

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)
    
    def execute(self, context):
        AssetCategory.remove_category(self.asset_type, self.category_key)
        context.scene.PlxProps.editing_category = ''
        context.scene.PlxProps.category_name = ''
        return {"FINISHED"}

@BlClassRegistry()
class PHILOGIX_OT_SetCategory(Operator):
    bl_idname = "plx.set_category"
    bl_label = "Setup Category"
    bl_description = ''
    bl_options = {'UNDO'}

    asset_type: bpy.props.StringProperty()
    category_key: bpy.props.StringProperty()
    
    def execute(self, context):
        active_asset = get_context_pointer(context, 'active_asset')

        if active_asset:
            active_asset.PlxAssetCategory = self.category_key

        context.scene.PlxProps.editing_category = ''
        context.scene.PlxProps.category_name = ''
        return {"FINISHED"}
    
@BlClassRegistry()
class PHILOGIX_OT_RenameCategory(Operator):
    bl_idname = "plx.rename_category"
    bl_label = "Rename Category"
    bl_description = ''
    bl_options = {'UNDO'}

    asset_type: bpy.props.StringProperty()
    category_key: bpy.props.StringProperty()
    
    def execute(self, context):
        props = context.scene.PlxProps
        category_items = AssetCategory.get_category_items(self.asset_type)

        if props.editing_category == self.category_key:
            props.editing_category = ''
            props.category_name = ''
        else:
            props.editing_category = ''
            props.category_name = category_items[self.category_key]['name']
            props.editing_category = self.category_key

        return {"FINISHED"}
