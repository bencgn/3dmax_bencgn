import bpy, os

from bpy.types import Operator

from ..addon.distribution import ExportPresets
from ..bl_class_registry import BlClassRegistry
from ..core.registration_manager import RegistrationManager
from ..core.serializer.properties_serializer import PropertiesSerializer

from ..utils.data_definitions import get_bake_list, get_pbr_channels, get_cycles_bake_list
from ..utils.general_utilities import delimiter_join, delimiter_split, get_addon_directory

def check_export_slot_name(slots, new_name):
    #for slot in slots:
    if new_name in slots:
        splitext = os.path.splitext(new_name)
        ext = splitext[1]
        if len(ext)>0:
            ext = ext.replace('.', '')
            new_name = splitext[0] + '.' + str(int(ext)+1)
        else:
            new_name = new_name + '.' + str(1)
        new_name = check_export_slot_name(slots, new_name)
        
    return new_name

def get_colorspace_items(self, context):
    return [(item.identifier, item.name, item.description) 
            for item in context.scene.sequencer_colorspace_settings.bl_rna.properties['name'].enum_items]

# Export Slots

class PHILOGIX_OT_AddExportSlot(Operator):
    bl_idname = "plx.add_export"
    bl_label = "Add Export Slot"
    bl_description = "Add a new export slot"
    
    slot_name: bpy.props.StringProperty(default='Export Channel')
    
    output_type: bpy.props.EnumProperty(
        name='Output Type',
        items=(
            ('RGB', 'RGB', ''),
            (delimiter_join('Red', 'Green', 'Blue'), 'R + G + B', ''),
            (delimiter_join('RGB', 'Alpha'), 'RGB + Alpha', ''),
            (delimiter_join('Red', 'Green', 'Blue', 'Alpha'), 'R + G + B + Alpha', ''),
            ),
        )
        
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        
        row = layout.row()
        row.prop(self, 'slot_name', text='Channel Name')
        row = layout.row()
        row.prop(self, 'output_type', text='Output Type')

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=250)
    
    def execute(self, context):
        slots = context.scene.PlxProps.export_properties.slots
        
        slot_name = check_export_slot_name(slots, self.slot_name)
        
        new_slot = slots.add()
        new_slot.name = slot_name
        new_slot.output_type = self.output_type
        
        
        return {"FINISHED"}
    

class PHILOGIX_OT_ChangeOutputChannel(Operator):
    bl_idname = "plx.change_output"
    bl_label = "Add Export Slot"
    bl_description = "Add a new export slot"
    
    def get_output_channel_info(self):
        bake_list = get_bake_list()
        cycles_list = get_cycles_bake_list()
        pbr_channels = get_pbr_channels()
        sRGB_channels = {'Base Color', 'Diffuse', 'Specular', 'DIFFUSE', 'GLOSSY'}

        del pbr_channels['Layer Mask']

        output_channel_info = {}

        idx = 0
        for pbr_channel_name in pbr_channels:
            output_channel_info[str(idx)] = {
                'name': pbr_channel_name,
                'bake_type': 'EMIT',
                'shader_output': pbr_channel_name,
                'color_space': 'sRGB' if pbr_channel_name in sRGB_channels else 'Non-Color'
            }

            idx += 1

        for bake_info in bake_list.values():
            output_channel_info[str(idx)] = {
                'name': bake_info['bake_name'],
                'bake_type': 'EMIT',
                'color_space': 'Non-Color',
                'shader_output': bake_info['image_name']}
            idx += 1

        for cycle_name, cycle_info in cycles_list.items():
            output_channel_info[str(idx)] = {
                'name': cycle_name,
                'bake_type': cycle_info['bake_type'],
                'shader_output': 'Material',
                'normal_format': cycle_info.get('normal_format', 'POS_Y'),
                'color_space': 'sRGB' if pbr_channel_name in sRGB_channels else 'Non-Color'}
            idx += 1

        return output_channel_info[self.output_channel]

    def get_output_channel_item(self, context):
        bake_list = get_bake_list()
        pbr_channels = get_pbr_channels()
        cycles_list = get_cycles_bake_list()

        del pbr_channels['Layer Mask']

        idx = 0
        enum_items = [('', 'Processed', '')]
        for pbr_channel_name in pbr_channels:
            enum_items.append((str(idx), pbr_channel_name, ''))
            idx += 1

        enum_items.append(('', 'Baked maps', ''))
        for bake_info in bake_list.values():
            enum_items.append((str(idx), bake_info['bake_name'], ''))
            idx += 1

        enum_items.append(('', 'Cycles maps', ''))
        for cycle_name in cycles_list:
            enum_items.append((str(idx), cycle_name, ''))
            idx += 1

        return enum_items

    idx: bpy.props.IntProperty()
    channel: bpy.props.StringProperty()
    output_channel: bpy.props.EnumProperty(items=get_output_channel_item)

    def execute(self, context):
        idx = self.idx
        channel = self.channel
        channel_info = self.get_output_channel_info()
        export_slot = context.scene.PlxProps.export_properties.slots[idx]
        
        channel_image = getattr(export_slot, channel)
        channel_image.name = channel_info['name']
        channel_image.bake_type = channel_info['bake_type']
        channel_image.color_space = channel_info['color_space']
        channel_image.shader_output = channel_info['shader_output']
        channel_image.normal_format = channel_info.get('normal_format', 'POS_Y')

        return {"FINISHED"}

class PHILOGIX_OT_ChangeOutputChannelColorSpace(Operator):
    bl_idname = "plx.change_output_color_space"
    bl_label = "Add Export Slot"
    bl_description = "Add a new export slot"

    idx: bpy.props.IntProperty()
    channel: bpy.props.StringProperty()
    change_output_color_spaces: bpy.props.EnumProperty(
        name='Color Space',
        items=get_colorspace_items
        )

    def execute(self, context):
        export_slot = context.scene.PlxProps.export_properties.slots[self.idx]
        channel_image = getattr(export_slot, self.channel)
        channel_image.color_space = self.change_output_color_spaces 
        return {"FINISHED"}

class PHILOGIX_OT_RemoveExportSlot(Operator):
    bl_idname = "plx.remove_export"
    bl_label = "Remove Export Slot"
    bl_description = "Remove a new export slot"
    
    index: bpy.props.IntProperty()
    
    def execute(self, context):
        
        slots = context.scene.PlxProps.export_properties.slots
        
        slots.remove(self.index)
        
        return {"FINISHED"}


# Export Presets
@BlClassRegistry()
class PHILOGIX_OT_LoadExportPreset(Operator):
    bl_idname = "plx.load_preset"
    bl_label = "Load Export Preset"
    bl_description = "Load Export Preset"

    preset_id: bpy.props.StringProperty()
    
    def execute(self, context):
        props = context.scene.PlxProps
        presets = {**ExportPresets.sys_presets, **ExportPresets.user_presets}
        preset = presets.get(self.preset_id, {})
        attrs = preset.get('attrs')
        if attrs:
            PropertiesSerializer(props.export_properties).from_dict(attrs_dict=attrs)
            props.export_properties.id = ''
            props.export_properties.name = preset['name']
            props.export_properties.id = self.preset_id
            self.report({'INFO'}, f"'{preset['name']}' preset loaded!")
        else:
            self.report({'WARNING'}, f"Error when loading preset!")
        return {"FINISHED"}

class PHILOGIX_OT_NewExportPreset(Operator):
    bl_idname = "plx.new_preset"
    bl_label = "Add Preset"
    bl_description = "Save the current Export Settings to the currently selected preset"
    
    def execute(self, context):
        is_system = RegistrationManager().is_dev_version
        preset_id = ExportPresets.add_preset('New Preset', is_system)
        bpy.ops.plx.load_preset(preset_id=preset_id)
        return {"FINISHED"}
    
class PHILOGIX_OT_SaveExportPreset(Operator):
    bl_idname = "plx.save_preset"
    bl_label = "Edit Export Preset"
    bl_description = "Editing current Export Setting"

    save_type: bpy.props.EnumProperty(
        items=(
            ('save' , 'Save', ''),
            ('save_copy' , 'Save a Copy', ''),
        ),
        default='save'
    )
    
    def execute(self, context):
        props = context.scene.PlxProps
        is_system = RegistrationManager().is_dev_version    
        presets =  ExportPresets.get_items()
        preset_info = presets.get(props.export_properties.id)
        
        is_copy = self.save_type == 'save_copy' or not preset_info or (not is_system and preset_info['is_system'])
        preset_name = f"{preset_info['name']} (copy)" if preset_info else 'New Preset'
        preset_id = ExportPresets.add_preset(preset_name, is_system) if is_copy else props.export_properties.id

        ExportPresets.update_preset(preset_id, export_props=props.export_properties)
        ExportPresets.update_presets_file(is_system)

        if is_copy:
            bpy.ops.plx.load_preset(preset_id=preset_id)

        self.report({'INFO'}, 'Preset saved!')
        return {"FINISHED"}

class PHILOGIX_OT_RemoveExportPreset(Operator):
    bl_idname = "plx.remove_preset"
    bl_label = "Remove Export Preset"
    bl_description = "Remove the current Export Settings"

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)
    
    def execute(self, context):
        props = context.scene.PlxProps
        export_props = props.export_properties 

        presets =  ExportPresets.get_items()
        preset_info = presets.get(export_props.id)

        ExportPresets.remove_preset(export_props.id)
        ExportPresets.update_presets_file(preset_info['is_system'])
        return {"FINISHED"}