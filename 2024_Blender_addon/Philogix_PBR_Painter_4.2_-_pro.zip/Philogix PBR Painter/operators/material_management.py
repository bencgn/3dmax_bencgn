import bpy

from bpy.types import Operator
from bpy.props import StringProperty, IntProperty, BoolProperty, EnumProperty

from ..properties import properties_update

from ..utils.general_utilities import make_uid, delimiter_join, print_message
from ..utils.layer_utilities import update_material_layers
from ..utils.object_utilities import get_active_material, get_active_mesh_object
from ..utils.data_definitions import get_bake_list, get_pbr_channels, remove_idle_plx_data


from ..bl_class_registry import BlClassRegistry
from ..core.udim_manager import UdimManager
from ..core.node.nodes_manager import PlxMaterialNodesManager
from ..core.structure.material_manager import PlxMaterialManager
from ..core.material_manager import PlxChannelSetter, PlxBakeSlotsManager, PlxBakeImageManager


@BlClassRegistry()
class PHILOGIX_OT_CreateShader(Operator):
    bl_idname = "plx.create_shader"
    bl_label = "Create new Philogix shader"
    bl_description = "Create new Philogix shader" 
    bl_options = {'UNDO'}

    workflow: EnumProperty(
        name= 'PBR workflow',
        items =  (
                ('Metallic' ,'Metallic','', 'NONE', 0),
                ('Specular' ,'Specular','', 'NONE', 1),
            ),
    )

    pbr_channels = get_pbr_channels()
    metallic_pbr_channels = get_pbr_channels('Metallic')
    specular_pbr_channels = get_pbr_channels('Specular')

    for channel_info in pbr_channels.values():
        exec(f"{channel_info['prop']}: BoolProperty(default={str(channel_info['prop_default'])})")

    def get_activated_channels(self):
        activated_channels = []
        channel_list = get_pbr_channels(self.workflow)
        for channel_name, channel_info in channel_list.items():
            if getattr(self, channel_info['prop']):
                activated_channels.append((channel_name, channel_info))
        return activated_channels

    def draw(self, context):
        layout = self.layout

        pbr_channels = self.metallic_pbr_channels if self.workflow == 'Metallic' else self.specular_pbr_channels
        if 'Layer Mask' in pbr_channels:
            del pbr_channels['Layer Mask']
        checked = sum(getattr(self, info['prop']) for _, info in pbr_channels.items())

        layout.label(text='PBR workflow:')
        layout.row().prop(self, 'workflow', expand=True)
        layout.label(text='Channels:')
        
        box = layout.box()

        for channel_name, channel_info in pbr_channels.items():
            row = box.row()
            row.enabled = checked > 1 or not getattr(self, channel_info['prop'])
            row.prop(self, channel_info['prop'], text=channel_name)

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=175)

    def execute(self, context):
        obj = get_active_mesh_object()
        activated_channels = self.get_activated_channels()

        material_manager = PlxMaterialManager(self.workflow)
        material_manager.register(context, obj)

        channel_setter = PlxChannelSetter(material_manager.mat)
        channel_setter.set_channels(activated_channels)
        
        bake_slots_manager = PlxBakeSlotsManager(context)
        bake_slots_manager.set_bake_slots()

        material_nodes_manager = PlxMaterialNodesManager(material_manager.mat)
        material_nodes_manager.create_nodes()
        
        if not material_nodes_manager.shader_node:
            self.report({'ERROR'}, "Unable to create Plx Shader!")
            return {'FINISHED'}

        uv_layer = obj.data.uv_layers.get(obj.data.PlxProps.bake_uvmap) or obj.data.uv_layers.active
        titles = UdimManager.get_valid_udim_titles(context, obj, uv_layer.name)
        bake_image_manager = PlxBakeImageManager(context, obj)
        bake_image_manager.set_bake_images(titles)
        bake_image_manager.reload_bake_images(material_nodes_manager.mat)
        material_nodes_manager.mat.PlxProps.edit_maps = 'Layer Mask'
        update_material_layers(material_manager.mat)

        return {'FINISHED'}

class PHILOGIX_OT_RemoveShader(Operator):
    bl_idname = "plx.remove_shader"
    bl_label = "Remove Plx Shader"
    bl_description = "Remove Philogix shader" 
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        mat = get_active_material()
        
        if not mat: return False
        
        mat_props = mat.PlxProps
        return mat_props.ID != ''
        
    def draw(self, context):
        layout = self.layout
        layout.alert = True

        row = layout.row()
        row.label(text = 'All data of the material will be deleted')

        row = layout.row()
        row.label(text= 'Do you want to continue?')

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=250)

    def execute(self, context):
        mat = get_active_material()

        material_manager = PlxMaterialManager(mat.PlxProps.workflow)
        material_nodes_manager = PlxMaterialNodesManager(mat)
        
        material_manager.unregister(mat)
        material_nodes_manager.clear_default_nodes()
        remove_idle_plx_data()

        return {'FINISHED'}

class PHILOGIX_OT_RemoveMatSlot(Operator):
    bl_idname = "plx.remove_material_slot"
    bl_label = "Remove"
    bl_description = "Remove the selected material slot" 
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode != 'EDIT_MESH' and  len(context.object.material_slots)!=0

    def execute(self, context):
        mat = get_active_material()

        if mat != None:
            if mat.PlxProps.ID != '' and mat.users==1:
                bpy.ops.plx.remove_shader()
        try:
            if mat.users==0:
                bpy.ops.plx.remove_shader()
        except:
            print_message('No has Plx Shader!')
        bpy.ops.object.material_slot_remove()
        
        return {'FINISHED'}

@BlClassRegistry()
class PHILOGIX_OT_FixShader(Operator):
    bl_idname = "plx.fix_shader"
    bl_label = "Fixing Philogix shader"
    bl_description = 'The "Fix Plx Shader" button will appear when the node structure of the material is faulty, use this function to correct the material'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        mat = get_active_material()
        return mat and mat.PlxProps.ID != ''

    def execute(self, context):
        mat = get_active_material()
        obj = get_active_mesh_object()

        material_manager = PlxMaterialManager(mat.PlxProps.workflow)
        material_manager.register(context, obj)

        material_nodes_manager = PlxMaterialNodesManager(material_manager.mat)
        material_nodes_manager.clear_default_nodes()
        material_nodes_manager.create_nodes()

        bake_slots_manager = PlxBakeSlotsManager(context)
        bake_slots_manager.set_bake_slots()

        uv_layer = obj.data.uv_layers.get(obj.data.PlxProps.bake_uvmap) or obj.data.uv_layers.active

        titles = UdimManager.get_valid_udim_titles(context, obj, uv_layer.name)
        bake_image_manager = PlxBakeImageManager(context, obj)
        bake_image_manager.set_bake_images(titles)
        bake_image_manager.reload_bake_images(material_manager.mat)

        update_material_layers(material_manager.mat)
        properties_update.material_layer_index_update(material_manager.mat.PlxProps, context)

        return {'FINISHED'}

@BlClassRegistry()
class PHILOGIX_OT_DuplicatedMaterial(Operator):
    bl_idname = "plx.duplicated_material"
    bl_label = "Duplicated Material"
    bl_description = "Duplicates the selected material, assigns a unique ID, and applies it to the active object"
    bl_options = {'UNDO'}

    object_name: StringProperty()
    material_name: StringProperty()

    def _copy_and_rename_material(self):
        mat = bpy.data.materials.get(self.material_name, get_active_material())

        old_name = mat.name
        newID = "Plx_" + make_uid(5)

        mat_copy = mat.copy()
        mat_copy.PlxProps.ID = newID
        mat_copy.name = old_name + " (copy)" 

        for layer in mat.PlxProps.layers:
            layer.regenerate()

        return mat_copy
    
    def _set_material_properties(self, context, obj, mat, bakes):
        obj.active_material = mat
        PlxBakeSlotsManager(context).set_bake_slots()

        material_manager = PlxMaterialManager(mat.PlxProps.workflow)
        material_manager.register(context, obj)

        uv_layer = obj.data.uv_layers.get(obj.data.PlxProps.bake_uvmap) or obj.data.uv_layers.active
        titles = UdimManager.get_valid_udim_titles(context, obj, uv_layer.name)
        bake_image_manager = PlxBakeImageManager(context, obj)
        bake_image_manager.set_bake_images(titles)
        bake_image_manager.reload_bake_images(material_manager.mat)

    @classmethod
    def poll(cls, context):
        mat = get_active_material()
        return mat and mat.PlxProps.ID != ''

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name, get_active_mesh_object())

        mat = self._copy_and_rename_material()
        bakes = get_bake_list()

        shader_node = mat.node_tree.nodes.get(delimiter_join("Plx", "Shader"))

        if shader_node:
            shader_node.node_tree = shader_node.node_tree.copy()
            shader_node.node_tree.name = delimiter_join(mat.PlxProps.ID, "Shader")

        self._set_material_properties(context, obj, mat, bakes)
        self.report({'INFO'}, "Duplicated the material for the active object!")

        return {'FINISHED'}


# Channel
@BlClassRegistry()
class PHILOGIX_OT_AddMaterialChannel(Operator):
    bl_idname = "plx.add_material_channel"
    bl_label = "Add channel"
    bl_description = "Adding channels to the process"
    bl_options = {'UNDO'}

    ID: IntProperty()
    name: StringProperty()
    icon: StringProperty()
    update: BoolProperty(default=True)
    description: StringProperty()
    color_space: StringProperty()

    def execute(self, context):
        if not self.name:
            return {'FINISHED'}

        mat = get_active_material()
        channel_setter = PlxChannelSetter(mat)
        channel_setter.set_channel(self.ID, self.name, self.icon, self.description, self.color_space)
        if self.update: update_material_layers(mat)
        
        return {'FINISHED'}

class PHILOGIX_OT_RemoveMaterialChannel(Operator):
    bl_idname = "plx.remove_material_channel"
    bl_label = "Remove channel"
    bl_description = "Remove channel from process"
    bl_options = {'UNDO'}

    name: StringProperty()

    def update_edit_maps(self, mat):
        mat_props = mat.PlxProps
        channels = mat_props.channels
        
        for i, channel in enumerate(channels):
            if self.name == channel.name:
                if mat_props.edit_maps == self.name:
                    mat_props.edit_maps = 'Layer Mask'
                channels.remove(i)
                break


    def draw(self, context):
        layout = self.layout
        layout.alert = True

        row = layout.row()
        row.label(text = 'All data of the channel will be deleted')
        row = layout.row()
        row.label(text= 'Do you want to continue?')


    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=250)


    def execute(self, context):
        mat = get_active_material()
                
        self.update_edit_maps(mat)
        update_material_layers(mat)

        return {'FINISHED'}
