import bpy, os

from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator, UIList, Material, ShaderNodeTree
from bpy.props import StringProperty, IntProperty, FloatVectorProperty, BoolProperty

from ...core.udim_manager import UdimManager
from ...core.image_manager import ImageManager
from ...core.node.node_creator import PlxNodeCreator
from ...core.layer_operations import LayerOperationsManager

from ...utils.object_utilities import get_active_mesh_object, get_active_material
from ...utils.general_utilities import get_context_pointer, delimiter_join, delimiter_split

PREV_MODE = ''

# Item
class PHILOGIX_OT_LoadImageTexture(Operator):
    bl_idname = "plx.load_image_texture"
    bl_label = "Load Image Texture"
    bl_description = ""
    bl_options = {'UNDO'}


    filepath: StringProperty(subtype="FILE_PATH")
    filename: StringProperty(default='')    
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.exr*;.rgb;*.jp2;*.tga;*.cin;*.dpx;*.hdr;*.tif",
        options={'HIDDEN'},
        )


    def invoke(self, context, event):

        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        
        brush = context.tool_settings.image_paint.brush
        
        new_image = bpy.data.images.load(self.filepath)
        
        new_texture = bpy.data.textures.new('PLXT_texture ' + os.path.basename(self.filename), type = 'IMAGE')
        new_texture.image = new_image
        
        brush.texture = new_texture

        return {"FINISHED"}

class PHILOGIX_OT_Painting(Operator):
    bl_idname = "plx.paint"
    bl_label = "Texture Painting"
    bl_description = "Set up texture painting for a specific image layer, excluding baked images"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        image = get_context_pointer(context, 'plx_paint_image')
        return image and image.plx_mesh_image_baking is None
        
    def invoke(self, context, event):
        obj = get_active_mesh_object()
        projection_layer = get_context_pointer(context, 'plx_projection_layer')

        node_tree = projection_layer.node_group
        mapping_node = node_tree.nodes.get('Mapping')
        active_layer_uvmap = obj.data.uv_layers.get(mapping_node.uv_map)

        if mapping_node and active_layer_uvmap and mapping_node.projection == "UV":
            active_layer_uvmap.active = True
            return self.execute(context)

        self.report({'WARNING'}, 'UVmap of layer could not be found!')
        return {"CANCELLED"}
        

    def execute(self, context):
        global PREV_MODE
        PREV_MODE = context.active_object.mode
        
        image = context.plx_paint_image

        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

        img_paint = context.tool_settings.image_paint
        img_paint.mode = 'IMAGE'
        img_paint.canvas = image

        return {"FINISHED"}

class PHILOGIX_OT_PaintFinish(Operator):
    bl_idname = "plx.paint_finish"
    bl_label = "Finish Painting"
    bl_description = "Ends the painting session"
    bl_options = {'UNDO'}

    def execute(self, context):
        global PREV_MODE
        image = context.tool_settings.image_paint.canvas
        
        if image.preview:
            image.preview.reload()
        
        if PREV_MODE in ['', 'TEXTURE_PAINT']:
            PREV_MODE = 'OBJECT'
            
        bpy.ops.object.mode_set(mode=PREV_MODE)
        
        return {"FINISHED"}

class PHILOGIX_OT_UDIMTileCreator(Operator):
    bl_idname = "plx.add_udim_tiles"
    bl_label = "Add UDIM Tiles"
    bl_description = "Add UDIM tiles to the tiled image based on the available area in the object's UV map"
    bl_options = {'UNDO'}

    def execute(self, context):
        # Logic để thêm các tiles UDIM vào hình ảnh
        # ...
        
        self.report({'INFO'}, "UDIM tiles have been created")
        return {"FINISHED"}

class PHILOGIX_OT_CreateLayerImage(Operator):
    bl_idname = "plx.create_layer_image"
    bl_label = "Create Layer Image"
    bl_description = "Creates a new image for the current image layer"
    bl_options = {'UNDO'}


    name: StringProperty(
        name="Name",
        description="Name of the new image",
        default="New Image"
    )

    width: IntProperty(
        name="Width",
        description="Width of the new image",
        default=1024,
        min=1,
        max=10000
    )

    height: IntProperty(
        name="Height",
        description="Height of the new image",
        default=1024,
        min=1,
        max=10000
    )

    color: FloatVectorProperty(
        name="Color",
        description="Background color of the image",
        subtype='COLOR',
        default=(0.0, 0.0, 0.0, 0.0),
        size=4,
        min=0.0,
        max=1.0
    )

    alpha: BoolProperty(
        name="Alpha",
        description="Include alpha channel in the image",
        default=True
    )

    float: BoolProperty(
        name="Float",
        description="Create image with float buffer",
        default=False
    )

    tiled: BoolProperty(
        name="Tiled",
        description="Create a tiled image for UDIM tiles",
        default=False
    )

    def draw(self, context):
        layout = self.layout
        self.layout.use_property_split = True
        self.layout.use_property_decorate = False

        col = layout.column()
        col.prop(self, 'name')
        col.prop(self, 'width')
        col.prop(self, 'height')
        col.prop(self, 'color')
        col.prop(self, 'alpha')
        col.prop(self, 'float')
    
    def invoke(self, context, event):        
        self.layer_group = get_context_pointer(context, 'active_layer_group')
        if not self.layer_group:
            return {"FINISHED"}
        
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=300)

    def execute(self, context):        
        uvmap_node = self.layer_group.nodes.get('Mapping')
        value_node = self.layer_group.nodes.get('Value')
        if not uvmap_node or not value_node:
            self.report({'INFO'}, "Could not find value node!")
            return {"FINISHED"}
        
        obj = get_active_mesh_object()
        udim_titles = UdimManager.get_valid_udim_titles(context, obj, uvmap_node.uv_map)
        value_node.image = ImageManager.new(context, self.name, self.width, self.height, color=self.color, alpha=self.alpha, float_buffer=self.float, tiles=udim_titles)

        return {"FINISHED"}


class PHILOGIX_OT_IDAdditions(Operator):
    bl_idname = "plx.aditions"
    bl_label = "ID Aditions"
    bl_description = ""
    bl_options = {'UNDO'}

    color_name: StringProperty(default='')

    def update_node(self, node_tree):
        layers = []
        Out = node_tree.nodes['Out']
        
        for node in node_tree.nodes:
            if node.name.split('.')[0]=='Math':
                layers.append(node)

        layer_1 = None
        for i, layer in enumerate(layers):
            if i==0:
                node_tree.links.new(layer.outputs['Value'], Out.inputs['Value'])
            else:
                node_tree.links.new(layer.outputs['Value'], layer_1.inputs[1])
            layer_1 = layer

    def execute(self, context):
        active_value_node = get_context_pointer(context, 'active_value_node')
        if not active_value_node:
            return {"FINISHED"} 
        
        value_group = active_value_node.node_tree

        if self.color_name == '':
            In = value_group.nodes['In']

            node_creator = PlxNodeCreator(value_group)

            math_node = node_creator.add_node('ShaderNodeMath')
            color_mask_node = node_creator.add_node('ShaderNodePlxColorMask')
            
            math_node.hide = True
            math_node.use_clamp = True
            math_node.inputs[0].default_value = 0
            math_node.inputs[1].default_value = 0

            color_mask_node.hide = True
            color_mask_node.node_tree.name = delimiter_join(value_group.name, "ColorMask")

            node_creator.add_link(In.outputs['ID'], color_mask_node.inputs['ID'])
            node_creator.add_link(In.outputs['Tollerance'], color_mask_node.inputs['Tollerance'])
            node_creator.add_link(color_mask_node.outputs['Value'], math_node.inputs[0])
        else:
            name_tail = ''
            if '.' in self.color_name:
                name_tail = '.' + self.color_name.split('.')[1]

            math_node = value_group.nodes[f"Math{name_tail}"]
            color_mask_node = value_group.nodes[f"Plx Color Mask{name_tail}"]

            value_group.nodes.remove(math_node)
            value_group.nodes.remove(color_mask_node)

        self.update_node(value_group)

        return {"FINISHED"} 

class PHILOGIX_OT_OpenGroup(Operator):
    bl_idname = "plx.open_group"
    bl_label = "Open in editor"
    bl_description = "Open this asset in the shader editor"

    def find_path_node(self, node_tree, path_node=[]):
        self.finded_groups.append(node_tree.name)

        for node in node_tree.nodes:
            if node.bl_idname == "ShaderNodeGroup":
                if node.node_tree == self.active_asset:
                    return path_node + [node]

                if node.node_tree and node.node_tree.name not in self.finded_groups:
                    sub_path_node = self.find_path_node(node.node_tree, path_node + [node])
                    if sub_path_node: return sub_path_node

    def modal(self, context, event):
        if self.edit_shader_area.spaces[0].edit_tree == self.active_asset:
            return {"FINISHED"}
        
        while len(self.edit_shader_area.spaces[0].path)>1:
            self.edit_shader_area.spaces[0].path.pop()

        for node in self.path_node:
            self.edit_shader_area.spaces[0].path[-1].node_tree.nodes.active = node
            self.edit_shader_area.spaces[0].path.append(node.node_tree)

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.active_asset = get_context_pointer(context, "active_asset")
        if not self.active_asset:
            return {"FINISHED"}
        
        material = get_active_material()
        screen = context.screen
        self.edit_shader_area = next((area for area in screen.areas if area.type == 'NODE_EDITOR'), None) 

        if not self.edit_shader_area:
            current_areas = set(screen.areas)
            bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
            new_areas = set(screen.areas) - current_areas
            self.edit_shader_area = new_areas.pop() if new_areas else None

        self.edit_shader_area.ui_type = 'ShaderNodeTree'

        self.finded_groups = []
        self.path_node = self.find_path_node(material.node_tree)

        if self.path_node:
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Could not find the asset's node group!")
            return {"FINISHED"}

class PHILOGIX_OT_ChangeAnchor(Operator):
    bl_idname = "plx.change_anchor"
    bl_label = "Change Anchor"
    bl_description = ""
    bl_options = {'UNDO'}

    select_group_name: StringProperty()

    def execute(self, context):
        channel_layer = get_context_pointer(context, 'active_layer_group')
        channel_layer_group = channel_layer

        select_group = bpy.data.node_groups[self.select_group_name]
        material_layer_group = bpy.data.node_groups[delimiter_split(self.select_group_name)[0]]
        
        channel_layer_value_node = channel_layer_group.nodes.get('Value')
        channel_layer_mapping_node = channel_layer_group.nodes.get('Mapping')
        material_layer_mapping_node = material_layer_group.nodes.get('Mapping')

        if (channel_layer_value_node 
            and channel_layer_mapping_node 
            and material_layer_mapping_node):

            channel_layer_value_node.node_tree = select_group
            channel_layer_mapping_node.node_tree = material_layer_mapping_node.node_tree
            
        else:
            self.report({'INFO'}, "Error finding anchor point!")

        return {"FINISHED"}

class PHILOGIX_OT_MoveDecal(Operator):
    bl_idname = "plx.move_decal"
    bl_label = "Move Decal"
    bl_description = "Move the decal object using snapping"
    bl_options = {'UNDO'}

    layer_group_name: StringProperty()
        
    def set_seclected_decal(self, context):
        scene = context.scene
        
        if self.decal_object.name not in scene.collection.objects:
            scene.collection.objects.link(self.decal_object)

        bpy.ops.object.select_all(action='DESELECT')
        self.decal_object.select_set(state=True)

    def unset_seclected_decal(self, context):
        scene = context.scene
        
        if self.decal_object.name in scene.collection.objects:
            scene.collection.objects.unlink(self.decal_object)

    def translate_decal(self, context, event):
        if event.value == 'PRESS':
            self.set_seclected_decal(context)            
            bpy.ops.transform.translate(
                'INVOKE_DEFAULT', 
                orient_type='GLOBAL', 
                orient_matrix_type='GLOBAL', 
                mirror=False, 
                use_proportional_edit=False, 
                proportional_edit_falloff='SMOOTH', 
                proportional_size=1, 
                use_proportional_connected=False, 
                use_proportional_projected=False, 
                snap=True, 
                snap_align=True, 
                snap_elements={'FACE', 'FACE_PROJECT', 'FACE_NEAREST'}, 
                use_snap_project=True, 
                snap_target='CENTER', 
                use_snap_self=True, 
                use_snap_edit=True, 
                use_snap_nonedit=True, 
                use_snap_selectable=False, 
                alt_navigation=True)

            
        return {'RUNNING_MODAL'}

    def rotate_decal(self, context, event):
        rotation_amount = 0.1 if event.type in ['WHEELUPMOUSE', 'UP_ARROW', 'RIGHT_ARROW'] else -0.1
        self.set_seclected_decal(context)
        self.decal_object.rotation_euler.rotate_axis("Z", rotation_amount)
        self.unset_seclected_decal(context)

        return {'RUNNING_MODAL'}

    def resize_decal(self, context, event):
        if event.value == 'PRESS':
            self.set_seclected_decal(context)
            bpy.ops.transform.resize('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}

    def exit_modal(self, context, event):
        context.workspace.status_text_set(text=None)
        context.area.spaces[0].show_region_ui = True
        return {'FINISHED'}


    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.mode == 'OBJECT'

    def invoke(self, context, event):
        data_objects = bpy.data.objects
        data_groups = bpy.data.node_groups
        layer_node_group = data_groups.get(self.layer_group_name)

        if not layer_node_group:
            self.report({'ERROR'}, "Layer node group not found!")
            return {'CANCELLED'}

        mapping_node = layer_node_group.nodes.get('Mapping')

        if not mapping_node:
            self.report({'ERROR'}, "Mapping node not found!")
            return {'CANCELLED'}

        decal_object_name = mapping_node.node_tree.name
        self.decal_object = data_objects.get(decal_object_name)

        if not self.decal_object:
            self.decal_object = data_objects.new(decal_object_name, None)
            self.decal_object.empty_display_size = 0.25
            self.decal_object.empty_display_type = 'SINGLE_ARROW'

        mapping_node.decal_object = self.decal_object
        self.decal_object.parent = context.active_object

        return self.execute(context)
    
    def execute(self, context):        
        status_text = "[Left Mouse]  Move            [Scroll Up/Down]  Rotate         [Middle Mouse]  Resize           [ESC/Right Mouse]  Finish"

        context.area.spaces[0].show_region_ui = False
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set_internal(status_text)

        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        context.area.tag_redraw()
        self.unset_seclected_decal(context)

        event_to_action = {
            'ESC': self.exit_modal,
            'RIGHTMOUSE': self.exit_modal,
            'MIDDLEMOUSE': self.resize_decal,
            'LEFTMOUSE': self.translate_decal,
            'WHEELUPMOUSE': self.rotate_decal,
            'WHEELDOWNMOUSE': self.rotate_decal,
            'LEFT_ARROW': self.rotate_decal,
            'DOWN_ARROW': self.rotate_decal,
            'UP_ARROW': self.rotate_decal,
            'RIGHT_ARROW': self.rotate_decal,
        }

        if event.type in event_to_action:
            action = event_to_action[event.type]
            return action(context, event)

        return {'RUNNING_MODAL'}


class PHILOGIX_UL_SelectLayerItems(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        group_props = item.node_group.PlxProps

        row = layout.row()
        row.active = item.selected
        row.label(icon_value=group_props.icon_value)
        row.prop(group_props, 'name', icon="NONE", emboss=False, text="")
        row.prop(item, 'selected', text='')


class PHILOGIX_OT_CopyLayer(Operator):
    bl_idname = "plx.copy_layer"
    bl_label = "Copy Layers"
    bl_description = "Copy layers to another"
    
    @classmethod
    def poll(cls, context):
        layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not layers_props:
            return False
        return len(layers_props.layers) > 0 and layers_props.layers_index != -1

    def execute(self, context):
        layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not layers_props:
            return {"CANCELLED"}
                    
        layer_index = layers_props.layers_index
        layer = layers_props.layers[layer_index]

        LayerOperationsManager.copy_layer(layer)
        self.report({'INFO'}, f"copied 1 layer to clipboard!")
        return {"FINISHED"}

class PHILOGIX_OT_CopyMultipleLayers(Operator):
    bl_idname = "plx.copy_multiple_layer"
    bl_label = "Copy Multiple Layers"
    bl_description = "Copy Multiple layers to another"

    def get_layers_index(self):
        return -1
        
    layers_index: bpy.props.IntProperty(get=get_layers_index)

    @classmethod
    def poll(cls, context):        
        layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not layers_props:
            return True
        return len(layers_props.layers) > 1
    
    def draw(self, context):
        self.layout.template_list("PHILOGIX_UL_SelectLayerItems", "1", self.layers_props, "layers", self, "layers_index", sort_reverse = True, sort_lock=True, rows = 5)


    def invoke(self, context, event):        
        self.layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not self.layers_props:
            return {"CANCELLED"}
        
        for layer in self.layers_props.layers:
            layer.selected = False

        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=250)


    def execute(self, context):    
        layers = [layer for layer in self.layers_props.layers if layer.selected]
        LayerOperationsManager.copy_multiple_layers(layers)
        self.report({'INFO'}, f"copied {len(layers)} layers to clipboard!")
        return {"FINISHED"}

class PHILOGIX_OT_PasteLayers(Operator):
    bl_idname = "plx.paste_layer"
    bl_label = "Paste Layers"
    bl_description = "Paste layers to active"
    bl_options = {'UNDO'}

    is_linked: bpy.props.BoolProperty(default=False)

    @classmethod
    def _get_valid_types(cls, layers_props):
        return {Material: {'MATERIAL', 'CUSTOM'},
                ShaderNodeTree:{'SURFACE', 'IMAGE', 'ANCHOR', 'ID', 'FILTER'}
                }.get(type(layers_props.id_data))

    @classmethod
    def poll(cls, context):
        if not LayerOperationsManager.copied_layers:
            return False
        try:
            copied_layers = LayerOperationsManager.copied_layers
            layers_props = get_context_pointer(context, 'plx_layers_origin_props')
            valid_types = cls._get_valid_types(layers_props)
            copied_layer_types = {layer.PlxProps.layer_type for layer in copied_layers if layer}
            return copied_layer_types.issubset(valid_types)
        except:
            return False

    def execute(self, context):
        layers_props = getattr(context, "plx_layers_origin_props", None)
        if not layers_props:
            return {"CANCELLED"}
        
        LayerOperationsManager.paste_layers(context, layers_props, self.is_linked)
        return {"FINISHED"}

class PHILOGIX_OT_DuplicatedLayers(Operator):
    bl_idname = "plx.duplicated_layer"
    bl_label = "Duplicated Layers"
    bl_description = "Duplicated layers to active"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy.ops.plx.copy_layer.poll()

    def execute(self, context):
        bpy.ops.plx.copy_layer()
        bpy.ops.plx.paste_layer()

        LayerOperationsManager.copied_layers.clear()

        return {"FINISHED"}

class PHILOGIX_OT_MakeLocalLayers(Operator):
    bl_idname = "plx.make_local_layer"
    bl_label = "Make Local Layer"
    bl_description = "Make Local"
    bl_options = {'UNDO'}

    path_from_id: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not layers_props:
            return False

        if not layers_props.layers or layers_props.layers_index < 0:
            return False
        
        selected_layer = layers_props.layers[layers_props.layers_index]
        layer_node_group = bpy.data.node_groups.get(selected_layer.ID)
        
        return layer_node_group != selected_layer.layer_node.node_tree

    def execute(self, context):
        layers_props = get_context_pointer(context, 'plx_layers_origin_props')
        if not layers_props:
            return False

        selected_layer = layers_props.layers[layers_props.layers_index]

        if selected_layer:
            selected_layer.make_local()

        return {"FINISHED"}
