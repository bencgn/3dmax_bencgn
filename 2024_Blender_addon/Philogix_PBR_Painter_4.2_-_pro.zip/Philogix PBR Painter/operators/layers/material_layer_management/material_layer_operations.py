import bpy, os

from bpy.types import Operator
from bpy.props import StringProperty, CollectionProperty

from ....utils.object_utilities import get_active_material
from ....utils.general_utilities import get_context_pointer, print_message

# Panel

class ChannelDeterminer:
    @staticmethod
    def determine(image_name):
        channel_key = {
            'Base Color': {'color', 'albedo', 'base color', 'diffuse'},
            'Roughness': {'roughness'},
            'Metallic': {'metallic', 'metalness'},
            'Emission': {'emission'},
            'Alpha': {'opacity', 'alpha'},
            'Height': {'height', 'bump'},
            'Normal': {'normal'},
            'Layer Mask': {'mask', 'layer mask'},
        }
        
        for key, values in channel_key.items():
            if any(value in image_name for value in values):
                return key
        return None

class PHILOGIX_OT_ImportPBR(Operator):
    bl_idname = "plx.import_pbr"
    bl_label = "Import PBR set"
    bl_description = "Import PBR texture to active material layer"

    filter_glob: StringProperty(name='Supported Extensions', default='', options={'SKIP_SAVE', 'HIDDEN'}, maxlen=500)
    filepath: StringProperty(subtype="FILE_PATH")
    filename: StringProperty(default='')
    directory: StringProperty(default='')
    files: CollectionProperty(
                type=bpy.types.OperatorFileListElement,
                options={'HIDDEN', 'SKIP_SAVE'},
            )

    @classmethod
    def poll(cls, context):
        material_layer = get_context_pointer(context, 'plx_actived_layer')
        return (material_layer 
                and material_layer.node_group
                and material_layer.node_group.PlxProps.layer_type == 'CUSTOM')

    def invoke(self, context, event):
        self.material_layer = get_context_pointer(context, 'plx_actived_layer')
        name_filter = ('*albedo*;*color*;*diffuse*;*roughness*;*metalness*;'
                       '*metallic*;*bump*;*height*;*emission*;*opacity*;'
                       '*alpha*;*normal*;*mask*;*layer mask*;')
        
        self.filter_glob = name_filter 
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def load_image(self, filepath, image_name):
        try:
            image = bpy.data.images.load(filepath)
            image.colorspace_settings.name = 'sRGB'
            return image
        except Exception as e:
            print_message(f"Error loading image {image_name}: {e}")
            return None

    def setup_image(self, mat, channel, image):
        mat_props = mat.PlxProps
        active_channel = mat_props.channels[channel]
        prev_edit_maps = mat_props.edit_maps
        mat_props.edit_maps = channel

        bpy.ops.plx.add_image()
        node_tree =  self.material_layer.channel_node_group.PlxProps.active_layer.node_group

        value_node = node_tree.nodes.get('Value')
        opacity_node = node_tree.nodes.get('MixOpacity')

        value_node.image = image
        image.colorspace_settings.name = active_channel.color_space
        if channel == 'Height':
            opacity_node.inputs[0].default_value = 0.01

        mat_props.edit_maps = prev_edit_maps

    def execute(self, context):
        mat = get_active_material()
        active_channels = mat.PlxProps.channels

        for file in self.files:
            image_name = os.path.splitext(file.name)[0].lower()
            filepath = os.path.join(self.directory, file.name)
            channel = ChannelDeterminer.determine(image_name)

            if channel and channel in active_channels:
                image = self.load_image(filepath, image_name)
                self.setup_image(mat, channel, image)

        return {"FINISHED"}