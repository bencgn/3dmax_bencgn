import bpy

from bpy.types import Operator

from ....utils import layer_utilities, object_utilities

start_mouse_y = None
start_mouse_x = None
is_move_layer = False

class PHILOGIX_OT_DownLayer(Operator):
    bl_idname = "plx.down_layer"
    bl_label = "Move Layer"
    bl_description = "Move down the selected layer"
    bl_options = {'UNDO'}

    update_in_nodes: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        mat = object_utilities.get_active_material()
        layers = mat.PlxProps.layers
        layer_index = mat.PlxProps.layers_index
        return -1<layer_index<len(layers)-1

    def execute(self, context):
        mat = object_utilities.get_active_material()
        mat_props = mat.PlxProps
        layers = mat_props.layers
        layer_index = mat.PlxProps.layers_index

        layers.move(layer_index, layer_index+1)
        mat_props.layers_index += 1
            
        if self.update_in_nodes:
            layer_utilities.update_material_layers(mat)

        return {"FINISHED"}

class PHILOGIX_OT_UpLayer(Operator):
    bl_idname = "plx.up_layer"
    bl_label = "Move Layer"
    bl_description = "Move up the selected layer"
    bl_options = {'UNDO'}

    update_in_nodes: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        mat = object_utilities.get_active_material()
        layers = mat.PlxProps.layers
        layer_index = mat.PlxProps.layers_index
        return len(layers)>layer_index>0

    def execute(self, context):
        mat = object_utilities.get_active_material()
        mat_props = mat.PlxProps
        layers = mat_props.layers
        layer_index = mat.PlxProps.layers_index

        layers.move(layer_index, layer_index-1)
        mat_props.layers_index -= 1
            
        if self.update_in_nodes:
            layer_utilities.update_material_layers(mat)

        return {"FINISHED"}

class PHILOGIX_OT_MoveMaterialLayers(Operator):
    bl_idname = "plx.move_layer"
    bl_label = "Move Layers"
    bl_description = "Move the selected layer"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return True
    
    def move_mode_setting(self, context, event):        
        global start_mouse_y, start_mouse_x, is_move_layer

        is_move_layer = True

        start_mouse_y = event.mouse_y
        start_mouse_x = event.mouse_x

        context.window.cursor_modal_set('NONE')
        context.window.cursor_warp(event.mouse_x - 500, event.mouse_y)
    
    def move_mode_setting_restore(self, context):        
        global start_mouse_y, start_mouse_x, is_move_layer

        is_move_layer = False

        if start_mouse_x and start_mouse_y:
            context.window.cursor_modal_restore()
            context.window.cursor_warp(start_mouse_x, start_mouse_y)
            start_mouse_y = None
            start_mouse_x = None


    def invoke(self, context, event):
        global is_move_layer, start_mouse_y, start_mouse_x

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not is_move_layer:
            start_mouse_y = event.mouse_y
            start_mouse_x = event.mouse_x

            context.window_manager.modal_handler_add(self)

            return {'RUNNING_MODAL'}
        
        return {'FINISHED'}

    def modal(self, context, event):
        global start_mouse_y, start_mouse_x, is_move_layer
        
        if event.value == 'RELEASE':
            if is_move_layer:
                mat = object_utilities.get_active_material()
                layer_utilities.update_material_layers(mat)

            self.move_mode_setting_restore(context)
    
            return {'FINISHED'}
        
        if event.type == 'MOUSEMOVE':
            diff_x = event.mouse_y - start_mouse_y

            if not is_move_layer and abs(diff_x) > 0:
                self.move_mode_setting(context, event)
                
            else:
                if abs(diff_x) > 35:
                        
                    if diff_x > 0 and bpy.ops.plx.down_layer.poll():
                        bpy.ops.plx.down_layer(update_in_nodes = False)

                    elif diff_x < 0 and bpy.ops.plx.up_layer.poll():
                        bpy.ops.plx.up_layer(update_in_nodes = False)

                    context.window.cursor_warp(start_mouse_x - 500, start_mouse_y)

        return {'RUNNING_MODAL'}
