import bpy

from bpy.types import Operator
from ....utils import (
    layer_utilities,
    object_utilities,
    data_definitions,
    )

start_mouse_y = None
start_mouse_x = None
is_move_layer = False

class PHILOGIX_OT_RemoveLayer(Operator):
    bl_idname = "plx.remove_layer"
    bl_label = "Remove Layer"
    bl_description = "Remove the currently selected item"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        mat = object_utilities.get_active_material()
        layers = mat.PlxProps.layers
        layer_index = mat.PlxProps.layers_index
        return len(layers) > layer_index > -1
        
    def execute(self, context):
        mat = object_utilities.get_active_material()

        mat_props = mat.PlxProps
        layers = mat_props.layers
        idx = mat_props.layers_index
        item = layers[idx]

        node_tree = mat.node_tree

        # Remove node
        layer_utilities.remove_layer(node_tree, item)
        data_definitions.remove_idle_plx_data()

        # Remove layer
        layers.remove(idx)
        if idx == len(layers): mat_props.layers_index -= 1

        # update layer
        layer_utilities.update_material_layers(mat)

        mat_props.layers_index = mat_props.layers_index

        return {"FINISHED"}
