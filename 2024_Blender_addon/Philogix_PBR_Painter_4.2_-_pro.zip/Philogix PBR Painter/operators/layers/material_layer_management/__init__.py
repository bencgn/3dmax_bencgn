###############   IMPORTS
import bpy
from . import material_layer_creation, material_layer_removal, material_layer_manipulation, material_layer_operations

###############   REGISTER ADDON
classes = (
    material_layer_creation.PHILOGIX_OT_AddCustonLayer,
    material_layer_creation.PHILOGIX_OT_AddSmartLayer,
    material_layer_removal.PHILOGIX_OT_RemoveLayer,
    material_layer_manipulation.PHILOGIX_OT_DownLayer,
    material_layer_manipulation.PHILOGIX_OT_UpLayer,
    material_layer_manipulation.PHILOGIX_OT_MoveMaterialLayers,
    material_layer_operations.PHILOGIX_OT_ImportPBR,
    )

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)