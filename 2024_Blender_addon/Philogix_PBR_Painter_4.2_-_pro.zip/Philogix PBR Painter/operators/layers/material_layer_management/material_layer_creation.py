import bpy, random

from bpy.types import Operator
from ....utils import node_utilities, general_utilities, data_definitions, layer_utilities, object_utilities
from ....core.structure.material_layer_manager import PlxMaterialLayerManager

start_mouse_y = None
start_mouse_x = None
is_move_layer = False


def make_material_layer_node(item, node_group):
    mat = item.id_data
    
    layer_node = node_utilities.create_node(mat.node_tree, 'ShaderNodeGroup', item.ID, hide = False, location = (0, 0))

    layer_node.node_tree = node_group
    layer_node.width = 250
    layer_node.use_custom_color = True
    layer_node.color = (random.random(), random.random(), random.random())

    return layer_node

def make_channel_node(node_tree, item, channel, location):
    bake_list = data_definitions.get_bake_list()

    mapping_node = node_tree.nodes['Mapping']
    input_node = node_tree.nodes['GroupInput']

    channel_node_group = make_channel_node_group(item.ID, channel)
    channel_node = node_utilities.create_node(node_tree, 'ShaderNodeGroup', channel['name'], channel['name'], location = location)
    
    channel_node.node_tree = channel_node_group
    channel_node.inputs['Color'].default_value = channel['default_value']


    for bake_values in bake_list:
        socket_name = bake_values['image_name']

        node_tree.links.new(input_node.outputs[socket_name], channel_node.inputs[socket_name])

    node_tree.links.new(mapping_node.outputs['Vector'], channel_node.inputs['Vector'])
    node_tree.links.new(mapping_node.outputs['Alpha'], channel_node.inputs['Alpha'])

    return channel_node

def add_material_layer_item(props):
    props.layers.add()
    idx = props.layers_index

    props.layers_index = idx + 1 if idx < len(props.layers) - 1 else len(props.layers) - 1
    props.layers.move(len(props.layers)-1, props.layers_index)

    return props.layers[props.layers_index]

def add_material_layer(mat, type, icon_value):
    mat_props = mat.PlxProps
    item = add_material_layer_item(mat_props)

    layer_node_group = make_layer_node_group(item)
    make_material_layer_node(item, layer_node_group)
    
    props = layer_node_group.PlxProps
    props.layer_type = type
    props.icon_value = icon_value
    props.name = layer_utilities.make_layer_node_label(mat.node_tree, 'Material')

    return item



class PHILOGIX_OT_AddCustonLayer(Operator):
    bl_idname = "plx.add_custom"
    bl_label = "Add Custom Layer"
    bl_description = "Custom Layer allows building material layer with full channel, can create layers within channel. And control the affected area with Layer Mask"
    bl_options = {'UNDO'}
    
    def execute(self, context):
        mat = object_utilities.get_active_material()
        PlxMaterialLayerManager(mat).add('CUSTOM')
        layer_utilities.update_material_layers(mat)
        mat.PlxProps.layers_index = mat.PlxProps.layers_index
        
        return {"FINISHED"}

class PHILOGIX_OT_AddSmartLayer(Operator):
    bl_idname = "plx.add_smart"
    bl_label = "Add Smart Material Layer"
    bl_description = "The Smart Material Layer is a pre-made material layer in Philogix PBR Painter that reads information from Bake Maps, processes it, and outputs channels"
    bl_options = {'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        mat = object_utilities.get_active_material()
        PlxMaterialLayerManager(mat).add('MATERIAL')
        layer_utilities.update_material_layers(mat)
        mat.PlxProps.layers_index = mat.PlxProps.layers_index

        return {"FINISHED"}