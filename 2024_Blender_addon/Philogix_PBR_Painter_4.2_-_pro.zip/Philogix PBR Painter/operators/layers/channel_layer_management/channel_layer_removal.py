import bpy
from bpy.types import Operator

from ....utils import layer_utilities, data_definitions, object_utilities

class PHILOGIX_OT_RemoveChannelLayer(Operator):
    bl_idname = "plx.remove_channel_layer"
    bl_label = "Remove Layer"
    bl_description = "Remove the currently selected item"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_node_group = material_layer.channel_node_group

        if channel_node_group:
            channel_props = channel_node_group.PlxProps
            channel_layers = channel_props.layers
            layers_index = channel_props.layers_index

            return len(channel_layers) > layers_index > -1
            
        return False

    def execute(self, context):
        mat = object_utilities.get_active_material()
        channel_node_group = mat.PlxProps.material_layer.channel_node_group
        channel_props = channel_node_group.PlxProps
        channel_layers = channel_props.layers
        idx = channel_props.layers_index
        item = channel_layers[idx]

        # kiểm tra unclipping layer
        if item.numb_sublayers > 0:
            channel_layers[idx+1].parent_layer_id = channel_layers[idx+1].ID
            channel_layers[idx+1].numb_sublayers = item.numb_sublayers - 1
            
            for i in range(2, item.numb_sublayers+1):
                channel_layers[idx+i].parent_layer_id = channel_layers[idx+1].ID

        elif item.ID != item.parent_layer_id:
            item.parent.numb_sublayers -= 1

        layer_utilities.remove_layer(channel_node_group, item)
        data_definitions.remove_idle_plx_data()

        channel_layers.remove(idx)
        
        if idx == len(channel_layers): channel_props.layers_index -= 1

        # update layer
        layer_utilities.update_channel_layers(channel_node_group)

        return {"FINISHED"}