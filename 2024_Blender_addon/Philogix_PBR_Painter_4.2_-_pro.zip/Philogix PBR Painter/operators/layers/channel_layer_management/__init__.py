###############   IMPORTS
import bpy
from . import channel_layer_creation, channel_layer_manipulation, channel_layer_removal, channel_layer_operations

###############   REGISTER ADDON
classes = (
    channel_layer_creation.PHILOGIX_OT_AddSufaceLayer,
    channel_layer_creation.PHILOGIX_OT_AddImageLayer,
    channel_layer_creation.PHILOGIX_OT_AddFilterLayer,
    channel_layer_creation.PHILOGIX_OT_AddAnchorLayer,
    channel_layer_creation.PHILOGIX_OT_AddIDLayer,

    channel_layer_manipulation.PHILOGIX_OT_DownChannelLayer,
    channel_layer_manipulation.PHILOGIX_OT_UpChannelLayer,
    channel_layer_manipulation.PHILOGIX_OT_MoveChannelLayers,

    channel_layer_removal.PHILOGIX_OT_RemoveChannelLayer,
    
    channel_layer_operations.PHILOGIX_OT_ClippingLayer,
    channel_layer_operations.PHILOGIX_OT_MakeLocalChannelLayers,
    )

def register():
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)