import bpy

from bpy.types import Operator
from bpy.props import IntProperty

from .... import utils
from ....utils import layer_utilities, object_utilities


class PHILOGIX_OT_ClippingLayer(Operator):
    bl_idname = "plx.clipping_layer"
    bl_label = "Clipping Layer"
    bl_description = "Clipping Layer converts the current layer into a sublayer of the layer below, the sublayer will only affect the parent layer. A parent class can have multiple subclasses above it"
    bl_options = {'UNDO'}

    item_idx: IntProperty()
    
    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_node_group = material_layer.channel_node_group
        
        channel_props = channel_node_group.PlxProps
        channel_layers = channel_props.layers

        item = channel_layers[self.item_idx]

        if item.parent_layer_id == item.ID:
            item.parent_layer_id = channel_layers[self.item_idx-1].parent_layer_id
            parent = item.parent
            parent_idx = channel_layers.find(parent.name)
            parent.numb_sublayers = 0

            i=parent_idx+1
            while channel_layers[i].parent_layer_id != channel_layers[i].ID:
                channel_layers[i].parent_layer_id = parent.ID
                channel_layers[i].numb_sublayers = 0
                parent.numb_sublayers += 1
                if i<len(channel_layers)-1:
                    i+=1
                else: break
        else:
            item.parent_layer_id = channel_layers[self.item_idx-1].parent_layer_id
            parent = item.parent
            parent_idx = channel_layers.find(parent.name)
            parent.numb_sublayers = 0
            
            i=self.item_idx
            while channel_layers[i].parent_layer_id != channel_layers[i].ID:
                channel_layers[i].parent_layer_id = channel_layers[i].ID
                channel_layers[i].numb_sublayers = 0
                if i<len(channel_layers)-1:
                    i+=1
                else: break

            i=parent_idx+1
            while channel_layers[i].parent_layer_id != channel_layers[i].ID:
                channel_layers[i].parent_layer_id = parent.ID
                channel_layers[i].numb_sublayers = 0
                parent.numb_sublayers += 1
                i+= 1
            
        layer_utilities.update_channel_layers(channel_node_group)
        
        return {"FINISHED"}

class PHILOGIX_OT_MakeLocalChannelLayers(Operator):
    bl_idname = "plx.make_local_channel_layer"
    bl_label = "Make Local Layer"
    bl_description = "Make Local"
    bl_options = {'UNDO'}

    path_from_id: bpy.props.StringProperty()

    def execute(self, context):
        material = utils.get_active_material()
        material_layer = material.path_resolve(self.path_from_id)

        if material_layer:
            material_layer.make_local()

        return {"FINISHED"}
