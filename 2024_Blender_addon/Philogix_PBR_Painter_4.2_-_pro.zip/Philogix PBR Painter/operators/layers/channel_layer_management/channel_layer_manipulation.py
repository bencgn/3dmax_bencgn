import bpy

from bpy.types import Operator

from ....utils.general_utilities import print_message
from ....utils.object_utilities import get_active_material
from ....utils.layer_utilities import update_channel_layers

start_mouse_y = None
start_mouse_x = None
is_move_layer = False

class PHILOGIX_OT_DownChannelLayer(Operator):
    bl_idname = "plx.down_channel_layer"
    bl_label = "Move Down Layer"
    bl_description = "Move down the selected layer"
    bl_options = {'UNDO'}

    update_in_nodes: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        try:
            mat = get_active_material()
            material_layer = mat.PlxProps.material_layer
            channel_node_group = material_layer.channel_node_group

            if channel_node_group:
                channel_props = channel_node_group.PlxProps

                index = channel_props.layers_index
                layers = channel_props.layers

                if index < len(layers) - 1:

                    item = layers[index]
                    above = layers[index + 1]

                    if item.parent_layer_id == item.ID:
                        return index + item.numb_sublayers != len(layers) - 1
                    else:
                        return above.parent_layer_id != above.ID and item.parent_layer_id != item.ID
                    
            return False
            
        except Exception as e:
            print_message(f"Error in poll (Move down layer): {e}")
            return False


    def execute(self, context):
        mat = get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_node_group = material_layer.channel_node_group

        channel_props = channel_node_group.PlxProps
        channel_layers = channel_props.layers
        idx = channel_props.layers_index

        above_numb_sublayers = channel_layers[idx+channel_layers[idx].numb_sublayers+1].numb_sublayers

        for i in range(above_numb_sublayers+1):
            numb_sublayers = channel_layers[channel_props.layers_index].numb_sublayers
            for ii in range(numb_sublayers, -1, -1):
                channel_layers.move(channel_props.layers_index+ii, channel_props.layers_index+1+ii)
            channel_props.layers_index += 1

        if self.update_in_nodes: update_channel_layers(channel_node_group)

        return {"FINISHED"}

class PHILOGIX_OT_UpChannelLayer(Operator):
    bl_idname = "plx.up_channel_layer"
    bl_label = "Move Up Layer"
    bl_description = "Move up the selected layer"
    bl_options = {'UNDO'}

    update_in_nodes: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        try:
            mat = get_active_material()
            material_layer = mat.PlxProps.material_layer
            channel_node_group = material_layer.channel_node_group

            if channel_node_group:
                channel_props = channel_node_group.PlxProps

                index = channel_props.layers_index
                layers = channel_props.layers

                if index > 0:
                    below = layers[index - 1]
                    return below.numb_sublayers == 0
                
            return False
            
        except Exception as e:
            print_message(f"Error in poll (Move up layer): {e}")
            return False

    def execute(self, context):
        mat = get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_node_group = material_layer.channel_node_group

        channel_props = channel_node_group.PlxProps
        channel_layers = channel_props.layers
        idx = channel_props.layers_index

        if channel_layers[idx].parent_layer_id==channel_layers[idx].ID:
            parent = channel_layers[idx-1].parent
            for i in range(parent.numb_sublayers+1):
                numb_sublayers = channel_layers[channel_props.layers_index].numb_sublayers
                for ii in range(numb_sublayers+1):
                    channel_layers.move(channel_props.layers_index+ii, channel_props.layers_index-1+ii)
                channel_props.layers_index -= 1
        else:
            channel_layers.move(idx, idx-1)
            channel_props.layers_index -= 1

        if self.update_in_nodes: update_channel_layers(channel_node_group)

        return {"FINISHED"}

class PHILOGIX_OT_MoveChannelLayers(Operator):
    bl_idname = "plx.move_channel_layer"
    bl_label = "Move Channel Layers"
    bl_description = "Move the selected layer"
    bl_options = {'UNDO'}
    

    def move_mode_setting(self, context, event):        
        global start_mouse_y, start_mouse_x, is_move_layer

        is_move_layer = True
        start_mouse_y = event.mouse_y
        start_mouse_x = event.mouse_x
        context.window.cursor_modal_set('NONE')
        context.window.cursor_warp(event.mouse_x - 500, event.mouse_y)
    
    def move_mode_setting_restore(self, context):        
        global start_mouse_y, start_mouse_x, is_move_layer

        is_move_layer = False
        if start_mouse_x and start_mouse_y:
            context.window.cursor_modal_restore()
            context.window.cursor_warp(start_mouse_x, start_mouse_y)
            start_mouse_y = None
            start_mouse_x = None


    def invoke(self, context, event):
        global is_move_layer, start_mouse_y, start_mouse_x

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not is_move_layer:
            start_mouse_y = event.mouse_y
            start_mouse_x = event.mouse_x
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'FINISHED'}

    def modal(self, context, event):
        global start_mouse_y, start_mouse_x, is_move_layer
        
        if event.value == 'RELEASE':
            if is_move_layer:
                mat = get_active_material()
                material_layer = mat.PlxProps.material_layer
                channel_node_group = material_layer.channel_node_group
                update_channel_layers(channel_node_group)
            self.move_mode_setting_restore(context)
            return {'FINISHED'}
        
        if event.type == 'MOUSEMOVE':
            diff_x = event.mouse_y - start_mouse_y
            if not is_move_layer and abs(diff_x) > 0:
                self.move_mode_setting(context, event)
            elif abs(diff_x) > 35:
                if diff_x > 0 and bpy.ops.plx.down_channel_layer.poll():
                    bpy.ops.plx.down_channel_layer(update_in_nodes=False)
                elif diff_x < 0 and bpy.ops.plx.up_channel_layer.poll():
                    bpy.ops.plx.up_channel_layer(update_in_nodes=False)
                context.window.cursor_warp(start_mouse_x - 500, start_mouse_y)
        return {'RUNNING_MODAL'}