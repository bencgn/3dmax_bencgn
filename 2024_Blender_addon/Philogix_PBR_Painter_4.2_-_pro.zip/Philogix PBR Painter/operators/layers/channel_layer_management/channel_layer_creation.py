import bpy

from bpy.types import Operator
from bpy.props import EnumProperty

from ....addon import distribution

from ....utils import (
    node_utilities,
    asset_utilities,
    layer_utilities,
    object_utilities,
    data_definitions,
    general_utilities,
    )

from ....core.structure.channel_layer_manager import PlxChannelLayerManager

class PHILOGIX_OT_AddSufaceLayer(Operator):
    bl_idname = "plx.add_surface"
    bl_label = "Add Surface Layer"
    bl_description = "Surface layer allows to set the color of the layer using the available parameters of the surface library"
    bl_options = {'UNDO'}
    
    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_group = material_layer.channel_node_group
        new_layer = PlxChannelLayerManager(channel_group).add('SURFACE')
        new_layer.node_group.PlxProps.uv_settings.uv_using = 'PRIVATE'
        layer_utilities.update_channel_layers(channel_group)
        return {"FINISHED"}

class PHILOGIX_OT_AddImageLayer(Operator):
    bl_idname = "plx.add_image"
    bl_label = "Add Image Layer"
    bl_description = "Image layer allows to control color value or intensity with image"
    bl_options = {'UNDO'}
    
    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_group = material_layer.channel_node_group

        new_layer = PlxChannelLayerManager(channel_group).add('IMAGE')
        new_layer.node_group.PlxProps.uv_settings.uv_using = 'PRIVATE'
        layer_utilities.update_channel_layers(channel_group)
        return {"FINISHED"}

class PHILOGIX_OT_AddAnchorLayer(Operator):
    bl_idname = "plx.add_anchor"
    bl_label = "Add Anchor Layer"
    bl_description = "Anchor Point is a way to expose any channel and reference it in different areas of the channel List for different purposes"
    bl_options = {'UNDO'}

    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_group = material_layer.channel_node_group

        PlxChannelLayerManager(channel_group).add('ANCHOR')
        layer_utilities.update_channel_layers(channel_group)
        return {"FINISHED"}

class PHILOGIX_OT_AddIDLayer(Operator):
    bl_idname = "plx.add_id"
    bl_label = "Add ID Layer"
    bl_description = "The ID layer allows you to convert colors in the ID map to intensity values"
    bl_options = {'UNDO'}
    

    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_group = material_layer.channel_node_group

        PlxChannelLayerManager(channel_group).add('ID')
        layer_utilities.update_channel_layers(channel_group)
        return {"FINISHED"}

class PHILOGIX_OT_AddFilterLayer(Operator):
    bl_idname = "plx.add_filter"
    bl_label = "Add Filter Layer"
    bl_options = {'UNDO'}
    
    filter_type: EnumProperty(items=[
            ('ShaderNodeBrightContrast', '', ''), 
            ('ShaderNodeHueSaturation', '', ''), 
            ('ShaderNodeGamma', '', ''), 
            ('ShaderNodeInvert', '', ''), 
            ('ShaderNodeRGBToBW', '', ''), 
            ('ShaderNodeRGBCurve', '', ''),
            ('ShaderNodeValToRGB', '', '')
            ])


    def execute(self, context):
        mat = object_utilities.get_active_material()
        material_layer = mat.PlxProps.material_layer
        channel_group = material_layer.channel_node_group

        new_layer = PlxChannelLayerManager(channel_group).add(self.filter_type)
        layer_utilities.update_channel_layers(channel_group)

        return {"FINISHED"}
