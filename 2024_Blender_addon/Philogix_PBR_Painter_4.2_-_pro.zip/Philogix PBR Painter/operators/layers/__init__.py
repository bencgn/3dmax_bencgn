###############   IMPORTS
import bpy
from . import layer_management, channel_layer_management, material_layer_management

###############   REGISTER ADDON
classes = (
    layer_management.PHILOGIX_OT_OpenGroup,
    layer_management.PHILOGIX_OT_Painting,
    layer_management.PHILOGIX_OT_PaintFinish,
    layer_management.PHILOGIX_OT_UDIMTileCreator,
    layer_management.PHILOGIX_OT_CreateLayerImage,
    layer_management.PHILOGIX_OT_IDAdditions,
    layer_management.PHILOGIX_OT_ChangeAnchor,
    layer_management.PHILOGIX_OT_LoadImageTexture,
    layer_management.PHILOGIX_OT_MoveDecal,

    layer_management.PHILOGIX_UL_SelectLayerItems,

    layer_management.PHILOGIX_OT_CopyLayer,
    layer_management.PHILOGIX_OT_CopyMultipleLayers,
    layer_management.PHILOGIX_OT_PasteLayers,
    layer_management.PHILOGIX_OT_MakeLocalLayers,
    layer_management.PHILOGIX_OT_DuplicatedLayers,
    )

def register():
    for c in classes:
        bpy.utils.register_class(c)

    channel_layer_management.register()
    material_layer_management.register()

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    channel_layer_management.unregister()
    material_layer_management.unregister()