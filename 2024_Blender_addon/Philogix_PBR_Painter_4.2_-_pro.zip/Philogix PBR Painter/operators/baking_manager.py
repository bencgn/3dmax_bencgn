import bpy
import functools

from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper

from ..core.bake.engine import BakeEngine

from ..utils.data_definitions import get_bake_list
from ..utils.object_utilities import  get_active_mesh_object
from ..utils.general_utilities import delimiter_join, get_context_pointer

# Bake Slots

class PHILOGIX_OT_ImportBakeImage(Operator):
    bl_idname = "plx.import_bake"
    bl_label = "Import"
    bl_options = {'UNDO'}

    filepath: StringProperty()
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.exr*;.rgb;*.jp2;*.tga;*.cin;*.dpx;*.hdr;*.tif",
        options={'HIDDEN'})

    def invoke(self, context, event):
        self.bake_image = get_context_pointer(context, 'plx_bake_image')
        return ImportHelper.invoke(self, context, event)
    
    def execute(self, context):
        if not self.bake_image.image:            
            self.report({'WARNING'}, 'No baking images found!')
            return {'CANCELLED'}

        color_space = self.bake_image.image.colorspace_settings.name

        if self.bake_image.image.packed_file:
            self.bake_image.image.unpack(method='REMOVE')

        self.bake_image.image.filepath = self.filepath
        self.bake_image.image.reload()
        self.bake_image.image.pack()
        self.bake_image.image.filepath = ''
        self.bake_image.image.colorspace_settings.name = color_space

        self.report({'INFO'}, self.bake_image.name + " map has been changed!")

        return {"FINISHED"}

class PHILOGIX_OT_ClearBakeImage(Operator):
    bl_idname = "plx.clear_bake"
    bl_label = "Clear Bake Map"
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        self.bake_image = get_context_pointer(context, 'plx_bake_image')
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=150)
    
    def execute(self, context):
        bake_info = get_bake_list()[self.bake_image.name]
        image = self.bake_image.image

        if not image:
            obj = get_active_mesh_object()
            image = bpy.data.images.new(bake_info['image_name'], 1, 1)
            image.colorspace_settings.name = bake_info['color_space']
            image.plx_mesh_image_baking = obj.data
            self.bake_image.image = image

        else:
            image.scale(1, 1)

        if len(image.pixels)>0 and image.packed_file:
            image.unpack(method='REMOVE')

        image.pixels = bake_info['default_value']
        image.scale(128, 128)
        image.pack()

        return {"FINISHED"}


# Baking

class PHILOGIX_OT_Baker(Operator):
    bl_idname = "plx.baking"
    bl_label = "Bake Maps"
    bl_description = "Bake activated Maps"

    @classmethod
    def poll(cls, context):
        slots = context.scene.PlxProps.bake_properties.slots
        
        for bake_slot in slots:
            if bake_slot.active:
                return slots

    def finish(self, context, event):
        bpy.app.timers.register(
        functools.partial(
            self.bake_engine.wait_for_completion,
            self.bake_engine.config.clear_temps))
        
        self.bake_engine.completion(context, event)
        
        if hasattr(self, 'timer') and self.timer:
            context.window_manager.event_timer_remove(self.timer)
            self.timer = None
            
        if hasattr(self, 'ctrl') and self.ctrl.gi_running:
            self.ctrl.close()
        
        return {'FINISHED'}
        
    def execute(self, context):
        bake_props = context.scene.PlxProps.bake_properties
        self.bake_engine = BakeEngine(context, bake_props)
        is_validate = self.bake_engine.initialize()
        
        if not is_validate:
            return {'CANCELLED'}

        self.ctrl = self.bake_engine.processing()

        window_manager = context.window_manager
        self.timer = window_manager.event_timer_add(0.25, window=context.window)
        window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        try:
            result = next(self.ctrl)
            context.area.tag_redraw()

            if result == 'done':
                return self.finish(context, event)
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f'Bake error: {e}')
            return self.finish(context, event)
