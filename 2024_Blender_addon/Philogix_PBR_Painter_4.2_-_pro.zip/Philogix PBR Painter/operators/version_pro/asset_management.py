from typing import Set
import bpy, os

from bpy_extras.io_utils import ImportHelper, ExportHelper

from bpy.types import Operator
from bpy.props import StringProperty, StringProperty, EnumProperty



from ...bl_class_registry import BlClassRegistry
from ...core.serializer.asset_serializer import PlxAsset
from ...addon.distribution import AssetCollection, AssetCategory
from ...core.registration_manager import RegistrationManager

from ...utils.asset_utilities import get_and_set_inputs
from ...utils.general_utilities import get_context_pointer

def get_category_enum_items(self, context):
    return AssetCategory.get_enum_items(self.asset_type)

@BlClassRegistry()
class PHILOGIX_OT_ImportAsset(Operator):
    bl_idname = "plx.import_asset"
    bl_label = "Import Smart Material"
    bl_description = 'Import Smart Material from "*.plxm" file'
    
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(name='Supported Extensions', default='*.plxm;*.plxs;*.plxb', options={'SKIP_SAVE', 'HIDDEN'})

    asset_type: StringProperty(options={'SKIP_SAVE', 'HIDDEN'})
    asset_id: StringProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self.active_value_node = get_context_pointer(context, 'active_value_node') 
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        if not os.path.isfile(self.filepath):
            self.report({'INFO'}, f"File not found: {self.filepath}!")
            return {'FINISHED'}

        loaded_asset = PlxAsset.import_file(self.filepath)

        if loaded_asset.PlxAssetType != self.asset_type:
            self.report({'INFO'}, f"Incorrect asset type: {loaded_asset.PlxAssetType} to {self.asset_type}!")
            return {'FINISHED'}

        if self.asset_type == 'Brushes':
            loaded_asset.use_custom_icon = True
            loaded_asset.icon_filepath = AssetCollection.get_preview_path(loaded_asset.PlxAssetId)
            context.tool_settings.image_paint.brush = loaded_asset

        else:
            if self.active_value_node:
                if self.active_value_node.node_tree:
                    bpy.data.node_groups.remove(self.active_value_node.node_tree)
                self.active_value_node.node_tree = loaded_asset
                get_and_set_inputs(self.active_value_node, loaded_asset)

        self.report({'INFO'}, f"Exported data: {self.filepath}!")
        return {'FINISHED'}
    
@BlClassRegistry()
class PHILOGIX_OT_ExportAsset(Operator):
    bl_idname = "plx.export_asset"
    bl_label = "Export Material"
    bl_description = 'Export the Material to the file "*.plx"'
    
    filter_glob: StringProperty(name='Supported Extensions', default='*.plxm;*.plxs;*.plxb', options={'SKIP_SAVE', 'HIDDEN'})
    filepath: StringProperty(subtype="FILE_PATH")

    asset_type: StringProperty(options={'SKIP_SAVE', 'HIDDEN'})
    asset_id: StringProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self.active_asset = get_context_pointer(context, 'active_asset')
        if not self.active_asset:
            self.report({'INFO'}, "Error!")
            return {"CANCELLED"}

        asset_name = self.active_asset.PlxAssetName
        if not asset_name:
            asset_name = self.active_asset.name

        rna_type = self.active_asset.rna_type.identifier

        self.file_extension = f".plx{rna_type[0].lower()}"
        self.filepath = f"{asset_name}{self.file_extension}"
        
        return ExportHelper.invoke(self, context, event)
    
    def execute(self, context):
        self.active_asset.PlxAssetType = self.asset_type
        self.filepath += '' if self.filepath.endswith(self.file_extension) else self.file_extension

        PlxAsset.export_file(self.active_asset, self.filepath)

        info = f"Exported data: !"
        self.report({'INFO'}, info)

        return {"FINISHED"}

@BlClassRegistry()
class PHILOGIX_OT_SaveAsset(Operator):
    bl_idname = "plx.save_asset"
    bl_label = "Save Asset"
    bl_description = 'Save current asset to library'
    
    asset_type: StringProperty()
    asset_id: StringProperty(options={'HIDDEN'})

    save_type: EnumProperty(
        items=(
            ('save' , 'Save', ''),
            ('save_copy' , 'Save a Copy', ''),
        ),
        default='save')

    def execute(self, context):
        active_asset = get_context_pointer(context, 'active_asset')
        if not active_asset:
            self.report({'INFO'}, "Error!")
            return {"CANCELLED"}
        
        asset_id = active_asset.PlxAssetId
        asset_info = AssetCollection.assets.get(asset_id, {})

        is_save_as = self.save_type == "save_copy"
        is_system = RegistrationManager().is_dev_version
        is_diff_type = not is_save_as and active_asset.PlxAssetType != self.asset_type
        is_non_system_user = not is_system and asset_info.get('is_system', False)

        should_insert = (is_save_as or is_diff_type or not asset_info or is_non_system_user)

        if should_insert:
            active_asset.PlxAssetId = ''
            active_asset.PlxAssetType = self.asset_type
            PlxAsset.insert_asset(active_asset, is_system, create_preview=True)
        else:
            PlxAsset.save_asset(active_asset, is_system)

        self.report({'INFO'}, f"Saved: {active_asset.PlxAssetName}!")
        return {"FINISHED"}

@BlClassRegistry()
class PHILOGIX_OT_RemoveAsset(Operator):
    bl_idname = "plx.remove_asset"
    bl_label = "Remove Material"
    bl_description = 'Remove Material from library'

    def invoke(self, context, event):
        self.active_asset = get_context_pointer(context, 'active_asset')
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=150)
    
    def execute(self, context):
        report_type, report_message = ({'WARNING'}, "Cannot remove this asset!")

        if self.active_asset:
            asset_info = AssetCollection.assets.get(self.active_asset.PlxAssetId, {})        
            is_system_user = RegistrationManager().is_dev_version
            is_system_asset = asset_info.get('is_system', False)
            asset_type = asset_info.get('asset_type', 'Defaults')

            if (not is_system_asset or is_system_user) and asset_type != 'Defaults':
                data_name = self.active_asset.name
                AssetCollection.remove_asset(self.active_asset.PlxAssetId)
                report_type, report_message = ({'INFO'}, f"Removed: {data_name}!")

        self.report(report_type, report_message)
        return {"FINISHED"}
