import bpy, functools
from bpy.types import Operator
from ...bl_class_registry import BlClassRegistry

from ...core.export.engine import ExportEngine
from ...core.bake_manager import BakeHandlers

# Exporting

@BlClassRegistry()
class PHILOGIX_OT_Exporter(Operator):
    bl_idname = "plx.export"
    bl_label = "Export PBR Maps"
    bl_description = "Export all activated textures"

    @classmethod
    def poll(cls, context):
        return any(slot.active for slot in context.scene.PlxProps.export_properties.slots)
    
    def draw(self, context):
        layout = self.layout
        layout.alert = True

        row = layout.row()
        row.label(text = self.message)

        row = layout.row()
        row.alignment = 'CENTER'
        row.label(text= 'Do you wish to proceed?')

    def finish(self, context, event):
        bpy.app.timers.register(
            functools.partial(
                self.export_engine.wait_for_completion, 
                self.export_engine.config.clear_temps))
        
        self.export_engine.completion(context, event)
        
        if hasattr(self, 'timer') and self.timer:
            context.window_manager.event_timer_remove(self.timer)
            self.timer = None
            
        if hasattr(self, 'ctrl') and self.ctrl.gi_running:
            self.ctrl.close()

        return {'FINISHED'}

    def invoke(self, context, event):
        export_props = context.scene.PlxProps.export_properties
        self.export_engine = ExportEngine(context, export_props)
        type, message = self.export_engine.initialize()
    
        if type=='ERROR':
            self.report({'ERROR'}, message)
            return {'FINISHED'}
        
        elif type=='WARNING':
            self.message = message
            wm = context.window_manager
            return wm.invoke_props_dialog(self, width=450)
        
        else:
            return self.execute(context)
        
    def execute(self, context):

        self.is_baking = True
        self.canceled = False

        self.ctrl = self.export_engine.processing()

        window_manager = context.window_manager
        self.timer = window_manager.event_timer_add(0.25, window=context.window)
        window_manager.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        try:
            result = next(self.ctrl)
            context.area.tag_redraw()

            if result == 'done':
                return self.finish(context, event)
            return {'RUNNING_MODAL'}
            
        except Exception as e:
            self.report({'ERROR'}, f'Export error: {e}')
            return self.finish(context, event)
