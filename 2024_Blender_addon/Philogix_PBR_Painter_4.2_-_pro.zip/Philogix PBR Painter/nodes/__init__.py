import bpy

from . import node_categories
 
categories = (
    node_categories.ShaderNodePlxSpecular,
    node_categories.ShaderNodePlxMetallic,
    node_categories.ShaderNodePlxMapping,
    node_categories.ShaderNodePlxColorMask,
    )
      
def register():
    for categorie in categories:
        bpy.utils.register_class(categorie)
 
def unregister():
    for categorie in categories:
        bpy.utils.unregister_class(categorie)
