import bpy, os

from bpy.types import ShaderNodeCustomGroup
from bpy.props import EnumProperty, StringProperty, PointerProperty, BoolProperty, FloatProperty

from ..core.serializer.asset_serializer import PlxAsset

from ..utils.data_definitions import get_bake_list
from ..utils.general_utilities import get_addon_directory, print_message, MessageType


def set_plx_node_attribute(self):
    self.use_custom_color = True
    self.color = (0.1, 0.15, 0.15)
    self.width = 200
    self.bl_width_default = 200

class ShaderNodePlxShader(ShaderNodeCustomGroup):
    bl_name='ShaderNodePlxShader'
    bl_label='Plx Shader'
    bl_icon='NONE'

    # HELPER FUNCTIONS
    
    def get_shader_outputs_items(self, context):
        if not self.node_tree:
            return [('', 'An error occurred in the shader!', '')]

        items = [('Material', 'Material', '')]

        for input_item in self.node_tree.interface.items_tree:
            if hasattr(input_item, 'in_out') and input_item.in_out == 'INPUT':
                if input_item.name != 'Layer Mask' and 'Image' not in input_item.name:
                    items.append((input_item.name, input_item.name, ''))

        items += [('', 'View Mode', ''), ('Layer Mask', 'Layer Mask', '')]

        for bake_name, bake_info in get_bake_list().items():
            items.append((bake_info['image_name'], bake_name, ''))

        return items
   
    def shader_output_update(self, context):
        nodes = self.node_tree.nodes
        links = self.node_tree.links

        if self.shader_output == 'Material':
            bump_node = nodes['Bump']
            glossy_node = nodes.get('Glossy BSDF')
            principled_node = nodes['Principled BSDF']

            if glossy_node:
                links.new(bump_node.outputs['Normal'], glossy_node.inputs['Normal'])
            links.new(bump_node.outputs['Normal'], principled_node.inputs['Normal'])
        
        if self.shader_output in nodes:
            out_socket = nodes[self.shader_output].outputs[0]
        else:
            out_socket = nodes['In'].outputs[self.shader_output]
            
        links.new(out_socket, nodes['Out'].inputs[0])

    def bake_output_update(self, context):
        bake_list = get_bake_list()
        node_name, output_name = bake_list[self.bake_output]['bake_socket']

        node_tree = self.node_tree
        output_node = node_tree.nodes['Out']
        bake_node = node_tree.nodes[node_name]

        node_tree.links.new(bake_node.outputs[output_name], output_node.inputs[0])

        if self.bake_output == 'Curvature':
            script_node = node_tree.nodes['Script']
            script_node.filepath = os.path.join(get_addon_directory(), 'operators', 'cur.osl')
            
            try:
                node_tree.links.new(script_node.outputs['Cavity'], output_node.inputs['Shader'])
            except Exception as e:
                print_message(f'Unable to connect Curvature Bake node!\n{e}', MessageType.WARNING)

        elif self.bake_output == 'Normal':
            bevel_node = node_tree.nodes['NodeBevel']
            glossy_node = node_tree.nodes.get('Glossy BSDF')
            principled_node = node_tree.nodes['Principled BSDF']

            if glossy_node:
                node_tree.links.new(bevel_node.outputs['Normal'], glossy_node.inputs['Normal'])
            node_tree.links.new(bevel_node.outputs['Normal'], principled_node.inputs['Normal'])

    def bake_distance_update(self, context):
        node_mapping = {
            "AO": "Distance",
            "Script": "Distance",
            "NodeBevel": "Radius",
        }
        
        node_tree = self.node_tree

        for node_name, input_name in node_mapping.items():
            node = node_tree.nodes[node_name]
            if input_name in node.inputs:
                node.inputs[input_name].default_value = self.bake_distance

    def apply_bevel_update(self, context):
        bevel_node = self.node_tree.nodes["NodeBevel"]
        bevel_node.mute = not self.apply_bevel

    def vertex_name_update(self, context):
        vertex_node = self.node_tree.nodes["Vertex Color"]
        vertex_node.layer_name = self.vertex_name

    # PROPERTIES
    
    shader_output: EnumProperty( 
        items = get_shader_outputs_items,
        name = "Shader Output",
        description = 'The Viewmode can be used to defined the current display context',
        update=shader_output_update
        )

    bake_output: EnumProperty(
        items=(
            ('Normal' ,'Normal', ''),
            ('ID' ,'ID', ''),
            ('Ambient Occlusion' ,'Ambient Occlusion', ''),
            ('Curvature' ,'Curvature', ''),
            ),
        name = "Bake Output",
        update=bake_output_update)

    bake_distance: FloatProperty(
        default=0.02,
        min=0,
        max=1000,
        update=bake_distance_update
    )

    apply_bevel: BoolProperty(
        default=False,
        update=apply_bevel_update
        )

    vertex_name: StringProperty(
        description='', 
        default='', 
        update=vertex_name_update
        )

    # INHERITED METHODS

    def init(self, context):
        set_plx_node_attribute(self)
        self.node_tree = PlxAsset.load_asset(self.asset_id)

    def free(self):
        if self.node_tree:
            bpy.data.node_groups.remove(self.node_tree, do_unlink=True)
         
    # DRAW

    def draw_buttons(self, context, layout):
        layout.prop(self, 'shader_output', text='')

class ShaderNodePlxSpecular(ShaderNodePlxShader):
    bl_name='ShaderNodePlxSpecular'
    bl_label='Plx Specular Shader'
    bl_icon='NONE'
    
    def init(self, context):
        self.asset_id = '4f08d2c7839840daa57c'
        super().init(context)
        
class ShaderNodePlxMetallic(ShaderNodePlxShader): 
    bl_name='ShaderNodePlxMetallic'
    bl_label='Plx Metallic Shader'
    bl_icon='NONE'
    
    def init(self, context):
        self.asset_id = 'ab3717b30a684dbd875a'
        super().init(context)

class ShaderNodePlxMapping(ShaderNodeCustomGroup):
    bl_name='ShaderNodePlxMapping'
    bl_label='Plx Mapping'
    bl_icon='NONE'

    # HELPER FUNCTIONS

    uv_effects_info = {
        'None': {},
        'Blur': {
            'output_vectors':
            {
                'node': 'Blur Mix',
                'socket': 2
            }
        },
        'Warp': {
            'output_vectors':
            {
                'node': 'Warp Mix',
                'socket': 2
            }
        },
        'Shattering': {
            'output_vectors':
            {
                'node': 'Shattering Mapping',
                'socket': 2
            }
        },
        'Crystallize': {
            'output_vectors':
            {
                'node': 'Voronoi Texture',
                'socket': 2
            }
        },
    }
    
    projection_info = {
        'UV': {
            'output_vectors':
            {
                'node': 'UV',
                'socket': 0
            }
        },
        'Global': {
            'output_vectors':
            {
                'node': 'Position',
                'socket': 0
            }
        },
        'Object': {
            'output_vectors':
            {
                'node': 'Object',
                'socket': 3
            }
        },
        'Decal': {
            'output_vectors':
            {
                'node': 'Object',
                'socket': 3
            }
        },
    }
    
    def get_vector_output_socket(self):
        if self.uv_effect_type == 'None':
            return self.node_tree.nodes["Mapping"].outputs[0]
        else:
            vector_info = self.uv_effects_info[self.uv_effect_type]

            output_info = vector_info.get('output_vectors')

            if output_info:
                node = output_info['node']
                socket = output_info['socket']
                output_node = self.node_tree.nodes[node]

                return output_node.outputs[socket]
        
    def get_projection_output_socket(self):
        rojection_info = self.projection_info[self.projection]

        output_info = rojection_info.get('output_vectors')

        if output_info:
            node = output_info['node']
            socket = output_info['socket']
            output_node = self.node_tree.nodes[node]

            return output_node.outputs[socket]
        
    def get_effect_intput_sockets(self):
        effects_info = self.uv_effects_info[self.uv_effect_type]

        inputs = []
        input_info = effects_info.get('input_vectors')

        if input_info:
            for inp in input_info:
                node = inp['node']
                socket = inp['socket']
                input_node = self.node_tree.nodes[node]

                inputs.append(input_node.inputs[socket])

            return inputs

    
    def uvmap_update(self, context):
        node = self.node_tree.nodes.get('UV')
        node.uv_map = self.uv_map

    def object_update(self, context):
        object_node = self.node_tree.nodes['Object']

        if self.projection == 'Decal':
            object_node.object = self.decal_object
        elif self.projection == 'Object':
            object_node.object = self.object
        
    def projection_update(self, context):
        self.object_update(context)

        out_node = self.node_tree.nodes["Out"]
        mapping_node = self.node_tree.nodes["Mapping"]
        noise_node = self.node_tree.nodes["Noise Texture"]
        culling_node = self.node_tree.nodes["Separate XYZ"]
        voronoi_node = self.node_tree.nodes["Voronoi Texture"]
        location_node = self.node_tree.nodes["Vector Location"]
        white_noise_node = self.node_tree.nodes["White Noise Texture"]

        vector_output_socket = self.get_vector_output_socket()
        projection_output_socket = self.get_projection_output_socket()

        geometry_normal_socket = self.node_tree.nodes["Geometry"].outputs[1]

        if self.projection == "UV":
            noise_node.noise_dimensions = '2D'
            voronoi_node.voronoi_dimensions = '2D'
            white_noise_node.noise_dimensions = '2D'
            geometry_normal_socket.links[0].is_muted = True
            mapping_node.inputs[1].default_value = (0, 0, 0)
        else:
            noise_node.noise_dimensions = '3D'
            voronoi_node.voronoi_dimensions = '3D'
            white_noise_node.noise_dimensions = '3D'
            geometry_normal_socket.links[0].is_muted = False
            mapping_node.inputs[1].default_value = (0.5, 0.5, 0.5)

        self.node_tree.links.new(vector_output_socket, out_node.inputs[0])
        self.node_tree.links.new(vector_output_socket, culling_node.inputs[0])
        self.node_tree.links.new(projection_output_socket, location_node.inputs[0])

    def culling_update(self, context):
        out_node = self.node_tree.nodes.get("Out")
        alpha_node = self.node_tree.nodes.get("Multiply 2")

        if out_node and alpha_node:
            if self.culling:
                self.node_tree.links.new(alpha_node.outputs["Value"], out_node.inputs["Alpha"])
            else:
                for link in out_node.inputs["Alpha"].links:
                    self.node_tree.links.remove(link)

    # PROPERTIES
    
    projection: EnumProperty( 
        name='UV Projection Mode',
        description='Specifies the UV projection mode for mapping onto the layer',
        items = [
            ( "UV", "UVMap", "Project UV coordinates onto the layer" ),
            ( "Global", "Global", "Project using global coordinates" ),
            ( "Object", "Object", "Project using an object as the mapping source" ),
            ( "Decal", "Decal", "Project using decal object" ),
        ],
        default = 'UV',
        update=projection_update
        )
    
    uv_effect_type: EnumProperty(
        name='UV Effect Type',
        description='Specifies the type of UV effect to apply',
        items=[
            ('None', 'None', ''),
            ('Blur', 'Blur', 'Applies a blur effect to the UV coordinates, creating a smooth and softened appearance.'),
            ('Warp', 'Warp', 'Applies a warp effect to the UV coordinates, distorting the texture mapping in a non-linear way.'),
            ('Shattering', 'Shattering', 'Applies a shattering effect to the UV coordinates, breaking the texture into random fragments.'),
            ('Crystallize', 'Crystallize', 'Applies a crystallize effect to the UV coordinates, creating a fragmented and crystalline appearance.'),
        ],
        default='None',
        update=projection_update
    )
    
    uv_map: StringProperty(
        name='UVMap', 
        description='Name of the UV map used for texture mapping', 
        default='', 
        update=uvmap_update
        )

    object: PointerProperty(
        type=bpy.types.Object, 
        name='Object', 
        description='Object used as the mapping source', 
        update=object_update)

    decal_object: PointerProperty(
        type=bpy.types.Object, 
        name='Decal Object', 
        description='Decal object used for UV projection', 
        update=object_update
        )

    culling: BoolProperty(
        name='Culling', 
        description='Enable culling to remove unnecessary parts during UV projection', 
        default=False,
        update=culling_update
        )

    # INHERITED METHODS

    def set_input_hide_value(self):
        for input in self.inputs:
            if input.name not in ["Location", "Rotation", "Scale"]:
                input.hide = True

    def init(self, context):
        set_plx_node_attribute(self)
        self.node_tree = PlxAsset.load_asset('233a2911dd244a5bab24')
        self.set_input_hide_value()

    def free(self):
        if self.node_tree:
            bpy.data.node_groups.remove(self.node_tree, do_unlink=True)

    # DRAW
    def draw_buttons(self, context, layout):
        
        layout.prop(self, 'projection', text='')
        layout.prop(self, 'uv_effect_type', text='')

class ShaderNodePlxColorMask(ShaderNodeCustomGroup):
    bl_name='ShaderNodePlxColorMask'
    bl_label='Plx Color Mask'
    bl_icon='NONE'

    def init(self, context):        
        set_plx_node_attribute(self)
        self.node_tree = PlxAsset.load_asset('7095a458520e40a98b87')

    def free(self):
        if self.node_tree and self.node_tree.users == 1:
            bpy.data.node_groups.remove(self.node_tree, do_unlink=True)
 