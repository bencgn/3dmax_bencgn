import bpy
from bpy.types import Panel, UIList
from ..utils import object_utilities, node_utilities

#######   Plx UI
    
class PHILOGIX_UL_matslots(UIList):

    def draw_item(self, _context, layout, _data, item, icon, _active_data, _active_propname, _index):
        mat = item.material
        is_availability = node_utilities.is_valid_plx_material(mat)

        row = layout.row()

        if mat:
            row.prop(mat, "name", text="", emboss=False, icon_value=icon)
        else:
            row.label(text="", icon_value=icon)

        row = layout.row()
        
        if is_availability:
            row.prop(mat, "use_nodes", text="", icon_value=(38 + int(mat.use_nodes)), emboss=False)
        else:
            row.alignment = "RIGHT"
            row.alert = not is_availability
            row.label(icon_value=(2 + int(is_availability)*34))
        
class PHILOGIX_PT_MatManager(Panel):
    bl_label = "Material set list"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        ob = object_utilities.get_active_mesh_object()
        mat = object_utilities.get_active_material()
        
        if ob is None:
            layout.box().label(text='Let\'s select a mesh object!', icon_value=110)
            return

        self._draw_material_slots(layout, ob, mat)
        self._draw_mesh_buttons(context, layout, mat)
        
    def _draw_material_slots(self, layout, ob, mat):
        col = layout.column(align=True)
        row = col.row(align=True)
        row.template_list("PHILOGIX_UL_matslots", "", ob, "material_slots", ob, "active_material_index", rows=3)

        col_actions = row.column(align=True)
        col_actions.operator("object.material_slot_add", icon='ADD', text="")
        col_actions.operator("plx.remove_material_slot", icon='REMOVE', text="")
        col_actions.operator("object.material_slot_move", icon='TRIA_UP', text="").direction = 'UP'
        col_actions.operator("object.material_slot_move", icon='TRIA_DOWN', text="").direction = 'DOWN'

        row = col.row(align=True)
        row.scale_y = 1.15
        mat_creation_args = {"filter": 'AVAILABLE'}
        if not mat:
            mat_creation_args["new"] = "material.new"
        row.template_ID(ob, "active_material", **mat_creation_args)

        layout.separator(factor=0.1)
    
    def _draw_mesh_buttons(self, context, layout, mat):
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.scale_x = 1.25

        if mat and mat.PlxProps.ID != '':
            row.operator("plx.fix_shader", text='Fix Plx Shader', emboss=True, depress=False, icon_value=92)
        else:
            row.operator("plx.create_shader", text='New Plx Shader', emboss=True, depress=False, icon='ADD')

        row.operator("plx.duplicated_material", text='', icon="DUPLICATE")
        row.operator("plx.remove_shader", text='', icon='TRASH')
