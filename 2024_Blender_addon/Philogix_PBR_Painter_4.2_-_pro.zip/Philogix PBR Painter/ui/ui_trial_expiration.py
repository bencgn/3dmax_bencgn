import bpy
from bpy.types import Panel

class PHILOGIX_PT_TrialExpiration(Panel):
    bl_label = "Trial Version Expiration"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Philogix'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        col.alert = True
        col.label(text="The trial version has expired", icon='ERROR')

        col = layout.column(align=True)
        col.label(text="Consider purchasing the pro version to continue using the addon.")

        col.separator()

        col.label(text="Upgrade Options:")
        row = layout.row()
        row.operator("wm.url_open", text="Philogix PBR Painter - Pro", icon='LINK_BLEND').url = 'https://www.blendermarket.com/products/philogix-pbr-painter-pro?ref=710'
