import bpy, textwrap
from bpy.types import Panel

from ..core.registration_manager import RegistrationManager

rm = RegistrationManager()

def label_multiline(context, layout, text):
    chars = int(context.region.width / 7)
    wrapper = textwrap.TextWrapper(width=chars)
    text_lines = wrapper.wrap(text=text)
    for text_line in text_lines:
        layout.label(text=text_line)

class PHILOGIX_PT_Info(Panel):
    bl_label = "Info"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        if bpy.app.version < (4, 0, 0):
            row = self.layout.row()
            row.alert = True
            row.label(text="", icon='ERROR')

        self.is_open = False
        

    def draw(self, context):
        global remaining_time
        layout = self.layout
        props = context.scene.PlxProps

        # Check if Blender version is less than 3.4
        if bpy.app.version < (3, 4, 0):
            row = layout.row()
            row.alert = True
            row.label(text="Warning: Blender 3.4+ required!", icon='ERROR')
        
        row = layout.row()
        row.label(text="Name:")
        row.label(text="Philogix PBR Painter")

        row = layout.row()
        row.label(text="Author:")
        row.label(text="Philogix studio")
        
        remaining_days_str = " ({} days left)".format(int(rm.remaining_days)) if rm.remaining_days > 0 else ""

        row = layout.row()
        row.label(text="Version:")
        row.label(text=f"4.2 {rm.version_str}{remaining_days_str}")
        
        col = layout.column(align=True)
        
        box = col.box()
        
        box.prop(props, 'fund', text='Thank You for Choosing Philogix PBR Painter!',icon='FUND')
        
        
        if props.fund:
            box = col.box()

            text="We're immensely grateful to all Philogix PBR Painter users. By choosing the pro version, you not only unlock its complete power but also gain lifelong support. Your support ensures a secure and vibrant future for our addon. If you're using the free trial, consider upgrading to unleash Philogix PBR Painter's full potential. Regardless, we appreciate your interest. Thank you for your consideration!"
            label_multiline(context, box, text)

        layout.separator(factor=0.1)

        row = layout.row()
        row.operator("wm.url_open", text="Philogix PBR Painter download links", icon='LINK_BLEND').url = 'https://www.blendermarket.com/products/philogix-pbr-painter-pro?ref=710'
        
        row = layout.row()
        row.operator("wm.url_open", text="Documentation", icon='HELP').url = 'https://philogix.github.io/Philogix-PBR-Painter-Docs/site/'
        row.operator("wm.url_open", text="Report a Bug", icon='URL').url = 'https://forms.gle/MHXbsEny9NdrAC8f6'
