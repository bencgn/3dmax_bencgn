import bpy

from bpy.types import Panel
from ..utils import general_utilities, object_utilities, node_utilities, data_definitions


class PHILOGIX_PT_Baker(Panel):
    bl_label = "Baking"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}


    def draw_bake_button(self, layout):
        row = layout.row()
        row.scale_y = 1.5
        row.operator("plx.baking",text='Baking',emboss=True,depress=False,icon_value=126)

        layout.separator()

    def draw_general_settings(self, layout):
        mesh_props = self.object.data.PlxProps
        layout.use_property_split = True
        layout.use_property_decorate = False
        
        col = layout.column()
        col.prop(mesh_props, "bake_size", text='Size')
        col.prop(self.bake_props, "margin", text='Margin')
        col.prop(self.bake_props, "quality", text='Quality')
        col.prop(self.bake_props, "device", text='Bake Device')
        
        layout.separator(factor=0.1)

        col = layout.column()
        col.prop_search(mesh_props, "bake_uvmap", self.object.data, 'uv_layers', text='Bake UV Map')
        
        layout.separator(factor=0.1)
        
        col = layout.column()
        col.prop(self.bake_props, "user_high", text="Use high mesh")

        if self.bake_props.user_high:
            col.separator()     
            col.prop(self.bake_props, "specified_object", text="Hight mesh")
            col.prop(self.bake_props, "cage_extrusion", text="Extrusion")
            col.prop(self.bake_props, "max_ray_distance", text="Max ray distance")
        
        layout.use_property_split = False
        
        layout.separator()

    def draw_bake_slots(self, layout):
            
        def draw_bake_slot(self, layout, bake_slot):
            
            def draw_slot(layout):
                box = layout.box()
                row = box.row(align=True)

                row.prop(bake_slot, 'extend', text='', icon_value = 28+18*int(bake_slot.extend), emboss=False)
                row.prop(bake_slot, "active", text=bake_slot.name, toggle=True, icon_value=2*wrong_map)

                row = row.row(align=True)
                row.context_pointer_set("plx_bake_image", plx_bake_image)
                row.operator("plx.import_bake", text='', icon_value=706)
                row.operator("plx.clear_bake", text='', icon_value=21)
            
            def draw_settings(layout):
                if not bake_slot.extend:
                    return
                mix_node = self.shader_node.node_tree.nodes.get('Mix' + bake_slot.name)

                if mix_node:
                    row = layout.box().box().row()
                    row.prop(mix_node, 'mute', text='Map Interplay', invert_checkbox = True)
                    row.prop(mix_node.inputs[0], 'default_value', text='Opacity')

                box = layout.box()
                box.use_property_split = True
                box.enabled = bake_slot.active

                if wrong_map:
                    row = box.box()
                    row.alert = True

                    if not bake_node_image:
                        row.label(text="Can't find bake map in Shader!", icon="ERROR")

                    elif not bake_image:
                        row.label(text='Bake Map uncreated for this Mesh!', icon="ERROR")

                    elif bake_image.plx_mesh_image_baking != self.object.data:

                        row.label(text='Bake map is not suitable for this mesh!', icon="ERROR")
                        
                    elif bake_node_image != bake_image:
                        row.label(text='Bake Map is not correct for this Mesh!', icon="ERROR")

                else:
                    row = box.row()
                    row.alert = wrong_map
                    row.prop(bake_node_image, 'name', text='Image Name')

                    for prop_name in props:
                        prop = props[prop_name]
                        
                        if len(prop) == 2:
                            parent_value = getattr(bake_slot, prop[1]['parent'])
                            if parent_value != prop[1]['value']: continue
                        
                        row = box.row()
                        if prop_name == 'layer_name':
                            row.prop_search(bake_slot, prop_name, self.object.data, 'color_attributes', text='Vertex Layer')
                        else:
                            row.prop(bake_slot, prop_name)
        
            bake_image = None
            bake_node_image = None
            node_tree = self.material.node_tree
            bake_list = data_definitions.get_bake_list()
            props = bake_list[bake_slot.name]['props']
            plx_bake_images = self.object.data.PlxProps.bake_images
            plx_bake_image = plx_bake_images.get(bake_slot.name)
            bake_image_node = node_tree.nodes.get(general_utilities.delimiter_join('Plx', bake_slot.image_name))

            if plx_bake_image: bake_image = plx_bake_image.image
            if bake_image_node: bake_node_image = bake_image_node.image

            wrong_map = bake_image is None or bake_node_image is None or bake_node_image != bake_image or bake_image.plx_mesh_image_baking != self.object.data

            draw_slot(layout)
            draw_settings(layout)
        
        for bake_slot in self.bake_props.slots:
            
            col = layout.column(align=True)
            
            draw_bake_slot(self, col, bake_slot)

    def draw_baking(self, layout):        
        col = layout.column(align=True)
        
        box = col.box()
        
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text='Press ESC to cancel', icon='CANCEL')

        box = col.box()

        for slot in self.bake_props.slots:
            status_mapping = {
                'waiting': (slot.name, 'SORTTIME'),
                'baking': (f'Baking {slot.name}...', 'RENDER_STILL'),
                'done': (slot.name, 'CHECKMARK')}
            
            text, icon = status_mapping.get(slot.baking_status, ('ERROR', 'ERROR'))
            box.label(text=text, icon=icon)

    def draw_error_box(self, layout, error_message):
        box = layout.box()
        box.label(text=error_message, icon='ERROR')

    def draw(self, context):
        self.object = object_utilities.get_active_mesh_object()
        self.material = object_utilities.get_active_material()
        self.shader_node = node_utilities.get_shader_node(self.material)
        self.bake_props = context.scene.PlxProps.bake_properties
        layout = self.layout

        if not node_utilities.is_valid_plx_material(self.material):
            self.draw_error_box(layout, 'Plx Shader not found !')
            return
            
        if not hasattr(context.scene, 'cycles'):
            self.draw_error_box(layout, 'Cycles Engine not found !')
            return
    
        self.draw_bake_button(layout)

        if self.bake_props.is_baking:
            self.draw_baking(layout)
        else:
            self.draw_general_settings(layout)
            self.draw_bake_slots(layout)