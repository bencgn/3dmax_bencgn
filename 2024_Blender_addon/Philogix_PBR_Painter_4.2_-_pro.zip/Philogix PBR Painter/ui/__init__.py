import bpy

from ..core.registration_manager import RegistrationManager
from . import ui_bake, ui_export, ui_groups, ui_info, ui_materials, ui_trial_expiration, paint_layers
    
rm = RegistrationManager()

###############   REGISTER ADDON

expired = False
classes = []

dev_version_classes = (
    ui_groups.PHILOGIX_PT_Dev,
)

pro_version_classes = (
    ui_info.PHILOGIX_PT_Info,
    ui_materials.PHILOGIX_PT_MatManager,
    ui_materials.PHILOGIX_UL_matslots,
    ui_bake.PHILOGIX_PT_Baker,
    ui_export.PHILOGIX_PT_Export,
    ui_export.PHILOGIX_PT_ExportPresets
)

trial_expiration_classes = (
    ui_trial_expiration.PHILOGIX_PT_TrialExpiration,
    )

if rm.is_pro_version or rm.trailer_remaining_time > 0:
    classes = list(pro_version_classes)
else:
    expired = True
    classes.append(ui_trial_expiration.PHILOGIX_PT_TrialExpiration)

if rm.is_dev_version:
    classes.extend(dev_version_classes)


def register():
    for c in classes:
        bpy.utils.register_class(c)

    if not expired:
        paint_layers.register()


def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    if not expired:
        paint_layers.unregister()

