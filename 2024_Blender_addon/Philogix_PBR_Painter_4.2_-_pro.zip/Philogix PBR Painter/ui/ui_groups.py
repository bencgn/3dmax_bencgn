import bpy
from bpy.types import Panel
from ..utils import asset_utilities

class PHILOGIX_PT_Dev(Panel):
    bl_label = "Development Panel"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 5
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        props = context.scene.PlxDevProps
        layout = self.layout

        snode = context.space_data
        tree = snode.edit_tree            

        layout.use_property_split = True
        layout.use_property_decorate = False

        original = asset_utilities.get_original_data_of_node_tree(tree)

        box = layout.box()
        box.label(text="Data Info:")

        layout.context_pointer_set("plx_editing_data", original)

        # Check type of 'original' and draw corresponding properties
        if type(original) in (bpy.types.ShaderNodeTree, bpy.types.Material):
            for prop, label in [('name', 'Name'), 
                                ('PlxAssetId', 'Asset ID'), 
                                ('PlxAssetType', 'Asset Type'), 
                                ('PlxAssetName', 'Asset Name')]:
                row = box.row()
                row.prop(original, prop, text=label)

        layout.separator()

        box = layout.box()
        box.label(text="Action:")

        # List of operator ids and their labels for drawing
        ops = [("plx.dev_import_asset", "Import"),
            ("plx.dev_export_asset", "Export"),
            ("plx.dev_set_asset", "Set To Data"),
            ("plx.dev_save_asset", "Save..."),
            ("plx.dev_save_as_asset", "Save As..."),
            ("plx.dev_remove_asset", "Remove"),
            ("plx.dev_fix_data", "Fix Asset")]

        for op_id, label in ops:
            row = box.row()
            row.operator(op_id, text=label, emboss=True, depress=False)

        box = layout.box()

        row = box.row()
        row.label(text='Defaults Data:')

        row = box.row()
        row.prop(props, 'default_data', text='')

        

class PhilogixInterfacePanel:
    smart_material_outputs_list = [
        {
            'name': 'Base Color',
            'type': 'NodeSocketColor',
            'default_value': (0.0, 0.0, 0.0, 1)
        },
        {
            'name': 'Diffuse',
            'type': 'NodeSocketColor',
            'default_value': (0.0, 0.0, 0.0, 1)
        },
        {
            'name': 'Subsurface',
            'type': 'NodeSocketFloat',
            'default_value': 0,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Subsurface Color',
            'type': 'NodeSocketColor',
            'default_value': (0.8, 0.8, 0.8, 1)
        },
        {
            'name': 'Metallic',
            'type': 'NodeSocketFloat',
            'default_value': 0,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Specular',
            'type': 'NodeSocketColor',
            'default_value': (0, 0, 0, 1)
        },
        {
            'name': 'Roughness',
            'type': 'NodeSocketFloat',
            'default_value': 0.5,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Glossiness',
            'type': 'NodeSocketFloat',
            'default_value': 0.5,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Emission',
            'type': 'NodeSocketColor',
            'default_value': (0, 0, 0, 1)
        },
        {
            'name': 'Alpha',
            'type': 'NodeSocketFloat',
            'default_value': 1,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Height',
            'type': 'NodeSocketFloat',
            'default_value': 0.5,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Normal',
            'type': 'NodeSocketColor',
            'default_value': (0.5, 0.5, 1, 1)
        },
        {
            'name': 'Transmission',
            'type': 'NodeSocketFloat',
            'default_value': 0,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Transmission Roughness',
            'type': 'NodeSocketFloat',
            'default_value': 0,
            'min_value': 0,
            'max_value': 1
        },
        {
            'name': 'Layer Mask',
            'type': 'NodeSocketFloat',
            'default_value': 1,
            'min_value': 0,
            'max_value': 1
        }
    ]

    smart_surface_outputs_list = [
        {
            'name': 'Color',
            'type': 'NodeSocketColor',
            'default_value': (0.8, 0.8, 0.8, 1)
        },
        {
            'name': 'Alpha',
            'type': 'NodeSocketFloat',
            'default_value': 1,
            'min_value': 0,
            'max_value': 1
        }
    ]

    inputs = (
        {'name': 'Vector','type': 'NodeSocketVector', 'default_value': (0, 0, 0), 'min_value': 0, 'max_value': 1},
        {'name': 'Image_Normal','type':  'NodeSocketColor', 'default_value': (0.5, 0.5, 1, 1), 'min_value': 0, 'max_value': 1},
        {'name': 'Image_ID','type':  'NodeSocketColor', 'default_value': (0, 0, 0, 1), 'min_value': 0, 'max_value': 1},
        {'name': 'Image_Ambient Occlusion','type':  'NodeSocketFloat', 'default_value': 1, 'min_value': 0, 'max_value': 1},
        {'name': 'Image_Curvature', 'type': 'NodeSocketFloat', 'default_value': 0, 'min_value': 0, 'max_value': 1},
    )


    def draw_socket_list(self, context, in_out, sockets_propname, active_socket_propname):
        layout = self.layout

        snode = context.space_data
        tree = snode.edit_tree
        
        if not hasattr(tree, sockets_propname):
            return
        
        sockets = getattr(tree, sockets_propname)
        active_socket_index = getattr(tree, active_socket_propname)
        active_socket = sockets[active_socket_index] if active_socket_index >= 0 else None

        split = layout.row()

        split.template_list("NODE_UL_interface_sockets", in_out, tree, sockets_propname, tree, active_socket_propname)

        ops_col = split.column()

        add_remove_col = ops_col.column(align=True)
        props = add_remove_col.operator("node.tree_socket_add", icon='ADD', text="")
        props.in_out = in_out
        props = add_remove_col.operator("node.tree_socket_remove", icon='REMOVE', text="")
        props.in_out = in_out

        ops_col.separator()

        up_down_col = ops_col.column(align=True)
        props = up_down_col.operator("node.tree_socket_move", icon='TRIA_UP', text="")
        props.in_out = in_out
        props.direction = 'UP'
        props = up_down_col.operator("node.tree_socket_move", icon='TRIA_DOWN', text="")
        props.in_out = in_out
        props.direction = 'DOWN'

        if active_socket is not None:
            if in_out == 'IN' and active_socket_index < 5:
                layout_row = layout.row(align=True)
                layout_row.label(text="This is the default socket")

            elif in_out == 'OUT' and active_socket_index < 14:
                layout_row = layout.row(align=True)
                layout_row.label(text="This is the default socket")

            else:
                # Mimicking property split.
                layout.use_property_split = False
                layout.use_property_decorate = False
                layout_row = layout.row(align=True)
                layout_split = layout_row.split(factor=0.4, align=True)

                label_column = layout_split.column(align=True)
                label_column.alignment = 'RIGHT'
                # Menu to change the socket type.
                label_column.label(text="Type")

                property_row = layout_split.row(align=True)
                props = property_row.operator_menu_enum(
                    "node.tree_socket_change_type",
                    "socket_type",
                    text=active_socket.bl_label if active_socket.bl_label else active_socket.bl_idname
                    )
                props.in_out = in_out

                layout.use_property_split = True
                layout.use_property_decorate = False

                layout.prop(active_socket, "name")
                active_socket.draw(context, layout)

                #if 'Float' in active_socket.bl_socket_idname:
                #    props = context.scene.PlxProps
                #    layout.prop(props, "active_factor")


class PHILOGIX_PT_node_tree_interface_inputs(PhilogixInterfacePanel, Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Philogix"
    bl_label = "Inputs"

    @classmethod
    def poll(cls, context):
        snode = context.space_data
        return snode.edit_tree is not None

    def draw(self, context):
        self.draw_socket_list(context, "IN", "inputs", "active_input")

class PHILOGIX_PT_node_tree_interface_outputs(PhilogixInterfacePanel, Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Philogix"
    bl_label = "Outputs"

    @classmethod
    def poll(cls, context):
        snode = context.space_data
        return snode.edit_tree is not None

    def draw(self, context):
        self.draw_socket_list(context, "OUT", "outputs", "active_output")

