import bpy
from . import ui_image_parament, ui_id_parameter, ui_filter_parameter, ui_anchor_parameter

from .ui_common_draw import draw_item_inputs, draw_asset_slot_control
from ....utils.general_utilities import delimiter_join


def draw_layer_parameters(self, layout, props):                 
    value_node = self.layer_node_group.nodes.get('Value')

    layout.context_pointer_set("active_layer_group", self.layer_node_group)

    if value_node:
        box = layout.box()
        box.context_pointer_set("active_value_node", value_node)

        layer_type = self.layer_node_group.PlxProps.layer_type
        draw_layer_header(self, box, props, layer_type, value_node)
        draw_parameters(self, box, props, layer_type, value_node)

def draw_layer_header(self, layout, props, layer_type, value_node):
    row = layout.row(align=True)

    row.prop(props, 'parameter_extended_settings', text='', emboss=False, icon_value = 4+int(props.parameter_extended_settings))
    row.label(text=" Parameters:")

def draw_parameters(self, layout, props, layer_type, value_node):
    if not props.parameter_extended_settings: return 
    origin_node_tree = self.editing_layer.origin_node_tree
    
    mix_node = origin_node_tree.nodes.get(delimiter_join(self.editing_layer.ID, 'MixLayer'))
    opacity_node = origin_node_tree.nodes.get(delimiter_join(self.editing_layer.ID, 'MixOpacity'))

    if mix_node and opacity_node:
        row = layout.box().row(align=True)
        row.prop(mix_node, "blend_type", text='')
        row.prop(opacity_node.inputs[0], 'default_value', text='Opacity', slider = True)
        
    if layer_type == 'MATERIAL':
        node_group = value_node.node_tree
        draw_asset_slot_control(layout, node_group, 'Materials')
        draw_item_inputs(self, layout, value_node)
            
    elif layer_type == 'SURFACE':
        value_group = value_node.node_tree
        draw_asset_slot_control(layout, value_group, 'Surfaces')
        draw_item_inputs(self, layout, value_node)
        
    elif layer_type == 'IMAGE':
        ui_image_parament.draw_image_parameters(self, layout, value_node)
        
    elif layer_type == 'ANCHOR':
        ui_anchor_parameter.draw_anchor_parameters(self, layout, value_node) 
        
    elif layer_type == 'ID':
        ui_id_parameter.draw_id_parameters(self, layout, value_node)
        
    elif layer_type == 'FILTER':
        ui_filter_parameter.draw_filter_parameters(self, layout, value_node)
    
