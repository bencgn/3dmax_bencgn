import bpy

def draw_filter_parameters(self, layout, value_node):
    box = layout.box()
    box.label(text = value_node.bl_label)

    if hasattr(value_node, "draw_buttons_ext"):
        value_node.draw_buttons_ext(bpy.context, box)
    elif hasattr(value_node, "draw_buttons"):
        value_node.draw_buttons(bpy.context, box)

    for input in value_node.inputs:
        
        if input.hide_value or not input.enabled or input.is_linked or input.name == 'Fac': continue
        
        box.prop(input, 'default_value', text = input.name)
