import bpy
from ....utils import asset_utilities
from . import ui_common_draw as common_draw

def draw_image_parameters(self, layout, value_node):
    image = value_node.image
    props = bpy.context.scene.PlxProps

    col = layout.column(align=True)

    draw_panel_control(col, props)

    if props.image_layer_parameter_mode == 'IMAGE':
        draw_image_panel(col, value_node)
        draw_image_setting(self, layout, value_node)
    else:
        context = bpy.context
        active_mode = context.active_object.mode
        active_brush = context.tool_settings.image_paint.brush
        active_canvas = context.tool_settings.image_paint.canvas
        draw_paint_panel(self, col, props, image, active_mode, active_canvas, active_brush)


def draw_panel_control(layout, props):
    box = layout.box()

    row = box.row(align=True)
    row.scale_x = 1.25
    row.scale_y = 1.5
    row.prop(props, "image_layer_parameter_mode", text='Parameter Panels', expand=True)
    
    row.separator(factor=0.2)
    row.menu("PHILOGIX_MT_Image", icon_value=18, text="")

def draw_image_setting(self, layout, value_node):
    image = value_node.image
    if image is None:
        return
    
    box = layout.box()
    common_draw.draw_channels_output(self, box)

    box.use_property_split = True
    box.use_property_decorate = False  # No animation.

    row = box.column()
    row.enabled = not image.is_dirty
    row.prop(image.colorspace_settings, "name", text = 'Color Space')
    row.prop(image, "alpha_mode")

    row = box.column()
    row.prop(value_node, "interpolation")
    row.prop(value_node, "extension")

    row = box.column()
    row.prop_with_menu(image, 'source', text= 'Image Source', menu='PHILOGIX_MT_ImageSource')


def draw_image_preview(layout, image, preview):
    # Vẽ xem trước hình ảnh
    row = layout.row()
    row.scale_y = 7.25 + int(image is None) * 1.4
    row.template_icon(preview)

def draw_image_control(layout, value_node):
    # Vẽ điều khiển hình ảnh
    row = layout.row()
    row.scale_y = 1.4
    row.scale_x = 1.1
    row.template_ID(value_node, 'image', new="plx.create_layer_image", open="image.open")


def draw_image_panel(layout, value_node):
    # Vẽ panel hình ảnh
    preview = asset_utilities.get_asset_image_preview(value_node)

    box = layout.box()
    draw_image_preview(box, value_node.image, preview)

    box = layout.box()
    draw_image_control(box, value_node)


def draw_paint_button(self, layout, props, image, mode, canvas):
    # Determine the paint text based on the image status
    operator = "plx.paint_finish" if mode == 'TEXTURE_PAINT' and canvas == image else "plx.paint"

    row = layout.row(align=True)
    row.scale_y = 1.5
    row.scale_x = 1.25

    row.context_pointer_set("plx_paint_image", image)
    row.context_pointer_set("plx_projection_layer", self.projection_layer)

    row.operator(operator, icon_value=134)
    row.prop(props, 'brush_settings_extend', text='', icon='TOOL_SETTINGS', slider=True)


def draw_paint_brush_slot(layout, brush):
    # Vẽ khe cọ vẽ
    common_draw.draw_asset_slot_control(layout, brush, 'Brushes')

def draw_paint_brush_settings(layout, props, brush):
    if not props.brush_settings_extend: return

    tex_slot = brush.texture_slot

    layout.separator(factor=0.25)

    col = layout.column(align=True)

    box = col.box()
    box.label(text='Basic Brush Settings:', icon='TOOL_SETTINGS')

    box.use_property_split = True
    box.use_property_decorate = False

    col = box.column()

    row = col.row(align=True)
    row.prop(tex_slot, 'map_mode', text='Texture Mode')
    row.operator("plx.load_image_texture", text='', icon='IMAGE_PLANE')

    col.separator(factor=1)

    col.prop(brush, 'stroke_method')

    col.separator(factor=0.1)

    row = col.row(align=True)
    row.prop(brush, 'spacing')
    row.prop(brush, "use_pressure_spacing", toggle=True, text="")

    col.separator(factor=0.25)

    row = col.row(align=True)
    if brush.jitter_unit == 'BRUSH':
        row.prop(brush, "jitter", slider=True)
    else:
        row.prop(brush, "jitter_absolute")
    row.prop(brush, "use_pressure_jitter", toggle=True, text="")
    col.row().prop(brush, "jitter_unit", expand=True)

    col.separator(factor=0.25)

    row = col.row(align=True)
    row.active = brush.use_smooth_stroke
    row.prop(brush, "smooth_stroke_radius", text="Smooth Stroke", slider=True)
    row.prop(brush, 'use_smooth_stroke', toggle=True, text="", icon='IPO_ELASTIC')


def draw_paint_panel(self, layout, props, image, mode, canvas, brush):
    # Vẽ panel vẽ
    box = layout.box()
    box.enabled = image is not None

    draw_paint_brush_slot(box, brush)

    col = box.column()

    draw_paint_button(self, col, props, image, mode, canvas)
    draw_paint_brush_settings(col, props, brush)
