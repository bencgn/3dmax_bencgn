import bpy

def draw_id_parameters(self, layout, value_node):
    nodes = value_node.node_tree.nodes
    tollerance = value_node.inputs['Tollerance']

    alpha_node = self.layer_node_group.nodes.get('AlphaMode')

    col = layout.column(align=True)
    box = col.box()

    row = box.row()
    row.label(text='Colors:')
    row.operator('plx.aditions', text='Add ID Color', icon_value=31).color_name = ''

    for node in nodes:
        if node.name.split('.')[0]!='Plx Color Mask': continue

        row = box.row()

        picker_row = row.row(align=True)
        picker_row.prop(node.inputs['Color'], 'default_value', text='')
        screen_picker = picker_row.operator('plx.screen_picker', text='', icon='EYEDROPPER')
        screen_picker.id_node_name = value_node.node_tree.name
        screen_picker.color_node_name = node.name
        
        row.operator('plx.aditions', text='', icon_value=32).color_name = node.name

    row = box.row()
    row.prop(tollerance, 'default_value', text = 'Tollerance', slider = True)

    if alpha_node:
        box.separator(factor=0.1)

        row = box.row()
        row.prop(alpha_node, "mute", text="Includes Alpha", icon='IMAGE_ALPHA')
