import bpy
from ....addon.distribution import AssetCategory
from ....utils.asset_utilities import get_asset_image_preview
from ....core.registration_manager import RegistrationManager

rm = RegistrationManager()
OPERATION_IDS = {
    "import": "plx.import_asset",
    "export": "plx.export_asset",
    "save": "plx.save_asset",
    "remove": "plx.remove_asset"
} if rm.is_pro_version else {
    "import": "plx.trailer_action",
    "export": "plx.trailer_action",
    "save": "plx.trailer_action",
    "remove": "plx.trailer_action"
}

def draw_channels_output(self, layout):
    row = layout.row()
    row.use_property_split = True
    row.use_property_decorate = False  # No animation.
    row.prop(self.editing_layer, "channels_output")

def draw_item_inputs(self, layout, value_node):
    box = None
    layer_props = self.layer_node_group.PlxProps

    if layer_props.layer_type in ['SURFACE', 'IMAGE']:
        box = layout.box()
        draw_channels_output(self, box)

    for input in value_node.inputs:
        if  input.name.startswith('plx_separator'):
            if box is None: 
                box = layout.box()

            box.separator(factor=0.1)
            split_name = input.name.split(':')
            
            if len(split_name)>1:
                row = box.row()
                row.label(text=split_name[1])

        elif not input.hide_value and input.enabled:
            if box is None: 
                box = layout.box()

            row = box.row()
            row.prop(input, 'default_value', text = input.name)

def draw_asset_slot_control(layout, asset, asset_type):
    layout.context_pointer_set("active_asset", asset)

    row = layout.box()
    box = row.box()

    draw_items(box, asset, asset_type)
    draw_name(box, asset)
    draw_preferences(row, asset, asset_type)

def draw_items(layout, asset, asset_type):
    preview = get_asset_image_preview(asset)
    col = layout.column(align=True)
    
    row = col.row()
    row.scale_y = 7.5
    row.ui_units_y = 0.25
    row.operator("plx.select_asset", text=' ').asset_type = asset_type

    row = col.row()
    row.template_icon(preview, scale=7)
    
def draw_name(layout, data):
    row = layout.row()
    row.scale_y = 1.15

    if data:
        if data.PlxAssetName:
            row.prop(data, 'PlxAssetName', text='', icon='CURRENT_FILE')
        else:
            row.prop(data, 'name', text='', icon='CURRENT_FILE')
    else:
        box = row.box()
        box.scale_y = 0.625
        box.label(text='No brush available!', icon = 'INFO')

def draw_preferences(layout, asset,  asset_type):
    global OPERATION_IDS
    category_items = AssetCategory.get_category_items(asset_type)
    asset_category = asset.PlxAssetCategory if asset else ''
    asset_category_info = category_items.get(asset_category, {'name': 'Other'})

    factor = 0.5

    row = layout.row(align=True)

    row.popover("PHILOGIX_PT_Category", text=asset_category_info['name'], icon='ASSET_MANAGER')
    row.separator(factor=factor)

    if asset_type != 'Brushes': 
        row.operator("plx.open_group", text = "", icon = "TOPBAR")
        row.separator(factor=factor)

    row.operator(OPERATION_IDS['import'], text='', icon='IMPORT', emboss=True).asset_type = asset_type
    row.separator(factor=factor)

    row.operator(OPERATION_IDS['export'], text='', icon='EXPORT', emboss=True).asset_type = asset_type
    row.separator(factor=factor)

    row.operator_menu_enum(OPERATION_IDS['save'], "save_type", text="", icon='DISK_DRIVE').asset_type = asset_type
    row.separator(factor=factor)

    row.operator(OPERATION_IDS['remove'], text='', icon='TRASH', emboss=True)
