import bpy
from ....utils.general_utilities import delimiter_split

def draw_anchor_parameters(self, layout, value_node):    
    box = layout.box()
    active_anchor_name = "Select anchor..."

    if hasattr(value_node, 'node_tree'):
        split_name = delimiter_split(value_node.node_tree.name)
        active_node_group = bpy.data.node_groups.get(split_name[0])

        if active_node_group and active_node_group.PlxProps.layer_type in ["CUSTOM", "MATERIAL"]:
            active_anchor_name = f"{active_node_group.PlxProps.name} -> {split_name[1]}"     

    box.menu("PHILOGIX_MT_AnchorPointsMenu", icon='NODETREE', text=active_anchor_name)