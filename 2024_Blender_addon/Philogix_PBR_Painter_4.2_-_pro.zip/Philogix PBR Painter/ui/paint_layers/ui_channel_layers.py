import bpy
from ...addon import distribution


def draw_channel_layers(self, layout): 
    material_layer_props = self.material_layer_group.PlxProps
    layer_type = material_layer_props.layer_type

    col = layout.column(align=True)

    if layer_type == 'MATERIAL' and self.mat.PlxProps.edit_maps != 'Layer Mask':
        col.enabled = False
        self.editing_layer = self.material_layer

    elif self.channel_group:
        col.enabled = True
        self.editing_layer = self.channel_group.PlxProps.active_layer

    else:
        col.enabled = False
        self.editing_layer = None

    if not self.channel_group:
        box = layout.box()
        row = box.row()
        row.label(text = ' An error occurred in the channel !', icon_value = 110)
        return

    draw_channel_layer_slots(self, col)
    draw_channel_layers_control(self, col)
        
    layout.separator(factor=0.5)



def draw_channel_layer_slots(self, layout):
    row = layout.row(align=True)
    row.scale_y = 1

    row.context_pointer_set("plx_layers_origin_props", self.channel_group.PlxProps)
    row.template_list("PHILOGIX_UL_LayerChannelItems", "2", self.channel_group.PlxProps, 'layers', self.channel_group.PlxProps, 'layers_index', sort_reverse = True, sort_lock=True, rows = 3)          

def draw_channel_layers_control(self, layout): 
    material_layer_props = self.material_layer_group.PlxProps

    row = layout.row(align=True)
    row.enabled = not (self.mat.PlxProps.edit_maps!='Layer Mask' and material_layer_props.icon_value == 127)

    box = row.box()
    box.alignment = "CENTER"
    draw_add_layer_operators(box)
    
    box = row.box()
    box.alignment = "CENTER"
    draw_function_operators(self, box)


def draw_add_layer_operators(layout):

    icon = distribution.PreviewsCollection.previews
    
    row = layout.row()
    row.alignment = "CENTER"

    row.operator("plx.add_surface", text="", icon_value=313, emboss=False)
    row.operator("plx.add_image", text="", icon_value=361, emboss=False)
    row.operator("plx.add_anchor", text="", icon_value=icon['ANCHOR'], emboss=False)
    row.operator("plx.add_id", text="", icon_value=34, emboss=False)
    row.menu("PHILOGIX_MT_Filter", icon_value=93, text="")

def draw_function_operators(self, layout):
    
    col = layout.row()
    col.alignment = "RIGHT"
    col.context_pointer_set("plx_layers_origin_props", self.channel_group.PlxProps)
    
    col.menu("PHILOGIX_MT_LayersExpandedMenu", icon='DOWNARROW_HLT', text="")
    col.operator("plx.up_channel_layer", text="", icon="TRIA_DOWN", emboss=False)
    col.operator("plx.down_channel_layer", text="", icon="TRIA_UP", emboss=False)
    col.operator("plx.remove_channel_layer", text="", icon="TRASH", emboss=False)


    

