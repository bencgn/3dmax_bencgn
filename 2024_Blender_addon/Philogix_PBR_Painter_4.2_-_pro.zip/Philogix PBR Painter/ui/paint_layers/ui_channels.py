import bpy
from ...utils.general_utilities import delimiter_join

from ...addon.distribution import PreviewsCollection

def draw_material_layer_channels(self, layout):
    mat_props = self.mat.PlxProps
    
    if not self.material_layer or not self.material_layer.node_group:
        box = layout.box()
        row = box.row()
        row.label(text = ' No Material Layer selected !', icon_value = 110)
        return False
    
    self.material_layer_group = self.material_layer.node_group
    self.channel_group = self.material_layer.channel_node_group

    layout.active = self.material_layer and self.material_layer_group == bpy.data.node_groups.get(self.material_layer.name)
    
    
    draw_channel_list(layout, mat_props)
    draw_channel_layer_name(self, layout, mat_props)

    layout.separator(factor=0.5)
    return True

def draw_channel_list(layout, mat_props):
    box = layout.box()
    box = box.box()
    row = box.row()

    row.alignment = 'CENTER'
    row.scale_y = 1.5
    row.scale_x = 2
    row.prop(mat_props, "edit_maps", expand=True, icon_only=True)

def draw_channel_layer_name(self, layout, mat_props):
    icon = PreviewsCollection.previews
    material_layer_props = self.material_layer_group.PlxProps
    layer_type = material_layer_props.layer_type

    blend_node = self.material_layer_group.nodes.get(delimiter_join(mat_props.edit_maps, 'MixLayer'))
    opacity_node = self.material_layer_group.nodes.get(delimiter_join(mat_props.edit_maps, 'MixOpacity'))
    
    box = layout.box()
    row = box.row(align=True)
    row_anchor = row.row()

    if self.channel_group and ((layer_type == "MATERIAL" and mat_props.edit_maps == 'Layer Mask') or (layer_type != "MATERIAL")):
        row_anchor.prop(self.channel_group.PlxProps, 'channel_anchor', icon_value=icon['ANCHOR'], icon_only=True)
    else:
        row_anchor.alert = True
        row_anchor.label(icon_value=icon['ANCHOR_BAN'])

    row.label(text=' ' + mat_props.edit_maps + ':')

    if mat_props.edit_maps != 'Layer Mask' and blend_node and opacity_node:
        row.prop(blend_node, 'blend_type', text='')
        row.prop(opacity_node.inputs[0], 'default_value', text='Opacity', slider=True)
    
    layout.separator(factor=0.35)
