import bpy
from bpy.types import Panel, UIList, Menu

from . import ui_layer_settings, ui_material_layers, ui_channel_layers, ui_channels
from ...operators.layers.channel_layer_management import  channel_layer_manipulation
from ...operators.layers.material_layer_management import material_layer_manipulation

from ...utils.data_definitions import get_pbr_channels
from ...utils.node_utilities import is_valid_plx_material
from ...utils.object_utilities import get_active_material
from ...utils.general_utilities import get_context_pointer, delimiter_join, delimiter_split

from ...addon.distribution import AssetCategory

class PHILOGIX_MT_ImageSource(Menu):
    bl_label = "Image Source"

    def draw(self, context):
        editing_layer = get_context_pointer(context, 'plx_editing_layer')
        self.layout.prop(editing_layer, 'image_source', emboss=True, expand=True)

class PHILOGIX_MT_Image(Menu):
    bl_label = "Image"

    def draw(self, context):
        value_node = get_context_pointer(context, 'active_value_node')
        image = value_node.image

        if not image:
            self.layout.label(text="Image not found!", icon="ERROR")
            return

        image_name = image.name
        pack_enabled = not image.packed_file

        layout = self.layout

        row = layout.row()
        row.operator("plx.save_image", text="Save", icon='FILE_TICK').image_name = image_name

        row = layout.row()
        row.operator("plx.save_as_image", text="Save As...").image_name = image_name

        row = layout.row()
        layout.operator("image.save_all_modified", text="Save All Images")

        layout.separator()

        row = layout.row()
        row.enabled = pack_enabled
        row.operator("plx.pack_image", text="Pack").image_name = image_name

        row = layout.row()
        row.enabled = not pack_enabled
        row.operator("plx.unpack_image", text="Unpack").image_name = image_name

class PHILOGIX_MT_Filter(Menu):
    bl_label = "Add Filter Layer"
    bl_description = "Filter Layer allows to apply color filters to the layers below it"

    def draw(self, _context):

        types=[
            ('ShaderNodeBrightContrast', 'Bright/Contrast', 'LIGHT_SUN'), 
            ('ShaderNodeHueSaturation', 'Hue/Saturation', 'FCURVE'), 
            ('ShaderNodeGamma', 'Gamma', 'IMAGE_RGB'), 
            ('ShaderNodeInvert', 'Invert', 'IMAGE_ZDEPTH'), 
            ('ShaderNodeRGBToBW', 'Black & White', 'IMAGE_ALPHA'), 
            ('ShaderNodeRGBCurve', 'Curve', 'IPO_BEZIER'),
            ('ShaderNodeValToRGB', 'Color Ramp', 'FCURVE_SNAPSHOT')
            ]
        layout = self.layout

        for type in types:
            layout.operator("plx.add_filter", text=type[1], icon=type[2]).filter_type = type[0]

class PHILOGIX_MT_AnchorPointsMenu(Menu):
    bl_label = "Anchor Points Menu"

    def draw(self, context):
        layout = self.layout

        channel_layer = get_context_pointer(context, 'active_layer_group')
        channel_group = channel_layer.id_data

        anchor_list = {
            ng: f"{bpy.data.node_groups[delimiter_split(ng.name)[0]].PlxProps.name} -> {delimiter_split(ng.name)[1]}"
            for ng in bpy.data.node_groups
            if ng.PlxProps.channel_anchor and ng != channel_group
        }

        if anchor_list:
            for node_group, anchor_name in anchor_list.items():
                layout.operator("plx.change_anchor", text=anchor_name).select_group_name = node_group.name
        else:
            layout.label(text="Anchor Point not found!", icon="INFO")

class PHILOGIX_MT_LayersExpandedMenu(Menu):
    bl_label = "Material Layers Expanded Menu"

    def draw(self, context):
        layout = self.layout

        layout.separator()
        layout.operator("plx.copy_layer", text="Copy", icon='COPYDOWN')
        layout.operator("plx.copy_multiple_layer", text="Copy Multiple", icon='COPYDOWN')
        layout.operator("plx.paste_layer", text="Paste", icon='PASTEDOWN').is_linked = False
        layout.operator("plx.paste_layer", text="Paste Linked", icon='LINKED').is_linked = True
        layout.operator("plx.make_local_layer", text = "Unlink Layer", icon_value=55)
        layout.operator("plx.duplicated_layer", text="Duplicated", icon='DUPLICATE')

        plx_layers_origin_props = getattr(context, "plx_layers_origin_props", None)
        if isinstance(plx_layers_origin_props.id_data, bpy.types.Material):
            layout.separator()
            layout.operator("plx.import_pbr", icon='IMPORT')

class PHILOGIX_UL_MaterialLayerItems(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        mat = data.id_data
        node_tree = mat.node_tree
        self.item_node = node_tree.nodes.get(item.ID)

        # Simplified early exit for error drawing
        if self.is_valid_item_node():
            layer_node_group = self.item_node.node_tree
            group_props = layer_node_group.PlxProps
            layer_type = group_props.layer_type
            is_moved_item = mat.PlxProps.layers_index == index

            # Check for valid layer types
            if layer_type in ['MATERIAL', 'CUSTOM']:
                self.draw_valid_layer(layout, layer_node_group, group_props, is_moved_item, item, index)
                return

        self.draw_error_layer(layout)

    def is_valid_item_node(self):
        """ Check if the item node is valid """
        return self.item_node and hasattr(self.item_node, 'node_tree') and self.item_node.node_tree

    def draw_layer_controls(self, layout, icon_value, item, group_props):
        """ Draw the layer control UI elements """
        row = layout.row(align=True)

        icon_row = row.row()
        icon_row.active = False
        icon_row.label(icon_value=icon_value)

        row.prop(item, 'mute', text='', icon_value=(254 - int(item.mute)), emboss=False)
        row.prop(group_props, 'name', icon="NONE", emboss=False, text="")

        color_row = layout.row()
        color_row.ui_units_x = 1
        color_row.prop(self.item_node, 'color', text="")

    def draw_valid_layer(self, layout, layer_node_group, group_props, is_moved_item, item, index):
        """ Draw UI elements for a valid layer """
        is_linked_layer = layer_node_group != bpy.data.node_groups.get(item.ID)
        icon_value = 259 if is_linked_layer else group_props.icon_value
        layout.ui_units_y = 1.25 if material_layer_manipulation.is_move_layer and is_moved_item else 1.0

        # Adjust layout if moving the layer
        if material_layer_manipulation.is_move_layer and is_moved_item:
            layout.split(factor=0.75, align=True)

        self.draw_layer_controls(layout, icon_value, item, group_props)

    def draw_error_layer(self, layout):
        layout.alert = True
        layout.alignment = "LEFT"

        row = layout.row()
        row.label(icon="ERROR")
        row.label(text='Material Layer is faulty!')

class PHILOGIX_UL_LayerChannelItems(UIList):
    def draw_type_icon(self, context, layout, layer_node, icon_value):
        active_object = context.active_object.mode
        img_paint = context.tool_settings.image_paint 
        value_node =  layer_node.node_tree.nodes.get("Value")
        image = getattr(value_node, 'image', None)

        row = layout.row()

        if image:
            row.alert = image.is_dirty
            row.enabled = image.is_dirty
            icon_value = 134 if active_object == 'TEXTURE_PAINT' and img_paint.canvas == image else icon_value
            
        else:
            row.enabled = False
                
        row.label(text='', icon_value=icon_value)

    def draw_hide_icon(self, layout, mix_node):
        layout.prop(mix_node, 'mute', text='', icon_value=(254 - int(mix_node.mute)), emboss=False)

    def draw_layer_name(self, layout):
        layout.prop(self.channel_layer_props, 'name', icon="NONE", emboss=False, text="")

    def draw_clipping_button(self, layout, index):
        row = layout.row()
        row.enabled = index != 0
        operator = row.operator("plx.clipping_layer", text="", icon_value=46 + (int(self.item.parent_layer_id == self.item.ID) * 478), emboss=False)
        operator.item_idx = index

    def draw_error_layer(self, layout):
        layout.alert = True

        row = layout.row()
        row.alignment = "LEFT"
        row.label(icon="ERROR")

        row = layout.row()
        row.alignment = "LEFT"
        row.label(text='Channel Layer is faulty!')


    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        self.item = item

        self.channel_node_group = item.id_data
        channel_layer_node = self.channel_node_group.nodes.get(item.ID)
        blend_node = self.channel_node_group.nodes.get(delimiter_join(item.ID, 'MixLayer'))
        opacity_node = self.channel_node_group.nodes.get(delimiter_join(item.ID, 'MixOpacity'))

        if channel_layer_node and blend_node and opacity_node and hasattr(channel_layer_node, 'node_tree'):
            channel_layer_node_group = channel_layer_node.node_tree
            self.channel_layer_props = channel_layer_node_group.PlxProps

            layers = self.channel_node_group.PlxProps.layers
            layers_index = self.channel_node_group.PlxProps.layers_index
            moved_item = layers[layers_index]
            is_clipping = item.ID != item.parent_layer_id
            is_parent_item = moved_item.ID == item.parent_layer_id
            is_moved_item = not channel_layer_manipulation.is_move_layer or layers_index == index

            is_linked_layer = channel_layer_node_group != bpy.data.node_groups.get(item.ID)
            icon_value = 259 if is_linked_layer else self.channel_layer_props.icon_value

            if channel_layer_manipulation.is_move_layer and (is_moved_item or is_parent_item):
                if is_moved_item: layout.ui_units_y = 1.25
                layout.split(factor=0.5)

            if is_clipping:
                layout.split(factor=0.5)

            row = layout.row(align=True)
            
            self.draw_type_icon(context, row, item.layer_node, icon_value)
            self.draw_hide_icon(row, blend_node)
            self.draw_layer_name(row)
            self.draw_clipping_button(row, index)
        else:
            self.draw_error_layer(layout)


class PHILOGIX_PT_ChannelSetting(Panel):
    bl_label = "Channel Setting"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 12

    def draw(self, context):     
           
        def draw_warking_channels(layout):
            
            layout.label(text="Channel Settings")

            box = None
            
            remove_enabled = len(mat_channels)>2
            
            for channel_name in channel_list.keys():
                if channel_name not in mat_channels or channel_name == 'Layer Mask': continue
                if not box: box = layout.box()

                mat_channel = mat_channels[channel_name]

                row = box.row()

                col = row.column()
                col.label(text = '', icon = mat_channel.icon)

                col = row.column()
                col.label(text = channel_name)
                
                col = row.column()
                col.enabled = remove_enabled
                col.operator("plx.remove_material_channel", text="", icon='REMOVE', emboss=True).name = channel_name

        def draw_not_processed_channels(layout):
            
            layout.label(text="Channels are not processed:")
            
            box = None
            for channel_name, channel_info in channel_list.items():
                
                if channel_name in mat_channels or channel_name == 'Layer Mask': continue

                inp = shader.inputs[channel_name]

                if not box: box = layout.box()

                row = box.row()

                col = row.row()
                col.prop(inp, 'default_value', text=channel_name, emboss=True, slider=True)

                col = row.row()
                add = col.operator("plx.add_material_channel", text="", icon='ADD', emboss=True)
                add.ID = channel_info['ID']
                add.name = channel_name
                add.icon = channel_info['icon'] 
                add.description = channel_info['description']
                add.color_space = channel_info['color_space']       
        
        def draw_material_settings(layout):
            
            box = layout.box()
            
            row = box.row()
            row.label(text='Material Alpha Blend Mode:')
            
            row = box.row()
            row.prop(mat, 'blend_method', text='')
                    
        mat = get_active_material()
        mat_props = mat.PlxProps
        mat_channels = mat_props.channels
        channel_list = get_pbr_channels(mat_props.workflow)

        nodes = mat.node_tree.nodes
        shader = nodes[delimiter_join('Plx', 'Shader')]

        layout = self.layout

        draw_warking_channels(layout)
        draw_not_processed_channels(layout)
        draw_material_settings(layout)

class PHILOGIX_PT_PaintLayer(Panel):
    bl_label = "Paint Layers"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED', "HEADER_LAYOUT_EXPAND"}

    def draw_header(self, context):
        mat = get_active_material()

        row = self.layout.row(align=True)
        row.alignment = "RIGHT"
        row.enabled = is_valid_plx_material(mat)
        row.popover("PHILOGIX_PT_ChannelSetting", text='', icon='PREFERENCES')

    def draw(self, context):
        self.mat = get_active_material()
        is_baking = context.scene.PlxProps.bake_properties.is_baking
        
        self.layout.enabled = not is_baking
        
        if not ui_material_layers.draw_material_layers(self, self.layout):
            return
        
        col = self.layout.column(align=True)

        if not ui_channels.draw_material_layer_channels(self, col):
            return
        
        ui_channel_layers.draw_channel_layers(self, col)
        ui_layer_settings.draw_layer_settings(self, col)

class PHILOGIX_PT_Category(Panel):
    bl_label = "Assets Category"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    layer_group = None
    asset_type_map = {'MATERIAL': 'Materials', 'SURFACE': 'Surfaces', 'IMAGE': 'Brushes'}

    def draw(self, context):
        props = context.scene.PlxProps

        if not self.layer_group:
            self.layer_group = get_context_pointer(context, 'active_layer_group')
            active_asset = get_context_pointer(context, 'active_asset')
            layer_type = self.layer_group.PlxProps.layer_type
            asset_type = self.asset_type_map.get(layer_type, '')

        layout = self.layout
        row = layout.row()
        row.label(text="Assets Category")
        row.operator("plx.add_category", text="New", icon='ADD', emboss=True).asset_type = asset_type

        col = layout.column(align=True)

        for category_key, category_info in AssetCategory.get_category_items(asset_type).items():
            col.separator(factor=0.75 if not category_info else 0.35)

            if not category_info:
                continue

            row = col.row(align=True)
            row.scale_y = 1.1

            if category_key == props.editing_category:
                row.prop(props, "category_name", text="", icon='CURRENT_FILE')

            else:
                depress = active_asset.PlxAssetCategory == category_key
                set_op = row.operator('plx.set_category', text=category_info['name'], depress=depress)
                set_op.asset_type = asset_type
                set_op.category_key = category_key

            if not category_info.get('is_system'):
                for op, icon in [('plx.rename_category', 'CURRENT_FILE'), ('plx.remove_category', 'TRASH')]:
                    operator = row.operator(op, text='', icon=icon)
                    operator.asset_type = asset_type
                    operator.category_key = category_key


classes = (
    PHILOGIX_UL_MaterialLayerItems,
    PHILOGIX_UL_LayerChannelItems,
    PHILOGIX_PT_PaintLayer,
    PHILOGIX_MT_Filter,
    PHILOGIX_MT_Image,
    PHILOGIX_MT_LayersExpandedMenu,
    PHILOGIX_MT_AnchorPointsMenu,
    PHILOGIX_PT_ChannelSetting,
    PHILOGIX_PT_Category,
    PHILOGIX_MT_ImageSource
    )


def plx_layers_menu_func(self, context):

    if hasattr(context, "plx_layers_origin_props"):
        layout = self.layout

        layout.separator()
        layout.label(text="Philogix PBR Painter")
        layout.operator("plx.copy_layer", text="Copy", icon='COPYDOWN')
        layout.operator("plx.copy_multiple_layer", text="Copy Multiple", icon='COPYDOWN')
        layout.operator("plx.paste_layer", text="Paste", icon='PASTEDOWN').is_linked = False
        layout.operator("plx.paste_layer", text="Paste Linked", icon='LINKED').is_linked = True
        layout.operator("plx.make_local_layer", text = "Unlink Layer", icon_value=55)
        layout.operator("plx.duplicated_layer", text="Duplicated", icon='DUPLICATE')


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.UI_MT_list_item_context_menu.append(plx_layers_menu_func)

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    bpy.types.UI_MT_list_item_context_menu.remove(plx_layers_menu_func)
