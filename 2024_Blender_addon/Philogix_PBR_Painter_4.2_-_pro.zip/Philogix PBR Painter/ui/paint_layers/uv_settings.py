import bpy


def draw_uv_settings(self, layout, props):
    uv_settings = self.layer_node_group.PlxProps.uv_settings
    is_projection_layer = self.layer_node_group.PlxProps.layer_type in ['MATERIAL', 'IMAGE', 'SURFACE']
    is_useuv = is_projection_layer and props.uv_extended_settings
    self.projection_layer = self.material_layer if uv_settings.uv_using == 'GENERAL' else self.editing_layer    
    
    box = layout.box()
    box.enabled = is_projection_layer

    draw_header(self, box, props, uv_settings, is_useuv)
    draw_uv_parameters(self, box, is_useuv)


def draw_header(self, layout, props, uv_settings, is_useuv):
    row = layout.row(align=True)

    col = row.column()
    col.prop(props, 'uv_extended_settings', text='', emboss=False, icon_value=4 + int(is_useuv))
    
    col = row.column()
    col.label(text="Using UVs:")
    
    col = row.column()
    col.enabled = self.layer_node_group.PlxProps.layer_type != 'MATERIAL'
    col.prop(uv_settings, 'uv_using', text='')


def draw_uv_parameters(self, layout, is_useuv):
    if not is_useuv:
        return

    mapping_node = self.projection_layer.node_group.nodes.get('Mapping')

    if mapping_node:
        box = layout.box()
        draw_projection(self, box, mapping_node)
        draw_culling(self, box, mapping_node)
        draw_mapping(box, mapping_node)

        box = layout.box()
        draw_effect(box, mapping_node)


def draw_projection(self, layout, mapping_node):
    layer_node_group = self.projection_layer.node_group
    # Create a new row for the UV projection mode settings
    box = layout.box()
    row = box.row()
    
    # Create two columns for the UV projection mode options
    col1 = row.column()
    col2 = row.column()

    uv_settings = layer_node_group.PlxProps.uv_settings
    
    # Display the UV projection mode selection dropdown
    col1.prop(uv_settings, 'uv_projection_mode', text='', icon='GROUP_UVS')
    
    # Enable the second column only when the mode is not 'Global'
    col2.enabled = uv_settings.uv_projection_mode != 'Global'
    
    if uv_settings.uv_projection_mode == 'UV':
        # Adjust the width of the column for better alignment
        col2.scale_x = 0.955
        
        # Display the UV map selection dropdown when in 'UV' mode
        col2.prop_search(mapping_node, "uv_map", bpy.context.object.data, "uv_layers", text='')

    elif uv_settings.uv_projection_mode == 'Decal':
        # Display the move decal operator button when in 'Vector' mode
        move_decal_operator = col2.operator('plx.move_decal', icon='OBJECT_ORIGIN')
        move_decal_operator.layer_group_name = layer_node_group.name

    else:
        # Display the object selection dropdown when in other modes
        col2.prop(mapping_node, 'object', text='')
    
    # Create a new row for the projection and option settings
    row = box.row()
    
    # Create two sub-rows within the main row
    projection_row = row.row()
    
    # Enable the projection row only for certain modes
    projection_row.enabled = uv_settings.uv_projection_mode not in ['UV', 'Decal']
    
    # Display the UV projection type dropdown
    projection_row.prop(uv_settings, 'uv_projection', text='', icon_value=204)
    
    option_row = row.row()
    
    # Enable the option row only when in 'BOX' projection mode
    option_row.enabled = uv_settings.uv_projection == 'BOX'
    
    # Display the blend option slider for 'BOX' projection
    option_row.prop(uv_settings, 'blend', slider=True)

def draw_culling(self, layout, mapping_node):
    layer_node_group = self.projection_layer.node_group
    uv_settings = layer_node_group.PlxProps.uv_settings

    box = layout.box()
    box.enabled = uv_settings.uv_projection_mode not in ['UV', 'Global']

    culling_text = 'Enabled' if mapping_node.culling else 'Disabled'

    row = box.row()
    row.label(text="Culling Projection:")
    row.prop(mapping_node, 'culling', text=culling_text, icon="OBJECT_HIDDEN")

    if not mapping_node.culling:
        return

    row = box.row()

    col = row.column()
    col.label(text="Width:")
    col.prop(mapping_node.inputs['Culling Width'], "default_value", text="")

    col = row.column()
    col.label(text="Height:")
    col.prop(mapping_node.inputs['Culling Height'], "default_value", text="")
    
    col = row.column()
    col.label(text="Depth:")
    col.prop(mapping_node.inputs['Culling Depth'], "default_value", text="")

def draw_mapping(layout, mapping_node):
    box = layout.box()
    row = box.row()
    
    col = row.column()
    col.prop(mapping_node.inputs['Rotation'], "default_value", text='Rotation')
    
    col = row.column()
    col.prop(mapping_node.inputs['Location'], "default_value", text='Location')
    
    col = row.column()
    col.prop(mapping_node.inputs['Scale'], "default_value", text='Scale')

def draw_effect(layout, mapping_node):

    row = layout.row()
    
    row.prop(mapping_node, "uv_effect_type", text = 'Effect')

    if mapping_node.uv_effect_type != 'None':
        if mapping_node.uv_effect_type in ['Blur', 'Warp', 'Shattering']:
            row = layout.row()
            row.prop(mapping_node.inputs['Strength'], "default_value", text='Strength')

        if mapping_node.uv_effect_type in ['Warp', 'Shattering', 'Crystallize']:
            row = layout.row()
            row.prop(mapping_node.inputs['Size'], "default_value", text='Size')

        if mapping_node.uv_effect_type in ['Shattering', 'Crystallize']:
            row = layout.row()
            row.prop(mapping_node.inputs['Exponent'], "default_value", text='Exponent')

        if mapping_node.uv_effect_type == 'Warp':
            row = layout.row()
            row.prop(mapping_node.inputs['Distortion'], "default_value", text='Distortion')
