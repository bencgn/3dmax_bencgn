import bpy 
from ...utils import general_utilities
from ...utils.node_utilities import is_valid_plx_material


def draw_material_layers(self, layout):
    if not is_valid_plx_material(self.mat):
        box = self.layout.box()
        box.label(text = ' Plx Shader not found !', icon_value = 110)
        return False
    
    self.material_layer = self.mat.PlxProps.material_layer
    col = layout.column(align=True)
    draw_layers_control(self, col)
    draw_material_layers_list(self, col)
    return True


def draw_layers_control(self, layout):
    row = layout.row(align=True)

    box = row.box()
    box.alignment = "LEFT"
    draw_add_layer_operators(box)

    box = row.box()
    box.alignment = "CENTER"
    draw_function_operators(self, box)

def draw_material_layers_list(self, layout):
    mat_props = self.mat.PlxProps

    row = layout.row(align=True)
    row.context_pointer_set("plx_layers_origin_props", self.mat.PlxProps)

    row.template_list("PHILOGIX_UL_MaterialLayerItems", "1", mat_props, "layers", mat_props, "layers_index", sort_reverse = True, sort_lock=True, rows = 2)
    

def draw_add_layer_operators(layout):
    row = layout.row()
    row.operator("plx.add_custom", text="", icon_value=125, emboss=False)
    row.operator("plx.add_smart", text="", icon_value=127, emboss=False)

def draw_move_layer_operators(layout):
    
    row = layout.row()
    row.alignment = "CENTER"
    row.scale_x = 0.85

    row.operator("plx.up_layer", text="", icon="TRIA_DOWN", emboss=False)
    row.operator("plx.down_layer", text="", icon="TRIA_UP", emboss=False)

def draw_remove_layer_operators(layout):
    
    row = layout.row()
    row.alignment = "RIGHT"
    
    row.operator("plx.remove_layer", text="", icon="TRASH", emboss=False)

def draw_function_operators(self, layout):
    node_tree = self.mat.node_tree

    shader_node = node_tree.nodes[general_utilities.delimiter_join('Plx', 'Shader')]
    
    col = layout.row()
    col.alignment = "RIGHT"
    col.context_pointer_set("plx_actived_layer", self.material_layer)
    col.context_pointer_set("plx_layers_origin_props", self.mat.PlxProps)

    col.menu("PHILOGIX_MT_LayersExpandedMenu", icon='DOWNARROW_HLT', text="")
    col.operator("plx.up_layer", text="", icon="TRIA_DOWN", emboss=False)
    col.operator("plx.down_layer", text="", icon="TRIA_UP", emboss=False)
    col.operator("plx.remove_layer", text="", icon="TRASH", emboss=False)
    col.prop(shader_node, 'shader_output', text='', icon_value=254)