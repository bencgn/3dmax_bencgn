import bpy

from .uv_settings import draw_uv_settings
from .layer_paraments.ui_layer_parameter import draw_layer_parameters

def draw_layer_settings(self, layout):
    if not self.editing_layer or not self.editing_layer.node_group:
        box = layout.box()
        row = box.row()
        row.label(text = ' No Channel Layer selected !', icon_value = 110)
        return
    
    layout.context_pointer_set("plx_editing_layer", self.editing_layer)

    props = bpy.context.scene.PlxProps
    self.layer_node_group = self.editing_layer.node_group

    is_linked_layer = self.layer_node_group != bpy.data.node_groups.get(self.editing_layer.ID)

    box = layout.box()
    box.active = not is_linked_layer
    box.label(text = f"{self.layer_node_group.PlxProps.name} settings:")

    draw_uv_settings(self, box, props)
    draw_layer_parameters(self, box, props)