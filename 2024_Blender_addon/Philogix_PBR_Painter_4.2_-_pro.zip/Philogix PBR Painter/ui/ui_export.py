import bpy
from bpy.types import Panel

from ..addon.distribution import ExportPresets
from ..core.registration_manager import RegistrationManager
from ..properties.export_properties import PHILOGIX_ChannelOutputImage

from ..utils.general_utilities import delimiter_split
from ..utils.draw_utilities import configure_image_export_ui
from ..utils.file_utilities import generate_export_slot_file_name
from ..utils.object_utilities import get_active_material, get_active_mesh_object

EXPORT_OPERATION_ID = "plx.export" if RegistrationManager().is_pro_version else "plx.trailer_action"

def is_saved_export_preset(props, attrs):
    for attr, value in attrs.items():
        prop = getattr(props , attr, None)
        if prop is None:
            continue

        elif attr == 'slots':
            if len(value) != len(prop):
                return False
            
            for slot_name, slot_attrs in value.items():
                slot = prop.get(slot_name)
                if not slot or not is_saved_export_preset(slot, slot_attrs):
                    return False

        elif attr == 'image_settings' or isinstance(prop, PHILOGIX_ChannelOutputImage):
            if not is_saved_export_preset(prop, value):
                return False

        elif prop != value:
            return False
        
    return True

class PHILOGIX_PT_ExportPresets(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_label = "Export Presets"
    bl_ui_units_x = 12

    def draw(self, context):
        is_system = RegistrationManager().is_dev_version
        preset_items = ExportPresets.get_items()
        export_props = context.scene.PlxProps.export_properties
                
        layout = self.layout

        row = layout.row()
        row.label(text="Export Presets")
        row.operator('plx.new_preset', icon='PRESET_NEW')

        col = layout.column(align=True)
        col.scale_y = 1.15
        for preset_id, preset_info in preset_items.items():
            col.separator(factor=0.35 if preset_info else 0.75)

            if preset_info:
                depress = export_props.id == preset_id
                is_dirty = preset_info.get('is_dirty', False)
                alert = depress and (is_dirty or not is_saved_export_preset(export_props, preset_info['attrs']))
                
                row = col.row(align=True)
                row.alert = alert
                row.operator('plx.load_preset', text=preset_info['name'], depress=not alert and depress).preset_id = preset_id

        col = layout.column(align=True)
        col.label(text='Preset Settings:')

        preset_info = preset_items.get(export_props.id, False)
        enabled = preset_info and (is_system or not preset_info.get('is_system'))

        row = col.row(align=True)
        row.separator(factor=0.5)

        edit_col = row.column()
        edit_col.enabled = enabled
        edit_col.prop(export_props, 'name', text='')

        row.separator(factor=0.5)
        edit_col = row.column()
        edit_col.operator_menu_enum("plx.save_preset", "save_type", text="", icon='DISK_DRIVE')

        row.separator(factor=0.5)
        edit_col = row.column()
        edit_col.enabled = enabled
        edit_col.operator('plx.remove_preset', text='', icon='TRASH')
          
class PHILOGIX_PT_Export(Panel):
    bl_label = "Export texture"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Philogix'
    bl_order = 4
    bl_options = {'DEFAULT_CLOSED', 'HEADER_LAYOUT_EXPAND'}
    
    def draw_export_button(self):
        global EXPORT_OPERATION_ID
        layout = self.layout
        
        row = layout.row()
        row.scale_y = 1.5

        row.operator(EXPORT_OPERATION_ID, text='Export', emboss=True, depress=False, icon_value=126)
        
        layout.separator()

    def draw_general_settings(self, context):
        # Exit early if baking is in progress
        if self.export_props.is_baking:
            return
        
        export_settings = self.export_props
        layout = self.layout
        general_box = layout.box()

        # Toggle button for extending settings and the label
        row = general_box.row()
        icon_value_toggle = 28 + 18 * int(export_settings.setting_extend)
        row.prop(export_settings, 'setting_extend', text='', icon_value=icon_value_toggle, emboss=False)
        row.label(text='General Settings:')

        # Return if settings aren't extended
        if not export_settings.setting_extend:
            return

        column = general_box.column()
        column.use_property_split = True
        column.use_property_decorate = False

        # Basic settings: size, margin, quality, and device
        basic_settings_box = column.box()
        basic_settings_box.label(text='Base')

        basic_settings_box.prop(export_settings, "size", text='Size')
        basic_settings_box.prop(export_settings, "margin", text='Margin')
        basic_settings_box.prop(export_settings, "quality", text='Quality')
        basic_settings_box.prop(export_settings, "device", text='Export Device')

        basic_settings_box.prop_search(export_settings, "uv_layer", self.object.data, 'uv_layers', text='Export UV')

        # Material settings
        material_settings_box = basic_settings_box.box()
        if export_settings.export_type == "ANOTHER":
            material_settings_box.prop(export_settings, "export_type")
            material_settings_box.prop(export_settings, "specified_object")
            material_settings_box.prop(export_settings, "cage_extrusion")
            material_settings_box.prop(export_settings, "max_ray_distance")
        else:
            material_settings_box.prop(export_settings, "export_type")

        column.separator()

        # Output settings: UV and file path
        output_settings_box = column.box()
        output_settings_box.label(text='Output')
        output_settings_box.prop(export_settings, "filepath", text='File path')

        filename_row = output_settings_box.row()
        filename_row.prop(export_settings, "filename")
        filename_row.prop(export_settings, "expressions", text='', icon='HAND', icon_only=True)
        
        layout.separator(factor=0)

    
    def draw_export_slots(self, context):
        
        def draw_add_slot_button(layout):                
            row = layout.row()
            row.label(text='Export Slots:')
            row.operator('plx.add_export', text='Add Export Slot', icon_value=31)
             
        def draw_export_notification(layout):
            row = layout.row()
            row.alignment = 'CENTER'
            row.label(text='Press ESC to cancel', icon='CANCEL')
            
        def draw_export_channel(layout):
            box = layout.box()
            
            row = box.row()
            row.enabled = not self.export_props.is_baking
            
            row.prop(export_slot, 'extend', text='', icon_value = 28+18*int(export_slot.extend), emboss=False)
            if export_slot.is_baking:
                row.label(text = 'Baking... ' + export_slot.name, icon='SORTTIME')
            else:
                row.prop(export_slot, 'name', text='')
                row.prop(export_slot, 'active', text='')
            
            row.operator('plx.remove_export', text='', icon_value=32).index = i
           
        def draw_output_setting(layout, idx):
            if not export_slot.extend: return
            
            box = layout.box()
            box.enabled = export_slot.active
            
            if export_slot.is_baking:
                box.template_running_jobs()
                return
            
            col = box.column()
            col.label(text='Output settings: ', icon='OUTPUT')
            
            row = col.row()
            row.label(text='Type:')
            row.scale_x = 2.1
            row.prop(export_slot, 'output_type', text='')

            col.separator(factor=0.5)

            output_channels = delimiter_split(export_slot.output_type)
            
            row = col.row()
            row.label(text='Channels:')
            
            channel_col = row.column()

            for channel in output_channels:
                channel_image = getattr(export_slot, channel)
                channel_name = f"{channel_image.name.replace('Image_', '')} Map" if channel_image.name.startswith("Image_") else channel_image.name

                channel_row = channel_col.row(align=True)
                channel_row.scale_x = 2

                changer = channel_row.operator_menu_enum("plx.change_output", "output_channel", text=f"{channel}: {channel_name} ({channel_image.color_space})")
                changer.idx = idx
                changer.channel = channel

                channel_row.scale_x = 1
                changer = channel_row.operator_menu_enum("plx.change_output_color_space", "change_output_color_spaces", text='', icon='COLOR')
                changer.idx = idx
                changer.channel = channel

            box.separator(factor=0.1)

                    
        def draw_image_setting(self, layout):
            if not export_slot.extend or self.export_props.is_baking: return

            filename = generate_export_slot_file_name(self.export_props.filename, export_slot.name, self.object, self.material, image_settings.file_format)
            
            box = layout.box()
            box.enabled = export_slot.active
            row = box.row()
            row.label(text='Image Setting: ' + filename, icon='FILE_IMAGE')
                        
            configure_image_export_ui(box, image_settings)
                    
            box.separator(factor=0.1)
                                                
        layout = self.layout
        box = layout.box()
        
        if not self.export_props.is_baking:
            draw_add_slot_button(box)
        else:
            draw_export_notification(box)
        
        for i, export_slot in enumerate(self.export_props.slots):
            image_settings = export_slot.image_settings
            
            col = box.column(align=True)
        
            draw_export_channel(col)
            draw_output_setting(col, i)
            draw_image_setting(self, col)

    def draw_error_box(self, layout, error_message):
        box = layout.box()
        box.label(text=error_message, icon='ERROR')

    def draw_header(self, context):
        layout = self.layout
        layout.label(text = '')

        row = layout.row()
        row.alignment = 'RIGHT'
        row.enabled = hasattr(context.scene, 'cycles')
        
        row.popover("PHILOGIX_PT_ExportPresets", text='', icon='PRESET')
    
    def draw(self, context):
        self.props = context.scene.PlxProps
        self.object = get_active_mesh_object()
        self.material = get_active_material()
        self.export_props = context.scene.PlxProps.export_properties
        
        layout = self.layout        
        
        if not self.object:
            self.draw_error_box(layout, 'Let\'s select a mesh object !')
            return
            
        if not hasattr(context.scene, 'cycles'):
            self.draw_error_box(layout, 'Cycles Engine not found !')
            return

        self.draw_export_button()
        self.draw_general_settings(context)
        self.draw_export_slots(context)
