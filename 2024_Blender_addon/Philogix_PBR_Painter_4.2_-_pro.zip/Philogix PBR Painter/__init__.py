bl_info = {
    "name": "Philogix PBR Painter",
    "description": "",
    "author": "Philogix studio",
    "version": (4, 2),
    "blender": (4, 0, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}

import bpy

from . import properties, addon, nodes, operators, ui
from . import bl_class_registry

def register():
    properties.register()
    addon.register()
    nodes.register()
    operators.register()
    ui.register()
    
    bl_class_registry.BlClassRegistry.register()

def unregister():

    properties.unregister()
    addon.unregister()
    nodes.unregister()
    operators.unregister()
    ui.unregister()

    bl_class_registry.BlClassRegistry.unregister()

if __name__ == "__main__":
    register()