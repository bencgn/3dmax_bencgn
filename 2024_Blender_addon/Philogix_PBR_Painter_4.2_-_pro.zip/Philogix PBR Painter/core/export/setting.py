import bpy, os

from ..udim_manager import UdimManager
from ..serializer.properties_serializer import PropertiesSerializer
from ..bake_manager import MaterialPropertiesManager

from ...utils.general_utilities import delimiter_split
from ...utils.object_utilities import get_active_material, get_active_mesh_object

class ExportSettings:
    def __init__(self, context, properties):
        self.context = context
        self.properties = properties

        self.slots = {}
        self.titles = []
        
        self.active_scene = None
        self.active_uvmap = None
        self.active_object = None
        self.active_material = None
        self.selected_objects = None
        self.specified_object = None

        self.exported_materials = None
        
        self.filepath = None
        self.filename = None
        self.device = None
        self.quality = None
        self.margin = None
        self.uv_layer = None
        self.export_type = None
        self.texture_size = None
        self.cage_extrusion = None
        self.max_ray_distance = None

    def initialize(self):
        SettingsInitializer.base_initialize(self)
        SettingsInitializer.object_initialize(self.context, self)

        self.exported_materials = MaterialInitializer.get_exported_materials(self)

    def validate(self):
        return SettingsInitializer.validate_settings(self)

class SettingsInitializer:
    @classmethod
    def base_initialize(cls, settings: ExportSettings):
        settings.device = settings.properties.device
        settings.quality = settings.properties.quality
        settings.margin = settings.properties.margin
        settings.uv_layer = settings.properties.uv_layer
        settings.texture_size = int(settings.properties.size)

        settings.filepath = settings.properties.filepath
        settings.filename = settings.properties.filename
        settings.export_type = settings.properties.export_type
        settings.cage_extrusion = settings.properties.cage_extrusion
        settings.max_ray_distance = settings.properties.max_ray_distance

        settings.slots = cls.slots_initialize(settings.properties)

    @classmethod
    def object_initialize(cls, context, settings: ExportSettings):
        settings.active_scene = context.scene
        settings.active_object = ObjectInitializer.get_active_ocject()
        settings.active_material = ObjectInitializer.get_active_material()
        settings.active_uvmap = ObjectInitializer.get_uv_layer(settings)
        settings.selected_objects = ObjectInitializer.get_selected_ocject(context, settings)
        settings.specified_object = ObjectInitializer.get_selected_specified_object(settings)

        settings.titles = UdimManager.get_valid_udim_titles(context, settings.active_object, settings.uv_layer)

    @classmethod
    def slots_initialize(cls, properties):
        properties_info = PropertiesSerializer(properties).to_dict()
        return properties_info['slots']

    @classmethod
    def validate_settings(cls, settings: ExportSettings):
        filepath = bpy.path.abspath(settings.filepath)

        export_type = settings.export_type
        specified_uvmap = settings.uv_layer

        if not os.path.exists(filepath):
            return 'ERROR', 'Path not found!'
        
        if export_type == 'ANOTHER' and not settings.specified_object:
                return 'ERROR', 'No specified object found!'

        if export_type in ['ACTIVE', 'ANOTHER']:
            if not settings.active_material or not settings.active_material.use_nodes:
                return 'ERROR', 'No active materials found!'     
            
        if export_type == 'OBJECTS' and settings.selected_objects:
            mismatched_transforms = any(
                obj.scale != (1.0, 1.0, 1.0) or 
                obj.location != (0.0, 0.0, 0.0) or 
                obj.rotation_euler != (0.0, 0.0, 0.0) 
                for obj in settings.selected_objects
            )
            if mismatched_transforms:
                return 'WARNING', 'Objects with mismatched Transforms may alter the textures when exporting Maps!'
            
        if settings.exported_materials and len(settings.exported_materials) == 0:
            return 'ERROR', 'No materials found!'
        
        if specified_uvmap and specified_uvmap not in settings.active_object.data.uv_layers:
            return 'ERROR', 'No UVMap found!'

        for slot_name, slot in settings.slots.items():
            for channel_output in delimiter_split(slot['output_type']):
                if not slot[channel_output]['bake_type']:
                    return 'ERROR', f'Slot "{slot_name}" lacks a selected channel!'
            
        return 'NONE', None

class MaterialInitializer:    
    @classmethod
    def get_exported_materials(cls, settings: ExportSettings):        
        if settings.export_type is None:
            return
        
        elif settings.export_type == "OBJECTS":
            collected_objects = settings.selected_objects

        elif settings.export_type == "ANOTHER" and settings.specified_object:
            collected_objects = [settings.specified_object]

        else:
            collected_objects = [settings.active_object]

        active_material = settings.active_material
        exported_materials = cls.collect_exported_materials(collected_objects)
        exported_materials[active_material] = MaterialPropertiesManager.get_material_properties(active_material)

        return exported_materials

    @classmethod
    def collect_exported_materials(cls, objects):
        all_materials = []
        export_materials = {}

        for obj in objects:
            for mat_slot in obj.material_slots:
                if mat_slot.material and mat_slot.material not in all_materials:
                    all_materials.append(mat_slot.material)
        
        for material in all_materials:
            if material not in export_materials:
                export_materials[material] = MaterialPropertiesManager.get_material_properties(material)

        return export_materials

class ObjectInitializer:
    @classmethod
    def get_uv_layer(cls, settings):
        object_uv_layers = settings.active_object.data.uv_layers
        return object_uv_layers.get(settings.uv_layer) or object_uv_layers.active

    @classmethod
    def get_active_material(cls):
        return get_active_material()
    
    @classmethod
    def get_active_ocject(cls):
        return get_active_mesh_object()
    
    @classmethod
    def get_selected_ocject(cls, context, settings: ExportSettings):
        return [obj for obj in context.selected_objects if obj != settings.active_object]
    
    @classmethod
    def get_selected_specified_object(cls, settings: ExportSettings):
        if settings.export_type == 'ANOTHER':
            return settings.properties.specified_object