import bpy, os, random
from mathutils import Color
from fractions import Fraction as F

from .setting import ExportSettings
from ..image_manager import ImageManager
from ..bake_manager import BakeTempDatas, MaterialPropertiesManager

from ...utils.file_utilities import generate_export_slot_file_name
from ...utils.general_utilities import delimiter_join, delimiter_split, make_uid, print_message, MessageType

class ExportConfig:
    def __init__(self, context, settings: ExportSettings):
        self.id = make_uid(5)
        self.context = context
        self.settings = settings

        self.export_mesh = None
        self.bake_scene = None
        self.compositor_scene = None

        self.output_images = {}
        self.temp_datas = BakeTempDatas()

    def configure(self):
        SceneConfigurator.configure_export_scene(self)
        SceneConfigurator.configure_compositor_scene(self)
        ObjectConfigurator.configure_export_object(self)
        ImageConfigurator.configure_output_images(self)
        MaterialConfigurator.configure_exported_materials(self)

    def deconfigure(self):
        MaterialConfigurator.deconfigure_materials(self.settings)
        SceneConfigurator.deconfigure_scene(self.context, self.settings)
        
    def clear_temps(self):
        self.temp_datas.clear()

    def export_channel_configure(self, material, slot_name, bake_image):
        if not material.use_nodes:
            return
        node_tree = material.node_tree
        SceneConfigurator.configure_export_slot(self, slot_name, bake_image)
        NodeConfigurator.shader_node_setup(node_tree, bake_image)
        NodeConfigurator.export_node_setup(node_tree, bake_image)

    def combine_slot_configure(self, output_image_info):
        image_settings = output_image_info['image_settings']
        channel_images = output_image_info['channel_images']
        CompositorConfigurator.image_settings(self, image_settings)
        CompositorConfigurator.nodes_setup(self, channel_images)

    def save_filepath_configure(self, slot_name, output_image_info, tile_number=None):
        image_settings = output_image_info['image_settings']
        CompositorConfigurator.filepath_settings(self, slot_name, image_settings, tile_number)


class ExportOutputImage:
    def __init__(self):
        image = None
        bake_type = None
        color_space = None
        shader_output = None
        normal_format = None
        composite_channels = None

class SceneConfigurator:
    @classmethod
    def configure_render(cls, scene, settings: ExportSettings):
        render = scene.render
        render.engine = 'CYCLES'
        render.use_border = False
        render.bake.use_clear = False
        render.resolution_percentage = 100
        render.bake.target = 'IMAGE_TEXTURES'
        render.bake.margin_type = 'EXTEND'
        
        render.bake.normal_space = 'TANGENT'
        render.bake.normal_r = 'POS_X'
        render.bake.normal_b = 'POS_Z'

        render.bake.margin = settings.margin
        render.bake.cage_extrusion = settings.cage_extrusion
        render.bake.max_ray_distance = settings.max_ray_distance
        render.bake.use_selected_to_active = settings.specified_object is not None

    @classmethod
    def configure_export_scene(cls, config: ExportConfig):
        settings = config.settings
        bpy.ops.scene.new(type='EMPTY')

        scene = config.context.scene
        scene.name = f"Plx_Temp_{config.id}_Export"
        scene.cycles.use_denoising = False
        scene.cycles.device = settings.device
        scene.PlxProps.export_properties.is_baking = True

        cls.configure_render(scene, settings)

        config.bake_scene = scene
        config.context.window.scene = scene
        config.temp_datas.add(scene)
    
    @classmethod
    def configure_compositor_scene(cls, config: ExportConfig):
        size = config.settings.texture_size
        scene = bpy.data.scenes.new(f"Plx_Temp_{config.id}_Compositor")
        
        scene.use_nodes = True
        scene.cycles.samples = 2
        scene.render.resolution_x = size
        scene.render.resolution_y = size
        scene.render.resolution_percentage = 100
        scene.view_settings.view_transform = 'Raw'

        
        config.compositor_scene = scene
        config.temp_datas.add(scene)

    @classmethod
    def deconfigure_scene(self, context, settings):
        context.window.scene = settings.active_scene

    @classmethod
    def configure_export_slot(cls, config, slot_name, bake_image):
        scene = config.bake_scene
        
        quality = (int(bake_image.bake_type == 'EMIT') + 2) * config.settings.quality
        scene.cycles.samples = round(quality)
        scene.render.bake.normal_g = bake_image.normal_format

        slots = scene.PlxProps.export_properties.slots
        slots[slot_name].is_baking = True
        slots[slot_name].extend = True

class ObjectConfigurator:
    @classmethod
    def configure_export_object(cls, config: ExportConfig):
        context = config.context
        settings = config.settings

        if settings.specified_object:
            settings.specified_object = settings.specified_object.copy()
            config.bake_scene.collection.objects.link(settings.specified_object)
            settings.specified_object.name = f"Plx_Temp_{config.id}_Specified"

        if settings.export_type == "OBJECTS":
            export_object = cls.create_combined_mesh_from_selected(context, settings)
        else:
            export_object = settings.active_object.copy()
            export_object.data = export_object.data.copy()
            config.bake_scene.collection.objects.link(export_object)
            
        config.export_mesh = export_object.data
        
        bpy.ops.object.select_all(action='SELECT')
        context.view_layer.objects.active = export_object
        settings.export_object = export_object

        if settings.export_type != "ANOTHER":
            export_object.data.use_auto_smooth = False
        
        uv_layer = export_object.data.uv_layers.get(settings.uv_layer)

        export_object.data.uv_layers.active = uv_layer
        context.view_layer.objects.active = export_object

        export_object.name = f"Plx_Temp_{config.id}_Export"
        export_object.data.name = f"Plx_Temp_{config.id}_Export"

        config.temp_datas.add(export_object.data)
        config.temp_datas.add([export_object, settings.specified_object])

    @classmethod
    def create_combined_mesh_from_selected(cls, context, settings):
        active_object = settings.active_object
        selected_objects = settings.selected_objects

        export_object = active_object.copy()
        export_object.data = export_object.data.copy()

        context.collection.objects.link(export_object)
        context.view_layer.objects.active = export_object

        for obj in selected_objects:
            if obj.type == 'MESH' and obj != active_object:
                dup_obj = obj.copy()
                context.collection.objects.link(dup_obj)

        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.join()

        return context.active_object

class NodeConfigurator:
    @classmethod
    def shader_node_setup(cls, node_tree, bake_image):            
        shader_node = node_tree.nodes.get(delimiter_join('Plx', 'Shader'))
        if shader_node:
            try:
                shader_node.shader_output = bake_image.shader_output
            except Exception as e:
                shader_node.shader_output = 'Material'
                print_message(str(e), MessageType.WARNING)

    @classmethod
    def export_node_setup(cls, node_tree, bake_image):
        image_node_name = delimiter_join('Plx', 'Image_Export')
        image_node = node_tree.nodes.get(image_node_name)
        
        if not image_node:
            image_node = node_tree.nodes.new(type="ShaderNodeTexImage")
            image_node.name = image_node_name

        image_node.image = bake_image.image
        node_tree.nodes.active = image_node

class ImageConfigurator:
    @classmethod
    def create_slot_image(cls, context, settings, image_name, color_space):
        image = ImageManager.new(context, image_name, settings.texture_size, settings.texture_size, tiles=settings.titles)
        image.colorspace_settings.name = color_space
        return image
    
    @classmethod
    def get_composite_channels(cls, channels_color):
        channels_mapping = {
            "Alpha": [['Image', 'A']],
            "RGB": [['R', 'R'], ['G', 'G'], ['B', 'B']],
            "Red": [['Image', 'R']],
            "Green": [['Image', 'G']],
            "Blue": [['Image', 'B']]
        }

        return channels_mapping.get(channels_color)
        
    @classmethod
    def configure_output_images(cls, config: ExportConfig):
        context = config.context
        settings = config.settings

        for slot_name, slot_info in settings.slots.items():
            channels_colors_list = delimiter_split(slot_info['output_type'])
            channel_images = []

            for channels_color in channels_colors_list:
                channel_setting = slot_info[channels_color]
                if channel_setting:
                    channel_image = cls.create_slot_image(context, settings, f"Plx_Temp_{config.id}_{slot_name}.{channels_color}", channel_setting['color_space'])
                    
                    bake_image = ExportOutputImage()
                    bake_image.image = channel_image
                    bake_image.bake_type = channel_setting['bake_type']
                    bake_image.color_space = channel_setting['color_space']
                    bake_image.shader_output = channel_setting['shader_output']
                    bake_image.normal_format = channel_setting['normal_format']
                    bake_image.composite_channels = cls.get_composite_channels(channels_color)

                    channel_images += [bake_image]
                    config.temp_datas.add(channel_image)

            config.output_images[slot_name] = {
                'channel_images': channel_images,
                'image_settings': slot_info['image_settings']
                }

class MaterialConfigurator:
    @classmethod
    def configure_exported_materials(cls, config):
        settings = config.settings
        settings.exported_materials = {}
        active_object = settings.active_object
        active_material = settings.active_material
        specified_object = settings.specified_object
        selected_objects = settings.selected_objects
            
        if settings.export_type == "OBJECTS":
            collected_objects = selected_objects
        elif settings.export_type == "ANOTHER" and specified_object:
            collected_objects = [specified_object]
        else:
            collected_objects = [active_object]

        settings.exported_materials = cls.collect_exported_materials(collected_objects)
        settings.exported_materials[active_material] = cls.get_material_info(active_material)

    @classmethod
    def deconfigure_materials(cls, settings):
        for material, material_info in settings.exported_materials.items():
            MaterialPropertiesManager.set_material_properties(material, material_info)

    @classmethod
    def collect_exported_materials(cls, objects):
        all_materials = []
        export_materials = {}

        for obj in objects:
            for mat_slot in obj.material_slots:
                if mat_slot.material and mat_slot.material not in all_materials:
                    all_materials.append(mat_slot.material)
        
        for material in all_materials:
            if material not in export_materials:
                export_materials[material] = cls.get_material_info(material)

        return export_materials
    
    @classmethod
    def get_material_info(cls, material):
        if not (material and material.use_nodes):
            return None
        
        shader_node = material.node_tree.nodes.get(delimiter_join('Plx', 'Shader'))
        shader_output = shader_node.shader_output if shader_node else None
        return {'use_nodes': material.use_nodes,
                'shader_output': shader_output}
    
class CompositorConfigurator:
    @classmethod
    def image_settings(cls, config, image_settings):
        scene = config.compositor_scene
        scene_image_settings = scene.render.image_settings
        scene_image_settings.file_format = image_settings['file_format']
        
        for attr in image_settings.items():
            if hasattr(scene_image_settings, attr[0]):
                try:
                    setattr(scene_image_settings, attr[0], attr[1])
                except Exception as e:
                    print_message(str(e))

    @classmethod
    def filepath_settings(cls, config, slot_name, image_settings, tile_number):
        scene = config.compositor_scene

        object = config.settings.active_object
        file_name = config.settings.filename
        file_path = config.settings.filepath
        material = config.settings.active_material
        file_format = image_settings['file_format']
        filename = generate_export_slot_file_name(file_name, slot_name, object, material, file_format, tile_number)
        
        scene.render.filepath = os.path.join(file_path, filename)

    @classmethod
    def nodes_setup(cls, config, channel_images):
        scene = config.compositor_scene
        node_tree = scene.node_tree
        node_tree.nodes.clear()
        
        combiner = node_tree.nodes.new("CompositorNodeCombRGBA") 
        compositer = node_tree.nodes.new("CompositorNodeComposite")
        
        node_tree.links.new(combiner.outputs['Image'], compositer.inputs['Image'])
                        
        for channel_image in channel_images:
            if not channel_image.image: 
                continue

            if channel_image.image.is_dirty: 
                channel_image.image.pack()
            channel_image.image.colorspace_settings.name = 'Non-Color'

            image_node = node_tree.nodes.new("CompositorNodeImage")
            separater_node = node_tree.nodes.new("CompositorNodeSepRGBA")
            
            image_node.image = channel_image.image
            
            node_tree.links.new(image_node.outputs['Image'], separater_node.inputs['Image'])
            
            for composite_channel in channel_image.composite_channels:

                if composite_channel[0] in image_node.outputs:
                    out_socket = image_node.outputs[composite_channel[0]]
                else:
                    out_socket = separater_node.outputs[composite_channel[0]]
                    
                inp_socket = combiner.inputs[composite_channel[1]]
                
                node_tree.links.new(out_socket, inp_socket)
