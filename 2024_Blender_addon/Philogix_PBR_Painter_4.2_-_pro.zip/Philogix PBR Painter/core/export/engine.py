import bpy
from .config import ExportConfig
from .setting import ExportSettings
from ..bake_manager import BakeHandlers

from ...utils.general_utilities import print_message, MessageType

class ExportEngine:
    def __init__(self, context, properties):
        self.handlers = BakeHandlers()
        self.settings = ExportSettings(context, properties)
        self.config = ExportConfig(context, self.settings)

    def initialize(self):
        self.settings.initialize()
        return self.settings.validate()

    def processing(self):
        self.config.configure()

        for export_name, slot_image_info in self.config.output_images.items():
            channel_images = slot_image_info['channel_images']
            for channel_image in channel_images:            
                if self.handlers.status == 'canceled':
                    yield 'done'
                else:
                    yield from ExportProcessing.bake_texture(self, export_name, channel_image)
            ExportProcessing.save_texture(self, export_name, slot_image_info)
        yield 'done'

    def wait_for_completion(self, callback):
        if bpy.app.is_job_running('OBJECT_BAKE'):
            print_message('Waitting bake completed!', MessageType.INFO)
            return 0.25
        callback()
        return None
    
    def completion(self, context, event):        
        self.config.deconfigure()
        self.handlers.bake_cancel_handler(context, event)

class ExportProcessing:
    @staticmethod
    def bake_texture(bake_engine: ExportEngine, slot_name, channel_image):
        active_material = bake_engine.settings.active_material
        exported_materials = bake_engine.settings.exported_materials
        is_active_material_check = bake_engine.settings.export_type == 'ACTIVE'
        
        for mat, use_nodes in exported_materials.items():
            mat.use_nodes = mat == active_material or (use_nodes and not is_active_material_check)
            bake_engine.config.export_channel_configure(mat, slot_name, channel_image)

        while bpy.ops.object.bake('INVOKE_DEFAULT', type=channel_image.bake_type, pass_filter={'COLOR'}) != {'RUNNING_MODAL'}:
            yield 'waitting'

        while not channel_image.image.is_dirty or bpy.app.is_job_running('OBJECT_BAKE'):
            yield 'baking'

    @staticmethod
    def save_texture(bake_engine: ExportEngine, slot_name, slot_image_info):
        channel_images = slot_image_info['channel_images']
        bake_engine.config.combine_slot_configure(slot_image_info)

        if len(bake_engine.settings.titles)==1 and 1001 in bake_engine.settings.titles:
            bake_engine.config.save_filepath_configure(slot_name, slot_image_info)
            bpy.ops.render.render(write_still=True, scene=bake_engine.config.compositor_scene.name)
        else:
            for tile_number in bake_engine.settings.titles:
                bake_engine.config.save_filepath_configure(slot_name, slot_image_info, tile_number)
                bpy.ops.render.render(write_still=True, scene=bake_engine.config.compositor_scene.name)
                for channel_image in channel_images:
                    tile = channel_image.image.tiles.get(tile_number)
                    channel_image.image.tiles.remove(tile)