import bpy, time
from .config import BakeConfig
from .setting import BakeSettings
from ..bake_manager import BakeHandlers

from ...utils.general_utilities import print_message, MessageType

class BakeEngine:
    def __init__(self, context, properties):
        self.handlers = BakeHandlers()
        self.settings = BakeSettings(context, properties)
        self.config = BakeConfig(context, self.settings)

    def initialize(self):
        self.settings.initialize()
        return self.settings.validate()
    
    def processing(self):
        self.config.configure()
        for slot_name, slot_info in self.config.bake_slots.items():
            if self.handlers.status == 'canceled':
                yield 'done'
            else:
                yield from BakeProcessing.bake_texture(self, slot_name, slot_info)
                BakeProcessing.save_texture(self, slot_name, slot_info)
        yield 'done'

    def wait_for_completion(self, callback):
        if bpy.app.is_job_running('OBJECT_BAKE'):
            print_message("Waitting bake completed!", MessageType.INFO)
            return 0.25
        callback()
        return None

    def completion(self, context, event):        
        self.config.deconfigure()
        self.handlers.bake_cancel_handler(context, event)

class BakeProcessing:
    @staticmethod
    def bake_texture(bake_engine: BakeEngine, slot_name, slot_info):
        bake_engine.config.bake_slot_configure(slot_name, slot_info)

        image = slot_info['image']
        settings = slot_info['settings']
        
        while bpy.ops.object.bake('INVOKE_DEFAULT', type=settings['bake_type']) != {'RUNNING_MODAL'}:
            yield 'waitting'

        while not image.is_dirty or bpy.app.is_job_running('OBJECT_BAKE'):
            yield 'baking'
                                
    @staticmethod
    def save_texture(bake_engine: BakeEngine, slot_name, slot_info):
        properties = bake_engine.config.bake_scene.PlxProps.bake_properties
        properties.slots[slot_name].baking_status = 'done'
        image = slot_info['image']
        image.pack()
