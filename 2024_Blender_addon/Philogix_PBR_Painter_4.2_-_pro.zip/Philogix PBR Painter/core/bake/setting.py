import bpy, os

from ..udim_manager import UdimManager
from ..serializer.properties_serializer import PropertiesSerializer
from ..bake_manager import MaterialPropertiesManager

from ...utils.object_utilities import get_active_material, get_active_mesh_object

class BakeSettings:
    def __init__(self, context, properties):
        self.context = context
        self.properties = properties

        self.slots = {}
        
        self.active_scene = None
        self.active_uvmap = None
        self.active_object = None
        self.active_material = None
        self.specified_object = None
        self.use_auto_smooth = None

        self.active_object_materials = None
        self.specified_object_materials = None
        
        self.filepath = None
        self.filename = None
        self.device = None
        self.quality = None
        self.margin = None
        self.uv_layer = None
        self.export_type = None

        self.user_high = None
        self.cage_extrusion = None
        self.max_ray_distance = None

    def initialize(self):
        SettingsInitializer.base_initialize(self)
        SettingsInitializer.object_initialize(self.context, self)

        self.active_object_materials = MaterialInitializer.get_object_materials(self.active_object)
        self.specified_object_materials = MaterialInitializer.get_object_materials(self.specified_object)

    def validate(self):
        return SettingsInitializer.validate_settings(self)

class SettingsInitializer:
    @classmethod
    def base_initialize(cls, settings: BakeSettings):
        settings.device = settings.properties.device
        settings.quality = settings.properties.quality
        settings.margin = settings.properties.margin
        settings.user_high = settings.properties.user_high
        settings.cage_extrusion = settings.properties.cage_extrusion
        settings.max_ray_distance = settings.properties.max_ray_distance

        settings.slots = cls.slots_initialize(settings.properties)

    @classmethod
    def object_initialize(cls, context, settings: BakeSettings):
        settings.active_scene = context.scene
        settings.active_object = ObjectInitializer.get_active_ocject()
        settings.active_material = ObjectInitializer.get_active_material()
        settings.uv_layer = ObjectInitializer.get_uv_layer(settings)
        settings.active_uvmap = settings.active_object.data.uv_layers.active
        settings.specified_object = ObjectInitializer.get_selected_specified_object(settings)
        settings.use_auto_smooth = settings.active_object.data.use_auto_smooth

    @classmethod
    def slots_initialize(cls, properties):
        properties_info = PropertiesSerializer(properties).to_dict()
        return properties_info['slots']

    @classmethod
    def validate_settings(self, settings):
        if not settings.uv_layer:
            self.report({'OPERATOR'}, "Can't find active uv map!")
            return False
        return True

class MaterialInitializer:
    @classmethod
    def get_object_materials(cls, object):
        if not object: 
            return
        return {slot.material: MaterialPropertiesManager.get_material_properties(slot.material) for slot in object.material_slots}

class ObjectInitializer:
    @classmethod
    def get_uv_layer(cls, settings):
        object_uv_layers = settings.active_object.data.uv_layers
        return object_uv_layers.get(settings.active_object.data.PlxProps.bake_uvmap) or object_uv_layers.active

    @classmethod
    def get_active_material(cls):
        return get_active_material()
    
    @classmethod
    def get_active_ocject(cls):
        return get_active_mesh_object()
    
    @classmethod
    def get_selected_specified_object(cls, settings: BakeSettings):
        if settings.user_high:
            return settings.properties.specified_object
        
    