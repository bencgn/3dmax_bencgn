import bpy, os, random
from mathutils import Color
from fractions import Fraction

from .setting import BakeSettings
from ..bake_manager import BakeTempDatas, MaterialPropertiesManager

from ...utils.general_utilities import delimiter_join, make_uid

class BakeConfig:
    def __init__(self, context, settings: BakeSettings):
        self.id = make_uid(5)
        self.context = context
        self.settings = settings

        self.bake_scene = None
        self.lowmesh = None
        self.highmesh = None

        self.vertex_layer = None
        self.vertex_layer_name = None

        self.bake_slots = {}
        self.temp_datas = BakeTempDatas()

    def configure(self):
        ImagesConfigurator.configure(self)
        SceneConfigurator.configure(self)
        ObjectConfigurator.configure(self)
        MaterialsConfigurator.configure(self)
        SlotsConfigurator.configure(self)

    def deconfigure(self):
        VertexColorConfigurator.deconfigure(self)
        MaterialsConfigurator.deconfigure(self)
        ObjectConfigurator.deconfigure(self)
        SceneConfigurator.deconfigure(self)

    def clear_temps(self):
        self.temp_datas.clear()

    def bake_slot_configure(self, slot_name, slot_info):
        node_tree = self.settings.active_material.node_tree
        SceneConfigurator.configure_slot(self, slot_name, slot_info)
        NodeConfigurator.bake_node_setup(self, node_tree, slot_name, slot_info)
        NodeConfigurator.shader_node_setup(self, node_tree, slot_name, slot_info)

class SceneConfigurator:
    @classmethod
    def configure_render(cls, scene, settings: BakeSettings):
        render = scene.render
        render.engine = 'CYCLES'
        render.use_border = False
        render.bake.use_clear = False
        render.resolution_percentage = 100
        render.bake.target = 'IMAGE_TEXTURES'
        render.bake.margin_type = 'EXTEND'

        
        render.bake.normal_space = 'TANGENT'
        render.bake.normal_r = 'POS_X'
        render.bake.normal_b = 'POS_Z'

        render.bake.margin = settings.margin
        render.bake.cage_extrusion = settings.cage_extrusion
        render.bake.max_ray_distance = settings.max_ray_distance
        render.bake.use_selected_to_active = settings.specified_object is not None

    @classmethod
    def configure(cls, config: BakeConfig):
        scene = bpy.data.scenes.new(f"Plx_Temp_{config.id}_Bake")
        scene.cycles.use_denoising = False
        scene.PlxProps.bake_properties.is_baking = True

        cls.configure_render(scene, config.settings)
        
        config.bake_scene = scene
        config.context.window.scene = scene
        config.temp_datas.add(scene)

    @classmethod
    def configure_slot(cls, config, slot_name, slot_info):
        scene = config.bake_scene   
        settings = config.settings
        slot_settings = slot_info['settings']

        is_curvature = (slot_name == 'Curvature')
        quality = round(settings.quality*slot_settings['coefficient'])

        scene.cycles.samples = quality
        scene.cycles.device = 'CPU' if is_curvature else settings.device
        scene.cycles.shading_system = is_curvature
        scene.render.bake.normal_g = slot_settings['normal_format']

        slots = scene.PlxProps.bake_properties.slots
        slots[slot_name].baking_status = 'baking'
        
    @classmethod
    def deconfigure(cls, config: BakeConfig):
        config.context.window.scene = config.settings.active_scene

class ObjectConfigurator:
    @classmethod
    def configure(cls, config: BakeConfig):
        cls.configure_lowmesh(config)
        cls.configure_highmesh(config)

    @classmethod
    def deconfigure(cls, config: BakeConfig):
        settings = config.settings
        active_object = settings.active_object
        active_object.data.use_auto_smooth = settings.use_auto_smooth
        uv_layer = active_object.data.uv_layers.get(settings.active_uvmap.name)
        if uv_layer:
            uv_layer.active = True
    
    @classmethod
    def configure_lowmesh(cls, config: BakeConfig):
        scene = config.bake_scene
        settings = config.settings
        active_object = settings.active_object

        lowmesh = bpy.data.objects.new(f"Plx_Temp_{config.id}_LowMesh", active_object.data)

        if settings.use_auto_smooth:
            edge_split = lowmesh.modifiers.new('EdgeSplit', 'EDGE_SPLIT')
            edge_split.use_edge_angle = False
            lowmesh.data.use_auto_smooth = False

        uv_layer = lowmesh.data.uv_layers.get(settings.uv_layer.name)
        if uv_layer: 
            uv_layer.active = True
        
        lowmesh.scale = active_object.scale
        lowmesh.location = active_object.location
        lowmesh.rotation_mode = active_object.rotation_mode
        lowmesh.rotation_euler = active_object.rotation_euler
        lowmesh.rotation_quaternion = active_object.rotation_quaternion
        lowmesh.rotation_axis_angle = active_object.rotation_axis_angle

        scene.collection.objects.link(lowmesh)
        lowmesh.select_set(True)
        lowmesh.hide_set(False)
        lowmesh.select_set(True)
        config.context.view_layer.objects.active = lowmesh
        lowmesh.hide_render = False

        config.lowmesh = lowmesh
        config.temp_datas.add(lowmesh)

    @classmethod
    def configure_highmesh(cls, config: BakeConfig):
        settings = config.settings

        if not settings.specified_object:
            return
        
        scene = config.bake_scene
        specified_object = settings.specified_object
        highmesh = bpy.data.objects.new(f"Plx_Temp_{config.id}_HighMesh", specified_object.data)
        highmesh.scale = specified_object.scale
        highmesh.location = specified_object.location
        highmesh.rotation_mode = specified_object.rotation_mode
        highmesh.rotation_euler = specified_object.rotation_euler
        highmesh.rotation_quaternion = specified_object.rotation_quaternion
        highmesh.rotation_axis_angle = specified_object.rotation_axis_angle

        scene.collection.objects.link(highmesh)
        highmesh.select_set(True)
        highmesh.hide_set(False)
        highmesh.select_set(True)
        highmesh.hide_render = False
        
        config.highmesh = highmesh
        config.temp_datas.add(highmesh)

class NodeConfigurator:
    @classmethod
    def bake_node_setup(cls, config: BakeConfig, node_tree, slot_name, slot_info):
        bake_node = node_tree.nodes.get(delimiter_join('Plx', f'Image_{slot_name}'))

        if not bake_node:
            bake_node = node_tree.nodes.new(type="ShaderNodeTexImage")
            bake_node.name = delimiter_join('Plx', f'Image_{slot_name}')

        bake_node.image = slot_info['image']
        node_tree.nodes.active = bake_node

    @classmethod
    def shader_node_setup(cls, config: BakeConfig, node_tree, slot_name, slot_info):       
        settings = config.settings      
        slot_settings = slot_info['settings']
        shader_node = node_tree.nodes.get(delimiter_join('Plx', 'Shader'))

        if not shader_node:
            return
        
        shader_node.bake_output = slot_name
        shader_node.bake_distance = slot_settings['radius']
        shader_node.apply_bevel = slot_settings['apply_bevel']

        if slot_name == 'ID':
            VertexColorConfigurator.configure(config, slot_info)
            shader_node.vertex_name = config.vertex_layer_name
  
class ImagesConfigurator:
    @classmethod
    def configure(cls, config: BakeConfig):
        settings = config.settings
        active_object = settings.active_object
        bake_images = active_object.data.PlxProps.bake_images
        
        for slot_name, slot_info in settings.slots.items():
            bake_image = bake_images.get(slot_name)
            image = bake_image.image
            if image.is_dirty: image.pack()
            config.bake_slots[slot_name] = {
                'image': image,
                'settings': slot_info
                }

class SlotsConfigurator:
    @classmethod
    def configure(cls, config: BakeConfig):
        settings = config.settings
        slots = config.bake_scene.PlxProps.bake_properties.slots
        
        for slot_name, slot_info in settings.slots.items():
            bake_slot = slots.add()
            bake_slot.name = slot_name

class MaterialsConfigurator:
    @classmethod
    def configure(cls, config: BakeConfig):
        cls.configure_low_mesh_materials(config)
        cls.configure_high_mesh_materials(config)

    @classmethod
    def configure_low_mesh_materials(cls, config: BakeConfig):
        active_material = config.settings.active_material
        materials = config.settings.active_object_materials
        
        for material in materials:            
            material.use_nodes = (material == active_material)

    @classmethod
    def configure_high_mesh_materials(cls, config: BakeConfig):
        if not config.highmesh: 
            return
        
        active_material = config.settings.active_material
        
        if len(config.highmesh.material_slots)==0:
            config.highmesh.data.materials.append(active_material)
            return
        
        for material_slot in config.highmesh.material_slots:
            material_slot.material = active_material

    @classmethod
    def deconfigure(cls, config: BakeConfig):
        for material, material_info in config.settings.active_object_materials.items():
            MaterialPropertiesManager.set_material_properties(material, material_info)

        if config.settings.specified_object:
            config.settings.specified_object.data.materials.clear()
            for material, material_info in config.settings.specified_object_materials.items():
                config.settings.specified_object.data.materials.append(material)
                MaterialPropertiesManager.set_material_properties(material, material_info)
          
class VertexColorConfigurator:
    @classmethod
    def get_color_id(cls, count):
        colorList = []
        color = Color()

        hueColorList = []
        hueColor = -Fraction(1, 3)
        colorStep = Fraction(1, 3)
        colorUnit = Fraction(1, 3)

        for i in range(count):
            saturation = random.uniform(0.5, 1)
            value = random.uniform(0.5, 1)
            hueColor += colorStep

            if hueColor in hueColorList or hueColor>=Fraction(1, 1):
                colorStep = colorUnit
                colorUnit = colorUnit/2
                hueColor = colorUnit

            color.hsv = hueColor, saturation, value
            hueColorList.append(hueColor)
            colorList.append((color[0], color[1], color[2], 1))
            
        return colorList

    @classmethod
    def setup_vertex_color_id_element(cls, context, object):
        import bmesh
        prev_mode = object.mode

        object.hide_set(False)
        context.view_layer.objects.active = object

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')

        object.data.vertex_colors.active = object.data.vertex_colors.new()
        bm = bmesh.from_edit_mesh(object.data)
        colorLayer = bm.loops.layers.color.active

        # Collect elements
        groups = []
        processed = set([])

        for face in bm.faces:
            if face not in processed:
                bpy.ops.mesh.select_all(action='DESELECT')
                face.select = True
                bpy.ops.mesh.select_linked(delimit={'NORMAL'})
                linked = [face for face in bm.faces if face.select]

                for link in linked:
                    processed.add(link)
                groups.append(linked)

        # Color each group
        colorList = cls.get_color_id(len(groups))

        for i, color in enumerate(colorList):
            for face in groups[i]:
                for loop in face.loops:
                    loop[colorLayer] = color

        object.data.update()
        bpy.ops.object.mode_set(mode=prev_mode)

        return object.data.vertex_colors.active

    @classmethod
    def configure(cls, config: BakeConfig, slot_info):
        slot_settings = slot_info['settings']
        if slot_settings['color_source']!='Mesh ID':
            config.vertex_layer_name = slot_settings['layer_name']
            return 
        
        object = config.highmesh or config.lowmesh
        vertex_layer = cls.setup_vertex_color_id_element(config.context, object)
    
        config.vertex_layer = vertex_layer
        config.vertex_layer_name = vertex_layer.name
        config.context.view_layer.objects.active = config.lowmesh

    @classmethod
    def deconfigure(cls, config: BakeConfig):
        settings = config.settings
        bake_object = settings.specified_object or settings.active_object
        vertex_colors = bake_object.data.vertex_colors

        if config.vertex_layer and config.vertex_layer_name in vertex_colors:
            vertex_colors.remove(config.vertex_layer)
