import bpy
from ...core.node.material_layer_nodes import PlxMaterialLayerNodes
from ...core.node.node_tree_handler import PlxNodeTreeHandler

class PlxMaterialLayerManager:
    def __init__(self, mat) -> None:
        self.mat = mat

    def add(self, layer_type):
        mat_props = self.mat.PlxProps
        item = self._add_item(mat_props)

        nodes_manager = PlxMaterialLayerNodes(item, layer_type)
        PlxNodeTreeHandler.build_nodes(self.mat.node_tree, nodes_manager)

        return item

    def _add_item(self, props):
        props.layers.add()
        idx = props.layers_index
        props.layers_index = idx + 1 if idx < len(props.layers) - 1 else len(props.layers) - 1
        props.layers.move(len(props.layers)-1, props.layers_index)
        return props.layers[props.layers_index]
