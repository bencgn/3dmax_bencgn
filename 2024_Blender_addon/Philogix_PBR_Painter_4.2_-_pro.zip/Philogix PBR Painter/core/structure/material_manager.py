import bpy
from ...utils import general_utilities, object_utilities

class PlxMaterialManager:
    def __init__(self, workflow):
        self.workflow = workflow

    def register(self, context, obj):
        self.mat = self._set_plx_material(obj)
        self.mat.use_nodes = True
        self.mat.PlxProps.workflow = self.workflow
        if not self.mat.PlxProps.ID:
            self.mat.PlxProps.ID = 'Plx_' + general_utilities.make_uid(5)
        props = context.scene.PlxProps
        props.preview = 0

    def unregister(self, mat):
        mat_props = mat.PlxProps
        mat_props.ID = ''
        mat_props.workflow = ''
        mat_props.uv_layer = ''
        mat_props.layers_index = -1
        mat_props.layers.clear()
        mat_props.channels.clear()

    def _set_plx_material(self, obj):
        mat = object_utilities.get_active_material(obj)
        if not mat:
            mat = bpy.data.materials.new('Material')
            if obj.data.materials:
                material_index = obj.active_material_index
                obj.material_slots[material_index].material = mat
            else:
                obj.data.materials.append(mat)
        return mat
