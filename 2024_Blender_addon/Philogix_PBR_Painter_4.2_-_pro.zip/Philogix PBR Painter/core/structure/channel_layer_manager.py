import bpy
from ...core.node.channel_layer_nodes import PlxChannelLayerNodes
from ...core.node.node_tree_handler import PlxNodeTreeHandler

class PlxChannelLayerManager:
    def __init__(self, channel_group) -> None:
        self.channel_group = channel_group

    def add(self, layer_type):
        channel_props = self.channel_group.PlxProps
        item = self._add_item(channel_props)

        nodes_manager = PlxChannelLayerNodes(item, layer_type)
        PlxNodeTreeHandler.build_nodes(self.channel_group, nodes_manager)
        return item

    def _add_item(self, props):
        idx = props.layers_index
        channel_layers = props.layers
    
        item = channel_layers.add()
        item.parent_layer_id = item.ID

        props.layers_index = idx + 1 if idx < len(channel_layers) - 1 else len(channel_layers) - 1
        channel_layers.move(len(channel_layers) - 1, props.layers_index)
        
        # kiểm tra clipping layer

        idx = props.layers_index
        item = channel_layers[idx]

        if idx < len(channel_layers)-1:
            next_layer = channel_layers[idx+1]
            if next_layer.ID != next_layer.parent_layer_id:
                item.parent_layer_id = next_layer.parent_layer_id
                item.parent.numb_sublayers += 1

        return channel_layers[props.layers_index]
