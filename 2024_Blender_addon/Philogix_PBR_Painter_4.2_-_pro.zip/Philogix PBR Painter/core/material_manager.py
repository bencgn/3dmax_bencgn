import bpy

from .udim_manager import UdimManager
from .image_manager import ImageManager

from ..utils.data_definitions import get_bake_list
from ..utils.general_utilities import  delimiter_join

class PlxChannelSetter:
    def __init__(self, mat):
        self.mat = mat
        self.workflow = mat.PlxProps.workflow

    def set_channel(self, id, name, icon, description, color_space):
        channels = self.mat.PlxProps.channels
        channel = channels.add()
        channel.ID = id
        channel.name = name
        channel.icon = icon
        channel.description = description
        channel.color_space = color_space

    def set_channels(self, activated_channels):
        for channel_name, channel_info in activated_channels:
            self.set_channel(channel_info['ID'], channel_name, channel_info['icon'], channel_info['description'], channel_info['color_space'])

class PlxBakeImageManager:
    def __init__(self, context, object):
        self.context = context
        self.object = object
        self.bake_list = get_bake_list()

    def set_bake_images(self, tiles):
        bake_list = get_bake_list()
        mesh_props =  self.object.data.PlxProps
        bake_images = mesh_props.bake_images
        bake_size = int(mesh_props.bake_size)

        for bake_name, bake_value in bake_list.items():
            image_slot = bake_images.get(bake_name)

            if not image_slot:
                image_slot = bake_images.add()
                image_slot.name = bake_name

            if (not image_slot.image 
                or image_slot.image.plx_mesh_image_baking != self.object.data
                or set(tile.number for tile in image_slot.image.tiles) != set(tiles)):

                new_image = ImageManager.new(self.context, 
                                             f"{self.object.data.name}_{bake_name}", 
                                             color=bake_value['default_value'], 
                                             width=bake_size, 
                                             height=bake_size, 
                                             float_buffer=True, 
                                             tiles=tiles)
                new_image.pack()        
                new_image.generated_color = bake_value['default_value']
                new_image.colorspace_settings.name = bake_value['color_space']
                    
                new_image.plx_mesh_image_baking = self.object.data
                image_slot.image = new_image

    def reload_bake_images(self, mat):
        bake_images = self.object.data.PlxProps.bake_images

        for bake_name, bake_info in self.bake_list.items():
            bake_node_name = delimiter_join('Plx', bake_info["image_name"])
            bake_slot = bake_images.get(bake_name)
            bake_node = mat.node_tree.nodes.get(bake_node_name)

            if bake_slot and bake_node:
                bake_node.image = bake_slot.image

class PlxBakeSlotsManager:
    def __init__(self, context):
        self.scene = context.scene
        self.bake_list = get_bake_list()

    def set_bake_slots(self):
        bake_slots = self.scene.PlxProps.bake_properties.slots
        
        for bake_name, bake_info in self.bake_list.items():
            bake_slot = bake_slots.get(bake_name, None) 

            if bake_slot is None:
                bake_slot = bake_slots.add()
                
                setattr(bake_slot, 'name', bake_name)
                setattr(bake_slot, 'image_name', bake_info['image_name'])
                setattr(bake_slot, 'bake_type', bake_info['bake_type']) 
                setattr(bake_slot, 'color_space', bake_info['color_space'])
                setattr(bake_slot, 'coefficient', bake_info['coefficient'])
                
                for prop_name in bake_info['props']:
                    prop = bake_info['props'][prop_name]
                    
                    setattr(bake_slot, prop_name, prop[0])
