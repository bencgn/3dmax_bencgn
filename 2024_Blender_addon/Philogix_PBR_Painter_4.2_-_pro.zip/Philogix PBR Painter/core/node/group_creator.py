import bpy

class PlxGroupCreator:
    @classmethod
    def add(cls, name):
        return bpy.data.node_groups.new(name, 'ShaderNodeTree')
    
    @classmethod
    def get(cls, name):
        return bpy.data.node_groups.get(name)
