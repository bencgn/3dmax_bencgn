import bpy
from ...utils import general_utilities
from ...core.serializer.attribute_serializer import AttributesDataSerializer as Attribute

class PlxNodeCreator:
    def __init__(self, node_tree):
        self.node_tree = node_tree

    def add_link(self, output_socket, input_socket):
        self.node_tree.links.new(output_socket, input_socket)

    def add_node(self, types, name='', parent=None, location=None):
        node = self.node_tree.nodes.new(types)
        node.width = 175
        node.parent = parent
        node.name = name if name else node.name
        node.location = location if location else (0, 0)
        return node

    def set_arrts(self, node, attrs):
        attr_serializer = Attribute(node)
        errors = attr_serializer.list_to_attrs(attrs)            
        if errors > 0:
            general_utilities.print_message(f"Has {errors} Errors\nNode Group: {node.id_data.name}\nNode: {node.name}")
                   

    def set_inputs(self, node, inputs={}):
        for input_idx, input_value in inputs.items():
            for arrt, value in input_value.items():
                setattr(node.inputs[input_idx], arrt, value)

    def set_outputs(self, node, outputs={}):
        for output_idx, output_value in outputs.items():
            for arrt, value in output_value.items():
                setattr(node.outputs[output_idx], arrt, value)
