import bpy
from ...utils import data_definitions
from .node_tree_handler import PlxNodesManager

class PlxMaterialNodes(PlxNodesManager):
    def __init__(self, mat):   
        self.mat = mat
        self.nodes_idx = 0
        self.workflow = mat.PlxProps.workflow
        self.bake_list = data_definitions.get_bake_list()
        self.channel_list = data_definitions.get_pbr_channels(self.workflow)
        del self.channel_list["Layer Mask"]
        
        self.init_nodes()

    def init_nodes_info(self):
        return {
            self.join_name('Plx', 'Default', 'Frame'): {
                "type": 'NodeFrame',
                "location": (0, 0),
                "hide": False
            },
            self.join_name('Plx', 'Shader'): {
                "type": f"ShaderNodePlx{self.workflow}",
                "location": (0, 0),
                "hide": False,
                "attrs": [
                    {
                        "attr_name": "node_tree.name",
                        "type_name": "str",
                        "value": self.join_name(self.mat.PlxProps.ID, 'Shader')
                    }
                ]
                
            },
            self.join_name('Plx', 'Material Output'): {
                "type": 'ShaderNodeOutputMaterial',
                "location": (200, 0),
                "hide": False
            },
        }

    def init_links_info(self):
        return [
            {
                "from_node": self.join_name('Plx', 'Shader'), 
                "from_socket": 0,
                "to_node": self.join_name('Plx', 'Material Output'),
                "to_socket": 0,
            },
        ]

    def setup_custom_nodes_info(self):
        self.setup_default_nodes_info()
        self.setup_bake_nodes_info()

    def setup_default_nodes_info(self):
        for channel_name, channel_info in self.channel_list.items():
            self.add_node_info(
                type = channel_info['default_node_type'],
                name = self.join_name('Plx', 'Default', channel_name),
                parent = self.join_name('Plx', 'Default', 'Frame'),
                location = (-1000, -self.nodes_idx * 40 + 160),
                attrs = [
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ],
                outputs={
                    0: {
                        'default_value': channel_info['default_value'],
                        },
                }
            )
            self.nodes_idx += 1

            
    def setup_bake_nodes_info(self):
        bake_uvmap_node_name = self.join_name('Plx', 'Default', 'Bake_UVMap')
        self.add_node_info(
                type='ShaderNodeUVMap',
                name=bake_uvmap_node_name,
                parent=self.join_name('Plx', 'Default', 'Frame'),
                location=(-1000, -self.nodes_idx * 40 + 160),
                attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ]
            )
        
        self.nodes_idx += 1

        self.add_node_info(
        type='ShaderNodeTexImage',
        name=self.join_name('Plx', 'Image_Export'),
        parent=self.join_name('Plx', 'Default', 'Frame'),
        location=(-1000, -self.nodes_idx * 40 + 160),
        attrs=[
            {
                "attr_name": "hide",
                "type_name": "bool",
                "value": True
            }])
        
        self.nodes_idx += 1

        for bake_info in self.bake_list.values():
            bake_map_node_name = self.join_name('Plx', bake_info['image_name'])
    
            self.add_node_info(
                type = 'ShaderNodeTexImage',
                name = bake_map_node_name,
                parent = self.join_name('Plx', 'Default', 'Frame'),
                location = (-1000, -self.nodes_idx  * 40 + 160),
                attrs = [
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ]
            )

            self.add_link_info({
                "from_node": bake_uvmap_node_name,
                "from_socket": 'UV',
                "to_node": bake_map_node_name,
                "to_socket": 'Vector'
            })

            self.nodes_idx += 1