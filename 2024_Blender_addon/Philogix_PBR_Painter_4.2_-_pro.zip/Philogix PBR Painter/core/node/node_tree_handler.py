import bpy

from .node_creator import PlxNodeCreator
from ...utils.general_utilities import  delimiter_join, print_message, MessageType

class PlxNodesManager():
    def init_nodes(self):
        self.nodes_info = self.init_nodes_info()
        self.links_info = self.init_links_info()
        self.setup_custom_nodes_info()

    def get_node(self, node_tree, *names):
        return node_tree.nodes.get(self.join_name(*names))
    
    def join_name(self, *names):
        return delimiter_join(*names)

    def add_node_info(self, type, name, location=(0,0), parent=None, attrs=[], inputs={}, outputs={}):
        self.nodes_info[name] = {
            "type": type,
            "attrs": attrs,
            "parent": parent,
            "inputs": inputs,
            "outputs": outputs,
            "location": location,
            }
        
    def add_link_info(self, info):
        if isinstance(info, dict):
            self.links_info.append({
                "from_node": info["from_node"],
                "from_socket": info["from_socket"],
                "to_node": info["to_node"],
                "to_socket": info["to_socket"]
            })
        else:
            self.links_info.extend(info)

class PlxNodeTreeHandler:
    @classmethod
    def build_nodes(cls, node_tree, nodes_manager):
        node_creator = PlxNodeCreator(node_tree)
        cls.create_nodes(node_creator, node_tree, nodes_manager)
        cls.create_links(node_creator, node_tree, nodes_manager)

    @classmethod
    def create_nodes(cls, node_creator, node_tree, nodes_manager):
        for node_name, node_info in nodes_manager.nodes_info.items():
            parent_node = None
            attrs = node_info.get("attrs", [])
            inputs = node_info.get("inputs", {})
            outputs = node_info.get("outputs", {})
            parent_node_name = node_info.get("parent")
            if parent_node_name:
                parent_node = node_tree.nodes.get(parent_node_name)

            new_node = node_creator.add_node(
                name=node_name,
                parent=parent_node,
                types=node_info.get("type"),
                location=node_info.get("location")
            )

            node_creator.set_arrts(new_node, attrs)
            node_creator.set_inputs(new_node, inputs)
            node_creator.set_outputs(new_node, outputs)

    @classmethod
    def create_links(cls, node_creator, node_tree, nodes_manager):
        for link_info in nodes_manager.links_info:
            from_node = node_tree.nodes.get(link_info['from_node'])
            to_node = node_tree.nodes.get(link_info['to_node'])

            if from_node and to_node:
                from_socket = from_node.outputs[link_info['from_socket']]
                to_socket = to_node.inputs[link_info['to_socket']]

                node_creator.add_link(from_socket, to_socket)
            else:
                print_message(f"Cannot find '{link_info['from_node']}' or '{link_info['to_node']}' in '{node_tree}' nodes")