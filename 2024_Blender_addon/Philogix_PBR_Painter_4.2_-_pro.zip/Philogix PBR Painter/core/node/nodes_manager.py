import bpy
from ...utils import general_utilities
from .material_nodes import PlxMaterialNodes
from .node_tree_handler import PlxNodeTreeHandler

class PlxMaterialNodesManager:
    def __init__(self, mat):
        self.mat = mat
        self.node_tree = mat.node_tree
        self.workflow = mat.PlxProps.workflow

    def create_nodes(self):
        self.node_idx = 0
        material_nodes = PlxMaterialNodes(self.mat)
        PlxNodeTreeHandler.build_nodes(self.node_tree, material_nodes)
        self.shader_node = material_nodes.get_node(self.node_tree, 'Plx', 'Shader')
        self._clean_output_nodes()
    
    def clear_default_nodes(self):
        node_tree = self.mat.node_tree
        nodes_to_remove = []

        shader_node_name = general_utilities.delimiter_join('Plx', 'Shader')
        default_node_prefix = general_utilities.delimiter_join('Plx', 'Default')
        material_output_node_name = general_utilities.delimiter_join('Plx', 'Material Output')

        for node in node_tree.nodes:
            if node.name == shader_node_name:
                if node.node_tree:
                    bpy.data.node_groups.remove(node.node_tree)
                nodes_to_remove.append(node)
            elif default_node_prefix in node.name or 'Image_' in node.name or node.name == material_output_node_name:
                nodes_to_remove.append(node)

        for node in nodes_to_remove:
            node_tree.nodes.remove(node)

    def _clean_output_nodes(self):
        for i in self.node_tree.nodes:
            if i.type == 'OUTPUT_MATERIAL' and i.name != general_utilities.delimiter_join('Plx', 'Material Output'):
                self.node_tree.nodes.remove(i)
