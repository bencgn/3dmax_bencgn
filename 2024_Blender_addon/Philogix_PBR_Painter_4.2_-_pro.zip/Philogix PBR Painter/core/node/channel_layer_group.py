import bpy

from .node_tree_handler import PlxNodesManager
from ..node.group_handler import PlxGroupManager
from .node_tree_handler import PlxNodeTreeHandler
from ...addon import distribution
from ...core.node.channel_group import PlxChannelGroup
from ...core.serializer.asset_serializer import PlxAsset

from ...utils.layer_utilities import make_layer_node_label
from ...utils.data_definitions import get_bake_list, get_pbr_channels
from ...utils.object_utilities import get_active_material, get_active_mesh_object

class PlxChannelLayerGroup(PlxGroupManager):
    @property
    def type_info(self): 
        icons = distribution.PreviewsCollection.previews
        return {
        'NONE': ("NONE", 1),
        'ID': ("ID", 34),
        'IMAGE': ("IMAGE", 361),
        "SURFACE":("SURFACE", 313),
        'ANCHOR': ("ANCHOR", icons.get('ANCHOR', 1)),
    }

    def __init__(self, layer, layer_type):
        self.layer = layer

        self.bake_list = get_bake_list()
        channel_group = layer.id_data
        self.channel_color_output_socket = channel_group.interface.items_tree[0]

        self.init_sokkets()
        self.node_group = self.build_group(self.layer.ID)

        if layer_type != 'NONE':
            nodes_manager = PlxChannelLayerGroupNodes(layer.ID, layer_type)
            PlxNodeTreeHandler.build_nodes(self.node_group, nodes_manager)

        layer_type, layer_icon = self.type_info.get(layer_type, ('FILTER', 93))
        layer_props = self.node_group.PlxProps
        layer_props.layer_type = layer_type
        layer_props.icon_value = layer_icon
        layer_props.name = make_layer_node_label(channel_group, 'Layer')

    def init_outputs_info(self):
        return [
            {
                "type": self.channel_color_output_socket.bl_socket_idname,
                "name": "Color", 
                "default_value": self.channel_color_output_socket.default_value
            },
            {
                "type": 'NodeSocketFloat', 
                "name": "Alpha", 
                "default_value": 1
            }
        ]
    
    def init_inputs_info(self):
        return [
            {
                "type": 'NodeSocketVector', 
                "name": "Vector", 
                "default_value": (0, 0, 0)
            },
            {
                "type": 'NodeSocketFloat', 
                "name": "Alpha", 
                "default_value": 1
            },
            {
                "type": self.channel_color_output_socket.bl_socket_idname,
                "name": "Color", 
                "default_value": self.channel_color_output_socket.default_value
            },
        ]
    
    def setup_custom_sockets_info(self):
        for bake_info in self.bake_list.values():
            self.inputs_info.append(
                {
                    "type": 'NodeSocketColor', 
                    "name": bake_info["image_name"], 
                    "default_value": bake_info["default_value"]
                })

class PlxChannelLayerGroupNodes(PlxNodesManager):
    def __init__(self, layer_id, layer_type):
        self.layer_id = layer_id
        self.layer_type = layer_type
        
        self.init_nodes()

    def init_nodes_info(self):
        return {
            "GroupInput": {
                "type": 'NodeGroupInput',
                "location": (-350, 0),
            },
            "GroupOutput": {
                "type": 'NodeGroupOutput',
                "location": (350, 0),
            }
        }

    def init_links_info(self):
        return [
            {
                "from_node": 'Value', 
                "from_socket": 0,
                "to_node": 'GroupOutput',
                "to_socket": 'Color',
            }
        ]
    
    def setup_custom_nodes_info(self):
        if self.layer_type == "SURFACE":
            self.setup_suface_layer_nodes_info()
        elif self.layer_type == "IMAGE":
            self.setup_image_layer_nodes_info()
        elif self.layer_type == "ANCHOR":
            self.setup_anchor_layer_nodes_info()
        elif self.layer_type == "ID":
            self.setup_id_layer_nodes_info()
        else:
            self.setup_filter_layer_nodes_info()


    def setup_suface_layer_nodes_info(self):
        self.setup_mapping_node_info()
        self.setup_math_node_info()
        self.setup_separate_node_info()

        mat = get_active_material()
        self.surface_node_group = PlxAsset.load_asset('92b682f047e24638b1ce')
        self.surface_node_group.name = self.join_name(self.layer_id, 'SmartSurface')
        channel = get_pbr_channels().get(mat.PlxProps.edit_maps)

        socket_type = channel['socket_type']
        
        new_input_name = socket_type.replace('NodeSocket', '').replace('Factor', '')
        new_input = self.surface_node_group.interface.new_socket(name=new_input_name, socket_type=socket_type)
        
        if 'min-max' in channel:
            new_input.subtype = 'FACTOR'
            new_input.min_value = channel['min-max'][0]
            new_input.max_value = channel['min-max'][1]

        new_input.default_value = channel['default_value']

        self.surface_node_group.links.new(self.surface_node_group.nodes['In'].outputs[new_input_name], self.surface_node_group.nodes['Out'].inputs['Color'])

        self.add_node_info(
            name="Value",
            type="ShaderNodeGroup",
            location=(0, -50),
            attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "node_tree",
                        "type_name": "str",
                        "value": self.surface_node_group
                    }
                ],
            inputs={
                new_input_name:{
                    "default_value": channel['default_value']
                }
            }
        )    


        for bake_value in get_bake_list().values():
            self.add_link_info({
                "from_node": 'GroupInput',
                "from_socket": bake_value["image_name"],
                "to_node": 'Value',
                "to_socket": bake_value["image_name"]
            })

    def setup_image_layer_nodes_info(self):
        self.setup_mapping_node_info()
        self.setup_math_node_info()
        self.setup_separate_node_info()

        self.add_node_info(
            name="Value",
            type="ShaderNodeTexImage",
            location=(0, -50),
            attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }

                ]
            )

    def setup_anchor_layer_nodes_info(self):
        self.setup_mapping_node_info()

        channel_handler = PlxChannelGroup(self.layer_id, "Layer Mask")
        
        self.add_node_info(
            name='Value',
            type="ShaderNodeGroup",
            location=(0, -50),               
            attrs= [
                {
                    "attr_name": "node_tree",
                    "type_name": "str",
                    "value": channel_handler.node_group
                },
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                }
            ]
        )

        self.add_link_info([
            {
                "from_node": 'Mapping', 
                "from_socket": 'Alpha',
                "to_node": 'Value',
                "to_socket": 'Alpha',
            },
            {
                "from_node": 'GroupInput', 
                "from_socket": 'Color',
                "to_node": 'Value',
                "to_socket": 'Color',
            }])
    

        for bake_value in get_bake_list().values():
            self.add_link_info({
                "from_node": 'GroupInput',
                "from_socket": bake_value["image_name"],
                "to_node": 'Value',
                "to_socket": bake_value["image_name"]
            })

    def setup_id_layer_nodes_info(self):
        id_value_group = PlxAsset.load_asset('00991cdea8114282933d')
        id_value_group.name = self.join_name(self.layer_id, 'IdLayer')

        self.add_node_info(
            name="Value",
            type="ShaderNodeGroup",
            location=(0, 0),
            attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "node_tree",
                        "type_name": "node_group",
                        "value": id_value_group
                    },
                ]
            )
        
        self.add_node_info(
            name="AlphaMode",
            type="ShaderNodeMix",
            location=(0, -100),
            attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "data_type",
                        "type_name": "enum",
                        "value": 'FLOAT'
                    }
                ],
            inputs={
                    0: {'default_value': 1},
                    3: {'default_value': 1}
                }
            )


        self.add_link_info([
            {
                "from_node": 'Value', 
                "from_socket": 0,
                "to_node": 'AlphaMode',
                "to_socket": 2,
            },
            {
                "from_node": 'AlphaMode', 
                "from_socket": 0,
                "to_node": 'GroupOutput',
                "to_socket": 'Alpha',
            },
            {
                "from_node": 'GroupInput', 
                "from_socket": 'Image_ID',
                "to_node": 'Value',
                "to_socket": 'ID',
            }])

    def setup_filter_layer_nodes_info(self):
        self.add_node_info(
            name="Value",
            type=self.layer_type,
            location=(0, -50),
            attrs=[
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ]
            )
        
        if self.layer_type == "ShaderNodeValToRGB":
            self.add_link_info([
                {
                    "from_node": 'GroupInput', 
                    "from_socket": "Color",
                    "to_node": 'Value',
                    "to_socket": 'Fac',
                },
                {
                    "from_node": 'Value', 
                    "from_socket": "Alpha",
                    "to_node": 'GroupOutput',
                    "to_socket": 'Alpha',
                }])
        else:
            self.add_link_info(
                {
                    "from_node": 'GroupInput', 
                    "from_socket": "Color",
                    "to_node": 'Value',
                    "to_socket": 'Color',
                })
            
        

    def setup_separate_node_info(self):
        self.add_node_info(
            name="Separate",
            type='ShaderNodeSeparateColor',
            location=(0, -100),
            attrs=[
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                }
            ]
        )

        self.add_link_info(
            {
                "from_node": 'Value', 
                "from_socket": 0,
                "to_node": 'Separate',
                "to_socket": 0,
            })

    def setup_math_node_info(self):
        self.add_node_info(
            name="Math",
            type='ShaderNodeMath',
            location=(0, -150),
            attrs=[
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                },
                {
                    "attr_name": "use_clamp",
                    "type_name": "bool",
                    "value": True
                },
                {
                    "attr_name": "operation",
                    "type_name": "str",
                    "value": 'MULTIPLY'
                },
            ],
            inputs={
                0: {
                    "default_value": 1,
                },
                1: {
                    "default_value": 1,
                },
            }
        )
        
        self.add_link_info([
            {
                "from_node": 'Math', 
                "from_socket": 0,
                "to_node": 'GroupOutput',
                "to_socket": 'Alpha',
            },
            {
                "from_node": 'Mapping', 
                "from_socket": 'Alpha',
                "to_node": 'Math',
                "to_socket": 1,
            },
            {
                "from_node": 'Value', 
                "from_socket": 'Alpha',
                "to_node": 'Math',
                "to_socket": 0,
            }])
    
    def setup_mapping_node_info(self):
        obj = get_active_mesh_object()
        self.add_node_info(
            name="Mapping",
            type='ShaderNodePlxMapping',
            location=(0, 0),
            attrs=[
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                },
                {
                    "attr_name": "uv_map",
                    "type_name": "str",
                    "value": obj.data.uv_layers.active.name
                },
                {
                    "attr_name": "node_tree.name",
                    "type_name": "str",
                    "value": self.join_name(self.layer_id, 'Mapping')
                },
            ]
        )

        self.add_link_info(
            {
                "from_node": 'Mapping', 
                "from_socket": 'Vector',
                "to_node": 'Value',
                "to_socket": 'Vector',
            })
