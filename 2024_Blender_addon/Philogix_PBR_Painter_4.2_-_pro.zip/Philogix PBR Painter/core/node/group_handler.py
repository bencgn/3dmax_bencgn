import bpy

from .group_creator import PlxGroupCreator

class PlxGroupManager:
    def init_sokkets(self):
        self.outputs_info = self.init_outputs_info()
        self.inputs_info = self.init_inputs_info()
        self.setup_custom_sockets_info()

    def build_group(self, name):
        self.node_group  = PlxGroupCreator.add(name)
        self.set_sockets()
        return self.node_group 

    def set_sockets(self):
        """Create and return a new socket based on the provided info."""
        for output_info in self.outputs_info:
            socket = self.node_group.interface.new_socket(
                name=output_info["name"],
                in_out="OUTPUT",
                socket_type=output_info.get("type", ""),
                description=output_info.get("description", ""),
                parent=output_info.get("parent", None))
            socket.default_value = output_info.get("default_value", socket.default_value)

        for input_info in self.inputs_info:
            socket = self.node_group.interface.new_socket(
                name=input_info["name"],
                in_out="INPUT",
                socket_type=input_info.get("type", ""),
                description=input_info.get("description", ""),
                parent=input_info.get("parent", None))
            socket.default_value = input_info.get("default_value", socket.default_value)