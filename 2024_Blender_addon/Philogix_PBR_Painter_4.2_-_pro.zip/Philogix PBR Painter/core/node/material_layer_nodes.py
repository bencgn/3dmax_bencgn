import bpy, random
from .node_tree_handler import PlxNodesManager, PlxNodeTreeHandler
from ...core.node.material_layer_group import PlxMaterialLayerGroup

class PlxMaterialLayerNodes(PlxNodesManager):
    def __init__(self, layer, layer_type):
        self.layer = layer
        self.layer_type = layer_type
        
        self.init_nodes()

    def init_nodes_info(self):
        self.layer_group_manager = PlxMaterialLayerGroup(self.layer, self.layer_type)

        return {
            self.layer.ID: {
                "type": 'ShaderNodeGroup',
                "attrs": [
                    {
                        "attr_name": "node_tree",
                        "type_name": "str",
                        "value": self.layer_group_manager.node_group
                    },
                    {
                        "attr_name": "width",
                        "type_name": "int",
                        "value": 225
                    },
                    {
                        "attr_name": "use_custom_color",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "color",
                        "type_name": "Color",
                        "value": (random.random(), random.random(), random.random())
                    }
                ]
            }
        }

    def init_links_info(self):
        return []
    
    def setup_custom_nodes_info(self):
        pass