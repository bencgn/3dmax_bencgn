import bpy

from .node_tree_handler import PlxNodesManager
from .node_tree_handler import PlxNodeTreeHandler
from ...core.node.channel_group import PlxChannelGroup
from ...core.node.group_handler import PlxGroupManager
from ...core.serializer.asset_serializer import PlxAsset

from ...utils.layer_utilities import make_layer_node_label
from ...utils.object_utilities import get_active_mesh_object
from ...utils.data_definitions import get_bake_list, get_pbr_channels

class PlxMaterialLayerGroup(PlxGroupManager):
    @property
    def type_info(self): 
        return {
        "CUSTOM": 125,
        'MATERIAL': 127,
        'NONE': 1,
    }

    def __init__(self, layer, layer_type):
        self.mat = layer.id_data
        self.layer = layer
        self.layer_type = layer_type

        self.workflow = self.mat.PlxProps.workflow
        self.bake_list = get_bake_list()
        self.channel_list = get_pbr_channels(self.workflow)

        self.init_sokkets()
        self.node_group = self.build_group(self.layer.ID)

        if layer_type != 'NONE':
            nodes_manager = PlxMaterialLayerGroupNodes(layer.ID, layer_type, self.channel_list)
            PlxNodeTreeHandler.build_nodes(self.node_group, nodes_manager)

        layer_props = self.node_group.PlxProps
        layer_props.layer_type = self.layer_type
        layer_props.icon_value = self.type_info[self.layer_type]
        layer_props.name = make_layer_node_label(self.mat.node_tree, 'Material')


    def init_outputs_info(self):
        return []
    
    def init_inputs_info(self):
        return []
    
    def setup_custom_sockets_info(self):
        for channel_name, channel_info in self.channel_list.items():
            self.outputs_info.extend([
                {
                    "type": channel_info["socket_type"], 
                    "name": channel_name, 
                    "default_value": channel_info["default_value"]
                }])
            
            self.inputs_info.extend([
                {
                    "type": channel_info["socket_type"], 
                    "name": channel_name, 
                    "default_value": channel_info["default_value"]
                }])
            
        for bake_info in self.bake_list.values():
            self.inputs_info.append(
                {
                    "type": 'NodeSocketColor', 
                    "name": bake_info["image_name"], 
                    "default_value": bake_info["default_value"]
                 })

class PlxMaterialLayerGroupNodes(PlxNodesManager):
    def __init__(self, layer_id, layer_type, channel_list):
        self.layer_id = layer_id
        self.layer_type = layer_type
        self.channel_list = channel_list
        
        self.init_nodes()


    def init_nodes_info(self):
        obj = get_active_mesh_object()
        return {
            "Mapping": {
                "type": 'ShaderNodePlxMapping',
                "location": (-280, 160),
                "hide": True,
                "attrs": [
                    {
                        "attr_name": "uv_map",
                        "type_name": "str",
                        "value": obj.data.uv_layers.active.name
                    },
                    {
                        "attr_name": "node_tree.name",
                        "type_name": "str",
                        "value": self.join_name(self.layer_id, 'Mapping')
                    },
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ]
            },
            "GroupInput": {
                "type": 'NodeGroupInput',
                "location": (-520, 40)
            },
            "GroupOutput": {
                "type": 'NodeGroupOutput',
                "location": (460, 40),
            },
        }

    def init_links_info(self):
        return []

    def setup_custom_nodes_info(self):
        self.setup_layer_mask_nodes()
        self.setup_pbr_channel_nodes_info()
        self.setup_type_nodes_info(self.layer_type)


    def setup_pbr_channel_nodes_info(self):
        for i, channel_name in enumerate(self.channel_list.keys()):
            if channel_name != "Layer Mask":
                self.setup_individual_channel(channel_name, -i*40)

    def setup_individual_channel(self, channel_name, y):
            opacity_node_name = self.join_name(channel_name, 'MixOpacity')
            mix_layer_node_name = self.join_name(channel_name, 'MixLayer')

            self.add_node_info(
                name=opacity_node_name,
                type="ShaderNodeMix",
                location=(-280, y),
                attrs=[
                    {
                        "attr_name": "data_type",
                        "type_name": "str",
                        "value": "RGBA"
                    },
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ],
                inputs={
                    0: {
                        "default_value": 1
                    },
                    6: {
                        "default_value": (0,0,0,1)
                    },
                    7: {
                        "default_value": (1,1,1,1)
                    }
                }
            )
            self.add_node_info(
                name=mix_layer_node_name,
                type="ShaderNodeMix",
                location=(220, y+40),
                attrs=[
                    {
                        "attr_name": "data_type",
                        "type_name": "str",
                        "value": "RGBA"
                    },
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    }
                ],
                inputs={
                    0: {
                        "default_value": 1
                    }
                }
            )
            
            self.add_link_info([
                {
                "from_node": opacity_node_name,
                "from_socket": 2,
                "to_node": mix_layer_node_name,
                "to_socket": 0
                },
                {
                "from_node": "GroupInput",
                "from_socket": channel_name,
                "to_node": mix_layer_node_name,
                "to_socket": 6
                },
                {
                "from_node": self.join_name('Layer Mask', 'MixOpacity'),
                "from_socket": 2,
                "to_node": opacity_node_name,
                "to_socket": 7
                },
                {
                "from_node": mix_layer_node_name,
                "from_socket": 2,
                "to_node": "GroupOutput",
                "to_socket": channel_name
                }]
            )

    def setup_layer_mask_nodes(self):
        self.setup_channel_node('Layer Mask', (-280, 100))
        
        self.add_node_info(
            name=self.join_name('Layer Mask', 'MixOpacity'),
            type="ShaderNodeMix",
            location=(-280, 40),
            attrs=[
                {
                    "attr_name": "data_type",
                    "type_name": "str",
                    "value": "RGBA"
                },
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                }
            ],
            inputs={
                0: {
                    "default_value": 1
                },
                6: {
                    "default_value": (0,0,0,1)
                },
                7: {
                    "default_value": (1,1,1,1)
                }
            }
        )
        self.add_link_info([
            {
                "from_node": 'Layer Mask',
                "from_socket": 0,
                "to_node": 'GroupOutput',
                "to_socket": 'Layer Mask'
            },
            {
                "from_node": 'Layer Mask',
                "from_socket": 0,
                "to_node": self.join_name('Layer Mask', 'MixOpacity'),
                "to_socket": 7
            },
            {
                "from_node": "Mapping",
                "from_socket": 1,
                "to_node": self.join_name('Layer Mask', 'MixOpacity'),
                "to_socket": 0
            }])
        
    def setup_channel_node(self, channel_name, location):
        channel_handler = PlxChannelGroup(self.layer_id, channel_name)
        bake_list = get_bake_list()
        
        self.add_node_info(
            name=channel_name,
            type="ShaderNodeGroup",
            location=location,                
            attrs= [
                {
                    "attr_name": "node_tree",
                    "type_name": "str",
                    "value": channel_handler.node_group
                },
                {
                    "attr_name": "label",
                    "type_name": "str",
                    "value": channel_name
                },
                {
                    "attr_name": "hide",
                    "type_name": "bool",
                    "value": True
                }
            ]
        )
        
        self.add_link_info([
            {
                "from_node": 'Mapping',
                "from_socket": 0,
                "to_node": channel_name,
                "to_socket": 0
            },
            {
                "from_node": "Mapping",
                "from_socket": 1,
                "to_node": channel_name,
                "to_socket": 1
            }])
        
        for bake_info in bake_list.values():
            self.add_link_info(
                {
                    "from_node": 'GroupInput',
                    "from_socket": bake_info["image_name"],
                    "to_node": channel_name,
                    "to_socket": bake_info["image_name"]
                })


    def setup_type_nodes_info(self, layer_type):
        if layer_type == "MATERIAL":
            self.setup_smart_layer_nodes_info()
        elif layer_type == "CUSTOM":
            self.setup_custom_layer_nodes_info()

    def setup_custom_layer_nodes_info(self):
        y_offset = 100
        for channel_name in self.channel_list.keys():
            if channel_name == 'Layer Mask': continue
            self.setup_custom_layer_node(channel_name, y_offset)
            y_offset -= 75

    def setup_custom_layer_node(self, channel_name, y_offset):
        self.setup_channel_node(channel_name, (0, y_offset))

        self.add_link_info([{
            "from_node": channel_name,
            "from_socket": 'Color',
            "to_node": self.join_name(channel_name, 'MixLayer'),
            "to_socket": 7
        },
        {
            "from_node": 'GroupInput',
            "from_socket": channel_name,
            "to_node": channel_name,
            "to_socket": 'Color'
        },
        {
            "from_node": 'Mapping',
            "from_socket": 'Vector',
            "to_node": channel_name,
            "to_socket": 'Vector'
        }])

    def setup_smart_layer_nodes_info(self):
        bake_list = get_bake_list()

        smart_material_node_group = PlxAsset.load_asset('33e30d7081664ed99215')
        smart_material_node_group.name = self.join_name(self.layer_id, 'SmartMaterial')

        self.add_node_info(
            name='Value',
            type="ShaderNodeGroup",
            location=(-40, 120),
            attrs= [
                {
                    "attr_name": "node_tree",
                    "type_name": "str",
                    "value": smart_material_node_group
                },
                {
                    "attr_name": "label",
                    "type_name": "str",
                    "value": 'Smart Material'
                }
            ]
        )
        
        self.add_link_info([
            {
                "from_node": 'Mapping',
                "from_socket": 0,
                "to_node": 'Value',
                "to_socket": 'Vector'
            },
            {
                "from_node": 'Value',
                "from_socket": 'Layer Mask',
                "to_node": 'Layer Mask',
                "to_socket": 'Color'
            }])

        for channel_name in self.channel_list.keys():     
            if channel_name != "Layer Mask":      
                self.add_link_info(
                    {
                        "from_node": 'Value',
                        "from_socket": channel_name,
                        "to_node": self.join_name(channel_name, 'MixLayer'),
                        "to_socket": 7
                    })
            
        for bake_info in bake_list.values():
            self.add_link_info(
                {
                    "from_node": 'GroupInput',
                    "from_socket": bake_info["image_name"],
                    "to_node": 'Value',
                    "to_socket": bake_info["image_name"]
                })

        