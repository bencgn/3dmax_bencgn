import bpy, random
from .node_tree_handler import PlxNodesManager
from ..node.channel_layer_group import PlxChannelLayerGroup
from ...utils import data_definitions


class PlxChannelLayerNodes(PlxNodesManager):
    def __init__(self, layer, layer_type):
        self.layer = layer
        self.layer_type = layer_type
        
        self.init_nodes()

    def init_nodes_info(self):    
        layer_group_manager = PlxChannelLayerGroup(self.layer, self.layer_type)

        return {
            self.join_name(self.layer.ID, 'Frame'): {
                "type": "NodeFrame",
                "location": (0, 0),
            },

            self.layer.ID: {
                "type": 'ShaderNodeGroup',
                "location": (0, 0),
                "parent": self.join_name(self.layer.ID, 'Frame'),
                "attrs": [
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "node_tree",
                        "type_name": "node_group",
                        "value": layer_group_manager.node_group
                    }
                ]
            },

            self.join_name(self.layer.ID, 'MixLayer'): {
                "type": 'ShaderNodeMix',
                "location": (300, 20),
                "parent": self.join_name(self.layer.ID, 'Frame'),
                "attrs": [
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "data_type",
                        "type_name": "str",
                        "value": 'RGBA'
                    }
                ],
                "inputs":{
                    0: {
                        "default_value": 0,
                    }
                }
            },

            self.join_name(self.layer.ID, 'MixOpacity'): {
                "type": 'ShaderNodeMix',
                "location": (300, -20),
                "parent": self.join_name(self.layer.ID, 'Frame'),
                "attrs": [
                    {
                        "attr_name": "hide",
                        "type_name": "bool",
                        "value": True
                    },
                    {
                        "attr_name": "data_type",
                        "type_name": "str",
                        "value": 'RGBA'
                    }
                ],
                "inputs":{
                    0: {
                        "default_value": 1,
                    },
                    6: {
                        "default_value": (0,0,0,1),
                    },
                    7: {
                        "default_value": (1,1,1,1),
                    }
                }
            },
        }

    def init_links_info(self):
        return [
            {
                "from_node": 'GroupInput', 
                "from_socket": 'Alpha',
                "to_node": self.layer.ID,
                "to_socket": 'Alpha',
            },
            {
                "from_node": 'GroupInput', 
                "from_socket": 'Vector',
                "to_node": self.layer.ID,
                "to_socket": 'Vector',
            },
            {
                "from_node": self.layer.ID, 
                "from_socket": 'Color',
                "to_node": self.join_name(self.layer.ID, 'MixLayer'),
                "to_socket": 7,
            },
            {
                "from_node": self.layer.ID, 
                "from_socket": 'Alpha',
                "to_node": self.join_name(self.layer.ID, 'MixOpacity'),
                "to_socket": 7,
            },
            {
                "from_node": self.join_name(self.layer.ID, 'MixOpacity'), 
                "from_socket": 2,
                "to_node": self.join_name(self.layer.ID, 'MixLayer'),
                "to_socket": 0,
            }
        ]

    def setup_custom_nodes_info(self):
        for bake_value in data_definitions.get_bake_list().values():
            self.add_link_info({
                "from_node": 'GroupInput',
                "from_socket": bake_value["image_name"],
                "to_node": self.layer.ID,
                "to_socket": bake_value["image_name"]
            })