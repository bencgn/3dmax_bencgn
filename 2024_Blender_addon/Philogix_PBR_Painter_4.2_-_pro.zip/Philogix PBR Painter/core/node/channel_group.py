import bpy
from ...utils import data_definitions, general_utilities
from .node_tree_handler import PlxNodesManager, PlxNodeTreeHandler
from .group_handler import PlxGroupManager

from ...utils.general_utilities import print_message

class PlxChannelGroup(PlxGroupManager):
    def __init__(self, material_layer_id, channel_name):
        self.channel_info = data_definitions.get_pbr_channels().get(channel_name)
        group_name = general_utilities.delimiter_join(material_layer_id, channel_name)

        if not self.channel_info:
            print_message("PBR channel is not available!")
            return
        
        self.init_sokkets()

        self.node_group = self.build_group(group_name)

        nodes_manager = PlxChannelGroupNodes()
        PlxNodeTreeHandler.build_nodes(self.node_group, nodes_manager)


    def init_outputs_info(self):
        return [
            {
                "type": self.channel_info['socket_type'], 
                "name": 'Color', 
                "default_value": self.channel_info['default_value']
            }
        ]

    def init_inputs_info(self):
        return [
            {
                "type": 'NodeSocketVector', 
                "name": 'Vector', 
                "default_value": (0,0,0)
             },
            {
                "type": 'NodeSocketFloat', 
                "name": 'Alpha', 
                "default_value": 1
            },
            {
                "type": self.channel_info['socket_type'], 
                "name": 'Color', 
                "default_value": self.channel_info['default_value']
            }
        ]

    def setup_custom_sockets_info(self):     
        bake_list = data_definitions.get_bake_list()   
        for bake_info in bake_list.values():
            self.inputs_info.append(
                {
                    "type": 'NodeSocketColor', 
                    "name": bake_info["image_name"], 
                    "default_value": bake_info["default_value"]
                 })



class PlxChannelGroupNodes(PlxNodesManager):
    def __init__(self):
        self.init_nodes()

    def init_nodes_info(self):
        return {
            "GroupOutput": {
                "type": 'NodeGroupOutput',
                "location": (500, 0),
                "hide": False
            },
            "GroupInput": {
                "type": 'NodeGroupInput',
                "location": (-500, 0),
                "hide": False
            },
        }

    def init_links_info(self):
        return [
            {
                "from_node": 'GroupInput', 
                "from_socket": 'Color',
                "to_node": 'GroupOutput',
                "to_socket": 'Color',
            },
        ]
    
    def setup_custom_nodes_info(self):
        pass