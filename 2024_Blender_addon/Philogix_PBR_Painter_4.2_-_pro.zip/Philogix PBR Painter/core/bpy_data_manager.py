import bpy

from bpy.types import Scene, Mesh, Object, Brush, Image, Material, ShaderNodeTree
from ..utils.general_utilities import print_message, MessageType

class BpyDataManager:
    @classmethod
    def remove_data(cls, data):
        type_mapping = {
            Scene: bpy.data.scenes.remove,
            Brush: bpy.data.brushes.remove,
            Image: bpy.data.images.remove,
            Mesh: bpy.data.meshes.remove,
            Object: bpy.data.objects.remove,
            Material: bpy.data.materials.remove,
            ShaderNodeTree: bpy.data.node_groups.remove}
        
        remover = type_mapping.get(type(data))

        try: remover(data)
        except: print_message(f"{data}", MessageType.INFO)