import bpy, os

from ..utils.general_utilities import get_addon_directory, print_message, MessageType

class PathConverter:
    @staticmethod
    def from_list(list_path):
        if not isinstance(list_path, list):
            return ""
        
        addon_path = get_addon_directory()
        temp_path = os.path.dirname(bpy.app.tempdir)
        
        path_mapping = {
            'Philogix PBR Painter - Addon Folder': addon_path,
            'Philogix PBR Painter - Temp Folder': temp_path,
        }
        
        for path, replacement in path_mapping.items():
            list_path = [replacement if x == path else x for x in list_path]

        return os.sep.join(list_path)

    @staticmethod
    def to_list(filepath):
        addon_path = get_addon_directory()
        temp_path = os.path.dirname(bpy.app.tempdir)
        file_path = os.path.normpath(filepath)
        
        path_mapping = {
            os.path.normpath(addon_path): 'Philogix PBR Painter - Addon Folder',
            os.path.normpath(temp_path): 'Philogix PBR Painter - Temp Folder',
        }
        
        for path, replacement in path_mapping.items():
            file_path = file_path.replace(path, replacement)

        return file_path.split(os.sep)
