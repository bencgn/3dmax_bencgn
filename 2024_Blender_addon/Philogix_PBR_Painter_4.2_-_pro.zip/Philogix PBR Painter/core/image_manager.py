import bpy, os, shutil
import numpy as np

from ..utils.general_utilities import print_message, MessageType

class ImageManager:
    @staticmethod
    def new(context, name, width, height, color=(0,0,0,1), alpha=False, float_buffer=False, stereo3d=False, is_data=False, tiles=[1001]):
        tiled = (len(tiles)>1 or 1001 not in tiles)
        image = bpy.data.images.new(name=name, width=width, height=height, alpha=alpha, float_buffer=float_buffer, stereo3d=stereo3d, is_data=is_data, tiled=tiled)
        image.generated_color = color

        if tiled:
            prev_area_ui_type = context.area.ui_type
            context.area.ui_type = 'IMAGE_EDITOR'
            context.area.spaces[0].image = image

            for title_number in tiles:
                active_tile = image.tiles.get(title_number)
                if not active_tile:
                    image.tiles.active = image.tiles.new(title_number)
                    bpy.ops.image.tile_fill(color=color, width=width, height=height, float=float_buffer, alpha=alpha)

            if 1001 not in tiles:
                image.tiles.remove(image.tiles.get(1001))

            context.area.ui_type = prev_area_ui_type
        return image
    
    @staticmethod
    def scale(context, image, width, height):
        if not image:
            return
        
        if len(image.tiles)==1:
            image.scale(width, height)
        else:
            prev_area_ui_type = context.area.ui_type
            context.area.ui_type = 'IMAGE_EDITOR'
            context.area.spaces[0].image = image

            for tile in image.tiles:
                image.tiles.active = tile
                bpy.ops.image.resize(size=(width, height))

            context.area.ui_type = prev_area_ui_type

    @classmethod
    def save(cls, image, save_path, overwrite=False):
        if os.path.exists(save_path) and not overwrite:
            return
        
        if not image.packed_file:
            image.pack()
            
        image.filepath_raw = save_path
        image.save()

        if image.packed_file:
            image.unpack(method='REMOVE')

    @classmethod
    def save_copy(cls, image, save_path, overwrite=False):
        """ Save and reload image to the given path """
        new_image = image.copy()
        colorspace = new_image.colorspace_settings.name

        save_path = save_path.replace(".<UDIM>", "")
        if new_image.source == 'TILED':
            base_name, file_extension = os.path.splitext(save_path)
            save_path = f"{base_name}.<UDIM>{file_extension}"

        if os.path.exists(save_path) and not overwrite:
            new_image.filepath_raw = save_path

        elif os.path.exists(new_image.filepath_raw) and not new_image.is_dirty:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            shutil.copy(new_image.filepath_raw, save_path)
            new_image.filepath_raw = save_path

        else:
            if not new_image.packed_file:
                new_image.pack()

            new_image.filepath_raw = save_path
            new_image.save()

            if new_image.packed_file:
                new_image.unpack(method='REMOVE')

        new_image.reload()
        new_image.colorspace_settings.name = colorspace

        return new_image

    @classmethod
    def combine_images(cls, base_image, overlay_image, overlay_type, location=(0, 0), opacity=1.0):
        base_pixels = np.array(base_image.pixels)
        overlay_pixels = np.array(overlay_image.pixels)

        x, y = location
        overlay_size = overlay_image.size
        base_size = base_image.size

        overlay_alpha_full = np.zeros((base_size[1], base_size[0]))

        x_min, x_max = max(0, x), min(base_size[0], x + overlay_size[0])
        y_min, y_max = max(0, y), min(base_size[1], y + overlay_size[1])
        overlay_alpha = overlay_pixels[3::4].reshape(overlay_size[1], overlay_size[0])
        overlay_alpha_full[y_min:y_max, x_min:x_max] = overlay_alpha[:y_max - y_min, :x_max - x_min]

        if overlay_type == 'mask':
            base_pixels[3::4] = base_pixels[3::4] * overlay_alpha_full.flatten()

        elif overlay_type == 'add':
            for i in range(3):  # Xử lý cho mỗi kênh màu RGB
                base_channel = base_pixels[i::4].reshape(base_size[1], base_size[0])
                overlay_channel = overlay_pixels[i::4].reshape(overlay_size[1], overlay_size[0])
                overlay_alpha_channel = overlay_alpha_full[y_min:y_max, x_min:x_max]

                # Alpha blending
                base_channel[y_min:y_max, x_min:x_max] = (overlay_alpha_channel * overlay_channel[:y_max - y_min, :x_max - x_min] * opacity) + (1 - overlay_alpha_channel * opacity) * base_channel[y_min:y_max, x_min:x_max]
                base_pixels[i::4] = base_channel.flatten()

            # Cập nhật alpha channel của base_image
            base_alpha_channel = base_pixels[3::4].reshape(base_size[1], base_size[0])
            base_alpha_channel[y_min:y_max, x_min:x_max] = overlay_alpha_channel * opacity + (1 - overlay_alpha_channel * opacity) * base_alpha_channel[y_min:y_max, x_min:x_max]
            base_pixels[3::4] = base_alpha_channel.flatten()

        base_image.pixels = list(base_pixels)
