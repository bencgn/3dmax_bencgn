import bpy, os, time

from ..utils.general_utilities import get_addon_directory

class RegistrationManager:
    _instance = None

    _addon_directory = get_addon_directory()
    _operators_directory = os.path.join(_addon_directory, "operators")
    _registration_file = os.path.join(bpy.utils.user_resource('CONFIG'), "philogix_pbr_painter_registration.plxt")
    
    _version_files = {
        "dev": os.path.join(_operators_directory, "version_develop"),
        "pro": os.path.join(_operators_directory, "version_pro")
    }

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RegistrationManager, cls).__new__(cls)
            cls._instance.__init__()
        return cls._instance
    
    def __init__(self):
        self.version_str = None
        self.remaining_days = 0
        self.trailer_remaining_time = 0

        self._check_version()
        self._update_version_str()

        if not self.is_pro_version:
            self._check_registration()
            self._update_remaining_days()


    def _check_version(self):
        self.is_dev_version = os.path.exists(self._version_files["dev"])
        self.is_pro_version = os.path.exists(self._version_files["pro"])

    def _check_registration(self):             
        if os.path.isfile(self._registration_file):
            with open(self._registration_file, 'r') as file:
                expiration_time = float(file.read().strip())
        else:
            expiration_time = time.time() + 30 * 24 * 60 * 60
            with open(self._registration_file, 'w') as file:
                file.write(str(expiration_time))
        
        self.trailer_remaining_time = expiration_time - time.time()
        
    def _update_remaining_days(self):
        if self.trailer_remaining_time < 0:
            self.remaining_days = 0
        else:
            self.remaining_days = self.trailer_remaining_time // (24 * 60 * 60) + 1

    def _update_version_str(self):
        self.version_str = "Develop" if self.is_dev_version else "Pro" if self.is_pro_version else "Trailer"
