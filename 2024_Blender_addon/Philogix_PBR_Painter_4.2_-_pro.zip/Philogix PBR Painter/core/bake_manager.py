import bpy

from ..core.bpy_data_manager import BpyDataManager

from ..utils.general_utilities import delimiter_join

class BakeTempDatas:
    def __init__(self):
        self.datas = []

    def add(self, datas):
        self.datas += datas if isinstance(datas, list) else [datas]

    def clear(self):
        for data in self.datas:
            BpyDataManager.remove_data(data)

class BakeHandlers:
    def __init__(self) -> None:
        self.status = None
        self.add_handlers()

    def bake_cancel_handler(self, context, event):
        self.status = 'canceled'

        bpy.app.handlers.object_bake_pre.clear()
        bpy.app.handlers.object_bake_cancel.clear()
        bpy.app.handlers.object_bake_complete.clear()

    def bake_complete_handler(self, context, event):
        self.status = 'completed'

    def bake_pre_handler(self, context, event):
        self.status = 'processing'

    def add_handlers(self):
        bpy.app.handlers.object_bake_pre.append(self.bake_pre_handler)
        bpy.app.handlers.object_bake_cancel.append(self.bake_cancel_handler)
        bpy.app.handlers.object_bake_complete.append(self.bake_complete_handler)


class MaterialPropertiesManager:
    @classmethod
    def get_material_properties(cls, material):
        if not (material and material.use_nodes):
            return None
        
        shader_node = material.node_tree.nodes.get(delimiter_join('Plx', 'Shader'))
        shader_output = shader_node.shader_output if shader_node else None
        return {'use_nodes': material.use_nodes,
                'shader_output': shader_output}

    @classmethod
    def set_material_properties(cls, material, material_info):
        if not material_info:
            return
        
        material.use_nodes = material_info['use_nodes']
        shader_output = material_info['shader_output']
        shader_node = material.node_tree.nodes.get(delimiter_join('Plx', 'Shader'))

        if shader_output and shader_node:
            shader_node.shader_output = shader_output
