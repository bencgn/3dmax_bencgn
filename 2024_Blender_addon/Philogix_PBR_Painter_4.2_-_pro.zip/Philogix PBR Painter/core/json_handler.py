import bpy, json

class JsonDataHandler:
    @staticmethod
    def read_json(self, json_string) -> dict:
        try:
            return json.loads(json_string)
        except json.JSONDecodeError:
            # Xử lý lỗi nếu chuỗi JSON không hợp lệ
            return None
    @staticmethod
    def write_json(self, data):
        # Chuyển đổi đối tượng Python thành chuỗi JSON
        return json.dumps(data, indent=4)

class JsonHandler():
    @staticmethod
    def json_string_to_dict(json_string) -> dict:
        return json.loads(json_string)

    @staticmethod
    def dict_to_json_string(dict):
        return json.dumps(dict, indent=4)