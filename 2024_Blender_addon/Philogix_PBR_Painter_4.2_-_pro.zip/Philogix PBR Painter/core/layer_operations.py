import bpy, os

from bpy.types import (
    Material, 
    ShaderNodeTree,
    )

from ..core.structure.channel_layer_manager import PlxChannelLayerManager
from ..core.structure.material_layer_manager import PlxMaterialLayerManager

from ..utils.general_utilities import delimiter_join
from ..utils.layer_utilities import update_material_layers, update_channel_layers

from ..properties import properties_update

class LayerOperationsManager:
    copied_layers = {}

    @classmethod
    def copy_layer_properties(cls, layer):
        """
        Copies the properties of a single layer.
        """
        layer_id = delimiter_join(layer.ID)
        node_tree = layer.origin_node_tree

        mix_node = node_tree.nodes.get(delimiter_join(layer_id, 'MixLayer'))
        opacity_node = node_tree.nodes.get(delimiter_join(layer_id, 'MixOpacity'))

        blend_type = mix_node.blend_type if mix_node else None
        opacity = opacity_node.inputs[0].default_value if opacity_node else None

        return blend_type, opacity

    @classmethod
    def copy_layer(cls, layer):
        """
        Copies a single layer.
        """
        cls.copied_layers.clear()
        blend_type, opacity = cls.copy_layer_properties(layer)
        cls.copied_layers[layer.node_group] = [blend_type, opacity]

    @classmethod
    def copy_multiple_layers(cls, layers):
        """
        Copies multiple layers.
        """
        cls.copied_layers.clear()
        for layer in layers:
            blend_type, opacity = cls.copy_layer_properties(layer)
            cls.copied_layers[layer.node_group] = [blend_type, opacity]

    @classmethod
    def paste_layers(cls, context, layers_props, is_linked):
        origin_data = layers_props.id_data

        func_mapping = {
            Material:(PlxMaterialLayerManager(origin_data).add, update_material_layers),
            ShaderNodeTree: (PlxChannelLayerManager(origin_data).add, update_channel_layers),
        }

        add_layer_func, update_layers_func = func_mapping[type(origin_data)]

        for copied_layer_group, blend_data in cls.copied_layers.items():
            new_layer = add_layer_func('NONE')
            layer_node = new_layer.layer_node

            bpy.data.node_groups.remove(layer_node.node_tree)
            layer_node.node_tree = copied_layer_group

            if not is_linked:
                new_layer.make_local()
                new_layer.node_group.PlxProps.name += ' (copy)'

            mix_node = new_layer.origin_node_tree.nodes.get(delimiter_join(new_layer.ID, 'MixLayer'))
            opacity_node = new_layer.origin_node_tree.nodes.get(delimiter_join(new_layer.ID, 'MixOpacity'))

            if mix_node and opacity_node:
                mix_node.blend_type = blend_data[0]
                opacity_node.inputs[0].default_value = blend_data[1]

        update_layers_func(origin_data)
        
        if copied_layer_group.PlxProps.layer_type == "IMAGE":
            properties_update.channel_layer_index_update(new_layer.node_group.PlxProps, context)
