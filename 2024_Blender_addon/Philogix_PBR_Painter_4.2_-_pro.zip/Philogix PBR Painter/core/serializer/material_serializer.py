import bpy
from .node_tree_serializer import NodeTreeDataSerializer

class MaterialDataSerializer:
    def __init__(self, material):
        self.material = material

    def to_dict(self):
        node_tree_info = 'None'
        if self.material.node_tree:
            node_tree_serializer = NodeTreeDataSerializer(self.material.node_tree)
            node_tree_info = node_tree_serializer.to_dict()

        return {
            "type_name": "Material",
            "name": self.material.name,
            "use_nodes": self.material.use_nodes,
            "node_tree": node_tree_info
        }

    def from_dict(self, asset_dict):
        self.material.name = asset_dict["name"]
        self.material.use_nodes = asset_dict["use_nodes"]

        if self.material.node_tree:
            self.material.node_tree.nodes.clear()
            node_tree_serializer = NodeTreeDataSerializer(self.material.node_tree)
            node_tree_serializer.from_dict(asset_dict["node_tree"])

        return self.material