import os, bpy
import functools

from bpy.types import Brush
from bpy.types import Image
from bpy.types import Material
from bpy.types import ShaderNodeTree

from ...addon.distribution import AssetCollection
from ...addon.distribution import PreviewsCollection

from ..image_manager import ImageManager
from .file_serializer import AssetFile
from .brush_serializer import BrushSerialization
from .material_serializer import MaterialDataSerializer
from .node_tree_serializer import NodeTreeDataSerializer
from ..bpy_data_manager import BpyDataManager

from ...utils import data_definitions
from ...utils.file_utilities import get_image_extension
from ...utils.general_utilities import get_data_directory, get_temp_directory, make_uid, print_message, MessageType

class PlxAsset:
    @classmethod
    def insert_asset(cls, asset, is_system, create_preview=False):
        if asset.PlxAssetId in AssetCollection.assets:
            print_message('Asset id already exists in the collection!', MessageType.WARNING)
            return
        
        cls._set_default_asset_info(asset)
        cls.write_asset(asset, is_system, collect_files=True, create_preview=create_preview)

    @classmethod
    def save_asset(cls, asset, is_system, collect_files=True, create_preview=True):
        asset_id = asset.PlxAssetId

        if asset_id not in AssetCollection.assets:
            print_message("Could not find assert in collection!", MessageType.WARNING)
            return

        cls.write_asset(asset, is_system, collect_files, create_preview)

    @classmethod
    def load_asset(cls, asset_id):
        asset_info = AssetCollection.assets.get(asset_id)

        if not asset_info:
            raise ValueError(f"Asset not found: '{asset_id}'")
        
        is_system = asset_info['is_system']
        rna_type = asset_info['type_name']
        asset_type = asset_info['asset_type']

        data_directory = get_data_directory(is_system, asset_type)
        asset_path = os.path.join(data_directory, f"{asset_id}.plx{rna_type[0]}")

        if not os.path.exists(asset_path):
            #AssetCollection.remove_asset(asset_id)
            raise ValueError(f"Asset file not found: '{asset_path}'")
        
        # Load data json file
        asset_file = AssetFile(asset_path)
        asset_info = asset_file.load_data_json()

        return AssetSerializer.from_dict(asset_info)


    @classmethod
    def import_file(cls, asset_path, make_new_uid=True, is_system=False):
        asset_file = AssetFile(asset_path)
        asset_info = asset_file.load_data_json()

        if make_new_uid:
            while asset_info["id"] in AssetCollection.assets:
                asset_info["id"] = make_uid()

        extracted_files = asset_file.extract_files(asset_info["id"])

        # Add to Asset Collection
        preview_file, preview_path = next(((name, path) for name, path in extracted_files.items() if "_Preview" in name), (None, None))
        if preview_file:
            PreviewsCollection.add_preview(asset_info["id"], preview_path)
        AssetCollection.add_asset(asset_info["id"], asset_info["name"], None, asset_info["type_name"], None, asset_info["category"], preview_path, is_system)
        return AssetSerializer.from_dict(asset_info)

    @classmethod
    def export_file(cls, asset, file_path):
        cls._set_default_asset_info(asset)

        temp_name = f"Plx_Temp_{asset.name}"
        asset = asset.copy()

        # PATH
        temp_directory = get_temp_directory()
        asset_directory = os.path.join(temp_directory, asset.PlxAssetId)
        preview_path = os.path.join(asset_directory, asset.PlxAssetId + '_Preview.PNG')
        images_path_list = AssetImageCollector.collect_asset_images(asset, asset_directory, False)

        # OBJECT
        asset_dict = AssetSerializer.to_dict(asset)
        asset_file = AssetFile(file_path)
        asset_file.save_data_json(asset_dict)
        asset_file.insert_files(images_path_list)
        asset.name = temp_name

        AssetPreviewCreator.create_preview(asset, preview_path, file_path, True)

    @classmethod
    def write_asset(cls, asset, is_system, collect_files=False, create_preview=False):
        asset.PlxAssetId = make_uid() if len(asset.PlxAssetId) < 20 else asset.PlxAssetId

        temp_name = f"Plx_Temp_{asset.name}"
        asset = asset.copy()
        asset_id = asset.PlxAssetId
        asset_name = asset.PlxAssetName
        asset_type = asset.PlxAssetType
        asset_category = asset.PlxAssetCategory
        rna_type = asset.rna_type.identifier
        
        data_directory = get_data_directory(is_system, asset_type)

        images_directory = os.path.join(data_directory, "Images")
        asset_path = os.path.join(data_directory, f"{asset_id}.plx{rna_type[0].lower()}")
        preview_path = os.path.join(data_directory, "Previews", asset.PlxAssetId + '_Preview.PNG')

        if collect_files:
            AssetImageCollector.collect_asset_images(asset, images_directory, True)

        asset_dict = AssetSerializer.to_dict(asset)
        asset_file = AssetFile(asset_path)
        asset_file.save_data_json(asset_dict)
        asset.name = temp_name

        if asset_id in AssetCollection.assets:
            AssetCollection.update_asset(asset)
        else:
            index_numbers = (int(asset_info['index']) for asset_info in AssetCollection.assets.values() if asset_info['asset_type'] == asset_type)
            index = max(index_numbers, default=0) + 1
            AssetCollection.add_asset(asset_id, asset_name, index, rna_type, asset_type, asset_category, preview_path, is_system)

        AssetCollection.update_collection_file(asset_id)

        if create_preview:
            AssetPreviewCreator.create_preview(asset, preview_path, is_system=is_system)
        else:
            BpyDataManager.remove_data(asset)
        
    @classmethod
    def _set_default_asset_info(cls, asset):
        temp_asset_id = asset.PlxAssetId
        asset.PlxAssetId = ''

        asset.PlxAssetName = asset.name if not asset.PlxAssetName else asset.PlxAssetName
        asset.PlxAssetCategory = 'other' if not asset.PlxAssetCategory else asset.PlxAssetCategory
        asset.PlxAssetId = make_uid() if not temp_asset_id else temp_asset_id
        
class AssetSerializer:
    @classmethod
    def to_dict(cls, asset) -> dict:
        type_mapping = {
            Brush: lambda a: BrushSerialization(a).to_dict(),
            Material: lambda a: MaterialDataSerializer(a).to_dict(),
            ShaderNodeTree: lambda a: NodeTreeDataSerializer(a).to_dict()
        }

        asset_func = type_mapping.get(type(asset))

        if not asset_func:
            raise ValueError(f"AssetSerializer.to_dict(): Unsupported data type! '({type(asset)})'")
        
        return {
            "id": asset.PlxAssetId,
            "name": asset.PlxAssetName,
            "asset_type": asset.PlxAssetType,
            "category": asset.PlxAssetCategory,
            "type_name": asset.rna_type.identifier,
            "asset_info": asset_func(asset)
            }
    
    @classmethod
    def from_dict(cls, asset_dict):
        asset_info = asset_dict['asset_info']

        type_mapping = {
            "Brush": (lambda name: bpy.data.brushes.new(name), lambda a: BrushSerialization(a).from_dict(asset_info)),
            "Material": (lambda name: bpy.data.materials.new(name), lambda a: MaterialDataSerializer(a).from_dict(asset_info)),
            "ShaderNodeTree": (lambda name: bpy.data.node_groups.new(name, type='ShaderNodeTree'), lambda a: NodeTreeDataSerializer(a).from_dict(asset_info))
        }
        
        asset_creator, asset_func = type_mapping.get(asset_dict["type_name"], (None, None))

        if not asset_func:
            raise ValueError(f"AssetSerializer.from_dict(): Unsupported data type! '({asset_dict['type_name']})'")
        
        asset = asset_creator(asset_info['name'])

        asset.PlxAssetType = asset_dict.get("asset_type", "Defaults")
        asset.PlxAssetCategory = asset_dict["category"]
        asset.PlxAssetName = asset_dict["name"]
        asset.PlxAssetId = asset_dict["id"]

        return asset_func(asset)
    
class AssetImageCollector:
    @classmethod
    def _get_image_filename(cls, image):
        if image.filepath_raw:
            image_filename = os.path.basename(image.filepath_raw)
            return os.path.splitext(image_filename)
        else:
            return (image.name, f".{get_image_extension(image.file_format)}")

    @classmethod
    def create_image_newpath(cls, collect_dir, image, save_random_name):
        image_name, image_extension = cls._get_image_filename(image)

        if save_random_name and not image_name.startswith('PLX'):
            image_name = f"PLX_{make_uid()}"

        return os.path.join(collect_dir, f"{image_name}{image_extension}")

    @classmethod
    def collect_brush_image(cls, brush, image_dir, save_random_name=False):
        images_path_list = []

        for texture_attribute in ['mask_texture', 'texture']:
            texture = getattr(brush, texture_attribute, None)
            if texture and hasattr(texture, 'image') and texture.image:
                image_newpath = cls.create_image_newpath(image_dir, texture.image, save_random_name)
                texture.image = ImageManager.save_copy(texture.image, image_newpath)
                images_path_list.append(image_newpath)
                
        return images_path_list

    @classmethod
    def collect_node_tree_images(cls, node_tree, collect_dir, save_random_name=False):
        images_path_list = []
        
        for node in node_tree.nodes:
            if node.bl_idname == 'ShaderNodeTexImage':
                image_newpath = cls.create_image_newpath(collect_dir, node.image, save_random_name)
                node.image = ImageManager.save_copy(node.image, image_newpath)
                images_path_list.append(image_newpath)

            elif node.bl_idname == 'ShaderNodeGroup':
                sub_paths = cls.collect_node_tree_images(node.node_tree, collect_dir, save_random_name)
                images_path_list.extend(sub_paths)
                
        return images_path_list

    @classmethod
    def collect_asset_images(cls, asset, images_directory, random_name):
        type_mapping = {
            Brush: lambda: cls.collect_brush_image(asset, images_directory, random_name),
            Material: lambda: cls.collect_node_tree_images(asset.node_tree, images_directory, random_name),
            ShaderNodeTree: lambda: cls.collect_node_tree_images(asset, images_directory, random_name)
        }

        asset_func = type_mapping.get(type(asset))
        if not asset_func:
            raise ValueError(f"NodeGroupAsset.collect_images(): Unsupported data type! '({type(asset)})'")
        
        return asset_func()

class AssetPreviewCreator:
    @classmethod
    def _get_smart_input_icons(cls, node_group):
        bake_maps = data_definitions.get_bake_list()
        inputs_node = node_group.nodes.get('In')
        if not inputs_node:
            return []
        for bake in bake_maps.values():
            image_name = bake['image_name']
            if len(inputs_node.outputs[image_name].links) > 0:
                return ['is_smart']
        return []

    @classmethod
    def _get_pbr_workfow_icons(cls, node_group):
        out_node = node_group.nodes.get('Out')

        if not out_node:
            return []

        is_metallic = any(out_node.inputs.get(ch) and out_node.inputs.get(ch).links for ch in data_definitions.metallic_channels)
        is_specular = any(out_node.inputs.get(ch) and out_node.inputs.get(ch).links for ch in data_definitions.specular_channels)

        if is_metallic and is_specular:
            return ['is_both']
        elif is_metallic:
            return ['is_metallic']
        elif is_specular:
            return ['is_specular']

        return []

    @classmethod
    def _get_node_tree_temp_images(cls, node_tree):
        temp_images = set()
        for node in node_tree.nodes:
            if node.bl_idname == 'ShaderNodeTexImage' and node.image:
                temp_images.add(node.image)

            elif node.bl_idname == 'ShaderNodeGroup':
                sub_images = cls._get_node_tree_temp_images(node.node_tree)
                temp_images = temp_images.union(sub_images)

        return temp_images
    
    @classmethod
    def _set_projection(cls, asset):
        """Recursively set the projection for nodes."""
        projection_settings = {
            'ShaderNodeTexImage': ('projection', 'FLAT'),
            'ShaderNodeTexMusgrave': ('musgrave_dimensions', '2D'),
            'ShaderNodeTexNoise': ('noise_dimensions', '2D'),
            'ShaderNodeTexWhiteNoise': ('noise_dimensions', '2D'),
            'ShaderNodeTexVoronoi': ('voronoi_dimensions', '2D')
        }

        # Convert node type keys to a set for faster membership checks
        node_types = set(projection_settings.keys())

        for node in asset.nodes:
            if not node.hide and node.bl_idname in node_types:
                settings = projection_settings[node.bl_idname]
                for key, value in zip(settings[::2], settings[1::2]):
                    setattr(node, key, value)

            elif node.bl_idname == 'ShaderNodeGroup':
                cls._set_projection(node.node_tree)

    @classmethod
    def create_brush_preview(cls, brush):                        
        sources = [(brush.use_custom_icon and brush.icon_filepath, brush),
                (brush.mask_texture, brush.mask_texture),
                (brush.texture, brush.texture)]

        for condition, source in sources:
            if condition and getattr(source, 'preview'):
                source.asset_generate_preview()
                return source.preview, [], []
        
        return None, None, None
    
    @classmethod
    def create_material_preview(cls, material):
        material.asset_generate_preview()
        return material.preview, [], []
            
    @classmethod
    def create_smart_surface_asset_preview(cls, node_group):
        return cls.create_smart_asset_preview(node_group, 'e93bef1d41de4a8c975f')

    @classmethod
    def create_smart_material_asset_preview(cls, node_group):
        image_preview, icons, temp_datas = cls.create_smart_asset_preview(node_group, 'c46dfcbde7f145cab98a')
        icons += cls._get_pbr_workfow_icons(node_group)

        return image_preview, icons, temp_datas

    @classmethod
    def create_smart_asset_preview(cls, node_group, temp_material_id):
        temp_material = PlxAsset.load_asset(temp_material_id)
        main_node = temp_material.node_tree.nodes.get('Main Group')
        
        temp_datas = [main_node.node_tree, temp_material]
        main_node.node_tree = node_group

        cls._set_projection(node_group)
        temp_images = cls._get_node_tree_temp_images(temp_material.node_tree)

        temp_datas += list(temp_images)

        image_preview, _, _ = cls.create_material_preview(temp_material)
        icons = cls._get_smart_input_icons(node_group)

        return image_preview, icons, temp_datas

    @classmethod
    def create_preview(cls, asset, preview_path, zip_path=None, is_system=False):
        """Generate a data preview image."""
        type_mapping = {
            Brush: lambda: cls.create_brush_preview(asset),
            Material: lambda: cls.create_material_preview(asset),
            "Surfaces": lambda: cls.create_smart_surface_asset_preview(asset),
            "Materials": lambda: cls.create_smart_material_asset_preview(asset)
        }

        asset_func = type_mapping.get(type(asset)) or type_mapping.get(asset.PlxAssetType)

        if not asset_func:
            print_message(f"Creating previews for this type of asset is not supported! '({asset})", MessageType.WARNING)
            return
            
        image_preview, icons, temp_datas = asset_func()
        
        if not image_preview:
            print_message(f"Cannot create preview! '({asset.name})", MessageType.WARNING)
            return

        icons += ['is_user'] if not is_system else []
        icons += ['is_round_corner']
        temp_datas += [asset]

        bpy.app.timers.register(
            functools.partial(
                cls._wait_for_preview_completion,
                image_preview, 
                preview_path,
                zip_path,
                icons,
                temp_datas,
                cls._preview_completion))

    @staticmethod
    def _wait_for_preview_completion(image_preview, preview_path, zip_path, icons, temp_datas, callback):
        if (not image_preview.image_pixels_float[32003] 
            or bpy.app.is_job_running('RENDER_PREVIEW')):
            return 0.5
        
        callback(image_preview, preview_path, zip_path, icons, temp_datas)
        return None

    @staticmethod
    def _preview_completion(image_preview, preview_path, zip_path, icons, temp_datas):
        icons_mapping = {
            'is_both': ('DUAL_DATA.png', 'add', (100, 7), 0.85),
            'is_specular': ('S_DATA.png', 'add', (100, 7), 0.85),
            'is_metallic': ('M_DATA.png', 'add', (100, 7), 0.85),
            'is_smart': ('SMART_DATA.png', 'add', (7, 7), 0.85),
            'is_user': ('USER_DATA.png', 'add', (100, 100), 0.85),
            'is_round_corner': ('BRUSH_MASK.png', 'mask', (0, 0), 1)
        }

        image_size = image_preview.image_size
        preview_image = bpy.data.images.new('Plx Temp Preview Render', image_size[0], image_size[1], alpha=True)
        preview_image.pixels[:] = image_preview.image_pixels_float

        temp_datas += [preview_image]

        icon_directory = get_data_directory(True, 'Icons')

        for icon_type in icons:
            file_name, overlay_type, location, opacity = icons_mapping[icon_type]
            temp_icon_image = bpy.data.images.load(os.path.join(icon_directory, file_name))
            ImageManager.combine_images(preview_image, temp_icon_image, overlay_type, location, opacity)
            temp_datas += [temp_icon_image]
        
        ImageManager.save(preview_image, preview_path, overwrite=True)

        if zip_path:
            AssetFile(zip_path).insert_files([preview_path])
        else:
            preview_key = os.path.basename(preview_path).split('.')[0].replace("_Preview", "")
            PreviewsCollection.add_preview(preview_key, preview_path)

        for data in temp_datas:
            BpyDataManager.remove_data(data)

        print_message("Preview Generation Finished!", MessageType.INFO)
