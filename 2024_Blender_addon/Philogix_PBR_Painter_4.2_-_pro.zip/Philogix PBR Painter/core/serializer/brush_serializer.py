import bpy

from .attribute_serializer import AttributesDataSerializer

class BrushSerialization:
    def __init__(self, brush):
        self.brush = brush
        self.attributes_serializer = AttributesDataSerializer(brush)

    def to_dict(self):
        return {
            "type_name": "Brush",
            "name": self.brush.name,
            "attrs": self.attributes_serializer.attrs_to_list()
        }

    def from_dict(self, asset_dict):
        self.brush.name = asset_dict["name"]
        self.attributes_serializer.list_to_attrs(asset_dict["attrs"])

        return self.brush