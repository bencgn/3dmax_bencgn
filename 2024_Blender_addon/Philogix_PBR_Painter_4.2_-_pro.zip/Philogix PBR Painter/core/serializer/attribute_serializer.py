import bpy, os
from mathutils import Vector, Euler, Color

from bpy.types import Image, ImageUser
from bpy.types import bpy_func, bpy_prop_array
from bpy.types import ColorMapping, CurveMapping, ColorRamp
from bpy.types import Text, Object, ParticleSystem, BrushTextureSlot

from ..path_converter import PathConverter
from .node_tree_serializer import NodeTreeDataSerializer

from ...utils.general_utilities import print_message, MessageType
from ...utils.asset_utilities import get_default_attrs


class CurveMappingConverter:
    @staticmethod
    def to_dict(curve_mapping):        
        def get_curve_points(curve):
            return [{"handle_type": p.handle_type, "location": list(p.location)}
                for p in curve.points]

        result_dict = {
            "black_level": list(curve_mapping.black_level),
            "clip_max_x": curve_mapping.clip_max_x,
            "clip_max_y": curve_mapping.clip_max_y,
            "clip_min_x": curve_mapping.clip_min_x,
            "clip_min_y": curve_mapping.clip_min_y,
            "tone": curve_mapping.tone,
            "use_clip": curve_mapping.use_clip,
            "white_level": list(curve_mapping.white_level),
            "curves": [
                {
                    "extend": getattr(curve, "extend", "None"),
                    "points": get_curve_points(curve),
                } for curve in curve_mapping.curves
            ]
        }

        return result_dict

    @staticmethod
    def from_dict(curve_mapping, value_dict) -> dict:
        if not curve_mapping:
            return

        def assign_attribute(obj, attr, value):
            if not hasattr(obj, attr):
                return
            elif isinstance(value, list):
                setattr(obj, attr, tuple(value))
            elif value != "None":
                setattr(obj, attr, value)

        def remove_all_curve_points(curve):
            while len(curve.points) > 2:
                curve.points.remove(curve.points[-1])

        def recreate_points(curve, total_points):
            for _ in range(total_points - len(curve.points)):
                curve.points.new(0, 0)

        def set_values_for_curve(curve, curve_dict):
            remove_all_curve_points(curve)
            recreate_points(curve, len(curve_dict["points"]))
            assign_attribute(curve, "extend", curve_dict["extend"])
                    
            for index, point_dict in enumerate(curve_dict["points"]):
                p = curve.points[index]
                p.handle_type = point_dict["handle_type"]
                p.location = tuple(point_dict["location"])

        for key, value in value_dict.items():
            if key != "curves":
                assign_attribute(curve_mapping, key, value)

        for index, curve_dict in enumerate(value_dict["curves"]):
            set_values_for_curve(curve_mapping.curves[index], curve_dict)

        curve_mapping.update()

class ColorRampConverter:
    @staticmethod
    def to_dict(color_ramp) -> dict:
        elements = []
        for element in color_ramp.elements:
            color_ramp_element = {
            "alpha": element.alpha,
            "color": list(element.color),
            "position": element.position}            
            elements.append(color_ramp_element)
        
        dict = {
        "hue_interpolation": color_ramp.hue_interpolation,
        "interpolation": color_ramp.interpolation,
        "color_mode": color_ramp.color_mode,
        "elements": elements}
                
        return dict

    @staticmethod
    def from_dict(color_ramp, value_dict):
        if not color_ramp: 
            return
        
        color_ramp.color_mode = value_dict["color_mode"]
        color_ramp.interpolation = value_dict["interpolation"]
        color_ramp.hue_interpolation = value_dict["hue_interpolation"]
        
        elements = color_ramp.elements
        elements_list = value_dict["elements"]
        
        for index, element in enumerate(elements_list):
            if index in [0, len(elements_list)-1]:
                ele = elements[index]
            else:
                ele = elements.new(element["position"])
                
            ele.alpha = element["alpha"]
            ele.position = element["position"]
            ele.color = tuple(element["color"])

class ImageUserConverter:
    @staticmethod
    def to_dict(image_user) -> dict:
        return {
            "use_cyclic": image_user.use_cyclic,
            "frame_start": image_user.frame_start,
            "frame_offset": image_user.frame_offset,
            "frame_current": image_user.frame_current,
            "frame_duration": image_user.frame_duration,
            "use_auto_refresh": image_user.use_auto_refresh
        }
    @staticmethod
    def from_dict(image_user, value_dict):        
        if not image_user:
            return
        
        for key, value in value_dict.items():            
            setattr(image_user, key, value)

class ImageConverter:
    @staticmethod
    def to_dict(image):
        return {
            "image_name": image.name,
            "image_source": image.source,
            "alpha_mode": image.alpha_mode,
            "image_size": list(image.size),
            "image_file_format": image.file_format,
            "image_colorspace_settings": image.colorspace_settings.name,
            "image_filepath": PathConverter.to_list(image.filepath_from_user()),
        }
    
    @staticmethod
    def from_dict(value_dict):
        image_name = value_dict["image_name"]
        image_path = PathConverter.from_list(value_dict["image_filepath"])

        # Kiểm tra trước tiên nếu hình ảnh đã tồn tại
        image = bpy.data.images.get(image_name)
        if image and image.filepath_from_user() == image_path:
            return image

        # Tải hoặc tạo mới hình ảnh
        if os.path.exists(image_path):
            image = bpy.data.images.load(image_path)
        else:
            print_message(f"image not found {image_path}", MessageType.WARNING)
            image_size = value_dict["image_size"]
            image = bpy.data.images.new(image_name, image_size[0], image_size[1])

        # Update image properties
        image.source = value_dict.get("image_source", image.source)
        image.alpha_mode = value_dict.get("alpha_mode", image.alpha_mode)
        image.file_format = value_dict.get("image_file_format", image.file_format)

        # Safely update colorspace settings
        try:
            colorspace = value_dict.get("image_colorspace_settings", "Non-Color")
            image.colorspace_settings.name = colorspace
        except Exception as e:
            print_message(f"Error setting colorspace: {e}", MessageType.WARNING)
            image.colorspace_settings.name = "Non-Color"

        return image

class TextureConverter:
    @staticmethod
    def to_dict(texture):
        if not texture: 
            return 'None'
        
        node_tree_info = 'None'
        if texture.node_tree:
            node_tree_serializer = NodeTreeDataSerializer(texture.node_tree)
            node_tree_info = node_tree_serializer.to_dict()
        
        texture_name = texture.name if texture.name.startswith('PLXT_') else f"PLXT_{texture.name}"
            
        return {
            "texture_name": texture_name,
            "texture_type": texture.type,
            "use_nodes": texture.use_nodes,
            "attrs": AttributesDataSerializer(texture).attrs_to_list(),
            "node_tree": node_tree_info
        }
    
    @staticmethod
    def from_dict(value_dict):
        if value_dict == 'None': 
            return
        
        name = value_dict["texture_name"]
        type = value_dict["texture_type"]
        texture = bpy.data.textures.new(name, type)
        AttributesDataSerializer(texture).list_to_attrs(value_dict["attrs"])

        texture.use_nodes = value_dict["use_nodes"]
        if texture.node_tree:
            texture.node_tree.nodes.clear()
            node_tree_serializer = NodeTreeDataSerializer(texture.node_tree)
            node_tree_serializer.from_dict(value_dict["node_tree"])
        
        return texture
    
class TextureSlotConverter:
    @staticmethod
    def to_dict(texure_slot):
        return {
            "texture": TextureConverter.to_dict(texure_slot.texture),
            "attrs": AttributesDataSerializer(texure_slot).attrs_to_list(),
        }
    
    @staticmethod
    def from_dict(texure_slot, value_dict):
        texture = TextureConverter.from_dict(value_dict['texture'])
        texure_slot.texture = texture
        
        AttributesDataSerializer(texure_slot).list_to_attrs(value_dict["attrs"])


class AttributesDataSerializer:
    def __init__(self, object):
        self.object = object

    def attrs_to_list(self):
        attrs_list = []
        attrs = dir(self.object)
        for attr in attrs:
            attr_dict = self.attr_to_dict(attr)
            if attr_dict: 
                attrs_list.append(attr_dict)
        return attrs_list

    def list_to_attrs(self, attrs_list):
        errors = 0
        for attr_dict in attrs_list:    
            has_error = self.dict_to_attr(attr_dict)
            errors += int(has_error)
        return errors

    def dict_to_attr(self, attr_dict):
        value = attr_dict["value"]
        attr_path = attr_dict["attr_name"].split('.')
        type_name = attr_dict["type_name"]

        # Phân giải đối tượng và thuộc tính cuối cùng
        target_object, target_attr = self._resolve_attr_path(self.object, attr_path)
        
        if not target_object:
            print_message(f"Invalid Object!\nAttr: {attr_dict['attr_name']}")
            return True
        
        if not hasattr(target_object, target_attr):
            print_message(f"Object '{target_object}' does not exist attribute '{target_attr}'")
            return True

        type_conversion = {
            "bool": bool,
            "tuple": tuple,
            "bpy_prop_array": tuple,
            "Color": lambda c: Color(tuple(c)),
            "Vector": lambda v: Vector(tuple(v)),
            "Euler": lambda e: Euler(tuple(e), 'XYZ'),
            "Text": lambda v: bpy.data.texts.get(v),
            "Object": lambda v: bpy.data.objects.get(v),
            "ParticleSystem": lambda v: bpy.data.objects[attr_dict["object_name"]].particle_systems.get(v),

            "Image": ImageConverter.from_dict}

        plx_converter = {
            "ImageUser": ImageUserConverter.from_dict,
            "ColorRamp": ColorRampConverter.from_dict,
            "CurveMapping": CurveMappingConverter.from_dict,
            "BrushTextureSlot": TextureSlotConverter.from_dict
            }.get(type_name)

        if plx_converter:
            plx_converter(getattr(target_object, target_attr), value)
            return False
        
        value = type_conversion.get(type_name, lambda v: v)(value)

        try:
            setattr(target_object, target_attr, value)

        except Exception as e:
            print_message(f"{str(e)}\nMissing Data: {type(self.object)} {self.object.name}", MessageType.WARNING)
            return True
        
        return False

    def attr_to_dict(self, attr):
        if attr in get_default_attrs():
            return
        
        value = getattr(self.object, attr, None)
        not_supported_type = [bpy_func, ColorMapping]

        if value is None or type(value) in not_supported_type:
            return
        
        type_mapping = {
            str: {"type_name": "str", "func": str},
            int: {"type_name": "int", "func": int},
            list: {"type_name": "list", "func": list},
            float: {"type_name": "float", "func": float},
            bpy_prop_array: {"type_name": "bpy_prop_array", "func": list},

            bool: {"type_name": "bool", "func": lambda x: int(x)},
            Color: {"type_name": "Color", "func": lambda x: list(x)},
            tuple: {"type_name": "tuple", "func": lambda x: list(x)},

            Euler: {"type_name": "Euler", "func": lambda x: list(x[:])},
            Vector: {"type_name": "Vector", "func": lambda x: list(x.to_tuple())},

            Text: {"type_name": "Text", "func": lambda x: x.name},
            Object: {"type_name": "Object", "func": lambda x: x.name},
            ParticleSystem: {"type_name": "ParticleSystem", "func": lambda x: x.name},

            Image: {"type_name": "Image", "func": ImageConverter.to_dict},
            ColorRamp: {"type_name": "ColorRamp", "func": ColorRampConverter.to_dict},
            ImageUser: {"type_name": "ImageUser", "func": ImageUserConverter.to_dict},
            CurveMapping: {"type_name": "CurveMapping", "func": CurveMappingConverter.to_dict},
            BrushTextureSlot: {"type_name": "BrushTextureSlot", "func": TextureSlotConverter.to_dict},
        }

        type_info = type_mapping.get(type(value))

        if type_info:
            type_name = type_info["type_name"]
            conversion_func = type_info["func"]
            dict = {"attr_name": attr, "type_name": type_name, "value": conversion_func(value)}
        else:
            print_message(f"Can not processing attr type:\n {type(value)} attr: {attr} object: {self.object}", MessageType.ERROR)
            return

        return dict
    
    # Hàm trợ giúp để phân giải chuỗi thuộc tính
    def _resolve_attr_path(self, obj, path):
        for attr in path[:-1]:
            parent_obj = obj
            obj = getattr(parent_obj, attr, None)
            if obj is None:
                return parent_obj, attr
        return obj, path[-1]
