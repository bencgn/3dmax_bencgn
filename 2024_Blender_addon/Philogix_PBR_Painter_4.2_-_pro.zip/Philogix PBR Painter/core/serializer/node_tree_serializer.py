import bpy

from bpy.types import (
    NodeSocketInt, 
    NodeSocketIntFactor, 
    NodeSocketIntUnsigned,
    NodeSocketIntPercentage,

    NodeSocketFloat, 
    NodeSocketFloatTime, 
    NodeSocketFloatAngle, 
    NodeSocketFloatFactor, 
    NodeSocketFloatDistance, 
    NodeSocketFloatUnsigned,
    NodeSocketFloatPercentage, 

    NodeSocketVector, 
    NodeSocketVectorXYZ,
    NodeSocketVectorEuler, 
    NodeSocketVectorVelocity, 
    NodeSocketVectorDirection, 
    NodeSocketVectorTranslation, 
    NodeSocketVectorAcceleration, 
    
    NodeSocketBool, 
    NodeSocketColor, 
    NodeSocketShader, 
    NodeSocketString, 
    NodeSocketVirtual,  
    NodeSocketRotation,
)

from ...utils.node_utilities import get_node_index
from ...utils.general_utilities import print_message, MessageType

from ..node.group_creator import PlxGroupCreator
from . import attribute_serializer

class SocketsConverter:
    @staticmethod
    def to_list(sockets):
        socket_type_mapping = {
            NodeSocketBool: "NodeSocketBool",
            NodeSocketColor: "NodeSocketColor",
            NodeSocketString: "NodeSocketString",
            NodeSocketShader: "NodeSocketShader",
            NodeSocketVirtual: "NodeSocketVirtual",
            NodeSocketRotation: "NodeSocketRotation",

            NodeSocketInt: "NodeSocketInt",
            NodeSocketIntFactor: "NodeSocketIntFactor",
            NodeSocketIntUnsigned: "NodeSocketIntUnsigned",
            NodeSocketIntPercentage: "NodeSocketIntPercentage",

            NodeSocketFloat: "NodeSocketFloat",
            NodeSocketFloatTime: "NodeSocketFloatTime",
            NodeSocketFloatAngle: "NodeSocketFloatAngle",
            NodeSocketFloatFactor: "NodeSocketFloatFactor",
            NodeSocketFloatDistance: "NodeSocketFloatDistance",
            NodeSocketFloatUnsigned: "NodeSocketFloatUnsigned",
            NodeSocketFloatPercentage: "NodeSocketFloatPercentage",

            NodeSocketVector: "NodeSocketVector",
            NodeSocketVectorXYZ: "NodeSocketVector",
            NodeSocketVectorEuler: "NodeSocketVector",
            NodeSocketVectorVelocity: "NodeSocketVector",
            NodeSocketVectorDirection: "NodeSocketVector",
            NodeSocketVectorTranslation: "NodeSocketVector",
            NodeSocketVectorAcceleration: "NodeSocketVector",
        }

        def socket_to_dict(socket):
            type_name = type(socket)

            if type_name in socket_type_mapping:
                return {
                    "type_name": socket_type_mapping[type_name],
                    "name": socket.name,
                    "identifier": socket.identifier,
                    "socket_attrs": attribute_serializer.AttributesDataSerializer(socket).attrs_to_list()
                }
            else:
                print_message(f"Cannot process input type: {type_name}", MessageType.WARNING)
                raise ValueError(f"socket_to_dict() cannot process input type: {type_name}")

        sockets_list = []
        for socket in sockets:
            socket_dict = socket_to_dict(socket)
            if socket_dict:
                sockets_list.append(socket_dict)

        return sockets_list

    @staticmethod
    def from_list(sockets, sockets_list, is_node_group=False):
        def _get_socket_by_identifier(sockets, identifier):
            return next((socket for socket in sockets if socket.identifier == identifier), None)
                
        for i, socket_dict in enumerate(sockets_list):
            try:
                socket = None
                identifier = socket_dict.get("identifier")

                if identifier and not is_node_group:
                    socket = _get_socket_by_identifier(sockets, identifier)
                elif len(sockets) == len(sockets_list):
                    socket = sockets[i]

                if not socket:
                    socket = sockets.get(socket_dict["name"])

                errors = attribute_serializer.AttributesDataSerializer(socket).list_to_attrs(socket_dict["socket_attrs"])

                if errors > 0:
                    socket_name = socket.name if socket else f"Socket not found: {socket_dict['name']}"
                    print_message(
                        f"Has {errors} Warnings\n"
                        f"Node: {sockets.id_data.name}\n"
                        f"Socket: {socket_name}", MessageType.WARNING)

            except Exception as e:
                print_message(f"Missing socket in node: {sockets.path_from_id()}"
                              f"Error: {e}", MessageType.ERROR)

class LinkDataSerializer:
    def __init__(self, node_tree):
        self.node_tree = node_tree

    def to_list(self):
        links = self.node_tree.links
        nodes = self.node_tree.nodes
        
        links_list = []
        for link in links:
            link_dict = {}
            for node_index, n in enumerate(nodes):
                inputs = n.inputs
                outputs = n.outputs
                for index, o in enumerate(outputs):
                    if link.from_socket == o:
                        link_dict["from_node_index"] = node_index
                        link_dict["from_socket_index"] = index
                        link_dict["from_socket_name"] = o.name
                for index, i in enumerate(inputs):
                    if link.to_socket == i:
                        link_dict["to_node_index"] = node_index
                        link_dict["to_socket_index"] = index
                        link_dict["to_socket_name"] = i.name
            links_list.append(link_dict)
            
        return links_list

    def from_list(self, ret_nodes, links_list):

        def get_socket_by_name(sockets, name, index):
            for i, socket in enumerate(sockets):
                if name == socket.name and i == index:
                    return socket
            for i, socket in enumerate(sockets):
                if name == socket.name:
                    return socket

            return None
        
        links = self.node_tree.links
        for link in links_list:
            to_node_index = link["to_node_index"]
            to_socket_index = link["to_socket_index"]
            from_node_index = link["from_node_index"]
            from_socket_index = link["from_socket_index"]
            
            to_node = ret_nodes[to_node_index]
            from_node = ret_nodes[from_node_index]
            
            to_socket = get_socket_by_name(to_node.inputs, link["to_socket_name"], to_socket_index)
            from_socket = get_socket_by_name(from_node.outputs, link["from_socket_name"], from_socket_index)

            if to_socket == None or from_socket == None: continue
            
            links.new(from_socket, to_socket)

class NodesDataSerializer:
    def __init__(self, node_tree):
        self.node_tree = node_tree
        self.link_converter = LinkDataSerializer(node_tree)
        
    def to_dict(self):
        if not self.node_tree: 
            return {}

        nodes_list = []
        for node in self.node_tree.nodes:
            attribute_converter = attribute_serializer.AttributesDataSerializer(node)
            node_dict = {}
            node_dict["node_name"] = node.bl_idname
            node_dict["name"] = node.name
            node_dict["label"] = node.label
            node_dict["parent"] = get_node_index(self.node_tree, node.parent)
            node_dict["attrs"] = attribute_converter.attrs_to_list()
            node_dict["outputs"] = SocketsConverter.to_list(node.outputs)
            node_dict["inputs"] = SocketsConverter.to_list(node.inputs)
            
            if node.bl_idname == "ShaderNodeGroup":
                node_dict["node_tree"] = NodeTreeDataSerializer(node.node_tree).to_dict()
                
            nodes_list.append(node_dict)

        links_list = self.link_converter.to_list()
        
        nodes_dict = {"nodes_list": nodes_list, "links_list": links_list}
        
        return nodes_dict

    def from_dict(self, nodes_dict):
        ret_nodes = []
        nodes_list = nodes_dict["nodes_list"]
        links_list = nodes_dict["links_list"]

        for node_data in nodes_list:
            node_type = node_data["node_name"]
            is_node_group = (node_type == "ShaderNodeGroup")
            curent_node = self.node_tree.nodes.get(node_data["name"])
            parent_node = self._get_parent_node(node_data["parent"])

            if not curent_node:
                curent_node = self.node_tree.nodes.new(type=node_type)

            if node_type == "ShaderNodeGroup":
                node_group = None
                group_name = node_data["node_tree"]['name']

                if node_data["node_tree"].get('asset_type') == 'Constant':
                    node_group = PlxGroupCreator.get(group_name)
                    
                if not node_group or node_group.PlxAssetType != 'Constant':
                    node_group = PlxGroupCreator.add(group_name)
                    NodeTreeDataSerializer(node_group).from_dict(node_data["node_tree"])

                curent_node.node_tree = node_group

            curent_node.name = node_data["name"]
            curent_node.label = node_data["label"]
            curent_node.parent = parent_node

            attribute_converter = attribute_serializer.AttributesDataSerializer(curent_node)
            errors = attribute_converter.list_to_attrs(node_data["attrs"])
            SocketsConverter.from_list(curent_node.inputs, node_data["inputs"], is_node_group)
            SocketsConverter.from_list(curent_node.outputs, node_data["outputs"], is_node_group)

            if errors > 0:
                print_message(f"Has {errors} Warrings\nNode Group: {curent_node.id_data.name}\nNode: {curent_node.name}", MessageType.WARNING)
                            
            ret_nodes.append(curent_node)
            
        self.link_converter.from_list(ret_nodes, links_list)

    def _get_parent_node(self, parent_index):
        if parent_index != "None":
            return self.node_tree.nodes[parent_index]


class InterfaceDataSerializer:
    def __init__(self, interface):
        self.interface = interface

    def to_list(self):
        interfaces_list = []
        items_tree = self.interface.items_tree
        for item in items_tree:
            interface_dict = {
                'name': item.name,
                'parent': item.parent.index,
                'description': item.description,
                'in_out': getattr(item, 'in_out', 'None'),
                'type_name': getattr(item, 'bl_socket_idname', 'None'),
                "socket_attrs": attribute_serializer.AttributesDataSerializer(item).attrs_to_list()
            }
            interfaces_list.append(interface_dict)
            
        return interfaces_list

    def from_list(self, interface_list, in_out_default='None'):
        def _old_asset_prosess(socket_type):
            valid_socket_types = ['NodeSocketVector', 'NodeSocketShader', 'NodeSocketFloat', 'NodeSocketColor']
            return next(((st, socket_type.replace(st, '')) for st in valid_socket_types if st in socket_type), ('NodeSocketFloat', ''))

        for interface_info in interface_list:
            name = interface_info.get('name', 'Unnamed')
            description = interface_info.get('description', '')
            in_out = interface_info.get('in_out', in_out_default)
            parent_index = interface_info.get('parent', -1)
            socket_type = interface_info.get('type_name', 'NodeSocketFloat')
            parent = self.interface.items_tree[parent_index] if parent_index != -1 else None

            if in_out == 'None':
                new_interface = self.interface.new_panel(name, description=description, default_closed=False, parent=parent)
            else:
                socket_type, subtype = _old_asset_prosess(socket_type)
                new_interface = self.interface.new_socket(name, description=description, in_out=in_out, socket_type=socket_type, parent=parent)

                if subtype:
                    new_interface.subtype = subtype.upper()
                    
            errors = attribute_serializer.AttributesDataSerializer(new_interface).list_to_attrs(interface_info['socket_attrs'])

            if errors > 0:
                print_message(
                    f"Has {errors} Warrings\n"
                    f"Node Group: {self.interface.id_data.name}\n"
                    f"Interface: {new_interface.name}", MessageType.WARNING)

class NodeTreeDataSerializer:
    def __init__(self, node_tree):
        self.node_tree = node_tree
        self.nodes_serializer = NodesDataSerializer(self.node_tree)
        self.interface_converter = InterfaceDataSerializer(self.node_tree.interface)

    def to_dict(self):
        return {
            "name": self.node_tree.name,
            "type_name": 'ShaderNodeTree',
            "asset_type": self.node_tree.PlxAssetType,
            "interface": self.interface_converter.to_list(),
            "nodes_dict": self.nodes_serializer.to_dict()
        }

    def from_dict(self, node_tree_dict):
        if self.node_tree.PlxAssetType == 'None':
            self.node_tree.PlxAssetType = node_tree_dict.get('asset_type', 'None')
        self.interface_converter.from_list(node_tree_dict['interface'])
        self.nodes_serializer.from_dict(node_tree_dict["nodes_dict"])

        return self.node_tree