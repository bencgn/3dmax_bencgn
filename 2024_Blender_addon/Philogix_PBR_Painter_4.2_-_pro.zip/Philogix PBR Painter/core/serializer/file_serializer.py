import os, bpy, json, zipfile
from ...utils.general_utilities import  get_temp_directory, print_message

class AssetFile:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.zip_file_manager = ZipFileManager(file_path)

    def load_data_json(self) -> dict:
        asset_json = self.zip_file_manager.read_string_file('data.json')
        return json.loads(asset_json)

    def save_data_json(self, data_dict) -> dict:
        asset_json = json.dumps(data_dict)
        self.zip_file_manager.white_string_file('data.json', asset_json)

    def insert_files(self, file_paths):
        self.zip_file_manager.create_zip(file_paths)

    def extract_files(self, asset_id) -> dict:
        temp_directory = get_temp_directory()
        return self.zip_file_manager.extract_zip(os.path.join(temp_directory, asset_id))



class JsonFile:
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path        

    def read(self) -> dict:
        if not os.path.isfile(self.file_path):
            return {}
        try:
            with open(self.file_path, 'r') as json_file:
                return json.load(json_file)
        except json.JSONDecodeError:
            print_message(f"Error decoding JSON from {self.file_path}")
            return {}

    def write(self, json_data: dict) -> None:
        try:
            with open(self.file_path, 'w') as json_file:
                json.dump(json_data, json_file, indent=4)
        except IOError:
            print_message(f"IO error occurred when writing to {self.file_path}")

class ZipFileManager:
    def __init__(self, file_path: str):
        self.file_path = file_path

    def create_zip(self, path_list: list):
        with zipfile.ZipFile(self.file_path, 'a', zipfile.ZIP_LZMA) as zipf:
            for path in path_list:
                if os.path.exists(path):
                    zipf.write(path, os.path.basename(path))

    def extract_zip(self, extract_path: str) -> dict:
        extracted_files = []
        with zipfile.ZipFile(self.file_path, 'r') as zipf:
            zipf.extractall(extract_path)
            extracted_files = zipf.namelist()
            
        return {key: os.path.join(extract_path, key) for key in extracted_files}
        
    def read_string_file(self, file_name: str) -> str:
        if not os.path.exists(self.file_path):
            raise ValueError(f"No such file or directory: {self.file_path}")
        
        with zipfile.ZipFile(self.file_path, 'r') as zipf:
            with zipf.open(file_name) as file:
                return file.read().decode('utf-8')

    def white_string_file(self, file_name: str, string_data: str):
        with zipfile.ZipFile(self.file_path, 'w', zipfile.ZIP_LZMA) as zipf:
            zipf.writestr(file_name, string_data)

    def count_files_in_zip(self):
        try:
            with zipfile.ZipFile(self.file_path, 'r') as zipf:
                return len(zipf.filelist)
        except Exception as e:
            print_message(f"{e}")
            return 0
