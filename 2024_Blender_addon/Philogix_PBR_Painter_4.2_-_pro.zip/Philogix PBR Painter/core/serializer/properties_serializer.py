import bpy

from ...properties.export_properties import PHILOGIX_ChannelOutputImage
from .attribute_serializer import AttributesDataSerializer

from ...utils.general_utilities import print_message

class PropertiesSerializer:
    def __init__(self, object):
        self.object = object

    def to_dict(self, object=None):
        attrs_dict = {}
        target_object = self.object if object is None else object

        for attr in dir(target_object):
            attr_value = getattr(target_object, attr)
            if attr == 'slots':
                attrs_dict['slots'] = {slot.name: self.to_dict(slot) for slot in attr_value if slot.active}
            elif attr == 'image_settings':
                attrs_dict[attr] = self.to_dict(attr_value)
            elif isinstance(attr_value, PHILOGIX_ChannelOutputImage):
                attrs_dict[attr] = {
                    'name': attr_value.name, 
                    'bake_type': attr_value.bake_type, 
                    'color_space': attr_value.color_space, 
                    'normal_format': attr_value.normal_format,
                    'shader_output': attr_value.shader_output}
            else:
                attr_dict = AttributesDataSerializer(target_object).attr_to_dict(attr)
                if attr_dict:
                    attrs_dict[attr] = attr_dict["value"]
                    
        return attrs_dict

    def from_dict(self, object=None, attrs_dict={}):
        target_object = self.object if object is None else object

        for attr, value in attrs_dict.items():
            prop = getattr(target_object , attr, None)
            if prop is None:
                continue
            
            elif attr == 'slots':
                prop.clear()
                for slot_name, slot_attrs in value.items():
                    new_slot = prop.add()
                    new_slot.name = slot_name
                    self.from_dict(new_slot, slot_attrs)
            
            elif attr == 'image_settings':
                prop.file_format = value['file_format']
                self.from_dict(prop, value)

            elif isinstance(prop, PHILOGIX_ChannelOutputImage):
                self.from_dict(prop, value)

            else:
                try: 
                    setattr(target_object , attr, value)
                except Exception as e:
                    print_message(f"{str(e)}\nMissing Data: {type(target_object)}, Attr: {attr}")