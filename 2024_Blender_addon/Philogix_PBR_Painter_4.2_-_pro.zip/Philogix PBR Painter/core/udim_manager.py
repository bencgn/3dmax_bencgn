import bpy, bmesh, math
from ..utils.general_utilities import print_message, MessageType

UV_TOLERANCE = 0.001

class UdimManager:
    prev_object_mode = None

    @classmethod
    def get_valid_udim_titles(cls, context, object, uv_map_name):
        if not object or object.type != 'MESH':
            print_message("No valid mesh object found!", MessageType.INFO)
            return None
                
        cls.prev_object_mode = context.active_object.mode
        bpy.ops.object.mode_set(mode='EDIT')

        bm = bmesh.from_edit_mesh(object.data)
        uv_layers = bm.loops.layers.uv
        uv_layer = uv_layers.get(uv_map_name, uv_layers.active)

        if not uv_layer:
            print_message(f"UV map not found '{uv_map_name}' in '{object.name}'", MessageType.INFO)
            bm.free()
            return None

        grid_size = 10
        found_udims = set()

        for face in bm.faces:
            min_u, min_v, max_u, max_v = (math.inf, math.inf, -math.inf, -math.inf)

            for loop in face.loops:
                uv = loop[uv_layer].uv
                min_u = min(min_u, uv.x)
                min_v = min(min_v, uv.y)
                max_u = max(max_u, uv.x)
                max_v = max(max_v, uv.y)

            start_u_tile = max(0, math.floor(min_u))
            end_u_tile = min(grid_size - 1, math.ceil(max_u) - 1)
            start_v_tile = max(0, math.floor(min_v))
            end_v_tile = min(grid_size - 1, math.ceil(max_v) - 1)

            for u_tile in range(start_u_tile, end_u_tile + 1):
                for v_tile in range(start_v_tile, end_v_tile + 1):
                    udim_id = 1001 + u_tile + v_tile * grid_size
                    found_udims.add(udim_id)

        bm.free()
        bpy.ops.object.mode_set(mode=cls.prev_object_mode)
        
        found_udims = list(found_udims)
        found_udims.sort()
        
        return found_udims
    