import bpy

from ..addon import distribution

def get_asset_image_preview(asset):
    if hasattr(asset, 'image') and asset.image:
        image = asset.image
        if not image.preview and hasattr(image, 'preview_ensure'):
            image.preview_ensure()
        return image.preview.icon_id

    elif hasattr(asset, 'PlxAssetId') and asset.PlxAssetId:
        previews = distribution.PreviewsCollection.previews
        asset_id = asset.PlxAssetId
        return previews.get(f"{asset_id}", 1)
    
    return 1

def get_default_attrs():
    return [
        # Python
        '__le__', '__init__', '__hash__', '__gt__', '__getattribute__', '__ge__', '__format__',
        '__subclasshook__' , '__str__', '__sizeof__', '__setattr__', '__repr__', '__reduce_ex__', 
        '__dir__', '__delattr__', '__class__', '__reduce__', '__new__', '__ne__', '__lt__',  '__eq__',
        '__init_subclass__', '__annotations__', '__dict__', '__weakref__', '__doc__', '__module__', '__slots__',
        # bpy
        'bl_height_max', 'bl_height_min', 'bl_icon', 'bl_idname', 'bl_label', 
        'bl_description', 'bl_height_default', 'bl_subtype_label', 'bl_socket_idname',
        'bl_rna', 'bl_static_type', 'bl_width_default', 'bl_width_max', 'bl_width_min', 
        # Node default value
        'show_options', 'show_preview', 'show_texture', 'codeEffects',
        'internal_links', 'is_active_output', 'is_registered_node_type',
        'type', 'socket_value_update', 'draw_buttons', 'draw_buttons_ext', 
        'poll', 'poll_instance', 'rna_type', 'select', 'update', 'parent',
        'dimensions', 'inputs', 'outputs', 'input_template', 'output_template', 
        # Socket default value
        'description', 'display_shape', 'draw', 'draw_color', 'item_type',
        'enabled', 'is_linked', 'is_multi_input', 'is_output', 'label', 'socket_type',
        'interface', 'node_tree', 'texture_mapping', 'identifier', 'position', 'index',
        'link_limit', 'name', 'node', 'show_expanded', 'is_unavailable', 'hide_in_modifier',
        # Brush
        'is_missing',
        # Texture default attr
        'original', 'preview', 'sculpt_capabilities', 'texture', 'vertex_paint_capabilities', 
        'weight_paint_capabilities', 'brush_capabilities', 'image_paint_capabilities', 'users',
        'name_full', 'has_texture_angle_source', 'has_texture_angle', 'has_random_texture_angle',
        'is_library_indirect', 'is_evaluated', 'is_embedded_data', 'output_node', 'mask_texture',
        'users_material', 'use_nodes',
        # Philogix
        'PlxAssetId', 'PlxAssetName',  'PlxAssetType',  'PlxAssetCategory', 
        # Interface default value
        'attribute_domain', 'in_out',
        # Export and Bake
        'setting_extend', 'extend', 'active', 'specified_object', 'id']

def get_original_data_of_node_tree(node_tree):
    for material in bpy.data.materials:
        if material.node_tree == node_tree:
            return material
    return node_tree

def get_and_set_inputs(value_node, node_group):
    node_group_inputs = {interface.name: interface for interface in node_group.interface.items_tree if getattr(interface, 'in_out')=='INPUT'}
    for input in value_node.inputs:
        if not node_group or input.hide_value or not hasattr(input, 'default_value'):
            continue
        input.default_value = node_group_inputs[input.name].default_value
