import bpy

cycles_bake_list = {
    'DIFFUSE': {
        'bake_type': 'DIFFUSE',
        }, 
    'ROUGHNESS': {
        'bake_type': 'ROUGHNESS',
        }, 
    'TRANSMISSION': {
        'bake_type': 'TRANSMISSION',
        }, 
    'GLOSSY': {
        'bake_type': 'GLOSSY',
        }, 
    'NORMAL DirectX': {
        'bake_type': 'NORMAL',
        'normal_format': 'NEG_Y',
        }, 
    'NORMAL OpenGL': {
        'bake_type': 'NORMAL',
        'normal_format': 'POS_Y',
        }, 
    'EMIT': {
        'bake_type': 'EMIT',
        }, 
    'AO': {
        'bake_type': 'AO',
        }, 
    'UV': {
        'bake_type': 'UV',
        }, 
    'SHADOW': {
        'bake_type': 'SHADOW',
        }, 
    'POSITION': {
        'bake_type': 'POSITION',
        }, 
    'ENVIRONMENT': {
        'bake_type': 'ENVIRONMENT',
        }}

bake_list = {
    'Normal': {
        'bake_type': 'NORMAL',
        'bake_name': 'Normal Map',
        'coefficient': 16,
        'color_space': 'Non-Color',
        'image_name': 'Image_Normal',
        'default_value': (0.5,0.5,1,1),
        'props': {
            #'normal_format': ['POS_Y'],
            'apply_bevel': [False],
            'radius': [0.01, {
                'parent': 'apply_bevel',
                'value': True
                }]
            },
        'bake_socket': ('Material', 'Shader'),
        },

    'ID': {
        'bake_type': 'EMIT',
        'bake_name': 'ID Map',
        'coefficient': 16,
        'color_space': 'sRGB',
        'image_name': 'Image_ID',
        'default_value': (0,0,0,1),
        'props': {
            'color_source': ['Vertex Color'],
            'layer_name': ['', {'parent': 'color_source', 'value': 'Vertex Color'}]
            },
        'bake_socket': ('Vertex Color', 'Color'),
        },

    'Ambient Occlusion': {
        'bake_type': 'EMIT',
        'bake_name': 'Ambient Occlusion Map',
        'coefficient': 16,
        'color_space': 'Non-Color',
        'default_value': (1,1,1,1),
        'image_name': 'Image_Ambient Occlusion',
        'props': {
            'radius': [1]
            },
        'bake_socket': ('AO', 'AO'),
        },

    'Curvature': {
        'bake_type': 'EMIT',
        'bake_name': 'Curvature Map',
        'coefficient': 16,
        'color_space': 'Non-Color',
        'default_value': (0.5,0.5,0.5,1),
        'image_name': 'Image_Curvature',
        'props': {
            'radius': [0.0025]
            },
        'bake_socket': ('Mix', 2),
        },
}

metallic_channels = {
    'Base Color': {
        'prop': 'BaseColor',
        'prop_default': True,
        'description': 'Base Color',
        'ID': 0,
        'icon': 'EVENT_B',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0.8, 0.8, 0.8, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'sRGB'
    },

    'Metallic': {
        'prop': 'Metallic',
        'prop_default': True,
        'description': 'Metallic',
        'ID': 3,
        'icon': 'EVENT_M',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },

    'Roughness': {
        'prop': 'Roughness',
        'prop_default': True,
        'description': 'Roughness',
        'ID': 4,
        'icon': 'EVENT_R',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0.5,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },
}

specular_channels = {

    'Diffuse': {
        'prop': 'Diffuse',
        'prop_default': True,
        'description': 'Diffuse',
        'ID': 0,
        'icon': 'EVENT_D',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0.8, 0.8, 0.8, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'sRGB'
    },

    'Specular': {
        'prop': 'Specular',
        'prop_default': True,
        'description': 'Specular',
        'ID': 3,
        'icon': 'EVENT_S',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0, 0, 0, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'sRGB'
    },
    
    'Glossiness': {
        'prop': 'Glossiness',
        'prop_default': True,
        'description': 'Glossiness',
        'ID': 4,
        'icon': 'EVENT_G',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0.5,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },
}

common_pbr_channels = {

    'Subsurface': {
        'prop': 'Subsurface',
        'prop_default': False,
        'description': 'Subsurface',
        'ID': 1,
        'icon': 'EVENT_F',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },

    'Subsurface Color': {
        'prop': 'SubsurfaceColor',
        'prop_default': False,
        'description': 'Subsurface Color',
        'ID': 2,
        'icon': 'EVENT_C',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0.8, 0.8, 0.8, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'Non-Color'
    },    

    'Emission': {
        'prop': 'Emission',
        'prop_default': False,
        'description': 'Emission',
        'ID': 5,
        'icon': 'EVENT_E',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0, 0, 0, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'Non-Color'
    },

    'Alpha': {
        'prop': 'Alpha',
        'prop_default': False,
        'description': 'Alpha',
        'ID': 6,
        'icon': 'EVENT_A',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 1,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },

    'Height': {
        'prop': 'Height',
        'prop_default': True,
        'description': 'Height',
        'ID': 7,
        'icon': 'EVENT_H',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0.5,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },

    'Normal': {
        'prop': 'Normal',
        'prop_default': True,
        'description': 'Normal',
        'ID': 8,
        'icon': 'EVENT_N',
        'default_node_type': 'ShaderNodeRGB',
        'default_value': (0.5, 0.5, 1, 1),
        'socket_type': 'NodeSocketColor',
        'color_space': 'Non-Color',
        'bake_type': 'NORMAL',
    },

    'Transmission': {
        'prop': 'Transmission',
        'prop_default': False,
        'description': 'Transmission',
        'ID': 9,
        'icon': 'EVENT_T',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 0,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },

    'Layer Mask': {
        'prop': 'LayerMask',
        'prop_default': True,
        'description': 'Layer Mask (The Layer Mask channel controls the hidden or visible area of a material layer)',
        'ID': 11,
        'icon': 'MOD_MASK',
        'default_node_type': 'ShaderNodeValue',
        'default_value': 1,
        'min-max': [0, 1],
        'socket_type': 'NodeSocketFloat',
        'color_space': 'Non-Color'
    },    
}


def remove_idle_plx_data():
    for node_group in bpy.data.node_groups:
        if node_group.name.startswith('Plx_') and node_group.users == 0:
            bpy.data.node_groups.remove(node_group)

    for image in bpy.data.images:
        if image.name.startswith('Plx_') and image.users == 0:
            bpy.data.images.remove(image)

    for image in bpy.data.objects:
        if image.name.startswith('Plx_') and image.users == 0:
            bpy.data.objects.remove(image)

    for scene in bpy.data.scenes:
        if scene.name.startswith('Plx_') and scene.users == 0:
            bpy.data.scenes.remove(scene)

def get_cycles_bake_list():
    return cycles_bake_list 

def get_bake_list():
    return bake_list

def get_pbr_channels(workflow=None):
    if workflow is None:
        return {**metallic_channels, **specular_channels, **common_pbr_channels}

    if workflow == 'Metallic': 
        return {**metallic_channels, **common_pbr_channels}
    else: 
        return {**specular_channels, **common_pbr_channels}
    