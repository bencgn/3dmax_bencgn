import bpy
from . import data_definitions
from .general_utilities import delimiter_join, print_message, MessageType

def extract_number_from_label(label, prefix):
    parts = label.split()
    if label.startswith(prefix) and len(parts) == 2 and parts[-1].isdigit():
        return int(parts[-1])
    return 0

def make_layer_node_label(node_tree, prefix):
    used_labels = {node.node_tree.PlxProps.name for node in node_tree.nodes if hasattr(node, 'node_tree') and hasattr(node.node_tree, 'PlxProps')}
    numbers = [extract_number_from_label(label, prefix) for label in used_labels]
    number = max(numbers) + 1 if numbers else 1

    return f"{prefix} {number}"

# Remove Node
def remove_layer(node_tree, item):
    for node in node_tree.nodes:
        if item.ID in node.name:
            node_tree.nodes.remove(node)

# Update Node
def update_material_layers(mat):
    links = mat.node_tree.links
    nodes = mat.node_tree.nodes
    layers = mat.PlxProps.layers
    channels = mat.PlxProps.channels

    bake_list = data_definitions.get_bake_list()

    shader_node = nodes.get(delimiter_join('Plx', 'Shader'))
    default_frame = nodes.get(delimiter_join('Plx', 'Default', 'Frame'))

    default_frame.location = (-(len(layers)*350-700), -175)

    active_layers = []

    for i, item in enumerate(layers):
        layer_node = nodes.get(item.ID)
        if layer_node and hasattr(layer_node, 'node_tree'):
            layer_node.location = (-((len(layers)-1-i)*350+350), 0)
            layer_type = layer_node.node_tree.PlxProps.layer_type
            if layer_type in ['MATERIAL', 'CUSTOM']:
                # Remove old links
                for output in layer_node.outputs:
                    if output.name == 'Layer Mask': continue
                    for link in output.links:
                        links.remove(link)
                if not item.mute:
                    active_layers.append(item)
            
    for i, item in enumerate(active_layers):
        layer_node = nodes.get(item.ID)

        for channel in channels:
            node_soket_name = channel.name

            if node_soket_name == 'Layer Mask': continue

            if i == 0:
                node_out = nodes[delimiter_join('Plx', 'Default', node_soket_name)]
                links.new(node_out.outputs[0], layer_node.inputs[node_soket_name])

            if i == len(active_layers)-1:
                links.new(layer_node.outputs[node_soket_name], shader_node.inputs[node_soket_name])
            
            if i<len(active_layers)-1:
                node_in = nodes[active_layers[i+1].ID]
                links.new(layer_node.outputs[node_soket_name], node_in.inputs[node_soket_name])

        for bake_info in bake_list.values():
            image_name = delimiter_join('Plx' ,bake_info['image_name'])
            bake_image_socket = nodes[image_name].outputs['Color']
            links.new(bake_image_socket, layer_node.inputs[bake_info['image_name']])

    for bake_info in bake_list.values():
        image_name = delimiter_join('Plx' ,bake_info['image_name'])
        bake_image_socket = nodes[image_name].outputs['Color']
        links.new(bake_image_socket, shader_node.inputs[bake_info['image_name']])

def update_channel_layers(node_tree):
    nodes = node_tree.nodes
    links = node_tree.links
    layers = node_tree.PlxProps.layers

    group_in = nodes.get('GroupInput')
    group_out = nodes.get('GroupOutput')

    if not (group_in and group_out):
        print_message("No input or output found!", MessageType.WARNING)
        return
    
    if len(layers) == 0:
        links.new(group_in.outputs['Color'], group_out.inputs['Color'])
        return
            
    for i, layer in enumerate(layers):
        layer_lv = (layer.ID == layer.parent_layer_id)     

        layer_node = nodes.get(layer.ID)
        frame_node = nodes.get(delimiter_join(layer.ID, 'Frame'))
        mix_layer_node = nodes.get(delimiter_join(layer.ID, 'MixLayer'))

        if not (layer_node and frame_node and mix_layer_node):
            print_message("An error occurred in the node structure!", MessageType.WARNING)
            continue
        
        frame_node.location = ((layer_lv * 25 - 125), i * 150 - 100)
        
        # Remove old link
        for link in mix_layer_node.outputs[2].links: links.remove(link)

        if i == 0: 
            links.new(group_in.outputs['Color'], mix_layer_node.inputs[6])
            
        node_input_socket = None

        if i == len(layers)-1:
            if layer_lv:
                node_input_socket = group_out.inputs[0]
            else:
                layer_1 = layer.parent
                node_input = nodes.get(delimiter_join(layer_1.ID, 'MixLayer'))
                if node_input:
                    node_input_socket = node_input.inputs[7]

        else:
            layer_1 = layers[i+1]
            layer_1_lv = layer_1.ID == layer_1.parent_layer_id

            if layer_lv == layer_1_lv:
                node_input = nodes.get(delimiter_join(layer_1.ID, 'MixLayer'))
                if node_input:
                    node_input_socket = node_input.inputs[6]
                
            elif layer_lv > layer_1_lv:
                in_idx = i + layer.numb_sublayers + 1
                mix_layer1_node = nodes.get(delimiter_join(layer_1.ID, 'MixLayer'))
                if mix_layer1_node:
                    links.new(layer_node.outputs['Color'], mix_layer1_node.inputs[6])
                try:
                    node_input_socket = nodes[delimiter_join(layers[in_idx].ID, 'MixLayer')].inputs[6]
                except:
                    node_input_socket = group_out.inputs[0]

            else:
                layer_1 = layer.parent
                node_input = nodes.get(delimiter_join(layer_1.ID, 'MixLayer'))
                if node_input:
                    node_input_socket = node_input.inputs[7]

        if node_input_socket:
            links.new(mix_layer_node.outputs[2], node_input_socket)
        links.new(layer_node.outputs['Color'], mix_layer_node.inputs[7])
        links.new(mix_layer_node.inputs[6].links[0].from_socket, layer_node.inputs['Color'])
