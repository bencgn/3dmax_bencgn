import bpy, os, inspect, addon_utils
from enum import Enum
from uuid import uuid4

def make_uid(length=20) -> str:
    """ returns a uid with the given length """
    return uuid4().hex[:length]

DELIMITER = '$.'

def delimiter_split(name) -> list:
    """Splits a string into a list of substrings based on a fixed delimiter."""
    return name.split(DELIMITER)

def delimiter_join(*names) -> str:
    """Joins a variable number of strings or string-convertible values into a single string using a fixed delimiter."""
    return DELIMITER.join(str(i) for i in names)

def get_addon_directory() -> str:
    """Returns the directory path of the addon."""
    for mod in addon_utils.modules():
        if mod.bl_info['name'] == "Philogix PBR Painter":
            return os.path.dirname(mod.__file__)

def get_data_directory(is_system=True, data_location=None) -> str:
    if is_system:
        addon_directory = get_addon_directory()
        data_folder_path = (addon_directory, 'data')
    else:
        resource_path = bpy.utils.resource_path('USER')
        data_folder_path = (resource_path, 'PlxDatas')

    if data_location:
        data_directory = os.path.join(*data_folder_path, data_location)
    else:
        data_directory = os.path.join(*data_folder_path)
    
    if not os.path.exists(data_directory):
        os.makedirs(data_directory)

    return data_directory

def get_temp_directory() -> str:
    return os.path.dirname(bpy.app.tempdir)

def get_context_pointer(context, name):
    """Get the item from the context."""
    return getattr(context, name, None)

def draw_popup_menu(title, message, icon='NONE'):    
    def draw(self, context):
        self.layout.label(text=message)
    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)

class MessageType(Enum):
    ERROR   = "  PHILOGIX ERROR REPORT  "
    WARNING = " PHILOGIX WARNING REPORT "
    INFO    = "  PHILOGIX INFO REPORT   "

def print_message(message, message_type=MessageType.ERROR):    
    if not isinstance(message_type, MessageType):
        raise ValueError("Invalid message_type. Must be a member of MessageType enum.")
    
    caller_frame = inspect.currentframe().f_back
    caller_module = inspect.getmodule(caller_frame)

    caller_location = "Unknown Location"
    caller_class = caller_frame.f_locals.get('self', None) if caller_module else None
    caller_class = f"{caller_class.__class__.__name__}." if caller_class else ""
    caller_location = f"{caller_module.__name__}.{caller_class}{caller_frame.f_code.co_name}" if caller_module else "Unknown Location"

    formatted_message = (
        f"\n===================================={message_type.value}===================================="
        f"\n[{caller_location}]"
        f"\n{message}"
        f"\n=================================================================================================")
    
    print(formatted_message)
