import bpy

def get_image_extension(file_format):
    extensions = {
        'BMP': 'bmg',
        'IRIS': 'rgb',
        'PNG': 'png',
        'JPEG': 'jpg',
        'JPEG2000': 'jp2',
        'TARGA': 'tga',
        'TARGA_RAW': 'tga',
        'CINEON': 'cin',
        'DPX': 'dpx',
        'OPEN_EXR_MULTILAYER': 'exr',
        'OPEN_EXR': 'exr',
        'HDR': 'hdr',
        'TIFF': 'tif'
        }
    
    return extensions.get(file_format, ".unknown")

def generate_export_slot_file_name(file_name_string, slot_name, object, material, file_format, tile_number=None):
    replacements = {
        '$Slot': slot_name,
        '$Mesh': object.name if object else "NotFind",
        '$Material': material.name if material else "NotFind",
    }    

    extension = get_image_extension(file_format)

    file_name = file_name_string
    for key, value in replacements.items():
        file_name = file_name.replace(key, value)

    if tile_number:
        return f"{file_name}.{tile_number}.{extension}"
    else:
        return f"{file_name}.{extension}"
