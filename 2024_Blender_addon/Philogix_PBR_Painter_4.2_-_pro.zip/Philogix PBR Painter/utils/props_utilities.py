def get_device_items(self, context):
    items = []
    for item in context.scene.cycles.bl_rna.properties['device'].enum_items:
        items.append((item.identifier, item.name, item.description))
        
    return items
