
import bpy

def draw_png_settings(col, image_settings):        
    row = col.row()
    row.prop(image_settings, 'color_depth', expand=True)
    row = col.row()
    row.prop(image_settings, 'compression', slider=True)

def draw_jpeg_settings(col, image_settings):
    row = col.row()
    row.prop(image_settings, 'quality', slider=True)

def draw_jpeg2000_settings(col, image_settings):
    row = col.row()
    row.prop(image_settings, 'color_depth', expand=True)
    row = col.row()
    row.prop(image_settings, 'quality', slider=True)
    row = col.row()
    row.prop(image_settings, 'jpeg2k_codec', slider=True)
    row = col.row()
    row.prop(image_settings, 'use_jpeg2k_cinema_preset', slider=True)
    row = col.row()
    row.prop(image_settings, 'use_jpeg2k_cinema_48', slider=True)
    row = col.row()
    row.prop(image_settings, 'use_jpeg2k_ycc', slider=True)

def draw_dpx_settings(col, image_settings):
    row = col.row()
    row.prop(image_settings, 'color_depth', expand=True)        
    row = col.row()
    row.prop(image_settings, 'use_cineon_log', slider=True)

def draw_exr_settings(col, image_settings, file_format):
    row = col.row()
    row.prop(image_settings, 'color_depth', expand=True)
    row = col.row()
    row.prop(image_settings, 'exr_codec')
    
    if image_settings.file_format == 'OPEN_EXR':
        row = col.row()
        row.prop(image_settings, 'use_zbuffer', slider=True)
        
    if image_settings.file_format == 'OPEN_EXR_MULTILAYER':
        row = col.row()
        row.prop(image_settings, 'use_cineon_log', slider=True)

    row = col.row()
    row.prop(image_settings, 'use_preview', slider=True)

def draw_tiff_settings(col, image_settings):
    row = col.row()
    row.prop(image_settings, 'color_depth', expand=True)
    row = col.row()
    row.prop(image_settings, 'tiff_codec')

def configure_image_export_ui(layout, image_settings):
    layout.use_property_split = True
    layout.use_property_decorate = False
    col = layout.column()
    
    row = col.row()
    row.prop(image_settings, 'file_format')       
    
    row = col.row()
    row.prop(image_settings, 'color_mode', expand=True)

    format_settings_map = {
        'PNG': draw_png_settings,
        'JPEG': draw_jpeg_settings,
        'JPEG2000': draw_jpeg2000_settings,
        'DPX': draw_dpx_settings,
        'OPEN_EXR': lambda col, settings: draw_exr_settings(col, settings, 'OPEN_EXR'),
        'OPEN_EXR_MULTILAYER': lambda col, settings: draw_exr_settings(col, settings, 'OPEN_EXR_MULTILAYER'),
        'TIFF': draw_tiff_settings
    }

    if image_settings.file_format in format_settings_map:
        format_settings_map[image_settings.file_format](col, image_settings)