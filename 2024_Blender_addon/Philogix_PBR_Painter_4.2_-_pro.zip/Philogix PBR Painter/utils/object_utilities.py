import bpy

def get_active_material(obj=None):
    obj = get_active_mesh_object() if not obj else obj
    if obj: return obj.active_material

def set_active_object(object):
    bpy.context.view_layer.objects.active = object
    object.select_set(state=True)

def get_active_mesh_object():
    if bpy.context.active_object and bpy.context.active_object.type == "MESH":
        return bpy.context.active_object
