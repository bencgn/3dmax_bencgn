import bpy
from . import general_utilities, data_definitions


def clone_and_update_node_group(node_group, copied_images_dict={}, copied_node_trees_dict={}):
    for node in node_group.nodes:
        if hasattr(node, 'node_tree') and node.node_tree:
            # Nếu node_tree chưa được copy, tạo một bản copy và lưu vào dictionary
            if node.node_tree not in copied_node_trees_dict:
                copied_node_tree = node.node_tree.copy()
                copied_node_trees_dict[node.node_tree] = copied_node_tree
                clone_and_update_node_group(copied_node_tree, copied_images_dict, copied_node_trees_dict)
            # Gán node hiện tại với bản copy từ dictionary
            node.node_tree = copied_node_trees_dict[node.node_tree]

        elif hasattr(node, 'image') and node.image:
            # Nếu image chưa được copy, tạo một bản copy và lưu vào dictionary
            if node.image not in copied_images_dict:
                new_image = node.image.copy()
                if node.image.is_dirty:
                    new_image.pixels[:] = node.image.pixels[:]
                copied_images_dict[node.image] = new_image
            # Gán node hiện tại với bản copy từ dictionary
            node.image = copied_images_dict[node.image]

def is_valid_plx_material(mat):
    if not mat or not mat.PlxProps.ID: 
        return False
    
    node_tree = mat.node_tree
    bakes_list = data_definitions.get_bake_list()
    pbr_channels = data_definitions.get_pbr_channels(mat.PlxProps.workflow)

    default_nodes_name = [
        general_utilities.delimiter_join('Plx', 'Default', 'Frame'),
        general_utilities.delimiter_join('Plx', 'Material Output'),
        general_utilities.delimiter_join('Plx', 'Shader'),
        ]
    
    for node_name in default_nodes_name:
        if node_name not in node_tree.nodes:
            return False

    for bake_name, bake_value in bakes_list.items():
        bake_image_node_name = general_utilities.delimiter_join('Plx', bake_value['image_name'])
        if bake_image_node_name not in node_tree.nodes:
            return False

    for channel_name in pbr_channels.keys():
        if channel_name != 'Layer Mask':
            default_channel_node = general_utilities.delimiter_join('Plx', 'Default', channel_name)
            
            if default_channel_node not in node_tree.nodes:
                return False
            
    return True

def is_surface_node_group(node_group):
    available_interface = ['Color', 'Alpha', 'Vector']    
    for interface in available_interface:
        if interface not in node_group.interface.items_tree:
            return False
    bake_list = data_definitions.get_bake_list()
    for bake in bake_list.values():
        if bake['image_name'] not in node_group.inputs:
            return False
        
    return True

def get_shader_node(mat):
    if not mat:
        return None
    shader_node_name = general_utilities.delimiter_join('Plx', 'Shader')
    return mat.node_tree.nodes.get(shader_node_name)
    
def get_node_index(node_tree, node):
    if node is not None:
        for index, n in enumerate(node_tree.nodes):
            if n == node:
                return index
    return "None"