import bpy
from bpy.types import PropertyGroup
from bpy.props import (
    EnumProperty,
    FloatProperty,
)
from . import properties_update

from ..utils.object_utilities import get_active_material



def uv_using_update(self, context):
    node_tree = self.id_data

    math_node = node_tree.nodes.get('Math')
    value_node = node_tree.nodes.get('Value')

    if self.uv_using == 'GENERAL':
        mat = get_active_material()
        material_layer = mat.PlxProps.material_layer
        uv_settings = material_layer.node_group.PlxProps.uv_settings
        mapping_node = node_tree.nodes.get('GroupInput')

    else:
        uv_settings = self
        mapping_node = node_tree.nodes.get('Mapping')

    if math_node and value_node:
        node_tree.links.new(mapping_node.outputs['Alpha'], math_node.inputs[1])
        node_tree.links.new(mapping_node.outputs['Vector'], value_node.inputs['Vector'])

    uv_projection_mode_update(uv_settings, context)

def uv_projection_mode_update(self, context):
    mapping_node = self.id_data.nodes.get('Mapping')
    mapping_node.projection = self.uv_projection_mode
    
    if self.uv_projection_mode in ['UV', 'Global']:
        mapping_node.culling = False

    if self.uv_projection_mode in ['UV', 'Decal']:
        self.uv_projection = 'FLAT'
    else:
        uv_projection_update(self, context)

def uv_projection_update(self, context):
    def set_projection_for_node(value_node):
        if value_node.bl_idname == 'ShaderNodeTexImage':
            value_node.projection = self.uv_projection

        elif value_node.bl_idname in ['ShaderNodeTexMusgrave', 'ShaderNodeTexNoise', 'ShaderNodeTexWhiteNoise', 'ShaderNodeTexVoronoi']:
            node_dimensions = '2D' if self.uv_projection == 'FLAT' else '3D'
            if value_node.bl_idname == 'ShaderNodeTexMusgrave':
                value_node.musgrave_dimensions = node_dimensions
            elif value_node.bl_idname == 'ShaderNodeTexNoise':
                value_node.noise_dimensions = node_dimensions
            elif value_node.bl_idname == 'ShaderNodeTexWhiteNoise':
                value_node.noise_dimensions = node_dimensions
            elif value_node.bl_idname == 'ShaderNodeTexVoronoi':
                value_node.voronoi_dimensions = node_dimensions
    
    update_nodes_with_function(self, set_projection_for_node)
    blend_update(self, context)

def blend_update(self, context):
    def set_blend_for_node(node):
        if node.bl_idname=='ShaderNodeTexImage':
            node.projection_blend = self.blend

    update_nodes_with_function(self, set_blend_for_node)

def update_nodes_with_function(self, update_function):
    def set_function_for_node(node, is_value_node=False):
        if not node:
            return
        
        elif node.bl_idname == 'ShaderNodeGroup' and node.node_tree not in processed_groups:
            processed_groups.add(node.node_tree)
            for sub_node in node.node_tree.nodes:
                set_function_for_node(sub_node)

        elif not node.hide or is_value_node:
            update_function(node)

    processed_groups = set()
    layer_node_group = self.id_data
    value_node = layer_node_group.nodes.get('Value')

    if value_node:
        set_function_for_node(value_node, True)
        return

    if self.uv_using != 'GENERAL' and layer_node_group.PlxProps.layer_type != 'MATERIAL':
        return

    for channel_node in layer_node_group.nodes:
        if channel_node.bl_idname == 'ShaderNodeGroup' and value_node != channel_node:
            for channel_layer_node in channel_node.node_tree.nodes:
                if channel_layer_node.bl_idname == 'ShaderNodeGroup':
                    channel_layer_value_node = channel_layer_node.node_tree.nodes.get('Value')
                    set_function_for_node(channel_layer_value_node, True)


class PHILOGIX_UVSettings(PropertyGroup):

    uv_using: EnumProperty(
        name='UV Using',
        items=(
            ('GENERAL', 'General UV', 'Use the general UV vector from the Material Layer'),
            ('PRIVATE', 'Private UV', 'Use the private UV vector from the Current Layer'),
        ),
        default='GENERAL',
        description='Select the UV vector source to determine how UV coordinates are used',
        update=uv_using_update,
    )

    uv_projection_mode: EnumProperty(
        name='UV Projection Mode',
        description='Specifies the UV projection mode for mapping onto the layer',
        items=(
            ( "UV", "UVMap", "Project UV coordinates onto the layer" ),
            ( "Global", "Global", "Project using global coordinates" ),
            ( "Object", "Object", "Project using an object as the mapping source" ),
            ( "Decal", "Decal", "Project using decal object" ),
        ),
        default='UV',
        update=uv_projection_mode_update,
    )

    uv_projection: EnumProperty(
        name='Projection',
        description='Specifies the projection method for UV mapping',
        items=(
            ('FLAT', 'Flat', 'Flat projection onto the object'),
            ('BOX', 'Box', 'Box projection onto the object'),
            ('SPHERE', 'Sphere', 'Sphere projection onto the object'),
            ('TUBE', 'Tube', 'Tube projection onto the object'),
        ),
        default='FLAT',
        update=uv_projection_update,
    )

    blend: FloatProperty(default=0, min=0, max=1, step=1, update=blend_update)

