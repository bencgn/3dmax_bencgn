import bpy
from bpy.types import PropertyGroup
from bpy.props import IntProperty, EnumProperty, BoolProperty, StringProperty, PointerProperty

from ..addon.distribution import AssetCategory
from .bake_properties import PHILOGIX_BakeProperties
from .export_properties import PHILOGIX_ExportProperties

from ..utils.object_utilities import get_active_material
from ..utils.general_utilities import delimiter_join, get_context_pointer, print_message, MessageType


def category_name_update(self, context):
    if not self.editing_category:
        return
    
    layer_group = get_context_pointer(context, 'active_layer_group')
    asset_type_map = {'MATERIAL': 'Materials', 'SURFACE': 'Surfaces', 'IMAGE': 'Brushes'}

    layer_type = layer_group.PlxProps.layer_type
    asset_type = asset_type_map.get(layer_type, '')
    user_category = AssetCategory.user_category.get(asset_type)

    if not user_category:
        print_message(f"Asset type not found {asset_type}", MessageType.WARNING)
        
    if self.editing_category in user_category:
        user_category[self.editing_category] = self.category_name
        AssetCategory.update_category_file()

    self.editing_category = ''
    self.category_name = ''

def pie_update(self, context):
    mat = get_active_material()
    if not mat:
        return
    shader_node_name = delimiter_join('Plx', 'Shader')
    shader_node = mat.node_tree.nodes.get(shader_node_name)
    if not shader_node:
        return
    try:
        shader_output_index = 0
    except IndexError:
        shader_output_index = 1
    finally:
        shader_node.shader_output = self.pie_preview.split('/')[shader_output_index]

def get_active_factor(self):
    return True

def set_active_factor(self, value):
    self.active_factor = value


class PHILOGIX_Properties(PropertyGroup):
    active_factor: BoolProperty(name='Factor', description='', default=False, get=get_active_factor, set=set_active_factor)

    # Property for funding status
    fund: BoolProperty(name='Funding Status', description='Indicates if the project has been funded or not', default=False)

    # Drop-down for texture preview mode
    pie_preview : EnumProperty(
            name = 'Texture Preview',
            description = 'Choose the type of texture to preview',
            items = (
                ('Base Color/Diffuse', 'Base Color/Diffuse', 'Preview Base Color or Diffuse Map'),
                ('Metallic/Specular', 'Metallic/Specular', 'Preview Metallic or Specular Map'),
                ('Roughness/Glossiness', 'Roughness/Glossiness', 'Preview Roughness or Glossiness Map'),
                ('Material', 'Material', 'Preview Full Material'),
                ('Normal', 'Normal', 'Preview Normal Map'),
                ('Height', 'Height', 'Preview Height Map'),
                ('Subsurface', 'Subsurface', 'Preview Subsurface Map'),
                ('Subsurface Color', 'Subsurface Color', 'Preview Subsurface Color Map'),
            ),
            update=pie_update
        )

    # Toggles for extended settings
    uv_extended_settings: BoolProperty(name='UV Extended Settings', description='Show or hide extended UV settings', default=False)
    
    parameter_extended_settings: BoolProperty(name='Parameter Extended Settings', description='Show or hide extended parameter settings', default=True)
    
    data_extended_settings: BoolProperty(
        name="Data Extended Settings",
        description="Show or hide extended settings for exporting, importing, saving, and deleting",
        default=False)

    # Category
    category_name: StringProperty(
        update=category_name_update
    )

    editing_category: StringProperty(default='')

    category_display_size: IntProperty(
        name='Display Size',
        description='Change the size of thumbnails',
        subtype='FACTOR',
        min=24,
        max=96,
        default=35
    )

    category_display_cols: IntProperty(
        name='Display Columns',
        description='Change the Columns of thumbnails',
        subtype='FACTOR',
        min=4,
        max=12,
        default=8
    )
    
    # Pointer properties to bake and export settings
    bake_properties: PointerProperty(name='Bake Properties', 
                                     description='Settings related to baking textures', 
                                     type=PHILOGIX_BakeProperties)
    
    export_properties: PointerProperty(
        name='Export Properties', 
        description='Settings related to exporting assets', 
        type=PHILOGIX_ExportProperties)

    # Parameter panel mode for image layers
    image_layer_parameter_mode: EnumProperty(
        name='Parameter Panels',
        description='Select the parameter panel mode for the image layer',
        items=(
            ('IMAGE', 'Image Panel', 'Parameter panel for images'),
            ('PAINT', 'Paint Panel', 'Parameter panel for painting'),
        ),
        default='IMAGE',
        options={'SKIP_SAVE'}
    )

    # Toggle for brush settings extension
    brush_settings_extend: BoolProperty(
        name='Brush Settings Extend',
        description='Expand or collapse the brush settings panel for the channel layer',
        default=False,
    )
