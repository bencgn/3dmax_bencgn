import bpy

from ..bl_class_registry import BlClassRegistry

from ..core.serializer.asset_serializer import PlxAsset
from ..addon.distribution import AssetCategory, AssetCollection

def get_category_enum_items(self, context):
    return AssetCategory.get_enum_items(self.asset_type)

def get_default_item(self, context):
    enum_items = AssetCollection.get_asset_items('Defaults')
    return [(asset_id, asset_info['name'], '', asset_info['preview'], idx) 
            for idx, (asset_id, asset_info) in enumerate(enum_items.items())]

def update_default_data(self, context):
    if self.default_data != 'NONE':
        default_data = self.default_data
        self.default_data = 'NONE'
        PlxAsset.load_asset(default_data)

class PHILOGIX_DevProps(bpy.types.PropertyGroup):
    default_data: bpy.props.EnumProperty(
        name='Defaults Data',
        items=get_default_item,
        update=update_default_data
    )