import bpy
from bpy.types import PropertyGroup
from bpy.props import (
            IntProperty,
            EnumProperty,
            BoolProperty,
            FloatProperty,
            StringProperty,
            PointerProperty,
            CollectionProperty,
        )

from ..addon import distribution

from ..utils.general_utilities import delimiter_join
from ..utils.props_utilities import get_device_items

def get_colorspace_items(self, context):
    items = []

    for item in context.scene.sequencer_colorspace_settings.bl_rna.properties['name'].enum_items:
        items.append((item.identifier, item.name, item.description))
        
    return items

def get_color_depth_items(self, context):
    items = [('16', '16', '16-bit color channels')]
    
    if self.file_format in ['PNG', 'TIFF']:
        items = [
            ('8', '8', '8-bit color channels'),
            ('16', '16', '16-bit color channels')
        ]
        
    elif self.file_format in ['OPEN_EXR_MULTILAYER', 'OPEN_EXR']:
        items = [
            ('16', 'Float (Half)', '16-bit color channels'),
            ('32', 'Float (Full)', '32-bit color channels')
        ]
        
    elif self.file_format == 'JPEG2000':
        items = [
            ('8', '8', '8-bit color channels'),
            ('12', '12', '12-bit color channels'),
            ('16', '16', '16-bit color channels')
        ]
        
    elif self.file_format == 'DPX':
        items = [
            ('8', '8', '8-bit color channels'),
            ('10', '10', '10-bit color channels'),
            ('12', '12', '12-bit color channels'),
            ('16', '16', '16-bit color channels')
        ]
        
    return items
    
def get_color_mode_items(self, context):
    items=[
            ('BW', 'BW', 'Images get saved in 8-bit grayscale (only PNG, JPEG, TGA, TIF)'),
            ('RGB', 'RGB', 'Images are saved with RGB (color) data'),
            ('RGBA', 'RGBA', 'Images are saved with RGB and Alpha data (if supported)'),
        ]
    
    if self.file_format in ['BMP', 'JPEG', 'CINEON', 'HDR']:
        items=[
            ('BW', 'BW', 'Images get saved in 8-bit grayscale (only PNG, JPEG, TGA, TIF)'),
            ('RGB', 'RGB', 'Images are saved with RGB (color) data'),
        ]
    
    return items


def extend_update(self, context):
    if not self.extend: return
    
    for slot in self.id_data.PlxProps.export_properties.slots:
        if slot != self:
            slot.extend = False

def is_baking_update(self, context):
    if not self.is_baking: return
    for slot in self.id_data.PlxProps.export_properties.slots:
        if slot != self:
            slot.is_baking = False

def file_format_update(self, context):
    try:
        self.color_mode = self.color_mode
    except:
        self.color_mode = 'RGB'
        
    try:
        self.color_depth = self.color_depth
    except: 
        self.color_depth = '16'

def expressions_update(self, context):
    self.filename = self.filename + self.expressions

def preset_name_update(self, context):
    if self.id:
        distribution.ExportPresets.update_preset(self.id, self.name)

class PHILOGIX_ImageFormatSettings(PropertyGroup):
    ''' Settings for image formats'''
    
    file_format: EnumProperty(
        name='File Format',
        description='File format to save the rendered images as',
        default='PNG',
        items=(
            ('BMP', 'BMP', 'Output image in bitmap format'),
            ('IRIS', 'Iris', 'Output image in SGI IRIS format'),
            ('PNG', 'PNG', 'Output image in PNG format'),
            ('JPEG', 'JPEG', 'Output image in JPEG format'),
            ('JPEG2000', 'JPEG 2000', 'Output image in JPEG 2000 format'),
            ('TARGA', 'Targa', 'Output image in Targa format'),
            ('TARGA_RAW', 'Targa Raw', 'Output image in uncompressed Targa format'),
            ('CINEON', 'Cineon', 'Output image in Cineon format'),
            ('DPX', 'DPX', 'Output image in DPX format'),
            ('OPEN_EXR_MULTILAYER', 'OpenEXR MultiLayer', 'Output image in multilayer OpenEXR format'),
            ('OPEN_EXR', 'OpenEXR', 'Output image in OpenEXR format'),
            ('HDR', 'Radiance HDR', 'Output image in Radiance HDR format'),
            ('TIFF', 'TIFF', 'Output image in TIFF format')
            ),
        update=file_format_update
        )

    color_depth: EnumProperty(
        name='Color Depth',
        description='Bit depth per channel',
        items=get_color_depth_items
        )

    color_mode: EnumProperty(
        name='Color',
        description='Choose BW for saving grayscale images, RGB for saving red, green and blue channels, and RGBA for saving red, green, blue and alpha channels',
        items=get_color_mode_items,
        default=1,
        )

    
    cineon_black: IntProperty(
        name='B',
        description='Log conversion reference blackpoint',
        default=0,
        )

    cineon_gamma: FloatProperty(
        name='G',
        description='Log conversion gamma',
        default=0.0,
        )

    cineon_white: IntProperty(
        name='W',
        description='Log conversion reference whitepoint',
        default=0,
        )

    compression: IntProperty(
        name='Compression',
        description='Amount of time to determine best compression: 0 = no compression with fast file output, 100 = maximum lossless compression with slow file output',
        subtype='PERCENTAGE',
        default=15,
        min=0,
        max=100,
        )

    exr_codec: EnumProperty(
        name='Codec',
        description='Codec settings for OpenEXR',
        default='NONE',
            items=(
            ('NONE', 'None', ''),
            ('PXR24', 'Pxr24 (lossy)', ''),
            ('ZIP', 'ZIP (lossless)', ''),
            ('PIZ', 'PIZ (lossless)', ''),
            ('RLE', 'RLE (lossless)', ''),
            ('ZIPS', 'ZIPS (lossless)', ''),
            ('B44', 'B44 (lossy)', ''),
            ('B44A', 'B44A (lossy)', ''),
            ('DWAA', 'DWAA (lossy)', ''),
            ('DWAB', 'DWAB (lossy)', ''),
            ),
        )

    jpeg2k_codec: EnumProperty(
        name='Codec',
        description='Codec settings for Jpeg2000',
        default='JP2',
        items=(
            ('JP2', 'JP2', ''),
            ('J2K', 'J2K', ''),
            ),
        )

    quality: IntProperty(
        name='Quality',
        description='Quality for image formats that support lossy compression',
        default=90,
        subtype='PERCENTAGE',
        min=0,
        max=100,
        )

    tiff_codec: EnumProperty(
        name='Compression',
        description='Compression mode for TIFF',
        default='DEFLATE',
        items=(
            ('NONE', 'None', ''),
            ('DEFLATE', 'Deflate', ''),
            ('LZW', 'LZW', ''),
            ('PACKBITS', 'Pack Bits', ''),
            ),
        )

    use_cineon_log: BoolProperty(
        name='Log',
        description='Convert to logarithmic color space',
        default=False,
        )

    use_jpeg2k_cinema_48: BoolProperty(
        name='Cinema (48)',
        description='Use Openjpeg Cinema Preset (48fps)',
        default=False,
        )

    use_jpeg2k_cinema_preset: BoolProperty(
        name='Cinema',
        description='Use Openjpeg Cinema Preset',
        default=False,
        )

    use_jpeg2k_ycc: BoolProperty(
        name='YCC',
        description='Save luminance-chrominance-chrominance channels instead of RGB colors',
        default=False,
        )

    use_preview: BoolProperty(
        name='Preview',
        description='When rendering animations, save JPG preview images in same directory',
        default=False,
        )

    use_zbuffer: BoolProperty(
        name='Z Buffer',
        description='Save the z-depth per pixel (32-bit unsigned integer z-buffer)',
        default=False,
        )

class PHILOGIX_ChannelOutputImage(PropertyGroup):
    bake_type: StringProperty()
    color_space: StringProperty()
    shader_output: StringProperty()

    normal_format: EnumProperty(
        name='Normal Format',
        description='Format of the normal map',
        items=(
            ('POS_Y', 'OpenGL', 'OpenGL format for normal map'),
            ('NEG_Y', 'DirecX', 'DirectX format for normal map'),
        ),
        default='POS_Y'
    )

class PHILOGIX_ExportSlot(PropertyGroup):
    # Check if currently baking
    is_baking: BoolProperty(
        name='Currently Baking',
        description='Indicates if the slot is currently in the baking process',
        update=is_baking_update,
        default=False)
    
    # Activation toggle for export slot
    active: BoolProperty(
        name='Active Slot',
        description='Toggle this option to specify if the slot should be considered during baking',
        default=True)
    
    # Option to extend settings panel
    extend: BoolProperty(
        name='Extend Parameters',
        description='Toggle to expand or collapse the parameter setting panel',
        default=False,
        update=extend_update)
    
    # Image settings reference
    image_settings: PointerProperty(
        name='Image Format Settings',
        description='Reference to the image format settings for the slot',
        type=PHILOGIX_ImageFormatSettings)

    # Define output type for exporting
    output_type: EnumProperty(
        name='Output Type',
        description='Choose the output type for the export, such as RGB, R+G+B, and more',
        items=(
            ('RGB', 'RGB', 'Standard RGB channels without Alpha'),
            (delimiter_join('Red', 'Green', 'Blue'), 'R + G + B', 'Red, Green, and Blue channels as separate outputs'),
            (delimiter_join('RGB', 'Alpha'), 'RGB + Alpha', 'Standard RGB channels with Alpha'),
            (delimiter_join('Red', 'Green', 'Blue', 'Alpha'), 'R + G + B + Alpha', 'Red, Green, Blue channels and Alpha as separate outputs'),
            ),
        )
    
    # Define properties for each channel
    RGB: PointerProperty(name='RGB Channel', description='Define the RGB channel settings for export', type=PHILOGIX_ChannelOutputImage)
    Red: PointerProperty(name='Red Channel', description='Define the Red channel settings for export', type=PHILOGIX_ChannelOutputImage)
    Green: PointerProperty(name='Green Channel', description='Define the Green channel settings for export', type=PHILOGIX_ChannelOutputImage)
    Blue: PointerProperty(name='Blue Channel', description='Define the Blue channel settings for export', type=PHILOGIX_ChannelOutputImage)
    Alpha: PointerProperty(name='Alpha Channel', description='Define the Alpha channel settings for export', type=PHILOGIX_ChannelOutputImage)

class PHILOGIX_ExportProperties(PropertyGroup):
    id: StringProperty()
    name: StringProperty(update=preset_name_update)

    is_baking: BoolProperty(
        name='Baking Status', 
        description='Indicates if the software is currently baking textures or not', 
        default=False
        )

    device: EnumProperty(
            name='Export Device',
            description='Select the device target for the export',
            items=get_device_items)
    
    slots: CollectionProperty(
            name='Export Slots',
            description='List of export slots for the export',
            type=PHILOGIX_ExportSlot)
    
    setting_extend: BoolProperty(
            name='Extend Settings',
            description='Toggle to extend or limit the settings for the export',
            default=True)
    
    size: EnumProperty(
            name='Texture Size',
            description='Select the resolution size for the exported texture',
            items=(
                ('16', '16', 'Texture resolution of 16x16 pixels'),
                ('32', '32', 'Texture resolution of 32x32 pixels'),
                ('64', '64', 'Texture resolution of 64x64 pixels'),
                ('128', '128', 'Texture resolution of 128x128 pixels'),
                ('256', '256', 'Texture resolution of 256x256 pixels'),
                ('512', '512', 'Texture resolution of 512x512 pixels'),
                ('1024', '1024', 'Texture resolution of 1024x1024 pixels'),
                ('2048', '2048', 'Texture resolution of 2048x2048 pixels'),
                ('4096', '4096', 'Texture resolution of 4096x4096 pixels'),
                ('8192', '8192 (Requires large memory)', 'Texture resolution of 8192x8192 pixels'),
            ),
            default='2048'
        )
    
    export_type: EnumProperty(
        name='Export Type',
        description='Choose which materials to include in the export',
        items=(
            ('ACTIVE','Active Material','Export the currently active material'),
            ('ALL','All Materials','Export all materials from the current object'),
            ('OBJECTS','All Selected Objects','Export materials from all selected objects'),
            ('ANOTHER','Another Object','Export materials from a specified object'),
        ),
        default="ACTIVE",
    )
    
    margin: IntProperty(
            name='Margin Size',
            description='Set the margin size for the exported texture',
            min=0, 
            max=64, 
            default=16, 
            subtype='PIXEL')
    
    quality: IntProperty(
            name='Export Quality',
            description='Adjust the quality level for the export',
            min=0, 
            max=32, 
            default=2)
    
    uv_layer: StringProperty(
            name='UV Layer',
            description='Specify the UV layer to be used for the export',
            default='')
    
    filepath: StringProperty(
            name='Export Path',
            description='Directory path for the export',
            default='//', 
            subtype='DIR_PATH')
    
    filename: StringProperty(
            name='File Name',
            description='Specify the file name format for the export. You can use expressions like $Material and $Slot for dynamic naming',
            default='$Material_$Slot')
    
    expressions : EnumProperty(
            name='Expressions',
            description='Add expressions in the path that will be replaced during export',
            items =  (
                ('$Material' ,'Material','Represents the material name in the file path'),
                ('$Mesh' ,'Mesh','Represents the mesh name in the file path'),
                ('$Slot' ,'Slot','Represents the channel name in the file path')
            ),
            update=expressions_update,
        )

    specified_object: PointerProperty(
        name='Specified Object',
        description='Specified Object to Get Material Information',
        type=bpy.types.Object
    )
    
    cage_extrusion: FloatProperty(
        name='Cage Extrusion',
        description='Amount of extrusion applied to the baking cage',
        min=0, max=1, default=0.035, unit='LENGTH'
    )
    
    max_ray_distance: FloatProperty(
        name='Max Ray Distance',
        description='Maximum distance rays can travel while baking. Useful to avoid intersection artifacts',
        min=0, max=1, default=0, unit='LENGTH'
    )
