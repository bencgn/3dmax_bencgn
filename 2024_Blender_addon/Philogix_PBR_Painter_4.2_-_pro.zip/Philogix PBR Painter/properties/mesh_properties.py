import bpy
from bpy.types import PropertyGroup
from bpy.props import StringProperty, CollectionProperty, PointerProperty, EnumProperty

from . import properties_update

from ..core.image_manager import ImageManager

from ..utils.general_utilities import delimiter_join
from ..utils.object_utilities import get_active_mesh_object


def get_edit_maps_item(self, context):
    items = []

    mat_channels = self.id_data.PlxProps.channels

    for mat_channel in sorted(mat_channels, key=lambda channel: channel.ID):
        items.append((mat_channel.name , '', mat_channel.description, mat_channel.icon, mat_channel.ID))

    items.insert(-1, None)

    return items

def bake_size_update(self, context):
    for bake_image in self.bake_images:
        ImageManager.scale(context, bake_image.image, int(self.bake_size), int(self.bake_size))

def bake_uvmap_update(self, context):
    mesh = self.id_data
    for material in mesh.materials:
        uvmap_node_name = delimiter_join('Plx', 'Default', 'Bake_UVMap')
        bake_uvmap_node = material.node_tree.nodes.get(uvmap_node_name)

        if bake_uvmap_node:
            bake_uvmap_node.uv_map = self.bake_uvmap
        else:
            raise ValueError(f"Bake UV Map node '{uvmap_node_name}' not found in material '{material.name}'!")


class PHILOGIX_MeshBakeImage(PropertyGroup):
    name: StringProperty()
    image: PointerProperty(type=bpy.types.Image)

class PHILOGIX_MeshProps(PropertyGroup):
    ID: StringProperty(
        name='ID',
        description='An identifier for the mesh property'
    )

    bake_size: EnumProperty(
        name='Bake Resolution',
        description='Resolution of the output baked texture',
        items=(
            ('128', '128', 'Texture resolution of 128x128 pixels'),
            ('512', '512', 'Texture resolution of 512x512 pixels'),
            ('1024', '1024', 'Texture resolution of 1024x1024 pixels'),
            ('2048', '2048', 'Texture resolution of 2048x2048 pixels'),
            ('4096', '4096', 'Texture resolution of 4096x4096 pixels'),
        ),
        default='128',
        update=bake_size_update
    )

    bake_uvmap: StringProperty(
        name='Bake UV Map',
        description='The UV map used for baking textures',
        update=bake_uvmap_update
    )

    bake_images: CollectionProperty(type=PHILOGIX_MeshBakeImage)