
###############   IMPORTS
import bpy
from bpy.props import PointerProperty, StringProperty, EnumProperty
from ..core.registration_manager import RegistrationManager

from . import (
    develop_properties,
    node_group_properties, 
    material_layer_properties, 
    channel_layer_properties, 
    layer_projection_properties, 
    material_properties, 
    mesh_properties,
    bake_properties,
    export_properties,
    scene_properties
    )

###############   REGISTER ADDON
classes = (
    layer_projection_properties.PHILOGIX_UVSettings,
    channel_layer_properties.PHILOGIX_ChannelLayer,
    material_layer_properties.PHILOGIX_MaterialLayer,

    node_group_properties.PHILOGIX_NodeGroupProps,

    material_properties.PHILOGIX_MaterialChannels,
    material_properties.PHILOGIX_MaterialProps,

    mesh_properties.PHILOGIX_MeshBakeImage,
    mesh_properties.PHILOGIX_MeshProps,


    bake_properties.PHILOGIX_BakeSlots,
    bake_properties.PHILOGIX_BakeProperties,

    export_properties.PHILOGIX_ChannelOutputImage,
    export_properties.PHILOGIX_ImageFormatSettings,
    export_properties.PHILOGIX_ExportSlot,
    export_properties.PHILOGIX_ExportProperties,

    scene_properties.PHILOGIX_Properties,

    develop_properties.PHILOGIX_DevProps,
    )

def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Brush.PlxAssetId = StringProperty()
    bpy.types.Brush.PlxAssetName = StringProperty()
    bpy.types.Brush.PlxAssetType = EnumProperty(
        items=(
            ('None', 'None', 'Asset type unknown'),
            ('Constant', 'Constant', 'Asset types do not change content'),
            ('Defaults', 'Defaults', 'Default Asset types'),
            ('Brushes', 'Defaults', 'Brushes Asset types')
        ),
        default='None'
    )
    bpy.types.Brush.PlxAssetCategory = StringProperty()
    
    bpy.types.Material.PlxAssetId = StringProperty()
    bpy.types.Material.PlxAssetName = StringProperty()
    bpy.types.Material.PlxAssetType = EnumProperty(
        items=(
            ('None', 'None', 'Asset type unknown'),
            ('Constant', 'Constant', 'Asset types do not change content'),
            ('Defaults', 'Defaults', 'Default Asset types')
        ),
        default='None'
    )
    bpy.types.Material.PlxAssetCategory = StringProperty()
    
    bpy.types.ShaderNodeTree.PlxAssetId = StringProperty()
    bpy.types.ShaderNodeTree.PlxAssetName = StringProperty()
    bpy.types.ShaderNodeTree.PlxAssetType = EnumProperty(
        items=(
            ('None', 'None', 'Asset type unknown'),
            ('Constant', 'Constant', 'Asset types do not change content'),
            ('Defaults', 'Defaults', 'Default Asset types'),
            ('Materials', 'Materials', 'Materials Asset types'),
            ('Surfaces', 'Surfaces', 'Surfaces Asset types')
        ),
        default='None'
    )
    bpy.types.ShaderNodeTree.PlxAssetCategory = StringProperty()

    bpy.types.Image.plx_mesh_image_baking = PointerProperty(type=bpy.types.Mesh)
    bpy.types.Mesh.PlxProps = PointerProperty(type=mesh_properties.PHILOGIX_MeshProps)
    bpy.types.Scene.PlxProps = PointerProperty(type=scene_properties.PHILOGIX_Properties)
    bpy.types.Material.PlxProps = PointerProperty(type = material_properties.PHILOGIX_MaterialProps)
    bpy.types.ShaderNodeTree.PlxProps = PointerProperty(type = node_group_properties.PHILOGIX_NodeGroupProps)

    if RegistrationManager().is_dev_version:
        bpy.types.Scene.PlxDevProps = bpy.props.PointerProperty(type=develop_properties.PHILOGIX_DevProps)
    
def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
