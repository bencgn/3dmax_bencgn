import bpy

from ..operators import exporting_manager
from ..addon.distribution import ExportPresets


from ..utils.general_utilities import delimiter_join
from ..utils.object_utilities import get_active_material
from ..utils.layer_utilities import update_material_layers

def mute_update(self, context):
    mat = self.id_data
    update_material_layers(mat)

def material_layer_index_update(self, context):
    bpy.ops.plx.move_layer('INVOKE_DEFAULT')

    node_tree = self.id_data.node_tree
    layers = self.layers

    if len(layers) > 0 and self.layers_index >= 0:
        layer = layers[self.layers_index]
        layer_node = node_tree.nodes.get(layer.ID)

        if layer_node:
            layer_mask_socket = layer_node.outputs.get('Layer Mask')

            if layer_mask_socket:
                shader_node = node_tree.nodes[delimiter_join('Plx', 'Shader')]
                node_tree.links.new(layer_mask_socket, shader_node.inputs['Layer Mask'])

def channel_layer_index_update(self, context):
    bpy.ops.plx.move_channel_layer('INVOKE_DEFAULT')

    if context.active_object.mode != 'TEXTURE_PAINT':
        return

    channel_layer_group = self.active_layer.node_group
    if not channel_layer_group or channel_layer_group.PlxProps.layer_type != "IMAGE":
        return

    value_node = channel_layer_group.nodes.get("Value")
    if not value_node:
        return
    
    node_tree = channel_layer_group
    uv_using = channel_layer_group.PlxProps.uv_settings.uv_using

    if uv_using == 'GENERAL':
        mat = get_active_material()
        node_tree = mat.PlxProps.material_layer.node_group

    mapping_node = node_tree.nodes.get('Mapping')
    if mapping_node:
        active_layer_uvmap = context.object.data.uv_layers.get(mapping_node.uv_map)
        if active_layer_uvmap:
            active_layer_uvmap.active = True

    img_paint = context.tool_settings.image_paint
    img_paint.mode = 'IMAGE'
    img_paint.canvas = value_node.image