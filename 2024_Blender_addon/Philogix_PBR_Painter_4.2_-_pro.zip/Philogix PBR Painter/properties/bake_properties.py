import bpy, copy
from bpy.types import PropertyGroup
from bpy.props import (
            IntProperty,
            EnumProperty,
            BoolProperty,
            FloatProperty,
            StringProperty,
            PointerProperty,
            CollectionProperty,
        )

from ..utils.props_utilities import get_device_items

def extend_update(self, context):
    if not self.extend: return
    
    for slot in self.id_data.PlxProps.bake_properties.slots:
        if slot != self:
            slot.extend = False

class PHILOGIX_BakeSlots(PropertyGroup):    
    baking_status:EnumProperty(
        name='Bake Status',
        description='Indicates the baking status for the slot',
        items=(
            ('waiting', 'waiting', ''),
            ('baking', 'baking', ''),
            ('done', 'done', ''),
        ),
        default='waiting'
    )

    # Activation toggle for the bake slot and option to extend its settings panel
    active: BoolProperty(name='Active Bake Slot', description='Activate this slot for baking', default=False)

    extend: BoolProperty(
        name='Extend Settings', 
        description='Expand or collapse the parameter setting panel for this bake slot', 
        default=False, update=extend_update
        )

    # Type of bake operation
    bake_type: EnumProperty(
        name='Bake Type',
        description='Specify the type of texture to bake',
        default='COMBINED',
        items=(
            ('COMBINED', 'Combined', 'Bake all light interactions into a single texture'),
            ('AO', 'Ambient Occlusion', 'Bake ambient occlusion map'),
            ('SHADOW', 'Shadow', 'Bake shadow map'),
            ('POSITION', 'Position', 'Bake position map'),
            ('NORMAL', 'Normal', 'Bake normal map'),
            ('UV', 'UV', 'Bake UV layout'),
            ('ROUGHNESS', 'Roughness', 'Bake roughness map'),
            ('EMIT', 'Emit', 'Bake emission map'),
            ('ENVIRONMENT', 'Environment', 'Bake environment lighting'),
            ('DIFFUSE', 'Diffuse', 'Bake diffuse color'),
            ('GLOSSY', 'Glossy', 'Bake glossy reflections'),
            ('TRANSMISSION', 'Transmission', 'Bake light transmission'),
        )
    )

    # Image and vertex color layer details
    image_name: StringProperty(name='Image Name', description='Name of the image to bake to')
    layer_name: StringProperty(name='Vertex Color Layer', description='Name of the vertex color layer to bake to')

    # Source for color data
    color_source: EnumProperty(
        name='Color Source',
        description='Define the source of color data for baking',
        items=(
            ('Vertex Color', 'Vertex Color', 'Use vertex color as the color source'),
            ('Mesh ID', 'Mesh Elements ID', 'Use ID of mesh elements as the color source'),
        ),
    )

    # Bevel settings
    apply_bevel: BoolProperty(name='Apply Bevel', description='Apply bevel effect to the baked texture', default=False)
    radius: FloatProperty(name='Radius', description='Radius of the bevel effect.', subtype='DISTANCE', min=0, max=1000)

    # Ambient occlusion option
    only_local: BoolProperty(name='Only Local AO', description='Compute ambient occlusion based only on the object itself', default=True)

    # Normal map format
    normal_format: EnumProperty(
        name='Normal Format',
        description='Format of the normal map',
        items=(
            ('POS_Y', 'OpenGL', 'OpenGL format for normal map'),
            ('NEG_Y', 'DirecX', 'DirectX format for normal map'),
        ),
        default='POS_Y'
    )

    # Color space for the baked image
    color_space: EnumProperty(
        name='Color Space',
        description='Define the color space for the baked image',
        items=(
            ('Non-Color', 'Non-Color', 'Non-Color color space'),
            ('sRGB', 'sRGB', 'sRGB color space'),
        ),
        default='Non-Color',
    )

    # Coefficient property
    coefficient: IntProperty(name='Coefficient', description='Multiplier or factor applied during baking', default=1)

class PHILOGIX_BakeProperties(PropertyGroup):
    is_baking: BoolProperty(
        name='Baking Status', 
        description='Indicates if the software is currently baking textures or not', 
        default=False
        )

    device: EnumProperty(
        name='Bake Device',
        description='Device used for baking operations',
        items=get_device_items
    )

    slots: CollectionProperty(
        name='Bake Slots',
        description='List of bake slots that specify different baking settings',
        type=PHILOGIX_BakeSlots
    )

    margin: IntProperty(
        name='Bake Margin',
        description='Margin (in pixels) around the baked texture to prevent seams',
        min=0, max=64, default=16, subtype='PIXEL'
    )
    
    quality: IntProperty(
        name='Bake Quality',
        description='Quality setting for the baking operation. Higher values might increase bake time',
        min=0, max=32, default=2
    )

    normal_format: EnumProperty(
        name='Normal Format',
        description='Format of the baked normal map',
        items=(
            ('POS_Y', 'OpenGL', 'OpenGL format for normal map'),
            ('NEG_Y', 'DirectX', 'DirectX format for normal map'),
        ),
        default='POS_Y'
    )

    user_high: BoolProperty(
        name='Use High-Poly Mesh',
        description='Use a specified high-poly mesh for generating normal maps',
        default=False
    )
    
    specified_object: PointerProperty(
        name='High-Poly Mesh',
        description='High-poly mesh used for generating normal maps',
        type=bpy.types.Object
    )
    
    cage_extrusion: FloatProperty(
        name='Cage Extrusion',
        description='Amount of extrusion applied to the baking cage',
        min=0, max=1, default=0.035, unit='LENGTH'
    )
    
    max_ray_distance: FloatProperty(
        name='Max Ray Distance',
        description='Maximum distance rays can travel while baking. Useful to avoid intersection artifacts',
        min=0, max=1, default=0, unit='LENGTH'
    )
