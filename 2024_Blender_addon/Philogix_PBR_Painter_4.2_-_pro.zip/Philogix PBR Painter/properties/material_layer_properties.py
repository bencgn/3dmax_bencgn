import bpy
from bpy.types import PropertyGroup
from bpy.props import BoolProperty, StringProperty

from .properties_update import mute_update

from ..utils.general_utilities import make_uid, delimiter_join
from ..utils.object_utilities import get_active_mesh_object
from ..utils.node_utilities import clone_and_update_node_group

def update_mapping_node(self, layer_node):      
    # Update mapping node if it exists and has multiple users
    mapping_node = layer_node.node_tree.nodes.get('Mapping')

    if mapping_node:
        active_object = get_active_mesh_object()
        mapping_name = delimiter_join(self.ID, 'Mapping')

        if mapping_node.node_tree.users > 1:
            mapping_node.node_tree = mapping_node.node_tree.copy()
            if mapping_node.decal_object:
                mapping_node.decal_object = mapping_node.decal_object.copy()

        if mapping_node.decal_object:
            mapping_node.decal_object.name = mapping_name
            mapping_node.decal_object.parent = active_object

        mapping_node.node_tree.name = mapping_name

class PHILOGIX_MaterialLayer(PropertyGroup):
    def regenerate(self):
        layer_node = self.origin_node_tree.nodes.get(self.name)
        self.name = f"Plx_{make_uid(5)}"
        layer_node.name = self.name

        self.make_local()

    def make_local(self):        
        node_group = self.node_group

        if self.ID != node_group.name:
            if node_group.users > 1:
                node_group = node_group.copy()
                self.layer_node.node_tree = node_group

            node_group.name = self.ID

            value_node = node_group.nodes.get('Value')
                   
            if value_node:
                if value_node.node_tree.users > 1:
                    value_node.node_tree = value_node.node_tree.copy()
                    clone_and_update_node_group(value_node.node_tree)

                value_node.node_tree.name = delimiter_join(self.ID, 'SmartMaterial')

            update_mapping_node(self, self.layer_node)

            image_layers = {}

            for node in node_group.nodes:
                if node.bl_idname == 'ShaderNodeGroup':
                    if node == value_node:
                        continue
                    
                    new_name = delimiter_join(self.ID, node.name)
                    
                    if node.node_tree.users > 1:
                        node.node_tree = node.node_tree.copy()

                    node.node_tree.name = new_name

                    for channel_layer in node.node_tree.PlxProps.layers:
                        layer_node = channel_layer.layer_node
                        if channel_layer.node_group.PlxProps.layer_type == 'IMAGE':
                            image_layers[channel_layer] = getattr(layer_node, 'image', None)
                        else:
                            channel_layer.regenerate()

            # Group channel_layers by their associated images
            image_to_layers = {}
            for channel_layer, image in image_layers.items():
                if image not in image_to_layers:
                    image_to_layers[image] = []
                image_to_layers[image].append(channel_layer)

            for image, associated_layers in image_to_layers.items():
                if len(associated_layers) == 1:
                    associated_layers[0].regenerate()

                elif image:
                    for channel_layer in associated_layers:
                        channel_layer.regenerate(False)
                        channel_layer.value_node.image = image.copy()

    def _get_id(self):
        if not self.name: 
            self.name = 'Plx_' + make_uid(5)
        return self.name

    @property
    def origin_node_tree(self):
        return self.id_data.node_tree
    
    @property
    def layer_node(self):
        return self.origin_node_tree.nodes.get(self.ID)

    @property
    def node_group(self):
        if (self.layer_node and 
            self.layer_node.node_tree and 
            self.layer_node.node_tree.PlxProps.layer_type in ['MATERIAL', 'CUSTOM']):
            return self.layer_node.node_tree
            
    @property
    def value_node(self):
        if self.node_group:
            return self.node_group.nodes.get('Value')

    @property
    def channel_node_group(self):
        if not self.node_group:
            return
        mat_props = self.id_data.PlxProps
        if self.node_group.PlxProps.layer_type == 'MATERIAL':
            channel_node = self.node_group.nodes.get('Layer Mask')
        else:
            channel_node = self.node_group.nodes.get(mat_props.edit_maps)
        if channel_node: 
            return channel_node.node_tree

    ID: StringProperty(
        name='ID',
        description='Unique identifier for the channel layer',
        get=_get_id,
    )

    mute: BoolProperty(
        default=False,
        name='Mute',
        description='Toggle to mute/unmute the paint layer',
        update=mute_update
    )

    selected: BoolProperty(
        default=False,
        name='Selected',
        description='Toggle to select/deselect the paint layer'
    )
