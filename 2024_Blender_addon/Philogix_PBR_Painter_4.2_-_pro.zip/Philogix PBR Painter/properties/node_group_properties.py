import bpy
from bpy.types import PropertyGroup
from bpy.props import IntProperty, CollectionProperty, BoolProperty, EnumProperty, PointerProperty

from . import channel_layer_properties, layer_projection_properties, properties_update

class PHILOGIX_NodeGroupProps(PropertyGroup):
    @property
    def active_layer(self):
        if 0 <= self.layers_index < len(self.layers):
            return self.layers[self.layers_index]
    

    layer_type: EnumProperty(
        name='Layer Type',
        items=(
            ('NONE', 'None', ''),
            ('CUSTOM', 'Custom Layer', 'Custom layer type'),
            ('MATERIAL', 'Smart Material Layer', 'Smart material layer type'), 
            ('SURFACE', 'Surface Layer', 'Layer type for surfaces'),
            ('IMAGE', 'Image Layer', 'Layer type for images'),
            ('ANCHOR', 'Anchor Layer', 'Layer type for anchors'),
            ('ID', 'ID Layer', 'Layer type for IDs'),
            ('FILTER', 'Filter Layer', 'Layer type for filters'),
        ),

        default=None,
        description='The type of the paint layer',
    )
    
    icon_value: IntProperty(
        default=1,
        name='Icon Value',
        description='The icon value associated with this layer'
    )

    uv_settings: PointerProperty(
        type=layer_projection_properties.PHILOGIX_UVSettings,
        name='UV Settings',
        description='Pointer to the UV settings for this layer'
    )
        

    channel_anchor: BoolProperty(
        name='Anchor Point', 
        default=False,
        description='Toggle to indicate if this channel is an anchor point'
    )

    layers: CollectionProperty(
        type=channel_layer_properties.PHILOGIX_ChannelLayer,
        name='Channel Layers',
        description='Collection of channel layers associated with this paint layer'
    )
    
    layers_index: IntProperty(
        name='', 
        default=-1,
        update=properties_update.channel_layer_index_update,
        options={'LIBRARY_EDITABLE'},
        description='Index of the selected channel layer'
    )
