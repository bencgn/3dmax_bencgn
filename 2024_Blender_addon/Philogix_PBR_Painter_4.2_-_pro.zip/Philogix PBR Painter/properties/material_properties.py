import bpy
from bpy.types import PropertyGroup
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, CollectionProperty

from . import material_layer_properties, properties_update

def get_edit_maps_item(self, context):
    items = []

    mat_channels = self.id_data.PlxProps.channels

    for mat_channel in sorted(mat_channels, key=lambda channel: channel.ID):
        items.append((mat_channel.name , '', mat_channel.description, mat_channel.icon, mat_channel.ID))

    items.insert(-1, None)

    return items

class PHILOGIX_MaterialChannels(PropertyGroup):
    ID: IntProperty()
    name: StringProperty()
    node_name: StringProperty()
    description: StringProperty()
    icon: StringProperty(default='NONE')
    active: BoolProperty(default=False)
    color_space: StringProperty()

class PHILOGIX_MaterialProps(PropertyGroup):
    @property
    def material_layer(self):
        if self.layers and (0 <= self.layers_index < len(self.layers)):
            return self.layers[self.layers_index]
        return None
    
    @property
    def channel_group(self):
        if self.material_layer:
            return self.material_layer.channel_node_group
        
    @property
    def channel_layer(self):
        if self.channel_group:
            self.channel_group.PlxProps.active_layer

    ID: StringProperty(
        name='ID',
        description='An identifier for the material property'
    )

    workflow: StringProperty(
        name='Workflow',
        description='The workflow associated with the material'
    )

    channels: CollectionProperty(
        type=PHILOGIX_MaterialChannels,
        name='Channels',
        description='A collection of material channels',
    )

    layers: CollectionProperty(
        type=material_layer_properties.PHILOGIX_MaterialLayer,
        name='Layers',
        description='A collection of paint layers'
    )

    layers_index: IntProperty(
        name='Layers Index',
        description='The index of the selected paint layer',
        update=properties_update.material_layer_index_update,
        options={'LIBRARY_EDITABLE'}
    )

    edit_maps: EnumProperty(
        name='Edit Channels',
        description='This option allows converting the channel to be edited in the layers below',
        items=get_edit_maps_item,
        default=1,
        options={'SKIP_SAVE'}
    )
