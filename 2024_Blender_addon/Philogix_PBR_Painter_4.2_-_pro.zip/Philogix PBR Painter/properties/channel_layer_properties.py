import bpy
from bpy.types import PropertyGroup
from bpy.props import (
    IntProperty,
    BoolProperty,
    StringProperty,
    EnumProperty
)
from .properties_update import mute_update

from ..utils.object_utilities import get_active_mesh_object
from ..utils.general_utilities import make_uid, delimiter_join


def update_mapping_node(self, layer_node):      
    # Update mapping node if it exists and has multiple users
    mapping_node = layer_node.node_tree.nodes.get('Mapping')

    if mapping_node:
        active_object = get_active_mesh_object()
        mapping_name = delimiter_join(self.ID, 'Mapping')

        if mapping_node.node_tree.users > 1:
            mapping_node.node_tree = mapping_node.node_tree.copy()
            if mapping_node.decal_object:
                mapping_node.decal_object = mapping_node.decal_object.copy()

        if mapping_node.decal_object:
            mapping_node.decal_object.name = mapping_name
            mapping_node.decal_object.parent = active_object

        mapping_node.node_tree.name = mapping_name

def clone_and_update_node_group(node_group, copied_images_dict=None, copied_node_trees_dict=None):
    if copied_images_dict is None:
        copied_images_dict = {}
    
    if copied_node_trees_dict is None:
        copied_node_trees_dict = {}

    for node in node_group.nodes:
        if hasattr(node, 'node_tree') and node.node_tree:
            # Nếu node_tree chưa được copy, tạo một bản copy và lưu vào dictionary
            if node.node_tree not in copied_node_trees_dict:
                copied_node_tree = node.node_tree.copy()
                copied_node_trees_dict[node.node_tree] = copied_node_tree
                clone_and_update_node_group(copied_node_tree, copied_images_dict, copied_node_trees_dict)
            # Gán node hiện tại với bản copy từ dictionary
            node.node_tree = copied_node_trees_dict[node.node_tree]

        elif hasattr(node, 'image') and node.image:
            # Nếu image chưa được copy, tạo một bản copy và lưu vào dictionary
            if node.image not in copied_images_dict:
                new_image = node.image.copy()
                if node.image.is_dirty:
                    new_image.pixels[:] = node.image.pixels[:]
                copied_images_dict[node.image] = new_image
            # Gán node hiện tại với bản copy từ dictionary
            node.image = copied_images_dict[node.image]


def image_source_update(self, context):
    self.value_node.image.source = self.image_source

def channels_output_update(self, context):
    node_tree = self.node_group
    
    math_node = node_tree.nodes.get('Math')
    value_node = node_tree.nodes.get('Value')
    separate_node = node_tree.nodes.get('Separate')
    output_node = node_tree.nodes.get('GroupOutput')
    
    if math_node:
        for link in math_node.inputs[0].links:
            node_tree.links.remove(link)

    if self.channels_output == 'Color&Alpha':
        output = value_node.outputs.get('Color')
        if value_node and math_node and output:
            node_tree.links.new(value_node.outputs.get('Alpha'), math_node.inputs[0])

    elif self.channels_output in ['Color', 'Alpha']:
        output = value_node.outputs.get(self.channels_output)

    else:
        if separate_node:
            output = separate_node.outputs.get(self.channels_output, separate_node.outputs.get(self.channels_output[0]))
        
    if output and output_node:
        node_tree.links.new(output, output_node.inputs.get('Color'))



class PHILOGIX_ChannelLayer(PropertyGroup):

    def regenerate(self, copy_image = True):
        old_id = self.name
        new_id = 'Plx_' + make_uid(5)
        channel_layers = self.id_data.PlxProps.layers

        node_tree = self.origin_node_tree

        layer_node = node_tree.nodes.get(old_id)
        frame_node = node_tree.nodes.get(delimiter_join(old_id, 'Frame'))
        blend_node = node_tree.nodes.get(delimiter_join(old_id, "MixLayer"))
        opacity_node = node_tree.nodes.get(delimiter_join(old_id, "MixOpacity"))

        self.name = new_id

        layer_node.name = new_id
        frame_node.name = delimiter_join(new_id, 'Frame')
        blend_node.name = delimiter_join(new_id, 'MixLayer')
        opacity_node.name = delimiter_join(new_id, 'MixOpacity')

        if self.parent_layer_id == old_id:
            self.parent_layer_id = new_id

        for channel_layer in channel_layers:
            if channel_layer.parent_layer_id == old_id:
                channel_layer.parent_layer_id = new_id

        self.make_local(copy_image)
    
    def make_local(self, copy_image=True):
        if self.ID != self.node_group.name:
            layer_node = self.layer_node
            self._update_node_tree(layer_node)
            update_mapping_node(self, layer_node)
                        
            layer_actions = {
                'ID': self._process_id_layer,
                'IMAGE': self._process_image_layer,
                'SURFACE': self._process_surface_layer
            }
            
            layer_type = layer_node.node_tree.PlxProps.layer_type
            if layer_type in layer_actions:
                layer_actions[layer_type](copy_image)

    def _update_node_tree(self, layer_node):
        if layer_node.node_tree.users > 1:
            layer_node.node_tree = layer_node.node_tree.copy()
        layer_node.node_tree.name = self.ID

    def _process_id_layer(self, copy_image):
        value_node = self.value_node
        value_node.node_tree = value_node.node_tree.copy()
        value_node.node_tree.name = delimiter_join(self.ID, 'ColorMask')

    def _process_image_layer(self, copy_image):
        value_node = self.value_node
        image = value_node.image
        if image and copy_image and image.plx_mesh_image_baking is None:
            new_image = image.copy()
            if image.is_dirty:
                new_image.pixels[:] = image.pixels[:]
            value_node.image = new_image

    def _process_surface_layer(self, copy_image):
        value_node = self.value_node
        if value_node.node_tree.users > 1:
            value_node.node_tree = value_node.node_tree.copy()
            clone_and_update_node_group(value_node.node_tree)
        value_node.node_tree.name = delimiter_join(self.ID, 'SmartSurface')

    def _get_id(self):
        if not self.name: 
            self.name = 'Plx_' + make_uid(5)
        return self.name
    
    @property
    def parent(self):
        channel_layers = self.id_data.PlxProps.layers
        #layer_dict = {layer.ID: layer for layer in channel_layers}
        return channel_layers.get(self.parent_layer_id, self)
    
    @property
    def origin_node_tree(self):
        return self.id_data

    @property
    def layer_node(self):
        return self.id_data.nodes.get(self.ID)
    
    @property
    def node_group(self):
        if self.layer_node:
            return self.layer_node.node_tree
        
    @property
    def value_node(self):
        if self.node_group:
            return self.node_group.nodes.get('Value')
    
    ID: StringProperty(
        name='ID',
        description='Unique identifier for the channel layer',
        get=_get_id,
    )
    
    mute: BoolProperty(
        default=False,
        name='Mute',
        description='Toggle to mute/unmute the paint layer',
        update=mute_update
    )
    
    selected: BoolProperty(
        default=False,
        name='Selected',
        description='Toggle to select/deselect the channel layer'
    )

    parent_layer_id: StringProperty(
        name='Parent ID',
        description='Identifier of the parent channel layer',
    )
    
    numb_sublayers: IntProperty(
        default=0,
        name='Sub Number',
        description='Sub number for the channel layer',
    )

    channels_output: EnumProperty(
        name='Channels Output',
        description='Specifies the channel to output in the layer',
        items=(
            ('Color&Alpha', 'RGB+A', 'Output channel for color and alpha'),
            ('Color', 'RGB', 'Output channel for color only'),
            ('Alpha', 'Alpha', 'Output channel for alpha only'),
            ('', 'Output Channel', ''),
            ('Red', 'Red', 'Output channel for red'),
            ('Green', 'Green', 'Output channel for green'),
            ('Blue', 'Blue', 'Output channel for blue'),
        ),
        default='Color&Alpha',
        update=channels_output_update,
    )

    image_source: EnumProperty(
        name='Image Source',
        description='Where the image comes from',
        items=(
            ('FILE', 'Single Image', 'Single image file'),
            ('GENERATED', 'Generated', 'Generated image'),
            ('TILED', 'UDIM Tiles', 'Tiled UDIM image texture')
        ),
        default='FILE',
        update=image_source_update,
    )


