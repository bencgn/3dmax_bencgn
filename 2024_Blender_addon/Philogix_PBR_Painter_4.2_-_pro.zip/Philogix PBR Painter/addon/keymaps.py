import bpy

from math import degrees, radians
from bpy.types import Menu

class PHILOGIX_MT_Preview(Menu):
    bl_idname = "PHILOGIX_MT_Preview"
    bl_label = "Select Preview"

    def draw(self, context):
        props = context.scene.PlxProps
        layout = self.layout

        pie = layout.menu_pie()
        pie.prop(props, 'pie_preview', text='Preview', expand=True)

class PHILOGIX_OT_RotateBG(bpy.types.Operator):
    bl_idname = "plx.rbg"
    bl_label = "Rotate Background"

    def modal(self, context, event):
        bpy.context.window.cursor_set("MOVE_X")

        if event.type == "RIGHTMOUSE" and event.value == "RELEASE":
            context.window.cursor_set("DEFAULT")
            return {'FINISHED'}
        
        elif event.type == "ESC":
            context.window.cursor_set("DEFAULT")
            return {'CANCELLED'}
        
        factor = 0.25
        value = (event.mouse_x - self.startValue) * factor
        value = self.startRotation + value
        
        if value >= 180:
            value -= 360
        elif value <= -180:
            value += 360

        context.area.spaces[0].shading.studiolight_rotate_z = radians(value)
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area and context.area.type == "VIEW_3D":
            self.startValue = event.mouse_x

            shading = context.area.spaces[0].shading
            self.startRotation = degrees(shading.studiolight_rotate_z)
            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        return {'FINISHED'}


classes = (PHILOGIX_MT_Preview, PHILOGIX_OT_RotateBG)

hotkey_data = {
    "3D View Generic": [
        ("wm.call_menu_pie", 'V', 'PRESS', False, False, False, "PHILOGIX_MT_Preview"),
        ("plx.rbg", "RIGHTMOUSE", "PRESS", False, False, True, None),
    ],
}

addon_keymaps = []

def get_hotkey_entry_item(kc, km_name, kmi_name, kmi_value = None):
    km = kc.keymaps[km_name]

    for kmi in km.keymap_items:
        if kmi.idname  == kmi_name:
            properties = kmi.properties
            
            if kmi_value and hasattr(properties, 'name'):
                if properties.name == kmi_value:
                    return km, kmi
            else:
                return km, kmi
            
    return km, None


def add_hotkey():
    wm = bpy.context.window_manager

    for keymap_name, keymap_data in hotkey_data.items():
        if keymap_name == "3D View Generic":
            km = wm.keyconfigs.addon.keymaps.new(name=keymap_name, space_type='VIEW_3D', region_type='WINDOW')
        else:
            km = wm.keyconfigs.addon.keymaps.new(name=keymap_name, space_type='EMPTY', region_type='WINDOW')

        for idname, key, key_type, shift, ctrl, alt, name in keymap_data:
            kmi = km.keymap_items.new(idname, key, key_type, shift=shift, ctrl=ctrl, alt=alt)
            if name: kmi.properties.name = name
            addon_keymaps.append((km, kmi))

def remove_hotkey():
    ''' clears all addon level keymap hotkeys stored in addon_keymaps '''
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)

    addon_keymaps.clear()


def register():
    for c in classes:
        bpy.utils.register_class(c)
    add_hotkey()

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
    remove_hotkey()