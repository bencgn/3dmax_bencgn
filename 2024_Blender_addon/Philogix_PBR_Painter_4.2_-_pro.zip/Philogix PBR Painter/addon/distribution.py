import bpy, os
import bpy.utils.previews

from ..utils.general_utilities import get_data_directory, draw_popup_menu, print_message, MessageType

from ..core.registration_manager import RegistrationManager
from ..core.serializer.file_serializer import JsonFile
from ..core.serializer.properties_serializer import PropertiesSerializer

class DirectoryReader:
    @staticmethod
    def get_images_path(dir_path):
        valid_extensions = ['.png', '.jpg', '.jpeg']
        return [os.path.join(dir_path, img) 
                for img in os.listdir(dir_path) 
                if os.path.splitext(img)[1].lower() in valid_extensions]
    
class PreviewsCollection:
    previews = {}
    bpy_previews = None

    @classmethod
    def initialize(cls):
        if not cls.bpy_previews:
            cls.bpy_previews = bpy.utils.previews.new()
        sys_data_directory = get_data_directory(True)
        icon_dir = os.path.join(sys_data_directory, "Icons")
        images_path = DirectoryReader.get_images_path(icon_dir)

        for image_path in images_path:
            image_name = os.path.basename(image_path).split('.')[0]
            preview_key = image_name.replace("_Preview", "")
            if preview_key not in cls.previews:
                cls.add_preview(preview_key, image_path)

    @classmethod
    def add_preview(cls, preview_key, preview_path):
        if not os.path.isfile(preview_path):
            return 1
        
        if preview_key in  cls.bpy_previews:
            del cls.bpy_previews[preview_key]

        icon = cls.bpy_previews.load(preview_key, preview_path, 'IMAGE', True)
        cls.previews[preview_key] = icon.icon_id

        return icon.icon_id

    @classmethod
    def clear_previews(cls):
        if cls.bpy_previews:
            bpy.utils.previews.remove(cls.bpy_previews)
            cls.bpy_previews = None
        cls.previews.clear()

    @classmethod
    def get_preview_id(cls, preview_key):
        if cls.previews:
            preview = cls.previews.get(f"{preview_key}")
            return preview if preview else 1

class AssetCollection:
    assets = {}

    @classmethod
    def _sort_chain_by_index(cls, chain):
        sorted_chain = dict(sorted(chain.items(), key=lambda x: x[1]["index"]))
        for idx, asset_id in enumerate(sorted_chain):
            sorted_chain[asset_id]['index'] = idx
        return sorted_chain
    
    @classmethod
    def initialize(cls):
        collection_file_mapping = {
            get_data_directory(True): True,
            get_data_directory(False): False,
        }

        for data_directory, is_system in collection_file_mapping.items():
            collection_file = JsonFile(os.path.join(data_directory, 'asset_collection.json'))
            collection_info = collection_file.read()

            if not collection_info:
                continue

            for asset_type, chain in collection_info.items():
                sorted_chain = cls._sort_chain_by_index(chain)
                for asset_id, asset_info in sorted_chain.items():
                    asset_name = asset_info.get("name")
                    asset_index = asset_info.get("index")
                    rna_type = asset_info.get("type_name")
                    asset_category = asset_info.get("category")
                    preview_path = cls._identify_preview_path(asset_id, is_system)

                    PreviewsCollection.add_preview(asset_id, preview_path)

                    cls.add_asset(asset_id, asset_name, asset_index, rna_type, asset_type, asset_category, preview_path, is_system)

    @classmethod
    def add_asset(cls, asset_id, asset_name, index, rna_type, asset_type, category, preview_path, is_system):
        data_directory = get_data_directory(is_system, asset_type)
        asset_path = os.path.join(data_directory, f"{asset_id}.plx{rna_type[0].lower()}")

        data_dict = {
            "type_name": rna_type,
            "name": asset_name,
            "index": index,
            "path": asset_path,
            "category": category,
            "is_system": is_system,
            "asset_type": asset_type,
            "preview_path": preview_path,
        }

        cls.assets[asset_id] = data_dict

        return cls.assets[asset_id]

    @classmethod
    def remove_asset(cls, data_id):
        data_dict = cls.assets.get(data_id)

        if data_dict:
            cls._delete_asset_files(data_dict)
            cls.update_collection_file(data_id, is_del=True)
            del cls.assets[data_id]
            return True
        return False
    
    @classmethod
    def update_asset(cls, asset):
        asset_info = cls.assets.get(asset.PlxAssetId)

        if not asset_info:
            print_message(f"ID assets not found! '({asset.PlxAssetId})'", MessageType.WARNING)
            return
        
        if not RegistrationManager().is_dev_version and asset_info["is_system"]:
            draw_popup_menu('Warning', "Does not have permission to change Asset information!", 'INFO')
            return asset_info
                
        asset_info["name"] = asset.PlxAssetName
        asset_info["asset_type"] = asset.PlxAssetType
        asset_info["category"] = asset.PlxAssetCategory

    @classmethod
    def update_collection_file(cls, asset_id, is_del=False):
        asset_info = cls.assets[asset_id]
        is_system = asset_info["is_system"]
        asset_type = asset_info["asset_type"]

        data_directory = get_data_directory(is_system)
        collection_file_path = os.path.join(data_directory, "asset_collection.json")

        collection_file = JsonFile(collection_file_path)
        json_data = collection_file.read()
        type_info = json_data.get(asset_type)

        if not type_info:
            json_data[asset_type] = {}

        if asset_id in json_data[asset_type]:
            del json_data[asset_type][asset_id]

        if not is_del:
            json_data[asset_type][asset_id] = {
                "name": asset_info["name"],
                "index": asset_info["index"],
                "category": asset_info["category"],
                "type_name": asset_info["type_name"]
            }

        for json_asset_id in json_data[asset_type]:
            index = cls.assets[json_asset_id].get('index') or 0
            json_data[asset_type][json_asset_id]['index'] = index

        collection_file.write(json_data)

        
    @classmethod
    def get_preview_path(cls, asset_id):
        return cls.assets.get(asset_id, {}).get('preview_path', '')

    @classmethod
    def get_asset_items(cls, asset_type, category='All', search_keyword=''):
        asset_items = {}
        search_keyword = search_keyword.lower()
        category_items = AssetCategory.get_category_items(asset_type)

        for asset_id, asset_info in cls.assets.items():
            if asset_info["asset_type"] != asset_type:
                continue

            in_search = not search_keyword or search_keyword in asset_info['name'].lower()

            if (in_search and (
                (category == 'All' or asset_info["category"] == category) or
                (category == 'Other' and asset_info["category"] not in category_items))):

                asset_items[asset_id] = {
                    'name': asset_info['name'],
                    'preview': PreviewsCollection.get_preview_id(asset_id),
                    'is_system': asset_info['is_system']
                    }

        return asset_items


    @classmethod
    def _identify_preview_path(cls, asset_id, is_system):
        data_directory = get_data_directory(is_system, 'Previews')
        return os.path.join(data_directory, f"{asset_id}_Preview.PNG")
    
    @classmethod
    def _delete_asset_files(self, data_dict):
        for file_path in [data_dict["path"], data_dict["preview_path"]]:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception as e:
                    print_message(f"Error deleting file {file_path}: {e}", MessageType.ERROR)

class ExportPresets():
    sys_presets = {}
    user_presets = {}

    @classmethod
    def initialize(cls):
        sys_presets_path = os.path.join(get_data_directory(True), 'export_presets.json')
        user_presets_path = os.path.join(get_data_directory(False), 'export_presets.json')
        cls.sys_presets = JsonFile(sys_presets_path).read()
        cls.user_presets = JsonFile(user_presets_path).read()

    @classmethod
    def add_preset(cls, preset_name, is_system):        
        key_numbers = (int(key.split('.')[1]) 
                       for category in [cls.sys_presets, cls.user_presets] 
                       for key in category if key.startswith("preset."))
        
        max_key = max(key_numbers, default=0)
        new_key = f"preset.{max_key + 1}"
        new_preset = {
            'is_dirty': True,
            'name': preset_name,
            'attrs': cls.sys_presets['new']['attrs']
            }

        if is_system:
            cls.sys_presets[new_key] = new_preset
        else:
            cls.user_presets[new_key] = new_preset

        return new_key

    @classmethod
    def update_preset(cls, preset_id, export_name=None, export_props=None):
        presets =  {**cls.sys_presets, **cls.user_presets}
        preset_info = presets.get(preset_id)
        
        if not preset_info:
            print_message(f"Preset not found! '({preset_id})'", MessageType.WARNING)
            return
        
        if export_name:
            preset_info['is_dirty'] = True
            preset_info['name'] = export_name

        if export_props:
            preset_info['is_dirty'] = False
            preset_info['attrs'] = PropertiesSerializer(export_props).to_dict()

    @classmethod
    def remove_preset(cls, preset_id):
        if preset_id in cls.sys_presets:
            del cls.sys_presets[preset_id]
        elif preset_id in cls.user_presets:
            del cls.user_presets[preset_id]
        else:
            print_message(f"Preset not found! '({preset_id})'", MessageType.WARNING)
            return

    @classmethod
    def update_presets_file(cls, is_system):
        presets = cls.sys_presets if is_system else cls.user_presets
        category_path = os.path.join(get_data_directory(is_system), 'export_presets.json')
        category_file = JsonFile(category_path)
        category_file.write(presets)

    @classmethod
    def get_items(cls):
        preset_items = {}
        for preset_id, preset_info in cls.sys_presets.items():
            if preset_id == 'new': continue
            preset_info['is_system'] = True
            preset_items[preset_id] = preset_info
        preset_items['NONE'] = None
        for preset_id, preset_info in cls.user_presets.items():
            preset_info['is_system'] = False
            preset_items[preset_id] = preset_info
        return preset_items
    
class AssetCategory():
    sys_category = {}
    user_category = {}

    @classmethod
    def initialize(cls):
        sys_category_path = os.path.join(get_data_directory(True), 'asset_category.json')
        user_category_path = os.path.join(get_data_directory(False), 'asset_category.json')

        cls.sys_category = JsonFile(sys_category_path).read()
        cls.user_category = JsonFile(user_category_path).read()

    @classmethod
    def add_category(cls, category_type, category_name):        
        sys_category = cls.sys_category.get(category_type)
        user_category = cls.user_category.get(category_type, {})

        key_numbers = (int(key.split('.')[1]) 
                       for category in [sys_category, user_category] 
                       for key in category if key.startswith("category."))
        
        max_key = max(key_numbers, default=0)
        new_key = f"category.{max_key + 1}"

        if not user_category:
            cls.user_category[category_type] = {}

        cls.user_category[category_type][new_key] = category_name

        cls.update_category_file()

    @classmethod
    def remove_category(cls, category_type, category_key):
        if category_key in cls.user_category[category_type]:
            del cls.user_category[category_type][category_key]
        else:
            print_message(f"Category key {category_key} not found in {category_type}", MessageType.WARNING)

        cls.update_category_file()

    @classmethod
    def update_category_file(cls):
        user_category_path = os.path.join(get_data_directory(False), 'asset_category.json')
        category_file = JsonFile(user_category_path)
        category_file.write(cls.user_category)

    @classmethod
    def get_category_items(cls, asset_type):
        category_items = {}
        sys_category = cls.sys_category.get(asset_type, {})
        user_category = cls.user_category.get(asset_type, {})

        for category_id, category_name in sys_category.items():
            category_items[category_id] = {"name": category_name, "is_system": True}

        category_items['NONE'] = None

        for category_id, category_name in user_category.items():
            category_items[category_id] = {"name": category_name, "is_system": False}

        return category_items
        
    @classmethod
    def get_enum_items(cls, asset_type, only_real_category=False):
        sys_category = cls.sys_category[asset_type]
        user_category = cls.user_category.get(asset_type, {})

        enum_items = [('All', 'All', "")] if not only_real_category else []
        enum_items += [(cat_id, cat_name, "") for cat_id, cat_name in sys_category.items()]
        enum_items += [('Other', 'Other...', ""), (None)] if not only_real_category else [(None)]
        enum_items += [(cat_id, cat_name, "") for cat_id, cat_name in user_category.items()]

        return enum_items


def register():
    PreviewsCollection.initialize()
    AssetCollection.initialize()
    ExportPresets.initialize()
    AssetCategory.initialize()

def unregister():
    PreviewsCollection.clear_previews()

