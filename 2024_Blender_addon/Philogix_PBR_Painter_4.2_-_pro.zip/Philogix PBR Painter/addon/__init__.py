import bpy

from . import distribution, preferences, keymaps

classes = (
    preferences.PHILOGIX_AddonPreferences,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

    keymaps.register()
    distribution.register()

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
        
    keymaps.unregister()
    distribution.unregister()
