import bpy, rna_keymap_ui
from . import keymaps

class PHILOGIX_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__.split('.')[0]

    def draw(self, context):
            layout = self.layout
            split = layout.split()
            col = split.column()

            wm = context.window_manager
            kc = wm.keyconfigs.user

            row = col.row(align=True)
            row.label(text="Keymaps")

            keymap_restore = False
            for keymap_name, keymap_data in keymaps.hotkey_data.items():

                col.separator()

                for idname, key, key_type, shift, ctrl, alt, name in keymap_data:
                    km, kmi = keymaps.get_hotkey_entry_item(kc, keymap_name, idname, name)

                    if kmi:
                        col.context_pointer_set("keymap", km)
                        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)

                    elif not keymap_restore:
                        keymap_restore = True
                        subrow = row.row()
                        subrow.alignment = 'RIGHT'
                        subrow.context_pointer_set("keymap", km)
                        subrow.operator("preferences.keymap_restore", text="Restore")