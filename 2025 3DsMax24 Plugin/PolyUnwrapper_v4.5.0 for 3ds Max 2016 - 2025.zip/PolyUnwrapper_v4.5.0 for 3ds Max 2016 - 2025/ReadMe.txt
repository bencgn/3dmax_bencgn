------------------------------------------------------------------------------------------------------------
                       PolyUnwrapper v4.5.0 for 3ds Max 2016 - 2025 | Repack | by msi
------------------------------------------------------------------------------------------------------------

Just install & enjoy:
- Drag&drop the MZP file into 3dsmax window or run it from the menu Maxscript -> Run Script
- Press "Install" button


Notes:

If you have v3 installed, uninstall it first.

If you don't want to use the built-in license then Open Unwrap Editor > PolyUnwrapper toolbar > ? > Register
Type any name and paste one of these serials:

44921681620388665829
72092255326566391384
38057157397859015230
26994739181961362986
74538724329542998772
44633089361419859770
59281856257329119778
68781275127561366801
66861910938251829153
25077634574942581805


					iggtech.com