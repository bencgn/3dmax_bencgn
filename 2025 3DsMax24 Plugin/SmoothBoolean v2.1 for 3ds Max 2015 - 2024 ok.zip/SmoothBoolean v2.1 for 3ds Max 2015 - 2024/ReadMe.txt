-------------------------------------------------------------------------
     SmoothBoolean v2.1 for 3ds Max 2015 - 2024 x64 | Repack | by msi
-------------------------------------------------------------------------

Just install & enjoy.



if the plugin appears as not activated then activate it with this serial:

BOOBQBOOBSBOOBSBOOBPUBOOB


iggtech.com