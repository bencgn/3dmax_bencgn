------------------------------------------------------------------------
     Weight Pro v2.01 for 3ds Max 2013 - 2024 x64 | Repack | by msi
------------------------------------------------------------------------

Just install & enjoy.



if the plugin appears as not activated then activate it with this serial:

U41UU41UU41UU41UU41UU4UU


iggtech.com