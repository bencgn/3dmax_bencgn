-----------------------------------------------------------------------------------------------------------------------
                               ReDeform 1.0.3.1 for 3ds Max 2015 - 2024 | Patch | by msi
-----------------------------------------------------------------------------------------------------------------------
			iggtech.com

1.  Copy ReDeform_20XXx64.dlm file to the Max plugins directory, e.g:  "C:\Program Files\Autodesk\3ds Max 2023\plugins"

2.  Enjoy!




Notes:


ReDeform_20XXx64_net.dlm - network version of the plugin for distributive rendering.

2016 plugins are patched to load in Max 2015, but there's no any guarantee that they work flawlessly