﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version
# n
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####n
## Script copyright (C) Andrea Donati
##

bl_info = {
    "name": "HDRi Maker",
    "author": "Andrea Donati",
    "version": (2, 0, 87),
    "blender": (2, 90, 0),
    "location": "View3D > Tools > HDRi Maker",
    "description": "Big hdri management",
    "category": "3D View"}

import bpy, re, os, bpy.utils.previews, webbrowser, shutil, time, datetime, zipfile, addon_utils, requests, textwrap
from bpy.props import StringProperty, BoolProperty, IntProperty, FloatProperty, EnumProperty, FloatVectorProperty
from bpy.types import PropertyGroup, Panel, Scene, AddonPreferences, Operator, Material, WindowManager, Object, World, \
    Image, Node, Texture
from bpy.utils import register_class, unregister_class
from os.path import join, isfile, basename
from os import listdir
from math import radians
from bpy import data
from itertools import chain
from bpy_extras.io_utils import ExportHelper, ImportHelper
from mathutils import Vector
from bpy.app.handlers import persistent
from distutils.util import strtobool
from html.parser import HTMLParser

contextEngine = None


###########################
class PercorsoHDRiMaker(AddonPreferences):
    bl_idname = __name__

    first_installation: BoolProperty(default=False,
                                     description='Use this menu if this is your first time using HDRi Maker')
    module_status: BoolProperty(default=False, description='Check the installed modules')
    update_pack: BoolProperty(default=False,
                              description='Use this menu if you have downloaded HDMK_XPAND packages. If you do not have these packages or would like to know more, consult the user manual')
    folder_installation: BoolProperty(default=False,
                                      description='Use this menu if this is your first time using HDRi Maker')
    menu_installation: EnumProperty(default='FINSTALL', items=(
    ('FINSTALL', 'First Installation:', "Use this menu if this is your first time using HDRi Maker", 'AUTO', 1),
    ('UPDATE', 'Install expansion pack',
     'Use this menu if you have downloaded HDMK_XPAND packages. If you do not have these packages or would like to know more, consult the user manual',
     'ASSET_MANAGER', 2),
    ('FOLDERS', 'Library Management', 'Use this menu if this is your first time using HDRi Maker', 'FILE_FOLDER', 3)))

    hdriLib_fromZip: StringProperty(name="Zips Source", subtype='DIR_PATH',
                                    description='Choose the path where the downloaded zip files of the main library are (HDRI_MAKER_LIB), are numbered with the system 0_1, 0_2, 0_3, ... etc. Make sure you have downloaded them all')
    hdriLib_unZip: StringProperty(name="Installation Path", subtype='DIR_PATH',
                                  description='Choose the path where to install the main library, a folder will be created automatically with the name HDRI_MAKER_LIB which will contain all the main library of materials')

    hdri_maker_library: StringProperty(name="HDRI_MAKER_LIB", subtype='DIR_PATH',
                                       description='You must choose the "HDRi_MAKER_LIB" folder you downloaded.')
    hdri_maker_user_library: StringProperty(name="User Library", subtype='DIR_PATH',
                                            description="""If you had previously created a material library (With HDRi Maker), enter the path If this is the first time you do it, you need to create a folder in a path that you feel is appropriate (The folder must be new and empty) and use it as a materials save folder.To the rest, HDRi Maker thinks of saving correctly""")
    installation_time: BoolProperty(default=False)
    conteggioLibrerieZip: IntProperty(default=0)

    hdrimaker_library_name: StringProperty()
    hdri_maker_user_library_name: StringProperty()
    possiedo_le_librerie: StringProperty(name="User Library", subtype='DIR_PATH')

    aprox_time: FloatProperty()

    def draw(self, context):
        self.relative_path = False
        layout = self.layout
        # expansionModule(self,context)
        # masterModule(self,context)
        box = layout.box()
        box.label(text='HDRi Maker smart Management:', icon='OUTLINER_DATA_ARMATURE')
        box.label(
            text='Choose the operation you need to do, and open the menu you need (For the first installation choose the first on the left)')
        row = box.row()
        row.label(text='If you have problems consult the PDF:')
        row.operator("hdrimaker.info", text='PDF').options = '2'
        row = box.row()
        row.label(text='Remember to save your preferences, and to restart Blender after a successful installation')

        if self.installation_time is False:

            row = box.row()
            row.scale_y = 2
            row.prop(self, "menu_installation", text='Choose', expand=True)

            if self.menu_installation == 'FINSTALL':

                box = layout.box()
                box.label(text='Smart library installation:', icon='INFO', translate=True)
                box.label(text='First step:', icon='EVENT_A')
                box.label(
                    text='Make sure you have downloaded all the libraries before proceeding, everything you have downloaded')
                box.label(text='must be in a unique folder The necessary Zip files will be chosen automatically')
                box.label(
                    text='HDMK_LIB_VOL and HDMK_XPAND (Library expansions) will be installed in this operation (Recommended)')
                box.label(text='Search the PATH where you put ALL the downloads:')
                box.prop(self, "hdriLib_fromZip", text='Zip libraries path', icon='EVENT_A')
                box.label(text='Second step:', icon='EVENT_B')
                box.label(
                    text='Choose a path on your Computer where the library will be created automatically (Do not use the addon path!)')
                box.label(text='Requires minimum 46 GB of hard disk space')
                box.prop(self, "hdriLib_unZip", text='Install Path', icon='EVENT_B')
                box.label(text='Third step', icon='EVENT_C')
                box.label(text='Have you already created custom materials with HDRi Maker before? If the answer is yes')
                box.label(text='choose the path to your User Library and enter it in this box. If this is not')
                box.label(
                    text="the case or you don't know what I'm talking about, don't worry and leave this path empty")
                box.prop(self, "possiedo_le_librerie", text='Your User Libary', icon='EVENT_C')
                box.label(text='Last step, click on this button ↓ ↓ ↓', icon='EVENT_D')

                row = box.row()
                row.scale_y = 2
                row.operator("hdrimaker.installer", text='Install', icon='AUTO')
                if self.installation_time == True:
                    box.label(text='Check the installation progress under this button')

            if self.menu_installation == 'UPDATE':
                box = layout.box()
                box.label(text='Enter here the PATH where the expansion modules are located (HDMK_XPAND_N#.zip)')
                box.prop(self, "hdriLib_fromZip", text='Zip Path', icon='EVENT_A')
                row = box.row()
                row.scale_y = 2
                row.operator("hdrimaker.installer", text='Install', icon='AUTO')

            if self.menu_installation == 'FOLDERS':

                box = layout.box()
                box.label(text="Install management:")
                box.label(text='If you already have the main library HDRI_MAKER_LIB simply enter the path:',
                          icon='INFO')
                box.prop(self, "hdri_maker_library")
                box.label(
                    text='If you already have a library of previously created materials with HDRi Maker, enter your path here:',
                    icon='INFO')
                box.prop(self, "hdri_maker_user_library")

                resolve = None
                if len(self.hdri_maker_library) > 1:
                    if self.hdri_maker_library[-1] != os.sep:
                        resolve = True

                if len(self.hdri_maker_user_library) > 1:
                    if self.hdri_maker_user_library[-1] != os.sep:
                        resolve = True

                if self.hdri_maker_library[:2] == "//" or self.hdri_maker_user_library[:2] == "//":
                    resolve = True

                if resolve != None:
                    box = layout.box()
                    row = box.row()
                    row.scale_y = 4
                    row.label(text='Attention, the relative paths must be corrected, press fix button to correct:')

                    row.operator("hdrimaker.absolutepath", text='Fix', icon='MODIFIER')

        try:
            if self.installation_time:
                box = layout.box()
                box.label(text="Installation info:", icon='INFO')
                box.label(text='Attention, the installation is in progress, it will take a few minutes')
                box.label(text='depending on the speed of the hard disk and the processor in use')
                # if self.conteggioLibrerieZip>0:

                box.label(text="Remaining files to install:" + str(self.conteggioLibrerieZip) + ' Press ESC to abort')
                box.label(text=str(int(100 - (self.conteggioLibrerieZip / percentuale))) + " %")
                box.label(text='')
                box.label(text='Are you getting bored during installation?')
                box.label(text='If you want to subscribe to my youtube channel click here, and take a look at the news')
                box.operator('hdrimaker.info', text='Youtube', icon='RESTRICT_VIEW_ON').options = '3'
                box.label(text='When finished, press save preferences and restart Blender!')
                if 100 - (self.conteggioLibrerieZip / percentuale) == 100:
                    box.label(text="Finish !")
                    box.operator("hdrimaker.finishconfirm", text='OK', icon='FUND')

        except:

            self.installation_time = False


class HDRIMAKER_OT_ConvertToAbsolutePath(bpy.types.Operator):
    """Fix"""

    bl_idname = "hdrimaker.absolutepath"
    bl_label = "Fix"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__name__].preferences
        addon_prefs.hdri_maker_library = bpy.path.abspath(addon_prefs.hdri_maker_library)
        addon_prefs.hdri_maker_user_library = bpy.path.abspath(addon_prefs.hdri_maker_user_library)

        if len(addon_prefs.hdri_maker_library) > 1:
            if addon_prefs.hdri_maker_library[-1] != os.sep:
                addon_prefs.hdri_maker_library = addon_prefs.hdri_maker_library + os.sep

        if len(addon_prefs.hdri_maker_user_library) > 1:
            if addon_prefs.hdri_maker_user_library[-1] != os.sep:
                addon_prefs.hdri_maker_user_library = addon_prefs.hdri_maker_user_library + os.sep

        bpy.ops.wm.save_userpref()
        return {'FINISHED'}


class HDRIMAKER_OT_FinishConfirmation(bpy.types.Operator):
    """Finish"""

    bl_idname = "hdrimaker.finishconfirm"
    bl_label = "Finish"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__name__].preferences
        addon_prefs.installation_time = False
        return {'FINISHED'}


##################################
#####################Operator Modal Installer

class HDRIMAKER_OT_IntallerModal(bpy.types.Operator):
    """Installer"""

    bl_idname = "hdrimaker.installer"
    bl_label = "Modal Intaller Operator"
    bl_options = {'INTERNAL'}

    _timer = None

    def modal(self, context, event):

        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__name__].preferences
        from_zip_dir = bpy.path.abspath(addon_prefs.hdriLib_fromZip)

        if addon_prefs.menu_installation == 'FINSTALL':
            to_zip_dir = bpy.path.abspath(addon_prefs.hdriLib_unZip)  # + os.sep + addon_prefs.hdrimaker_library_name)

        if addon_prefs.menu_installation == 'UPDATE':
            to_zip_dir = bpy.path.abspath(addon_prefs.hdri_maker_library)

        if event.type == 'ESC':
            addon_prefs.installation_time = False
            context.area.tag_redraw()
            bpy.ops.wm.save_userpref()
            self.cancel(context)

            return {'CANCELLED'}

        if event.type == 'TIMER':

            context.area.tag_redraw()
            ###esegue finchè la lista degli zip si svuota
            if len(zipList) > 0:

                with zipfile.ZipFile(zipList[0][0], 'r') as zipObj:
                    zipObj.extract(zipList[0][1], to_zip_dir)

                zipList.pop(0)

                addon_prefs.conteggioLibrerieZip -= 1
            else:

                if addon_prefs.menu_installation == 'FINSTALL':
                    addon_prefs.hdri_maker_library = addon_prefs.hdriLib_unZip + addon_prefs.hdrimaker_library_name
                bpy.ops.wm.save_userpref()

                # addon_prefs.installation_time = False
                addon_prefs.hdriLib_fromZip = ''
                addon_prefs.hdriLib_unZip = ''
                addon_prefs.possiedo_le_librerie = ''

                self.cancel(context)
                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def execute(self, context):

        global zipList
        global percentuale

        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__name__].preferences

        addon_prefs.possiedo_le_librerie = bpy.path.abspath(addon_prefs.possiedo_le_librerie)
        addon_prefs.hdriLib_fromZip = bpy.path.abspath(addon_prefs.hdriLib_fromZip)
        addon_prefs.hdriLib_unZip = bpy.path.abspath(addon_prefs.hdriLib_unZip)

        if addon_prefs.menu_installation == 'FINSTALL':

            from_zip_dir = bpy.path.abspath(addon_prefs.hdriLib_fromZip)
            to_zip_dir = bpy.path.abspath(addon_prefs.hdriLib_unZip)

            addon_prefs.hdrimaker_library_name = 'HDRI_MAKER_LIB'

            if to_zip_dir == '':
                def draw(self, context):
                    if addon_prefs.menu_installation == 'FINSTALL':
                        self.layout.label(text="WARNING! Enter paths in the relevant B boxes, this path is null")
                    if addon_prefs.menu_installation == 'UPDATE':
                        self.layout.label(text="WARNING! Enter paths in the relevant boxes, this path is null")
                    self.layout.label(text="or it is directly on the main disk of the operating system")
                    self.layout.label(text="and this is not good practice. Choose a directory that is valid")

                context.window_manager.popup_menu(draw, title="Path Problem", icon='INFO')
                return {'CANCELLED'}

            if from_zip_dir == to_zip_dir:
                def draw(self, context):
                    if addon_prefs.menu_installation == 'FINSTALL':
                        self.layout.label(
                            text="WARNING! Attention, the path 'A' must be different from the path 'B', please try again")

                context.window_manager.popup_menu(draw, title="Path Problem", icon='INFO')
                return {'CANCELLED'}

        # se l'utente sta aggiornando alle espansioni:
        if addon_prefs.menu_installation == 'UPDATE':
            ###qua cambia la destinazione direttamente alle librerie se sono installate
            from_zip_dir = bpy.path.abspath(addon_prefs.hdriLib_fromZip)
            to_zip_dir = bpy.path.abspath(addon_prefs.hdri_maker_library)

        if from_zip_dir == '':
            def draw(self, context):
                self.layout.label(text="WARNING! Enter paths in the relevant A boxes, this path is null")

            context.window_manager.popup_menu(draw, title="Path problem", icon='INFO')
            return {'CANCELLED'}

        # doppio controllo , se esistono i percorsi nelle caselle input
        if os.path.isdir(to_zip_dir):
            if os.path.isdir(from_zip_dir):
                dirName = addon_prefs.hdriLib_unZip  # + os.sep + addon_prefs.hdrimaker_library_name
                userdirName = os.path.join(addon_prefs.hdriLib_unZip, 'HDRi Maker User_library')

                ###primo controllo per trovare Librerie o Espansioni:
                file_found = []
                for subdir, dirs, files in os.walk(from_zip_dir):
                    for item in files:
                        if not any(m in item for m in mac_bad_extension):
                            if zipfile.is_zipfile(os.path.join(subdir, item)):
                                if 'HDMK_XPAND_' in item or 'HDMK_LIB_VOL' in item:
                                    file_found.append((item))

                ##Occasione della prima installazione:
                if addon_prefs.menu_installation == 'FINSTALL':
                    controllo_dei_19 = []
                    for file in file_found:
                        if 'HDMK_LIB_VOL_' in file:
                            ##Qua evita i doppioni
                            if not any(file[:20] in s for s in controllo_dei_19):
                                controllo_dei_19.append(file)

                    ##Se risultano 0 moduli trovati interrompe
                    if len(controllo_dei_19) == 0:
                        def draw(self, context):
                            self.layout.label(text="Attention, no 'HDRI MAKER LIB' library has been found!")
                            self.layout.label(
                                text="make sure you have the libraries available in zip format and not to decompress them")

                        context.window_manager.popup_menu(draw, title="No library module found", icon='INFO')
                        return {'CANCELLED'}
                    ###Qua controlla se ci sono tutti e 10 i moduli , se non ci sono interrompe e lancia un messaggio
                    if len(controllo_dei_19) < 19:
                        def draw(self, context):
                            self.layout.label(
                                text="Attention, the library is not complete, to proceed correctly you must have all 19 modules in the main library")
                            self.layout.label(
                                text="Go to your download page and make sure you download all the modules with the name HDMK_LIB_VOL")

                        context.window_manager.popup_menu(draw, title="Some libraries are missing", icon='INFO')
                        return {'CANCELLED'}

                    ####Controlla se è il caso di lasciare questo blocco in questa posizione
                    # controllo se esiste già la cartella dei materiali , in caso contrario crea la cartella HDMK_LIB_VOL
                    if not os.path.exists(dirName):
                        os.mkdir(dirName)
                    # controllo se esiste la cartella user library , altrimenti la creo e la aggancio
                    if addon_prefs.possiedo_le_librerie == '' or not os.path.exists(addon_prefs.possiedo_le_librerie):
                        if not os.path.exists(userdirName):
                            os.mkdir(userdirName)
                        addon_prefs.hdri_maker_user_library = userdirName
                    else:
                        addon_prefs.hdri_maker_user_library = addon_prefs.possiedo_le_librerie

                if addon_prefs.menu_installation == 'UPDATE':
                    found_update = []
                    for file in file_found:
                        if 'HDMK_XPAND_' in file:
                            found_update.append(file)

                    if len(found_update) == 0:
                        def draw(self, context):
                            self.layout.label(text="Attention, no expansion module (HDMK_XPAND)")
                            self.layout.label(text="was found in this directory!")
                            self.layout.label(text="1 - Make sure you have downloaded the HDRI_EXPAND modules")
                            self.layout.label(text="2 - Make sure you haven't unzipped them")
                            self.layout.label(text="3 - Then enter the path where they are located and try again")

                        context.window_manager.popup_menu(draw, title="Expansion modules not found", icon='INFO')
                        return {'CANCELLED'}

                # os.chdir(from_zip_dir)
                zipList = []
                ###lista dei singoli file per archivio zip
                for subdir, dirs, files in os.walk(from_zip_dir):
                    for item in files:
                        if 'HDMK_LIB_VOL_' in item or 'HDMK_XPAND_' in item:
                            if item.endswith('.zip'):  # check for ".zip" extension """
                                if not any(m in item for m in mac_bad_extension):
                                    try:
                                        with zipfile.ZipFile(os.path.join(subdir, item), 'r') as zipObj:

                                            listOfFileNames = zipObj.namelist()
                                            # Iterate over the file names
                                            for fileName in listOfFileNames:
                                                if addon_prefs.menu_installation == 'FINSTALL':
                                                    ##nel caso in cui prima installazione installa tutti i moduli
                                                    zipList.append((os.path.join(subdir, item), fileName))
                                                if addon_prefs.menu_installation == 'UPDATE':
                                                    if 'HDMK_XPAND' in item:
                                                        ##Nel caso di aggiornamento installa solo i moduli di EXPAND
                                                        zipList.append((os.path.join(subdir, item), fileName))

                                    except zipfile.BadZipfile:

                                        def draw(self, context):
                                            self.layout.label(text="Attention, the file is corrupt, delete it,")
                                            self.layout.label(
                                                text="download it again (Maybe with a Chrome Browser or Firefox)")
                                            self.layout.label(text="Corrupted zip file name:  " + item)

                                        context.window_manager.popup_menu(draw, title="Bad zip file", icon='INFO')

                                        return {'CANCELLED'}

                addon_prefs.conteggioLibrerieZip = len(zipList)
                addon_prefs.installation_time = True
                addon_prefs.update_pack = False
                addon_prefs.folder_installation = False
                addon_prefs.first_installation = False

                percentuale = len(zipList)
                percentuale /= 100
                wm = context.window_manager
                self._timer = wm.event_timer_add(0.0001, window=context.window)
                wm.modal_handler_add(self)

                return {'RUNNING_MODAL'}

            else:
                def draw(self, context):
                    self.layout.label(text="Attention the directory where the zip files should be,")
                    self.layout.label(text="does not exist, check the path and enter the correct one!")

                context.window_manager.popup_menu(draw, title="ZIP source invalid (A Box)", icon='INFO')

                return {'CANCELLED'}

        else:
            if addon_prefs.menu_installation == 'UPDATE':
                def draw(self, context):
                    self.layout.label(text="Attention, before installing the expansions, you must ")
                    self.layout.label(text="set the path of the libraries in 'Library management'")
                    self.layout.label(
                        text="If you have never installed the HDRi Maker libraries before, use 'First install'")
                    self.layout.label(
                        text="from which it will also accept the 'Expansion Pack' directly in the first installation")

                context.window_manager.popup_menu(draw, title="No path in 'Library management'", icon='INFO')


            else:
                def draw(self, context):
                    self.layout.label(text="Attention the directory where the zip files should be,")
                    self.layout.label(text="does not exist, check the path and enter the correct one!")

                context.window_manager.popup_menu(draw, title="Destination folder invalid (B Box)", icon='INFO')

            return {'CANCELLED'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        preferences = bpy.context.preferences
        addon_prefs = preferences.addons[__name__].preferences
        addon_prefs.installation_time = False
        bpy.ops.hdrimaker.absolutepath()
        bpy.ops.wm.save_userpref()


class HDRIMAKER_OT_WebInfo(bpy.types.Operator):
    """Info"""

    bl_idname = "hdrimaker.info"
    bl_label = "Info"
    bl_options = {'INTERNAL'}

    options: EnumProperty(items=(('1', "1", ""), ('2', "2", ""), ('3', "3", "")))

    def execute(self, context):
        GlobalPathHdri(self, context)

        if self.options == '1':
            webbrowser.open('https://blendermarket.com/products/hdri-maker')

        if self.options == '2':
            webbrowser.open_new(r'file://' + os.sep + GlobalPathHdri.tools_lib + os.sep + 'Manual.pdf')

        if self.options == '3':
            webbrowser.open('https://www.youtube.com/channel/UCe5vB8ehr9hrQrYvfCb8j9w?')

        return {'FINISHED'}


#######################

class OBJECT_OT_hdri_maker_directory(Operator):
    """Directory HDRi"""
    bl_idname = "object.hdri_maker_library"
    bl_label = "HDRi Maker Directory"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        preferences = context.preferences
        addon_prefs = preferences.addons[__name__].preferences

        info = ("Path: %s" %
                (addon_prefs.hdri_maker_library))

        self.report({'INFO'}, info)

        return {'FINISHED'}


def GlobalPathHdri(self, context):
    preferences = bpy.context.preferences
    addon_prefs = preferences.addons[__name__].preferences
    GlobalPathHdri.HdriLib = bpy.path.abspath(addon_prefs.hdri_maker_library)
    GlobalPathHdri.HdriUser = bpy.path.abspath(addon_prefs.hdri_maker_user_library)

    ########
    # GlobalPathHdri.HdriLib = os.path.join('J:\\3D Studio 2018\\Hdri Maker\\HDRi_Lib_4k')
    ###Libreria interna
    # GlobalPathHdri.tools_lib = os.path.join(bpy.path.abspath("//"),"HDRi_tools_lib")
    GlobalPathHdri.tools_lib = os.path.join(os.path.dirname(__file__), "HDRi_tools_lib")


def iconsSwitch(self, context):
    scn = context.scene
    csp = scn.hdri_prop_scn

    path = os.path.join(GlobalPathHdri.tools_lib, 'Icons', csp.menu_icon_theme)

    for iconcollhdr in preview_icon_blu.values():
        bpy.utils.previews.remove(iconcollhdr)
    preview_icon_blu.clear()

    iconcollhdr = bpy.utils.previews.new()
    preview_icon_blu["icone"] = iconcollhdr
    hdriMkr_icon_dir = os.path.join(path)
    for ic in os.listdir(hdriMkr_icon_dir):
        iconcollhdr.load(ic, os.path.join(hdriMkr_icon_dir, ic), 'IMAGE')


############################################################################################################
###############================Upcategory==============#####################################################
def funzione_preview_categorie(self, context):
    scn = context.scene
    csp = scn.hdri_prop_scn

    GlobalPathHdri(self, context)

    hdriLibrary = os.path.join(GlobalPathHdri.HdriLib, "preview_hdri")
    hdriUser = os.path.join(GlobalPathHdri.HdriUser)

    updirectory = hdriLibrary if csp.def_to_user_lib == 'DEFAULT' else hdriUser
    ###########

    try:
        dirListing = os.listdir(updirectory)
        dirListing.sort()
        cat_name = []
        for item in dirListing:
            if not any(m in item for m in mac_bad_extension):
                cat_name.append(item)
        if len(cat_name) == 0:
            cat_name = ['Empty Collection...']
    except:

        cat_name = ['Empty Collection...']

    funzione_preview_categorie.indice = cat_name

    return [(name, name, "") for name in cat_name]


def saveCatView(self, context):
    scn = context.scene
    csp = scn.hdri_prop_scn

    GlobalPathHdri(self, context)
    updirectory = os.path.join(GlobalPathHdri.HdriUser)
    ###########

    try:
        dirListing = os.listdir(updirectory)
        dirListing.sort()
        cat_name = []
        for item in dirListing:
            if not any(m in item for m in mac_bad_extension):
                cat_name.append(item)

        if not cat_name:
            cat_name = ['Empty Collection...']
    except:

        cat_name = ['Empty Collection...']

    saveCatView.list = cat_name

    return [(name, name, "") for name in cat_name]


def update_first_cat(self, context):
    funzione_preview_categorie(self, context)
    set = bpy.context.scene.hdri_prop_scn
    set.up_category = funzione_preview_categorie.indice[0]


def update_first_catView(self, context):
    saveCatView(self, context)
    set = bpy.context.scene.hdri_prop_scn
    set.personal_category = saveCatView.list[0]


###########################################################################################
###===================================Downcat================================######

def funzione_preview_icone_hdri(self, context):
    """EnumProperty"""
    enumera_items = []
    set = bpy.context.scene.hdri_prop_scn

    hdri_folder = set.up_category

    if context is None:
        return enumera_items

    wm = context.window_manager

    hdriLibrary = os.path.join(GlobalPathHdri.HdriLib, "preview_hdri", hdri_folder)
    hdriUser = os.path.join(GlobalPathHdri.HdriUser, hdri_folder)

    if set.up_category != 'Empty Collection...':
        category = hdriLibrary if set.def_to_user_lib == 'DEFAULT' else hdriUser
    else:
        category = os.path.join(GlobalPathHdri.tools_lib, 'Empty_path')

    # Get the preview collection (defined in register func).
    CollezioneHDRi = hdri_preview_collection["HDRiCol"]

    if category == CollezioneHDRi.hdri_category_dir:
        return CollezioneHDRi.hdri_category

    if category and os.path.exists(category):
        # Scan the directory for png files
        percorso_immagini = []
        for fn in os.listdir(category):
            if fn.lower().endswith(".png"):
                if not any(m in fn for m in mac_bad_extension):
                    percorso_immagini.append(fn)

        if len(percorso_immagini) == 0:
            category = os.path.join(GlobalPathHdri.tools_lib, 'Empty_path')
            for fn in os.listdir(category):
                percorso_immagini.append(fn)

        for i, name in enumerate(percorso_immagini):
            # generates a thumbnail preview for a file.
            filepath = os.path.join(category, name)
            icon = CollezioneHDRi.get(name)  #
            if not icon:

                thumb = CollezioneHDRi.load(name, filepath, 'IMAGE')

            else:
                thumb = CollezioneHDRi[name]

            enumera_items.append((name[:-4], name[:-4], "", thumb.icon_id, i))

        funzione_preview_icone_hdri.indice = percorso_immagini

    CollezioneHDRi.hdri_category = enumera_items
    CollezioneHDRi.hdri_category_dir = category

    return CollezioneHDRi.hdri_category


def update_first_icon(self, context):
    funzione_preview_icone_hdri(self, context)
    bpy.data.window_managers["WinMan"].hdri_category = funzione_preview_icone_hdri.indice[0].replace(".png", "")


def enum_k_size(self, context):
    scn = context.scene
    scnProp = scn.hdri_prop_scn
    preview = bpy.data.window_managers["WinMan"].hdri_category

    kSizePreview = k_size_refer["Refer"]

    if kSizePreview.k_size_from_prev == preview:
        return kSizePreview.k_size_list

    kSizeDim = []
    for subdir, dirs, files in os.walk(GlobalPathHdri.HdriLib):
        for f in files:
            if not any(m in f for m in mac_bad_extension):
                if f.endswith('.hdr') or f.endswith('.exr'):
                    if f[:-8] == preview:
                        if f[-7:][:-4] not in kSizeDim:
                            if f[-7] == '0':
                                kSizeDim.append((f[-7:][:-4] + '_Library', f[-6:][:-4], ""))
                            else:
                                kSizeDim.append((f[-7:][:-4] + '_Library', f[-7:][:-4], ""))

    kSizeDim.sort()

    kSizePreview.k_size_list = kSizeDim
    kSizePreview.k_size_from_prev = preview

    return kSizePreview.k_size_list


def updatebackground(self, context):
    scn = bpy.context.scene
    set = scn.hdri_prop_scn

    if scn.world:

        # if 'HDRi Maker' in scn.world.hdri_prop_world.world_id_base_name:

        for n in scn.world.node_tree.nodes:

            if n.name == 'World Rotation':
                n.inputs[2].default_value[0] = radians(set.rot_world_x)
                n.inputs[2].default_value[1] = radians(set.rot_world_y)
                n.inputs[2].default_value[2] = radians(set.rot_world)
                n.inputs[1].default_value[2] = -set.menu_bottom

            if n.name == 'Background light':
                n.inputs[1].default_value = set.emission_force

            if n.name == 'Hdri hue_sat':
                n.inputs[1].default_value = set.hue_saturation

            if n.name == 'HDRI_COLORIZE':
                n.outputs[0].default_value = set.colorize

            if n.name == 'HDRI_COLORIZE_MIX':
                n.inputs[0].default_value = set.colorize_mix

            if n.name == 'BLURRY_Value':
                n.outputs[0].default_value = set.blurry_value / 2

                if scn.hdri_prop_scn.show_dome:
                    n.outputs[0].default_value = 0

            if n.name == 'HDRI_Maker_Exposure':
                n.inputs[1].default_value = set.exposure_hdri

        for o in context.scene.objects:

            if o.type == 'LIGHT':
                if o.data.type == 'SUN':
                    if o.hdri_prop_obj.object_id_name == 'HDRI_MAKER_SUN':
                        o.rotation_euler.z = radians((-set.sunRot_z) - set.rot_world)
                        o.rotation_euler.x = radians(set.sunRot_x)
                        o.data.energy = set.sun_light
                        o.data.color = set.sun_color

            if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':

                o.hide_render = False if scn.hdri_prop_scn.show_dome else True
                o.hide_viewport = False if scn.hdri_prop_scn.show_dome else True
                o.hide_set(state=False if scn.hdri_prop_scn.show_dome else True)

                siz = scn.hdri_prop_scn.dome_size

                try:
                    for a in bpy.context.screen.areas:
                        if a.type == 'VIEW_3D':
                            for s in a.spaces:
                                if s.type == 'VIEW_3D':
                                    if s.clip_end < siz:
                                        s.clip_end = siz + 10
                except:
                    pass
                ##Conversione della dimensione della cupola basato sul sistema metrico e sulla unità della scala del progetto

                siz = (siz / 50) / scn.unit_settings.scale_length if scn.unit_settings.system == 'METRIC' else ((
                                                                                                                            siz / 3.28084) / 50) / scn.unit_settings.scale_length
                o.scale = (siz, siz, siz)

                for mod in o.modifiers:
                    if mod.name == 'HDRI_SMOOTH':
                        mod.iterations = set.wrap_smooth

            # distanza nebbia in eevee se il box supera la soglia:
            def fog_view_end(value):
                if value > scn.eevee.volumetric_end:
                    scn.eevee.volumetric_end = value

            if o.hdri_prop_obj.object_id_name == 'hdri_fog_box':
                if set.show_dome:
                    siz = scn.hdri_prop_scn.dome_size
                    siz += 20
                    o.dimensions = (siz, siz, siz / 2.08298755186722)
                    fog_view_end(siz)
                else:
                    siz = set.fog_box_size
                    siz = (siz / 50) / scn.unit_settings.scale_length if scn.unit_settings.system == 'METRIC' else ((
                                                                                                                                siz / 3.28084) / 50) / scn.unit_settings.scale_length

                    o.scale = (siz, siz, siz)
                    fog_view_end(o.dimensions[0])

        for m in bpy.data.materials:
            if m.hdri_prop_mat.mat_id_name == 'HDRi_Maker_Sky_Dome' or m.hdri_prop_mat.mat_id_name == 'Hdri_On_Ground':
                for n in m.node_tree.nodes:
                    if n.name == 'World Rotation':
                        n.inputs[1].default_value[0] = scn.hdri_prop_scn.domeMap_x
                        n.inputs[1].default_value[1] = scn.hdri_prop_scn.domeMap_y
                        n.inputs[1].default_value[2] = scn.hdri_prop_scn.domeMap_z

                        n.inputs[2].default_value[0] = radians(-set.rot_world_x)
                        n.inputs[2].default_value[1] = radians(-set.rot_world_y)
                        n.inputs[2].default_value[2] = radians(-set.rot_world)

                    if n.name == 'Emi_Map':
                        n.inputs[1].default_value = scn.hdri_prop_scn.dome_top_light

                    if n.name == 'Background light':
                        n.inputs[1].default_value = set.emission_force

                    if n.name == 'Hdri hue_sat':
                        n.inputs[1].default_value = set.hue_saturation

                    if n.name == 'HDRI_COLORIZE':
                        n.outputs[0].default_value = set.colorize

                    if n.name == 'HDRI_COLORIZE_MIX':
                        n.inputs[0].default_value = set.colorize_mix

                    if n.name == 'BLURRY_Value':
                        n.outputs[0].default_value = set.blurry_value / 2

                    if n.name == 'HDRI_Maker_Exposure':
                        n.inputs[1].default_value = set.exposure_hdri

            if m.hdri_prop_mat.mat_id_name == 'HDRI_MAKER_FOG':
                for n in m.node_tree.nodes:
                    if n.name == 'fog_level':
                        n.inputs[1].default_value[0] = 0
                        n.inputs[1].default_value[1] = 0
                        n.inputs[1].default_value[2] = 1 - set.fog_level if set.fog_flip else set.fog_level

                        n.inputs[2].default_value[0] = 0
                        n.inputs[2].default_value[1] = radians(-90) if set.fog_flip else radians(90)
                        n.inputs[2].default_value[2] = 0

                    if n.name == 'fog':
                        n.inputs[2].default_value = set.fog_density
                        n.inputs[6].default_value = set.fog_emission

                    if n.name == 'fog_mapping':
                        n.inputs[2].default_value[2] = radians(set.fog_direction)

                    if n.name == 'fog_ramp':
                        n.color_ramp.elements[0].color = (0, 0, 0, 1)
                        n.color_ramp.elements[1].color = (1, 1, 1, 1)

                        n.color_ramp.elements[0].position = set.fog_patches * 0.25
                        n.color_ramp.elements[1].position = 1 - (set.fog_patches * 0.60)

                    if n.name == 'fog_noise':
                        n.inputs[2].default_value = 1 + (set.fog_patches_size * 10)


def delete_world(self, context):
    scn = context.scene

    if scn.world:
        bpy.data.worlds.remove(scn.world)
    purgeOldImage()


def hide_Wrap_objects(self, context):
    o = self.id_data
    o.display.show_shadows = False if o.hdri_prop_obj.hide_wrap else True
    o.display_type = 'BOUNDS' if o.hdri_prop_obj.hide_wrap else 'TEXTURED'
    o.hide_render = True if o.hdri_prop_obj.hide_wrap else False
    if hasattr(o, 'cycles_visibility'):
        # Per versioni precedenti alla 3.0
        o.cycles_visibility.camera = False if o.hdri_prop_obj.hide_wrap else True
        o.cycles_visibility.diffuse = False if o.hdri_prop_obj.hide_wrap else True
        o.cycles_visibility.glossy = False if o.hdri_prop_obj.hide_wrap else True
        o.cycles_visibility.transmission = False if o.hdri_prop_obj.hide_wrap else True
        o.cycles_visibility.scatter = False if o.hdri_prop_obj.hide_wrap else True
        o.cycles_visibility.shadow = False if o.hdri_prop_obj.hide_wrap else True
    else:
        # Per versioni dalla 3.0 in su
        o.visible_camera = False if o.hdri_prop_obj.hide_wrap else True
        o.visible_diffuse = False if o.hdri_prop_obj.hide_wrap else True
        o.visible_glossy = False if o.hdri_prop_obj.hide_wrap else True
        o.visible_transmission = False if o.hdri_prop_obj.hide_wrap else True
        o.visible_scatter = False if o.hdri_prop_obj.hide_wrap else True
        o.visible_shadow = False if o.hdri_prop_obj.hide_wrap else True

class DELETE_OT_BackgroundHdri(bpy.types.Operator):
    """Delete all ground hdri active"""
    bl_idname = "delhdri.background"
    bl_label = "deletehdri"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        delete_world(self, context)
        delete_dome(self, context)
        return {'FINISHED'}


def appendWorld(self, context, scnProp, cat, preview, type):
    scn = context.scene

    path = os.path.join(GlobalPathHdri.HdriUser, cat, preview + '.blend')

    with bpy.data.libraries.load(path, link=False) as (data_from, data_to):
        data_to.worlds = [w for w in data_from.worlds]

    for wrld in data_to.worlds:
        context.scene.world = wrld.copy()
        context.scene.world.hdri_prop_world.world_user = True
        context.scene.world.hdri_prop_world.world_hdri_maker = True

    if context.scene.world:

        scn.world.hdri_prop_world.world_id_name = preview

        for n in context.scene.world.node_tree.nodes:
            if n.type == 'MAPPING':
                if n.name == 'World Rotation':
                    scnProp.rot_world_x = n.inputs[2].default_value[0]
                    scnProp.rot_world_y = n.inputs[2].default_value[1]
                    scnProp.rot_world = n.inputs[2].default_value[2]
                    scnProp.menu_bottom = n.inputs[1].default_value[2]
            if n.type == 'BACKGROUND':
                if n.name == 'Background light':
                    if type == 'REDRAW':
                        n.inputs[1].default_value = sceneSwitch.light
                    else:
                        scnProp.emission_force = n.inputs[1].default_value

            if n.type == 'HUE_SAT':
                if n.name == 'Hdri hue_sat':
                    if type == 'REDRAW':
                        n.inputs[1].default_value = sceneSwitch.satur
                    else:
                        scnProp.hue_saturation = n.inputs[1].default_value

            if n.type == 'TEX_ENVIRONMENT':
                if n.image:
                    n.image.hdri_prop_image.image_tag = True
    purgeOldImage()


def purge_duplicate(scn):
    def nodeTree(alberoDiNodi):

        exposure = None
        nodeGroupToDelete = []
        for ng in bpy.data.node_groups:
            if ng.name == 'HDRI_Maker_Exposure':
                exposure = ng
            if 'HDRI_Maker_Exposure' in ng.name:
                nodeGroupToDelete.append(ng)

        for n in alberoDiNodi:
            if exposure:
                if n.name == 'HDRI_Maker_Exposure':
                    if n.node_tree:
                        if n.node_tree.name[-4] == '.' and n.node_tree.name[-3:].isnumeric():
                            n.node_tree = exposure

        for ng in nodeGroupToDelete:
            if not ng.users:
                bpy.data.node_groups.remove(ng)

    for m in bpy.data.materials:
        if m.node_tree:
            nodeTree(m.node_tree.nodes)

    if scn.world:
        if scn.world.use_nodes:
            nodeTree(scn.world.node_tree.nodes)

        if len(scn.world.name) > 4:
            if scn.world.name[-4] == '.':
                if scn.world.name[-3:].isnumeric():
                    scn.world.name = scn.world.name[:-4]


def subOperatorSky(self, context, realContext, type_save, immagine, nomePreview):
    if nomePreview == 'None':
        text = bpy.data.window_managers["WinMan"].hdri_category
    else:
        text = nomePreview

    hue_saturation = realContext.hdri_prop_scn.hue_saturation
    scn = realContext
    set = scn.hdri_prop_scn

    """if type_save != 'PANORAMA':
        delete_world(self,context)"""

    emission_force = scn.hdri_prop_scn.emission_force

    hdri_folder = bpy.data.window_managers["WinMan"].hdri_category

    # Modifica della enum per la ricerca delle cartelle tramite chiave espressa in "k"

    # kSizeNameRecomp=text+"_"+set.k_size_available[:-8]+".hdr"
    # image_path = os.path.join(GlobalPathHdri.HdriLib + os.sep + set.k_size_available + os.sep + kSizeNameRecomp)

    mat_dir = bpy.data.window_managers["WinMan"].hdri_category
    trovata_immagine = []
    # if scn.world is None:

    # create a new world
    percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'Background Node v2.blend')

    with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
        data_to.worlds = [w for w in data_from.worlds]

    ### Test Import append:
    for wrld in data_to.worlds:
        world = wrld.copy()

    new_world = world
    scn.world = new_world
    new_world.use_nodes = True
    new_world.hdri_prop_world.world_user = True
    new_world.hdri_prop_world.world_hdri_maker = True

    ###############

    enviroment = new_world.node_tree.nodes.get('HDRi Maker Background')

    ###Attenzione:
    new_world.hdri_prop_world.world_id_base_name = 'HDRi Maker'

    if type_save == 'PANORAMA':
        enviroment.image = bpy.data.images.load(panoramaScene.filepath + '.hdr')
        enviroment.image.name = panoramaScene.filepath + '.hdr'


    elif type_save == 'BATCH':

        enviroment.image = bpy.data.images.load(searchHdr.list[0])
        new_world.hdri_prop_world.world_id_name = enviroment.image.name[:-4]

    elif type_save == 'IMPORT':
        enviroment.image = immagine
        new_world.hdri_prop_world.world_id_name = enviroment.image.name[:-4]

    else:

        kSizeNameRecomp = text + "_" + set.k_size_available[:-8] + ".hdr"
        image_path = os.path.join(GlobalPathHdri.HdriLib, set.k_size_available, kSizeNameRecomp)
        new_world.hdri_prop_world.world_id_name = text.replace(kSizeNameRecomp, "")

        ##Cerca se l'immagine è già presente in data , e se è linkata a un file vero
        ##Altrimenti la carica:
        findoldImage = None
        for i in bpy.data.images:
            if i.name == kSizeNameRecomp:
                if os.path.isfile(i.filepath_raw):
                    findoldImage = i

        enviroment.image = findoldImage if findoldImage else bpy.data.images.load(image_path)

    enviroment.image.hdri_prop_image.image_tag = True
    trovata_immagine.append(enviroment.image)

    purgeOldImage()


def load_dome(self, context):
    envImage = None
    for n in context.scene.world.node_tree.nodes:
        if n.name == 'HDRi Maker Background':
            envImage = n.image

    dome = None

    for o in context.scene.objects:
        if o.name == 'HDRi_Maker_Dome':
            if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
                dome = o

    if dome is None:

        for o in bpy.data.objects:
            if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
                if o.name == 'HDRi_Maker_Dome':
                    dome = o
                    context.scene.collection.objects.link(dome)

    if envImage is not None:
        if dome is None:

            percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'hdri_dome.blend')

            with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
                data_to.objects = [o for o in data_from.objects]

            for o in data_to.objects:
                if o.name == 'HDRi_Maker_Dome':
                    o.hdri_prop_obj.object_id_name = 'HDRi_Maker_Dome'
                    dome = o.copy()
                    bpy.data.objects.remove(o)
                    context.scene.collection.objects.link(dome)
                    dome.name = 'HDRi_Maker_Dome'
                    dome.location = (0, 0, 0)
                    dome.hide_select = True
                    dome.lock_location[:] = (True, True, True)

        mat = dome.material_slots[0].material
        mat.name = 'HDRi_Maker_Sky_Dome'
        mat.hdri_prop_mat.mat_id_name = 'HDRi_Maker_Sky_Dome'
        mat.diffuse_color = (1, 1, 1, 0)

        for n in dome.material_slots[0].material.node_tree.nodes:
            if n.name == 'HDRI_ENV':
                n.image = envImage
            if n.name == 'Texture Coordinate':
                n.object = dome

        for m in bpy.data.materials:
            if m.hdri_prop_mat.mat_id_name == 'Hdri_On_Ground':
                for n in m.node_tree.nodes:
                    if n.name == 'HDRI_ENV':
                        n.image = envImage
                    if n.name == 'Texture Coordinate':
                        n.object = dome

                # un po pasticciato , ma recupera il ground material se presente in bpy.data e lo sostituisce per
                # non avere dupplicati .001 etc
                if m.name == 'Hdri_On_Ground':
                    for s in dome.material_slots:
                        if 'Hdri_On_Ground' in s.material.name:
                            s.material = m


def delete_dome(self, context):
    deleteList = []
    for o in context.scene.objects:
        if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
            deleteList.append(o)
        if o.hdri_prop_obj.object_id_name == 'HDRi_CenterPoint':
            deleteList.append(o)
        if o.hdri_prop_obj.object_id_name == 'hdri_fog_box':
            deleteList.append(o)

    for o in deleteList:
        bpy.data.objects.remove(o)


class HDRI_OT_OperatorSky(bpy.types.Operator):
    """Create new world from current preview"""

    bl_idname = "hdrimaker.add"
    bl_label = "Add hdri"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        scn = context.scene
        scnProp = scn.hdri_prop_scn
        cat = scnProp.up_category
        preview = bpy.data.window_managers["WinMan"].hdri_category

        if scnProp.up_category == 'Empty Collection...':
            return {'FINISHED'}
        if preview == '' or preview == 'Empty':
            return {'FINISHED'}

        if scnProp.def_to_user_lib == 'DEFAULT':
            # Questo perchè durante il panorama save bisogna passare un copy context:
            # In questo caso il context è il semplice contesto corrente
            subOperatorSky(self, context, context.scene, 'NONE', 'No Image', preview)
            load_dome(self, context)
            load_fog(self, context)
            wrap_the_objects(context, [o for o in scn.objects if o.hdri_prop_obj.object_id_name == 'Wrap'])

        else:

            appendWorld(self, context, scnProp, cat, preview, type)
            load_new_world_nodes(scn)  # carica i nuovi nodi nel caso si utilizzi un vecchio nodo salvato
            load_dome(self, context)
            load_fog(self, context)
            wrap_the_objects(context, [o for o in scn.objects if o.hdri_prop_obj.object_id_name == 'Wrap'])

        purge_duplicate(scn)
        updatebackground(self, context)

        return {'FINISHED'}


class HDRI_OT_CREDIT(bpy.types.Operator):
    """All hdri  is based on this site"""

    bl_idname = "credithdri.web"
    bl_label = "crediti"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        iconsSwitch(self, context)
        # webbrowser.open('https://hdrihaven.com/')

        return {'FINISHED'}


def indicone(self, context):
    funzione_preview_icone_hdri(self, context)
    current = bpy.data.window_managers["WinMan"].hdri_category
    indicone.immagini = funzione_preview_icone_hdri.indice

    for i in indicone.immagini:
        if current + '.png' == i:
            indicone.get = indicone.immagini.index(i)


def cat(self, context):
    ###indice categorie
    csp = context.scene.hdri_prop_scn
    try:
        current = csp.up_category

        for i in funzione_preview_categorie.indice:
            if current == i:
                cat.current_index = funzione_preview_categorie.indice.index(i)
    except:
        update_first_cat(self, context)
        update_first_icon(self, context)


#############################################################################
class HDRI_PT_Panel(bpy.types.Panel):
    bl_label = "HDRi Maker 2.0"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hdri Maker"

    def draw(self, context):

        layout = self.layout

        pollClose = False
        for s in bpy.data.scenes:
            if s.hdri_prop_scn.scene_id_name == 'batch_scene':
                pollClose = True

        pollLightProbe = False
        for o in context.scene.objects:
            objIdName = o.hdri_prop_obj.object_id_name
            if objIdName in ('LIGHT_PROBE_PLANE', 'CYCLES_SHADOW_CATCHER'):
                if not o.parent:
                    pollLightProbe = True

        if pollClose:

            col = layout.column(align=True)
            col.label(text="A 'Batch scene' has been created")
            col.label(text="to save the previous background")
            col.label(text="for security reasons, remove it")
            col.label(text="manually by pressing this button:")
            row = layout.row(align=True)
            row.scale_y = 2
            row.operator("hdrimaker.saveop", text='Delete batch scene')

        elif pollLightProbe:
            col = layout.column(align=True)
            col.label(text="The ShadowCatcher plane has been canceled.")
            col.label(text="A 'Lightprobe' is orphaned, press the button")
            col.label(text="in order to correct.")
            row = layout.row(align=True)
            row.scale_y = 2
            row.operator("hdrimaker.lightproberemove", text='Fix')


        else:

            try:
                bpy.data.window_managers["WinMan"].hdri_category
                ready = True

            except:
                ready = False

            scn = context.scene
            csp = scn.hdri_prop_scn
            wm = context.window_manager

            if ready is False:
                row = layout.row(align=True)
                row.label(text='Please install or link the libraries!')
                row = layout.row(align=True)
                row.scale_y = 2
                row.operator("hdrimaker.info", text='Read the Manual').options = '2'

                col = layout.column(align=True)
                col.label(text='If you have linked or installed the libraries')
                col.label(text='Save the preferences and restart Blender')

            if ready:

                hdr_name = bpy.data.window_managers["WinMan"].hdri_category
                icone = preview_icon_blu["icone"]
                indicone(self, context)
                totic = len(funzione_preview_icone_hdri.indice)
                ob = bpy.context.active_object
                cat(self, context)

                ######################

                ###Librerie
                row = layout.row(align=True)
                row.label(text='Library:')
                row.prop(scn.hdri_prop_scn, "def_to_user_lib", text='Libraries', expand=True)
                ###Category
                row = layout.row(align=True)
                row.scale_x = 0.7
                row.prop(scn.hdri_prop_scn, "up_category", text='Category')
                row.scale_x = 0.3
                row.label(text=str(cat.current_index + 1) + "/" + str(len(funzione_preview_categorie.indice)),
                          icon_value=icone['info green.png'].icon_id)

                row = layout.row()

                row.scale_x = 3
                row.operator("hdri.previuscategory", text='', icon_value=icone['top.png'].icon_id)

                row = layout.row()
                row.scale_y = 4 + csp.menu_icon_size * 2
                row.scale_x = 1.05
                row.operator("hdri.previusicon", text='', icon_value=icone['previus.png'].icon_id)

                sub = row.row()
                sub.scale_y = 0.17
                sub.template_icon_view(wm, "hdri_category", show_labels=True if csp.menu_label else False,
                                       scale_popup=csp.menu_icon_popup + 3)

                row.operator("hdri.nexticon", text='', icon_value=icone['next.png'].icon_id)

                row = layout.row()

                row.scale_x = 3
                row.operator("hdri.nextcategory", text='', icon_value=icone['down.png'].icon_id)

                # row.scale_x = 1
                # row.prop(csp,'auto_add',text='',icon_value = icone['picture.png'].icon_id)

                box1 = layout.box()
                row1 = box1.row()

                row1.operator("hdri.search_popup", text=hdr_name, emboss=False, icon_value=icone['find.png'].icon_id)

                ###Stella
                row1.scale_x = 2.2

                row1.scale_x = 0.4
                row1.label(text=str(indicone.get + 1) + "/" + str(totic), icon_value=icone['info green.png'].icon_id)
                row1.scale_x = 1
                row1.operator("hdrimaker.current", text='', emboss=True, icon_value=icone['star.png'].icon_id)

                row = layout.row(align=True)
                row.scale_y = 2

                row.operator("hdrimaker.add", text='Add', icon_value=icone['Aggiungi.png'].icon_id)
                row.operator("hdrimaker.importhdr", text='Import', icon_value=icone['import.png'].icon_id)
                if scn.world:
                    row.operator("delhdri.background", text='Remove', icon_value=icone['Remove.png'].icon_id)

                if csp.def_to_user_lib == 'DEFAULT':

                    try:
                        row = layout.row(align=True)
                        row.prop(csp, "k_size_available", text='Size', expand=True)

                    except:
                        pass

                if csp.def_to_user_lib == 'USER':
                    row = layout.row()
                    row.prop(csp, 'redraw_menu', text='Redraw preview',
                             icon_value=icone['Menu open.png'].icon_id if csp.redraw_menu else icone[
                                 'Menu close.png'].icon_id)
                    if csp.redraw_menu:
                        box = layout.box()
                        split = box.split(factor=0.05, align=True)

                        col = split.column(align=True)
                        col.label(text='', icon_value=icone['Sun.png'].icon_id)
                        col.label(text='', icon_value=icone['Color.png'].icon_id)

                        col = split.column(align=True)
                        col.prop(csp, 'light_redraw', text='Light Redraw')
                        col.prop(csp, 'saturation_redraw', text='Saturation Redraw')

                        split = box.split(factor=0.05, align=True)

                        col = split.column(align=True)
                        col.label(text='', icon_value=icone['x.png'].icon_id)
                        col.label(text='', icon_value=icone['y.png'].icon_id)
                        col.label(text='', icon_value=icone['z.png'].icon_id)

                        col = split.column(align=True)
                        col.prop(csp, 'camera_redraw_tilt', text='Camera Tilt Redraw')
                        col.prop(csp, 'camera_redraw_up_down', text='Camera Up/Down Redraw')
                        col.prop(csp, 'camera_redraw_rotation', text='Camera Turn Redraw')
                        col = box.row(align=True)
                        col.scale_y = 2
                        col.operator('hdrimaker.redraw', text='Redraw Preview', icon_value=icone['camera.png'].icon_id)

                layout.prop(csp, 'menu_enviroment', text='Background controls',
                            icon_value=icone['Menu open.png'].icon_id if csp.menu_enviroment else icone[
                                'Menu close.png'].icon_id)

                if csp.menu_enviroment:

                    box = layout.box()
                    row = box.row(align=False)

                    row.operator("hdrimaker.addsun", text='Add-Synch sun', icon_value=icone['Sun.png'].icon_id)
                    row = box.row(align=False)
                    row.prop(scn.render, 'film_transparent', text='Transp Background')
                    row.prop(scn.hdri_prop_scn, 'show_dome', text='Hdri Projected')

                    icon_size = 0.1
                    slider_size = 0.5

                    col = box.column(align=True)

                    row = col.split(factor=icon_size)
                    row.label(text='', icon_value=icone['Sun.png'].icon_id)
                    row = row.split(align=True)
                    row.prop(scn.hdri_prop_scn, 'sun_light', text='Force', slider=True)

                    row = col.split(factor=icon_size)
                    row.label(text='', icon_value=icone['sunrot.png'].icon_id)
                    row = row.split(factor=slider_size, align=True)

                    row.prop(scn.hdri_prop_scn, 'sunRot_x', text='Inclination', slider=True)
                    row.prop(scn.hdri_prop_scn, 'sunRot_z', text='Rotation')

                    col = box.column(align=True)

                    row = col.split(factor=icon_size)
                    row.label(text='', icon_value=icone['sun white.png'].icon_id)
                    row = row.split(align=True)
                    row.prop(scn.hdri_prop_scn, 'emission_force', text='Hdri light', slider=True)
                    row.prop(scn.hdri_prop_scn, 'exposure_hdri', text='Exposure')

                    row = col.split(factor=icon_size)
                    row.prop(scn.hdri_prop_scn, 'colorize', text='')
                    row = row.split(factor=slider_size, align=True)
                    row.prop(scn.hdri_prop_scn, 'colorize_mix', text='Colorize mix', slider=True)
                    row.prop(scn.hdri_prop_scn, 'hue_saturation', text='Saturation')

                    row = col.split(factor=icon_size)
                    row.label(text='', icon_value=icone['xyz.png'].icon_id)
                    row = row.split(factor=0.33, align=True)
                    row.prop(scn.hdri_prop_scn, 'rot_world_x', text='X')
                    row.prop(scn.hdri_prop_scn, 'rot_world_y', text='Y')
                    row.prop(scn.hdri_prop_scn, 'rot_world', text='Z')

                    if scn.hdri_prop_scn.show_dome is False:
                        row = col.split(factor=icon_size)
                        row.label(text='', icon_value=icone['topdown.png'].icon_id)
                        row = row.split(align=True)
                        row.prop(scn.hdri_prop_scn, 'menu_bottom', text='Move bottom')
                        row.prop(scn.hdri_prop_scn, 'blurry_value', text='Blur', slider=True)

                    """
                    #col.label(text = '',icon_value = icone['restore.png'].icon_id)            
                    #col.operator("hdri.resdef",text='Restore default')"""

                    row = box.row(align=True)
                    row.prop(scn.hdri_prop_scn, 'hdri_projected_menu',
                             text='Projection Menu')  # ,icon_value = icone['Menu open.png'].icon_id if csp.hdri_projected_menu else icone['Menu close.png'].icon_id)
                    row.prop(scn.hdri_prop_scn, 'fog_menu',
                             text='Fog Menu')  # ,icon_value = icone['Menu open.png'].icon_id if csp.fog_menu else icone['Menu close.png'].icon_id)

                    if scn.hdri_prop_scn.hdri_projected_menu:
                        box1 = box.box()

                        split = box1.split(factor=0.5, align=True)
                        col = split.column(align=True)
                        col.prop(scn.hdri_prop_scn, 'domeMap_x', text='Move X')
                        col.prop(scn.hdri_prop_scn, 'domeMap_y', text='Move Y')
                        col.prop(scn.hdri_prop_scn, 'domeMap_z', text='Height')
                        col = split.column(align=True)
                        col.prop(scn.hdri_prop_scn, 'dome_size', text='Dome Size')
                        col.prop(scn.hdri_prop_scn, 'dome_top_light', text='Top Light')
                        col.prop(scn.hdri_prop_scn, 'wrap_smooth', text='Smooth wrap', slider=True)

                        row = box1.row(align=True)
                        row.operator("hdrimaker.shrinkwrap", text='Wrap', icon='SEQ_HISTOGRAM').options = 'ADD'

                        if ob:
                            if ob.type == 'MESH':
                                row.prop(ob.hdri_prop_obj, 'hide_wrap', text='Hide',
                                         icon='HIDE_ON' if ob.hdri_prop_obj.hide_wrap else 'HIDE_OFF')

                        row.operator("hdrimaker.shrinkwrap", text='Un-Wrap', icon='REMOVE').options = 'REMOVE'

                        row = box1.row(align=True)

                        row.operator("hdrimaker.assignbackat", text='Add Ground', icon='MATERIAL').options = 'ADD'
                        row.operator("hdrimaker.assignbackat", text='Remove', icon='REMOVE').options = 'REMOVE'

                    if scn.hdri_prop_scn.fog_menu:
                        box2 = box.box()
                        row = box2.row()
                        row.prop(scn.hdri_prop_scn, 'fog_on_off', text='Show Fog', slider=True)
                        row.prop(scn.hdri_prop_scn, 'fog_flip', text='Flip top', slider=True)

                        icon_size = 0.1
                        slider_size = 0.5

                        col = box2.column(align=True)

                        row = col.split(factor=icon_size)
                        row.label(text='', icon_value=icone['cloud_white_single.png'].icon_id)
                        row = row.split(align=True)
                        row.prop(scn.hdri_prop_scn, 'fog_density', text='Density', slider=True)
                        row.prop(scn.hdri_prop_scn, 'fog_level', text='Level', slider=True)
                        row.prop(scn.hdri_prop_scn, 'fog_emission', text='Emissive', slider=True)

                        row = col.split(factor=icon_size)
                        row.label(text='', icon_value=icone['cloud_white.png'].icon_id)

                        row = row.split(align=True)
                        row.prop(scn.hdri_prop_scn, 'fog_patches', text='Patches', slider=True)
                        row.prop(scn.hdri_prop_scn, 'fog_patches_size', text='P.Scale', slider=True)

                        row = col.split(factor=icon_size)
                        row.label(text='', icon_value=icone['windsock.png'].icon_id)
                        row = row.split(factor=slider_size, align=True)
                        row.prop(scn.hdri_prop_scn, 'fog_wind', text='Wind force', slider=True)
                        row.prop(scn.hdri_prop_scn, 'fog_direction', text='Direction')

                        if scn.hdri_prop_scn.show_dome is False:
                            row = box2.row(align=True)
                            row.prop(scn.hdri_prop_scn, 'fog_box_size', text='Fog area size')
                        row = box2.row(align=True)
                        row.prop(scn.hdri_prop_scn, 'fog_detail', text='Fog details')

                layout.prop(csp, 'menu_shadowcatcher', text='Shadow Catcher',
                            icon_value=icone['Menu open.png'].icon_id if csp.menu_shadowcatcher else icone[
                                'Menu close.png'].icon_id)
                if csp.menu_shadowcatcher:
                    box = layout.box()
                    # if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                    if ob:

                        row = box.row(align=True)
                        row.operator("hdrimaker.switchengine",
                                     text='Switch to Cycles' if scn.render.engine == 'BLENDER_EEVEE' else 'Switch to Eevee')

                        # if scn.render.engine == 'BLENDER_EEVEE':

                        row = box.row(align=True)
                        row.scale_y = 2

                        findSC = False
                        for s in ob.material_slots:
                            if s.material:
                                if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                                    findSC = True

                        if findSC:
                            row.operator("hdrimaker.removeshadowcatcher", text='Remove Shadow Catcher',
                                         icon_value=icone['remove green.png'].icon_id)
                        else:
                            if ob.hdri_prop_obj.object_id_name != 'CYCLES_SHADOW_CATCHER':
                                row.operator("hdrimaker.shadowcatcher", text='Add Shadow Catcher',
                                             icon_value=icone['add green.png'].icon_id)

                        row = box.row(align=False)
                        row.label(text="Shadow catcher type:")
                        row = box.row(align=False)
                        row.label(text='', icon_value=icone['play_green.png'].icon_id)
                        row.prop(ob.hdri_prop_obj, 'shadow_catcher_type', text='')
                        # row = box.row(align = False)
                        # row.prop(ob.hdri_prop_obj,'alpha_mode',text='Alpha')

                        if findSC:

                            col = box.column(align=True)
                            if scn.render.engine == 'BLENDER_EEVEE':
                                col.prop(ob.hdri_prop_obj, 'SC_SHADOW_COLOR', text='Shadow color')

                            col.prop(ob.hdri_prop_obj, 'SC_SHADOW_RAMP_Range', text='Adjust Range', slider=True)
                            if scn.render.engine == 'BLENDER_EEVEE':
                                col.prop(ob.hdri_prop_obj, 'SC_SHADOW_RAMP_Fade', text='Fade shadow', slider=True)
                            col.prop(ob.hdri_prop_obj, 'SC_REFLECTION_MIX', text='Reflection', slider=True)
                            col.prop(ob.hdri_prop_obj, 'SC_REFLECTION_ROUGH', text='Roughness', slider=True)
                            if scn.render.engine == 'BLENDER_EEVEE':
                                col.prop(ob.hdri_prop_obj, 'reflection_probe_size', text='Reflection probe size',
                                         slider=True)

                            row = box.row(align=True)
                            row.scale_x = 6
                            row.prop(ob.hdri_prop_obj, 'SC_FADE_REFLECTION', text='Reflection fade', slider=True)
                            row.prop(ob.hdri_prop_obj, 'SC_GRADIENT_REFLECTION_TYPE', text='RF', expand=True)

                            if ob.hdri_prop_obj.shadow_catcher_type == 'NORMAL_CATCHER':
                                col = box.column(align=True)
                                col.prop(ob.hdri_prop_obj, 'normal_maps_list', text='Map')
                                col = box.column(align=True)
                                col.label(text='Normal controls:')
                                col.prop(ob.hdri_prop_obj, 'normal_scale', text='Scale')
                                col.prop(ob.hdri_prop_obj, 'normal_rotation', text='Rotate')
                                col.prop(ob.hdri_prop_obj, 'normal_strength', text='Strength')

                            if ob.hdri_prop_obj.shadow_catcher_type == 'WATER_CATCHER':
                                col = box.column(align=True)
                                col.label(text='Water Type')
                                col.prop(ob.hdri_prop_obj, 'water_type', text='', slider=True)
                                col.prop(ob.hdri_prop_obj, 'wave_size', text='Wave scale')
                                if ob.hdri_prop_obj.water_type == 'FLOW':
                                    col.prop(ob.hdri_prop_obj, 'water_direct', text='Water direction')
                                col.prop(ob.hdri_prop_obj, 'water_vel', text='Water speed', slider=True)
                                col.prop(ob.hdri_prop_obj, 'wave_detail', text='Wave detail', slider=True)
                                col.prop(ob.hdri_prop_obj, 'water_bump', text='Wave strength', slider=True)


                    else:
                        col = box.column(align=True)
                        col.label(text='Add or select a plane to apply shadow catcher')

                    if ob:

                        displace = ob.modifiers.get('HDRI_MAKER_DISPLACE')
                        obIdName = ob.hdri_prop_obj.object_id_name
                        if displace is None and obIdName == 'SHADOW_CATCHER':
                            if findSC:
                                row = box.row(align=True)
                                row.operator("hdrimaker.displaceadd", text='Add displace',
                                             icon_value=icone['add orange.png'].icon_id)
                        if displace and findSC:
                            row = box.row(align=True)
                            row.operator("hdrimaker.displaceremove", text='Remove displace',
                                         icon_value=icone['remove orange.png'].icon_id)

                            row = box.row(align=True)
                            row.operator("hdrimaker.suddividi", text='Subdivide',
                                         icon_value=icone['plus_orange.png'].icon_id)
                            row.operator("hdrimaker.dissuddividi", text='Un-Subdivide',
                                         icon_value=icone['minus_orange.png'].icon_id)

                            col = box.column(align=True)
                            col.prop(ob.hdri_prop_obj, 'show_wireframe', text='Show wire')
                            col.prop(ob.hdri_prop_obj, 'displace_maps_list', text='Displace')
                            col.prop(ob.hdri_prop_obj, 'displace_strength', text='Strength')
                            col.prop(ob.hdri_prop_obj, 'displace_smooth', text='Smooth')
                            col.prop(ob.hdri_prop_obj, 'displace_midlevel', text='Midlevel')
                            col.prop(ob.hdri_prop_obj, 'displace_scale', text='Scale')

                    col = box.column(align=True)
                    col.prop(scn.render, 'film_transparent', text='Transparent Background')

                layout.prop(csp, 'save_menu', text='Save menu',
                            icon_value=icone['Menu open.png'].icon_id if csp.save_menu else icone[
                                'Menu close.png'].icon_id)
                if csp.save_menu:
                    box = layout.box()
                    col = box.column(align=True)
                    col.operator("hdrimaker.exporthdr", text='Export image', icon_value=icone['export.png'].icon_id)

                    col = box.column(align=True)
                    col.prop(csp, 'save_type', text='Save type')

                    if csp.save_type == 'CURRENT':
                        col = box.column(align=True)
                        col.scale_y = 2
                        col.operator("hdrimaker.saveop", text='Save background')
                        col = box.column(align=True)
                        col.scale_y = 1
                        col.prop(csp, 'sovrascrivi', text='Overwrite if the name exists')

                    if csp.save_type == 'PANORAMA':
                        col = box.column(align=True)
                        col.prop(csp, 'denoise_type', text='Denoise')
                        col.prop(csp, 'k_custom_size', text='Custom size', expand=True)

                        row = box.row()
                        if csp.k_custom_size:
                            row.prop(csp, 'k_panorama_size_custom', text='Size in K', expand=True)
                        else:
                            row.prop(csp, 'k_panorama_size', text='Size in K', expand=True)
                        row = box.row()
                        row.prop(csp, 'compute_processor', text='')
                        row.prop(csp, 'render_sample', text='Samples')

                        okCam = False
                        for o in context.scene.objects:
                            if o.hdri_prop_obj.object_id_name == 'CamSphere':
                                okCam = True
                        if okCam:

                            col = box.column(align=True)
                            col.scale_y = 2
                            col.operator("hdrimaker.saveop", text='Panorama Save',
                                         icon_value=icone['camera.png'].icon_id)
                            row = box.row(align=True)
                            row.operator("hdrimaker.putcamera", text='360 Cam on cursor',
                                         icon_value=icone['circle.png'].icon_id)
                            row.operator("hdrimaker.findcam", text='Find Camera',
                                         icon_value=icone['search.png'].icon_id)

                            col = box.column(align=True)
                            col.scale_y = 1
                            col.prop(csp, 'sovrascrivi', text='Overwrite if the name exists')

                        else:

                            col = box.column(align=True)
                            col.scale_y = 2
                            col.operator("hdrimaker.cameraloc", text='Add 360 Cam on cursor')

                    if csp.save_type == 'BATCH':
                        col = box.column(align=True)
                        col.label(text='Choose the source folder:')
                        col.prop(csp, 'save_source_path', text='', icon_value=icone['folder.png'].icon_id)
                        col = box.column(align=True)
                        col.scale_y = 2
                        col.operator("hdrimaker.saveop", text='Batch Save')
                        col = box.column(align=True)
                        col.scale_y = 1
                        col.prop(csp, 'sovrascrivi', text='Overwrite if the name exists')

                    col = box.column(align=False)
                    if csp.def_to_user_lib == 'DEFAULT':
                        col.prop(csp, 'personal_category', text='Save to Cat')
                    else:
                        col.prop(csp, 'up_category', text='Save to Cat')

                    if csp.save_type != 'BATCH':
                        col.prop(csp, 'world_save_name', text='HDR Name')

                    row = box.row(align=True)
                    row.scale_x = 0.4
                    row.operator('hdrimaker.addcategory', text='Add Cat', icon_value=icone['folder.png'].icon_id)
                    row.scale_x = 0.6
                    row.prop(csp, 'add_category', text='')

                    if csp.def_to_user_lib == 'USER':
                        col = box.column()
                        col.prop(csp, 'collection_management', text='Cat Managemet',
                                 icon_value=icone['Menu open.png'].icon_id if csp.collection_management else icone[
                                     'Menu close.png'].icon_id)
                        if csp.collection_management:

                            box = col.box()
                            col = box.column(align=False)
                            col.label(text='Move current background to another cat')
                            row = col.row(align=False)
                            row.scale_x = 0.35
                            row.prop(csp, 'up_category', text='')
                            row.scale_x = 0.30
                            row.operator("hdrimaker.tocat", text='Move', icon_value=icone["right.png"].icon_id)
                            row.scale_x = 0.35
                            row.prop(csp, 'category_destination', text='')

                            col = box.column(align=False)
                            col.label(text='Rename:')
                            row = col.row(align=True)
                            row.scale_x = 0.4
                            row.operator("hdrimaker.renamemat", text='Background',
                                         icon_value=icone["rename.png"].icon_id)
                            row.scale_x = 0.6
                            row.prop(csp, 'renamed_material', text='')

                            row = col.row(align=True)
                            row.scale_x = 0.4
                            row.operator("hdrimaker.renamecat", text='Category', icon_value=icone['rename.png'].icon_id)
                            row.scale_x = 0.6
                            row.prop(csp, 'rename_category', text='')

                            if csp.up_category != 'Empty Collection...' or hdr_name != 'Empty':
                                col = box.column(align=False)
                                col.prop(csp, 'safety_delete', text='Safety delete',
                                         icon_value=icone['Menu open.png'].icon_id if csp.safety_delete else icone[
                                             'Menu close.png'].icon_id)
                                if csp.safety_delete:
                                    if csp.up_category != 'Empty Collection...':
                                        col.operator("hdrimaker.removecategory", text="Delete category",
                                                     icon_value=icone['danger.png'].icon_id)
                                    if hdr_name != 'Empty':
                                        if csp.def_to_user_lib == 'USER':
                                            col.operator("hdrimaker.removebackground", text="Delete background",
                                                         icon_value=icone['danger.png'].icon_id)
                    else:
                        col = box.column()
                        box = col.box()
                        col = box.column()
                        col.label(text='Switch to User for more options', icon_value=icone['info.png'].icon_id)

                layout.prop(csp, 'menu_option', text='Options',
                            icon_value=icone['Menu open.png'].icon_id if csp.menu_option else icone[
                                'Menu close.png'].icon_id)

                if csp.menu_option:
                    box = layout.box()
                    col = box.column(align=True)
                    col.prop(csp, 'menu_icon_size', text='Box icons scale')
                    col.prop(csp, 'menu_icon_popup', text='Popup icons scale')

                    row = box.row()
                    row.label(text='Eevee Shadow options:')

                    row = box.row()
                    row.prop(csp, 'shadow_detail', text='Detail')
                    col = box.column(align=True)
                    col.prop(csp, 'menu_label', text='Popup label')

                    col.operator("hdrimaker.info", text='PDF Manual').options = '2'
                    col = box.column(align=True)
                    # col.prop(csp,'menu_icon_theme',text='Theme')
                    col.operator("hdrimaker.checkupdate", text='Check for update', icon="LINK_BLEND")


def load_new_world_nodes(scn):
    # Il discorso è, i nodi sono in continua evoluzione e sottoposti ad aggiornamenti
    # quindi gli sfondi precedentemente salvati vanno esaminati per determinare se si tratta di un nodo aggiornato o no
    # se non è aggiornato verrà caricato il nuovo nodo e sostituita l'immagine solo nel caso sia uno sfondo di tipo HDRi Maker

    nodoImmagine = None
    immagine = None
    colorize = None
    colorMix = None
    exposure = None

    for n in scn.world.node_tree.nodes:
        ###3 condizioni di riscontro per definire se si tratta di uno sfondo creato con HDRi Maker di tipo HDR
        if n.name == 'HDRi Maker Background':
            nodoImmagine = n
            immagine = n.image
        if n.name == 'HDRI_COLORIZE':
            colorize = n
        if n.name == 'HDRI_COLORIZE_MIX':
            colorMix = n
        ############################################
        ### Nuovi nodi di tipo gruppo:
        if n.name == 'HDRI_Maker_Exposure':
            exposure = n

    if exposure:
        return

    else:
        if nodoImmagine and colorize and colorMix:

            percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'Background Node v2.blend')

            with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
                data_to.worlds = [w for w in data_from.worlds]

            for w in data_to.worlds:
                scn.world = w.copy()
                scn.world.hdri_prop_world.world_user = True
                scn.world.hdri_prop_world.world_hdri_maker = True

            if immagine:
                for n in scn.world.node_tree.nodes:
                    if n.name == 'HDRi Maker Background':
                        n.image = immagine


class PREVIUS_OT_HdriImage(bpy.types.Operator):
    """Previus HDRI"""

    bl_idname = "hdri.previusicon"
    bl_label = "Previus hdri"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        indicone(self, context)
        csp = context.scene.hdri_prop_scn

        try:

            if indicone.get != 0:
                bpy.data.window_managers["WinMan"].hdri_category = indicone.immagini[indicone.get - 1].replace('.png',
                                                                                                               '')
                # if csp.auto_add:
                #    bpy.ops.hdrimaker.add()
        except:
            pass

        return {'FINISHED'}


class NEXT_OT_HdriImage(bpy.types.Operator):
    """Next HDRI"""

    bl_idname = "hdri.nexticon"
    bl_label = "Next hdri"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        indicone(self, context)
        csp = context.scene.hdri_prop_scn

        try:
            bpy.data.window_managers["WinMan"].hdri_category = indicone.immagini[indicone.get + 1].replace('.png', '')
            # if csp.auto_add:
            #    bpy.ops.hdrimaker.add()
        except:
            pass

        return {'FINISHED'}


class PREVIUS_OT_CategoryHdri(bpy.types.Operator):
    """Previus category"""

    bl_idname = "hdri.previuscategory"
    bl_label = "Previus category"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        cat(self, context)
        csp = context.scene.hdri_prop_scn

        try:
            if cat.current_index != 0:
                csp.up_category = funzione_preview_categorie.indice[cat.current_index - 1]
                # if csp.auto_add:
                #    bpy.ops.hdrimaker.add()
        except:
            pass

        return {'FINISHED'}


class NEXT_OT_CategoryHdri(bpy.types.Operator):
    """Next category"""

    bl_idname = "hdri.nextcategory"
    bl_label = "Next category"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        cat(self, context)
        csp = context.scene.hdri_prop_scn

        try:
            csp.up_category = funzione_preview_categorie.indice[cat.current_index + 1]
            # if csp.auto_add:
            #    bpy.ops.hdrimaker.add()
        except:
            pass
        return {'FINISHED'}


def searchCallback(scene, context):
    scn = context.scene
    scnProp = scn.hdri_prop_scn

    if scnProp.def_to_user_lib == 'DEFAULT':
        dir = os.path.join(GlobalPathHdri.HdriLib, "preview_hdri")
    else:
        dir = os.path.join(GlobalPathHdri.HdriUser)

    png = []
    for subdir, dirs, files in os.walk(dir):
        for f in files:
            if not any(m in f for m in mac_bad_extension):
                if '.png' in f:
                    png.append(f[:-4])

    return [(y, y, "", x) for x, y in enumerate(png)]


class SEARCHER_OT_Hdri(bpy.types.Operator):
    """Search background"""
    bl_idname = "hdri.search_popup"
    bl_label = "Search Popup"
    bl_property = "search_hdri"
    bl_options = {'INTERNAL'}

    search_hdri: EnumProperty(name="search_hdri", description="", items=searchCallback)

    def execute(self, context):
        csp = context.scene.hdri_prop_scn
        if csp.def_to_user_lib == 'DEFAULT':
            dir = os.path.join(GlobalPathHdri.HdriLib, "preview_hdri")
        else:
            dir = os.path.join(GlobalPathHdri.HdriUser)

        for subdir, dirs, files in os.walk(dir):
            for f in files:
                if not any(m in f for m in mac_bad_extension):
                    if f == self.search_hdri + '.png':
                        csp.up_category = subdir.split(os.path.sep)[-1]
        bpy.data.window_managers["WinMan"].hdri_category = self.search_hdri
        # if csp.auto_add:
        #    bpy.ops.hdrimaker.add()

        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        wm.invoke_search_popup(self)
        return {'FINISHED'}


def searchWorld(self, context):
    try:
        scn = bpy.context.scene
        csp = scn.hdri_prop_scn

        idWorld = scn.world.hdri_prop_world.world_id_name

        dir = (os.path.join(GlobalPathHdri.HdriLib, "preview_hdri"), GlobalPathHdri.HdriUser)

        if idWorld != '':
            for subdir, dirs, files in chain.from_iterable(os.walk(path) for path in dir):
                for f in files:
                    if not any(m in f for m in mac_bad_extension):
                        if f == idWorld + '.png':
                            try:
                                csp.def_to_user_lib = 'DEFAULT'
                                csp.up_category = subdir.split(os.path.sep)[-1]
                            except:
                                csp.def_to_user_lib = 'USER'
                                csp.up_category = subdir.split(os.path.sep)[-1]

            bpy.data.window_managers["WinMan"].hdri_category = idWorld
    except:
        pass


class SEARCH_OT_InUseWorld(bpy.types.Operator):
    """Look for the preview of the current world"""

    bl_idname = "hdrimaker.current"
    bl_label = "Check hdri"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        searchWorld(self, context)

        return {'FINISHED'}


def reset(self, context):
    scn = bpy.context.scene
    csp = scn.hdri_prop_scn
    csp.emission_force = 1
    csp.bright_hdri = 0
    csp.exposure_hdri = 0
    csp.hue_saturation = 1
    csp.rot_world_x = 0
    csp.rot_world_y = 0
    csp.rot_world = 0
    csp.menu_bottom = 0
    csp.colorize_mix = 0
    csp.dome_top_light = 2
    csp.domeMap_x = 0
    csp.domeMap_y = 0
    csp.domeMap_z = 2
    csp.sun_light = 2
    csp.sunRot_x = 45
    csp.sunRot_z = 0


class RESET_OT_HDRiOptions(bpy.types.Operator):
    """Reset to default"""

    bl_idname = "hdri.resdef"
    bl_label = "Reset"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        reset(self, context)

        return {'FINISHED'}


def updateSwitch(self, context):
    cat(self, context)
    funzione_preview_categorie(self, context)
    update_first_cat(self, context)
    update_first_icon(self, context)


def searchHdr(self, context):
    scn = bpy.context.scene
    scnProp = scn.hdri_prop_scn
    sourcePath = scnProp.save_source_path

    hdrFound = []
    for item in os.listdir(sourcePath):
        if not any(m in item for m in mac_bad_extension):
            if item.endswith('.hdr') or item.endswith('.exr'):
                hdrFound.append(os.path.join(sourcePath, item))

    searchHdr.list = hdrFound


class HDRIMAKER_OT_BatchModal(bpy.types.Operator):
    """Batch Save Modal"""

    bl_idname = "hdrimaker.batchmodal"
    bl_label = "Modal Save Operator"
    bl_options = {'INTERNAL'}

    _timer = None
    full_list = None
    chrono_start = None
    cronometro = None
    media_step = 0
    chrono_aprx_memory = 0
    mouse_location = None

    def modal(self, context, event):

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.area.tag_redraw()
            self.cancelled(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':

            if len(searchHdr.list) != 0:

                chrono_check = time.time()

                subOperatorSky(self, context, sceneSwitch.scenaBatch, 'BATCH', 'No Image', 'None')

                nomeSalvataggio = os.path.basename(searchHdr.list[0])[:-4]
                for s in bpy.data.scenes:
                    if s.hdri_prop_scn.scene_id_name == 'batch_scene':
                        s.hdri_prop_scn.world_save_name = nomeSalvataggio

                if sceneSwitch.scenaUtente.hdri_prop_scn.sovrascrivi is False:
                    controllaNome(GlobalPathHdri.HdriUser, nomeSalvataggio, 'BATCH')

                savePreviewAndWorld(self, context, 'BATCH', context.copy(), 'NONE')

                searchHdr.list.pop(0)

                total = 100 - ((len(searchHdr.list) / self.full_list) * 100)
                bar = []
                for i in range(int(total)):
                    bar.append('|')
                bar = ''.join(bar)

                chrono_stop = time.time()
                cronometro = chrono_stop - self.chrono_start

                if self.media_step == 0:
                    chrono_aprox = (chrono_stop - chrono_check) * len(searchHdr.list)
                    self.chrono_aprx_memory = chrono_aprox
                    if len(searchHdr.list) > 6:
                        self.media_step = 3
                    else:
                        self.media_step = 1
                else:
                    self.media_step = self.media_step - 1
                    chrono_aprox = self.chrono_aprx_memory

                # chrono_aprox*=len(count)
                rimanenti = self.full_list - len(searchHdr.list)

                context.window.cursor_warp(self.mouse_location.x, self.mouse_location.y)

                def popup(self, context):

                    layout = self.layout
                    layout.label(text="The background are currently being saved, to cancel:")
                    layout.label(text="hold 'Esc' or press the right mouse button a few times")
                    layout.label(text="")
                    layout.label(text="Time: " + "{}".format(datetime.timedelta(seconds=int(cronometro))), icon='TIME')
                    layout.label(text=str(len(searchHdr.list)) + " backgrounds to finish", icon='MATERIAL')
                    layout.label(text="")
                    layout.label(text="Saved background: " + str(rimanenti), icon='MATERIAL')
                    layout.label(text="Approximate remaining time: " + "{}".format(
                        datetime.timedelta(seconds=int(chrono_aprox))), icon='TIME')
                    col = layout.column(align=True)
                    col.label(
                        text="------------------------------------------ {}% -------------------------------------------".format(
                            round(total, 2)))
                    col.label(text=bar)

                context.window_manager.popup_menu(popup, title="Save State: ", icon='INFO')




            else:
                self.cancelled(context)
                return {'CANCELLED'}

        context.area.tag_redraw()

        return {'PASS_THROUGH'}

    def execute(self, context):

        finestra = context.area.regions.data
        pos_x = finestra.x
        pos_y = finestra.y
        lar_x = finestra.width
        lar_y = finestra.height
        x = pos_x + (lar_x / 2)
        y = pos_y + (lar_y / 2)
        self.mouse_location = Vector([x, y])

        def draw(self, context):
            self.layout.label(text="!!! Please wait !!!")

        context.window_manager.popup_menu(draw, title="HDRi Maker", icon='INFO')

        self.chrono_start = time.time()
        self.full_list = len(searchHdr.list)

        for s in bpy.data.scenes:
            if s.hdri_prop_scn.scene_id_name == 'scena_utente':
                context.window.scene = s

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancelled(self, context):

        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        removeScene()


def sceneSwitch(self, context, type_save, ctx):
    scena_utente = ctx['scene']

    scnProp = scena_utente.hdri_prop_scn
    sceneSwitch.light = scnProp.light_redraw
    sceneSwitch.satur = scnProp.saturation_redraw

    ##id name alla scena utente in maniera da reimpostarla senza problemi:

    scena_utente.hdri_prop_scn.scene_id_name = 'scena_utente'
    background_utente = scena_utente.world

    sceneSwitch.correctCat = scnProp.personal_category if scnProp.def_to_user_lib == 'DEFAULT' else scnProp.up_category

    # Cerca se c'è già una scena batch in maniera da non scriverne 2 in caso di errori

    for s in bpy.data.scenes:
        if s.hdri_prop_scn.scene_id_name == 'batch_scene':
            ctx['window'].scene = s

    # Se non trova nessuna scena batch_scene procede con la scrittura di una nuova scena e la rende contestuale
    if ctx['window'].scene.hdri_prop_scn.scene_id_name != 'batch_scene':
        batch_scene = bpy.data.scenes.new('Batch scene')
        batch_scene.hdri_prop_scn.scene_id_name = 'batch_scene'
        ctx['window'].scene = batch_scene

    for o in batch_scene.objects:
        bpy.data.objects.remove(o)

    ###Questo è l'input della funzione, se false , utilizza il background della scena utente
    sceneSwitch.scenaUtente = scena_utente
    sceneSwitch.scenaBatch = batch_scene

    ###Aggiungo questo poichè al cambio scena si perde la categoria corrente

    if type_save == 'PANORAMA':
        ###Chiamata della funzione che aggiunge un mondo , ma bisogna cambiare l'immagine e aggiungere
        # quella appena renderizzata:
        batch_scene.hdri_prop_scn.def_to_user_lib = 'DEFAULT'
        subOperatorSky(self, context, ctx['window'].scene, 'PANORAMA', 'No Image', 'None')
        savePreviewAndWorld(self, context, 'PANORAMA', ctx, 'NONE')

        return True

    if type_save == 'CURRENT':
        batch_scene.world = background_utente


def panoramaScene(self, context):
    # Memorizzo i dati che vengono cambiati nella context.scene poichè questo tipo di
    # Salvataggio necessita la scena utente e va a modificare i parametri in essa
    # Quindi andranno riportati allo stato di partenza, altrimenti l'utente avrà le impostazioni
    # Render ed altro sballate

    ctx = context.copy()
    panoramaScene.contesto = ctx

    scena_utente = ctx['scene']
    csp = scena_utente.hdri_prop_scn
    csp.scene_id_name = 'scena_utente'

    categoria = csp.personal_category if csp.def_to_user_lib == 'DEFAULT' else csp.up_category
    panoramaScene.filepath = GlobalPathHdri.HdriUser + categoria + os.sep + 'HDRI_MAKER_TEMP_360_' + csp.world_save_name

    nomeFile = csp.world_save_name + '.hdr'

    ##indecisione se rimuovere o sovrascrivere
    """
    for file in os.listdir(GlobalPathHdri.HdriUser + os.sep + categoria):
        if file.casefold() ==  nomeFile.casefold():
            os.remove(panoramaScene.filepath+'.hdr')"""

    ######################################################################
    # Memorizzo Blocco dati da riportare allo stato di partenza dopo il render
    previus_use_node = scena_utente.use_nodes
    previus_compositing_process = scena_utente.render.use_compositing
    previus_overwrite = scena_utente.render.use_overwrite
    previus_filextensions = scena_utente.render.use_file_extension
    previus_placeholders = scena_utente.render.use_placeholder
    previus_chacheresult = scena_utente.render.use_render_cache

    previusRenderPath = scena_utente.render.filepath
    previus_engine = scena_utente.render.engine
    previus_size_x = scena_utente.render.resolution_x
    previus_size_y = scena_utente.render.resolution_y
    previus_image_format = scena_utente.render.image_settings.file_format
    previus_bW = scena_utente.render.image_settings.color_mode
    previus_denoise = context.view_layer.cycles.use_denoising
    ####
    previus_samples_cycles = scena_utente.cycles.samples
    previus_samples_eevee = scena_utente.eevee.taa_render_samples
    if hasattr(scena_utente.render, 'tile_x'):
        previus_tile_x = scena_utente.render.tile_x
        previus_tile_y = scena_utente.render.tile_y
    ####

    ######################################################################
    sferaCam = None
    for o in scena_utente.objects:
        if o.hdri_prop_obj.object_id_name == 'CamSphere':
            sferaCam = o

    cam_pano_data = bpy.data.cameras.new("Camera Pano")
    camera_panorama = bpy.data.objects.new("Camera", cam_pano_data)
    camera_panorama.data.type = 'PANO'
    camera_panorama.location = sferaCam.location
    camera_panorama.rotation_euler = ((radians(90), 0, 0))
    camera_panorama.hdri_prop_obj.object_id_name = 'camera_panorama'
    camera_panorama.data.cycles.panorama_type = 'EQUIRECTANGULAR'
    camera_panorama.data.cycles.latitude_min = -1.5708
    camera_panorama.data.cycles.latitude_max = 1.5708
    camera_panorama.data.cycles.longitude_min = -3.14159
    camera_panorama.data.cycles.longitude_max = 3.14159
    camera_panorama.data.shift_x = 0
    camera_panorama.data.shift_y = 0
    camera_panorama.data.clip_start = 0.1
    camera_panorama.data.clip_end = 10000

    ######################################################################
    # Blocco dati da riportare allo stato di partenza dopo il render
    scena_utente.render.image_settings.color_mode = 'RGB'
    scena_utente.render.use_overwrite = True
    scena_utente.render.use_file_extension = True
    scena_utente.render.use_placeholder = False
    scena_utente.render.use_render_cache = False
    scena_utente.render.filepath = panoramaScene.filepath

    sizeK = float(csp.k_panorama_size) if csp.k_custom_size is False else float(csp.k_panorama_size_custom)
    scena_utente.render.resolution_x = sizeK * 1024
    scena_utente.render.resolution_y = sizeK * 512
    scena_utente.render.engine = 'CYCLES'
    ####
    scena_utente.cycles.samples = csp.render_sample
    scena_utente.eevee.taa_render_samples = csp.render_sample
    ####
    scena_utente.render.image_settings.file_format = 'HDR'
    scena_utente.camera = camera_panorama

    if csp.denoise_type == 'NONE':
        scena_utente.use_nodes = False
        context.window.view_layer.cycles.use_denoising = False

    if csp.denoise_type == 'COMPOSITE':
        scena_utente.render.use_compositing = True
        scena_utente.use_nodes = True
        context.window.view_layer.cycles.use_denoising = False
        mem_nod_out(self, context)
        create_node(self, context)

    if csp.denoise_type == 'CYCLES':
        scena_utente.use_nodes = False
        context.window.view_layer.cycles.use_denoising = True

    if hasattr(scena_utente.render, 'tile_x'):
        if csp.compute_processor == 'GPU':
            scena_utente.render.tile_x = 256
            scena_utente.render.tile_y = 256
        else:
            scena_utente.render.tile_x = 64
            scena_utente.render.tile_y = 64

    ######################################################################

    def end_of_pano_render():

        sceneSwitch(self, context, 'PANORAMA', ctx)

        try:
            if csp.world_save_name[-4] == '_':
                if csp.world_save_name[-3:].isnumeric():
                    csp.world_save_name = csp.world_save_name[:-4]
        except:
            pass

        for i in bpy.data.images:
            if i.name == 'hdriMaker_render_finished.png':
                bpy.data.images.remove(i)

        endImgPath = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'hdriMaker_render_finished.png')
        end_image = bpy.data.images.load(endImgPath)

        check_if_window_is_closed = True
        for w in bpy.context.window_manager.windows:
            if len(w.screen.areas) == 1:
                for area in w.screen.areas:
                    if area.type == 'IMAGE_EDITOR':
                        area.spaces.active.image = end_image
                        check_if_window_is_closed = False
                        # bpy.ops.wm.window_close(contestoRender)

        ###Se non trova piu la finestra vuol dire che è stata chiusa, quindi cancella i
        ###file creati che sono sbagliati in quanto il render non è completo
        if check_if_window_is_closed:
            try:
                os.remove(savePreviewAndWorld.previewPath + '.png')
                os.remove(savePreviewAndWorld.blendPath)
            except:
                pass
        else:
            renamePng = savePreviewAndWorld.previewPath + '.png'
            renamePng = renamePng.replace('HDRI_MAKER_TEMP_360_', '')
            renameBlend = savePreviewAndWorld.previewPath + '.blend'
            renameBlend = renameBlend.replace('HDRI_MAKER_TEMP_360_', '')
            panoramaScene.previewCall = renamePng[:-4]
            if os.path.exists(renamePng):
                os.remove(renamePng)
            if os.path.exists(renameBlend):
                os.remove(renameBlend)

            os.rename(savePreviewAndWorld.previewPath + '.png', renamePng)
            os.rename(savePreviewAndWorld.previewPath + '.blend', renameBlend)

        # Cancella il file hdr creato poichè è già impaccato nel file .blend
        try:
            os.remove(savePreviewAndWorld.previewPath + '.hdr')
        except:
            pass

        ricaricaPreview(self)

        return None

    def redo_user_settings(self):
        # try:
        # Blocco dati  riporto allo stato di partenza
        if scena_utente.hdri_prop_scn.denoise_type == 'COMPOSITE':
            redo_last_compo_node(self)

        ctx['view_layer'].cycles.use_denoising = previus_denoise
        for s in bpy.data.scenes:
            if s.hdri_prop_scn.scene_id_name == 'scena_utente':

                s.render.use_overwrite = previus_overwrite
                s.render.use_file_extension = previus_filextensions
                s.render.use_placeholder = previus_placeholders
                s.render.use_render_cache = previus_chacheresult
                s.render.use_compositing = previus_compositing_process
                s.render.filepath = previusRenderPath
                s.render.engine = previus_engine
                s.render.resolution_x = previus_size_x
                s.render.resolution_y = previus_size_y
                s.render.image_settings.file_format = previus_image_format
                s.render.image_settings.color_mode = previus_bW
                s.cycles.samples = previus_samples_cycles
                s.eevee.taa_render_samples = previus_samples_eevee
                if hasattr(s.render, 'tile_x'):
                    s.render.tile_x = previus_tile_x
                    s.render.tile_y = previus_tile_x
                s.use_nodes = previus_use_node

    def end_panorama_render(nessuno):
        bpy.app.handlers.render_complete.remove(end_panorama_render)
        bpy.app.handlers.render_cancel.remove(cancel_panorama_render)

        for o in scena_utente.objects:
            if o.hdri_prop_obj.object_id_name == 'camera_panorama':
                bpy.data.objects.remove(o)
        redo_user_settings(self)

        bpy.app.timers.register(end_of_pano_render, first_interval=1.5)

    ##Solo nel caso si prema esc questo non viene eseguito se si chiude la finestra render
    def cancel_panorama_render(nessuno):

        bpy.app.handlers.render_complete.remove(end_panorama_render)
        bpy.app.handlers.render_cancel.remove(cancel_panorama_render)
        try:
            if csp.world_save_name[-4] == '_':
                if csp.world_save_name[-3:].isnumeric():
                    csp.world_save_name = csp.world_save_name[:-4]
        except:
            pass

        redo_user_settings(self)
        return None

    bpy.app.handlers.render_complete.append(end_panorama_render)
    bpy.app.handlers.render_cancel.append(cancel_panorama_render)

    try:
        context.scene.cycles.device = scena_utente.hdri_prop_scn.compute_processor
        bpy.ops.render.render('INVOKE_DEFAULT', animation=False, write_still=True)

    except:
        scena_utente.hdri_prop_scn.compute_processor = 'CPU'
        context.scene.cycles.device = 'CPU'
        if hasattr(scena_utente.render, 'tile_x'):
            scena_utente.render.tile_x = 64
            scena_utente.render.tile_y = 64
        bpy.ops.render.render('INVOKE_DEFAULT', animation=False, write_still=True)
    contestoRender = context.copy()


def correct_size(scnProp):
    scnProp.k_panorama_size_custom = scnProp.k_panorama_size_custom.replace(',', '.')
    for i in scnProp.k_panorama_size_custom:
        if i != '.':
            if i.isnumeric() is False:
                return 'Error, There are non-numeric characters!'

    if len(scnProp.k_panorama_size_custom) == 0:
        return "Enter a number (Size in K), or deactivate the 'Custom Size' checkbox and choose a default size"

    return


class HDRIMAKER_OT_Save(bpy.types.Operator):
    """Save HDRs based on the selected option"""
    bl_idname = "hdrimaker.saveop"
    bl_label = "Save HDRs based on the selected option"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        icone = preview_icon_blu["icone"]
        scn = bpy.context.scene
        scnProp = scn.hdri_prop_scn

        for s in bpy.data.scenes:
            if s.hdri_prop_scn.scene_id_name == 'batch_scene':
                bpy.data.scenes.remove(s)
                try:
                    bpy.data.window_managers["WinMan"].hdri_category = os.path.basename(panoramaScene.previewCall)
                except:
                    pass
                return {'FINISHED'}

        up = scnProp.up_category
        pc = scnProp.personal_category
        empty = "Empty Collection..."
        if up == empty or pc == empty or up == '' or pc == '':
            def draw(self, context):
                self.layout.label(text="Before saving, you need to create a new category!")
                self.layout.label(text="Choose a name and press Add Cat")

            bpy.context.window_manager.popup_menu(draw, title="Invalid Folder")
            update_first_cat(self, context)
            update_first_catView(self, context)

            return {'FINISHED'}

        ###Controllo unico tranne per Batch:
        if scnProp.save_type != 'BATCH':
            # Controllo nome esistente tramite funzione , di ritorno può avere il nome modificato con aggiunta numerica

            if scnProp.save_type != 'PANORAMA':
                if context.scene.world is None:
                    def draw(self, context):
                        self.layout.label(text="This scene does not contain any backgrounds to save")

                    bpy.context.window_manager.popup_menu(draw, title="No world background!")
                    return {'FINISHED'}

            regex = re.compile('[@!#$%^&*()<>?/\|}{~:]')
            if (regex.search(scnProp.world_save_name) is not None):
                stopErrorCharacter(self, context)
                return {'FINISHED'}

            if scnProp.sovrascrivi is False:
                check = controllaNome(GlobalPathHdri.HdriUser, scnProp.world_save_name, 'NONE')
                if check is None:
                    return {'FINISHED'}

        if scnProp.save_type == 'CURRENT':
            ctx = context.copy()

            sceneSwitch(self, context, 'CURRENT', ctx)
            savePreviewAndWorld(self, context, 'CURRENT', ctx, 'NONE')

            if len(scnProp.world_save_name) > 4:
                if scnProp.world_save_name[-4] == '_':
                    if scnProp.world_save_name[-3:].isnumeric():
                        scnProp.world_save_name = scnProp.world_save_name[:-4]

            for s in bpy.data.scenes:
                if s.hdri_prop_scn.scene_id_name == 'batch_scene':
                    bpy.data.scenes.remove(s)

            ################################################
            ################################################
        if scnProp.save_type == 'PANORAMA':

            if scnProp.k_custom_size:
                checkNumber = correct_size(scnProp)
                if checkNumber is not None:
                    def draw(self, context):
                        self.layout.label(text=checkNumber)

                    bpy.context.window_manager.popup_menu(draw, title="Invalid custom k size number!")
                    return {'FINISHED'}

            bpy.context.space_data.shading.type = 'SOLID'

            panoramaScene(self, context)
            # Nota: Non mettere piu nulla sotto qui nella condizione 'PANORAMA' poichè il multitreading
            ##
            ### ^^^^^^^^^^^^

        if scnProp.save_type == 'BATCH':
            sourcePath = bpy.path.abspath(scnProp.save_source_path)
            if sourcePath == '':
                if not os.path.exists(sourcePath):
                    def draw(self, context):
                        self.layout.label(text="Attention Enter a path that contains .hdr files")

                    bpy.context.window_manager.popup_menu(draw, title="Invalid Folder")

                    return {'FINISHED'}

            searchHdr(self, context)

            if len(searchHdr.list) == 0:
                def draw(self, context):
                    self.layout.label(text="Attention:")
                    self.layout.label(text="This directory does not contain any .hdr files")
                    self.layout.label(text="Choose a directory that contains .hdr (Background) files")

                bpy.context.window_manager.popup_menu(draw, title="No hdr files found")
                return {'FINISHED'}

            sceneSwitch(self, context, 'BATCH', context.copy())

            bpy.ops.hdrimaker.batchmodal()

            return {'FINISHED'}

        return {'FINISHED'}


def savePreviewAndWorld(self, context, type_save, ctx, preview):
    # if type_save in ('PANORAMA','CURRENT','REDRAW'):
    scena_batch = sceneSwitch.scenaBatch
    # else:
    #    scena_batch = context.scene
    if type_save != 'BATCH':
        ctx['window'].scene = scena_batch

    scnProp = sceneSwitch.scenaUtente.hdri_prop_scn

    cam_data = bpy.data.cameras.new("Camera Preview")
    camera_preview = bpy.data.objects.new("Camera Preview", cam_data)
    camera_preview.data.type = 'PERSP'
    camera_preview.data.lens = 12
    camera_preview.location = (0, 0, 0)
    if type_save == 'REDRAW':
        camera_preview.rotation_euler = (
        radians(90 + scnProp.camera_redraw_up_down), radians(-scnProp.camera_redraw_tilt),
        radians(-scnProp.camera_redraw_rotation))
    else:
        camera_preview.rotation_euler = (radians(90), 0, 0)

    camera_preview.hdri_prop_obj.object_id_name = 'camera_preview'

    scena_batch.collection.objects.link(camera_preview)
    scena_batch.render.use_overwrite = True
    scena_batch.render.use_file_extension = True
    scena_batch.render.use_placeholder = False
    scena_batch.render.use_render_cache = False
    scena_batch.camera = camera_preview
    scena_batch.render.resolution_x = 512
    scena_batch.render.resolution_y = 512
    scena_batch.render.image_settings.file_format = 'PNG'
    scena_batch.render.image_settings.color_mode = 'RGBA'
    scena_batch.render.engine = 'CYCLES'
    scena_batch.cycles.samples = 16

    bpy.context.view_layer.update()

    if type_save == 'REDRAW':
        scena_batch.render.filepath = os.path.join(GlobalPathHdri.HdriUser, sceneSwitch.correctCat, preview)

    else:
        if type_save != 'BATCH':
            nomeMondo = sceneSwitch.scenaUtente.hdri_prop_scn.world_save_name
            if type_save == 'PANORAMA':
                nomeMondo = 'HDRI_MAKER_TEMP_360_' + nomeMondo
        else:
            nomeMondo = sceneSwitch.scenaBatch.hdri_prop_scn.world_save_name

        scena_batch.world.name = nomeMondo
        scena_batch.world.hdri_prop_world.world_id_savename = nomeMondo
        scena_batch.render.filepath = os.path.join(GlobalPathHdri.HdriUser, sceneSwitch.correctCat, nomeMondo)

    try:
        scena_batch.cycles.device = 'GPU'
        bpy.ops.render.render(animation=False, write_still=True, scene=scena_batch.name)
    except:
        scena_batch.cycles.device = 'CPU'
        bpy.ops.render.render(animation=False, write_still=True, scene=scena_batch.name)

    bpy.data.objects.remove(camera_preview)

    if type_save != 'REDRAW':
        ########################################################################
        ###per ora questa sembra la miglior soluzione per impaccare le immagini:

        imageToPack = []
        for n in scena_batch.world.node_tree.nodes:
            if n.type == 'TEX_ENVIRONMENT':
                for i in bpy.data.images:
                    if i == n.image:
                        imageToPack.append(i)

        try:
            for i in imageToPack:
                i.pack()
        except:
            pass

        data_blocks = {scena_batch, scena_batch.world}
        savePreviewAndWorld.previewPath = scena_batch.render.filepath
        savePreviewAndWorld.blendPath = os.path.join(GlobalPathHdri.HdriUser, sceneSwitch.correctCat,
                                                     nomeMondo + ".blend")
        bpy.data.libraries.write(savePreviewAndWorld.blendPath, data_blocks, compress=True, fake_user=True)

        try:
            for i in imageToPack:
                i.unpack(method='USE_ORIGINAL')
        except:
            pass

    ricaricaPreview(self)
    if type_save == 'PANORAMA':
        panoramaScene.contesto['window'].scene = sceneSwitch.scenaUtente

    elif type_save == 'BATCH':

        # Attenzione

        context.window.scene = sceneSwitch.scenaBatch

    else:
        context.window.scene = sceneSwitch.scenaUtente

    try:

        ctx['window'].scene.hdri_prop_scn.def_to_user_lib = 'USER'
        ctx['window'].scene.hdri_prop_scn.up_category = sceneSwitch.correctCat
        if type_save != 'REDRAW':
            bpy.data.window_managers["WinMan"].hdri_category = scnProp.world_save_name
    except:
        pass


def removeScene():
    for s in bpy.data.scenes:
        if s.hdri_prop_scn.scene_id_name == 'batch_scene':
            bpy.data.scenes.remove(s)
    return None


#############Funzione da controllare bene!!!!!!!!!!!!!!!!!!!

def controllaNome(savelib, saveNameCheck, type_save):
    """Check if exist"""

    if type_save != 'BATCH':
        scnProp = bpy.context.scene.hdri_prop_scn
    else:
        scnProp = sceneSwitch.scenaBatch.hdri_prop_scn

    if bpy.context.scene.hdri_prop_scn.save_type != 'BATCH':
        if saveNameCheck == '' or saveNameCheck == 'Empty':
            def draw(self, context):
                if saveNameCheck == '':
                    self.layout.label(text="Attention, Empty name!")
                else:
                    self.layout.label(text="Attention, {} is not a valid name!".format(saveNameCheck))

            bpy.context.window_manager.popup_menu(draw, title="Invalid Name!")

            return None

    ##Qua invece mi sembra intelligente che se esiste il nome nella lista calderone
    ##Venga aggiunto un numero tipo _001 a crescere , poichè il batch save ne può giovare
    switchDir = scnProp.up_category if scnProp.def_to_user_lib == 'USER' else scnProp.personal_category
    for file in os.listdir(os.path.join(savelib, switchDir)):
        if not any(m in file for m in mac_bad_extension):
            if file.endswith('.blend'):

                if saveNameCheck.casefold() == file[:-6].casefold():
                    scnProp.world_save_name = saveNameCheck + '_001'

                elif (saveNameCheck + '_').casefold() in file.casefold():
                    if file[:-6][-3:].isnumeric():
                        if file[-10] == '_':
                            numero = int(file[:-6][-3:])
                            numero = numero + 1
                            scnProp.world_save_name = saveNameCheck + '_' + str(numero).zfill(3)

    return not None


"""
def updateTheSizeValue(self,context):
    
    scn = bpy.context.scene         
    
    if not scn.world:
        return{'FINISHED'}
    if scn.world.hdri_prop_world.world_id_base_name == '':
        return{'FINISHED'}
    if scn.world.hdri_prop_world.world_user is True:
        return{'FINISHED'}
        
    try:        
        bpy.ops.hdrimaker.current()
        bpy.ops.hdrimaker.add()
    except:
        pass"""


def purgeOldImage():
    for wrl in bpy.data.worlds:
        if not wrl.users:
            if wrl.hdri_prop_world.world_hdri_maker is True:
                bpy.data.worlds.remove(wrl)

    for mat in bpy.data.materials:
        if not mat.users:
            if mat.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                bpy.data.materials.remove(mat)

    for img in bpy.data.images:
        if not img.users:
            if img.hdri_prop_image.image_tag:
                bpy.data.images.remove(img)
            elif img.hdri_prop_image.image_tag_normal:
                bpy.data.images.remove(img)
            elif img.hdri_prop_image.image_tag_displace:
                bpy.data.images.remove(img)


class HDRIMAKER_OT_AddCategory(bpy.types.Operator):
    """Add New category to save your background"""

    bl_idname = "hdrimaker.addcategory"
    bl_label = "Add category"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        csp = bpy.context.scene.hdri_prop_scn
        regex = re.compile('[@!#$%^&*()<>?/\|}{~:]')
        if (regex.search(csp.add_category) is not None):
            stopErrorCharacter(self, context)
            return {'FINISHED'}

        savelib = GlobalPathHdri.HdriUser
        dirName = os.path.join(savelib, csp.add_category)

        if csp.add_category == '' or 'Empty Collection...' in csp.add_category:
            def draw(self, context):
                self.layout.label(text="Attention, enter a valid name!")

            bpy.context.window_manager.popup_menu(draw, title="Name error")
            return {'FINISHED'}

        # controllo maiuscole minuscole se c'è la categoria
        for file in os.listdir(savelib):
            if not any(m in file for m in mac_bad_extension):
                if file.casefold() == csp.add_category.casefold():
                    if not os.path.isfile(file):
                        csp.def_to_user_lib = 'USER'
                        csp.up_category = file

                        def draw(self, context):
                            self.layout.label(text="Attention, this category already exists, try with another name")

                        bpy.context.window_manager.popup_menu(draw, title="Name error")
                        return {'FINISHED'}

        if not os.path.exists(dirName):
            os.mkdir(dirName)

        csp.def_to_user_lib = 'USER'
        csp.up_category = csp.add_category
        csp.add_category = ''

        return {'FINISHED'}


def stopErrorCharacter(self, context):
    def draw(self, context):
        layout = self.layout
        layout.label(text="Attention special characters not allowed within the name")

    bpy.context.window_manager.popup_menu(draw, title="Name error:")


class HDRIMAKER_OT_RemoveCategory(bpy.types.Operator):
    """Remove active category and materials WARNING! All background contained in this category will be deleted, please consider if it is what you really want!"""

    bl_idname = "hdrimaker.removecategory"
    bl_label = "Remove category?"
    bl_options = {'INTERNAL'}

    options: EnumProperty(default='NO', items=(('YES', "Yes", ""), ('NO', "No", "")))

    def execute(self, context):
        if self.options == 'YES':
            cancellaTutto = True
            deleteCategory_and_or_file(self, context, cancellaTutto)
        return {'FINISHED'}

    def invoke(self, context, event):
        self.options = 'NO'
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        row = self.layout
        row.label(text='Do you really want to remove this item from your category?')
        row.label(text="Note : if you choose 'Yes' the operation cannot be Undo")
        row.label(text='')
        row.prop(self, "options", text="Are you sure?", expand=True)
        row.label(text="After your choice, press 'Ok' to confirm, or Esc, to cancel.")


class HDRIMAKER_OT_RemoveBackground(bpy.types.Operator):
    """Remove active saved background! Single background contained in this category will be deleted"""

    bl_idname = "hdrimaker.removebackground"
    bl_label = "Delete single background?"
    bl_options = {'INTERNAL'}

    options: EnumProperty(default='NO', items=(('YES', "Yes", ""), ('NO', "No", "")))

    def execute(self, context):
        if self.options == 'YES':
            cancellaTutto = False
            deleteCategory_and_or_file(self, context, cancellaTutto)
        return {'FINISHED'}

    def invoke(self, context, event):
        self.options = 'NO'
        return context.window_manager.invoke_props_dialog(self, width=500)

    def draw(self, context):
        row = self.layout
        row.label(text='Do you really want to delete this background the single category?')
        row.label(text="Note : if you choose 'Yes' the operation cannot be Undo")
        row.prop(self, "options", text="Are you sure?", expand=True)
        row.label(text="After your choice, press 'Ok' to confirm, or Esc, to cancel.")


def deleteCategory_and_or_file(self, context, deleteCategory):
    set = bpy.context.scene.hdri_prop_scn
    savelib = GlobalPathHdri.HdriUser
    if set.def_to_user_lib == 'DEFAULT':
        cartella = os.path.join(savelib, set.personal_category)
    if set.def_to_user_lib == 'USER':
        cartella = os.path.join(savelib, set.up_category)
    if savelib:
        if not set.up_category or not set.personal_category:
            update_first_catView(self, context)
            update_first_cat(self, context)
            return {'FINISHED'}
        if set.up_category == 'Empty Collection...':
            return {'FINISHED'}
        if set.personal_category == 'Empty Collection...':
            return {'FINISHED'}

        ##qua se l'operatore scelto è cancella categoria:
        if deleteCategory:

            # cancella la cartella categoria:
            shutil.rmtree(cartella)

            update_first_catView(self, context)

            def draw(self, context):
                layout = self.layout
                layout.label(text="Category '{}' correctly removed".format(os.path.basename(cartella)))

            bpy.context.window_manager.popup_menu(draw, title="Result info:", icon='INFO')

        ##qua cancella solo il singolo elemento Preview + File Calderone
        else:
            ###Ricerca e cancellazione preview nella cartella della categoria
            immagineDaEliminare = bpy.data.window_managers["WinMan"].hdri_category
            percorsoPreview = savelib + set.up_category
            for file in os.listdir(percorsoPreview):
                if not any(m in file for m in mac_bad_extension):
                    if file.endswith(".png"):
                        if file[:-4] == immagineDaEliminare:
                            os.remove(os.path.join(percorsoPreview, file))

            for file in os.listdir(percorsoPreview):
                if not file.startswith("."):
                    destinazione = set.up_category if set.def_to_user_lib == 'DEFAULT' else set.personal_category
                    if file.endswith(".blend"):
                        if file[:-6] == immagineDaEliminare:
                            os.remove(os.path.join(savelib, destinazione, file))

            def draw(self, context):

                layout = self.layout
                layout.label(text="Background '{}' correctly removed".format(immagineDaEliminare))

            bpy.context.window_manager.popup_menu(draw, title="Result info:", icon='INFO')

        if set.def_to_user_lib != 'DEFAULT':
            update_first_cat(self, context)

        ricaricaPreview(self)


def ricaricaPreview(self):
    bpy.utils.previews.remove(hdri_preview_collection["HDRiCol"])
    CollezioneHDRi = bpy.utils.previews.new()
    CollezioneHDRi.hdri_category = ()
    CollezioneHDRi.hdri_category_dir = ""
    hdri_preview_collection["HDRiCol"] = CollezioneHDRi


class HDRIMAKER_OT_ObjectImporter(bpy.types.Operator):
    """Import 360 camera location"""

    bl_idname = "hdrimaker.cameraloc"
    bl_label = "Add camera sphere"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'HDRi_Maker_Cam360.blend')

        with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if 'HDRi_Maker_Cam360' in name]

        for o in data_to.objects:
            camSphere = o.copy()
            context.scene.collection.objects.link(camSphere)

        camSphere.location = context.scene.cursor.location
        camSphere.hdri_prop_obj.object_id_name = 'CamSphere'
        for o in context.scene.objects:
            o.select_set(state=False)
        context.view_layer.objects.active = camSphere
        camSphere.select_set(state=True)
        camSphere.hide_render = True

        return {'FINISHED'}


class HDRIMAKER_OT_FindCamera(bpy.types.Operator):
    """Find Camera"""

    bl_idname = "hdrimaker.findcam"
    bl_label = "Find camera sphere"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        camSphere = None
        for o in context.scene.objects:
            if o.hdri_prop_obj.object_id_name == 'CamSphere':
                camSphere = o

        if camSphere is None:
            def draw(self, context):
                layout = self.layout
                layout.label(text="No camera 360 in this scene")
                layout.label(text="Add 360 cam and try again")

            bpy.context.window_manager.popup_menu(draw, title="Camera not found")
            return {'FINISHED'}

        x, y, z = camSphere.location

        for space in [area.spaces[0] for area in bpy.context.window.screen.areas if area.type == 'VIEW_3D']:

            space.region_3d.view_perspective = 'PERSP'
            space.region_3d.view_rotation = (0.7071067094802856, 0.7071068286895752, 0.0, 0.0)
            space.region_3d.view_location = (x, y, z)
            space.region_3d.view_distance = 5.73

            if space.region_3d.view_perspective == 'CAMERA':
                space.region_3d.view_perspective = 'PERSP'
                bpy.ops.view3d.view_camera()

        return {'FINISHED'}


class HDRIMAKER_OT_ResnapCamera(bpy.types.Operator):
    """Put camera on 3D Cursor"""

    bl_idname = "hdrimaker.putcamera"
    bl_label = "Redraw"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        for o in context.scene.objects:
            if o.hdri_prop_obj.object_id_name == 'CamSphere':
                o.location = context.scene.cursor.location

        return {'FINISHED'}


class HDRIMAKER_OT_Redraw(bpy.types.Operator):
    """Redraw contextual preview"""

    bl_idname = "hdrimaker.redraw"
    bl_label = "Redraw"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        ctx = context.copy()
        scnProp = ctx['scene'].hdri_prop_scn
        cat = scnProp.up_category

        preview = bpy.data.window_managers["WinMan"].hdri_category

        if preview == 'Empty' or preview == '':
            return {'FINISHED'}

        def draw(self, context):

            layout = self.layout
            layout.label(text="The preview is about to be drawn,")
            layout.label(text="the time depends on the size of the background pixels and the speed of the PC in use")

        bpy.context.window_manager.popup_menu(draw, title="Please Wait")

        context.window_manager.update_tag()

        sceneSwitch(self, context, 'REDRAW', ctx)
        appendWorld(self, context, scnProp, cat, preview, 'REDRAW')
        savePreviewAndWorld(self, context, 'REDRAW', ctx, preview)

        for s in bpy.data.scenes:
            if s.hdri_prop_scn.scene_id_name == 'batch_scene':
                bpy.data.scenes.remove(s)

        bpy.data.window_managers["WinMan"].hdri_category = preview
        purgeOldImage()

        return {'FINISHED'}


def write_some_data(context, filepath, image):
    old_filepath = image.filepath_raw

    # deve mantenere il filepath_raw , altrimenti l'immagine nel progetto verrà
    # linkata a dove viene salvata

    image.filepath_raw = filepath

    if image.name[-4] == '.':
        if image.name[-3:].isnumeric():
            image.name = image.name[:-4]

            image.file_format = image.name[-3:].upper() if image.name[-3:].upper() != 'EXR' else 'OPEN_EXR'

        else:
            image.file_format = image.name[-3:].upper() if image.name[-3:].upper() != 'EXR' else 'OPEN_EXR'
    else:
        image.file_format = image.name[-4:].upper()

    image.save()

    image.filepath_raw = old_filepath

    return {'FINISHED'}


class HDRIMAKER_OT_ExportHdr(Operator, ExportHelper):
    """Note: the image file exporter only works if the image has been assigned to the background, via HDRi Maker"""
    bl_idname = "hdrimaker.exporthdr"
    bl_label = "Export"
    bl_options = {'INTERNAL'}

    filename_ext = ".hdr"
    filter_glob: StringProperty(
        default="*.hdr;*.png;*.hdr;*.jpg;*.jpeg;*.bmp;*.exr;",
        options={'HIDDEN'},
        maxlen=255,
    )

    @classmethod
    def poll(self, context):
        immage = None
        if context.scene.world:
            for n in context.scene.world.node_tree.nodes:
                if n.type == 'TEX_ENVIRONMENT':
                    if n.image:
                        if n.image.hdri_prop_image.image_tag:
                            for image in bpy.data.images:
                                if image == n.image:
                                    immage = image
        if immage is not None:
            return True

    def execute(self, context):
        immage = None
        if context.scene.world:
            for n in context.scene.world.node_tree.nodes:
                if n.type == 'TEX_ENVIRONMENT':
                    if n.image.hdri_prop_image.image_tag:
                        for image in bpy.data.images:
                            if image == n.image:
                                immage = image

        if immage is not None:
            self.filename_ext = ".hdr"
            return write_some_data(context, self.filepath, immage)

        return {'FINISHED'}


class HDRIMAKER_OT_RenameCurrentCat(bpy.types.Operator):
    """Rename the current category"""

    bl_idname = "hdrimaker.renamecat"
    bl_label = "Rename cat"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        csp = context.scene.hdri_prop_scn

        if csp.rename_category == '':
            return {'FINISHED'}
        if csp.up_category == 'Empty Collection...':
            return {'FINISHED'}

        regex = re.compile('[@!#$%^&*()<>?/\|}{~:]')
        if (regex.search(csp.rename_category) is not None):
            stopErrorCharacter(self, context)
            return {'FINISHED'}

        input = os.path.join(GlobalPathHdri.HdriUser, csp.up_category)
        output = os.path.join(GlobalPathHdri.HdriUser, csp.rename_category)

        if os.path.isdir(output):
            def draw(self, context):
                layout = self.layout
                layout.label(
                    text="Attention, this name is already present in the library! Try changing the name or replacing the existing category name.",
                    icon='MATERIAL')

                csp.up_category = csp.rename_category

            bpy.context.window_manager.popup_menu(draw, title="Name error:", icon='ERROR')
            return {'FINISHED'}

        ricaricaPreview(self)
        os.rename(input, output)
        csp.up_category = csp.rename_category
        csp.rename_category = ''

        return {'FINISHED'}


class HDRIMAKER_OT_RenameCurrentMat(bpy.types.Operator):
    """Rename current material"""

    bl_idname = "hdrimaker.renamemat"
    bl_label = "Rename current material"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        csp = context.scene.hdri_prop_scn
        if csp.renamed_material == '':
            return {'FINISHED'}
        regex = re.compile('[@!#$%^&*()<>?/\|}{~:]')
        if (regex.search(csp.renamed_material) is not None):
            stopErrorCharacter(self, context)
            return {'FINISHED'}

        directory = os.path.join(GlobalPathHdri.HdriUser, csp.up_category)
        current_mat = bpy.data.window_managers["WinMan"].hdri_category

        if current_mat == 'Empty...':
            return {'FINISHED'}
        if csp.up_category == 'Empty Collection...':
            return {'FINISHED'}

        old_icon = os.path.join(directory, current_mat + ".png")
        new_icon = os.path.join(directory, csp.renamed_material + ".png")
        old_blend = os.path.join(directory, current_mat + ".blend")
        new_blend = os.path.join(directory, csp.renamed_material + ".blend")
        os.rename(old_icon, new_icon)
        os.rename(old_blend, new_blend)
        ricaricaPreview(self)
        bpy.data.window_managers["WinMan"].hdri_category = csp.renamed_material
        csp.renamed_material = ''

        return {'FINISHED'}


class HDRIMAKER_OT_FileToCat(bpy.types.Operator):
    """Transfer the selected material from the left to the right category"""

    bl_idname = "hdrimaker.tocat"
    bl_label = "Drop background"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        csp = context.scene.hdri_prop_scn

        current_mat = bpy.data.window_managers["WinMan"].hdri_category
        if current_mat == '' or current_mat == 'Empty':
            return {'FINISHED'}

        try:

            move_from = os.path.join(GlobalPathHdri.HdriUser, csp.up_category)
            move_to = os.path.join(GlobalPathHdri.HdriUser, csp.category_destination)

            shutil.move(os.path.join(move_from, current_mat + '.png'), os.path.join(move_to, current_mat + '.png'))
            shutil.move(os.path.join(move_from, current_mat + '.blend'), os.path.join(move_to, current_mat + '.blend'))

        except:
            pass
        ricaricaPreview(self)
        update_first_icon(self, context)
        return {'FINISHED'}


def catcherMaterialRemoveSlot(self, context, plane, idName):
    count = -1
    for s in plane.material_slots:
        count = count + 1
        plane.active_material_index = count
        if s.material:
            if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                bpy.ops.object.material_slot_remove({'object': plane})
                if plane.hdri_prop_obj.object_id_name == 'SHADOW_CATCHER':
                    plane.hdri_prop_obj.object_id_name = idName


def cycles_shadow_catcher(scn):
    plane = None
    findChildSchatcher = None
    for o in bpy.data.objects:
        if o.hdri_prop_obj.object_id_name == 'SHADOW_CATCHER':
            objProp = o.hdri_prop_obj
            plane = o

            for child in o.children:
                if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
                    if scn.render.engine == 'CYCLES':

                        if hasattr(child, 'is_shadow_catcher'):
                            child.is_shadow_catcher = True
                        else:
                            child.cycles.is_shadow_catcher = True
                        child.update_tag()
                        findChildSchatcher = True

                    elif scn.render.engine == 'BLENDER_EEVEE':
                        bpy.data.objects.remove(child)

            for child in o.children:
                if scn.render.engine == 'CYCLES':
                    if child.hdri_prop_obj.object_id_name == 'LIGHT_PROBE_PLANE':
                        bpy.data.objects.remove(child)

    if findChildSchatcher is None:
        if scn.render.engine == 'CYCLES':
            if plane is not None:
                data = plane.data.copy()
                cycles_sc_plane = bpy.data.objects.new(plane.name + '_Cycles', data)
                if hasattr(cycles_sc_plane, 'cycles_visibility'):
                    # Solo per le versioni precedenti alla 3.0
                    cycles_sc_plane.cycles_visibility.glossy = False
                elif hasattr(cycles_sc_plane, 'visible_glossy'):
                    # Solo pre blender 3.0 in su
                    cycles_sc_plane.visible_glossy = False

                cycles_sc_plane.matrix_world = plane.matrix_world
                cycles_sc_plane.hdri_prop_obj.object_id_name = 'CYCLES_SHADOW_CATCHER'
                cycles_sc_plane.parent = plane
                cycles_sc_plane.matrix_parent_inverse = plane.matrix_world.inverted()
                cycles_sc_plane.hide_select = True
                cycles_sc_plane.scale = plane.scale
                cycles_sc_plane.location.z = cycles_sc_plane.location.z - 0.01

                if hasattr(cycles_sc_plane, 'is_shadow_catcher'): # Blender 2.93/3.0
                    cycles_sc_plane.is_shadow_catcher = True
                else:
                    cycles_sc_plane.cycles.is_shadow_catcher = True

                cycles_sc_plane.update_tag()
                scn.collection.objects.link(cycles_sc_plane)

                cycles_sc_plane.active_material_index = 0
                for i in range(len(cycles_sc_plane.material_slots)):
                    bpy.ops.object.material_slot_remove({'object': cycles_sc_plane})

                trovaModifier = plane.modifiers.get('HDRI_MAKER_DISPLACE')

                if trovaModifier is not None:
                    displace_add(cycles_sc_plane, objProp)
                    update_displace_value_ops(cycles_sc_plane, objProp)

    if plane is not None:
        probe = False
        if scn.render.engine == 'BLENDER_EEVEE':
            for child in plane.children:
                if child.hdri_prop_obj.object_id_name == 'LIGHT_PROBE_PLANE':
                    probe = True

            if probe is False:
                add_probe_funct(plane)


def add_probe_funct(plane):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.lightprobe_add(type='PLANAR', enter_editmode=False, align='WORLD')
    planar = bpy.context.active_object
    ##Matrix world è la miglior soluzione perchè bypassa il problema di posizione se l'oggetto è figlio
    planar.matrix_world = plane.matrix_world
    planar.name = 'LIGHT_PROBE_PLANE'
    planar.hdri_prop_obj.object_id_name = 'LIGHT_PROBE_PLANE'
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = plane
    plane.select_set(state=True)
    planar.parent = plane
    planar.matrix_parent_inverse = plane.matrix_world.inverted()
    planar.hide_select = True
    planar.scale = plane.scale


class HDRIMAKER_OT_AddShadowCatcher(bpy.types.Operator):
    """Add Shadow Catcher"""

    bl_idname = "hdrimaker.shadowcatcher"
    bl_label = "Add shadow catcher"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        scn = context.scene
        scn.eevee.use_ssr = True
        scn.eevee.use_ssr_refraction = True
        scn.eevee.use_gtao = True

        plane = bpy.context.object

        if plane.type != 'MESH':
            def draw(self, context):
                layout = self.layout
                layout.label(text="Only mesh objects support the shadow catcher")
                layout.label(text="Add a plan to create the shadow catcher")

            bpy.context.window_manager.popup_menu(draw, title="Ineligible object")
            return {'FINISHED'}

        zLocation = []
        for vertici in plane.data.vertices:
            zLocation.append(vertici.co[2])

        result = all(elem == zLocation[0] for elem in zLocation)

        if result:
            objProp = plane.hdri_prop_obj
            objProp.object_id_name = 'SHADOW_CATCHER'
            cycles_shadow_catcher(scn)

            bpy.ops.hdrimaker.addsun()

            if hasattr(plane, 'cycles_visibility'):  # Blender 2.93/3.0
                # Solo per le versioni precedenti alla 3.0
                plane.cycles_visibility.glossy = False
            elif hasattr(plane, 'visible_glossy'):
                # Solo pre blender 3.0 in su
                plane.visible_glossy = False

            catcherMaterialRemoveSlot(self, context, plane, 'SHADOW_CATCHER')

            percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'Shadow_catcher.blend')

            with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
                data_to.materials = [name for name in data_from.materials if objProp.shadow_catcher_type in name]

            for m in data_to.materials:
                plane.active_material = m
                plane.active_material.use_backface_culling = True
                plane.active_material.use_screen_refraction = True
                plane.active_material.hdri_prop_mat.mat_id_name = 'SHADOW_CATCHER'

            reflect_probe = False
            for child in plane.children:
                if child.hdri_prop_obj.object_id_name == 'LIGHT_PROBE_PLANE':
                    reflect_probe = True

            if reflect_probe is False:
                if scn.render.engine == 'BLENDER_EEVEE':
                    add_probe_funct(plane)

            if objProp.shadow_catcher_type == 'WATER_CATCHER':
                ###Aggiunge i driver ai nodi mapping dell'acqua
                objProp.SC_REFLECTION_MIX = 1

                for n in plane.active_material.node_tree.nodes:

                    if n.name == 'SC_WATERMAP_1':
                        fcurve = n.inputs[1].driver_add("default_value", 0)
                        fcurve.driver.expression = 'water_drive_hdrimaker(self)*(var/100)'
                        fcurve.driver.use_self = True
                        var = fcurve.driver.variables.new()
                        var.targets[0].id_type = 'OBJECT'
                        var.targets[0].id = bpy.context.object  ####METTI IL MATERIALE ATTIVO
                        var.targets[0].data_path = "hdri_prop_obj.water_vel"
                        var.name = "var"
                    if n.name == 'SC_WATERMAP_2':
                        fcurve = n.inputs[1].driver_add("default_value", 1)
                        fcurve.driver.expression = 'water_drive_hdrimaker(self)*(var/100)'
                        fcurve.driver.use_self = True
                        var = fcurve.driver.variables.new()
                        var.targets[0].id_type = 'OBJECT'
                        var.targets[0].id = bpy.context.object  ####METTI IL MATERIALE ATTIVO
                        var.targets[0].data_path = "hdri_prop_obj.water_vel"
                        var.name = "var"

            update_shadow_catcher(self, context)
            updateNormalMap(self, context)



        else:
            def draw(self, context):

                layout = self.layout
                layout.label(text="Warning this object is not suitable for the shadow catcher")
                layout.label(text="The object must be a plane, add a plane object and try again")

            bpy.context.window_manager.popup_menu(draw, title="Ineligible object")
            return {'FINISHED'}

        return {'FINISHED'}


def update_shadow_catcher(self, context):
    catcher_plane = context.object
    objProp = catcher_plane.hdri_prop_obj

    for s in catcher_plane.material_slots:
        if s.material:
            if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                for n in s.material.node_tree.nodes:
                    if n.name == 'SC_SHADOW_RAMP':
                        nodoRamp = n
                        nodoRamp.color_ramp.elements[0].color = (0, 0, 0, 1)
                        nodoRamp.color_ramp.elements[1].color = (1, 1, 1, 1)

                        if objProp.SC_SHADOW_RAMP_Range >= 0.5:
                            nodoRamp.color_ramp.elements[1].position = (objProp.SC_SHADOW_RAMP_Range - 0.4)
                        else:
                            for gamma in s.material.node_tree.nodes:
                                if gamma.name == 'SC_GAMMA':
                                    gamma.inputs[1].default_value = 0.5 + objProp.SC_SHADOW_RAMP_Range

                        nodoRamp.color_ramp.elements[0].position = nodoRamp.color_ramp.elements[1].position - (
                                    objProp.SC_SHADOW_RAMP_Fade / 10) - 0.001

                    if n.name == 'SC_DIFFUSE_SHADOW':
                        n.inputs[0].default_value = objProp.SC_SHADOW_COLOR

                    if n.name == 'SC_REFLECTION_MIX':
                        n.inputs[0].default_value = objProp.SC_REFLECTION_MIX / 2
                    if n.name == 'SC_GLOSSY':
                        n.inputs[1].default_value = objProp.SC_REFLECTION_ROUGH / 2

                    if n.name == 'SC_MAPPING_IMAGE':
                        n.inputs[2].default_value[2] = radians(objProp.normal_rotation)

                        n.inputs[3].default_value[0] = objProp.normal_scale
                        n.inputs[3].default_value[1] = objProp.normal_scale
                        n.inputs[3].default_value[2] = objProp.normal_scale

                    if n.name == 'SC_NORMAL_IMAGE':
                        n.inputs[0].default_value = objProp.normal_strength

                    if 'SC_WATER_BUMP' in n.name:
                        n.inputs[0].default_value = objProp.water_bump
                        n.inputs[1].default_value = objProp.water_bump * 2

                    if 'SC_WATER_NOISE_1' in n.name or 'SC_WATER_NOISE_2' in n.name:
                        n.inputs[2].default_value = objProp.wave_size
                        n.inputs[3].default_value = objProp.wave_detail

                    if 'SC_WAVE_MIX' in n.name:
                        n.inputs[0].default_value = 0.5 if objProp.water_type == 'STATIC' else 0.8

                    if 'SC_WATERMAP_1' in n.name:
                        n.inputs[2].default_value[2] = radians(45 + objProp.water_direct)

                    if 'SC_WATERMAP_2' in n.name:
                        n.inputs[2].default_value[2] = radians(objProp.water_direct)

                    if 'SC_GAMMA_RAMP' in n.name:
                        n.inputs[1].default_value = objProp.SC_FADE_REFLECTION * 1.5

                    if 'SC_RAMP_X' in n.name:
                        n.color_ramp.elements[0].color = (0, 0, 0, 1)
                        n.color_ramp.elements[1].color = (1, 1, 1, 1)
                        n.color_ramp.elements[2].color = (1, 1, 1, 1)
                        n.color_ramp.elements[3].color = (0, 0, 0, 1)

                        n.color_ramp.elements[0].position = 0
                        n.color_ramp.elements[1].position = 0.1 + objProp.SC_FADE_REFLECTION / 3
                        n.color_ramp.elements[2].position = 0.9 - objProp.SC_FADE_REFLECTION / 3
                        n.color_ramp.elements[3].position = 1

                    if 'SC_RAMP_Y' in n.name:
                        n.color_ramp.elements[0].color = (0, 0, 0, 1)
                        n.color_ramp.elements[1].color = (1, 1, 1, 1)
                        n.color_ramp.elements[2].color = (1, 1, 1, 1)
                        n.color_ramp.elements[3].color = (0, 0, 0, 1)

                        n.color_ramp.elements[0].position = 0
                        n.color_ramp.elements[1].position = 0.1 + objProp.SC_FADE_REFLECTION / 3
                        n.color_ramp.elements[2].position = 0.9 - objProp.SC_FADE_REFLECTION / 3
                        n.color_ramp.elements[3].position = 1

                    if 'SC_MIX_QUAD_SPHERE' in n.name:
                        n.inputs[0].default_value = int(objProp.SC_GRADIENT_REFLECTION_TYPE)

                    if 'SC_GAMMA_GRADIENT' in n.name:
                        n.inputs[1].default_value = objProp.SC_FADE_REFLECTION + 0.2


def update_shadow_catcher_type(self, context):
    catcher_plane = context.active_object
    for s in catcher_plane.material_slots:
        if s.material:
            if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                bpy.ops.hdrimaker.shadowcatcher()
    purgeOldImage()


class HDRIMAKER_OT_ImportHdr(Operator, ImportHelper):
    """Import an image and create the background at the same time"""
    bl_idname = "hdrimaker.importhdr"
    bl_label = "Import hdr"
    bl_options = {'INTERNAL', 'UNDO'}

    filter_glob: StringProperty(options={'HIDDEN'}, default='*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.hdr;*.exr')

    def execute(self, context):
        immagine = bpy.data.images.load(self.filepath)
        subOperatorSky(self, context, context.scene, 'IMPORT', immagine, 'None')
        load_dome(self, context)
        updatebackground(self, context)

        return {'FINISHED'}


def loadNormalMap(self, context):
    scn = context.scene
    csp = scn.hdri_prop_scn

    normal_dir = os.path.join(GlobalPathHdri.tools_lib, 'Maps', 'Normal_maps')

    dirListing = os.listdir(normal_dir)
    dirListing.sort()
    cat_name = []
    for item in dirListing:
        if not any(m in item for m in mac_bad_extension):
            cat_name.append(item)

    return [(name[:-4], name[:-4], "") for name in cat_name]


def loadDisplaceMap(self, context):
    scn = context.scene
    csp = scn.hdri_prop_scn

    displace_dir = os.path.join(GlobalPathHdri.tools_lib, 'Maps', 'Displace_maps')

    dirListing = os.listdir(displace_dir)
    dirListing.sort()
    cat_name = []
    for item in dirListing:
        if not any(m in item for m in mac_bad_extension):
            cat_name.append(item)

    return [(name[:-4], name[:-4], "") for name in cat_name]


def updateNormalMap(self, context):
    objProp = context.active_object.hdri_prop_obj
    path = os.path.join(GlobalPathHdri.tools_lib, 'Maps', 'Normal_maps', objProp.normal_maps_list + '.jpg')

    for s in context.active_object.material_slots:
        if s.material:
            if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                catcherMat = s.material

    for n in catcherMat.node_tree.nodes:
        if n.name == 'SC_IMAGE_FOR_NORMAL':
            bpy.data.images.remove(n.image)
            purgeOldImage()
            normalImage = bpy.data.images.load(path)
            normalImage.hdri_prop_image.image_tag_normal = True
            n.image = normalImage
            normalImage.colorspace_settings.name = 'Non-Color'


class HDRIMAKER_OT_LightProbeForceDelete(bpy.types.Operator):
    """Remove probe plane"""
    bl_idname = "hdrimaker.lightproberemove"
    bl_label = "Remove probe plane"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        plane = context.object

        for o in context.scene.objects:
            objIdName = o.hdri_prop_obj.object_id_name
            if objIdName in ('LIGHT_PROBE_PLANE', 'CYCLES_SHADOW_CATCHER'):
                if not o.parent:
                    bpy.data.objects.remove(o)
                else:
                    shadowCatcherFind = False

                    if o.parent == plane:
                        for s in o.parent.material_slots:
                            if s.material:
                                if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                                    shadowCatcherFind = True

                        if shadowCatcherFind is False:
                            bpy.data.objects.remove(o)

        return {'FINISHED'}


class HDRIMAKER_OT_RemoveShadowCatcher(bpy.types.Operator):
    """Remove Eevee Shadow Catcher"""
    bl_idname = "hdrimaker.removeshadowcatcher"
    bl_label = "Remove shadow catcher"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        catcherMaterialRemoveSlot(self, context, context.object, '')
        remove_plane_cycles_catcher(context.object)
        bpy.ops.hdrimaker.displaceremove()
        bpy.ops.hdrimaker.lightproberemove()

        return {'FINISHED'}


def remove_plane_cycles_catcher(plane):
    for child in plane.children:
        if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
            bpy.data.objects.remove(child)


class HDRIMAKER_OT_AddSun(bpy.types.Operator):
    """Add controllable sun"""
    bl_idname = "hdrimaker.addsun"
    bl_label = "Add sun"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        plane = context.object
        find_sun = False
        for o in context.scene.objects:
            if o.type == 'LIGHT':
                if o.data.type == 'SUN':
                    sunObj = o
                    find_sun = True

        if find_sun is False:
            sunData = bpy.data.lights.new('HDRI_MAKER_SUN', type='SUN')
            sunData.use_contact_shadow = True
            sunObj = bpy.data.objects.new('HDRI_MAKER_SUN', sunData)
            context.scene.collection.objects.link(sunObj)

        sunObj.hdri_prop_obj.object_id_name = 'HDRI_MAKER_SUN'
        if plane is not None:
            for s in plane.material_slots:
                if s.material:
                    if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                        sunObj.matrix_world.translation = plane.matrix_world.translation
                        sunObj.matrix_world.translation.z = plane.matrix_world.translation.z + 10
        else:
            sunObj.matrix_world.translation = (0, 0, 10)

        sunObj.data.use_contact_shadow = True
        updatebackground(self, context)

        return {'FINISHED'}


class HDRIMAKER_OT_SwitchEngine(bpy.types.Operator):
    """Switch eevee/cycles"""
    bl_idname = "hdrimaker.switchengine"
    bl_label = "Switch Engine"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        if context.scene.render.engine == 'CYCLES':
            context.scene.render.engine = 'BLENDER_EEVEE'
        else:
            context.scene.render.engine = 'CYCLES'

        return {'FINISHED'}


def displace_remove(plane):
    for m in plane.modifiers:

        if 'HDRI_MAKER_DISPLACE' in m.name:
            plane.modifiers.remove(m)

        elif 'HDRI_MAKER_SMOOTH' in m.name:
            plane.modifiers.remove(m)

    for t in bpy.data.textures:
        if t.hdri_prop_texture.texture_id_name == 'HDRI_TEXTURE_DISPLACE':
            if not t.users:
                bpy.data.textures.remove(t)

    purgeOldImage()


def displace_add(plane, objProp):
    for o in bpy.context.scene.objects:
        if o != plane:
            o.select_set(state=False)

    bpy.ops.object.mode_set(mode='OBJECT')

    vertCount = []
    for v in plane.data.vertices:
        v.select = True
        vertCount.append(v)

    if plane.hdri_prop_obj.object_id_name != 'CYCLES_SHADOW_CATCHER':
        if len(vertCount) < 5:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.subdivide()
            bpy.ops.mesh.subdivide()
            bpy.ops.mesh.subdivide()
            bpy.ops.mesh.subdivide()
            bpy.ops.mesh.subdivide()
            bpy.ops.mesh.subdivide()

            bpy.ops.object.mode_set(mode='OBJECT')

    for f in plane.data.polygons:
        f.use_smooth = True

    displace_remove(plane)

    displace = plane.modifiers.new(name="HDRI_MAKER_DISPLACE", type='DISPLACE')
    displace.texture_coords = 'OBJECT'
    displace.uv_layer = 'UVMap'

    corrective_smooth = plane.modifiers.new(name="HDRI_MAKER_SMOOTH", type='CORRECTIVE_SMOOTH')
    corrective_smooth.use_only_smooth = False
    corrective_smooth.use_pin_boundary = False

    self = 'None'
    context = bpy.context

    update_displacement_ops(plane, objProp)
    try:
        context.view_layer.objects.active = obj
    except:
        pass


###Questo è solo per l'aggiornamento della proprietà, poichè non accetta altro self,context
def update_displacement(self, context):
    plane = context.object
    objProp = plane.hdri_prop_obj
    update_displacement_ops(plane, objProp)


def update_displacement_ops(plane, objProp):
    ### Se non c'è displacement questo aggiornamento deve fermarsi ###
    finDisp = False
    for m in plane.modifiers:
        if m.type == 'DISPLACE':
            if m.name == 'HDRI_MAKER_DISPLACE':
                finDisp = True

    if finDisp is False:
        return
    ##################################################################

    textura = None
    for m in plane.modifiers:
        if m.type == 'DISPLACE':
            if m.name == 'HDRI_MAKER_DISPLACE':
                displace = m
                if m.texture:
                    if m.texture.hdri_prop_texture.texture_id_name == 'HDRI_TEXTURE_DISPLACE':
                        textura = m.texture

                else:
                    for txr in bpy.data.textures:
                        if txr.hdri_prop_texture.texture_id_name == 'HDRI_TEXTURE_DISPLACE':
                            displaceList = objProp.displace_maps_list

                            if txr.image.name == displaceList + '.png' or txr.image.name == displaceList + '.jpg':
                                m.texture = txr
                                textura = m.texture

    if textura is None:
        textura = bpy.data.textures.new('HDRI_TEXTURE_DISPLACE', type='IMAGE')
        textura.hdri_prop_texture.texture_id_name = 'HDRI_TEXTURE_DISPLACE'

    displace.texture = textura

    pathJPG = os.path.join(GlobalPathHdri.tools_lib, 'Maps', 'Displace_maps', objProp.displace_maps_list + '.jpg')
    pathPNG = os.path.join(GlobalPathHdri.tools_lib, 'Maps', 'Displace_maps', objProp.displace_maps_list + '.png')

    try:
        textura.image = bpy.data.images.load(pathJPG)
        textura.image.hdri_prop_image.image_tag_displace = True
        textura.name = objProp.displace_maps_list
    except:
        textura.image = bpy.data.images.load(pathPNG)
        textura.image.hdri_prop_image.image_tag_displace = True
        textura.name = objProp.displace_maps_list

    textura.image.colorspace_settings.name = 'Non-Color'
    textura.crop_max_x = -10
    textura.crop_max_y = -10
    textura.extension = 'REPEAT'
    textura.repeat_x = 1
    textura.repeat_y = 1

    if textura.image.name[-3:].isnumeric():
        textura.image.name = textura.image.name[:-4]

    purgeOldImage()


def update_displace_value(self, context):
    plane = bpy.context.object
    objProp = plane.hdri_prop_obj

    update_displace_value_ops(plane, objProp)

    for child in plane.children:
        if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
            update_displace_value_ops(child, objProp)


def update_displace_value_ops(plane, objProp):
    for m in plane.modifiers:
        if m.type == 'DISPLACE':
            if m.name == 'HDRI_MAKER_DISPLACE':
                m.strength = objProp.displace_strength / 10
                m.mid_level = -objProp.displace_midlevel
                m.texture.crop_min_x = objProp.displace_scale - 10
                m.texture.crop_min_y = objProp.displace_scale - 10

        if m.type == 'CORRECTIVE_SMOOTH':
            if m.name == 'HDRI_MAKER_SMOOTH':
                m.iterations = objProp.displace_smooth


def copy_mesh_to_cycles_plane(plane):
    dataPlane = plane.data.copy()

    for child in plane.children:
        if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
            child.data = dataPlane
            child.active_material_index = 0
            for i in range(len(child.material_slots)):
                bpy.ops.object.material_slot_remove({'object': child})


class HDRIMAKER_OT_DisplaceAdd(bpy.types.Operator):
    """Add a displacement"""
    bl_idname = "hdrimaker.displaceadd"
    bl_label = "Add displacement"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        plane = context.object
        objProp = plane.hdri_prop_obj

        displace_add(plane, objProp)
        update_displace_value(self, context)

        copy_mesh_to_cycles_plane(plane)

        for child in plane.children:
            if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
                displace_add(child, objProp)

        context.object.hdri_prop_obj.displace_midlevel = -0.4

        return {'FINISHED'}


class HDRIMAKER_OT_DisplaceRemove(bpy.types.Operator):
    """Remove displacement"""
    bl_idname = "hdrimaker.displaceremove"
    bl_label = "Remove displacement"
    bl_options = {'INTERNAL'}

    def execute(self, context):

        plane = context.object

        displace_remove(plane)
        unSubdivide(plane, 'DISSOLVE')

        for child in plane.children:
            if child.hdri_prop_obj.object_id_name == 'CYCLES_SHADOW_CATCHER':
                displace_remove(child)

        return {'FINISHED'}


def water_drive_hdrimaker(self):
    scn = bpy.context.scene

    vel = scn.frame_current / scn.render.fps
    velocita = scn.frame_current / scn.render.fps

    return velocita


def update_alpha(self, context):
    objProp = context.object.hdri_prop_obj
    for s in context.object.material_slots:
        if s.material:
            if s.material.hdri_prop_mat.mat_id_name == 'SHADOW_CATCHER':
                s.material.blend_method = objProp.alpha_mode


@persistent
def load_handler(self):
    bpy.app.driver_namespace['fog_drivers'] = fog_drivers
    bpy.app.driver_namespace['water_drive_hdrimaker'] = water_drive_hdrimaker


def fog_drivers(self):
    scn = bpy.context.scene

    vel = scn.frame_current / scn.render.fps
    velocita = scn.frame_current / scn.render.fps

    return velocita


class HDRIMAKER_OT_SubdivideMesh(bpy.types.Operator):
    """Subdivide the plane for increase the displacement details"""
    bl_idname = "hdrimaker.suddividi"
    bl_label = "Sub-d"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        plane = context.object
        for o in context.scene.objects:
            if o != plane:
                o.select_set(state=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide()
        bpy.ops.object.mode_set(mode='OBJECT')

        copy_mesh_to_cycles_plane(plane)

        return {'FINISHED'}


def unSubdivide(plane, type):
    for o in bpy.context.scene.objects:
        if o != plane:
            o.select_set(state=False)

    for v in plane.data.vertices:
        v.select = True
    bpy.ops.object.mode_set(mode='EDIT')

    if type == 'DISSOLVE':
        bpy.ops.mesh.dissolve_limited()
    else:
        bpy.ops.mesh.unsubdivide()

    bpy.ops.object.mode_set(mode='OBJECT')

    copy_mesh_to_cycles_plane(plane)


class HDRIMAKER_OT_UnSubdivideMesh(bpy.types.Operator):
    """Un-Subdivide the plane for decrease the displacement details"""
    bl_idname = "hdrimaker.dissuddividi"
    bl_label = "UnS-D"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):

        plane = context.object
        vertList = []
        for v in plane.data.vertices:
            v.select = True
            vertList.append(v)

        if len(vertList) < 10:
            unSubdivide(plane, 'DISSOLVE')

        else:
            unSubdivide(plane, 'NONE')

        return {'FINISHED'}


def update_probe(self, context):
    plane = context.object
    objProp = plane.hdri_prop_obj
    for o in context.scene.objects:
        if o.hdri_prop_obj.object_id_name == 'LIGHT_PROBE_PLANE':
            if o.parent == plane:
                o.data.influence_distance = objProp.reflection_probe_size


def update_scene_pref(self, context):
    scn = context.scene
    scnProp = scn.hdri_prop_scn

    listaOpzioni = scnProp.shadow_detail.split('_')

    scn.eevee.shadow_cube_size = listaOpzioni[0]
    scn.eevee.shadow_cascade_size = listaOpzioni[1]
    scn.eevee.use_shadow_high_bitdepth = strtobool(listaOpzioni[2])
    scn.eevee.use_soft_shadows = strtobool(listaOpzioni[3])


def mem_nod_out(self, context):
    scn = context.scene
    scn.use_nodes = True

    mem_nod_out.nodo_output = None

    mem_nod_out.nodo_zero_out = None
    mem_nod_out.nodo_uno_out = None
    mem_nod_out.nodo_due_out = None

    for n in scn.node_tree.nodes:
        if n.type == 'COMPOSITE':
            for inp in n.inputs:

                if inp.name == 'Image':
                    if inp.is_linked:
                        mem_nod_out.nodo_output = n

                        mem_nod_out.nodo_zero_out = inp.links[0].from_socket
                        scn.node_tree.links.remove(n.inputs[0].links[0])


                elif inp.name == 'Alpha':
                    if inp.is_linked:
                        mem_nod_out.nodo_uno_out = inp.links[0].from_socket
                        scn.node_tree.links.remove(n.inputs[1].links[0])



                elif inp.name == 'Z':
                    if inp.is_linked:
                        mem_nod_out.nodo_due_out = inp.links[0].from_socket
                        scn.node_tree.links.remove(n.inputs[2].links[0])


def create_node(self, context):
    scn = context.scene
    node = scn.node_tree.nodes
    link = scn.node_tree.links

    if mem_nod_out.nodo_output == None:
        composite_out = node.new(type='CompositorNodeComposite')
        create_node.composite_out = composite_out
        composite_out.use_alpha = True
        composite_out.location = (300, 600)
        composite_out.hdri_prop_nodes.node_to_delete = True
    else:
        composite_out = mem_nod_out.nodo_output

    layer_node = node.new(type='CompositorNodeRLayers')
    create_node.layer_node = layer_node
    layer_node.name = 'Hdri Render Layer'
    layer_node.layer = context.window.view_layer.name
    layer_node.scene = scn
    layer_node.location = (-300, 600)
    layer_node.hdri_prop_nodes.node_to_delete = True

    denoise = node.new(type='CompositorNodeDenoise')
    create_node.denoise = denoise
    denoise.name = 'Hdri Denoise'
    denoise.location = (0, 600)
    denoise.use_hdr = True
    denoise.hdri_prop_nodes.node_to_delete = True

    link.new(layer_node.outputs[0], denoise.inputs[0])
    link.new(denoise.outputs[0], composite_out.inputs[0])

    for n in node:
        n.update()
    link.update()

    context.window.view_layer.update()
    context.scene.view_layers.update()


def redo_last_compo_node(self):
    for s in bpy.data.scenes:
        if s.hdri_prop_scn.scene_id_name == 'scena_utente':

            for n in s.node_tree.nodes:
                if n.hdri_prop_nodes.node_to_delete == True:
                    s.node_tree.nodes.remove(n)

            if mem_nod_out.nodo_output == None:
                return

            link = s.node_tree.links
            if mem_nod_out.nodo_zero_out is not None:
                link.new(mem_nod_out.nodo_zero_out, mem_nod_out.nodo_output.inputs[0])
            if mem_nod_out.nodo_uno_out is not None:
                link.new(mem_nod_out.nodo_uno_out, mem_nod_out.nodo_output.inputs[1])
            if mem_nod_out.nodo_due_out is not None:
                link.new(mem_nod_out.nodo_due_out, mem_nod_out.nodo_output.inputs[2])


def update_wire(self, context):
    obj = context.object
    if obj:
        objProp = obj.hdri_prop_obj
        if objProp.show_wireframe:
            obj.show_wire = True
            if context.space_data.overlay.show_overlays is False:
                context.space_data.overlay.show_overlays = True

        else:
            obj.show_wire = False


@persistent
def engine_change_function(scena):
    global contextEngine

    scn = bpy.context.scene

    if contextEngine is None:
        contextEngine = scn.render.engine

    else:
        if scn.render.engine != contextEngine:
            contextEngine = scn.render.engine
            cycles_shadow_catcher(scn)


class HDRIMAKER_OT_AssignMat(bpy.types.Operator):
    """Assign HDRI material"""

    bl_idname = "hdrimaker.assignbackat"
    bl_label = "Assign material"
    bl_options = {'INTERNAL', 'UNDO'}

    options: EnumProperty(items=(('ADD', "Add", ""), ('REMOVE', "Remove", "")))

    def execute(self, context):

        scn = context.scene

        if self.options == 'ADD':

            hdri = None
            for o in scn.objects:
                if o.name == 'HDRi_Maker_Dome':
                    if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
                        for s in o.material_slots:
                            if s.material.hdri_prop_mat.mat_id_name == 'HDRi_Maker_Sky_Dome':
                                for n in s.material.node_tree.nodes:
                                    if n.name == 'HDRI_ENV':
                                        if n.image:
                                            hdri = n.image

            if hdri is not None:

                groundMat = None
                for m in bpy.data.materials:
                    if m.hdri_prop_mat.mat_id_name == 'Hdri_On_Ground':
                        if m.name == 'Hdri_On_Ground':
                            groundMat = m

                if groundMat is None:

                    percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'HDRI_GROUND_MATERIAL.blend')

                    with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
                        data_to.materials = data_from.materials

                    for m in data_to.materials:
                        if m.name == 'Hdri_On_Ground':
                            groundMat = m.copy()


                else:
                    for o in context.selected_objects:
                        if o.type == 'MESH' or o.type == 'CURVE':
                            if o.hdri_prop_obj.object_id_name != 'HDRi_Maker_Dome':
                                found = None
                                for m in o.data.materials:
                                    if m == groundMat:
                                        found = True
                                if found is None:
                                    o.data.materials.append(groundMat)
                                    groundMat.name = 'Hdri_On_Ground'
                                    groundMat.hdri_prop_mat.mat_id_name = 'Hdri_On_Ground'

                for n in groundMat.node_tree.nodes:
                    if n.name == 'HDRI_ENV':
                        n.image = hdri
                    if n.name == 'Texture Coordinate':
                        for o in scn.objects:
                            if o.name == 'HDRi_Maker_Dome':
                                if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
                                    n.object = o

        if self.options == 'REMOVE':

            for o in context.selected_objects:
                if o.type == 'MESH' or o.type == 'CURVE':
                    if o.hdri_prop_obj.object_id_name != 'HDRi_Maker_Dome':
                        count = -1
                        for s in o.material_slots:
                            count = count + 1
                            o.active_material_index = count
                            if s.material:
                                if s.material.hdri_prop_mat.mat_id_name == 'Hdri_On_Ground':
                                    bpy.ops.object.material_slot_remove({'object': o})

        updatebackground(self, context)

        return {'FINISHED'}


class HDRIMAKER_OT_Shrinkwrap(bpy.types.Operator):
    """Assign/remove Shrinkwrap to object(s)"""

    bl_idname = "hdrimaker.shrinkwrap"
    bl_label = "Assign material"
    bl_options = {'INTERNAL', 'UNDO'}

    options: EnumProperty(items=(('ADD', "Add", ""), ('REMOVE', "Remove", "")))

    def execute(self, context):

        objs = context.selected_objects

        if self.options == 'ADD':
            wrap_the_objects(context, objs)
        if self.options == 'REMOVE':
            wrap_remove(context, objs)

        return {'FINISHED'}


def wrap_the_objects(context, objs):
    scn = context.scene
    scnProp = scn.hdri_prop_scn

    dome = None
    vertexGround = None
    for o in scn.objects:
        if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
            dome = o
            for vg in dome.vertex_groups:
                if vg.name == 'Ground':
                    vertexGround = vg

    if dome is not None:

        smooth = None

        # lista modificatori senza riferimento da cancellare
        lost_modifier = []
        for m in dome.modifiers:
            if m.type == 'SHRINKWRAP':
                if m.target is None:
                    lost_modifier.append(m)

            if m.type == 'SMOOTH':
                if m.name == 'HDRI_SMOOTH':
                    smooth = m
                    smooth.vertex_group = vertexGround.name

        if smooth is None:
            smooth = dome.modifiers.new(name='HDRI_SMOOTH', type='SMOOTH')
            smooth.vertex_group = vertexGround.name

        for o in objs:
            if o != dome:
                if o.type == 'MESH':
                    o.hdri_prop_obj.object_id_name = 'Wrap'

                    modExist = None
                    for m in dome.modifiers:
                        if m.type == 'SHRINKWRAP':
                            if m.target == o:
                                modExist = True

                    if modExist is None:

                        shrinkwrap = dome.modifiers.new(name='Sw_on_' + o.name, type='SHRINKWRAP')
                        shrinkwrap.target = o
                        shrinkwrap.wrap_method = 'PROJECT'
                        shrinkwrap.use_negative_direction = True
                        shrinkwrap.use_positive_direction = True
                        shrinkwrap.use_project_z = True

                        if vertexGround is not None:
                            shrinkwrap.vertex_group = vertexGround.name
                            smooth.vertex_group = vertexGround.name
                            smooth.use_x = False
                            smooth.use_y = False
                            smooth.use_z = True

        # rimuove definitivamente i modificatori senza riferimento ad un oggetto

        for m in lost_modifier:
            dome.modifiers.remove(m)

        for m in dome.modifiers:
            c = {}
            c["object"] = c["active_object"] = dome
            # c["selected_objects"] = c["selected_editable_objects"] = dome
            bpy.ops.object.modifier_move_down(c, modifier=smooth.name)


def wrap_remove(context, objs):
    dome = None
    for o in context.scene.objects:
        if o.hdri_prop_obj.object_id_name == 'HDRi_Maker_Dome':
            dome = o

    if dome is not None:

        modifiersToRemove = []

        for o in objs:
            if o.type == 'MESH':
                if o.hdri_prop_obj.object_id_name == 'Wrap':
                    o.hdri_prop_obj.object_id_name = ''

                    for m in dome.modifiers:
                        if m.type == 'SHRINKWRAP':
                            if m.target == o:
                                modifiersToRemove.append(m)

        for m in modifiersToRemove:
            dome.modifiers.remove(m)


def load_fog(self, context):
    scn = context.scene
    scnProp = scn.hdri_prop_scn

    fogBox = None
    fogMat = None

    for o in bpy.data.objects:
        if 'hdri_fog_box' in o.hdri_prop_obj.object_id_name:
            bpy.data.objects.remove(o)

    for mesh in bpy.data.meshes:
        if 'hdri_fog_box' in mesh.name:
            bpy.data.meshes.remove(mesh)

    for m in bpy.data.materials:
        if 'HDRI_MAKER_FOG' in m.hdri_prop_mat.mat_id_name:
            bpy.data.materials.remove(m)

    if scnProp.fog_on_off:
        percorso = os.path.join(GlobalPathHdri.tools_lib, 'Files', 'hdri_fog.blend')
        with bpy.data.libraries.load(percorso, link=False) as (data_from, data_to):
            data_to.objects = [o for o in data_from.objects]

        for o in data_to.objects:
            if o.name == 'hdri_fog_box':

                fogBox = o.copy()
                bpy.data.objects.remove(o)
                fogBox.hdri_prop_obj.object_id_name = 'hdri_fog_box'
                context.scene.collection.objects.link(fogBox)
                fogBox.name = 'hdri_fog_box'
                fogBox.location = (0, 0, 0)

                for s in fogBox.material_slots:
                    if 'HDRI_MAKER_FOG' in s.material.name:
                        s.material.hdri_prop_mat.mat_id_name = 'HDRI_MAKER_FOG'
                        s.material.name = 'HDRI_MAKER_FOG'
                        s.material.diffuse_color = (1, 1, 1, 0)

                        for n in s.material.node_tree.nodes:
                            if n.name == 'fog_mapping':
                                fcurve = n.inputs[1].driver_add("default_value", 1)
                                fcurve.driver.expression = 'fog_drivers(self)*(var/10)'
                                fcurve.driver.use_self = True
                                var = fcurve.driver.variables.new()
                                var.targets[0].id_type = 'SCENE'
                                var.targets[0].id = scn
                                var.targets[0].data_path = "hdri_prop_scn.fog_wind"
                                var.name = "var"

        fogBox.hide_render = False if scnProp.fog_on_off else True
        fogBox.hide_viewport = False if scnProp.fog_on_off else True
        fogBox.hide_set(state=False if scnProp.fog_on_off else True)

        fogBox.location = (0, 0, 0)
        fogBox.hide_select = True
        fogBox.lock_location[:] = (True, True, True)
        fogBox.lock_rotation[:] = (True, True, True)
        fogBox.lock_scale[:] = (True, True, True)

        updatebackground(self, context)


class HDRIMAKER_OT_CheckForUpdate(bpy.types.Operator):
    """Check for update"""

    bl_idname = "hdrimaker.checkupdate"
    bl_label = "Update check"
    bl_options = {'INTERNAL'}

    new_version = False
    lista_versioni = None
    release_info = None
    url = 'https://blendermarket.com/products/hdri-maker'

    def execute(self, context):

        webbrowser.open(self.url)

        return {'FINISHED'}

    def invoke(self, context, event):
        class HTMLFilter(HTMLParser):
            text = ""

            def handle_data(self, data):
                self.text += data

        self.lista_versioni = []

        def request_error(error):
            def draw(self, context):
                self.layout.label(text=error)

            bpy.context.window_manager.popup_menu(draw, title="Web problems:", icon='INFO')

        try:

            r = requests.get(self.url, timeout=10, headers={'referer': 'hdri_maker_2_0_7'})
            r.raise_for_status()

            text = r.text

            # Qui recupera i blocchi informazioni di aggiornamento tra parentesi
            search_results = re.finditer(r'\[.*?\]', r.text)
            self.lista_versioni = []
            self.release_info = []
            for item in search_results:
                ###Qui trova se c'è l'update version
                if 'Update_version_' in item.group(0):
                    # Splitta in singole parole con il metodo split
                    for ver in item.group(0).split():
                        if 'Update_version_' in ver:

                            ver = ver.replace('<', ' ').replace('>', ' ')
                            ver = ver.replace('.', ' ').replace('_', ' ')
                            ver = tuple([int(s) for s in ver.split() if s.isdigit()])
                            # text è la versione online, questo recupera piu versioni se le versioni sono molto avanzate nel tempo
                            if ver > bl_info['version']:
                                self.new_version = True
                                f = HTMLFilter()
                                f.feed(item.group(0))
                                testo_corretto = f.text
                                ##Cerca se c'è un url nuovo nelle info dell'aggiornamento
                                cerca_url = re.findall(
                                    'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
                                    testo_corretto)
                                # Siccome restituisce una lista di url, qui sarà semre e solo 1 url
                                if len(cerca_url) > 0:
                                    self.url = cerca_url[0]

                                self.lista_versioni.append(ver)
                                self.release_info.append(
                                    testo_corretto[+1:][:-1])  # toglie le prime 3 parentesi e l'ultima



        except requests.exceptions.RequestException as err:
            request_error("OOps: Something Else" + str(err))
            return {'FINISHED'}
        except requests.exceptions.HTTPError as errh:
            request_error("Http Error:" + errh)
            return {'FINISHED'}
        except requests.exceptions.ConnectionError as errc:
            request_error("Error Connecting:" + str(errc))
            return {'FINISHED'}
        except requests.exceptions.Timeout as errt:
            request_error("Timeout Error:" + str(errt))
            return {'FINISHED'}

        return context.window_manager.invoke_props_dialog(self, width=720)

    def draw(self, context):

        layout = self.layout
        col = layout.column(align=True)

        if self.new_version:

            col.label(text="This product has had " + str(
                len(self.lista_versioni)) + " updates! You are using an old version of " + str(
                len(self.lista_versioni)) + " updates")
            col.label(text="You missed these updates:")
            col.label(text="")

            for release in self.release_info:
                for acapo in release.split('#'):
                    wrapper = textwrap.TextWrapper(width=130)

                    word_list = wrapper.wrap(text=acapo)

                    # Print each line.
                    for element in word_list:
                        col.label(text=element)

            col.label(text="")
            col.label(text="Your version is: " + str(bl_info['version']))
            col.label(text="You need this update: " + str(self.lista_versioni[0]))
            col.label(text="")
            col.label(text="Press Ok to check the ")

        else:
            col.label(text="Your version is updated")
            col.label(text="The version you are using is the newest version available")
            col.label(text="")
            col.label(text="Your version is: " + str(bl_info['version']))
            col.label(text="")
            col.label(text="Press Ok to check, or 'ESC' to go back")


def update_fog_details(self, context):
    scn = context.scene
    scnProp = scn.hdri_prop_scn

    listaOpzioni = scnProp.fog_detail.split('_')
    scn.eevee.volumetric_tile_size = listaOpzioni[0]
    scn.eevee.volumetric_samples = int(listaOpzioni[1])
    scn.cycles.volume_max_steps = int(listaOpzioni[2])
    scn.eevee.use_volumetric_lights = True
    scn.eevee.use_volumetric_shadows = True


k_size_refer = {}
hdri_preview_collection = {}
preview_icon_blu = {}

mac_bad_extension = [".DS_Store", "._"]


class HdriPropertyScene(bpy.types.PropertyGroup):
    denoise_type: EnumProperty(default='NONE', items=(
    ('NONE', "No denoise", "No denoise will be applied to the render"), ('CYCLES', "Cycles", "Classic Cycles denoise"),
    ('COMPOSITE', "Compositor",
     "Automatically create a denoise node, useful if you want to keep the rendering sample low")))
    k_size_available: EnumProperty(items=enum_k_size)
    def_to_user_lib: EnumProperty(default='DEFAULT', items=(('DEFAULT', "Default", ""), ('USER', "User", "")),
                                  description='Switch from the default library to the library where you can save your HDRs',
                                  update=update_first_cat)

    rot_world: FloatProperty(description="Rotation Z of worls hdri", default=0, update=updatebackground)
    rot_world_y: FloatProperty(description="Rotation Y of worls hdri", default=0, update=updatebackground)
    rot_world_x: FloatProperty(description="Rotation X of worls hdri", default=0, update=updatebackground)
    sun_color: FloatVectorProperty(name="", subtype='COLOR', default=(1, 1, 1), min=0.0, max=1.0, size=3,
                                   description='Sun Color', update=updatebackground)
    sun_light: FloatProperty(description='Intensity of sun light', default=2, min=0, max=100, update=updatebackground)
    sunRot_x: FloatProperty(description="Sun inclination", default=45, min=0, max=89, update=updatebackground)
    sunRot_z: FloatProperty(description="Sun Rotation", default=0, update=updatebackground)

    bright_hdri: FloatProperty(description="Brightness controll 0 = Default bright ", default=0, min=-1, max=1,
                               update=updatebackground)
    exposure_hdri: FloatProperty(description="Exposure controll 0 = Default exposure ", default=0, min=-10, max=10,
                                 update=updatebackground)
    emission_force: FloatProperty(description="Intensity of Hdri light", default=2, min=0, max=10,
                                  update=updatebackground)
    hue_saturation: FloatProperty(description="Saturation controll 1 = Default color ", default=1, min=0, max=5,
                                  update=updatebackground)
    up_category: EnumProperty(items=funzione_preview_categorie, update=update_first_icon)
    options_icon_size: FloatProperty(default=1, min=0, max=5, description='choose the size of the preview icon')
    options_scale_popup: FloatProperty(default=3, min=0, max=8)

    menu_enviroment: BoolProperty(default=False, description='Background options')
    menu_shadowcatcher: BoolProperty(default=False, description='This menu is dedicated to the shadow catcher.')
    menu_option: BoolProperty(default=False, description='Menu options')
    menu_icon_size: FloatProperty(default=2.5, min=0, max=8, description='Icon panel size')
    menu_icon_popup: FloatProperty(default=4, min=0, max=7, description='Icon popup size')
    menu_icon_theme: EnumProperty(default='BLUE', update=iconsSwitch,
                                  items=(('BLUE', "Blue", ""), ('PINK', "Pink", "")))
    menu_label: BoolProperty(default=True, description='Shows the name of the icons in the popup menu')
    menu_bottom: FloatProperty(default=0, min=-1, max=1, step=0.1, description='Adjust the z position',
                               update=updatebackground)
    auto_add: BoolProperty(default=False,
                           description='If this button is on, the backgrounds of the scene will change automatically as the preview changes only by the arrows use')
    last_preview: StringProperty()
    WindowManager.hdri_category = EnumProperty(
        items=funzione_preview_icone_hdri,
        description="Select by click"
    )
    save_menu: BoolProperty(default=False, description='This menu is dedicated to saving backgrounds')
    save_type: EnumProperty(default='CURRENT', items=(('CURRENT', "Current Background", 'Save the current background'),
                                                      ('PANORAMA', "Panorama 360 (Beta)",
                                                       "Create a 360 degree panoramic photo from current scene"),
                                                      ('BATCH', "Batch from folder",
                                                       "Multiple batch, save all the backgrounds contained in a directory")))
    save_source_path: StringProperty(subtype='DIR_PATH')
    scene_id_name: StringProperty()
    k_custom_size: BoolProperty(default=False)
    k_panorama_size: EnumProperty(default='4', items=(
    ('1', "1k", ""), ('2', "2k", ""), ('4', "4k", ""), ('8', "8k", ""), ('16', "16k", "")))
    k_panorama_size_custom: StringProperty(
        description='The value is expanded in k, so it will automatically correct the aspect ratio. For example, 2 = 2048x1024. Note, For decimal numbers use the dot.')
    render_sample: IntProperty(default=512, min=32, max=2048,
                               description='Render resolution, attention, a large number means better quality, but more time')
    personal_category: EnumProperty(items=saveCatView)
    category_destination: EnumProperty(items=saveCatView)
    add_category: StringProperty()
    safety_delete: BoolProperty(default=False, description='Safety delete category')
    world_save_name: StringProperty()
    redraw_menu: BoolProperty(default=False,
                              description='This menu is used to redesign the previews of backgrounds saved by the user')
    camera_redraw_rotation: IntProperty(default=0, min=-180, max=180)
    camera_redraw_up_down: IntProperty(default=0, min=-90, max=90)
    camera_redraw_tilt: IntProperty(default=0, min=-90, max=90)
    light_redraw: FloatProperty(default=1, min=0.5, max=10)
    saturation_redraw: FloatProperty(default=1, min=0, max=5)
    compute_processor: EnumProperty(default='GPU', items=(('GPU', "Gpu", ""), ('CPU', "Cpu", "")))
    sovrascrivi: BoolProperty(default=False, description='Overwrite the name if the name is present in this category')
    rename_category: StringProperty()
    renamed_material: StringProperty()
    collection_management: BoolProperty(default=False)
    shadow_detail: EnumProperty(update=update_scene_pref, default='512_1024_False_True',
                                items=(('64_64_False_False', "Very low", ""),
                                       ('256_512_False_True', "Low", ""),
                                       ('512_1024_False_True', "Default", ""),
                                       ('1024_2048_False_True', "High", ""),
                                       ('2048_2048_True_True', "Very high", ""),
                                       ('4096_4096_True_True', "Ultra", "")))

    blurry_value: FloatProperty(default=0, min=0, max=0.5, update=updatebackground,
                                description='Adjust the blurry intensity')
    colorize_mix: FloatProperty(default=0, min=0, max=1, update=updatebackground,
                                description='Adjust the colorize intensity')
    colorize: FloatVectorProperty(name="", subtype='COLOR', default=(0, 0, 0, 1), min=0.0, max=1.0, size=4,
                                  description='Colorize background', update=updatebackground)

    show_dome: BoolProperty(default=False, update=updatebackground, description="Enable / disable HDR projection")
    domeMap_x: FloatProperty(default=0, update=updatebackground,
                             description="Move the center of the projection on the x-axis")
    domeMap_y: FloatProperty(default=0, update=updatebackground,
                             description="Move the center of the projection on the y-axis")
    domeMap_z: FloatProperty(default=2, min=0.2, update=updatebackground,
                             description="This simulates +/- the height of the camera tripod. If you increase this value, you should increase the height of your camera to have a better visual effect")
    dome_size: FloatProperty(default=200, min=10, update=updatebackground,
                             description="Adjust the size of the dome. The value shown is the unit of measurement used. So 200 will equal 200 dome diameter")
    hdri_projected_menu: BoolProperty(default=False)

    dome_top_light: FloatProperty(default=2, min=0.5, update=updatebackground,
                                  description="Adjusts the light of the upper part of the dome, useful for adjusting the lighting differences between the ground")

    wrap_smooth: IntProperty(default=1, min=0, max=30, update=updatebackground,
                             description='Softens the ground with Wrapped objects')

    fog_menu: BoolProperty(default=False)
    fog_on_off: BoolProperty(default=False, update=load_fog, description='Show or hide the fog')
    fog_density: FloatProperty(default=0.4, min=0, max=2, step=0.001, update=updatebackground,
                               description="Fog intensity, to increase the white effect, use 'Emissive'")
    fog_level: FloatProperty(default=0.3, min=0, max=1, step=0.01, update=updatebackground,
                             description="Height of the fog from the ground, or from the sky, depending on the 'Flip top' option")
    fog_flip: BoolProperty(default=False, update=updatebackground,
                           description="Switch between fog from the ground to fog from the sky and vice versa")
    fog_box_size: FloatProperty(default=200, min=10, update=updatebackground,
                                description="The size of the box containing the fog, if you are using HDRi Projected, the size of the box will be set automatically")
    fog_wind: FloatProperty(default=0.2, min=0, max=1, update=updatebackground,
                            description="Fog animation, to show the best effect, increase the 'Patches' option")
    fog_direction: FloatProperty(default=0, update=updatebackground,
                                 description="Wind direction simulated on the fog (Rotation on Z-axis)")
    fog_patches: FloatProperty(default=0.7, min=0, max=1, update=updatebackground,
                               description="Patchy fog simulation. 0 = no blotches")
    fog_patches_size: FloatProperty(default=0.2, min=0, max=1, update=updatebackground,
                                    description="Patchy fog size,default=0.1")
    fog_emission: FloatProperty(default=0, min=0, max=1, update=updatebackground,
                                description="Fog emissivity. (In Cycles the fog will become a real light source)")
    fog_detail: EnumProperty(update=update_fog_details, default='4_32_8', items=(('16_8_2', "Very low", ""),
                                                                                 ('8_16_4', "Low", ""),
                                                                                 ('4_32_8', "Default", ""),
                                                                                 ('2_32_32', "High", ""),
                                                                                 ('2_64_64', "Very high", ""),
                                                                                 ('2_128_128', "Best", "")))


class HdriObjPropertySet(bpy.types.PropertyGroup):
    shadow_catcher_type: EnumProperty(default='SHADOW_CATCHER', update=update_shadow_catcher_type, items=(
    ('SHADOW_CATCHER', "Simple + reflection", "The basic shadow catcher, can create a simple reflex"),
    ('NORMAL_CATCHER', "Reflection + Normal", "Normal maps can be added to the reflection to simulate imperfections"),
    ('WATER_CATCHER', "Water effect", "Simulates an aquatic effect on a plane, works with an aquatic-type background")))
    ##
    realSun: StringProperty()
    object_id_name: StringProperty()

    alpha_mode: EnumProperty(default='BLEND', update=update_alpha, items=(
    ('BLEND', "Blend", "Less impact on performance, but no shadow reflection on other objects"),
    ('HASHED', "Hashed",
     "Shadows reflected on the objects in the scene, but require a large number of samples for an optimal result")))
    SC_SHADOW_RAMP_Range: FloatProperty(min=0, max=1, default=0.55, update=update_shadow_catcher,
                                        description="Adjust the shadow range, if this is not enough, For best results, raise the value of the sun")
    SC_SHADOW_RAMP_Fade: FloatProperty(min=0, max=1, default=0.3, update=update_shadow_catcher)
    SC_REFLECTION_MIX: FloatProperty(min=0, max=1, default=0, update=update_shadow_catcher)
    SC_REFLECTION_ROUGH: FloatProperty(min=0, max=1, default=0, update=update_shadow_catcher)
    SC_SHADOW_COLOR: FloatVectorProperty(name="", subtype='COLOR', default=(0, 0, 0, 1), min=0.0, max=1.0, size=4,
                                         description='Change the color of the shadow', update=update_shadow_catcher)
    SC_FADE_REFLECTION: FloatProperty(min=0, max=1, default=0.4, update=update_shadow_catcher,
                                      description='Manage the square gradient of reflection from the edges of the plane')
    SC_GRADIENT_REFLECTION_TYPE: EnumProperty(default='1', update=update_shadow_catcher, items=(
    ('1', "Square", "The fade will take place in a square design. Adjust the 'Reflection fade' to get a better result"),
    ('0', "Circle",
     "The fade will take place in a circular design. Adjust the 'Reflection fade' to get a better result")))
    normal_maps_list: EnumProperty(items=loadNormalMap, update=updateNormalMap)
    displace_maps_list: EnumProperty(items=loadDisplaceMap, update=update_displacement)
    normal_scale: FloatProperty(min=0, default=1, update=update_shadow_catcher)
    normal_rotation: FloatProperty(default=0, min=0, max=360, update=update_shadow_catcher)
    normal_strength: FloatProperty(default=1, min=0, max=2, update=update_shadow_catcher)

    water_type: EnumProperty(default='STATIC', update=update_shadow_catcher,
                             items=(('STATIC', "Static", ""), ('FLOW', "Flow", "")))
    water_vel: FloatProperty(default=5, min=0, max=50, description='Change the speed of the waves')
    water_bump: FloatProperty(default=1, min=0, max=1, description='Adjust wave strength', update=update_shadow_catcher)
    wave_size: FloatProperty(default=1, min=0, description='Adjust wave dimension', update=update_shadow_catcher)
    wave_detail: FloatProperty(default=5, min=0, max=16, description='Adjust the detail of the waves',
                               update=update_shadow_catcher)
    water_direct: FloatProperty(default=0, description='Adjust water direction', update=update_shadow_catcher)
    displace_strength: FloatProperty(default=0.5, min=0, max=10, update=update_displace_value)
    displace_smooth: FloatProperty(default=4, min=0, max=200, update=update_displace_value)
    displace_midlevel: FloatProperty(default=0, min=-1, max=1, update=update_displace_value)
    displace_scale: FloatProperty(default=1, min=0.1, max=10, update=update_displace_value)

    reflection_probe_size: FloatProperty(default=0.1, min=0.001, max=10, update=update_probe,
                                         description='Resize the shadow catcher relection plane (Cycles do not need it), this helps if there is a displacement, increasing the size increases the range of action.')
    show_wireframe: BoolProperty(default=False, update=update_wire, description='Show wireframe mesh')
    hide_wrap: BoolProperty(default=False, update=hide_Wrap_objects, description='Hide the wrapped object')


class HdriMatPropSet(bpy.types.PropertyGroup):
    mat_id_name: StringProperty()


class HdriWorldPropSet(bpy.types.PropertyGroup):
    world_id_name: StringProperty()
    world_id_base_name: StringProperty()
    world_id_savename: StringProperty()
    world_user: BoolProperty(default=False)
    world_hdri_maker: BoolProperty(default=False)
    world_nome_preview: StringProperty()


class HdirWorldImages(bpy.types.PropertyGroup):
    image_tag: BoolProperty()
    image_tag_normal: BoolProperty()
    image_tag_displace: BoolProperty()


class HdriTexturePropSet(bpy.types.PropertyGroup):
    texture_id_name: StringProperty()
    texture_tag_bool: BoolProperty(default=False)


class HdriNodesPropSet(bpy.types.PropertyGroup):
    node_id_name: StringProperty()
    node_to_delete: BoolProperty(default=False)


classes = (HDRI_PT_Panel,
           HdriPropertyScene,
           HDRI_OT_OperatorSky,
           HDRI_OT_CREDIT,
           DELETE_OT_BackgroundHdri,
           HdriObjPropertySet,
           PercorsoHDRiMaker,
           OBJECT_OT_hdri_maker_directory,
           HdriMatPropSet,
           PREVIUS_OT_HdriImage,
           SEARCHER_OT_Hdri,
           SEARCH_OT_InUseWorld,
           HdriWorldPropSet,
           PREVIUS_OT_CategoryHdri,
           NEXT_OT_CategoryHdri,
           RESET_OT_HDRiOptions,
           NEXT_OT_HdriImage,
           HDRIMAKER_OT_Save,
           HDRIMAKER_OT_BatchModal,
           HDRIMAKER_OT_AddCategory,
           HDRIMAKER_OT_RemoveCategory,
           HDRIMAKER_OT_RemoveBackground,
           HdirWorldImages,
           HDRIMAKER_OT_ObjectImporter,
           HDRIMAKER_OT_Redraw,
           HdriNodesPropSet,
           HDRIMAKER_OT_ExportHdr,
           HDRIMAKER_OT_RenameCurrentCat,
           HDRIMAKER_OT_RenameCurrentMat,
           HDRIMAKER_OT_FileToCat,
           HDRIMAKER_OT_ResnapCamera,
           HDRIMAKER_OT_ImportHdr,
           HDRIMAKER_OT_AddShadowCatcher,
           HDRIMAKER_OT_LightProbeForceDelete,
           HDRIMAKER_OT_RemoveShadowCatcher,
           HDRIMAKER_OT_AddSun,
           HDRIMAKER_OT_SwitchEngine,
           HDRIMAKER_OT_DisplaceAdd,
           HDRIMAKER_OT_SubdivideMesh,
           HDRIMAKER_OT_UnSubdivideMesh,
           HDRIMAKER_OT_DisplaceRemove,
           HdriTexturePropSet,
           HDRIMAKER_OT_FindCamera,
           HDRIMAKER_OT_ConvertToAbsolutePath,
           HDRIMAKER_OT_FinishConfirmation,
           HDRIMAKER_OT_IntallerModal,
           HDRIMAKER_OT_WebInfo,
           HDRIMAKER_OT_CheckForUpdate,
           HDRIMAKER_OT_AssignMat,
           HDRIMAKER_OT_Shrinkwrap
           )


def register():
    CollezioneHDRi = bpy.utils.previews.new()
    CollezioneHDRi.hdri_category = ()
    CollezioneHDRi.hdri_category_dir = ""
    hdri_preview_collection["HDRiCol"] = CollezioneHDRi

    kSizePreview = bpy.utils.previews.new()
    kSizePreview.k_size_list = ()
    kSizePreview.k_size_from_prev = ''
    k_size_refer["Refer"] = kSizePreview

    iconcollhdr = bpy.utils.previews.new()
    preview_icon_blu["icone"] = iconcollhdr
    hdriMkr_icon_dir = os.path.join(os.path.dirname(__file__), "HDRi_tools_lib", 'Icons', "BLUE")
    for ic in os.listdir(hdriMkr_icon_dir):
        iconcollhdr.load(ic, os.path.join(hdriMkr_icon_dir, ic), 'IMAGE')

    for cls in classes:
        bpy.utils.register_class(cls)

    Scene.hdri_prop_scn = bpy.props.PointerProperty(type=HdriPropertyScene)
    Object.hdri_prop_obj = bpy.props.PointerProperty(type=HdriObjPropertySet)
    Material.hdri_prop_mat = bpy.props.PointerProperty(type=HdriMatPropSet)
    World.hdri_prop_world = bpy.props.PointerProperty(type=HdriWorldPropSet)
    Image.hdri_prop_image = bpy.props.PointerProperty(type=HdirWorldImages)
    Node.hdri_prop_nodes = bpy.props.PointerProperty(type=HdriNodesPropSet)
    Texture.hdri_prop_texture = bpy.props.PointerProperty(type=HdriTexturePropSet)

    bpy.app.handlers.load_post.append(load_handler)
    bpy.app.handlers.depsgraph_update_post.append(engine_change_function)


def unregister():
    from bpy.types import WindowManager

    try:
        del WindowManager.hdri_category
    except:
        pass

    for CollezioneHDRi in hdri_preview_collection.values():
        bpy.utils.previews.remove(CollezioneHDRi)
    hdri_preview_collection.clear()

    for kSizePreview in k_size_refer.values():
        bpy.utils.previews.remove(kSizePreview)
    hdri_preview_collection.clear()

    for iconcollhdr in preview_icon_blu.values():
        bpy.utils.previews.remove(iconcollhdr)
    preview_icon_blu.clear()

    ###unregister class

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    bpy.app.handlers.load_post.remove(load_handler)
    bpy.app.handlers.depsgraph_update_post.remove(engine_change_function)


if __name__ == "__main__":
    register()
